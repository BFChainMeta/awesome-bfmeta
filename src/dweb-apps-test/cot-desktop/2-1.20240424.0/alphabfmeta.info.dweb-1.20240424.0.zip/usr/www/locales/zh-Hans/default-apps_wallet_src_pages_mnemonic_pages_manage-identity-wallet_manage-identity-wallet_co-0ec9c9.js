"use strict";
(self["webpackChunkwallet"] = self["webpackChunkwallet"] || []).push([["default-apps_wallet_src_pages_mnemonic_pages_manage-identity-wallet_manage-identity-wallet_co-0ec9c9"],{

/***/ 79033:
/*!*********************************************************************************************************!*\
  !*** ./apps/wallet/src/pages/mnemonic/pages/manage-identity-wallet/manage-identity-wallet.component.ts ***!
  \*********************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ManageIdentityWalletPage: () => (/* binding */ ManageIdentityWalletPage),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 52542);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! tslib */ 90505);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @angular/core */ 61039);
/* harmony import */ var _bnqkl_framework_controllers__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @bnqkl/framework/controllers */ 47919);
/* harmony import */ var _bnqkl_framework_helpers__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @bnqkl/framework/helpers */ 12169);
/* harmony import */ var _bnqkl_framework_plugins_toast__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @bnqkl/framework/plugins/toast */ 18030);
/* harmony import */ var _modules_page_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ~modules/page.module */ 77538);
/* harmony import */ var _services_permission_permission_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ~services/permission/permission.service */ 26502);
/* harmony import */ var _bnqkl_wallet_base_services_wallet_wallet_data_storage__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @bnqkl/wallet-base/services/wallet/wallet-data-storage */ 63024);
/* harmony import */ var _bnqkl_wallet_base_services_wallet_wallet__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @bnqkl/wallet-base/services/wallet/wallet */ 21789);
/* harmony import */ var _change_password_change_password_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../change-password/change-password.component */ 67948);
/* harmony import */ var _mnemonic_confirm_backup_mnemonic_confirm_backup_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../mnemonic-confirm-backup/mnemonic-confirm-backup.component */ 91879);
/* harmony import */ var _reset_password_reset_password_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../reset-password/reset-password.component */ 85652);
/* harmony import */ var _libs_bnf_components_ripple_button_ripple_button_directive__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../../../../../../libs/bnf/components/ripple-button/ripple-button.directive */ 16505);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @angular/common */ 6729);
/* harmony import */ var _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../../../../../../libs/bnf/modules/page/common-page/common-page.component */ 62052);
/* harmony import */ var _components_icon_icon_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../../../../components/icon/icon.component */ 74703);
/* harmony import */ var _pipes_color_color_pipe__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../../../../pipes/color/color.pipe */ 76489);

var _class;


















function ManageIdentityWalletPage_ng_container_11_button_1_span_6_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](0, "span", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const item_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"](2).$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtextInterpolate"](item_r1.tips);
  }
}
function ManageIdentityWalletPage_ng_container_11_button_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r7 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](0, "button", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("click", function ManageIdentityWalletPage_ng_container_11_button_1_Template_button_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵrestoreView"](_r7);
      const item_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"]().$implicit;
      const ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵresetView"](ctx_r5.mimeClick(item_r1.id));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](1, "div", 16)(2, "div", 5)(3, "span", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](5, "div", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](6, ManageIdentityWalletPage_ng_container_11_button_1_span_6_Template, 2, 1, "span", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelement"](7, "w-icon", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const item_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"]().$implicit;
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtextInterpolate"](item_r1.title);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngIf", !!item_r1.tips && ctx_r2.skipBackup);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("name", "right");
  }
}
function ManageIdentityWalletPage_ng_container_11_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](1, ManageIdentityWalletPage_ng_container_11_button_1_Template, 8, 3, "button", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const item_r1 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngIf", !item_r1.hide);
  }
}
const _c6 = a0 => ({
  "--color-1": a0
});
/**
 * 管理钱包
 */
class ManageIdentityWalletPage extends _modules_page_module__WEBPACK_IMPORTED_MODULE_4__.CommonPageBase {
  constructor() {
    super(...arguments);
    /** 页面返回值的类型 */
    this.returnValue$ = new _modules_page_module__WEBPACK_IMPORTED_MODULE_4__.PageReturnValue();
    /** 权限服务 */
    this._permissionService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_15__.inject)(_services_permission_permission_service__WEBPACK_IMPORTED_MODULE_5__.PermissionService);
    /** 钱包存储服务 */
    this._walletDataStorageService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_15__.inject)(_bnqkl_wallet_base_services_wallet_wallet_data_storage__WEBPACK_IMPORTED_MODULE_6__.WalletDataStorageService);
    /**
     * 传递过来的用户昵称类型
     */
    this.userNickName = '';
    /** 是否未备份 */
    this.skipBackup = true;
    /**
     * 用于判断钱包类型（身份、非身份）
     */
    this.walleterType = '';
    /**
     * 用于BFChain/CCChain链的地址密码
     */
    this.addressPasswordContent = '';
    /** 钱包对应的地址 */
    this.address = '';
    /** 功能列表 */
    this.noIdentityList = [{
      id: 'exportMnemonic',
      title: "\u5BFC\u51FA\u52A9\u8BB0\u8BCD",
      tips: "\u672A\u5907\u4EFD"
    }, {
      id: 'passwordHint',
      title: "\u5BC6\u7801\u63D0\u793A",
      hide: false
    }, {
      id: 'changePassword',
      title: "\u4FEE\u6539\u5BC6\u7801"
    }, {
      id: 'resetPassword',
      title: "\u91CD\u7F6E\u5BC6\u7801"
    }];
    /** 密码修改成功之后触发 */
    this.changePasswordPageReturnController = new _bnqkl_framework_controllers__WEBPACK_IMPORTED_MODULE_1__.PageReturnController(this, _change_password_change_password_component__WEBPACK_IMPORTED_MODULE_8__.ChangePasswordPage);
    /** 重置密码成功之后触发 */
    this.resetPasswordPageReturnController = new _bnqkl_framework_controllers__WEBPACK_IMPORTED_MODULE_1__.PageReturnController(this, _reset_password_reset_password_component__WEBPACK_IMPORTED_MODULE_10__.ResetPasswordPage);
    /** 备份过助记词 */
    this.mnemonicConfirmBackupPageturnController = new _bnqkl_framework_controllers__WEBPACK_IMPORTED_MODULE_1__.PageReturnController(this, _mnemonic_confirm_backup_mnemonic_confirm_backup_component__WEBPACK_IMPORTED_MODULE_9__["default"]);
  }
  /** 获取当前钱包的密码信息 */
  _getCurrentWalletPasswordInfo() {
    var _this = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const info = yield _this._walletDataStorageService.getWalleterInfo();
      if (info === undefined) {
        throw new Error('not find walleter info');
      }
      return info;
    })();
  }
  /** 点击功能列表触发事件 */
  mimeClick(event) {
    var _this2 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      if (event === 'editName') {
        const result = yield _this2.prompt({
          headerTitle: "\u4FEE\u6539\u7528\u6237\u540D",
          value: _this2.userNickName
        });
        if (result === null) {
          return;
        }
        const newUserNickName = result.trim();
        if (newUserNickName.length > 12 || newUserNickName.length === 0) {
          _bnqkl_framework_plugins_toast__WEBPACK_IMPORTED_MODULE_3__.Toast.show("\u94B1\u5305\u540D\u79F0\u957F\u5EA61~12");
          return;
        }
        const oldName = _this2.userNickName;
        /** 引入钱包本地存储服务 */
        const walleter = yield _this2._walletDataStorageService.getWalleterInfo();
        if (walleter) {
          try {
            walleter.name = newUserNickName;
            yield _this2._walletDataStorageService.saveWalleterInfo(walleter);
            _bnqkl_framework_plugins_toast__WEBPACK_IMPORTED_MODULE_3__.Toast.show("\u6210\u529F");
            _this2.userNickName = newUserNickName;
            _this2.returnValue$.next({
              result: newUserNickName
            });
          } catch (err) {
            walleter.name = oldName;
            _this2.userNickName = oldName;
            _this2.console.error(err);
            _bnqkl_framework_plugins_toast__WEBPACK_IMPORTED_MODULE_3__.Toast.show("\u5931\u8D25");
          }
        }
      }
      if (event === 'exportMnemonic') {
        // 需要先验证密码
        const pwdInfo = yield _this2._permissionService.requestPassword();
        if (pwdInfo === false || pwdInfo === null) {
          return;
        }
        /** 引入钱包本地存储服务 */
        const walletDataStorage = _this2.injectorForceGet(_bnqkl_wallet_base_services_wallet_wallet_data_storage__WEBPACK_IMPORTED_MODULE_6__.WalletDataStorageService);
        /** 获取当前使用者的助记词 */
        const walleter = yield walletDataStorage.getWalleterInfo();
        if (walleter === undefined) {
          throw new Error(`not find wallet`);
        }
        _this2.nav.routeTo('/mnemonic/mnemonic-backup-tips', {
          export: true,
          backUrl: '/mnemonic/manage-identity-wallet',
          mnemonicString: walleter.mnemonic,
          backup: true
        });
      }
      if (event === 'passwordHint') {
        const {
          passwordTips
        } = yield _this2._getCurrentWalletPasswordInfo();
        _this2.alert({
          headerTitle: "\u5BC6\u7801\u63D0\u793A",
          bodyMessage: passwordTips || '',
          buttonText: "\u786E\u5B9A"
        }, {
          panelClass: '_password-hint'
        });
      }
      if (event === 'changePassword') {
        _this2.nav.routeTo('/mnemonic/change-password', {
          chain: _this2.chain,
          address: _this2.address,
          notMainWalletKey: ''
        });
      }
      if (event === 'resetPassword') {
        _this2.nav.routeTo('/mnemonic/reset-password', {
          importType: _bnqkl_wallet_base_services_wallet_wallet_data_storage__WEBPACK_IMPORTED_MODULE_6__.WALLET_IMPORT_TYPE.mnemonic
        });
      }
    })();
  }
  /** 初始化获取传参 */
  initWalletInfo() {
    var _this3 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const walletDataStorageService = _this3.injectorForceGet(_bnqkl_wallet_base_services_wallet_wallet_data_storage__WEBPACK_IMPORTED_MODULE_6__.WalletDataStorageService);
      const walleterInfo = yield walletDataStorageService.getWalleterInfo();
      if (walleterInfo) {
        _this3.userNickName = walleterInfo.name;
        if ((0,_bnqkl_framework_helpers__WEBPACK_IMPORTED_MODULE_2__.$isNoEmptyString)(walleterInfo.passwordTips) === false) {
          /// 隐藏提示
          const t = _this3.noIdentityList.find(item => item.id === 'passwordHint');
          if (t) {
            t.hide = true;
            _this3.cdRef.detectChanges();
          }
        }
        _this3.skipBackup = !!walleterInfo.skipBackup;
      }
      /** 修改密码页 */
      _this3.changePasswordPageReturnController.pageReturn$.subscribe(data => {
        if (data.result === 'success') {
          if ((0,_bnqkl_framework_helpers__WEBPACK_IMPORTED_MODULE_2__.$isNoEmptyString)(data.tipContent) === false) {
            /// 隐藏提示
            _this3.isPasswordHint(true);
          } else {
            _this3.isPasswordHint(false);
          }
        }
      });
      /** 重置密码页 */
      _this3.resetPasswordPageReturnController.pageReturn$.subscribe(data => {
        if (data.result === 'success') {
          if ((0,_bnqkl_framework_helpers__WEBPACK_IMPORTED_MODULE_2__.$isNoEmptyString)(data.tipContent) === false) {
            /// 隐藏提示
            _this3.isPasswordHint(true);
          } else {
            _this3.isPasswordHint(false);
          }
        }
      });
      /** 备份助记词页 */
      _this3.mnemonicConfirmBackupPageturnController.pageReturn$.subscribe(data => {
        if (data) {
          _this3.skipBackup = false;
        }
      });
    })();
  }
  /** 刷新页面，显示或者隐藏密码提示 */
  isPasswordHint(result) {
    /// 隐藏提示
    const t = this.noIdentityList.find(item => item.id === 'passwordHint');
    if (t) {
      t.hide = result;
      this.cdRef.detectChanges();
    }
  }
  /** 退出身份钱包 */
  signOutMainWallet() {
    var _this4 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const walleterInfo = yield _this4._walletDataStorageService.getWalleterInfo();
      const hasNeedBackup = !!walleterInfo.skipBackup;
      if (hasNeedBackup) {
        const confirmed = yield _this4.confirm({
          headerTitle: "\u672A\u5907\u4EFD\u8EAB\u4EFD",
          bodyMessage: "\u5F53\u524D\u8EAB\u4EFD\u672A\u5907\u4EFD\uFF0C\u987B\u5B8C\u6210\u5907\u4EFD\u8EAB\u4EFD\u94B1\u5305\u52A9\u8BB0\u8BCD\u624D\u53EF\u9000\u51FA\u3002",
          confirmText: "\u524D\u5F80\u5907\u4EFD",
          cancelText: "\u53D6\u6D88"
        });
        if (confirmed) {
          _this4.nav.routeBack('/mnemonic/mnemonic-backup-tips', {
            export: true,
            backUrl: '/mnemonic/manage-identity-wallet',
            mnemonicString: walleterInfo.mnemonic,
            backup: true
          });
        }
        return;
      }
      const confirmed = yield _this4.confirm({
        headerTitle: "\u63D0\u793A",
        bodyMessage: "\u5220\u9664\u8EAB\u4EFD\u540E\uFF0C\u6240\u6709\u94B1\u5305\u6570\u636E\u5C06\u4F1A\u88AB\u5220\u9664\uFF08\u5305\u62EC\u8EAB\u4EFD\u94B1\u5305\u548C\u5BFC\u5165\u94B1\u5305\uFF09\uFF0C\u5EFA\u8BAE\u5B8C\u6210\u5907\u4EFD\u540E\u518D\u64CD\u4F5C\uFF0C\u786E\u5B9A\u5220\u9664\uFF1F",
        footerTheme: 'warn'
      });
      if (confirmed === false) {
        return;
      }
      const pwdInfo = yield _this4._permissionService.requestPassword();
      if (pwdInfo === null || pwdInfo === false) {
        return;
      }
      const walletService = _this4.injectorForceGet(_bnqkl_wallet_base_services_wallet_wallet__WEBPACK_IMPORTED_MODULE_7__.WalletService);
      yield walletService.mainWalletSignOut();
      _this4.nav.setPageRoot('mnemonic');
    })();
  }
}
_class = ManageIdentityWalletPage;
_class.ɵfac = /*@__PURE__*/(() => {
  let ɵManageIdentityWalletPage_BaseFactory;
  return function ManageIdentityWalletPage_Factory(t) {
    return (ɵManageIdentityWalletPage_BaseFactory || (ɵManageIdentityWalletPage_BaseFactory = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵgetInheritedFactory"](_class)))(t || _class);
  };
})();
_class.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵdefineComponent"]({
  type: _class,
  selectors: [["w-manage-identity-wallet-page"]],
  outputs: {
    returnValue$: "returnValue$"
  },
  standalone: true,
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵInheritDefinitionFeature"], _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵStandaloneFeature"]],
  decls: 16,
  vars: 11,
  consts: () => {
    let i18n_0;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_USER_AVATOR_AND_NIKENAME$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_MANAGE_IDENTITY_WALLET_MANAGE_IDENTITY_WALLET_COMPONENT_TS_1 = goog.getMsg("User avatar and nickname");
      i18n_0 = MSG_EXTERNAL_USER_AVATOR_AND_NIKENAME$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_MANAGE_IDENTITY_WALLET_MANAGE_IDENTITY_WALLET_COMPONENT_TS_1;
    } else {
      i18n_0 = "\u7528\u6237\u5934\u50CF\u548C\u6635\u79F0";
    }
    let i18n_2;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_MODIFY_IDENTITY_NAME$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_MANAGE_IDENTITY_WALLET_MANAGE_IDENTITY_WALLET_COMPONENT_TS_3 = goog.getMsg("Modify Identity Name");
      i18n_2 = MSG_EXTERNAL_MODIFY_IDENTITY_NAME$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_MANAGE_IDENTITY_WALLET_MANAGE_IDENTITY_WALLET_COMPONENT_TS_3;
    } else {
      i18n_2 = "\u4FEE\u6539\u94B1\u5305\u540D\u79F0";
    }
    let i18n_4;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_DELETE_IDENTITY_WALLET$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_MANAGE_IDENTITY_WALLET_MANAGE_IDENTITY_WALLET_COMPONENT_TS_5 = goog.getMsg("Delete Identity Wallet");
      i18n_4 = MSG_EXTERNAL_DELETE_IDENTITY_WALLET$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_MANAGE_IDENTITY_WALLET_MANAGE_IDENTITY_WALLET_COMPONENT_TS_5;
    } else {
      i18n_4 = "\u5220\u9664\u8EAB\u4EFD\u94B1\u5305";
    }
    return [[3, "contentBackground", "contentSafeArea"], [1, "px-page-safe-area-inset", "mb-1.5", "flex", "h-20", "w-full", "items-center", "justify-between", "bg-white", 3, "click"], ["aria-label", i18n_0, 1, "flex", "items-center"], ["name", "head", 1, "text-5xl"], [1, "ml-1.5", "font-semibold"], [1, "flex", "items-center"], [1, "text-subtext", "text-xs"], i18n_2, [1, "icon-4", "text-subtext", 3, "name"], [4, "ngFor", "ngForOf"], ["footer", ""], ["bnRippleButton", "", 1, "h-10.5", "w-full", "rounded-full", "bg-white", "text-center", 3, "click"], [1, "text-error"], i18n_4, ["bnRippleButton", "", "class", "px-page-safe-area-inset h-14 w-full bg-white", 3, "click", 4, "ngIf"], ["bnRippleButton", "", 1, "px-page-safe-area-inset", "h-14", "w-full", "bg-white", 3, "click"], [1, "flex", "h-14", "items-center", "justify-between"], [1, "text-title"], ["class", "text-error text-xs", 4, "ngIf"], [1, "text-error", "text-xs"]];
  },
  template: function ManageIdentityWalletPage_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](0, "common-page", 0)(1, "div", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("click", function ManageIdentityWalletPage_Template_div_click_1_listener() {
        return ctx.mimeClick("editName");
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](2, "div", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelement"](3, "w-icon", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipe"](4, "color");
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](5, "span", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](6);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](7, "div", 5)(8, "span", 6);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵi18n"](9, 7);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelement"](10, "w-icon", 8);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](11, ManageIdentityWalletPage_ng_container_11_Template, 2, 1, "ng-container", 9);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](12, "div", 10)(13, "button", 11);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("click", function ManageIdentityWalletPage_Template_button_click_13_listener() {
        return ctx.signOutMainWallet();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](14, "span", 12);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵi18n"](15, 13);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]()()()();
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("contentBackground", "env")("contentSafeArea", false);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpureFunction1"](9, _c6, _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipeBind1"](4, 7, "subtext")));
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtextInterpolate"](ctx.userNickName);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](4);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("name", "right");
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngForOf", ctx.noIdentityList);
    }
  },
  dependencies: [_modules_page_module__WEBPACK_IMPORTED_MODULE_4__.CommonPageModule, _libs_bnf_components_ripple_button_ripple_button_directive__WEBPACK_IMPORTED_MODULE_11__.RippleButtonDirective, _angular_common__WEBPACK_IMPORTED_MODULE_16__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_16__.NgIf, _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_12__.CommonPageComponent, _components_icon_icon_component__WEBPACK_IMPORTED_MODULE_13__.IconComponent, _pipes_color_color_pipe__WEBPACK_IMPORTED_MODULE_14__.ColorPipe],
  styles: ["._password-hint common-card-text-body > p {\n    border-radius: 0.5rem;\n    --tw-bg-opacity: 1;\n    background-color: rgb(243 242 255 / var(--tw-bg-opacity));\n    padding: 0.5rem\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL2FwcHMvd2FsbGV0L3NyYy9wYWdlcy9tbmVtb25pYy9wYWdlcy9tYW5hZ2UtaWRlbnRpdHktd2FsbGV0L21hbmFnZS1pZGVudGl0eS13YWxsZXQuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBRUk7SUFBQSxxQkFBQTtJQUFBLGtCQUFBO0lBQUEseURBQUE7SUFBQTtBQUFBIiwic291cmNlc0NvbnRlbnQiOlsiOjpuZy1kZWVwIC5fcGFzc3dvcmQtaGludCB7XHJcbiAgY29tbW9uLWNhcmQtdGV4dC1ib2R5ID4gcCB7XHJcbiAgICBAYXBwbHkgYmctZW52IHJvdW5kZWQtMiBwLTI7XHJcbiAgfVxyXG59XHJcbiJdLCJzb3VyY2VSb290IjoiIn0= */"],
  changeDetection: 0
});
(0,tslib__WEBPACK_IMPORTED_MODULE_17__.__decorate)([ManageIdentityWalletPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_17__.__metadata)("design:type", Object)], ManageIdentityWalletPage.prototype, "userNickName", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_17__.__decorate)([ManageIdentityWalletPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_17__.__metadata)("design:type", Object)], ManageIdentityWalletPage.prototype, "skipBackup", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_17__.__decorate)([ManageIdentityWalletPage.State(), ManageIdentityWalletPage.QueryParam('walleterType'), (0,tslib__WEBPACK_IMPORTED_MODULE_17__.__metadata)("design:type", Object)], ManageIdentityWalletPage.prototype, "walleterType", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_17__.__decorate)([ManageIdentityWalletPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_17__.__metadata)("design:type", Object)], ManageIdentityWalletPage.prototype, "addressPasswordContent", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_17__.__decorate)([ManageIdentityWalletPage.QueryParam('address'), (0,tslib__WEBPACK_IMPORTED_MODULE_17__.__metadata)("design:type", Object)], ManageIdentityWalletPage.prototype, "address", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_17__.__decorate)([ManageIdentityWalletPage.QueryParam('chain'), (0,tslib__WEBPACK_IMPORTED_MODULE_17__.__metadata)("design:type", String)], ManageIdentityWalletPage.prototype, "chain", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_17__.__decorate)([ManageIdentityWalletPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_17__.__metadata)("design:type", Object)], ManageIdentityWalletPage.prototype, "changePasswordPageReturnController", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_17__.__decorate)([ManageIdentityWalletPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_17__.__metadata)("design:type", Object)], ManageIdentityWalletPage.prototype, "resetPasswordPageReturnController", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_17__.__decorate)([ManageIdentityWalletPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_17__.__metadata)("design:type", Object)], ManageIdentityWalletPage.prototype, "mnemonicConfirmBackupPageturnController", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_17__.__decorate)([ManageIdentityWalletPage.OnInit(), (0,tslib__WEBPACK_IMPORTED_MODULE_17__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_17__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_17__.__metadata)("design:returntype", Promise)], ManageIdentityWalletPage.prototype, "initWalletInfo", null);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ManageIdentityWalletPage);

/***/ })

}]);
//# sourceMappingURL=default-apps_wallet_src_pages_mnemonic_pages_manage-identity-wallet_manage-identity-wallet_co-0ec9c9.js.map