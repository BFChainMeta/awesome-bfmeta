"use strict";
(self["webpackChunkwallet"] = self["webpackChunkwallet"] || []).push([["apps_wallet_src_pages_data-upgrade-instructions_data-upgrade-instructions_component_ts"],{

/***/ 6041:
/*!************************************************************************************************!*\
  !*** ./apps/wallet/src/pages/data-upgrade-instructions/data-upgrade-instructions.component.ts ***!
  \************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   DataUpgradeInstructionsPage: () => (/* binding */ DataUpgradeInstructionsPage),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 52542);
/* harmony import */ var D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncIterator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/esm/asyncIterator.js */ 9243);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! tslib */ 90505);
/* harmony import */ var _modules_page_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ~modules/page.module */ 77538);
/* harmony import */ var _bnqkl_framework_animations__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @bnqkl/framework/animations */ 43127);
/* harmony import */ var _bnqkl_wallet_base_services_wallet__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @bnqkl/wallet-base/services/wallet */ 20609);
/* harmony import */ var _bnqkl_framework_helpers__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @bnqkl/framework/helpers */ 12169);
/* harmony import */ var _bnqkl_framework_plugins__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @bnqkl/framework/plugins */ 43990);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/core */ 61039);
/* harmony import */ var _libs_bnf_components_ripple_button_ripple_button_directive__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../../../libs/bnf/components/ripple-button/ripple-button.directive */ 16505);
/* harmony import */ var _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../../../libs/bnf/modules/page/common-page/common-page.component */ 62052);
/* harmony import */ var _libs_bnf_components_loading_wrapper_loading_wrapper_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../../../../libs/bnf/components/loading-wrapper/loading-wrapper.component */ 51263);


var _class;










/** 升级数据页面 */
class DataUpgradeInstructionsPage extends _modules_page_module__WEBPACK_IMPORTED_MODULE_2__.CommonPageBase {
  constructor() {
    var _this;
    /** 应用名称 */
    super(...arguments);
    _this = this;
    this.appName = APP_NAME;
    /** 数据升级 */
    this.upgrade = (0,_bnqkl_framework_helpers__WEBPACK_IMPORTED_MODULE_5__.$singleton)( /*#__PURE__*/(0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const walletV2Service = _this.injectorForceGet(_bnqkl_wallet_base_services_wallet__WEBPACK_IMPORTED_MODULE_4__.WalletV2Service);
      const walletDataStorageService = _this.injectorForceGet(_bnqkl_wallet_base_services_wallet__WEBPACK_IMPORTED_MODULE_4__.WalletDataStorageService);
      const chainTokenDetailStoreService = _this.injectorForceGet(_bnqkl_wallet_base_services_wallet__WEBPACK_IMPORTED_MODULE_4__.ChainTokenDetailStoreService);
      const chainAddressBookStorageService = _this.injectorForceGet(_bnqkl_wallet_base_services_wallet__WEBPACK_IMPORTED_MODULE_4__.ChainAddressBookStorageService);
      const walletDataStorageV2Service = _this.injectorForceGet(_bnqkl_wallet_base_services_wallet__WEBPACK_IMPORTED_MODULE_4__.WalletDataStorageV2Service);
      {
        /// 简单的先来，先处理合约币种
        const allContractAddressTokenInfoKeys = yield walletDataStorageService.getAllContractAddressTokenInfoKeys();
        var _iteratorAbruptCompletion = false;
        var _didIteratorError = false;
        var _iteratorError;
        try {
          for (var _iterator = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncIterator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(allContractAddressTokenInfoKeys), _step; _iteratorAbruptCompletion = !(_step = yield _iterator.next()).done; _iteratorAbruptCompletion = false) {
            const key = _step.value;
            {
              const info = yield walletDataStorageService.getContractAddressTokenInfo(key);
              info && (yield chainTokenDetailStoreService.saveContractAddressTokenInfo(key, info));
            }
          }
        } catch (err) {
          _didIteratorError = true;
          _iteratorError = err;
        } finally {
          try {
            if (_iteratorAbruptCompletion && _iterator.return != null) {
              yield _iterator.return();
            }
          } finally {
            if (_didIteratorError) {
              throw _iteratorError;
            }
          }
        }
      }
      {
        /// 地址薄合并
        const allAddressBook = yield walletDataStorageService.getAllChainAddressBook();
        /// 构建数据
        const addressBook_Map = new Map();
        allAddressBook.forEach(item => {
          const info = addressBook_Map.get(item.address);
          const chainItem = {
            symbol: item.symbol,
            chain: item.chain
          };
          if (info) {
            info.chainList.push(chainItem);
          } else {
            addressBook_Map.set(item.addressBookId, {
              ...item,
              chainList: [chainItem]
            });
          }
        });
        var _iteratorAbruptCompletion2 = false;
        var _didIteratorError2 = false;
        var _iteratorError2;
        try {
          for (var _iterator2 = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncIterator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(addressBook_Map.values()), _step2; _iteratorAbruptCompletion2 = !(_step2 = yield _iterator2.next()).done; _iteratorAbruptCompletion2 = false) {
            const item = _step2.value;
            {
              yield chainAddressBookStorageService.saveChainAddressBook(item);
            }
          }
        } catch (err) {
          _didIteratorError2 = true;
          _iteratorError2 = err;
        } finally {
          try {
            if (_iteratorAbruptCompletion2 && _iterator2.return != null) {
              yield _iterator2.return();
            }
          } finally {
            if (_didIteratorError2) {
              throw _iteratorError2;
            }
          }
        }
      }
      {
        /// 钱包数据迁移
        /// 旧版本身份钱包肯定是 助记词 的
        const oldMainWallet = yield walletDataStorageService.getWalleterInfo();
        /// 对非身份钱包进行归集， 区分生物链以及外链， 生物链必定 助剂词模式
        const notMainWalletList = (yield walletDataStorageService.getAllNotMainWalletList()).flat();
        /// 非身份钱包地址整合
        const phraseInfo_Map = new Map();
        notMainWalletList.forEach(item => {
          if (phraseInfo_Map.has(item.address) === false) {
            phraseInfo_Map.set(item.address, {
              importPhrase: item.importPhrase,
              chainName: item.chain,
              importType: item.importType
            });
          }
        });
        /// 优先原来的身份钱包
        const {
          defaultWallet
        } = yield walletV2Service.createMainWallet({
          importPhrase: oldMainWallet.mnemonic,
          importType: _bnqkl_wallet_base_services_wallet__WEBPACK_IMPORTED_MODULE_4__.WALLET_IMPORT_TYPE.mnemonic
        }, {
          skipBackup: !!oldMainWallet.skipBackup
        });
        walletDataStorageV2Service.walletAppSettings.fingerprintPay = false;
        walletDataStorageV2Service.walletAppSettings.lastWalletActivate = defaultWallet;
        walletDataStorageV2Service.walletAppSettings.password = oldMainWallet.password;
        var _iteratorAbruptCompletion3 = false;
        var _didIteratorError3 = false;
        var _iteratorError3;
        try {
          for (var _iterator3 = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncIterator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(phraseInfo_Map.values()), _step3; _iteratorAbruptCompletion3 = !(_step3 = yield _iterator3.next()).done; _iteratorAbruptCompletion3 = false) {
            const item = _step3.value;
            {
              yield walletV2Service.createMainWallet({
                ...item
              });
            }
          }
        } catch (err) {
          _didIteratorError3 = true;
          _iteratorError3 = err;
        } finally {
          try {
            if (_iteratorAbruptCompletion3 && _iterator3.return != null) {
              yield _iterator3.return();
            }
          } finally {
            if (_didIteratorError3) {
              throw _iteratorError3;
            }
          }
        }
        return _this.nav.setPageRoot('guide');
      }
    }));
  }
  hideSplashScreen() {
    _bnqkl_framework_plugins__WEBPACK_IMPORTED_MODULE_6__.SplashScreen.hide();
  }
}
_class = DataUpgradeInstructionsPage;
_class.ɵfac = /*@__PURE__*/(() => {
  let ɵDataUpgradeInstructionsPage_BaseFactory;
  return function DataUpgradeInstructionsPage_Factory(t) {
    return (ɵDataUpgradeInstructionsPage_BaseFactory || (ɵDataUpgradeInstructionsPage_BaseFactory = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵgetInheritedFactory"](_class)))(t || _class);
  };
})();
_class.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵdefineComponent"]({
  type: _class,
  selectors: [["w-data-upgrade-instructions-page"]],
  standalone: true,
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵInheritDefinitionFeature"], _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵStandaloneFeature"]],
  decls: 25,
  vars: 10,
  consts: () => {
    let i18n_0;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_DUE_TO_THE_UPGRADE_OF_THE_NEW_VERSION_OF__APP_NAME__TIPS$$APPS_WALLET_SRC_PAGES_DATA_UPGRADE_INSTRUCTIONS_DATA_UPGRADE_INSTRUCTIONS_COMPONENT_TS_1 = goog.getMsg(" Due to the upgrade of the new version of {$interpolation}, which optimizes the wallet structure and interaction logic, the old data will be modified as follows. ", {
        "interpolation": "\uFFFD0\uFFFD"
      }, {
        original_code: {
          "interpolation": "{{ appName }}"
        }
      });
      i18n_0 = MSG_EXTERNAL_DUE_TO_THE_UPGRADE_OF_THE_NEW_VERSION_OF__APP_NAME__TIPS$$APPS_WALLET_SRC_PAGES_DATA_UPGRADE_INSTRUCTIONS_DATA_UPGRADE_INSTRUCTIONS_COMPONENT_TS_1;
    } else {
      i18n_0 = "\u7531\u65BC " + "\uFFFD0\uFFFD" + " \u65B0\u7248\u672C\u7684\u5347\u7D1A\uFF0C\u512A\u5316\u4E86\u9322\u5305\u6578\u64DA\u7D50\u69CB\u8207\u4E92\u52D5\u908F\u8F2F\uFF0C\u820A\u8CC7\u6599\u5C07\u505A\u4EE5\u4E0B\u4FEE\u6539\u3002 ";
    }
    let i18n_2;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_1_ALL_WALLET_DATA_IN_THE_ORIGINAL__APP_NAME_$$APPS_WALLET_SRC_PAGES_DATA_UPGRADE_INSTRUCTIONS_DATA_UPGRADE_INSTRUCTIONS_COMPONENT_TS_3 = goog.getMsg(" 1. All wallet data in the original {$interpolation} will be retained and the data will be organized. The rules are as follows: ", {
        "interpolation": "\uFFFD0\uFFFD"
      }, {
        original_code: {
          "interpolation": "{{ appName }}"
        }
      });
      i18n_2 = MSG_EXTERNAL_1_ALL_WALLET_DATA_IN_THE_ORIGINAL__APP_NAME_$$APPS_WALLET_SRC_PAGES_DATA_UPGRADE_INSTRUCTIONS_DATA_UPGRADE_INSTRUCTIONS_COMPONENT_TS_3;
    } else {
      i18n_2 = "1. \u539F " + "\uFFFD0\uFFFD" + " \u4E2D\u7684\u9322\u5305\u8CC7\u6599\u5C07\u5168\u90E8\u4FDD\u7559\uFF0C\u4E26\u9032\u884C\u8CC7\u6599\u6574\u7406\uFF0C\u898F\u5247\u5982\u4E0B\uFF1A ";
    }
    let i18n_4;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_DATA_UPGEADE_WALLET_NAME_TIPS$$APPS_WALLET_SRC_PAGES_DATA_UPGRADE_INSTRUCTIONS_DATA_UPGRADE_INSTRUCTIONS_COMPONENT_TS_5 = goog.getMsg("The original identity wallet will be \"Wallet 1\"; the first imported non-identity wallet will be \"Wallet 2\", and so on;");
      i18n_4 = MSG_EXTERNAL_DATA_UPGEADE_WALLET_NAME_TIPS$$APPS_WALLET_SRC_PAGES_DATA_UPGRADE_INSTRUCTIONS_DATA_UPGRADE_INSTRUCTIONS_COMPONENT_TS_5;
    } else {
      i18n_4 = "\u539F\u8EAB\u4EFD\u9322\u5305\u5C07\u4F5C\u70BA\u201C\u9322\u53051\u201D\uFF1B\u5C0E\u5165\u7684\u7B2C\u4E00\u500B\u975E\u8EAB\u4EFD\u9322\u5305\u5C07\u4F5C\u70BA\u201C\u9322\u53052\u201D\uFF0C\u4EE5\u6B64\u985E\u63A8\uFF1B";
    }
    let i18n_6;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_NON_IDENTITY_ASSOCIATE_ALL_CHAIN_TIPS$$APPS_WALLET_SRC_PAGES_DATA_UPGRADE_INSTRUCTIONS_DATA_UPGRADE_INSTRUCTIONS_COMPONENT_TS_7 = goog.getMsg("The original non-identity wallet will associate all corresponding chains according to the mnemonic phrase;");
      i18n_6 = MSG_EXTERNAL_NON_IDENTITY_ASSOCIATE_ALL_CHAIN_TIPS$$APPS_WALLET_SRC_PAGES_DATA_UPGRADE_INSTRUCTIONS_DATA_UPGRADE_INSTRUCTIONS_COMPONENT_TS_7;
    } else {
      i18n_6 = "\u539F\u975E\u8EAB\u4EFD\u9322\u5305\u5C07\u6839\u64DA\u52A9\u8A18\u8A5E\u95DC\u806F\u5C0D\u61C9\u7684\u6240\u6709\u93C8\uFF1B";
    }
    let i18n_8;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_WALLETS_ORIGINALLY_IMPORTED_WILL_BE_MERGED_TIPS$$APPS_WALLET_SRC_PAGES_DATA_UPGRADE_INSTRUCTIONS_DATA_UPGRADE_INSTRUCTIONS_COMPONENT_TS_9 = goog.getMsg("Wallets originally imported from different chains with the same mnemonic phrase will be merged;");
      i18n_8 = MSG_EXTERNAL_WALLETS_ORIGINALLY_IMPORTED_WILL_BE_MERGED_TIPS$$APPS_WALLET_SRC_PAGES_DATA_UPGRADE_INSTRUCTIONS_DATA_UPGRADE_INSTRUCTIONS_COMPONENT_TS_9;
    } else {
      i18n_8 = "\u539F\u5C0E\u5165\u7684\u76F8\u540C\u52A9\u8A18\u8A5E\u4E0D\u540C\u93C8\u7684\u9322\u5305\u5C07\u5408\u4F75\uFF1B";
    }
    let i18n_10;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_2_THE_ORIGINAL_IDENTITY_WALLET_PASSWORD_WILL_BE_USED_AS_THE_PASSWORD_FOR_ALL_WALLET$$APPS_WALLET_SRC_PAGES_DATA_UPGRADE_INSTRUCTIONS_DATA_UPGRADE_INSTRUCTIONS_COMPONENT_TS_11 = goog.getMsg(" 2. The original identity wallet password will be used as the password for all wallets and used for verification such as transfer/backup mnemonic phrases. ");
      i18n_10 = MSG_EXTERNAL_2_THE_ORIGINAL_IDENTITY_WALLET_PASSWORD_WILL_BE_USED_AS_THE_PASSWORD_FOR_ALL_WALLET$$APPS_WALLET_SRC_PAGES_DATA_UPGRADE_INSTRUCTIONS_DATA_UPGRADE_INSTRUCTIONS_COMPONENT_TS_11;
    } else {
      i18n_10 = "2. \u539F\u8EAB\u4EFD\u9322\u5305\u5BC6\u78BC\u5C07\u4F5C\u70BA\u6240\u6709\u9322\u5305\u7684\u5BC6\u78BC\uFF0C\u7528\u65BC\u8F49\u8CEC/\u5099\u4EFD\u52A9\u8A18\u8A5E\u7B49\u9A57\u8B49\u3002";
    }
    let i18n_12;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_OPEN_NEW_VERSION$$APPS_WALLET_SRC_PAGES_DATA_UPGRADE_INSTRUCTIONS_DATA_UPGRADE_INSTRUCTIONS_COMPONENT_TS_13 = goog.getMsg("Open new version");
      i18n_12 = MSG_EXTERNAL_OPEN_NEW_VERSION$$APPS_WALLET_SRC_PAGES_DATA_UPGRADE_INSTRUCTIONS_DATA_UPGRADE_INSTRUCTIONS_COMPONENT_TS_13;
    } else {
      i18n_12 = "\u958B\u59CB\u9AD4\u9A57\u65B0\u7248\u672C";
    }
    return [[3, "contentBackground", "headerBackground", "headerTranslucent", "contentSafeArea", "backButtonDisable"], [1, "text-title", "mt-6", "font-bold"], i18n_0, [1, "text-subtext", "mt-4", "w-full", "text-start"], [1, "mb-2"], i18n_2, [1, "mb-2", "flex", "items-center", "justify-start", "pl-5"], [1, "bg-subtext", "mr-[6px]", "inline-block", "h-[5px]", "w-[5px]", "shrink-0", "rounded-full"], i18n_4, i18n_6, i18n_8, [1, "mt-4", "font-bold"], i18n_10, ["footer", ""], ["bnRippleButton", "", 1, "h-10.5", "from-purple-gradient-start", "to-purple-gradient-end", "mb-4", "w-full", "rounded-full", "bg-gradient-to-b", "text-center", "text-sm", "text-white", 3, "disabled", "click"], [3, "loadingTheme", "waitFor"], i18n_12];
  },
  template: function DataUpgradeInstructionsPage_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "common-page", 0)(1, "div", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵi18n"](2, 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](3, "div", 3)(4, "div", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵi18n"](5, 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](6, "div", 6);
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](7, "span", 7);
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](8, "span");
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵi18n"](9, 8);
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](10, "div", 6);
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](11, "span", 7);
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](12, "span");
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵi18n"](13, 9);
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](14, "div", 6);
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](15, "span", 7);
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](16, "span");
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵi18n"](17, 10);
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](18, "div", 11);
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵi18n"](19, 12);
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](20, "div", 13)(21, "button", 14);
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("click", function DataUpgradeInstructionsPage_Template_button_click_21_listener() {
        return ctx.upgrade();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](22, "bn-loading-wrapper", 15)(23, "span");
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵi18n"](24, 16);
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()()()()();
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("contentBackground", "grey")("headerBackground", "grey")("headerTranslucent", false)("contentSafeArea", true)("backButtonDisable", true);
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵi18nExp"](ctx.appName);
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵi18nApply"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵi18nExp"](ctx.appName);
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵi18nApply"](5);
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](16);
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("disabled", ctx.upgrade.running);
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("loadingTheme", "ellipsis")("waitFor", ctx.upgrade.running);
    }
  },
  dependencies: [_modules_page_module__WEBPACK_IMPORTED_MODULE_2__.CommonPageModule, _libs_bnf_components_ripple_button_ripple_button_directive__WEBPACK_IMPORTED_MODULE_7__.RippleButtonDirective, _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_8__.CommonPageComponent, _libs_bnf_components_loading_wrapper_loading_wrapper_component__WEBPACK_IMPORTED_MODULE_9__.LoadingWrapperComponent],
  styles: ["/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsInNvdXJjZVJvb3QiOiIifQ== */"],
  data: {
    animation: [_bnqkl_framework_animations__WEBPACK_IMPORTED_MODULE_3__.fadeInUpTrigger]
  },
  changeDetection: 0
});
(0,tslib__WEBPACK_IMPORTED_MODULE_11__.__decorate)([DataUpgradeInstructionsPage.OnInit(), (0,tslib__WEBPACK_IMPORTED_MODULE_11__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_11__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_11__.__metadata)("design:returntype", void 0)], DataUpgradeInstructionsPage.prototype, "hideSplashScreen", null);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (DataUpgradeInstructionsPage);

/***/ })

}]);
//# sourceMappingURL=apps_wallet_src_pages_data-upgrade-instructions_data-upgrade-instructions_component_ts.js.map