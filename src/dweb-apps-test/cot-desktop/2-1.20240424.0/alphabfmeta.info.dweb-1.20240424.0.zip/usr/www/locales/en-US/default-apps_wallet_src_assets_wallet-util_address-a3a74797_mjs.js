"use strict";
(self["webpackChunkwallet"] = self["webpackChunkwallet"] || []).push([["default-apps_wallet_src_assets_wallet-util_address-a3a74797_mjs"],{

/***/ 75036:
/*!*****************************************************************!*\
  !*** ./apps/wallet/src/assets/wallet-util/address-a3a74797.mjs ***!
  \*****************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   a: () => (/* binding */ B),
/* harmony export */   b: () => (/* binding */ x),
/* harmony export */   c: () => (/* binding */ M),
/* harmony export */   d: () => (/* binding */ D),
/* harmony export */   e: () => (/* binding */ we),
/* harmony export */   f: () => (/* binding */ Ie),
/* harmony export */   g: () => (/* binding */ I),
/* harmony export */   h: () => (/* binding */ Be),
/* harmony export */   p: () => (/* binding */ O),
/* harmony export */   t: () => (/* binding */ Pe),
/* harmony export */   v: () => (/* binding */ te)
/* harmony export */ });
/* harmony import */ var _networks_0de0aba6_mjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./networks-0de0aba6.mjs */ 15108);
/* harmony import */ var _script_28a5953a_mjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./script-28a5953a.mjs */ 25453);
/* harmony import */ var _index_f363275a_mjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./index-f363275a.mjs */ 89279);
/* harmony import */ var _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./index-766bdb76.mjs */ 59809);
/* harmony import */ var _crypto_2c4d5428_mjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./crypto-2c4d5428.mjs */ 8319);
/* harmony import */ var _typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./typeforce-9b266dd0.mjs */ 26139);
/* harmony import */ var _ops_47b8fd99_mjs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./ops-47b8fd99.mjs */ 62510);







function O(e, t, r) {
  Object.defineProperty(e, t, {
    configurable: !0,
    enumerable: !0,
    get() {
      const e = r.call(this);
      return this[t] = e, e;
    },
    set(e) {
      Object.defineProperty(this, t, {
        configurable: !0,
        enumerable: !0,
        value: e,
        writable: !0
      });
    }
  });
}
function I(e) {
  let t;
  return () => (void 0 !== t || (t = e()), t);
}
const P = _ops_47b8fd99_mjs__WEBPACK_IMPORTED_MODULE_6__.OPS;
function B(o, i) {
  if (!(o.address || o.hash || o.output || o.pubkey || o.input)) throw new TypeError("Not enough data");
  i = Object.assign({
    validate: !0
  }, i || {}), (0,_typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_5__.t)({
    network: _typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_5__.t.maybe(_typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_5__.t.Object),
    address: _typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_5__.t.maybe(_typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_5__.t.String),
    hash: _typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_5__.t.maybe(_typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_5__.t.BufferN(20)),
    output: _typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_5__.t.maybe(_typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_5__.t.BufferN(25)),
    pubkey: _typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_5__.t.maybe(_script_28a5953a_mjs__WEBPACK_IMPORTED_MODULE_1__.f),
    signature: _typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_5__.t.maybe(_script_28a5953a_mjs__WEBPACK_IMPORTED_MODULE_1__.i),
    input: _typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_5__.t.maybe(_typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_5__.t.Buffer)
  }, o);
  const u = I(() => {
      const e = _index_f363275a_mjs__WEBPACK_IMPORTED_MODULE_2__.b.decode(o.address);
      return {
        version: e.readUInt8(0),
        hash: e.slice(1)
      };
    }),
    a = I(() => (0,_script_28a5953a_mjs__WEBPACK_IMPORTED_MODULE_1__.d)(o.input)),
    h = o.network || _networks_0de0aba6_mjs__WEBPACK_IMPORTED_MODULE_0__.b,
    f = {
      name: "p2pkh",
      network: h
    };
  if (O(f, "address", () => {
    if (!f.hash) return;
    const e = _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_3__.B.allocUnsafe(21);
    return e.writeUInt8(h.pubKeyHash, 0), f.hash.copy(e, 1), _index_f363275a_mjs__WEBPACK_IMPORTED_MODULE_2__.b.encode(e);
  }), O(f, "hash", () => o.output ? o.output.slice(3, 23) : o.address ? u().hash : o.pubkey || f.pubkey ? (0,_crypto_2c4d5428_mjs__WEBPACK_IMPORTED_MODULE_4__.hash160)(o.pubkey || f.pubkey) : void 0), O(f, "output", () => {
    if (f.hash) return (0,_script_28a5953a_mjs__WEBPACK_IMPORTED_MODULE_1__.c)([P.OP_DUP, P.OP_HASH160, f.hash, P.OP_EQUALVERIFY, P.OP_CHECKSIG]);
  }), O(f, "pubkey", () => {
    if (o.input) return a()[1];
  }), O(f, "signature", () => {
    if (o.input) return a()[0];
  }), O(f, "input", () => {
    if (o.pubkey && o.signature) return (0,_script_28a5953a_mjs__WEBPACK_IMPORTED_MODULE_1__.c)([o.signature, o.pubkey]);
  }), O(f, "witness", () => {
    if (f.input) return [];
  }), i.validate) {
    let e = _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_3__.B.from([]);
    if (o.address) {
      if (u().version !== h.pubKeyHash) throw new TypeError("Invalid version or Network mismatch");
      if (20 !== u().hash.length) throw new TypeError("Invalid address");
      e = u().hash;
    }
    if (o.hash) {
      if (e.length > 0 && !e.equals(o.hash)) throw new TypeError("Hash mismatch");
      e = o.hash;
    }
    if (o.output) {
      if (25 !== o.output.length || o.output[0] !== P.OP_DUP || o.output[1] !== P.OP_HASH160 || 20 !== o.output[2] || o.output[23] !== P.OP_EQUALVERIFY || o.output[24] !== P.OP_CHECKSIG) throw new TypeError("Output is invalid");
      const t = o.output.slice(3, 23);
      if (e.length > 0 && !e.equals(t)) throw new TypeError("Hash mismatch");
      e = t;
    }
    if (o.pubkey) {
      const t = (0,_crypto_2c4d5428_mjs__WEBPACK_IMPORTED_MODULE_4__.hash160)(o.pubkey);
      if (e.length > 0 && !e.equals(t)) throw new TypeError("Hash mismatch");
      e = t;
    }
    if (o.input) {
      const n = a();
      if (2 !== n.length) throw new TypeError("Input is invalid");
      if (!(0,_script_28a5953a_mjs__WEBPACK_IMPORTED_MODULE_1__.i)(n[0])) throw new TypeError("Input has invalid signature");
      if (!(0,_script_28a5953a_mjs__WEBPACK_IMPORTED_MODULE_1__.f)(n[1])) throw new TypeError("Input has invalid pubkey");
      if (o.signature && !o.signature.equals(n[0])) throw new TypeError("Signature mismatch");
      if (o.pubkey && !o.pubkey.equals(n[1])) throw new TypeError("Pubkey mismatch");
      const s = (0,_crypto_2c4d5428_mjs__WEBPACK_IMPORTED_MODULE_4__.hash160)(n[1]);
      if (e.length > 0 && !e.equals(s)) throw new TypeError("Hash mismatch");
    }
  }
  return Object.assign(f, o);
}
const N = _ops_47b8fd99_mjs__WEBPACK_IMPORTED_MODULE_6__.OPS;
function x(t, r) {
  if (!(t.address || t.hash || t.output || t.redeem || t.input)) throw new TypeError("Not enough data");
  r = Object.assign({
    validate: !0
  }, r || {}), (0,_typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_5__.t)({
    network: _typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_5__.t.maybe(_typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_5__.t.Object),
    address: _typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_5__.t.maybe(_typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_5__.t.String),
    hash: _typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_5__.t.maybe(_typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_5__.t.BufferN(20)),
    output: _typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_5__.t.maybe(_typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_5__.t.BufferN(23)),
    redeem: _typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_5__.t.maybe({
      network: _typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_5__.t.maybe(_typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_5__.t.Object),
      output: _typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_5__.t.maybe(_typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_5__.t.Buffer),
      input: _typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_5__.t.maybe(_typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_5__.t.Buffer),
      witness: _typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_5__.t.maybe(_typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_5__.t.arrayOf(_typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_5__.t.Buffer))
    }),
    input: _typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_5__.t.maybe(_typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_5__.t.Buffer),
    witness: _typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_5__.t.maybe(_typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_5__.t.arrayOf(_typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_5__.t.Buffer))
  }, t);
  let i = t.network;
  i || (i = t.redeem && t.redeem.network || _networks_0de0aba6_mjs__WEBPACK_IMPORTED_MODULE_0__.b);
  const u = {
      network: i
    },
    a = I(() => {
      const e = _index_f363275a_mjs__WEBPACK_IMPORTED_MODULE_2__.b.decode(t.address);
      return {
        version: e.readUInt8(0),
        hash: e.slice(1)
      };
    }),
    h = I(() => (0,_script_28a5953a_mjs__WEBPACK_IMPORTED_MODULE_1__.d)(t.input)),
    f = I(() => {
      const e = h(),
        r = e[e.length - 1];
      return {
        network: i,
        output: r === N.OP_FALSE ? _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_3__.B.from([]) : r,
        input: (0,_script_28a5953a_mjs__WEBPACK_IMPORTED_MODULE_1__.c)(e.slice(0, -1)),
        witness: t.witness || []
      };
    });
  if (O(u, "address", () => {
    if (!u.hash) return;
    const e = _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_3__.B.allocUnsafe(21);
    return e.writeUInt8(u.network.scriptHash, 0), u.hash.copy(e, 1), _index_f363275a_mjs__WEBPACK_IMPORTED_MODULE_2__.b.encode(e);
  }), O(u, "hash", () => t.output ? t.output.slice(2, 22) : t.address ? a().hash : u.redeem && u.redeem.output ? (0,_crypto_2c4d5428_mjs__WEBPACK_IMPORTED_MODULE_4__.hash160)(u.redeem.output) : void 0), O(u, "output", () => {
    if (u.hash) return (0,_script_28a5953a_mjs__WEBPACK_IMPORTED_MODULE_1__.c)([N.OP_HASH160, u.hash, N.OP_EQUAL]);
  }), O(u, "redeem", () => {
    if (t.input) return f();
  }), O(u, "input", () => {
    if (t.redeem && t.redeem.input && t.redeem.output) return (0,_script_28a5953a_mjs__WEBPACK_IMPORTED_MODULE_1__.c)([].concat((0,_script_28a5953a_mjs__WEBPACK_IMPORTED_MODULE_1__.d)(t.redeem.input), t.redeem.output));
  }), O(u, "witness", () => u.redeem && u.redeem.witness ? u.redeem.witness : u.input ? [] : void 0), O(u, "name", () => {
    const e = ["p2sh"];
    return void 0 !== u.redeem && void 0 !== u.redeem.name && e.push(u.redeem.name), e.join("-");
  }), r.validate) {
    let e = _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_3__.B.from([]);
    if (t.address) {
      if (a().version !== i.scriptHash) throw new TypeError("Invalid version or Network mismatch");
      if (20 !== a().hash.length) throw new TypeError("Invalid address");
      e = a().hash;
    }
    if (t.hash) {
      if (e.length > 0 && !e.equals(t.hash)) throw new TypeError("Hash mismatch");
      e = t.hash;
    }
    if (t.output) {
      if (23 !== t.output.length || t.output[0] !== N.OP_HASH160 || 20 !== t.output[1] || t.output[22] !== N.OP_EQUAL) throw new TypeError("Output is invalid");
      const r = t.output.slice(2, 22);
      if (e.length > 0 && !e.equals(r)) throw new TypeError("Hash mismatch");
      e = r;
    }
    const r = t => {
      if (t.output) {
        const r = (0,_script_28a5953a_mjs__WEBPACK_IMPORTED_MODULE_1__.d)(t.output);
        if (!r || r.length < 1) throw new TypeError("Redeem.output too short");
        const n = (0,_crypto_2c4d5428_mjs__WEBPACK_IMPORTED_MODULE_4__.hash160)(t.output);
        if (e.length > 0 && !e.equals(n)) throw new TypeError("Hash mismatch");
        e = n;
      }
      if (t.input) {
        const e = t.input.length > 0,
          r = t.witness && t.witness.length > 0;
        if (!e && !r) throw new TypeError("Empty input");
        if (e && r) throw new TypeError("Input and witness provided");
        if (e) {
          const e = (0,_script_28a5953a_mjs__WEBPACK_IMPORTED_MODULE_1__.d)(t.input);
          if (!(0,_script_28a5953a_mjs__WEBPACK_IMPORTED_MODULE_1__.g)(e)) throw new TypeError("Non push-only scriptSig");
        }
      }
    };
    if (t.input) {
      const e = h();
      if (!e || e.length < 1) throw new TypeError("Input too short");
      if (!_index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_3__.B.isBuffer(f().output)) throw new TypeError("Input is invalid");
      r(f());
    }
    if (t.redeem) {
      if (t.redeem.network && t.redeem.network !== i) throw new TypeError("Network mismatch");
      if (t.input) {
        const e = f();
        if (t.redeem.output && !t.redeem.output.equals(e.output)) throw new TypeError("Redeem.output mismatch");
        if (t.redeem.input && !t.redeem.input.equals(e.input)) throw new TypeError("Redeem.input mismatch");
      }
      r(t.redeem);
    }
    if (t.witness && t.redeem && t.redeem.witness && !function (e, t) {
      return e.length === t.length && e.every((e, r) => e.equals(t[r]));
    }(t.redeem.witness, t.witness)) throw new TypeError("Witness and redeem.witness mismatch");
  }
  return Object.assign(u, t);
}
var U = {};
Object.defineProperty(U, "__esModule", {
  value: !0
}), U.bech32m = U.bech32 = void 0;
const j = "qpzry9x8gf2tvdw0s3jn54khce6mua7l",
  q = {};
for (let e = 0; e < 32; e++) {
  const t = j.charAt(e);
  q[t] = e;
}
function H(e) {
  const t = e >> 25;
  return (33554431 & e) << 5 ^ 996825010 & -(t >> 0 & 1) ^ 642813549 & -(t >> 1 & 1) ^ 513874426 & -(t >> 2 & 1) ^ 1027748829 & -(t >> 3 & 1) ^ 705979059 & -(t >> 4 & 1);
}
function _(e) {
  let t = 1;
  for (let r = 0; r < e.length; ++r) {
    const n = e.charCodeAt(r);
    if (n < 33 || n > 126) return "Invalid prefix (" + e + ")";
    t = H(t) ^ n >> 5;
  }
  t = H(t);
  for (let r = 0; r < e.length; ++r) {
    const n = e.charCodeAt(r);
    t = H(t) ^ 31 & n;
  }
  return t;
}
function S(e, t, r, n) {
  let s = 0,
    o = 0;
  const i = (1 << r) - 1,
    u = [];
  for (let n = 0; n < e.length; ++n) for (s = s << t | e[n], o += t; o >= r;) o -= r, u.push(s >> o & i);
  if (n) o > 0 && u.push(s << r - o & i);else {
    if (o >= t) return "Excess padding";
    if (s << r - o & i) return "Non-zero padding";
  }
  return u;
}
function A(e) {
  return S(e, 8, 5, !0);
}
function L(e) {
  const t = S(e, 5, 8, !1);
  if (Array.isArray(t)) return t;
}
function W(e) {
  const t = S(e, 5, 8, !1);
  if (Array.isArray(t)) return t;
  throw new Error(t);
}
function V(e) {
  let t;
  function r(e, r) {
    if (r = r || 90, e.length < 8) return e + " too short";
    if (e.length > r) return "Exceeds length limit";
    const n = e.toLowerCase(),
      s = e.toUpperCase();
    if (e !== n && e !== s) return "Mixed-case string " + e;
    const o = (e = n).lastIndexOf("1");
    if (-1 === o) return "No separator character for " + e;
    if (0 === o) return "Missing prefix for " + e;
    const i = e.slice(0, o),
      u = e.slice(o + 1);
    if (u.length < 6) return "Data too short";
    let a = _(i);
    if ("string" == typeof a) return a;
    const h = [];
    for (let e = 0; e < u.length; ++e) {
      const t = u.charAt(e),
        r = q[t];
      if (void 0 === r) return "Unknown character " + t;
      a = H(a) ^ r, e + 6 >= u.length || h.push(r);
    }
    return a !== t ? "Invalid checksum for " + e : {
      prefix: i,
      words: h
    };
  }
  return t = "bech32" === e ? 1 : 734539939, {
    decodeUnsafe: function (e, t) {
      const n = r(e, t);
      if ("object" == typeof n) return n;
    },
    decode: function (e, t) {
      const n = r(e, t);
      if ("object" == typeof n) return n;
      throw new Error(n);
    },
    encode: function (e, r, n) {
      if (n = n || 90, e.length + 7 + r.length > n) throw new TypeError("Exceeds length limit");
      let s = _(e = e.toLowerCase());
      if ("string" == typeof s) throw new Error(s);
      let o = e + "1";
      for (let e = 0; e < r.length; ++e) {
        const t = r[e];
        if (t >> 5 != 0) throw new Error("Non 5-bit word");
        s = H(s) ^ t, o += j.charAt(t);
      }
      for (let e = 0; e < 6; ++e) s = H(s);
      s ^= t;
      for (let e = 0; e < 6; ++e) {
        o += j.charAt(s >> 5 * (5 - e) & 31);
      }
      return o;
    },
    toWords: A,
    fromWordsUnsafe: L,
    fromWords: W
  };
}
U.bech32 = V("bech32"), U.bech32m = V("bech32m");
const C = U.bech32,
  R = U.bech32m,
  G = _ops_47b8fd99_mjs__WEBPACK_IMPORTED_MODULE_6__.OPS,
  K = _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_3__.B.alloc(0);
function M(s, o) {
  if (!(s.address || s.hash || s.output || s.pubkey || s.witness)) throw new TypeError("Not enough data");
  o = Object.assign({
    validate: !0
  }, o || {}), (0,_typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_5__.t)({
    address: _typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_5__.t.maybe(_typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_5__.t.String),
    hash: _typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_5__.t.maybe(_typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_5__.t.BufferN(20)),
    input: _typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_5__.t.maybe(_typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_5__.t.BufferN(0)),
    network: _typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_5__.t.maybe(_typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_5__.t.Object),
    output: _typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_5__.t.maybe(_typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_5__.t.BufferN(22)),
    pubkey: _typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_5__.t.maybe(_script_28a5953a_mjs__WEBPACK_IMPORTED_MODULE_1__.f),
    signature: _typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_5__.t.maybe(_script_28a5953a_mjs__WEBPACK_IMPORTED_MODULE_1__.i),
    witness: _typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_5__.t.maybe(_typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_5__.t.arrayOf(_typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_5__.t.Buffer))
  }, s);
  const i = I(() => {
      const e = C.decode(s.address),
        t = e.words.shift(),
        r = C.fromWords(e.words);
      return {
        version: t,
        prefix: e.prefix,
        data: _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_3__.B.from(r)
      };
    }),
    u = s.network || _networks_0de0aba6_mjs__WEBPACK_IMPORTED_MODULE_0__.b,
    a = {
      name: "p2wpkh",
      network: u
    };
  if (O(a, "address", () => {
    if (!a.hash) return;
    const e = C.toWords(a.hash);
    return e.unshift(0), C.encode(u.bech32, e);
  }), O(a, "hash", () => s.output ? s.output.slice(2, 22) : s.address ? i().data : s.pubkey || a.pubkey ? (0,_crypto_2c4d5428_mjs__WEBPACK_IMPORTED_MODULE_4__.hash160)(s.pubkey || a.pubkey) : void 0), O(a, "output", () => {
    if (a.hash) return (0,_script_28a5953a_mjs__WEBPACK_IMPORTED_MODULE_1__.c)([G.OP_0, a.hash]);
  }), O(a, "pubkey", () => s.pubkey ? s.pubkey : s.witness ? s.witness[1] : void 0), O(a, "signature", () => {
    if (s.witness) return s.witness[0];
  }), O(a, "input", () => {
    if (a.witness) return K;
  }), O(a, "witness", () => {
    if (s.pubkey && s.signature) return [s.signature, s.pubkey];
  }), o.validate) {
    let e = _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_3__.B.from([]);
    if (s.address) {
      if (u && u.bech32 !== i().prefix) throw new TypeError("Invalid prefix or Network mismatch");
      if (0 !== i().version) throw new TypeError("Invalid address version");
      if (20 !== i().data.length) throw new TypeError("Invalid address data");
      e = i().data;
    }
    if (s.hash) {
      if (e.length > 0 && !e.equals(s.hash)) throw new TypeError("Hash mismatch");
      e = s.hash;
    }
    if (s.output) {
      if (22 !== s.output.length || s.output[0] !== G.OP_0 || 20 !== s.output[1]) throw new TypeError("Output is invalid");
      if (e.length > 0 && !e.equals(s.output.slice(2))) throw new TypeError("Hash mismatch");
      e = s.output.slice(2);
    }
    if (s.pubkey) {
      const r = (0,_crypto_2c4d5428_mjs__WEBPACK_IMPORTED_MODULE_4__.hash160)(s.pubkey);
      if (e.length > 0 && !e.equals(r)) throw new TypeError("Hash mismatch");
      if (e = r, !(0,_script_28a5953a_mjs__WEBPACK_IMPORTED_MODULE_1__.f)(s.pubkey) || 33 !== s.pubkey.length) throw new TypeError("Invalid pubkey for p2wpkh");
    }
    if (s.witness) {
      if (2 !== s.witness.length) throw new TypeError("Witness is invalid");
      if (!(0,_script_28a5953a_mjs__WEBPACK_IMPORTED_MODULE_1__.i)(s.witness[0])) throw new TypeError("Witness has invalid signature");
      if (!(0,_script_28a5953a_mjs__WEBPACK_IMPORTED_MODULE_1__.f)(s.witness[1]) || 33 !== s.witness[1].length) throw new TypeError("Witness has invalid pubkey");
      if (s.signature && !s.signature.equals(s.witness[0])) throw new TypeError("Signature mismatch");
      if (s.pubkey && !s.pubkey.equals(s.witness[1])) throw new TypeError("Pubkey mismatch");
      const n = (0,_crypto_2c4d5428_mjs__WEBPACK_IMPORTED_MODULE_4__.hash160)(s.witness[1]);
      if (e.length > 0 && !e.equals(n)) throw new TypeError("Hash mismatch");
    }
  }
  return Object.assign(a, s);
}
const Q = _ops_47b8fd99_mjs__WEBPACK_IMPORTED_MODULE_6__.OPS,
  $ = _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_3__.B.alloc(0);
function z(e) {
  return !(!_index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_3__.B.isBuffer(e) || 65 !== e.length || 4 !== e[0] || !(0,_script_28a5953a_mjs__WEBPACK_IMPORTED_MODULE_1__.f)(e));
}
function D(t, r) {
  if (!(t.address || t.hash || t.output || t.redeem || t.witness)) throw new TypeError("Not enough data");
  r = Object.assign({
    validate: !0
  }, r || {}), (0,_typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_5__.t)({
    network: _typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_5__.t.maybe(_typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_5__.t.Object),
    address: _typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_5__.t.maybe(_typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_5__.t.String),
    hash: _typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_5__.t.maybe(_typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_5__.t.BufferN(32)),
    output: _typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_5__.t.maybe(_typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_5__.t.BufferN(34)),
    redeem: _typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_5__.t.maybe({
      input: _typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_5__.t.maybe(_typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_5__.t.Buffer),
      network: _typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_5__.t.maybe(_typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_5__.t.Object),
      output: _typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_5__.t.maybe(_typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_5__.t.Buffer),
      witness: _typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_5__.t.maybe(_typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_5__.t.arrayOf(_typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_5__.t.Buffer))
    }),
    input: _typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_5__.t.maybe(_typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_5__.t.BufferN(0)),
    witness: _typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_5__.t.maybe(_typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_5__.t.arrayOf(_typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_5__.t.Buffer))
  }, t);
  const u = I(() => {
      const e = C.decode(t.address),
        r = e.words.shift(),
        n = C.fromWords(e.words);
      return {
        version: r,
        prefix: e.prefix,
        data: _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_3__.B.from(n)
      };
    }),
    a = I(() => (0,_script_28a5953a_mjs__WEBPACK_IMPORTED_MODULE_1__.d)(t.redeem.input));
  let h = t.network;
  h || (h = t.redeem && t.redeem.network || _networks_0de0aba6_mjs__WEBPACK_IMPORTED_MODULE_0__.b);
  const f = {
    network: h
  };
  if (O(f, "address", () => {
    if (!f.hash) return;
    const e = C.toWords(f.hash);
    return e.unshift(0), C.encode(h.bech32, e);
  }), O(f, "hash", () => t.output ? t.output.slice(2) : t.address ? u().data : f.redeem && f.redeem.output ? (0,_crypto_2c4d5428_mjs__WEBPACK_IMPORTED_MODULE_4__.sha256)(f.redeem.output) : void 0), O(f, "output", () => {
    if (f.hash) return (0,_script_28a5953a_mjs__WEBPACK_IMPORTED_MODULE_1__.c)([Q.OP_0, f.hash]);
  }), O(f, "redeem", () => {
    if (t.witness) return {
      output: t.witness[t.witness.length - 1],
      input: $,
      witness: t.witness.slice(0, -1)
    };
  }), O(f, "input", () => {
    if (f.witness) return $;
  }), O(f, "witness", () => {
    if (t.redeem && t.redeem.input && t.redeem.input.length > 0 && t.redeem.output && t.redeem.output.length > 0) {
      const e = (0,_script_28a5953a_mjs__WEBPACK_IMPORTED_MODULE_1__.h)(a());
      return f.redeem = Object.assign({
        witness: e
      }, t.redeem), f.redeem.input = $, [].concat(e, t.redeem.output);
    }
    if (t.redeem && t.redeem.output && t.redeem.witness) return [].concat(t.redeem.witness, t.redeem.output);
  }), O(f, "name", () => {
    const e = ["p2wsh"];
    return void 0 !== f.redeem && void 0 !== f.redeem.name && e.push(f.redeem.name), e.join("-");
  }), r.validate) {
    let e = _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_3__.B.from([]);
    if (t.address) {
      if (u().prefix !== h.bech32) throw new TypeError("Invalid prefix or Network mismatch");
      if (0 !== u().version) throw new TypeError("Invalid address version");
      if (32 !== u().data.length) throw new TypeError("Invalid address data");
      e = u().data;
    }
    if (t.hash) {
      if (e.length > 0 && !e.equals(t.hash)) throw new TypeError("Hash mismatch");
      e = t.hash;
    }
    if (t.output) {
      if (34 !== t.output.length || t.output[0] !== Q.OP_0 || 32 !== t.output[1]) throw new TypeError("Output is invalid");
      const r = t.output.slice(2);
      if (e.length > 0 && !e.equals(r)) throw new TypeError("Hash mismatch");
      e = r;
    }
    if (t.redeem) {
      if (t.redeem.network && t.redeem.network !== h) throw new TypeError("Network mismatch");
      if (t.redeem.input && t.redeem.input.length > 0 && t.redeem.witness && t.redeem.witness.length > 0) throw new TypeError("Ambiguous witness source");
      if (t.redeem.output) {
        if (0 === (0,_script_28a5953a_mjs__WEBPACK_IMPORTED_MODULE_1__.d)(t.redeem.output).length) throw new TypeError("Redeem.output is invalid");
        const r = (0,_crypto_2c4d5428_mjs__WEBPACK_IMPORTED_MODULE_4__.sha256)(t.redeem.output);
        if (e.length > 0 && !e.equals(r)) throw new TypeError("Hash mismatch");
        e = r;
      }
      if (t.redeem.input && !(0,_script_28a5953a_mjs__WEBPACK_IMPORTED_MODULE_1__.g)(a())) throw new TypeError("Non push-only scriptSig");
      if (t.witness && t.redeem.witness && !function (e, t) {
        return e.length === t.length && e.every((e, r) => e.equals(t[r]));
      }(t.witness, t.redeem.witness)) throw new TypeError("Witness and redeem.witness mismatch");
      if (t.redeem.input && a().some(z) || t.redeem.output && ((0,_script_28a5953a_mjs__WEBPACK_IMPORTED_MODULE_1__.d)(t.redeem.output) || []).some(z)) throw new TypeError("redeem.input or redeem.output contains uncompressed pubkey");
    }
    if (t.witness && t.witness.length > 0) {
      const e = t.witness[t.witness.length - 1];
      if (t.redeem && t.redeem.output && !t.redeem.output.equals(e)) throw new TypeError("Witness and redeem.output mismatch");
      if (t.witness.some(z) || ((0,_script_28a5953a_mjs__WEBPACK_IMPORTED_MODULE_1__.d)(e) || []).some(z)) throw new TypeError("Witness contains uncompressed pubkey");
    }
  }
  return Object.assign(f, t);
}
const F = {};
function Y() {
  if (!F.eccLib) throw new Error("No ECC Library provided. You must call initEccLib() with a valid TinySecp256k1Interface instance");
  return F.eccLib;
}
var X = _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_3__.b.Buffer,
  J = 9007199254740991;
function Z(e) {
  if (e < 0 || e > J || e % 1 != 0) throw new RangeError("value out of range");
}
function ee(e) {
  return Z(e), e < 253 ? 1 : e <= 65535 ? 3 : e <= 4294967295 ? 5 : 9;
}
var te = {
  encode: function e(t, r, n) {
    if (Z(t), r || (r = X.allocUnsafe(ee(t))), !X.isBuffer(r)) throw new TypeError("buffer must be a Buffer instance");
    return n || (n = 0), t < 253 ? (r.writeUInt8(t, n), e.bytes = 1) : t <= 65535 ? (r.writeUInt8(253, n), r.writeUInt16LE(t, n + 1), e.bytes = 3) : t <= 4294967295 ? (r.writeUInt8(254, n), r.writeUInt32LE(t, n + 1), e.bytes = 5) : (r.writeUInt8(255, n), r.writeUInt32LE(t >>> 0, n + 1), r.writeUInt32LE(t / 4294967296 | 0, n + 5), e.bytes = 9), r;
  },
  decode: function e(t, r) {
    if (!X.isBuffer(t)) throw new TypeError("buffer must be a Buffer instance");
    r || (r = 0);
    var n = t.readUInt8(r);
    if (n < 253) return e.bytes = 1, n;
    if (253 === n) return e.bytes = 3, t.readUInt16LE(r + 1);
    if (254 === n) return e.bytes = 5, t.readUInt32LE(r + 1);
    e.bytes = 9;
    var s = t.readUInt32LE(r + 1),
      o = 4294967296 * t.readUInt32LE(r + 5) + s;
    return Z(o), o;
  },
  encodingLength: ee
};
const re = 192,
  ne = e => "left" in e && "right" in e;
function se(e, t) {
  if (e.length < 33) throw new TypeError(`The control-block length is too small. Got ${e.length}, expected min 33.`);
  const r = (e.length - 33) / 32;
  let n = t;
  for (let t = 0; t < r; t++) {
    const r = e.slice(33 + 32 * t, 65 + 32 * t);
    n = n.compare(r) < 0 ? he(n, r) : he(r, n);
  }
  return n;
}
function oe(e) {
  if ((0,_script_28a5953a_mjs__WEBPACK_IMPORTED_MODULE_1__.j)(e)) return {
    hash: ue(e)
  };
  const t = [oe(e[0]), oe(e[1])];
  t.sort((e, t) => e.hash.compare(t.hash));
  const [r, n] = t;
  return {
    hash: he(r.hash, n.hash),
    left: r,
    right: n
  };
}
function ie(e, t) {
  if (ne(e)) {
    const r = ie(e.left, t);
    if (void 0 !== r) return [...r, e.right.hash];
    const n = ie(e.right, t);
    if (void 0 !== n) return [...n, e.left.hash];
  } else if (e.hash.equals(t)) return [];
}
function ue(e) {
  const t = e.version || re;
  return (0,_crypto_2c4d5428_mjs__WEBPACK_IMPORTED_MODULE_4__.taggedHash)("TapLeaf", _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_3__.B.concat([_index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_3__.B.from([t]), fe(e.output)]));
}
function ae(e, t) {
  if (!_index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_3__.B.isBuffer(e)) return null;
  if (32 !== e.length) return null;
  if (t && 32 !== t.length) return null;
  const r = function (e, t) {
      return (0,_crypto_2c4d5428_mjs__WEBPACK_IMPORTED_MODULE_4__.taggedHash)("TapTweak", _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_3__.B.concat(t ? [e, t] : [e]));
    }(e, t),
    n = Y().xOnlyPointAddTweak(e, r);
  return n && null !== n.xOnlyPubkey ? {
    parity: n.parity,
    x: _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_3__.B.from(n.xOnlyPubkey)
  } : null;
}
function he(e, t) {
  return (0,_crypto_2c4d5428_mjs__WEBPACK_IMPORTED_MODULE_4__.taggedHash)("TapBranch", _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_3__.B.concat([e, t]));
}
function fe(e) {
  const t = te.encodingLength(e.length),
    r = _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_3__.B.allocUnsafe(t);
  return te.encode(e.length, r), _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_3__.B.concat([r, e]);
}
const de = _ops_47b8fd99_mjs__WEBPACK_IMPORTED_MODULE_6__.OPS,
  pe = 1,
  ce = 80;
function we(t, r) {
  if (!(t.address || t.output || t.pubkey || t.internalPubkey || t.witness && t.witness.length > 1)) throw new TypeError("Not enough data");
  r = Object.assign({
    validate: !0
  }, r || {}), (0,_typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_5__.t)({
    address: _typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_5__.t.maybe(_typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_5__.t.String),
    input: _typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_5__.t.maybe(_typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_5__.t.BufferN(0)),
    network: _typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_5__.t.maybe(_typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_5__.t.Object),
    output: _typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_5__.t.maybe(_typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_5__.t.BufferN(34)),
    internalPubkey: _typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_5__.t.maybe(_typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_5__.t.BufferN(32)),
    hash: _typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_5__.t.maybe(_typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_5__.t.BufferN(32)),
    pubkey: _typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_5__.t.maybe(_typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_5__.t.BufferN(32)),
    signature: _typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_5__.t.maybe(_typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_5__.t.anyOf(_typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_5__.t.BufferN(64), _typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_5__.t.BufferN(65))),
    witness: _typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_5__.t.maybe(_typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_5__.t.arrayOf(_typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_5__.t.Buffer)),
    scriptTree: _typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_5__.t.maybe(_script_28a5953a_mjs__WEBPACK_IMPORTED_MODULE_1__.k),
    redeem: _typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_5__.t.maybe({
      output: _typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_5__.t.maybe(_typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_5__.t.Buffer),
      redeemVersion: _typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_5__.t.maybe(_typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_5__.t.Number),
      witness: _typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_5__.t.maybe(_typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_5__.t.arrayOf(_typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_5__.t.Buffer))
    }),
    redeemVersion: _typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_5__.t.maybe(_typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_5__.t.Number)
  }, t);
  const o = I(() => Te(t.address)),
    i = I(() => {
      if (t.witness && t.witness.length) return t.witness.length >= 2 && t.witness[t.witness.length - 1][0] === ce ? t.witness.slice(0, -1) : t.witness.slice();
    }),
    u = I(() => t.scriptTree ? oe(t.scriptTree) : t.hash ? {
      hash: t.hash
    } : void 0),
    d = t.network || _networks_0de0aba6_mjs__WEBPACK_IMPORTED_MODULE_0__.b,
    p = {
      name: "p2tr",
      network: d
    };
  if (O(p, "address", () => {
    if (!p.pubkey) return;
    const e = R.toWords(p.pubkey);
    return e.unshift(pe), R.encode(d.bech32, e);
  }), O(p, "hash", () => {
    const e = u();
    if (e) return e.hash;
    const t = i();
    if (t && t.length > 1) {
      const e = t[t.length - 1],
        r = e[0] & _script_28a5953a_mjs__WEBPACK_IMPORTED_MODULE_1__.T;
      return se(e, ue({
        output: t[t.length - 2],
        version: r
      }));
    }
    return null;
  }), O(p, "output", () => {
    if (p.pubkey) return (0,_script_28a5953a_mjs__WEBPACK_IMPORTED_MODULE_1__.c)([de.OP_1, p.pubkey]);
  }), O(p, "redeemVersion", () => t.redeemVersion ? t.redeemVersion : t.redeem && void 0 !== t.redeem.redeemVersion && null !== t.redeem.redeemVersion ? t.redeem.redeemVersion : re), O(p, "redeem", () => {
    const e = i();
    if (e && !(e.length < 2)) return {
      output: e[e.length - 2],
      witness: e.slice(0, -2),
      redeemVersion: e[e.length - 1][0] & _script_28a5953a_mjs__WEBPACK_IMPORTED_MODULE_1__.T
    };
  }), O(p, "pubkey", () => {
    if (t.pubkey) return t.pubkey;
    if (t.output) return t.output.slice(2);
    if (t.address) return o().data;
    if (p.internalPubkey) {
      const e = ae(p.internalPubkey, p.hash);
      if (e) return e.x;
    }
  }), O(p, "internalPubkey", () => {
    if (t.internalPubkey) return t.internalPubkey;
    const e = i();
    return e && e.length > 1 ? e[e.length - 1].slice(1, 33) : void 0;
  }), O(p, "signature", () => {
    if (t.signature) return t.signature;
    const e = i();
    return e && 1 === e.length ? e[0] : void 0;
  }), O(p, "witness", () => {
    if (t.witness) return t.witness;
    const e = u();
    if (e && t.redeem && t.redeem.output && t.internalPubkey) {
      const r = ie(e, ue({
        output: t.redeem.output,
        version: p.redeemVersion
      }));
      if (!r) return;
      const n = ae(t.internalPubkey, e.hash);
      if (!n) return;
      const s = _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_3__.B.concat([_index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_3__.B.from([p.redeemVersion | n.parity]), t.internalPubkey].concat(r));
      return [t.redeem.output, s];
    }
    return t.signature ? [t.signature] : void 0;
  }), r.validate) {
    let e = _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_3__.B.from([]);
    if (t.address) {
      if (d && d.bech32 !== o().prefix) throw new TypeError("Invalid prefix or Network mismatch");
      if (o().version !== pe) throw new TypeError("Invalid address version");
      if (32 !== o().data.length) throw new TypeError("Invalid address data");
      e = o().data;
    }
    if (t.pubkey) {
      if (e.length > 0 && !e.equals(t.pubkey)) throw new TypeError("Pubkey mismatch");
      e = t.pubkey;
    }
    if (t.output) {
      if (34 !== t.output.length || t.output[0] !== de.OP_1 || 32 !== t.output[1]) throw new TypeError("Output is invalid");
      if (e.length > 0 && !e.equals(t.output.slice(2))) throw new TypeError("Pubkey mismatch");
      e = t.output.slice(2);
    }
    if (t.internalPubkey) {
      const r = ae(t.internalPubkey, p.hash);
      if (e.length > 0 && !e.equals(r.x)) throw new TypeError("Pubkey mismatch");
      e = r.x;
    }
    if (e && e.length && !Y().isXOnlyPoint(e)) throw new TypeError("Invalid pubkey for p2tr");
    const r = u();
    if (t.hash && r && !t.hash.equals(r.hash)) throw new TypeError("Hash mismatch");
    if (t.redeem && t.redeem.output && r) {
      if (!ie(r, ue({
        output: t.redeem.output,
        version: p.redeemVersion
      }))) throw new TypeError("Redeem script not in tree");
    }
    const n = i();
    if (t.redeem && p.redeem) {
      if (t.redeem.redeemVersion && t.redeem.redeemVersion !== p.redeem.redeemVersion) throw new TypeError("Redeem.redeemVersion and witness mismatch");
      if (t.redeem.output) {
        if (0 === (0,_script_28a5953a_mjs__WEBPACK_IMPORTED_MODULE_1__.d)(t.redeem.output).length) throw new TypeError("Redeem.output is invalid");
        if (p.redeem.output && !t.redeem.output.equals(p.redeem.output)) throw new TypeError("Redeem.output and witness mismatch");
      }
      if (t.redeem.witness && p.redeem.witness && !(0,_script_28a5953a_mjs__WEBPACK_IMPORTED_MODULE_1__.l)(t.redeem.witness, p.redeem.witness)) throw new TypeError("Redeem.witness and witness mismatch");
    }
    if (n && n.length) if (1 === n.length) {
      if (t.signature && !t.signature.equals(n[0])) throw new TypeError("Signature mismatch");
    } else {
      const r = n[n.length - 1];
      if (r.length < 33) throw new TypeError(`The control-block length is too small. Got ${r.length}, expected min 33.`);
      if ((r.length - 33) % 32 != 0) throw new TypeError(`The control-block length of ${r.length} is incorrect!`);
      const s = (r.length - 33) / 32;
      if (s > 128) throw new TypeError(`The script path is too long. Got ${s}, expected max 128.`);
      const o = r.slice(1, 33);
      if (t.internalPubkey && !t.internalPubkey.equals(o)) throw new TypeError("Internal pubkey mismatch");
      if (!Y().isXOnlyPoint(o)) throw new TypeError("Invalid internalPubkey for p2tr witness");
      const i = r[0] & _script_28a5953a_mjs__WEBPACK_IMPORTED_MODULE_1__.T,
        u = ae(o, se(r, ue({
          output: n[n.length - 2],
          version: i
        })));
      if (!u) throw new TypeError("Invalid outputKey for p2tr witness");
      if (e.length && !e.equals(u.x)) throw new TypeError("Pubkey mismatch for p2tr witness");
      if (u.parity !== (1 & r[0])) throw new Error("Incorrect parity");
    }
  }
  return Object.assign(p, t);
}
const {
    typeforce: me
  } = _script_28a5953a_mjs__WEBPACK_IMPORTED_MODULE_1__.a,
  le = 40,
  ye = 2,
  be = 16,
  ge = 1,
  Ee = 80,
  ke = "WARNING: Sending to a future segwit version address can lead to loss of funds. End users MUST be warned carefully in the GUI and asked if they wish to proceed with caution. Wallets should verify the segwit version from the output of fromBech32, then decide when it is safe to use which version of segwit.";
function ve(e) {
  const t = _index_f363275a_mjs__WEBPACK_IMPORTED_MODULE_2__.b.decode(e);
  if (t.length < 21) throw new TypeError(e + " is too short");
  if (t.length > 21) throw new TypeError(e + " is too long");
  return {
    version: t.readUInt8(0),
    hash: t.slice(1)
  };
}
function Te(e) {
  let t, r;
  try {
    t = C.decode(e);
  } catch (e) {}
  if (t) {
    if (r = t.words[0], 0 !== r) throw new TypeError(e + " uses wrong encoding");
  } else if (t = R.decode(e), r = t.words[0], 0 === r) throw new TypeError(e + " uses wrong encoding");
  const n = C.fromWords(t.words.slice(1));
  return {
    version: r,
    prefix: t.prefix,
    data: _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_3__.B.from(n)
  };
}
function Oe(e, t, r) {
  const n = C.toWords(e);
  return n.unshift(t), 0 === t ? C.encode(r, n) : R.encode(r, n);
}
function Ie(t, r) {
  r = r || _networks_0de0aba6_mjs__WEBPACK_IMPORTED_MODULE_0__.b;
  try {
    return B({
      output: t,
      network: r
    }).address;
  } catch (e) {}
  try {
    return x({
      output: t,
      network: r
    }).address;
  } catch (e) {}
  try {
    return M({
      output: t,
      network: r
    }).address;
  } catch (e) {}
  try {
    return D({
      output: t,
      network: r
    }).address;
  } catch (e) {}
  try {
    return we({
      output: t,
      network: r
    }).address;
  } catch (e) {}
  try {
    return function (e, t) {
      const r = e.slice(2);
      if (r.length < ye || r.length > le) throw new TypeError("Invalid program length for segwit address");
      const n = e[0] - Ee;
      if (n < ge || n > be) throw new TypeError("Invalid version for segwit address");
      if (e[1] !== r.length) throw new TypeError("Invalid script for segwit address");
      return console.warn(ke), Oe(r, n, t.bech32);
    }(t, r);
  } catch (e) {}
  throw new Error((0,_script_28a5953a_mjs__WEBPACK_IMPORTED_MODULE_1__.p)(t) + " has no matching Address");
}
function Pe(t, r) {
  let s, o;
  r = r || _networks_0de0aba6_mjs__WEBPACK_IMPORTED_MODULE_0__.b;
  try {
    s = ve(t);
  } catch (e) {}
  if (s) {
    if (s.version === r.pubKeyHash) return B({
      hash: s.hash
    }).output;
    if (s.version === r.scriptHash) return x({
      hash: s.hash
    }).output;
  } else {
    try {
      o = Te(t);
    } catch (e) {}
    if (o) {
      if (o.prefix !== r.bech32) throw new Error(t + " has an invalid prefix");
      if (0 === o.version) {
        if (20 === o.data.length) return M({
          hash: o.data
        }).output;
        if (32 === o.data.length) return D({
          hash: o.data
        }).output;
      } else if (o.version >= ge && o.version <= be && o.data.length >= ye && o.data.length <= le) return console.warn(ke), (0,_script_28a5953a_mjs__WEBPACK_IMPORTED_MODULE_1__.c)([o.version + Ee, o.data]);
    }
  }
  throw new Error(t + " has no matching Script");
}
var Be = Object.freeze({
  __proto__: null,
  fromBase58Check: ve,
  fromBech32: Te,
  fromOutputScript: Ie,
  toBase58Check: function (e, t) {
    me((0,_script_28a5953a_mjs__WEBPACK_IMPORTED_MODULE_1__.t)(_script_28a5953a_mjs__WEBPACK_IMPORTED_MODULE_1__.n, _script_28a5953a_mjs__WEBPACK_IMPORTED_MODULE_1__.o), arguments);
    const r = _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_3__.B.allocUnsafe(21);
    return r.writeUInt8(t, 0), e.copy(r, 1), _index_f363275a_mjs__WEBPACK_IMPORTED_MODULE_2__.b.encode(r);
  },
  toBech32: Oe,
  toOutputScript: Pe
});


/***/ }),

/***/ 8319:
/*!****************************************************************!*\
  !*** ./apps/wallet/src/assets/wallet-util/crypto-2c4d5428.mjs ***!
  \****************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   hash160: () => (/* binding */ i),
/* harmony export */   hash256: () => (/* binding */ m),
/* harmony export */   ripemd160: () => (/* binding */ o),
/* harmony export */   sha1: () => (/* binding */ a),
/* harmony export */   sha256: () => (/* binding */ c),
/* harmony export */   taggedHash: () => (/* binding */ s)
/* harmony export */ });
/* harmony import */ var _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./index-766bdb76.mjs */ 59809);
/* harmony import */ var _ripemd160_3baa091d_mjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./ripemd160-3baa091d.mjs */ 70972);
/* harmony import */ var _sha1_e1635d39_mjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./sha1-e1635d39.mjs */ 57);
/* harmony import */ var _sha256_e58017d9_mjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./sha256-e58017d9.mjs */ 6612);
/* harmony import */ var _WASMInterface_b9f2203b_mjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./WASMInterface-b9f2203b.mjs */ 43670);





function o(n) {
  return _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_0__.B.from((0,_ripemd160_3baa091d_mjs__WEBPACK_IMPORTED_MODULE_1__.c)().update(n).digest());
}
function a(t) {
  return _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_0__.B.from((0,_sha1_e1635d39_mjs__WEBPACK_IMPORTED_MODULE_2__.c)().update(t).digest());
}
function c(t) {
  return _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_0__.B.from((0,_sha256_e58017d9_mjs__WEBPACK_IMPORTED_MODULE_3__.c)().update(t).digest());
}
function i(r) {
  return o(c(r));
}
function m(r) {
  return c(c(r));
}
const f = Object.fromEntries(["BIP0340/challenge", "BIP0340/aux", "BIP0340/nonce", "TapLeaf", "TapBranch", "TapSighash", "TapTweak", "KeyAgg list", "KeyAgg coefficient"].map(t => {
  const n = c(_index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_0__.B.from(t));
  return [t, _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_0__.B.concat([n, n])];
}));
function s(t, n) {
  return c(_index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_0__.B.concat([f[t], n]));
}


/***/ }),

/***/ 15108:
/*!******************************************************************!*\
  !*** ./apps/wallet/src/assets/wallet-util/networks-0de0aba6.mjs ***!
  \******************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   b: () => (/* binding */ e),
/* harmony export */   r: () => (/* binding */ i),
/* harmony export */   t: () => (/* binding */ s)
/* harmony export */ });
const e = {
    messagePrefix: "Bitcoin Signed Message:\n",
    bech32: "bc",
    bip32: {
      public: 76067358,
      private: 76066276
    },
    pubKeyHash: 0,
    scriptHash: 5,
    wif: 128
  },
  i = {
    messagePrefix: "Bitcoin Signed Message:\n",
    bech32: "bcrt",
    bip32: {
      public: 70617039,
      private: 70615956
    },
    pubKeyHash: 111,
    scriptHash: 196,
    wif: 239
  },
  s = {
    messagePrefix: "Bitcoin Signed Message:\n",
    bech32: "tb",
    bip32: {
      public: 70617039,
      private: 70615956
    },
    pubKeyHash: 111,
    scriptHash: 196,
    wif: 239
  };


/***/ }),

/***/ 57:
/*!**************************************************************!*\
  !*** ./apps/wallet/src/assets/wallet-util/sha1-e1635d39.mjs ***!
  \**************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   a: () => (/* binding */ e),
/* harmony export */   c: () => (/* binding */ i),
/* harmony export */   p: () => (/* binding */ s),
/* harmony export */   s: () => (/* binding */ t)
/* harmony export */ });
/* harmony import */ var D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 52542);
/* harmony import */ var _WASMInterface_b9f2203b_mjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./WASMInterface-b9f2203b.mjs */ 43670);


const s = (0,_WASMInterface_b9f2203b_mjs__WEBPACK_IMPORTED_MODULE_1__.c)("sha1", 20),
  t = /*#__PURE__*/function () {
    var _ref = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (a) {
      return (yield s()).calculate(a);
    });
    return function t(_x) {
      return _ref.apply(this, arguments);
    };
  }(),
  e = /*#__PURE__*/function () {
    var _ref2 = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      return i(yield s());
    });
    return function e() {
      return _ref2.apply(this, arguments);
    };
  }(),
  i = (a = s.wasm) => {
    a.init();
    const t = {
      init: () => (a.init(), t),
      update: s => (a.update(s), t),
      digest: s => a.digest(s),
      save: () => a.save(),
      load: s => (a.load(s), t),
      blockSize: 64,
      digestSize: 20
    };
    return t;
  };


/***/ })

}]);
//# sourceMappingURL=default-apps_wallet_src_assets_wallet-util_address-a3a74797_mjs.js.map