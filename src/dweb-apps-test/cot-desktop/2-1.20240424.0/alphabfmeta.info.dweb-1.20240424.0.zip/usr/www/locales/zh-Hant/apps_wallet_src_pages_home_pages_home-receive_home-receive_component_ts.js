"use strict";
(self["webpackChunkwallet"] = self["webpackChunkwallet"] || []).push([["apps_wallet_src_pages_home_pages_home-receive_home-receive_component_ts"],{

/***/ 89987:
/*!********************************************************!*\
  !*** ./apps/wallet/src/helpers/render-canvas/index.ts ***!
  \********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   CanvasRender: () => (/* reexport safe */ _render_canvas__WEBPACK_IMPORTED_MODULE_0__["default"])
/* harmony export */ });
/* harmony import */ var _render_canvas__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./render-canvas */ 17319);
/* harmony import */ var _types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./types */ 20415);



/***/ }),

/***/ 17319:
/*!****************************************************************!*\
  !*** ./apps/wallet/src/helpers/render-canvas/render-canvas.ts ***!
  \****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/** 设备基本宽度 设备像素比取整数 */
const _DEVICE_BASE_WIDTH = screen.availWidth / Math.round(devicePixelRatio);
/**
 * css 转化为canvas像素
 * 以宽度作为基准
 * @param value number/number'px' / number%
 * @returns
 */
const getCanvasPx = value => {
  if (typeof value === 'string') {
    if (value.endsWith('px')) {
      value = Number(value.slice(0, -2));
    } else if (value.endsWith('%')) {
      return screen.availWidth * Number(value.slice(0, -1));
    } else {
      // 不符合要求的置为0
      return 0;
    }
  }
  return screen.availWidth * value / _DEVICE_BASE_WIDTH;
};
/**
 * canvas初始化
 * @param width 宽度
 * @param aspectRatio 横纵比(宽/高)
 * @param canvas
 * @returns
 */
const initCanvas = (width, height, canvas) => {
  if (canvas === undefined) {
    canvas = document.createElement('canvas');
  }
  canvas.width = getCanvasPx(width);
  canvas.height = getCanvasPx(height);
  return canvas;
};
/**
 * 绘制canvas文本
 * @param ctx
 * @param text
 * @param position
 * @param style
 * @returns
 */
const renderCanvasText = (ctx, text, position, style) => {
  const {
    fontSize,
    fontWeight
  } = style;
  ctx.font = `${fontWeight} ${getCanvasPx(fontSize)}px PingFangSC`;
  ctx.fillStyle = style.color;
  ctx.textAlign = style.textAlign;
  ctx.textBaseline = 'middle';
  // 根据文本原点与行高，计算中线
  const centerDy = position.y + style.lineHeight / 2;
  ctx.fillText(text, position.x, centerDy);
  return style.lineHeight;
};
/**
 * 绘制canvas文本
 * @param ctx
 * @param text
 * @param position
 * @param style
 * @returns
 */
const renderCanvasMultiLineText = (ctx, text, position, style) => {
  const {
    fontSize,
    fontWeight
  } = style;
  ctx.font = `${fontWeight} ${getCanvasPx(fontSize)}px PingFangSC`;
  ctx.fillStyle = style.color;
  ctx.textAlign = style.textAlign;
  ctx.textBaseline = 'middle';
  const maxMultiLineTextWidth = getCanvasPx(style.maxMultiLineTextWidth);
  let lineText = '';
  for (const char of text) {
    const currentLineText = lineText + char;
    const metrics = ctx.measureText(currentLineText);
    if (metrics.width > maxMultiLineTextWidth) {
      ctx.fillText(lineText, position.x, position.y + style.lineHeight / 2);
      position.y += style.lineHeight;
      lineText = char;
    } else {
      lineText = currentLineText;
    }
  }
  if (lineText) {
    ctx.fillText(lineText, position.x, position.y + style.lineHeight / 2);
    position.y += style.lineHeight;
  }
  return position.y;
};
/**
 * 根据图片路径获取图片信息
 * @param src
 * @param crossOrigin 跨域
 * @returns
 */
const getImageInfo = (src, crossOrigin) => {
  return new Promise((resolve, reject) => {
    const image = new Image();
    image.style.overflow = 'hidden';
    if (crossOrigin) {
      image.crossOrigin = crossOrigin;
    }
    image.src = src;
    image.onload = () => {
      resolve(image);
    };
    image.onerror = event => {
      reject(typeof event === 'string' ? event : event instanceof ErrorEvent ? event.error : event);
    };
  });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  getCanvasPx,
  initCanvas,
  renderCanvasText,
  renderCanvasMultiLineText,
  getImageInfo
});

/***/ }),

/***/ 20415:
/*!********************************************************!*\
  !*** ./apps/wallet/src/helpers/render-canvas/types.ts ***!
  \********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);


/***/ }),

/***/ 6596:
/*!************************************************!*\
  !*** ./apps/wallet/src/helpers/utils/index.ts ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   isMobile: () => (/* binding */ isMobile)
/* harmony export */ });
/* harmony import */ var _plaoc_is_dweb__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @plaoc/is-dweb */ 69899);
/* harmony import */ var _environments_index__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ~environments/index */ 40014);


/** 判断是否是移动端 */
const isMobile = () => {
  if (_environments_index__WEBPACK_IMPORTED_MODULE_1__.environment.DWEB_APP) {
    return (0,_plaoc_is_dweb__WEBPACK_IMPORTED_MODULE_0__.isMobile)();
  } else {
    return true;
  }
};

/***/ }),

/***/ 99923:
/*!*********************************************************************************!*\
  !*** ./apps/wallet/src/pages/home/pages/home-receive/home-receive.component.ts ***!
  \*********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   HomeReceivePage: () => (/* binding */ HomeReceivePage),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 52542);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! tslib */ 90505);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! @angular/core */ 61039);
/* harmony import */ var _bnqkl_framework_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @bnqkl/framework/components */ 24182);
/* harmony import */ var _bnqkl_framework_plugins_filesystem__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @bnqkl/framework/plugins/filesystem */ 82737);
/* harmony import */ var _bnqkl_framework_plugins_share__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @bnqkl/framework/plugins/share */ 61056);
/* harmony import */ var _bnqkl_framework_plugins_toast__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @bnqkl/framework/plugins/toast */ 18030);
/* harmony import */ var _bnqkl_framework_render_helpers__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @bnqkl/framework/render-helpers */ 21131);
/* harmony import */ var _bnqkl_util_web_decorator__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @bnqkl/util-web/decorator */ 18112);
/* harmony import */ var _bnqkl_util_web_extends_promise__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @bnqkl/util-web/extends-promise */ 87778);
/* harmony import */ var _environments_index__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ~environments/index */ 40014);
/* harmony import */ var _helpers_render_canvas__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ~helpers/render-canvas */ 89987);
/* harmony import */ var _modules_page_module__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ~modules/page.module */ 77538);
/* harmony import */ var _bnqkl_wallet_base_services_wallet_chain__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @bnqkl/wallet-base/services/wallet/chain */ 27434);
/* harmony import */ var _services_color_color_service__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ~services/color/color.service */ 64443);
/* harmony import */ var _services_permission_permission_service__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ~services/permission/permission.service */ 26502);
/* harmony import */ var _helpers_utils__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ~helpers/utils */ 6596);
/* harmony import */ var _libs_bnf_components_ripple_button_ripple_button_directive__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ../../../../../../../libs/bnf/components/ripple-button/ripple-button.directive */ 16505);
/* harmony import */ var _libs_bnf_directives_click_to_copy_directive__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ../../../../../../../libs/bnf/directives/click-to-copy.directive */ 46413);
/* harmony import */ var _libs_bnf_directives_ob_size_directive__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ../../../../../../../libs/bnf/directives/ob-size.directive */ 46501);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! @angular/common */ 6729);
/* harmony import */ var _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ../../../../../../../libs/bnf/modules/page/common-page/common-page.component */ 62052);
/* harmony import */ var _components_icon_icon_component__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ../../../../components/icon/icon.component */ 74703);
/* harmony import */ var _pipes_color_color_pipe__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ../../../../pipes/color/color.pipe */ 76489);

var _class;
























function HomeReceivePage_span_4_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵi18nStart"](0, 3, 1);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelement"](1, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵi18nEnd"]();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵi18nExp"](ctx_r0.agreement);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵi18nApply"](0);
  }
}
function HomeReceivePage_Conditional_22_Template(rf, ctx) {
  if (rf & 1) {
    const _r3 = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](0, "button", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵlistener"]("click", function HomeReceivePage_Conditional_22_Template_button_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵrestoreView"](_r3);
      const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵresetView"](ctx_r2.shareQrcode());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵi18n"](1, 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
  }
}
const _c10 = a0 => ({
  "--color-1": a0
});
/**
 * 接收转入页面
 */
class HomeReceivePage extends _modules_page_module__WEBPACK_IMPORTED_MODULE_10__.CommonPageBase {
  constructor() {
    super(...arguments);
    /** 钱包信息存储服务 */
    this._permissionService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_21__.inject)(_services_permission_permission_service__WEBPACK_IMPORTED_MODULE_13__.PermissionService);
    /** 是否是移动端 */
    this.isMobile = (0,_helpers_utils__WEBPACK_IMPORTED_MODULE_14__.isMobile)();
    /** 币 */
    this.symbol = '';
    /** 链地址 */
    this.address = '';
    /** 颜色服务 */
    this._colorService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_21__.inject)(_services_color_color_service__WEBPACK_IMPORTED_MODULE_12__.ColorService);
  }
  /** 协议 */
  get agreement() {
    return this.injectorForceGet(_bnqkl_wallet_base_services_wallet_chain__WEBPACK_IMPORTED_MODULE_11__.ChainV2Service).getChainInfo(this.chain).agreement;
  }
  /** 二维码内容 */
  get qrCodeText() {
    return this.address;
  }
  init() {
    this.symbol = this.injectorForceGet(_bnqkl_wallet_base_services_wallet_chain__WEBPACK_IMPORTED_MODULE_11__.ChainV2Service).getChainInfo(this.chain).symbol;
  }
  /**
   * 分享二维码
   * @returns
   */
  shareQrcode() {
    var _this = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      if (_this._saveOrShareTask) {
        const result = yield _this._saveOrShareTask.promise;
        if (result === true) {
          return;
        }
      }
      _this._saveOrShareTask = new _bnqkl_util_web_extends_promise__WEBPACK_IMPORTED_MODULE_7__.PromiseOut();
      _this._saveOrShareTask.promise.finally(() => {
        _this._saveOrShareTask = undefined;
      });
      const hasFileSystemPermission = yield _this._permissionService.requestFilesystem();
      if (hasFileSystemPermission) {
        const qrcodeCanvas = yield _this._qrcodeImage;
        try {
          yield _bnqkl_framework_plugins_share__WEBPACK_IMPORTED_MODULE_3__.Share.share({
            imageData: qrcodeCanvas.toDataURL()
          }, {
            successMsg: "\u5206\u4EAB\u6210\u529F",
            errorMsg: "\u5206\u4EAB\u5931\u6557",
            cancelMsg: "\u5206\u4EAB\u53D6\u6D88"
          });
          _this._saveOrShareTask.resolve(true);
        } catch (err) {
          _this._saveOrShareTask.resolve(false);
        }
      } else {
        _this._saveOrShareTask.resolve(false);
      }
    })();
  }
  /**
   * 保存图片
   * @returns
   */
  saveQrcode() {
    var _this2 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      if (_this2._saveOrShareTask) {
        const result = yield _this2._saveOrShareTask.promise;
        if (result === true) {
          return;
        }
      }
      _this2._saveOrShareTask = new _bnqkl_util_web_extends_promise__WEBPACK_IMPORTED_MODULE_7__.PromiseOut();
      _this2._saveOrShareTask.promise.finally(() => {
        _this2._saveOrShareTask = undefined;
      });
      const hasFileSystemPermission = yield _this2._permissionService.requestFilesystem();
      if (hasFileSystemPermission) {
        if (_environments_index__WEBPACK_IMPORTED_MODULE_8__.environment.development) {
          const qrcodeCanvas = yield _this2._qrcodeImage;
          const a = document.createElement('a');
          a.href = qrcodeCanvas.toDataURL();
          a.download = `${Date.now()}.png`;
          a.click();
          _this2._saveOrShareTask.resolve(true);
        } else {
          const qrcodeCanvas = yield _this2._qrcodeImage;
          try {
            yield _bnqkl_framework_plugins_filesystem__WEBPACK_IMPORTED_MODULE_2__.Filesystem.writePhotoFile(qrcodeCanvas.toDataURL(), undefined, undefined, false);
            _bnqkl_framework_plugins_toast__WEBPACK_IMPORTED_MODULE_4__.Toast.show("\u4FDD\u5B58\u6210\u529F");
            _this2._saveOrShareTask.resolve(true);
          } catch (err) {
            _this2.console.error(err);
            _bnqkl_framework_plugins_toast__WEBPACK_IMPORTED_MODULE_4__.Toast.show("\u4FDD\u5B58\u5931\u6557");
            _this2._saveOrShareTask.resolve(false);
          }
        }
      } else {
        _this2._saveOrShareTask.resolve(false);
      }
    })();
  }
  /** 获取绘制出来的canvas元素 */
  get _qrcodeImage() {
    return this._drawShareQrcode();
  }
  /**
   * 绘制分享二维码
   * @param canvasWidth 画布宽度
   * @param canvasWidth 画布高度
   * @param canvas
   * @returns
   */
  _drawShareQrcode() {
    var _this3 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const canvas = _helpers_render_canvas__WEBPACK_IMPORTED_MODULE_9__.CanvasRender.initCanvas(375, 547);
      // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
      const ctx = canvas.getContext('2d');
      // 抗锯齿
      ctx.imageSmoothingEnabled = true;
      const {
        width,
        height
      } = canvas;
      // 开始绘制
      let dy = 0;
      // 绘制背景
      {
        ctx.fillStyle = _this3._colorService.transform('primary');
        ctx.beginPath();
        ctx.fillRect(0, 0, width, height);
        ctx.closePath();
      }
      // logo
      {
        dy += _helpers_render_canvas__WEBPACK_IMPORTED_MODULE_9__.CanvasRender.getCanvasPx(32);
        const logo = yield _helpers_render_canvas__WEBPACK_IMPORTED_MODULE_9__.CanvasRender.getImageInfo('./assets/images/logo.png');
        const logoWidth = _helpers_render_canvas__WEBPACK_IMPORTED_MODULE_9__.CanvasRender.getCanvasPx(60);
        ctx.drawImage(logo, (width - logoWidth) / 2, dy, logoWidth, logoWidth);
        dy += logoWidth;
      }
      // 绘制标题
      {
        dy += _helpers_render_canvas__WEBPACK_IMPORTED_MODULE_9__.CanvasRender.getCanvasPx(12);
        const lineHeight = _helpers_render_canvas__WEBPACK_IMPORTED_MODULE_9__.CanvasRender.renderCanvasText(ctx, 'Open COT [Scan]', {
          x: width / 2,
          y: dy
        }, {
          fontSize: 16,
          color: '#ffffff',
          fontWeight: 600,
          lineHeight: _helpers_render_canvas__WEBPACK_IMPORTED_MODULE_9__.CanvasRender.getCanvasPx(22),
          textAlign: 'center'
        });
        dy += lineHeight;
      }
      // 绘制地址二维码
      {
        dy += _helpers_render_canvas__WEBPACK_IMPORTED_MODULE_9__.CanvasRender.getCanvasPx(24);
        const qrcodeCtnWidth = _helpers_render_canvas__WEBPACK_IMPORTED_MODULE_9__.CanvasRender.getCanvasPx(278);
        const qrcodeCtnDx = (width - qrcodeCtnWidth) / 2;
        const qrcodeCtnDy = dy;
        const qrcodeCtnBorderRadius = _helpers_render_canvas__WEBPACK_IMPORTED_MODULE_9__.CanvasRender.getCanvasPx(8);
        ctx.beginPath();
        ctx.fillStyle = '#fff';
        ctx.moveTo(qrcodeCtnDx, qrcodeCtnDy);
        ctx.arcTo(qrcodeCtnDx + qrcodeCtnWidth, qrcodeCtnDy, qrcodeCtnDx + qrcodeCtnWidth, qrcodeCtnDy + qrcodeCtnWidth, qrcodeCtnBorderRadius);
        ctx.arcTo(qrcodeCtnDx + qrcodeCtnWidth, qrcodeCtnDy + qrcodeCtnWidth, qrcodeCtnDx, qrcodeCtnDy + qrcodeCtnWidth, qrcodeCtnBorderRadius);
        ctx.arcTo(qrcodeCtnDx, qrcodeCtnDy + qrcodeCtnWidth, qrcodeCtnDx, qrcodeCtnDy, qrcodeCtnBorderRadius);
        ctx.arcTo(qrcodeCtnDx, qrcodeCtnDy, qrcodeCtnDx + qrcodeCtnWidth, qrcodeCtnDy, qrcodeCtnBorderRadius);
        ctx.closePath();
        ctx.fill();
        // 绘制二维码
        {
          const padding = _helpers_render_canvas__WEBPACK_IMPORTED_MODULE_9__.CanvasRender.getCanvasPx(24);
          const qrcodeWidth = qrcodeCtnWidth - padding * 2;
          const qrcodeDy = dy + padding;
          const svgHtml = (0,_bnqkl_framework_render_helpers__WEBPACK_IMPORTED_MODULE_5__._renderSvg)({
            text: _this3.address,
            padding: 0,
            size: qrcodeWidth,
            color: '#000000',
            background: '#ffffff',
            ecl: 'L'
          });
          const qrcodeImg = yield _helpers_render_canvas__WEBPACK_IMPORTED_MODULE_9__.CanvasRender.getImageInfo('data:image/svg+xml;base64,' + self.btoa(svgHtml));
          ctx.drawImage(qrcodeImg, (width - qrcodeWidth) / 2, qrcodeDy, qrcodeWidth, qrcodeWidth);
        }
        dy += qrcodeCtnWidth;
      }
      // 绘制地址
      {
        dy += _helpers_render_canvas__WEBPACK_IMPORTED_MODULE_9__.CanvasRender.getCanvasPx(24);
        let lineHeight = _helpers_render_canvas__WEBPACK_IMPORTED_MODULE_9__.CanvasRender.renderCanvasText(ctx, 'Receiver', {
          x: _helpers_render_canvas__WEBPACK_IMPORTED_MODULE_9__.CanvasRender.getCanvasPx(48),
          y: dy
        }, {
          fontSize: 12,
          color: '#ffffff99',
          fontWeight: 400,
          lineHeight: _helpers_render_canvas__WEBPACK_IMPORTED_MODULE_9__.CanvasRender.getCanvasPx(17),
          textAlign: 'left'
        });
        dy += lineHeight;
        dy += _helpers_render_canvas__WEBPACK_IMPORTED_MODULE_9__.CanvasRender.getCanvasPx(6);
        lineHeight = _helpers_render_canvas__WEBPACK_IMPORTED_MODULE_9__.CanvasRender.renderCanvasMultiLineText(ctx, _this3.address, {
          x: _helpers_render_canvas__WEBPACK_IMPORTED_MODULE_9__.CanvasRender.getCanvasPx(48),
          y: dy
        }, {
          fontSize: 14,
          color: '#ffffff',
          fontWeight: 400,
          lineHeight: _helpers_render_canvas__WEBPACK_IMPORTED_MODULE_9__.CanvasRender.getCanvasPx(20),
          textAlign: 'left',
          maxMultiLineTextWidth: 278
        });
      }
      return canvas;
    })();
  }
}
_class = HomeReceivePage;
_class.ɵfac = /*@__PURE__*/(() => {
  let ɵHomeReceivePage_BaseFactory;
  return function HomeReceivePage_Factory(t) {
    return (ɵHomeReceivePage_BaseFactory || (ɵHomeReceivePage_BaseFactory = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵgetInheritedFactory"](_class)))(t || _class);
  };
})();
_class.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵdefineComponent"]({
  type: _class,
  selectors: [["w-home-receive-page"]],
  standalone: true,
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵInheritDefinitionFeature"], _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵStandaloneFeature"]],
  decls: 25,
  vars: 21,
  consts: () => {
    let i18n_1;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_THIS_ADDRESS_ONLY_SUPPORTS_ASSETS_PLEASE_DO_NOT_TRANSFER_TO_OTHER_PUBLIC_CHAIN_ASSETS$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_RECEIVE_HOME_RECEIVE_COMPONENT_TS_2 = goog.getMsg(" This address only supports {$interpolation} assets, please do not transfer to other public chain assets. ", {
        "interpolation": "\uFFFD0\uFFFD"
      }, {
        original_code: {
          "interpolation": "{{ chain }}"
        }
      });
      i18n_1 = MSG_EXTERNAL_THIS_ADDRESS_ONLY_SUPPORTS_ASSETS_PLEASE_DO_NOT_TRANSFER_TO_OTHER_PUBLIC_CHAIN_ASSETS$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_RECEIVE_HOME_RECEIVE_COMPONENT_TS_2;
    } else {
      i18n_1 = "\u8A72\u5730\u5740\u50C5\u652F\u6301 " + "\uFFFD0\uFFFD" + " \u8CC7\u7522\uFF0C\u8ACB\u52FF\u8F49\u5165\u5176\u4ED6\u516C\u93C8\u8CC7\u7522 ";
    }
    let i18n_3;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_RECEIVER$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_RECEIVE_HOME_RECEIVE_COMPONENT_TS_4 = goog.getMsg("Receiver");
      i18n_3 = MSG_EXTERNAL_RECEIVER$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_RECEIVE_HOME_RECEIVE_COMPONENT_TS_4;
    } else {
      i18n_3 = "\u6536\u6B3E\u5730\u5740";
    }
    let i18n_5;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_SAVE_QR_CODE$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_RECEIVE_HOME_RECEIVE_COMPONENT_TS_6 = goog.getMsg(" Save QR code ");
      i18n_5 = MSG_EXTERNAL_SAVE_QR_CODE$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_RECEIVE_HOME_RECEIVE_COMPONENT_TS_6;
    } else {
      i18n_5 = "\u4FDD\u5B58\u4E8C\u7DAD\u78BC";
    }
    let i18n_0;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_SCAN_TO_ASSET_TYPE_TRANSFER$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_RECEIVE_HOME_RECEIVE_COMPONENT_TS__7 = goog.getMsg(" Scan to transfer {$interpolation} {$startTagSpan}({$interpolation_1}){$closeTagSpan}", {
        "closeTagSpan": "\uFFFD/#1:1\uFFFD\uFFFD/*4:1\uFFFD",
        "interpolation": "\uFFFD0\uFFFD",
        "interpolation_1": "\uFFFD0:1\uFFFD",
        "startTagSpan": "\uFFFD*4:1\uFFFD\uFFFD#1:1\uFFFD"
      }, {
        original_code: {
          "closeTagSpan": "</span>",
          "interpolation": "{{ assetType }}",
          "interpolation_1": "{{ agreement }}",
          "startTagSpan": "<span *ngIf=\"assetType !== symbol\">"
        }
      });
      i18n_0 = MSG_EXTERNAL_SCAN_TO_ASSET_TYPE_TRANSFER$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_RECEIVE_HOME_RECEIVE_COMPONENT_TS__7;
    } else {
      i18n_0 = "\u6383\u63CF\u4E8C\u7DAD\u78BC\uFF0C\u8F49\u8F09 " + "\uFFFD0\uFFFD" + " " + "\uFFFD*4:1\uFFFD\uFFFD#1:1\uFFFD" + "(" + "\uFFFD0:1\uFFFD" + ")" + "\uFFFD/#1:1\uFFFD\uFFFD/*4:1\uFFFD" + "";
    }
    let i18n_8;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_SHARE$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_RECEIVE_HOME_RECEIVE_COMPONENT_TS__9 = goog.getMsg(" Share ");
      i18n_8 = MSG_EXTERNAL_SHARE$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_RECEIVE_HOME_RECEIVE_COMPONENT_TS__9;
    } else {
      i18n_8 = "\u5206\u4EAB";
    }
    return [[3, "pageBackground", "headerBackground", "headerTranslucent", "titleColor", "headerButtonColor", "contentBackground", "contentHeaderArea", "contentSafeArea"], [1, "rounded-5", "bg-purple-gradient-start", "mt-3", "px-7", "py-6", "backdrop-blur"], [1, "text-center", "text-base", "font-semibold", "text-white/90"], i18n_0, [4, "ngIf"], [1, "mt-3", "flex"], ["name", "warn-grey", 1, "icon-4"], [1, "text-xss", "ml-2", "text-white/60"], i18n_1, ["wObSize", "", 1, "mt-6"], [1, "--qr-bg", "flex", "h-auto", "w-full", "items-center", "justify-center", "p-6"], [1, "flex", "h-full", "w-full", "items-center", "justify-center", "rounded-lg", "bg-white", "p-6"], [1, "h-full", "w-full", 3, "text"], [1, "mt-6", "w-full", 3, "wClickToCopy"], [1, "flex", "items-center", "justify-between", "text-white/60"], [1, "text-xs"], i18n_3, ["name", "copy"], [1, "mt-1", "break-all", "text-left", "text-white"], [1, "my-6", "flex", "w-full", "items-center", "justify-between"], ["bnRippleButton", "", "class", "from-blue-gradient-start mr-5 to-blue-gradient-end h-10.5 flex-1 rounded-full bg-white/20 bg-gradient-to-b text-center text-white/90"], ["bnRippleButton", "", 1, "from-red-gradient-start", "to-red-gradient-end", "h-10.5", "flex-1", "rounded-full", "bg-white/20", "bg-gradient-to-b", "text-center", "text-white/90", 3, "click"], i18n_5, ["bnRippleButton", "", 1, "from-blue-gradient-start", "mr-5", "to-blue-gradient-end", "h-10.5", "flex-1", "rounded-full", "bg-white/20", "bg-gradient-to-b", "text-center", "text-white/90", 3, "click"], i18n_8];
  },
  template: function HomeReceivePage_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](0, "common-page", 0)(1, "div", 1)(2, "div", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵi18nStart"](3, 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtemplate"](4, HomeReceivePage_span_4_Template, 2, 1, "span", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵi18nEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](5, "div", 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelement"](6, "w-icon", 6);
      _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵpipe"](7, "color");
      _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](8, "div", 7);
      _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵi18n"](9, 8);
      _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](10, "div", 9)(11, "div", 10)(12, "div", 11);
      _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelement"](13, "bn-qrcode", 12);
      _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](14, "button", 13)(15, "div", 14)(16, "span", 15);
      _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵi18n"](17, 16);
      _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelement"](18, "w-icon", 17);
      _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](19, "div", 18);
      _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](20);
      _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]()()()();
      _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](21, "div", 19);
      _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtemplate"](22, HomeReceivePage_Conditional_22_Template, 2, 0, "button", 20);
      _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](23, "button", 21);
      _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵlistener"]("click", function HomeReceivePage_Template_button_click_23_listener() {
        return ctx.saveQrcode();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵi18n"](24, 22);
      _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]()()();
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("pageBackground", "black")("headerBackground", "black")("headerTranslucent", false)("titleColor", "white")("headerButtonColor", "light")("contentBackground", "black")("contentHeaderArea", false)("contentSafeArea", true);
      _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](4);
      _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngIf", ctx.assetType !== ctx.symbol);
      _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵi18nExp"](ctx.assetType);
      _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵi18nApply"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵpureFunction1"](19, _c10, _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵpipeBind1"](7, 17, "subtext")));
      _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵi18nExp"](ctx.chain);
      _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵi18nApply"](9);
      _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](4);
      _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("text", ctx.qrCodeText);
      _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("wClickToCopy", ctx.address);
      _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](6);
      _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtextInterpolate1"](" ", ctx.address, " ");
      _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵconditional"](22, ctx.isMobile ? 22 : -1);
    }
  },
  dependencies: [_modules_page_module__WEBPACK_IMPORTED_MODULE_10__.CommonPageModule, _libs_bnf_components_ripple_button_ripple_button_directive__WEBPACK_IMPORTED_MODULE_15__.RippleButtonDirective, _libs_bnf_directives_click_to_copy_directive__WEBPACK_IMPORTED_MODULE_16__.ClickToCopyDirective, _libs_bnf_directives_ob_size_directive__WEBPACK_IMPORTED_MODULE_17__.ObSizeDirective, _angular_common__WEBPACK_IMPORTED_MODULE_22__.NgIf, _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_18__.CommonPageComponent, _components_icon_icon_component__WEBPACK_IMPORTED_MODULE_19__.IconComponent, _pipes_color_color_pipe__WEBPACK_IMPORTED_MODULE_20__.ColorPipe, _bnqkl_framework_components__WEBPACK_IMPORTED_MODULE_1__.QrcodeSvgComponent],
  styles: ["[_nghost-%COMP%]   .--qr-bg[_ngcontent-%COMP%] {\n  background-image: url('address_qr_bg.svg');\n  background-size: 100% 100%;\n  background-repeat: no-repeat;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL2FwcHMvd2FsbGV0L3NyYy9wYWdlcy9ob21lL3BhZ2VzL2hvbWUtcmVjZWl2ZS9ob21lLXJlY2VpdmUuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQ0U7RUFDRSwwQ0FBQTtFQUNBLDBCQUFBO0VBQ0EsNEJBQUE7QUFBSiIsInNvdXJjZXNDb250ZW50IjpbIjpob3N0IHtcclxuICAuLS1xci1iZyB7XHJcbiAgICBiYWNrZ3JvdW5kLWltYWdlOiB1cmwoLi9hc3NldHMvaW1hZ2VzL2FkZHJlc3NfcXJfYmcuc3ZnKTtcclxuICAgIGJhY2tncm91bmQtc2l6ZTogMTAwJSAxMDAlO1xyXG4gICAgYmFja2dyb3VuZC1yZXBlYXQ6IG5vLXJlcGVhdDtcclxuICB9XHJcbn1cclxuIl0sInNvdXJjZVJvb3QiOiIifQ== */"],
  changeDetection: 0
});
(0,tslib__WEBPACK_IMPORTED_MODULE_23__.__decorate)([HomeReceivePage.State(), HomeReceivePage.QueryParam('chain'), (0,tslib__WEBPACK_IMPORTED_MODULE_23__.__metadata)("design:type", String)], HomeReceivePage.prototype, "chain", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_23__.__decorate)([HomeReceivePage.State(), HomeReceivePage.QueryParam('symbol'), (0,tslib__WEBPACK_IMPORTED_MODULE_23__.__metadata)("design:type", Object)], HomeReceivePage.prototype, "symbol", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_23__.__decorate)([HomeReceivePage.State(), HomeReceivePage.QueryParam('address'), (0,tslib__WEBPACK_IMPORTED_MODULE_23__.__metadata)("design:type", Object)], HomeReceivePage.prototype, "address", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_23__.__decorate)([HomeReceivePage.State(), HomeReceivePage.QueryParam('assetType'), (0,tslib__WEBPACK_IMPORTED_MODULE_23__.__metadata)("design:type", String)], HomeReceivePage.prototype, "assetType", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_23__.__decorate)([HomeReceivePage.OnInit(), (0,tslib__WEBPACK_IMPORTED_MODULE_23__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_23__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_23__.__metadata)("design:returntype", void 0)], HomeReceivePage.prototype, "init", null);
(0,tslib__WEBPACK_IMPORTED_MODULE_23__.__decorate)([_bnqkl_util_web_decorator__WEBPACK_IMPORTED_MODULE_6__.cacheGetter, (0,tslib__WEBPACK_IMPORTED_MODULE_23__.__metadata)("design:type", Object), (0,tslib__WEBPACK_IMPORTED_MODULE_23__.__metadata)("design:paramtypes", [])], HomeReceivePage.prototype, "_qrcodeImage", null);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (HomeReceivePage);

/***/ }),

/***/ 69899:
/*!*****************************************************************************************!*\
  !*** ./node_modules/.pnpm/@plaoc+is-dweb@0.1.0/node_modules/@plaoc/is-dweb/esm/main.js ***!
  \*****************************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   dwebTarget: () => (/* binding */ dwebTarget),
/* harmony export */   isDweb: () => (/* binding */ isDweb),
/* harmony export */   isMobile: () => (/* binding */ isMobile)
/* harmony export */ });
/**
 * 判断是不是dweb
 * * @returns boolean
 */
const isDweb = () => {
  const isDweb = self.navigator.userAgent.includes("Dweb");
  // @ts-ignore
  const isPlaoc = self.__native_close_watcher_kit__ !== void 0;
  if (isDweb || isPlaoc) {
    return true;
  }
  const userAgentData = self.navigator.userAgentData;
  if (!userAgentData) {
    return false;
  }
  const brands = userAgentData.brands.filter(value => {
    return value.brand === "DwebBrowser";
  });
  return Array.isArray(brands) && brands.length > 0;
};
/**
 * 判断dweb大版本
 * @returns boolean
 */
const dwebTarget = () => {
  if (isDweb()) {
    const userAgentData = self.navigator.userAgentData;
    if (!userAgentData) {
      return 2.0;
    }
    const brands = userAgentData.brands.filter(value => {
      return value.brand === "jmm.browser.dweb";
    });
    if (Array.isArray(brands) && brands.length > 0) {
      return parseFloat(brands[0].version);
    }
  }
  return 1.0;
};
/**
 * 判断是否是移动端
 * @returns boolean
 */
const isMobile = () => {
  if (!navigator.userAgentData) {
    return true;
  }
  return !!navigator.userAgentData.mobile;
};

/***/ })

}]);
//# sourceMappingURL=apps_wallet_src_pages_home_pages_home-receive_home-receive_component_ts.js.map