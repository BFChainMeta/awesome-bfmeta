"use strict";
(self["webpackChunkwallet"] = self["webpackChunkwallet"] || []).push([["default-apps_wallet_src_pages_home_pages_home-payment-details_home-payment-details_component_ts"],{

/***/ 38093:
/*!*************************************************************************************************!*\
  !*** ./apps/wallet/src/pages/home/pages/home-payment-details/home-payment-details.component.ts ***!
  \*************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   PAYMENT_DETAILS_PAGE_STATUS: () => (/* binding */ PAYMENT_DETAILS_PAGE_STATUS),
/* harmony export */   PaymentDetailsPage: () => (/* binding */ PaymentDetailsPage),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 52542);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! tslib */ 90505);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @angular/core */ 61039);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! @angular/forms */ 7820);
/* harmony import */ var _bnqkl_framework_helpers__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @bnqkl/framework/helpers */ 12169);
/* harmony import */ var _bnqkl_framework_plugins_toast__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @bnqkl/framework/plugins/toast */ 18030);
/* harmony import */ var _bnqkl_util_web_extends_promise__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @bnqkl/util-web/extends-promise */ 87778);
/* harmony import */ var _modules_page_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ~modules/page.module */ 77538);
/* harmony import */ var _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @bnqkl/wallet-base/services/wallet/chain-base */ 27187);
/* harmony import */ var _bnqkl_wallet_base_services_wallet_chain__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @bnqkl/wallet-base/services/wallet/chain */ 27434);
/* harmony import */ var _bnqkl_wallet_base_services_wallet_wallet_data_storage__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @bnqkl/wallet-base/services/wallet/wallet-data-storage */ 63024);
/* harmony import */ var _pages_mime_pages_verify_fingerprint_verify_fingerprint_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ~pages/mime/pages/verify-fingerprint/verify-fingerprint.component */ 5780);
/* harmony import */ var _bnqkl_framework_plugins_biometric__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @bnqkl/framework/plugins/biometric */ 52583);
/* harmony import */ var _libs_bnf_components_ripple_button_ripple_button_directive__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../../../../../../libs/bnf/components/ripple-button/ripple-button.directive */ 16505);
/* harmony import */ var _libs_bnf_directives_auto_complete_off_directive__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../../../../../../libs/bnf/directives/auto-complete-off.directive */ 66722);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! @angular/common */ 6729);
/* harmony import */ var _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../../../../../../libs/bnf/modules/page/common-page/common-page.component */ 62052);
/* harmony import */ var _components_icon_icon_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../../../../components/icon/icon.component */ 74703);
/* harmony import */ var _libs_bnf_pipes_errors_errors_pipe__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../../../../../../../libs/bnf/pipes/errors/errors.pipe */ 68362);
/* harmony import */ var _libs_bnf_pipes_number_format_number_format_pipe__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ../../../../../../../libs/bnf/pipes/number-format/number-format.pipe */ 89873);
/* harmony import */ var _libs_bnf_pipes_address_hidden_address_hidden_pipe__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ../../../../../../../libs/bnf/pipes/address-hidden/address-hidden.pipe */ 35222);
/* harmony import */ var _libs_bnf_pipes_amountFixed_amount_fixed_pipe__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ../../../../../../../libs/bnf/pipes/amountFixed/amount-fixed.pipe */ 44070);

var _class;























const _c10 = () => ({
  removeZero: true
});
function PaymentDetailsPage_ng_container_2_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r9 = _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](1, "div", 5)(2, "w-icon", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵlistener"]("click", function PaymentDetailsPage_ng_container_2_ng_container_1_Template_w_icon_click_2_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵrestoreView"](_r9);
      const ctx_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵresetView"](ctx_r8.closeModal());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](3, "h3", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵi18n"](4, 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](5, "div", 9)(6, "span", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵi18n"](7, 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](8, "span", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵtext"](9);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](10, "div", 13)(11, "span", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵi18n"](12, 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](13, "span", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵi18n"](14, 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](15, "div", 16)(16, "span", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵi18n"](17, 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](18, "span", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵtext"](19);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵpipe"](20, "amountFixed");
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const ctx_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵadvance"](9);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵtextInterpolate"](ctx_r6.dataInfo.chain);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵadvance"](10);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵtextInterpolate2"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵpipeBind3"](20, 3, ctx_r6.dataInfo.fee, ctx_r6.dataInfo.decimals, _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵpureFunction0"](7, _c10)), " ", ctx_r6.dataInfo.symbol, " ");
  }
}
function PaymentDetailsPage_ng_container_2_ng_container_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r11 = _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](1, "div", 5)(2, "w-icon", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵlistener"]("click", function PaymentDetailsPage_ng_container_2_ng_container_2_Template_w_icon_click_2_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵrestoreView"](_r11);
      const ctx_r10 = _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵresetView"](ctx_r10.closeModal());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](3, "h3", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](5, "div", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵtext"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵpipe"](7, "numberFormat");
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵpipe"](8, "amountFixed");
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](9, "span", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵtext"](10);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](11, "div", 20)(12, "span", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵi18n"](13, 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](14, "span", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵi18n"](15, 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](16, "div", 20)(17, "span", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵi18n"](18, 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](19, "span", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵtext"](20);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵpipe"](21, "addressHidden");
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](22, "div", 26)(23, "span", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵi18n"](24, 27);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](25, "span", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵtext"](26);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵpipe"](27, "addressHidden");
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](28, "div", 26)(29, "span", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵi18n"](30, 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](31, "span", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵtext"](32);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵpipe"](33, "amountFixed");
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const ctx_r7 = _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵtextInterpolate"](ctx_r7.pageTitle);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵpipeBind1"](7, 8, _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵpipeBind3"](8, 10, ctx_r7.dataInfo.amount, ctx_r7.dataInfo.decimals, _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵpureFunction0"](22, _c10))), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵtextInterpolate"](ctx_r7.dataInfo.assetType);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵi18nExp"](ctx_r7.dataInfo.chain);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵi18nApply"](15);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵpipeBind1"](21, 14, ctx_r7.dataInfo.receiveAddress));
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵadvance"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵpipeBind1"](27, 16, ctx_r7.dataInfo.senderAddress));
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵadvance"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵtextInterpolate2"](" \u2248 ", _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵpipeBind3"](33, 18, ctx_r7.dataInfo.fee, ctx_r7.dataInfo.decimals, _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵpureFunction0"](23, _c10)), " ", ctx_r7.dataInfo.symbol, " ");
  }
}
function PaymentDetailsPage_ng_container_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵtemplate"](1, PaymentDetailsPage_ng_container_2_ng_container_1_Template, 21, 8, "ng-container", 4)(2, PaymentDetailsPage_ng_container_2_ng_container_2_Template, 34, 24, "ng-container", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵproperty"]("ngIf", ctx_r0.dataInfo.status === ctx_r0.PAYMENT_DETAILS_PAGE_STATUS.TransactionPassword);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵproperty"]("ngIf", ctx_r0.dataInfo.status === ctx_r0.PAYMENT_DETAILS_PAGE_STATUS.Details);
  }
}
function PaymentDetailsPage_ng_container_3_w_icon_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r16 = _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](0, "w-icon", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵlistener"]("click", function PaymentDetailsPage_ng_container_3_w_icon_2_Template_w_icon_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵrestoreView"](_r16);
      const ctx_r15 = _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵresetView"](ctx_r15.closeModal());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
  }
}
function PaymentDetailsPage_ng_container_3_w_icon_3_Template(rf, ctx) {
  if (rf & 1) {
    const _r18 = _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](0, "w-icon", 40);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵlistener"]("click", function PaymentDetailsPage_ng_container_3_w_icon_3_Template_w_icon_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵrestoreView"](_r18);
      const ctx_r17 = _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵresetView"](ctx_r17.back("walletPassword"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
  }
}
function PaymentDetailsPage_ng_container_3_div_11_div_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const errors_r19 = _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵnextContext"]().ngIf;
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵtextInterpolate1"](" ", errors_r19["password"], " ");
  }
}
function PaymentDetailsPage_ng_container_3_div_11_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](0, "div", 41);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵtemplate"](1, PaymentDetailsPage_ng_container_3_div_11_div_1_Template, 2, 1, "div", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const errors_r19 = ctx.ngIf;
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵproperty"]("ngIf", errors_r19["password"]);
  }
}
function PaymentDetailsPage_ng_container_3_Template(rf, ctx) {
  if (rf & 1) {
    const _r23 = _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](1, "div", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵtemplate"](2, PaymentDetailsPage_ng_container_3_w_icon_2_Template, 1, 0, "w-icon", 29)(3, PaymentDetailsPage_ng_container_3_w_icon_3_Template, 1, 0, "w-icon", 30);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](4, "span", 31);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵtext"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](6, "form", 32);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵlistener"]("ngSubmit", function PaymentDetailsPage_ng_container_3_Template_form_ngSubmit_6_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵrestoreView"](_r23);
      const ctx_r22 = _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵresetView"](ctx_r22.onSubmit());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](7, "fieldset")(8, "legend", 33)(9, "div", 34);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵi18n"](10, 35);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵtemplate"](11, PaymentDetailsPage_ng_container_3_div_11_Template, 2, 1, "div", 36);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵpipe"](12, "errors");
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](13, "div", 37);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelement"](14, "input", 38);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](15, "w-icon", 39);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵlistener"]("click", function PaymentDetailsPage_ng_container_3_Template_w_icon_click_15_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵrestoreView"](_r23);
      const ctx_r24 = _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵresetView"](ctx_r24.inputContentShow = !ctx_r24.inputContentShow);
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]()()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵproperty"]("ngIf", ctx_r1.dataInfo.status === ctx_r1.PAYMENT_DETAILS_PAGE_STATUS.InputPassword);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵproperty"]("ngIf", ctx_r1.dataInfo.status !== ctx_r1.PAYMENT_DETAILS_PAGE_STATUS.InputPassword);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵtextInterpolate"](ctx_r1.pageTitle);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵproperty"]("formGroup", ctx_r1.form);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵproperty"]("ngIf", _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵpipeBind1"](12, 7, ctx_r1.bioforestPassword));
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵproperty"]("type", ctx_r1.inputContentShow ? "text" : "password");
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵproperty"]("name", ctx_r1.inputContentShow ? "visible" : "hidden");
  }
}
function PaymentDetailsPage_ng_container_4_w_icon_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r30 = _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](0, "w-icon", 40);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵlistener"]("click", function PaymentDetailsPage_ng_container_4_w_icon_2_Template_w_icon_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵrestoreView"](_r30);
      const ctx_r29 = _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵresetView"](ctx_r29.back("walletPassword"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
  }
}
function PaymentDetailsPage_ng_container_4_w_icon_3_Template(rf, ctx) {
  if (rf & 1) {
    const _r32 = _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](0, "w-icon", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵlistener"]("click", function PaymentDetailsPage_ng_container_4_w_icon_3_Template_w_icon_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵrestoreView"](_r32);
      const ctx_r31 = _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵresetView"](ctx_r31.closeModal());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
  }
}
function PaymentDetailsPage_ng_container_4_w_icon_6_Template(rf, ctx) {
  if (rf & 1) {
    const _r34 = _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](0, "w-icon", 47);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵlistener"]("click", function PaymentDetailsPage_ng_container_4_w_icon_6_Template_w_icon_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵrestoreView"](_r34);
      const ctx_r33 = _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵresetView"](ctx_r33.fingerprintPay());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
  }
}
function PaymentDetailsPage_ng_container_4_div_12_div_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](0, "div", 50);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const errors_r35 = _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵnextContext"]().ngIf;
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵtextInterpolate1"](" ", errors_r35["pwdErr"], " ");
  }
}
function PaymentDetailsPage_ng_container_4_div_12_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](0, "div", 48);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵtemplate"](1, PaymentDetailsPage_ng_container_4_div_12_div_1_Template, 2, 1, "div", 49);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const errors_r35 = ctx.ngIf;
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵproperty"]("ngIf", errors_r35["pwdErr"]);
  }
}
function PaymentDetailsPage_ng_container_4_Template(rf, ctx) {
  if (rf & 1) {
    const _r39 = _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](1, "div", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵtemplate"](2, PaymentDetailsPage_ng_container_4_w_icon_2_Template, 1, 0, "w-icon", 30)(3, PaymentDetailsPage_ng_container_4_w_icon_3_Template, 1, 0, "w-icon", 29);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](4, "span", 31);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵtext"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵtemplate"](6, PaymentDetailsPage_ng_container_4_w_icon_6_Template, 1, 0, "w-icon", 42);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](7, "form", 32);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵlistener"]("ngSubmit", function PaymentDetailsPage_ng_container_4_Template_form_ngSubmit_7_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵrestoreView"](_r39);
      const ctx_r38 = _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵresetView"](ctx_r38.onSubmit());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](8, "fieldset")(9, "legend", 33)(10, "div", 43);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵi18n"](11, 44);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵtemplate"](12, PaymentDetailsPage_ng_container_4_div_12_Template, 2, 1, "div", 45);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵpipe"](13, "errors");
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](14, "div", 37);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelement"](15, "input", 46);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](16, "w-icon", 39);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵlistener"]("click", function PaymentDetailsPage_ng_container_4_Template_w_icon_click_16_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵrestoreView"](_r39);
      const ctx_r40 = _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵresetView"](ctx_r40.inputContentShow = !ctx_r40.inputContentShow);
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]()()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵproperty"]("ngIf", ctx_r2.dataInfo.status !== ctx_r2.PAYMENT_DETAILS_PAGE_STATUS.InputPassword);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵproperty"]("ngIf", ctx_r2.dataInfo.status === ctx_r2.PAYMENT_DETAILS_PAGE_STATUS.InputPassword);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵtextInterpolate"](ctx_r2.pageTitle);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵproperty"]("ngIf", ctx_r2.hasOpenFingerprintPay);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵproperty"]("formGroup", ctx_r2.form);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵproperty"]("ngClass", ctx_r2.password.errors && (ctx_r2.password.dirty || ctx_r2.password.touched) ? "text-error" : "text-title");
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵproperty"]("ngIf", _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵpipeBind1"](13, 9, ctx_r2.password));
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵproperty"]("type", ctx_r2.inputContentShow ? "text" : "password");
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵproperty"]("name", ctx_r2.inputContentShow ? "visible" : "hidden");
  }
}
function PaymentDetailsPage_ng_container_6_Template(rf, ctx) {
  if (rf & 1) {
    const _r42 = _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](1, "button", 51);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵlistener"]("click", function PaymentDetailsPage_ng_container_6_Template_button_click_1_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵrestoreView"](_r42);
      const ctx_r41 = _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵresetView"](ctx_r41.next());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵi18n"](2, 52);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementContainerEnd"]();
  }
}
const _c35 = a0 => ({
  "opacity-30": a0
});
function PaymentDetailsPage_ng_container_7_Template(rf, ctx) {
  if (rf & 1) {
    const _r44 = _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](1, "div", 53)(2, "span", 54);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵi18n"](3, 55);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](4, "button", 56);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵlistener"]("click", function PaymentDetailsPage_ng_container_7_Template_button_click_4_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵrestoreView"](_r44);
      const ctx_r43 = _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵresetView"](ctx_r43.next());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵi18n"](5, 57);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵi18nExp"](ctx_r4.dataInfo.chain);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵi18nApply"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵproperty"]("disabled", !ctx_r4.bioforestPassword.value)("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵpureFunction1"](3, _c35, !ctx_r4.bioforestPassword.value));
  }
}
function PaymentDetailsPage_ng_container_8_Template(rf, ctx) {
  if (rf & 1) {
    const _r46 = _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](1, "div", 53)(2, "span", 58);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵlistener"]("click", function PaymentDetailsPage_ng_container_8_Template_span_click_2_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵrestoreView"](_r46);
      const ctx_r45 = _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵresetView"](ctx_r45.resetPassword());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵi18n"](3, 59);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](4, "form", 60);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵlistener"]("ngSubmit", function PaymentDetailsPage_ng_container_8_Template_form_ngSubmit_4_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵrestoreView"](_r46);
      const ctx_r47 = _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵresetView"](ctx_r47.onSubmit());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](5, "button", 61);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵi18n"](6, 62);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵproperty"]("formGroup", ctx_r5.form);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵproperty"]("disabled", !ctx_r5.password.value);
  }
}
/** 页面显示状态 */
var PAYMENT_DETAILS_PAGE_STATUS;
(function (PAYMENT_DETAILS_PAGE_STATUS) {
  PAYMENT_DETAILS_PAGE_STATUS[PAYMENT_DETAILS_PAGE_STATUS["Details"] = 0] = "Details";
  PAYMENT_DETAILS_PAGE_STATUS[PAYMENT_DETAILS_PAGE_STATUS["TransactionPassword"] = 1] = "TransactionPassword";
  /** 输入密码功能 */
  PAYMENT_DETAILS_PAGE_STATUS[PAYMENT_DETAILS_PAGE_STATUS["InputPassword"] = 2] = "InputPassword";
})(PAYMENT_DETAILS_PAGE_STATUS || (PAYMENT_DETAILS_PAGE_STATUS = {}));
/** 转账弹出框 */
class PaymentDetailsPage extends _modules_page_module__WEBPACK_IMPORTED_MODULE_4__.CommonPageBase {
  constructor() {
    super(...arguments);
    /** 页面现在类别 */
    this.PAYMENT_DETAILS_PAGE_STATUS = PAYMENT_DETAILS_PAGE_STATUS;
    /** 页面返回值 */
    this.returnValue$ = new _modules_page_module__WEBPACK_IMPORTED_MODULE_4__.PageReturnValue();
    /** 引入钱包存储服务 */
    this.walletDataStorageV2Service = (0,_angular_core__WEBPACK_IMPORTED_MODULE_18__.inject)(_bnqkl_wallet_base_services_wallet_wallet_data_storage__WEBPACK_IMPORTED_MODULE_7__.WalletDataStorageV2Service);
    /** 链服务 */
    this.chainV2Service = (0,_angular_core__WEBPACK_IMPORTED_MODULE_18__.inject)(_bnqkl_wallet_base_services_wallet_chain__WEBPACK_IMPORTED_MODULE_6__.ChainV2Service);
    /** 是否打开指纹支付 */
    this.hasOpenFingerprintPay = !!this.walletDataStorageV2Service.walletAppSettings.fingerprintPay;
    /** 弹窗类型 */
    this.pageType = 'paymentDetails';
    /** 弹窗title */
    this.pageTitle = "Payment Details";
    /** BFChain交易密码 */
    this.bioforestPasswordPublicKeyList = [];
    /** 是否设置BFChain交易密码 */
    this.walletInfo_password = '';
    /** 安全密码校验状态 */
    // private _paysecretCheckStatus: PAYSECERT_CHECK_RESULT = PAYSECERT_CHECK_RESULT.FAIL;
    /** 生物链林密码 */
    this.bioforestPassword = new _angular_forms__WEBPACK_IMPORTED_MODULE_19__.FormControl('', {
      nonNullable: true,
      validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_19__.Validators.required]
    });
    /**
     * 钱包密码
     * 校验放在按钮那边，这里不再提供实时校验
     */
    this.password = new _angular_forms__WEBPACK_IMPORTED_MODULE_19__.FormControl('', {
      nonNullable: true,
      validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_19__.Validators.required]
    });
    /**
     * 密码型内容显示与否
     */
    this.inputContentShow = false;
    /** 要提交的表单与复合验证 */
    this.form = new _angular_forms__WEBPACK_IMPORTED_MODULE_19__.FormGroup({
      bioforestPassword: this.bioforestPassword,
      password: this.password
    }, {
      validators: [],
      asyncValidators: []
    });
  }
  /** 检验是否全部都过了 */
  _checkAllBioforestPasswordCheck() {
    const index = this.bioforestPasswordPublicKeyList.findIndex(item => item.active);
    if (index > -1) {
      const allCheck = index === this.bioforestPasswordPublicKeyList.length - 1;
      if (allCheck === false) {
        /// 没有全部，继续下一个
        this.bioforestPasswordPublicKeyList.forEach(item => item.active = false);
        const nextItem = this.bioforestPasswordPublicKeyList[index + 1];
        nextItem.active = true;
        if ((0,_bnqkl_framework_helpers__WEBPACK_IMPORTED_MODULE_1__.$isNoEmptyString)(nextItem.bioforestPasswordPublicKey)) {
          this.pageType = 'bioforestPassword';
          this.pageTitle = "" + nextItem.chain + " Trading Password";
          this.bioforestPassword.setValue('');
        } else {
          /// nextItem的bioforestPasswordPublicKey可能是空的，那么再次调用一下
          return this._checkAllBioforestPasswordCheck();
        }
      }
      this.cdRef.detectChanges();
      return allCheck;
    }
    return true;
  }
  /** 校验生物链林密码 */
  checkBioforestPassword() {
    var _this = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      if (_this.dataInfo === undefined || _this.chainV2Service.isBioforestChainByChainName(_this.dataInfo.chain) === false) {
        return true;
      }
      if (_this.dataInfo.mnemonic === undefined) {
        throw new Error('lack mnemonic');
      }
      /**
       * 传入的交易密码publicKey为 this.bioforestPasswordPublicKey
       * 参考 borker 内的函数 verifySecondPassphrase
       */
      const item = _this.bioforestPasswordPublicKeyList.find(item => item.active);
      if (item === undefined) {
        return true;
      }
      if ((0,_bnqkl_framework_helpers__WEBPACK_IMPORTED_MODULE_1__.$isNoEmptyString)(item.bioforestPasswordPublicKey) === false) {
        return _this._checkAllBioforestPasswordCheck();
      }
      const chainApiService = _this.chainV2Service.getChainService(_this.dataInfo.chain);
      item.status = yield chainApiService.verifySecondPassphrase(_this.dataInfo.mnemonic, _this.bioforestPassword.value, item.bioforestPasswordPublicKey);
      if (item.status === _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_5__.PAYSECERT_CHECK_RESULT.FAIL) {
        _this.bioforestPassword.setErrors({
          password: "password input error"
        });
        return false;
      }
      item.paysecret = _this.bioforestPassword.value;
      return _this._checkAllBioforestPasswordCheck();
    })();
  }
  /** 关闭弹出层 */
  closeModal() {
    this.returnValue$.next(false);
    this.returnValue$.complete();
  }
  /** 返回上一个弹窗 */
  back(event) {
    if (event === 'walletPassword') {
      this.pageType = 'paymentDetails';
      this.pageTitle = "Payment Details";
      this.bioforestPassword.setValue('');
      this.password.setValue('');
      this.bioforestPasswordPublicKeyList.forEach(item => item.active = false);
    }
  }
  /** 弹窗下一步的点击事件 */
  next() {
    var _this2 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const {
        dataInfo
      } = _this2;
      if (dataInfo.status === PAYMENT_DETAILS_PAGE_STATUS.TransactionPassword) {
        /// 判断余额
        if (BigInt(dataInfo.balance) < BigInt(dataInfo.fee)) {
          _bnqkl_framework_plugins_toast__WEBPACK_IMPORTED_MODULE_2__.Toast.show("Insufficient balance in " + dataInfo.symbol + "");
          return;
        }
      }
      if (_this2.pageType === 'paymentDetails') {
        const item = _this2.bioforestPasswordPublicKeyList[0];
        if (item) {
          item.active = true;
          if ((0,_bnqkl_framework_helpers__WEBPACK_IMPORTED_MODULE_1__.$isNoEmptyString)(item.bioforestPasswordPublicKey)) {
            _this2.pageType = 'bioforestPassword';
            _this2.pageTitle = "" + item.chain + " Trading Password";
            return;
          } else {
            const res = _this2._checkAllBioforestPasswordCheck();
            if (res === false) {
              return;
            }
          }
        }
        _this2.pageType = 'walletPassword';
        _this2.pageTitle = "Password";
      } else {
        const res = yield _this2.checkBioforestPassword();
        if (res === false) {
          /// 密码校验不过去
          return;
        }
        _this2.pageType = 'walletPassword';
        _this2.pageTitle = "Password";
      }
      yield (0,_bnqkl_util_web_extends_promise__WEBPACK_IMPORTED_MODULE_3__.sleep)(0);
      _this2.cdRef.detectChanges();
    })();
  }
  /** 接收选择到的币种 */
  walletInfo() {
    var _this3 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this3.walletInfo_password = _this3.walletDataStorageV2Service.walletAppSettings.password;
      _this3._initBioforestPasswordPublicKeyList();
    })();
  }
  _initBioforestPasswordPublicKeyList() {
    var _this$dataInfo$biofor;
    if (this.bioforestPasswordPublicKeyList.length) {
      return;
    }
    const bioforestPasswordPublicKey = (_this$dataInfo$biofor = this.dataInfo.bioforestPasswordPublicKey) !== null && _this$dataInfo$biofor !== void 0 ? _this$dataInfo$biofor : '';
    this.bioforestPasswordPublicKeyList = typeof bioforestPasswordPublicKey === 'string' ? [{
      chain: this.dataInfo.chain,
      bioforestPasswordPublicKey
    }] : bioforestPasswordPublicKey;
  }
  /** 接收选择到的币种 */
  statusChange() {
    var _this4 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      if (_this4.dataInfo.status === PAYMENT_DETAILS_PAGE_STATUS.InputPassword) {
        _this4._initBioforestPasswordPublicKeyList();
        const item = _this4.bioforestPasswordPublicKeyList[0];
        /// 切换到输入密码页面就行
        if (item) {
          item.active = true;
          if ((0,_bnqkl_framework_helpers__WEBPACK_IMPORTED_MODULE_1__.$isNoEmptyString)(item.bioforestPasswordPublicKey)) {
            _this4.pageType = 'bioforestPassword';
            _this4.pageTitle = "" + item.chain + " Trading Password";
            return;
          } else {
            const res = _this4._checkAllBioforestPasswordCheck();
            if (res === false) {
              return;
            }
          }
        }
        _this4.pageType = 'walletPassword';
        _this4.pageTitle = "Password";
      }
    })();
  }
  /** 去重置密码页 */
  resetPassword() {
    var _this5 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this5.returnValue$.next(false);
      _this5.returnValue$.complete();
      _this5.nav.routeTo('mnemonic/reset-password-before');
    })();
  }
  /** 输入密码之后的点击事件 */
  onSubmit() {
    var _this6 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      if (_this6.pageType === 'bioforestPassword') {
        const res = yield _this6.checkBioforestPassword();
        if (res === false) {
          /// 密码校验不过去
          return;
        }
        _this6.pageType = 'walletPassword';
        _this6.pageTitle = "Password";
      } else if (_this6.pageType === 'walletPassword') {
        if (_this6.form.value.password !== _this6.walletInfo_password) {
          _this6.password.setErrors({
            pwdErr: "password input error"
          });
        } else {
          /// 是否输入生物链林密码
          _this6.returnValue$.return(_this6.bioforestPasswordPublicKeyList);
        }
      }
    })();
  }
  /** 指纹支付 */
  fingerprintPay() {
    var _this7 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      /// 判断是否被系统禁用
      const isProhibited = sessionStorage.getItem(_pages_mime_pages_verify_fingerprint_verify_fingerprint_component__WEBPACK_IMPORTED_MODULE_8__.FINGERPRINT_PROHIBITION_OF_USE);
      if (isProhibited) {
        _bnqkl_framework_plugins_toast__WEBPACK_IMPORTED_MODULE_2__.Toast.show("System fingerprinting has been disabled");
        return;
      }
      /// 判断下间隔
      const fingerprintTimestamp = Number(sessionStorage.getItem(_pages_mime_pages_verify_fingerprint_verify_fingerprint_component__WEBPACK_IMPORTED_MODULE_8__.FINGERPRINT_INTERVAL_SESSION_KEY) || 0);
      if (fingerprintTimestamp > 0) {
        const interval = Date.now() - fingerprintTimestamp;
        if (interval < 30 * 1000) {
          const waiting = 30 - Math.floor(interval / 1000);
          _bnqkl_framework_plugins_toast__WEBPACK_IMPORTED_MODULE_2__.Toast.show("Please try again in " + waiting + " seconds");
          return;
        }
      }
      /// 判断是否开启
      try {
        const info = yield _bnqkl_framework_plugins_biometric__WEBPACK_IMPORTED_MODULE_9__.NativeBiometric.isAvailable();
        _this7.console.log(info);
        if (info.isAvailable === false) {
          _this7.alert({
            bodyMessage: "Please go to the phone system to register fingerprints"
          });
          return;
        }
      } catch (error) {
        _this7.alert({
          bodyMessage: "Please go to the phone system to register fingerprints"
        });
        return;
      }
      const {
        success,
        code
      } = yield _bnqkl_framework_plugins_biometric__WEBPACK_IMPORTED_MODULE_9__.NativeBiometric.verifyIdentity({
        maxAttempts: 5,
        title: "Verify Fingerprint",
        negativeButtonText: "Cancel"
      });
      if (success) {
        _bnqkl_framework_plugins_toast__WEBPACK_IMPORTED_MODULE_2__.Toast.show("Validation succeeded");
        sessionStorage.removeItem(_pages_mime_pages_verify_fingerprint_verify_fingerprint_component__WEBPACK_IMPORTED_MODULE_8__.FINGERPRINT_INTERVAL_SESSION_KEY);
        yield (0,_bnqkl_util_web_extends_promise__WEBPACK_IMPORTED_MODULE_3__.sleep)(180);
        _this7.returnValue$.return(_this7.bioforestPasswordPublicKeyList);
        return;
      } else if (code != undefined) {
        if (code === 0) {
          _this7.alert({
            bodyMessage: "Fingerprint verification failed"
          });
          return;
        } else if (code === 7) {
          sessionStorage.setItem(_pages_mime_pages_verify_fingerprint_verify_fingerprint_component__WEBPACK_IMPORTED_MODULE_8__.FINGERPRINT_INTERVAL_SESSION_KEY, String(Date.now()));
          const waiting = 30;
          _bnqkl_framework_plugins_toast__WEBPACK_IMPORTED_MODULE_2__.Toast.show("Please try again in " + waiting + " seconds");
          return;
        } else if (code === 9) {
          localStorage.setItem(_pages_mime_pages_verify_fingerprint_verify_fingerprint_component__WEBPACK_IMPORTED_MODULE_8__.FINGERPRINT_PROHIBITION_OF_USE, '1');
          yield _this7.alert({
            bodyMessage: "The system fingerprint has been banned, please reset the system fingerprint first.",
            buttonText: "Confirm",
            footerTheme: 'blank'
          });
          return;
        }
      }
    })();
  }
}
_class = PaymentDetailsPage;
_class.ɵfac = /*@__PURE__*/(() => {
  let ɵPaymentDetailsPage_BaseFactory;
  return function PaymentDetailsPage_Factory(t) {
    return (ɵPaymentDetailsPage_BaseFactory || (ɵPaymentDetailsPage_BaseFactory = _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵgetInheritedFactory"](_class)))(t || _class);
  };
})();
_class.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵdefineComponent"]({
  type: _class,
  selectors: [["w-home-payment-details-page"]],
  inputs: {
    dataInfo: "dataInfo"
  },
  outputs: {
    returnValue$: "returnValue$"
  },
  standalone: true,
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵInheritDefinitionFeature"], _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵStandaloneFeature"]],
  decls: 9,
  vars: 11,
  consts: () => {
    let i18n_0;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_SIGNATURE_CONFIRMED$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_PAYMENT_DETAILS_HOME_PAYMENT_DETAILS_COMPONENT_TS___1 = goog.getMsg(" Signature Confirmed ");
      i18n_0 = MSG_EXTERNAL_SIGNATURE_CONFIRMED$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_PAYMENT_DETAILS_HOME_PAYMENT_DETAILS_COMPONENT_TS___1;
    } else {
      i18n_0 = " Signature Confirmed ";
    }
    let i18n_2;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_EVENT_SOURCE$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_PAYMENT_DETAILS_HOME_PAYMENT_DETAILS_COMPONENT_TS___3 = goog.getMsg("Event Source");
      i18n_2 = MSG_EXTERNAL_EVENT_SOURCE$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_PAYMENT_DETAILS_HOME_PAYMENT_DETAILS_COMPONENT_TS___3;
    } else {
      i18n_2 = "Event Source";
    }
    let i18n_4;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_EVENT_CONTENT$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_PAYMENT_DETAILS_HOME_PAYMENT_DETAILS_COMPONENT_TS___5 = goog.getMsg(" Event Content ");
      i18n_4 = MSG_EXTERNAL_EVENT_CONTENT$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_PAYMENT_DETAILS_HOME_PAYMENT_DETAILS_COMPONENT_TS___5;
    } else {
      i18n_4 = " Event Content ";
    }
    let i18n_6;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_SET_TRANSACTION_PASSWORD$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_PAYMENT_DETAILS_HOME_PAYMENT_DETAILS_COMPONENT_TS___7 = goog.getMsg(" Set Transaction Password ");
      i18n_6 = MSG_EXTERNAL_SET_TRANSACTION_PASSWORD$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_PAYMENT_DETAILS_HOME_PAYMENT_DETAILS_COMPONENT_TS___7;
    } else {
      i18n_6 = " Set Transaction Password ";
    }
    let i18n_8;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_MINER_FEE$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_PAYMENT_DETAILS_HOME_PAYMENT_DETAILS_COMPONENT_TS___9 = goog.getMsg("Miner Fee");
      i18n_8 = MSG_EXTERNAL_MINER_FEE$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_PAYMENT_DETAILS_HOME_PAYMENT_DETAILS_COMPONENT_TS___9;
    } else {
      i18n_8 = "Miner Fee";
    }
    let i18n_11;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_PAYMENT_INFO$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_PAYMENT_DETAILS_HOME_PAYMENT_DETAILS_COMPONENT_TS___12 = goog.getMsg(" Payment Info ");
      i18n_11 = MSG_EXTERNAL_PAYMENT_INFO$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_PAYMENT_DETAILS_HOME_PAYMENT_DETAILS_COMPONENT_TS___12;
    } else {
      i18n_11 = " Payment Info ";
    }
    let i18n_13;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_CHAIN_TRANSFER$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_PAYMENT_DETAILS_HOME_PAYMENT_DETAILS_COMPONENT_TS___14 = goog.getMsg(" {$interpolation} Transfer ", {
        "interpolation": "\uFFFD0\uFFFD"
      }, {
        original_code: {
          "interpolation": "{{ dataInfo.chain }}"
        }
      });
      i18n_13 = MSG_EXTERNAL_CHAIN_TRANSFER$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_PAYMENT_DETAILS_HOME_PAYMENT_DETAILS_COMPONENT_TS___14;
    } else {
      i18n_13 = " " + "\uFFFD0\uFFFD" + " Transfer ";
    }
    let i18n_15;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_RECEIVER$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_PAYMENT_DETAILS_HOME_PAYMENT_DETAILS_COMPONENT_TS___16 = goog.getMsg("Receiver");
      i18n_15 = MSG_EXTERNAL_RECEIVER$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_PAYMENT_DETAILS_HOME_PAYMENT_DETAILS_COMPONENT_TS___16;
    } else {
      i18n_15 = "Receiver";
    }
    let i18n_17;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_PAYER$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_PAYMENT_DETAILS_HOME_PAYMENT_DETAILS_COMPONENT_TS___18 = goog.getMsg("Payer");
      i18n_17 = MSG_EXTERNAL_PAYER$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_PAYMENT_DETAILS_HOME_PAYMENT_DETAILS_COMPONENT_TS___18;
    } else {
      i18n_17 = "Payer";
    }
    let i18n_19;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_FEE$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_PAYMENT_DETAILS_HOME_PAYMENT_DETAILS_COMPONENT_TS___20 = goog.getMsg("Fee");
      i18n_19 = MSG_EXTERNAL_FEE$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_PAYMENT_DETAILS_HOME_PAYMENT_DETAILS_COMPONENT_TS___20;
    } else {
      i18n_19 = "Fee";
    }
    let i18n_21;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_TRANSACTION_PASSWORD$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_PAYMENT_DETAILS_HOME_PAYMENT_DETAILS_COMPONENT_TS__22 = goog.getMsg("Transaction password");
      i18n_21 = MSG_EXTERNAL_TRANSACTION_PASSWORD$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_PAYMENT_DETAILS_HOME_PAYMENT_DETAILS_COMPONENT_TS__22;
    } else {
      i18n_21 = "Transaction password";
    }
    let i18n_23;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_ENTER_THE_TRANSACTION_PASSWORD$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_PAYMENT_DETAILS_HOME_PAYMENT_DETAILS_COMPONENT_TS__24 = goog.getMsg("Enter the transaction password");
      i18n_23 = MSG_EXTERNAL_ENTER_THE_TRANSACTION_PASSWORD$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_PAYMENT_DETAILS_HOME_PAYMENT_DETAILS_COMPONENT_TS__24;
    } else {
      i18n_23 = "Enter the transaction password";
    }
    let i18n_25;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_WALLET_PASSWORD$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_PAYMENT_DETAILS_HOME_PAYMENT_DETAILS_COMPONENT_TS__26 = goog.getMsg(" Wallet Password ");
      i18n_25 = MSG_EXTERNAL_WALLET_PASSWORD$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_PAYMENT_DETAILS_HOME_PAYMENT_DETAILS_COMPONENT_TS__26;
    } else {
      i18n_25 = " Wallet Password ";
    }
    let i18n_27;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_ENTER_WALLET_PASSWORD$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_PAYMENT_DETAILS_HOME_PAYMENT_DETAILS_COMPONENT_TS__28 = goog.getMsg("Enter wallet password");
      i18n_27 = MSG_EXTERNAL_ENTER_WALLET_PASSWORD$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_PAYMENT_DETAILS_HOME_PAYMENT_DETAILS_COMPONENT_TS__28;
    } else {
      i18n_27 = "Enter wallet password";
    }
    let i18n_29;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_NEXT$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_PAYMENT_DETAILS_HOME_PAYMENT_DETAILS_COMPONENT_TS__30 = goog.getMsg(" Next ");
      i18n_29 = MSG_EXTERNAL_NEXT$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_PAYMENT_DETAILS_HOME_PAYMENT_DETAILS_COMPONENT_TS__30;
    } else {
      i18n_29 = " Next ";
    }
    let i18n_31;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_YOU_NEED_TO_VERIFY_THE_TRANSACTION_PASSWORD_OF_BEFORE_YOU_CAN_INITIATE_A_TRANSACTION$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_PAYMENT_DETAILS_HOME_PAYMENT_DETAILS_COMPONENT_TS__32 = goog.getMsg(" You need to verify the transaction password of {$interpolation} before you can initiate a transaction ", {
        "interpolation": "\uFFFD0\uFFFD"
      }, {
        original_code: {
          "interpolation": "{{ dataInfo.chain }}"
        }
      });
      i18n_31 = MSG_EXTERNAL_YOU_NEED_TO_VERIFY_THE_TRANSACTION_PASSWORD_OF_BEFORE_YOU_CAN_INITIATE_A_TRANSACTION$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_PAYMENT_DETAILS_HOME_PAYMENT_DETAILS_COMPONENT_TS__32;
    } else {
      i18n_31 = " You need to verify the transaction password of " + "\uFFFD0\uFFFD" + " before you can initiate a transaction ";
    }
    let i18n_33;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_NEXT$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_PAYMENT_DETAILS_HOME_PAYMENT_DETAILS_COMPONENT_TS__34 = goog.getMsg(" Next ");
      i18n_33 = MSG_EXTERNAL_NEXT$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_PAYMENT_DETAILS_HOME_PAYMENT_DETAILS_COMPONENT_TS__34;
    } else {
      i18n_33 = " Next ";
    }
    let i18n_36;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_FORGOT_PASSWORD_GO_TO_RESET$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_PAYMENT_DETAILS_HOME_PAYMENT_DETAILS_COMPONENT_TS__37 = goog.getMsg(" Forgot password, go to reset ");
      i18n_36 = MSG_EXTERNAL_FORGOT_PASSWORD_GO_TO_RESET$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_PAYMENT_DETAILS_HOME_PAYMENT_DETAILS_COMPONENT_TS__37;
    } else {
      i18n_36 = " Forgot password, go to reset ";
    }
    let i18n_38;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_CONFIRM$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_PAYMENT_DETAILS_HOME_PAYMENT_DETAILS_COMPONENT_TS__39 = goog.getMsg(" Confirm ");
      i18n_38 = MSG_EXTERNAL_CONFIRM$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_PAYMENT_DETAILS_HOME_PAYMENT_DETAILS_COMPONENT_TS__39;
    } else {
      i18n_38 = " Confirm ";
    }
    return [[3, "hideHeader", "contentSafeArea", "contentClass"], [3, "ngSwitch"], [4, "ngSwitchCase"], ["footer", "", 3, "ngSwitch"], [4, "ngIf"], [1, "grid-areas-[nav_title_menu]", "grid", "h-11", "grid-cols-[0.2fr_1fr_0.2fr]", "items-center", "justify-between", "text-center"], ["name", "fail", 1, "grid-in-[nav]", "justify-self-start", "text-2xl", "font-semibold", 3, "click"], [1, "text-title", "grid-in-[title]", "text-sm", "font-semibold", "tracking-normal"], i18n_0, [1, "mb-3", "mt-6", "flex", "items-center", "justify-between", "text-sm"], [1, "text-subtext", "items-center", "font-normal", "tracking-normal"], i18n_2, [1, "text-title", "font-normal", "tracking-normal"], [1, "mb-3", "flex", "items-center", "justify-between", "text-sm"], i18n_4, i18n_6, [1, "mb-6", "flex", "items-center", "justify-between", "text-sm"], i18n_8, [1, "text-title", "mb-10", "pt-9", "text-center", "text-3xl", "font-black", "tracking-normal"], [1, "text-subtext", "text-base"], [1, "mb-3", "flex", "items-center", "justify-between"], [1, "text-subtext", "text-xss", "items-center", "font-normal", "tracking-normal"], i18n_11, [1, "text-title", "text-xss", "font-normal", "tracking-normal"], i18n_13, i18n_15, [1, "mb-6", "flex", "items-center", "justify-between"], i18n_17, i18n_19, ["name", "fail", "class", "grid-in-[nav] justify-self-start text-2xl font-semibold", 3, "click", 4, "ngIf"], ["name", "back", "class", "grid-in-[nav] justify-self-start text-2xl font-semibold", 3, "click", 4, "ngIf"], [1, "grid-in-[title]", "text-title", "text-sm", "font-semibold", "tracking-normal"], [1, "mb-6", 3, "formGroup", "ngSubmit"], [1, "flex", "h-10", "w-full", "items-end", "justify-between", "text-xs", "font-semibold"], [1, "flex-shrink-0", "pr-2"], i18n_21, ["class", "text-error text-right", 4, "ngIf"], [1, "bg-env", "mt-2", "flex", "h-10", "items-center", "rounded-lg", "px-2.5"], ["formControlName", "bioforestPassword", "placeholder", i18n_23, 1, "w-full", "border-none", "bg-transparent", "outline-none", 3, "type"], [1, "icon-5.5", "text-subtext", "ml-1.5", "flex-shrink-0", 3, "name", "click"], ["name", "back", 1, "grid-in-[nav]", "justify-self-start", "text-2xl", "font-semibold", 3, "click"], [1, "text-error", "text-right"], ["name", "fingerprint-pay", "class", "grid-in-[menu] mt-1 justify-self-end text-3xl font-semibold", 3, "click", 4, "ngIf"], [1, "flex-shrink-0", "pr-2", "text-xs", 3, "ngClass"], i18n_25, ["class", "text-red text-right", 4, "ngIf"], ["formControlName", "password", "placeholder", i18n_27, 1, "w-full", "border-none", "bg-transparent", "outline-none", 3, "type"], ["name", "fingerprint-pay", 1, "grid-in-[menu]", "mt-1", "justify-self-end", "text-3xl", "font-semibold", 3, "click"], [1, "text-red", "text-right"], ["class", "text-error text-xss font-normal", 4, "ngIf"], [1, "text-error", "text-xss", "font-normal"], ["bnRippleButton", "", 1, "h-10.5", "from-purple-gradient-start", "to-purple-gradient-end", "w-full", "rounded-full", "bg-gradient-to-b", "text-center", "text-sm", "text-white", 3, "click"], i18n_29, [1, "mb-5", "text-center"], [1, "text-subtext", "text-xss", "tracking-normal"], i18n_31, ["bnRippleButton", "", 1, "h-10.5", "from-purple-gradient-start", "to-purple-gradient-end", "w-full", "rounded-full", "bg-gradient-to-b", "text-center", "text-sm", "text-white", 3, "disabled", "ngClass", "click"], i18n_33, [1, "text-primary", "text-xss", "font-normal", "tracking-normal", 3, "click"], i18n_36, [1, "w-full", 3, "formGroup", "ngSubmit"], ["bnRippleButton", "", "type", "submit", 1, "h-10.5", "from-purple-gradient-start", "to-purple-gradient-end", "w-full", "rounded-full", "bg-gradient-to-b", "text-center", "text-white", 3, "disabled"], i18n_38];
  },
  template: function PaymentDetailsPage_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](0, "common-page", 0);
      _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementContainerStart"](1, 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵtemplate"](2, PaymentDetailsPage_ng_container_2_Template, 3, 2, "ng-container", 2)(3, PaymentDetailsPage_ng_container_3_Template, 16, 9, "ng-container", 2)(4, PaymentDetailsPage_ng_container_4_Template, 17, 11, "ng-container", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementContainerEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementContainerStart"](5, 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵtemplate"](6, PaymentDetailsPage_ng_container_6_Template, 3, 0, "ng-container", 2)(7, PaymentDetailsPage_ng_container_7_Template, 6, 5, "ng-container", 2)(8, PaymentDetailsPage_ng_container_8_Template, 7, 2, "ng-container", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementContainerEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵproperty"]("hideHeader", true)("contentSafeArea", true)("contentClass", "pt-5");
      _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵproperty"]("ngSwitch", ctx.pageType);
      _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵproperty"]("ngSwitchCase", "paymentDetails");
      _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵproperty"]("ngSwitchCase", "bioforestPassword");
      _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵproperty"]("ngSwitchCase", "walletPassword");
      _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵproperty"]("ngSwitch", ctx.pageType);
      _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵproperty"]("ngSwitchCase", "paymentDetails");
      _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵproperty"]("ngSwitchCase", "bioforestPassword");
      _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵproperty"]("ngSwitchCase", "walletPassword");
    }
  },
  dependencies: [_modules_page_module__WEBPACK_IMPORTED_MODULE_4__.CommonPageModule, _libs_bnf_components_ripple_button_ripple_button_directive__WEBPACK_IMPORTED_MODULE_10__.RippleButtonDirective, _libs_bnf_directives_auto_complete_off_directive__WEBPACK_IMPORTED_MODULE_11__.AutoCompleteOffDirective, _angular_common__WEBPACK_IMPORTED_MODULE_20__.NgClass, _angular_common__WEBPACK_IMPORTED_MODULE_20__.NgIf, _angular_common__WEBPACK_IMPORTED_MODULE_20__.NgSwitch, _angular_common__WEBPACK_IMPORTED_MODULE_20__.NgSwitchCase, _angular_forms__WEBPACK_IMPORTED_MODULE_19__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_19__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_19__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_19__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_19__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_19__.FormControlName, _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_12__.CommonPageComponent, _components_icon_icon_component__WEBPACK_IMPORTED_MODULE_13__.IconComponent, _libs_bnf_pipes_errors_errors_pipe__WEBPACK_IMPORTED_MODULE_14__.ErrorsPipe, _libs_bnf_pipes_number_format_number_format_pipe__WEBPACK_IMPORTED_MODULE_15__.NumberFormatPipe, _libs_bnf_pipes_address_hidden_address_hidden_pipe__WEBPACK_IMPORTED_MODULE_16__.AddressHiddenPipe, _libs_bnf_pipes_amountFixed_amount_fixed_pipe__WEBPACK_IMPORTED_MODULE_17__.AmountFixedPipe],
  styles: ["/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsInNvdXJjZVJvb3QiOiIifQ== */"],
  changeDetection: 0
});
(0,tslib__WEBPACK_IMPORTED_MODULE_21__.__decorate)([PaymentDetailsPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_21__.__metadata)("design:type", Object)], PaymentDetailsPage.prototype, "hasOpenFingerprintPay", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_21__.__decorate)([PaymentDetailsPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_21__.__metadata)("design:type", Object)], PaymentDetailsPage.prototype, "dataInfo", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_21__.__decorate)([PaymentDetailsPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_21__.__metadata)("design:type", Object)], PaymentDetailsPage.prototype, "pageType", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_21__.__decorate)([PaymentDetailsPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_21__.__metadata)("design:type", Object)], PaymentDetailsPage.prototype, "pageTitle", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_21__.__decorate)([PaymentDetailsPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_21__.__metadata)("design:type", Object)], PaymentDetailsPage.prototype, "bioforestPasswordPublicKeyList", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_21__.__decorate)([PaymentDetailsPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_21__.__metadata)("design:type", Object)], PaymentDetailsPage.prototype, "walletInfo_password", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_21__.__decorate)([PaymentDetailsPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_21__.__metadata)("design:type", Object)], PaymentDetailsPage.prototype, "bioforestPassword", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_21__.__decorate)([PaymentDetailsPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_21__.__metadata)("design:type", Object)], PaymentDetailsPage.prototype, "password", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_21__.__decorate)([PaymentDetailsPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_21__.__metadata)("design:type", Object)], PaymentDetailsPage.prototype, "inputContentShow", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_21__.__decorate)([PaymentDetailsPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_21__.__metadata)("design:type", Object)], PaymentDetailsPage.prototype, "form", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_21__.__decorate)([PaymentDetailsPage.OnReady(), (0,tslib__WEBPACK_IMPORTED_MODULE_21__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_21__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_21__.__metadata)("design:returntype", Promise)], PaymentDetailsPage.prototype, "walletInfo", null);
(0,tslib__WEBPACK_IMPORTED_MODULE_21__.__decorate)([PaymentDetailsPage.OnInit(), (0,tslib__WEBPACK_IMPORTED_MODULE_21__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_21__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_21__.__metadata)("design:returntype", Promise)], PaymentDetailsPage.prototype, "statusChange", null);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (PaymentDetailsPage);

/***/ })

}]);
//# sourceMappingURL=default-apps_wallet_src_pages_home_pages_home-payment-details_home-payment-details_component_ts.js.map