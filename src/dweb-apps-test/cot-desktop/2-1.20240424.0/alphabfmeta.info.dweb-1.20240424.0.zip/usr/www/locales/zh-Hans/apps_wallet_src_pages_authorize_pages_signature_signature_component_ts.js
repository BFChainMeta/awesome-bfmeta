"use strict";
(self["webpackChunkwallet"] = self["webpackChunkwallet"] || []).push([["apps_wallet_src_pages_authorize_pages_signature_signature_component_ts"],{

/***/ 78819:
/*!********************************************************************************!*\
  !*** ./apps/wallet/src/pages/authorize/pages/signature/signature.component.ts ***!
  \********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   WalletAuthorizeSignaturePage: () => (/* binding */ WalletAuthorizeSignaturePage),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 52542);
/* harmony import */ var D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncIterator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/esm/asyncIterator.js */ 9243);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! tslib */ 90505);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! @angular/core */ 61039);
/* harmony import */ var _bnqkl_framework_environments__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @bnqkl/framework/environments */ 47015);
/* harmony import */ var _bnqkl_framework_helpers__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @bnqkl/framework/helpers */ 12169);
/* harmony import */ var _bnqkl_framework_pipes__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @bnqkl/framework/pipes */ 80909);
/* harmony import */ var _bnqkl_framework_plugins__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @bnqkl/framework/plugins */ 43990);
/* harmony import */ var _bnqkl_util_web_extends_promise__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @bnqkl/util-web/extends-promise */ 87778);
/* harmony import */ var _bnqkl_wallet_base_services_plaoc__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @bnqkl/wallet-base/services/plaoc */ 63878);
/* harmony import */ var _bnqkl_wallet_base_services_wallet_chain__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @bnqkl/wallet-base/services/wallet/chain */ 27434);
/* harmony import */ var _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @bnqkl/wallet-base/services/wallet/chain-base */ 27187);
/* harmony import */ var _bnqkl_wallet_base_services_wallet_wallet_data_storage__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @bnqkl/wallet-base/services/wallet/wallet-data-storage */ 63024);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! rxjs */ 19177);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! rxjs */ 14115);
/* harmony import */ var _modules_page_module__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ~modules/page.module */ 77538);
/* harmony import */ var _pages_home_pages_home_payment_details_home_payment_details_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ~pages/home/pages/home-payment-details/home-payment-details.component */ 38093);
/* harmony import */ var _libs_bnf_modules_bottom_sheet_components_bottom_sheet_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../../../../../../../libs/bnf/modules/bottom-sheet/components/bottom-sheet.component */ 94072);
/* harmony import */ var _libs_bnf_components_ripple_button_ripple_button_directive__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../../../../../../../libs/bnf/components/ripple-button/ripple-button.directive */ 16505);
/* harmony import */ var _libs_bnf_directives_tab_directive__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ../../../../../../../libs/bnf/directives/tab.directive */ 384);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! @angular/common */ 6729);
/* harmony import */ var _libs_bnf_modules_dialog_components_template_dialog_opener_template_dialog_opener_component__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ../../../../../../../libs/bnf/modules/dialog/components/template-dialog-opener/template-dialog-opener.component */ 57628);
/* harmony import */ var _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ../../../../../../../libs/bnf/modules/page/common-page/common-page.component */ 62052);
/* harmony import */ var _components_icon_icon_component__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ../../../../components/icon/icon.component */ 74703);
/* harmony import */ var _libs_bnf_components_loading_wrapper_loading_wrapper_component__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ../../../../../../../libs/bnf/components/loading-wrapper/loading-wrapper.component */ 51263);
/* harmony import */ var _pipes_color_color_pipe__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ../../../../pipes/color/color.pipe */ 76489);


var _class;
























const _c4 = a0 => ({
  "--color-1": a0
});
function WalletAuthorizeSignaturePage_div_9_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](0, "div", 18)(1, "div", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelement"](2, "w-icon", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵpipe"](3, "color");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](4, "div", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵi18n"](5, 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵpureFunction1"](4, _c4, _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵpipeBind1"](3, 2, "error")));
  }
}
const _c9 = a0 => ({
  item: a0
});
function WalletAuthorizeSignaturePage_div_10_ng_container_14_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementContainer"](1, 32);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const item_r16 = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵnextContext"]();
    const _r7 = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵreference"](17);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngTemplateOutlet", _r7)("ngTemplateOutletContext", _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵpureFunction1"](2, _c9, item_r16));
  }
}
function WalletAuthorizeSignaturePage_div_10_ng_container_15_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementContainer"](1, 32);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const item_r16 = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵnextContext"]();
    const _r7 = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵreference"](17);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngTemplateOutlet", _r7)("ngTemplateOutletContext", _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵpureFunction1"](2, _c9, item_r16));
  }
}
function WalletAuthorizeSignaturePage_div_10_ng_container_16_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementContainer"](1, 32);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const item_r16 = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵnextContext"]();
    const _r9 = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵreference"](19);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngTemplateOutlet", _r9)("ngTemplateOutletContext", _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵpureFunction1"](2, _c9, item_r16));
  }
}
function WalletAuthorizeSignaturePage_div_10_ng_container_17_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementContainer"](1, 32);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const item_r16 = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵnextContext"]();
    const _r11 = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵreference"](21);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngTemplateOutlet", _r11)("ngTemplateOutletContext", _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵpureFunction1"](2, _c9, item_r16));
  }
}
function WalletAuthorizeSignaturePage_div_10_ng_container_18_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementContainer"](1, 32);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const item_r16 = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵnextContext"]();
    const _r13 = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵreference"](23);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngTemplateOutlet", _r13)("ngTemplateOutletContext", _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵpureFunction1"](2, _c9, item_r16));
  }
}
function WalletAuthorizeSignaturePage_div_10_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](0, "div", 23)(1, "div", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](3, "div", 25)(4, "div", 26);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵi18n"](5, 27);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](6, "div", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](7);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](8, "div", 25)(9, "div", 26);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵi18n"](10, 29);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](11, "div", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](12);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementContainerStart"](13, 30);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtemplate"](14, WalletAuthorizeSignaturePage_div_10_ng_container_14_Template, 2, 4, "ng-container", 31)(15, WalletAuthorizeSignaturePage_div_10_ng_container_15_Template, 2, 4, "ng-container", 31)(16, WalletAuthorizeSignaturePage_div_10_ng_container_16_Template, 2, 4, "ng-container", 31)(17, WalletAuthorizeSignaturePage_div_10_ng_container_17_Template, 2, 4, "ng-container", 31)(18, WalletAuthorizeSignaturePage_div_10_ng_container_18_Template, 2, 4, "ng-container", 31);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementContainerEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const item_r16 = ctx.$implicit;
    const i_r17 = ctx.index;
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtextInterpolate"](ctx_r1.signatureRequestTitleArray[i_r17]);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtextInterpolate"](item_r16.chainName);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtextInterpolate"](ctx_r1.getSignatureType(item_r16));
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngSwitch", item_r16.type);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngSwitchCase", ctx_r1.WALLET_SIGNATURE_TYPE.message);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngSwitchCase", ctx_r1.WALLET_SIGNATURE_TYPE.json);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngSwitchCase", ctx_r1.WALLET_SIGNATURE_TYPE.transfer);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngSwitchCase", ctx_r1.WALLET_SIGNATURE_TYPE.bioforestChainCertificateTransfer);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngSwitchCase", ctx_r1.WALLET_SIGNATURE_TYPE.ENTITY);
  }
}
function WalletAuthorizeSignaturePage_Conditional_12_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelement"](0, "bn-loading-wrapper", 33);
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("loadingTheme", "ellipsis")("showLoading", true);
  }
}
function WalletAuthorizeSignaturePage_Conditional_13_ng_container_0_Template(rf, ctx) {
  if (rf & 1) {
    const _r32 = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](1, "bn-loading-wrapper", 36)(2, "div", 37)(3, "button", 38);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵlistener"]("click", function WalletAuthorizeSignaturePage_Conditional_13_ng_container_0_Template_button_click_3_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵrestoreView"](_r32);
      const ctx_r31 = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵresetView"](ctx_r31.back());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵi18n"](4, 39);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](5, "button", 40);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵlistener"]("click", function WalletAuthorizeSignaturePage_Conditional_13_ng_container_0_Template_button_click_5_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵrestoreView"](_r32);
      const ctx_r33 = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵresetView"](ctx_r33.authorize());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵi18n"](6, 41);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const ctx_r28 = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("loadingTheme", "ellipsis")("contentWidthFull", true)("waitFor", ctx_r28.authorize.running);
  }
}
function WalletAuthorizeSignaturePage_Conditional_13_ng_template_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r35 = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](0, "button", 42);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵlistener"]("click", function WalletAuthorizeSignaturePage_Conditional_13_ng_template_1_Template_button_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵrestoreView"](_r35);
      const ctx_r34 = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵresetView"](ctx_r34.back());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵi18n"](1, 43);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
  }
}
function WalletAuthorizeSignaturePage_Conditional_13_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtemplate"](0, WalletAuthorizeSignaturePage_Conditional_13_ng_container_0_Template, 7, 3, "ng-container", 34)(1, WalletAuthorizeSignaturePage_Conditional_13_ng_template_1_Template, 2, 0, "ng-template", null, 35, _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtemplateRefExtractor"]);
  }
  if (rf & 2) {
    const _r30 = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵreference"](2);
    const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngIf", !ctx_r3.notImportAddress)("ngIfElse", _r30);
  }
}
function WalletAuthorizeSignaturePage_ng_template_14_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](0, "span", 44);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵi18n"](1, 45);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
  }
}
function WalletAuthorizeSignaturePage_ng_template_16_ng_container_5_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementContainer"](0, 49);
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵnextContext"](2);
    const _r5 = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵreference"](15);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngTemplateOutlet", _r5);
  }
}
function WalletAuthorizeSignaturePage_ng_template_16_div_6_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](0, "div", 25)(1, "div", 26);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵi18n"](2, 50);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](3, "div", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const item_r36 = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵnextContext"]().item;
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtextInterpolate"](item_r36.message);
  }
}
function WalletAuthorizeSignaturePage_ng_template_16_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](0, "div", 25)(1, "div", 26);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵi18n"](2, 46);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](3, "div", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtemplate"](5, WalletAuthorizeSignaturePage_ng_template_16_ng_container_5_Template, 1, 1, "ng-container", 47);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtemplate"](6, WalletAuthorizeSignaturePage_ng_template_16_div_6_Template, 5, 1, "div", 48);
  }
  if (rf & 2) {
    const item_r36 = ctx.item;
    const ctx_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtextInterpolate1"](" ", item_r36.senderAddress, "");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngIf", !!ctx_r6.appName && ctx_r6.checkAddressHasNotImport(item_r36.chainName));
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngIf", item_r36.type === ctx_r6.WALLET_SIGNATURE_TYPE.message);
  }
}
function WalletAuthorizeSignaturePage_ng_template_18_ng_container_5_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementContainer"](0, 49);
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵnextContext"](2);
    const _r5 = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵreference"](15);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngTemplateOutlet", _r5);
  }
}
function WalletAuthorizeSignaturePage_ng_template_18_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](0, "div", 25)(1, "div", 26);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵi18n"](2, 51);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](3, "div", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtemplate"](5, WalletAuthorizeSignaturePage_ng_template_18_ng_container_5_Template, 1, 1, "ng-container", 47);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](6, "div", 25)(7, "div", 26);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵi18n"](8, 52);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](9, "div", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](10);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](11, "div", 25)(12, "div", 26);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵi18n"](13, 53);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](14, "div", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](15);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](16, "div", 25)(17, "div", 26);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵi18n"](18, 54);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](19, "div", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](20);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const item_r40 = ctx.item;
    const ctx_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtextInterpolate1"](" ", item_r40.senderAddress, "");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngIf", !!ctx_r8.appName && ctx_r8.checkAddressHasNotImport(item_r40.chainName));
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtextInterpolate"](item_r40.receiveAddress);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtextInterpolate"](ctx_r8.getTransferAmount(item_r40));
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtextInterpolate"](ctx_r8.getFee(item_r40));
  }
}
function WalletAuthorizeSignaturePage_ng_template_20_ng_container_5_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementContainer"](0, 49);
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵnextContext"](2);
    const _r5 = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵreference"](15);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngTemplateOutlet", _r5);
  }
}
function WalletAuthorizeSignaturePage_ng_template_20_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](0, "div", 25)(1, "div", 26);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵi18n"](2, 55);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](3, "div", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtemplate"](5, WalletAuthorizeSignaturePage_ng_template_20_ng_container_5_Template, 1, 1, "ng-container", 47);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](6, "div", 25)(7, "div", 26);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵi18n"](8, 56);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](9, "div", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](10);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](11, "div", 25)(12, "div", 26);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵi18n"](13, 57);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](14, "div", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](15);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](16, "div", 25)(17, "div", 26);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵi18n"](18, 58);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](19, "div", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](20);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const item_r42 = ctx.item;
    const ctx_r10 = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtextInterpolate1"](" ", item_r42.senderAddress, "");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngIf", !!ctx_r10.appName && ctx_r10.checkAddressHasNotImport(item_r42.chainName));
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtextInterpolate"](item_r42.receiveAddress);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtextInterpolate"](item_r42.certificate);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtextInterpolate"](ctx_r10.getFee(item_r42));
  }
}
function WalletAuthorizeSignaturePage_ng_template_22_ng_container_5_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementContainer"](0, 49);
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵnextContext"](2);
    const _r5 = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵreference"](15);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngTemplateOutlet", _r5);
  }
}
function WalletAuthorizeSignaturePage_ng_template_22_div_6_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](0, "div", 25)(1, "div", 26);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵi18n"](2, 63);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](3, "div", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const item_r44 = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵnextContext"]().item;
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtextInterpolate"](item_r44.receiveAddress);
  }
}
function WalletAuthorizeSignaturePage_ng_template_22_Template(rf, ctx) {
  if (rf & 1) {
    const _r49 = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](0, "div", 25)(1, "div", 26);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵi18n"](2, 59);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](3, "div", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtemplate"](5, WalletAuthorizeSignaturePage_ng_template_22_ng_container_5_Template, 1, 1, "ng-container", 47);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtemplate"](6, WalletAuthorizeSignaturePage_ng_template_22_div_6_Template, 5, 1, "div", 48);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](7, "div", 25)(8, "div", 26);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵi18n"](9, 60);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](10, "div", 61);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵlistener"]("click", function WalletAuthorizeSignaturePage_ng_template_22_Template_div_click_10_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵrestoreView"](_r49);
      const item_r44 = restoredCtx.item;
      const ctx_r48 = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵresetView"]((item_r44.details[0] == null ? null : item_r44.details[0].imgLink) && ctx_r48.showEntityImgs(item_r44.details));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](11);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](12, "div", 25)(13, "div", 26);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵi18n"](14, 62);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](15, "div", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](16);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const item_r44 = ctx.item;
    const ctx_r12 = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtextInterpolate1"](" ", item_r44.senderAddress, "");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngIf", !!ctx_r12.appName && ctx_r12.checkAddressHasNotImport(item_r44.chainName));
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngIf", !!item_r44.receiveAddress);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngClass", (item_r44.details[0] == null ? null : item_r44.details[0].imgLink) ? "text-primary" : "text-title");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtextInterpolate1"](" ", item_r44.details[0].content, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtextInterpolate"](ctx_r12.getFee(item_r44));
  }
}
function WalletAuthorizeSignaturePage_common_bottom_sheet_24_ng_template_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r53 = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](0, "w-home-payment-details-page", 65);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵlistener"]("returnValue$", function WalletAuthorizeSignaturePage_common_bottom_sheet_24_ng_template_1_Template_w_home_payment_details_page_returnValue__0_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵrestoreView"](_r53);
      const ctx_r52 = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵresetView"](ctx_r52.paymenDetailOutput$.next($event));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const data_r50 = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵnextContext"]().ngIf;
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("dataInfo", data_r50);
  }
}
function WalletAuthorizeSignaturePage_common_bottom_sheet_24_Template(rf, ctx) {
  if (rf & 1) {
    const _r56 = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](0, "common-bottom-sheet", 64);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵlistener"]("isOpenChange", function WalletAuthorizeSignaturePage_common_bottom_sheet_24_Template_common_bottom_sheet_isOpenChange_0_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵrestoreView"](_r56);
      const ctx_r55 = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵresetView"]($event || (ctx_r55.paymentDetailInput = undefined));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtemplate"](1, WalletAuthorizeSignaturePage_common_bottom_sheet_24_ng_template_1_Template, 1, 1, "ng-template");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("disableClose", true)("isOpen", true)("panelClass", "payment-details-sheet-panel");
  }
}
const _forTrack46 = ($index, $item) => $item.content;
function WalletAuthorizeSignaturePage_ng_template_26_For_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](0, "div", 71);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelement"](1, "img", 72);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const item_r60 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("src", item_r60.imgLink, _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵsanitizeUrl"]);
  }
}
function WalletAuthorizeSignaturePage_ng_template_26_w_icon_3_Template(rf, ctx) {
  if (rf & 1) {
    const _r66 = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](0, "w-icon", 73);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵlistener"]("click", function WalletAuthorizeSignaturePage_ng_template_26_w_icon_3_Template_w_icon_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵrestoreView"](_r66);
      const ctx_r65 = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵresetView"](ctx_r65.handleCurrActivityIndex(false));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
  }
}
function WalletAuthorizeSignaturePage_ng_template_26_w_icon_4_Template(rf, ctx) {
  if (rf & 1) {
    const _r68 = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](0, "w-icon", 74);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵlistener"]("click", function WalletAuthorizeSignaturePage_ng_template_26_w_icon_4_Template_w_icon_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵrestoreView"](_r68);
      const ctx_r67 = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵresetView"](ctx_r67.handleCurrActivityIndex(true));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
  }
}
function WalletAuthorizeSignaturePage_ng_template_26_Template(rf, ctx) {
  if (rf & 1) {
    const _r70 = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](0, "div", 66);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵlistener"]("selectedIndexChange$", function WalletAuthorizeSignaturePage_ng_template_26_Template_div_selectedIndexChange__0_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵrestoreView"](_r70);
      const ctx_r69 = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵresetView"](ctx_r69.selectPointActivity($event));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵrepeaterCreate"](1, WalletAuthorizeSignaturePage_ng_template_26_For_2_Template, 2, 1, "div", 75, _forTrack46);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtemplate"](3, WalletAuthorizeSignaturePage_ng_template_26_w_icon_3_Template, 1, 0, "w-icon", 67)(4, WalletAuthorizeSignaturePage_ng_template_26_w_icon_4_Template, 1, 0, "w-icon", 68);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](5, "button", 69);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵlistener"]("click", function WalletAuthorizeSignaturePage_ng_template_26_Template_button_click_5_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵrestoreView"](_r70);
      const ctx_r71 = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵresetView"](ctx_r71.dialog_EntityImgs.is_open = false);
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelement"](6, "w-icon", 70);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵpipe"](7, "color");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r15 = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("selectedIndex", ctx_r15.dialog_EntityImgs.currActivityIndex);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵrepeater"](ctx_r15.dialog_EntityImgs.imgs);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngIf", ctx_r15.dialog_EntityImgs.currActivityIndex > 0);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngIf", ctx_r15.dialog_EntityImgs.currActivityIndex < ctx_r15.dialog_EntityImgs.imgs.length - 1);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngStyle", _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵpureFunction1"](6, _c4, _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵpipeBind1"](7, 4, "white")));
  }
}
/**
 * 签名
 */
class WalletAuthorizeSignaturePage extends _modules_page_module__WEBPACK_IMPORTED_MODULE_11__.CommonPageBase {
  constructor() {
    var _this;
    /** 链服务 */
    super(...arguments);
    _this = this;
    this._chainV2Service = (0,_angular_core__WEBPACK_IMPORTED_MODULE_21__.inject)(_bnqkl_wallet_base_services_wallet_chain__WEBPACK_IMPORTED_MODULE_8__.ChainV2Service);
    /** 存储 */
    this._walletDataStorageV2Service = (0,_angular_core__WEBPACK_IMPORTED_MODULE_21__.inject)(_bnqkl_wallet_base_services_wallet_wallet_data_storage__WEBPACK_IMPORTED_MODULE_10__.WalletDataStorageV2Service);
    /** 环境配置 */
    this._environment = (0,_angular_core__WEBPACK_IMPORTED_MODULE_21__.inject)(_bnqkl_framework_environments__WEBPACK_IMPORTED_MODULE_2__.ENV_TOKEN);
    /** 支付面板的输出 */
    this.paymenDetailOutput$ = new rxjs__WEBPACK_IMPORTED_MODULE_22__.Subject();
    this.dialog_EntityImgs = {
      is_open: false,
      imgs: [],
      currActivityIndex: 0
    };
    /** 地址索引数组 */
    this.addressKeyList = [];
    /** 二次密码 */
    this.bioforestPasswordPublicKeyList = [];
    /** 签名类型 */
    this.WALLET_SIGNATURE_TYPE = _bnqkl_wallet_base_services_plaoc__WEBPACK_IMPORTED_MODULE_7__.$WALLET_SIGNATURE_TYPE;
    /** 请求标题序号 */
    this.signatureRequestTitleArray = ["\u8BF7\u6C42\u4E00", "\u8BF7\u6C42\u4E8C", "\u8BF7\u6C42\u4E09", "\u8BF7\u6C42\u56DB", "\u8BF7\u6C42\u4E94", "\u8BF7\u6C42\u516D", "\u8BF7\u6C42\u4E03", "\u8BF7\u6C42\u516B"];
    /**
     * 应用链接
     */
    this.appHome = '';
    /**
     * 应用名称
     */
    this.appName = '';
    /**
     * 应用图标
     */
    this.appLogo = '';
    /** 检查地址 */
    this.runCheckAddressImport = true;
    /** 检查手续费 */
    this.runCheckFee = true;
    /**
     * 句柄id
     */
    this._eventId = '';
    /**
     * 需要签名的内容
     */
    this.signatureDataArray = [];
    /** 转账数据的提交 */
    this.authorize = (0,_bnqkl_framework_helpers__WEBPACK_IMPORTED_MODULE_3__.$singleton)( /*#__PURE__*/(0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      /// 转账判断余额
      var _iteratorAbruptCompletion = false;
      var _didIteratorError = false;
      var _iteratorError;
      try {
        for (var _iterator = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncIterator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(_this.signatureDataArray), _step; _iteratorAbruptCompletion = !(_step = yield _iterator.next()).done; _iteratorAbruptCompletion = false) {
          const item = _step.value;
          {
            if (item.type === _bnqkl_wallet_base_services_plaoc__WEBPACK_IMPORTED_MODULE_7__.$WALLET_SIGNATURE_TYPE.transfer || item.type === _bnqkl_wallet_base_services_plaoc__WEBPACK_IMPORTED_MODULE_7__.$WALLET_SIGNATURE_TYPE.bioforestChainCertificateTransfer || item.type === _bnqkl_wallet_base_services_plaoc__WEBPACK_IMPORTED_MODULE_7__.$WALLET_SIGNATURE_TYPE.ENTITY) {
              if (_this._chainV2Service.isBioforestChainByChainName(item.chainName)) {
                /// 服务与信息
                const chainService = _this._chainV2Service.getChainService(item.chainName);
                let transferAssetType = chainService.config.assetType;
                let balance = '0';
                if (item.type === _bnqkl_wallet_base_services_plaoc__WEBPACK_IMPORTED_MODULE_7__.$WALLET_SIGNATURE_TYPE.transfer) {
                  transferAssetType = item.contractInfo ? item.contractInfo.assetType : item.assetType || chainService.config.assetType;
                  balance = item.balance;
                }
                const fee = _this.getFee(item, true);
                if (isNaN(+fee)) {
                  _bnqkl_framework_plugins__WEBPACK_IMPORTED_MODULE_5__.Toast.show("\u624B\u7EED\u8D39\u4E0D\u6B63\u786E");
                  return;
                }
                /// 地址余额
                const res = yield chainService.getAddressAssets(item.senderAddress);
                /// 判断地址余额
                const cehckeAddressBalance = () => {
                  if (res) {
                    var _assetTypeBalanceInfo;
                    const assetTypeBalanceInfo = res.assets[chainService.config.magic];
                    const addressBalance = ((_assetTypeBalanceInfo = assetTypeBalanceInfo[chainService.config.assetType]) === null || _assetTypeBalanceInfo === void 0 ? void 0 : _assetTypeBalanceInfo.assetNumber) || '0';
                    if (transferAssetType !== chainService.config.assetType) {
                      var _assetTypeBalanceInfo2;
                      /// 非主链 需要判断 手续费跟对应代币余额
                      if (BigInt(fee || '0') > BigInt(addressBalance)) {
                        return false;
                      }
                      if (BigInt(balance) > BigInt(((_assetTypeBalanceInfo2 = assetTypeBalanceInfo[transferAssetType]) === null || _assetTypeBalanceInfo2 === void 0 ? void 0 : _assetTypeBalanceInfo2.assetNumber) || '0')) {
                        return false;
                      }
                      return true;
                    } else {
                      /// 主链直接 数量 + 手续费
                      const useBalance_BI = BigInt(fee || '0') + BigInt(balance);
                      if (useBalance_BI > BigInt(addressBalance)) {
                        return false;
                      }
                      return true;
                    }
                  }
                  return false;
                };
                if (cehckeAddressBalance() === false) {
                  _bnqkl_framework_plugins__WEBPACK_IMPORTED_MODULE_5__.Toast.show("\u4F59\u989D\u4E0D\u8DB3\uFF0C\u65E0\u6CD5\u53D1\u8D77\u4E8B\u4EF6");
                  return;
                }
              }
            }
          }
        }
        /// 校验密码
      } catch (err) {
        _didIteratorError = true;
        _iteratorError = err;
      } finally {
        try {
          if (_iteratorAbruptCompletion && _iterator.return != null) {
            yield _iterator.return();
          }
        } finally {
          if (_didIteratorError) {
            throw _iteratorError;
          }
        }
      }
      const addressInfo = yield _this._walletDataStorageV2Service.getChainAddressInfo(_this.addressKeyList[0].addressKey);
      const password = yield _this._walletDataStorageV2Service.walletAppSettings.password;
      _this.paymentDetailInput = {
        status: _pages_home_pages_home_payment_details_home_payment_details_component__WEBPACK_IMPORTED_MODULE_12__.PAYMENT_DETAILS_PAGE_STATUS.InputPassword,
        chain: addressInfo.chain,
        /** 密码 */
        password,
        /** 助记词 */
        mnemonic: addressInfo.mnemonic,
        /** 发送地址 */
        senderAddress: addressInfo.address,
        /** 生物链林交易密码 */
        bioforestPasswordPublicKey: _this.bioforestPasswordPublicKeyList
      };
      try {
        const data = yield (0,rxjs__WEBPACK_IMPORTED_MODULE_23__.firstValueFrom)(_this.paymenDetailOutput$);
        if (data === false) {
          return;
        }
        const res = [];
        /// 开始解析数据
        for (let i = 0; i < _this.signatureDataArray.length; i++) {
          const item = _this.signatureDataArray[i];
          const paysecretInfo = data.find(dataItem => item.chainName === dataItem.chain) || {
            chain: item.chainName
          };
          const chainInfo = _this._chainV2Service.getChainInfo(item.chainName);
          const chainApiService = chainInfo.service;
          if (item.type === _bnqkl_wallet_base_services_plaoc__WEBPACK_IMPORTED_MODULE_7__.$WALLET_SIGNATURE_TYPE.message || item.type === _bnqkl_wallet_base_services_plaoc__WEBPACK_IMPORTED_MODULE_7__.$WALLET_SIGNATURE_TYPE.json) {
            /// json签名
            if (item.type === _bnqkl_wallet_base_services_plaoc__WEBPACK_IMPORTED_MODULE_7__.$WALLET_SIGNATURE_TYPE.json && item.jsonInterpolation) {
              /// 看下是否需要插值
              try {
                item.jsonInterpolation.forEach(info => {
                  const trsInfo = res[info.index];
                  if (trsInfo) {
                    const trs = typeof trsInfo === 'object' && 'transaction' in trsInfo ? trsInfo.transaction : trsInfo;
                    const keys = info.path.split('.');
                    /// 未定义字段补充并插值
                    keys.reduce((pre, cur, i) => {
                      var _pre$cur;
                      const value = i === keys.length - 1 ? trs : pre[cur] || {};
                      return (_pre$cur = pre[cur]) !== null && _pre$cur !== void 0 ? _pre$cur : pre[cur] = value;
                    }, item.json);
                  }
                });
              } catch (err) {
                _this.console.error('jsonInterpolation:', item);
                _this.console.error(err);
              }
            }
            const message = item.type === _bnqkl_wallet_base_services_plaoc__WEBPACK_IMPORTED_MODULE_7__.$WALLET_SIGNATURE_TYPE.message ? item.message : JSON.stringify(item.json);
            let signature = '';
            if (_this._chainV2Service.isBioforestChainByChainName(item.chainName)) {
              /// 内链用地址密码签
              signature = yield chainApiService.signMessage(message, addressInfo.mnemonic);
            } else {
              signature = yield chainApiService.signMessage(message, addressInfo.privateKey);
            }
            res.push(signature);
          } else if (item.type === _bnqkl_wallet_base_services_plaoc__WEBPACK_IMPORTED_MODULE_7__.$WALLET_SIGNATURE_TYPE.transfer) {
            var _item$ethereumGasInfo, _item$binanceGasInfo$, _item$binanceGasInfo, _item$binanceGasInfo2, _item$contractInfo;
            /// 转账
            const assetType = item.contractInfo ? item.contractInfo.assetType : item.assetType || chainInfo.symbol;
            const transactionInfo = yield chainApiService.createTransaction({
              usePaySecretV1: paysecretInfo.status === _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_9__.PAYSECERT_CHECK_RESULT.OLD_SUCCESS,
              paySecret: paysecretInfo.paysecret,
              mainSecret: addressInfo.mnemonic,
              fee: item.fee,
              privateKey: addressInfo.privateKey,
              sendAddress: item.senderAddress,
              receiveAddress: item.receiveAddress,
              assetType,
              /// 转余额精度不在createTransaction做，传入就是最小单位
              amount: item.balance,
              chainSymbol: chainInfo.symbol,
              maxPriorityFeePerGas: (_item$ethereumGasInfo = item.ethereumGasInfo) === null || _item$ethereumGasInfo === void 0 ? void 0 : _item$ethereumGasInfo.maxPriorityFeePerGas,
              gasLimit: +((_item$binanceGasInfo$ = (_item$binanceGasInfo = item.binanceGasInfo) === null || _item$binanceGasInfo === void 0 ? void 0 : _item$binanceGasInfo.gasLimit) !== null && _item$binanceGasInfo$ !== void 0 ? _item$binanceGasInfo$ : 0),
              gasPrice: (_item$binanceGasInfo2 = item.binanceGasInfo) === null || _item$binanceGasInfo2 === void 0 ? void 0 : _item$binanceGasInfo2.gasPrice,
              remark: item.remark,
              contractAddress: (_item$contractInfo = item.contractInfo) === null || _item$contractInfo === void 0 ? void 0 : _item$contractInfo.contractAddress,
              validityHeight: 30
            });
            res.push({
              txId: transactionInfo.txId,
              transaction: transactionInfo.transaction
            });
          } else if (item.type === _bnqkl_wallet_base_services_plaoc__WEBPACK_IMPORTED_MODULE_7__.$WALLET_SIGNATURE_TYPE.bioforestChainCertificateTransfer) {
            /// 凭证
            const bioforestChainService = chainApiService;
            const trsJson = yield bioforestChainService.createCertificateTransferTransaction({
              /** 手续费 */
              fee: item.fee,
              /** 附言：碳域、BFCHAIN的转账附言格式 */
              remark: item.remark,
              /** 是否使用安全密码V1版本 */
              usePaySecretV1: paysecretInfo.status === _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_9__.PAYSECERT_CHECK_RESULT.OLD_SUCCESS,
              /** 安全密码 */
              paySecret: paysecretInfo.paysecret,
              /** 主密码 */
              mainSecret: addressInfo.mnemonic,
              /** 接收地址 */
              receiveAddress: item.receiveAddress,
              /** 凭证 */
              certificate: item.certificate
            });
            res.push(trsJson);
          } else if (item.type === _bnqkl_wallet_base_services_plaoc__WEBPACK_IMPORTED_MODULE_7__.$WALLET_SIGNATURE_TYPE.ENTITY) {
            const _chainApiService = chainApiService;
            if (item.transactionType === _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_9__.BIOFOREST_CHAIN_TRANSACTION_TYPES_BASE.TO_EXCHANGE_ANY) {
              /// 这边需要对ID进行构造
              for (let i = 0; i < item.details.length; i++) {
                const info = item.details[i];
                const minFee = yield _chainApiService.getCreateToExchangeAnyTransactionMinFee(info.remark || {}, info.assetInfo);
                const transaction = yield _chainApiService.createToExchangeAnyTransaction({
                  mainSecret: addressInfo.mnemonic,
                  paySecret: paysecretInfo.paysecret,
                  usePaySecretV1: paysecretInfo.status === _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_9__.PAYSECERT_CHECK_RESULT.OLD_SUCCESS,
                  fee: minFee,
                  validityHeight: item.validityHeight
                }, info.remark || {}, info.assetInfo);
                res.push(transaction);
              }
            } else if (item.transactionType === _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_9__.BIOFOREST_CHAIN_TRANSACTION_TYPES_BASE.BE_EXCHANGE_ANY) {
              const transaction = yield _chainApiService.createBeExchangeAnyTransaction({
                mainSecret: addressInfo.mnemonic,
                paySecret: paysecretInfo.paysecret,
                usePaySecretV1: paysecretInfo.status === _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_9__.PAYSECERT_CHECK_RESULT.OLD_SUCCESS,
                recipientId: item.receiveAddress,
                fee: item.fee,
                validityHeight: item.validityHeight
              }, item.remark || {}, item.beExchangeInfo, item.toExchangeInfo);
              res.push(transaction);
            } else if (item.transactionType === _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_9__.BIOFOREST_CHAIN_TRANSACTION_TYPES_BASE.TO_EXCHANGE_ANY_MULTI) {
              const transaction = yield _chainApiService.createToExchangeAnyMultiTransaction({
                mainSecret: addressInfo.mnemonic,
                paySecret: paysecretInfo.paysecret,
                usePaySecretV1: paysecretInfo.status === _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_9__.PAYSECERT_CHECK_RESULT.OLD_SUCCESS,
                fee: item.fee,
                validityHeight: item.validityHeight
              }, item.remark || {}, item.toExchangeInfoList, item.beExchangeInfo);
              res.push(transaction);
            } else if (item.transactionType === _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_9__.BIOFOREST_CHAIN_TRANSACTION_TYPES_BASE.BE_EXCHANGE_ANY_MULTI) {
              const transaction = yield _chainApiService.createBeExchangeAnyMultiTransaction({
                mainSecret: addressInfo.mnemonic,
                paySecret: paysecretInfo.paysecret,
                usePaySecretV1: paysecretInfo.status === _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_9__.PAYSECERT_CHECK_RESULT.OLD_SUCCESS,
                recipientId: item.receiveAddress,
                transactionSignature: item.transactionSignature,
                fee: item.fee,
                validityHeight: item.validityHeight
              }, item.remark || {}, item.toExchangeInfoList, item.beExchangeInfo);
              res.push(transaction);
            } else if (item.transactionType === _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_9__.BIOFOREST_CHAIN_TRANSACTION_TYPES_BASE.ISSUE_ENTITY) {
              /// 这边需要对ID进行构造
              for (let i = 0; i < item.details.length; i++) {
                const info = item.details[i];
                const assetInfo = {
                  ...item.assetInfo,
                  entityId: `${item.assetInfo.entityFactory.factoryId}_${info.entityId}`
                };
                const minFee = yield _chainApiService.getCreateIssueEntityTransactionMinFee(item.receiveAddress, info.remark || {}, assetInfo);
                const transaction = yield _chainApiService.createIssueEntityTransactionJSON({
                  mainSecret: addressInfo.mnemonic,
                  paySecret: paysecretInfo.paysecret,
                  usePaySecretV1: paysecretInfo.status === _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_9__.PAYSECERT_CHECK_RESULT.OLD_SUCCESS,
                  recipientId: item.receiveAddress,
                  fee: minFee,
                  validityHeight: item.validityHeight
                }, info.remark || {}, assetInfo);
                res.push(transaction);
              }
            } else if (item.transactionType === _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_9__.BIOFOREST_CHAIN_TRANSACTION_TYPES_BASE.ISSUE_ENTITY_MULTI) {
              /// 这边需要对ID进行构造
              item.assetInfo.entityStructList.forEach(info => {
                if (info.entityId.startsWith('m_') === false) {
                  info.entityId = `m_${item.assetInfo.entityFactory.factoryId}_${info.entityId}`;
                }
              });
              const transaction = yield _chainApiService.createIssueEntityMultiTransactionJSON({
                mainSecret: addressInfo.mnemonic,
                paySecret: paysecretInfo.paysecret,
                usePaySecretV1: paysecretInfo.status === _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_9__.PAYSECERT_CHECK_RESULT.OLD_SUCCESS,
                recipientId: item.receiveAddress,
                fee: item.fee,
                validityHeight: item.validityHeight
              }, item.remark || {}, item.assetInfo);
              res.push(transaction);
            } else if (item.transactionType === _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_9__.BIOFOREST_CHAIN_TRANSACTION_TYPES_BASE.ISSUE_ENTITY_FACTORY_V1) {
              const transaction = yield _chainApiService.createIssueEntityFactoryTransactionJSON({
                mainSecret: addressInfo.mnemonic,
                paySecret: paysecretInfo.paysecret,
                usePaySecretV1: paysecretInfo.status === _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_9__.PAYSECERT_CHECK_RESULT.OLD_SUCCESS,
                recipientId: item.receiveAddress,
                fee: item.fee,
                validityHeight: item.validityHeight
              }, item.remark || {}, item.assetInfo);
              res.push(transaction);
            } else {
              _bnqkl_framework_plugins__WEBPACK_IMPORTED_MODULE_5__.Toast.show("\u672A\u77E5");
              return;
            }
          } else {
            res.push(null);
          }
        }
        const plaoc = _this.injectorForceGet(_bnqkl_wallet_base_services_plaoc__WEBPACK_IMPORTED_MODULE_7__.PlaocService);
        plaoc.respondWith(_this._eventId, _bnqkl_wallet_base_services_plaoc__WEBPACK_IMPORTED_MODULE_7__.$WALLET_PLAOC_PATH.signature, res);
        _bnqkl_framework_plugins__WEBPACK_IMPORTED_MODULE_5__.Toast.show("\u7B7E\u540D\u6210\u529F");
        yield (0,_bnqkl_util_web_extends_promise__WEBPACK_IMPORTED_MODULE_6__.sleep)(500);
        _this.nav.back();
      } catch (err) {
        _this.console.error(err);
        _bnqkl_framework_plugins__WEBPACK_IMPORTED_MODULE_5__.Toast.show("\u5931\u8D25");
      }
    }));
  }
  /** 滚动 */
  handleCurrActivityIndex(add) {
    const nextIndex = this.dialog_EntityImgs.currActivityIndex + 1 * (add ? 1 : -1);
    if (nextIndex >= 0 || nextIndex < this.dialog_EntityImgs.imgs.length) {
      this.dialog_EntityImgs.currActivityIndex = nextIndex;
    }
  }
  /** 当前激活的活动 */
  selectPointActivity(index) {
    this.dialog_EntityImgs.currActivityIndex = index;
  }
  /**
   * 显示同质化图片
   */
  showEntityImgs(imgs) {
    this.dialog_EntityImgs.imgs = imgs;
    this.dialog_EntityImgs.currActivityIndex = 0;
    this.dialog_EntityImgs.is_open = true;
    this.cdRef.detectChanges();
  }
  /** 没导入 */
  get notImportAddress() {
    let notImport = !this.addressKeyList.length;
    if (notImport === false) {
      notImport = !!this.addressKeyList.find(item => !item.addressKey);
    }
    return notImport;
  }
  /** 检查地址是否没导入 */
  checkAddressHasNotImport(chain) {
    let notImport = !this.addressKeyList.length;
    if (notImport === false) {
      notImport = !!this.addressKeyList.find(item => item.chain === chain && !item.addressKey);
    }
    return notImport;
  }
  // [
  //   {
  //     type: $WALLET_SIGNATURE_TYPE.message,
  //     chainName: CHAIN_NAME.PMChain,
  //     senderAddress: 'cLsp2SM6TvvjGySSyamWAY6YoGNPs4BCrs',
  //     message: 'string',
  //   },
  //   {
  //     type: $WALLET_SIGNATURE_TYPE.bioforestChainCertificateTransfer,
  //     chainName: CHAIN_NAME.PMChain,
  //     senderAddress: 'cLsp2SM6TvvjGySSyamWAY6YoGNPs4BCrs',
  //     receiveAddress: 'cBeExS9K6muQs7Vu14XMWTo7YvevapADF7',
  //     /** 凭证 */
  //     certificate: '178846:bingzheng0',
  //   },
  // ];
  /** 初始化获取传参 */
  init() {
    var _this2 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const resolveData = _this2.resolveData;
      const signatureData = _this2.signatureDataArray = resolveData.data.signatureData;
      _this2._eventId = resolveData.data.eventId;
      _this2.checkAddressImport();
      _this2.appName = resolveData.data.appName;
      _this2.appHome = resolveData.data.appHome;
      _this2.appLogo = resolveData.data.appLogo;
      try {
        const check_task = [];
        for (let i = 0; i < signatureData.length; i++) {
          const item = signatureData[i];
          if ((item === null || item === void 0 ? void 0 : item.type) === _bnqkl_wallet_base_services_plaoc__WEBPACK_IMPORTED_MODULE_7__.$WALLET_SIGNATURE_TYPE.transfer || (item === null || item === void 0 ? void 0 : item.type) === _bnqkl_wallet_base_services_plaoc__WEBPACK_IMPORTED_MODULE_7__.$WALLET_SIGNATURE_TYPE.bioforestChainCertificateTransfer) {
            check_task.push(_this2.verificationFee(item));
          } else if ((item === null || item === void 0 ? void 0 : item.type) === _bnqkl_wallet_base_services_plaoc__WEBPACK_IMPORTED_MODULE_7__.$WALLET_SIGNATURE_TYPE.ENTITY) {
            check_task.push(_this2.verificationEntityFee(item));
          }
        }
        yield Promise.all(check_task);
      } finally {
        _this2.runCheckFee = false;
      }
      _this2.cdRef.detectChanges();
    })();
  }
  /** 校验地址是否导入 */
  checkAddressImport() {
    var _this3 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      try {
        /// 正常来说 senderAddress都是相同的
        const allAddressList = yield _this3._walletDataStorageV2Service.getAllChainAddressInfoList();
        const savePK_Set = new Set();
        var _iteratorAbruptCompletion2 = false;
        var _didIteratorError2 = false;
        var _iteratorError2;
        try {
          for (var _iterator2 = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncIterator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(_this3.signatureDataArray), _step2; _iteratorAbruptCompletion2 = !(_step2 = yield _iterator2.next()).done; _iteratorAbruptCompletion2 = false) {
            const item = _step2.value;
            {
              /// 寻找是否导入
              var _iteratorAbruptCompletion3 = false;
              var _didIteratorError3 = false;
              var _iteratorError3;
              try {
                for (var _iterator3 = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncIterator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(allAddressList), _step3; _iteratorAbruptCompletion3 = !(_step3 = yield _iterator3.next()).done; _iteratorAbruptCompletion3 = false) {
                  const addressInfo = _step3.value;
                  {
                    if (item.chainName === addressInfo.chain) {
                      const equal = yield _this3._chainV2Service.isAddressEqual(item.chainName, item.senderAddress, addressInfo.address);
                      if (equal) {
                        _this3.addressKeyList.push({
                          chain: addressInfo.chain,
                          addressKey: addressInfo.addressKey
                        });
                        /// 有导入就继续查下是否有二次密码
                        /// 判断二次密码
                        if (_this3._chainV2Service.isBioforestChainByChainName(item.chainName)) {
                          var _yield$_this3$_chainV;
                          /// 查询下二次密码
                          const bioforestPasswordPublicKey = yield (_yield$_this3$_chainV = yield _this3._chainV2Service.getChainService(item.chainName).getAddressInfo(item.senderAddress)) === null || _yield$_this3$_chainV === void 0 ? void 0 : _yield$_this3$_chainV.secondPublicKey;
                          /// 避免重复push 且消息签名不需要二次密码
                          if (savePK_Set.has(addressInfo.chain) === false && (item.type === _bnqkl_wallet_base_services_plaoc__WEBPACK_IMPORTED_MODULE_7__.$WALLET_SIGNATURE_TYPE.transfer || item.type === _bnqkl_wallet_base_services_plaoc__WEBPACK_IMPORTED_MODULE_7__.$WALLET_SIGNATURE_TYPE.bioforestChainCertificateTransfer || item.type === _bnqkl_wallet_base_services_plaoc__WEBPACK_IMPORTED_MODULE_7__.$WALLET_SIGNATURE_TYPE.ENTITY)) {
                            savePK_Set.add(addressInfo.chain);
                            _this3.bioforestPasswordPublicKeyList.push({
                              chain: addressInfo.chain,
                              bioforestPasswordPublicKey
                            });
                          }
                        }
                        break;
                      }
                    }
                  }
                }
              } catch (err) {
                _didIteratorError3 = true;
                _iteratorError3 = err;
              } finally {
                try {
                  if (_iteratorAbruptCompletion3 && _iterator3.return != null) {
                    yield _iterator3.return();
                  }
                } finally {
                  if (_didIteratorError3) {
                    throw _iteratorError3;
                  }
                }
              }
            }
          }
        } catch (err) {
          _didIteratorError2 = true;
          _iteratorError2 = err;
        } finally {
          try {
            if (_iteratorAbruptCompletion2 && _iterator2.return != null) {
              yield _iterator2.return();
            }
          } finally {
            if (_didIteratorError2) {
              throw _iteratorError2;
            }
          }
        }
      } finally {
        _this3.runCheckAddressImport = false;
      }
      _this3.cdRef.detectChanges();
    })();
  }
  /** 校验手续费 */
  verificationFee(item) {
    var _this4 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const chainInfo = _this4._chainV2Service.getChainInfo(item.chainName);
      const chainService = chainInfo.service;
      if (_this4._chainV2Service.isBioforestChainByChainName(item.chainName) || 'certificate' in item) {
        /// 内链只需要判断fee
        if (item.fee) {
          return;
        }
        /// 不存在就去获取拿，并扩大点倍数
        const fee = yield chainService.getTransferTransactionMinFee();
        item.fee = String(Math.floor(+(BigInt(fee) * BigInt(6)).toString() * (0.288 + Math.random())));
        if (BigInt(item.fee) > BigInt(188000)) {
          /// 避免太大
          item.fee = String(Math.floor(188000 * (0.5 + Math.random())));
        }
        return;
      }
      /// 波场不用计算真实手续费，但需要展示数据，地址如果未激活需要支付1.1trx
      if (_bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_9__.CHAIN_NAME.Tron === item.chainName) {
        item.fee = '266000';
        if (item.contractInfo) {
          return item.fee = _this4._chainV2Service.getPrecisionInteger('10', chainInfo.decimals, '266000');
        }
        /// 判断下地址是否激活
        const tronAddressActive = yield chainService.isAddressActive(item.receiveAddress).catch(() => true);
        if (tronAddressActive === false) {
          item.fee = _this4._chainV2Service.getPrecisionInteger('1.1', chainInfo.decimals, '266000');
        }
        return;
      }
      /// eth
      if (_bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_9__.CHAIN_NAME.Ethereum === item.chainName) {
        if (item.ethereumGasInfo === undefined) {
          item.ethereumGasInfo = {
            maxPriorityFeePerGas: '1500000000'
          };
        }
        const {
          maxPriorityFeePerGas
        } = item.ethereumGasInfo;
        const ethereumService = chainService;
        const hasContract = !!item.contractInfo;
        /// 先设置默认gas跟gasPrice, 网络请求有延迟
        const gasLimit = hasContract ? '210000' : '21000';
        const gasPrice = _this4._environment.production ? 5000000000 : 10000000000;
        const multiples = [10, 15]; // 用正常速率
        item.fee = ((BigInt(gasPrice) * BigInt(3) / BigInt(2) + BigInt(maxPriorityFeePerGas) / BigInt(multiples[0]) * BigInt(multiples[1])) * BigInt(gasLimit)).toString();
        try {
          const gasInfo = yield ethereumService.getGasInfo();
          const newGasPrice = yield ethereumService.getGasPrice();
          /// 合約 還是 主幣 的手續費
          const newGasLimit = hasContract ? gasInfo.contractGas : gasInfo.generalGas;
          item.fee = ((BigInt(newGasPrice) * BigInt(2) + BigInt(maxPriorityFeePerGas) / BigInt(multiples[0]) * BigInt(multiples[1])) * BigInt(newGasLimit)).toString();
        } catch (error) {
          _this4.console.log(error);
        }
      }
      /// binance
      if (_bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_9__.CHAIN_NAME.Binance === item.chainName) {
        if (item.binanceGasInfo === undefined) {
          item.binanceGasInfo = {
            gasLimit: 0,
            gasPrice: 0
          };
        }
        const hasContract = !!item.contractInfo;
        const binanceService = chainService;
        item.binanceGasInfo.gasLimit = hasContract ? 210000 : 21000;
        item.binanceGasInfo.gasPrice = _this4._environment.production ? 5000000000 : 10000000000;
        const multiples = [10, 15]; // 用正常速率
        item.fee = (BigInt(item.binanceGasInfo.gasLimit) * BigInt(item.binanceGasInfo.gasPrice) / BigInt(multiples[0]) * BigInt(multiples[1])).toString();
        try {
          const gasInfo = yield binanceService.getGasInfo();
          item.binanceGasInfo.gasPrice = yield binanceService.getGasPrice();
          item.binanceGasInfo.gasLimit = hasContract ? gasInfo.contractGas : gasInfo.generalGas;
          item.fee = (BigInt(item.binanceGasInfo.gasLimit) * BigInt(item.binanceGasInfo.gasPrice) / BigInt(multiples[0]) * BigInt(multiples[1])).toString();
        } catch (error) {
          _this4.console.log(error);
        }
      }
    })();
  }
  /** 校验同质化手续费 */
  verificationEntityFee(item) {
    var _this5 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const chainInfo = _this5._chainV2Service.getChainInfo(item.chainName);
      const chainApiService = chainInfo.service;
      if (_this5._chainV2Service.isBioforestChainByChainName(item.chainName)) {
        /// 转账
        const _chainApiService = chainApiService;
        if (item.transactionType === _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_9__.BIOFOREST_CHAIN_TRANSACTION_TYPES_BASE.TO_EXCHANGE_ANY) {
          /// 这边需要对ID进行构造
          let fee_BI = BigInt(0);
          for (let i = 0; i < item.details.length; i++) {
            const info = item.details[i];
            const minFee = yield _chainApiService.getCreateToExchangeAnyTransactionMinFee(info.remark || {}, info.assetInfo);
            fee_BI = fee_BI + BigInt(minFee);
            item.fee = fee_BI.toString();
          }
        } else if (item.transactionType === _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_9__.BIOFOREST_CHAIN_TRANSACTION_TYPES_BASE.BE_EXCHANGE_ANY) {
          item.fee = yield _chainApiService.getCreateBeExchangeAnyTransactionMinFee(item.receiveAddress, item.remark || {}, item.beExchangeInfo, item.toExchangeInfo);
        } else if (item.transactionType === _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_9__.BIOFOREST_CHAIN_TRANSACTION_TYPES_BASE.TO_EXCHANGE_ANY_MULTI) {
          item.fee = yield _chainApiService.getCreateToExchangeAnyMultiTransactionMinFee(item.remark || {}, item.toExchangeInfoList, item.beExchangeInfo);
        } else if (item.transactionType === _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_9__.BIOFOREST_CHAIN_TRANSACTION_TYPES_BASE.BE_EXCHANGE_ANY_MULTI) {
          item.fee = yield _chainApiService.getCreateBeExchangeAnyMultiTransactionMinFee({
            recipientId: item.receiveAddress,
            transactionSignature: item.transactionSignature
          }, item.remark || {}, item.toExchangeInfoList, item.beExchangeInfo);
        } else if (item.transactionType === _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_9__.BIOFOREST_CHAIN_TRANSACTION_TYPES_BASE.ISSUE_ENTITY) {
          let fee_BI = BigInt(0);
          /// 这边需要对ID进行构造
          for (let i = 0; i < item.details.length; i++) {
            const info = item.details[i];
            const assetInfo = {
              ...item.assetInfo,
              entityId: `${item.assetInfo.entityFactory.factoryId}_${info.entityId}`
            };
            const minFee = yield _chainApiService.getCreateIssueEntityTransactionMinFee(item.receiveAddress, info.remark || {}, assetInfo);
            fee_BI = fee_BI + BigInt(minFee);
          }
          item.fee = fee_BI.toString();
        } else if (item.transactionType === _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_9__.BIOFOREST_CHAIN_TRANSACTION_TYPES_BASE.ISSUE_ENTITY_MULTI) {
          /// 这边需要对ID进行构造
          item.assetInfo.entityStructList.forEach(info => {
            if (info.entityId.startsWith('m_') === false) {
              info.entityId = `m_${item.assetInfo.entityFactory.factoryId}_${info.entityId}`;
            }
          });
          item.fee = yield _chainApiService.getCreateIssueEntityMultiTransactionMinFee(item.receiveAddress, item.remark || {}, item.assetInfo);
        } else if (item.transactionType === _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_9__.BIOFOREST_CHAIN_TRANSACTION_TYPES_BASE.ISSUE_ENTITY_FACTORY_V1) {
          item.fee = yield _chainApiService.getCreateIssueEntityFactoryTransactionMinFee(item.receiveAddress, item.remark || {}, item.assetInfo);
        } else {
          _bnqkl_framework_plugins__WEBPACK_IMPORTED_MODULE_5__.Toast.show("\u672A\u77E5");
          return;
        }
      }
      _this5.console.warn(`verificationEntityFee is use BioforestChainByChainName!`);
    })();
  }
  /** 移除缓存 */
  removeEvent() {
    const plaoc = this.injectorForceGet(_bnqkl_wallet_base_services_plaoc__WEBPACK_IMPORTED_MODULE_7__.PlaocService);
    plaoc.removeEventId(this._eventId);
  }
  /** 获取显示类型 */
  getSignatureType(item) {
    let text = "\u672A\u77E5";
    switch (item.type) {
      case _bnqkl_wallet_base_services_plaoc__WEBPACK_IMPORTED_MODULE_7__.$WALLET_SIGNATURE_TYPE.message:
      case _bnqkl_wallet_base_services_plaoc__WEBPACK_IMPORTED_MODULE_7__.$WALLET_SIGNATURE_TYPE.json:
        text = "\u7B7E\u540D\u4FE1\u606F";
        break;
      case _bnqkl_wallet_base_services_plaoc__WEBPACK_IMPORTED_MODULE_7__.$WALLET_SIGNATURE_TYPE.transfer:
        text = "\u53D1\u8D77\u8F6C\u8D26";
        break;
      case _bnqkl_wallet_base_services_plaoc__WEBPACK_IMPORTED_MODULE_7__.$WALLET_SIGNATURE_TYPE.bioforestChainCertificateTransfer:
        text = "\u8F6C\u8D26\u51ED\u8BC1";
        break;
      case _bnqkl_wallet_base_services_plaoc__WEBPACK_IMPORTED_MODULE_7__.$WALLET_SIGNATURE_TYPE.ENTITY:
        /// 细分
        if (item.transactionType === _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_9__.BIOFOREST_CHAIN_TRANSACTION_TYPES_BASE.TO_EXCHANGE_ANY) {
          text = "\u542F\u52A8\u4EA4\u6362";
        } else if (item.transactionType === _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_9__.BIOFOREST_CHAIN_TRANSACTION_TYPES_BASE.BE_EXCHANGE_ANY) {
          text = "\u63A5\u6536\u4EA4\u6362";
        } else if (item.transactionType === _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_9__.BIOFOREST_CHAIN_TRANSACTION_TYPES_BASE.TO_EXCHANGE_ANY_MULTI) {
          text = "\u542F\u52A8\u4EA4\u6362";
        } else if (item.transactionType === _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_9__.BIOFOREST_CHAIN_TRANSACTION_TYPES_BASE.BE_EXCHANGE_ANY_MULTI) {
          text = "\u63A5\u6536\u4EA4\u6362";
        } else if (item.transactionType === _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_9__.BIOFOREST_CHAIN_TRANSACTION_TYPES_BASE.ISSUE_ENTITY) {
          text = "\u521B\u5EFA\u540C\u8D28\u5316\u8D44\u4EA7";
        } else if (item.transactionType === _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_9__.BIOFOREST_CHAIN_TRANSACTION_TYPES_BASE.ISSUE_ENTITY_MULTI) {
          text = "\u521B\u5EFA\u540C\u8D28\u5316\u8D44\u4EA7";
        } else if (item.transactionType === _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_9__.BIOFOREST_CHAIN_TRANSACTION_TYPES_BASE.ISSUE_ENTITY_FACTORY_V1) {
          text = "\u521B\u5EFA\u540C\u8D28\u5316\u8D44\u4EA7\u6A21\u677F";
        } else {
          text = "\u540C\u8D28\u5316\u8F6C\u79FB";
        }
        break;
    }
    return text;
  }
  /** 获取转账金额 */
  getTransferAmount(item) {
    const chainInfo = this._chainV2Service.getChainInfo(item.chainName);
    let assetType = item.assetType || chainInfo.symbol;
    let decimals = chainInfo.decimals;
    if (item.contractInfo) {
      assetType = item.contractInfo.assetType;
      decimals = item.contractInfo.decimals;
    }
    return `${_bnqkl_framework_pipes__WEBPACK_IMPORTED_MODULE_4__.AmountFixedPipe.transform(item.balance, decimals, {
      removeZero: true
    })} ${assetType}`;
  }
  /** 获取手续费 */
  getFee(item, notUsePipe = false) {
    const {
      decimals,
      symbol
    } = this._chainV2Service.getChainInfo(item.chainName);
    if (item.fee) {
      /// 由于现在存在多创建交易，这边还需要判断是否有多个交易
      const fee = item.fee;
      if (notUsePipe) {
        return fee;
      }
      return `${_bnqkl_framework_pipes__WEBPACK_IMPORTED_MODULE_4__.AmountFixedPipe.transform(fee, decimals, {
        removeZero: true
      })} ${symbol}`;
    }
    return '------';
  }
  /** 返回 */
  back() {
    if (this.nav.canGoBack) {
      this.nav.back();
    } else {
      this.nav.setPageRoot('tabs');
    }
  }
}
_class = WalletAuthorizeSignaturePage;
_class.ɵfac = /*@__PURE__*/(() => {
  let ɵWalletAuthorizeSignaturePage_BaseFactory;
  return function WalletAuthorizeSignaturePage_Factory(t) {
    return (ɵWalletAuthorizeSignaturePage_BaseFactory || (ɵWalletAuthorizeSignaturePage_BaseFactory = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵgetInheritedFactory"](_class)))(t || _class);
  };
})();
_class.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵdefineComponent"]({
  type: _class,
  selectors: [["w-authorize-signature-page"]],
  standalone: true,
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵInheritDefinitionFeature"], _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵStandaloneFeature"]],
  decls: 27,
  vars: 16,
  consts: () => {
    let i18n_0;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_REQUEST_SIGNATURE$$APPS_WALLET_SRC_PAGES_AUTHORIZE_PAGES_SIGNATURE_SIGNATURE_COMPONENT_TS_1 = goog.getMsg("Request Signature");
      i18n_0 = MSG_EXTERNAL_REQUEST_SIGNATURE$$APPS_WALLET_SRC_PAGES_AUTHORIZE_PAGES_SIGNATURE_SIGNATURE_COMPONENT_TS_1;
    } else {
      i18n_0 = "\u8BF7\u6C42\u7B7E\u540D";
    }
    let i18n_2;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_IMPORT_THE_WALLET_OF_THE_ADDRESS_AND_THE_PERFORM_THE_SIGNING_OPERATION$$APPS_WALLET_SRC_PAGES_AUTHORIZE_PAGES_SIGNATURE_SIGNATURE_COMPONENT_TS__3 = goog.getMsg(" Import the wallet of the address and then perform the signing operation ");
      i18n_2 = MSG_EXTERNAL_IMPORT_THE_WALLET_OF_THE_ADDRESS_AND_THE_PERFORM_THE_SIGNING_OPERATION$$APPS_WALLET_SRC_PAGES_AUTHORIZE_PAGES_SIGNATURE_SIGNATURE_COMPONENT_TS__3;
    } else {
      i18n_2 = "\u8BF7\u5148\u5BFC\u5165\u5173\u8054\u94B1\u5305\u5730\u5740\uFF0C\u518D\u8FDB\u884C\u7B7E\u540D\u64CD\u4F5C";
    }
    let i18n_5;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_NETWORK$$APPS_WALLET_SRC_PAGES_AUTHORIZE_PAGES_SIGNATURE_SIGNATURE_COMPONENT_TS__6 = goog.getMsg("Network");
      i18n_5 = MSG_EXTERNAL_NETWORK$$APPS_WALLET_SRC_PAGES_AUTHORIZE_PAGES_SIGNATURE_SIGNATURE_COMPONENT_TS__6;
    } else {
      i18n_5 = "\u7F51\u7EDC";
    }
    let i18n_7;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_SIGNATURE_TYPE$$APPS_WALLET_SRC_PAGES_AUTHORIZE_PAGES_SIGNATURE_SIGNATURE_COMPONENT_TS__8 = goog.getMsg("Signature type");
      i18n_7 = MSG_EXTERNAL_SIGNATURE_TYPE$$APPS_WALLET_SRC_PAGES_AUTHORIZE_PAGES_SIGNATURE_SIGNATURE_COMPONENT_TS__8;
    } else {
      i18n_7 = "\u7B7E\u540D\u7C7B\u578B";
    }
    let i18n_10;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_REJECT$$APPS_WALLET_SRC_PAGES_AUTHORIZE_PAGES_SIGNATURE_SIGNATURE_COMPONENT_TS___11 = goog.getMsg(" Reject ");
      i18n_10 = MSG_EXTERNAL_REJECT$$APPS_WALLET_SRC_PAGES_AUTHORIZE_PAGES_SIGNATURE_SIGNATURE_COMPONENT_TS___11;
    } else {
      i18n_10 = "\u62D2\u7EDD";
    }
    let i18n_12;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_AUTHORIZE$$APPS_WALLET_SRC_PAGES_AUTHORIZE_PAGES_SIGNATURE_SIGNATURE_COMPONENT_TS___13 = goog.getMsg(" Authorize ");
      i18n_12 = MSG_EXTERNAL_AUTHORIZE$$APPS_WALLET_SRC_PAGES_AUTHORIZE_PAGES_SIGNATURE_SIGNATURE_COMPONENT_TS___13;
    } else {
      i18n_12 = "\u6388\u6743";
    }
    let i18n_14;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_CLOSE$$APPS_WALLET_SRC_PAGES_AUTHORIZE_PAGES_SIGNATURE_SIGNATURE_COMPONENT_TS___15 = goog.getMsg(" Close ");
      i18n_14 = MSG_EXTERNAL_CLOSE$$APPS_WALLET_SRC_PAGES_AUTHORIZE_PAGES_SIGNATURE_SIGNATURE_COMPONENT_TS___15;
    } else {
      i18n_14 = "\u6536\u76D8";
    }
    let i18n_16;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_NOT_IMPORTED$$APPS_WALLET_SRC_PAGES_AUTHORIZE_PAGES_SIGNATURE_SIGNATURE_COMPONENT_TS__17 = goog.getMsg("(Not imported)");
      i18n_16 = MSG_EXTERNAL_NOT_IMPORTED$$APPS_WALLET_SRC_PAGES_AUTHORIZE_PAGES_SIGNATURE_SIGNATURE_COMPONENT_TS__17;
    } else {
      i18n_16 = "\uFF08\u672A\u5BFC\u5165\uFF09";
    }
    let i18n_18;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_SIGNATURE_ADDRESS$$APPS_WALLET_SRC_PAGES_AUTHORIZE_PAGES_SIGNATURE_SIGNATURE_COMPONENT_TS__19 = goog.getMsg("Signature address");
      i18n_18 = MSG_EXTERNAL_SIGNATURE_ADDRESS$$APPS_WALLET_SRC_PAGES_AUTHORIZE_PAGES_SIGNATURE_SIGNATURE_COMPONENT_TS__19;
    } else {
      i18n_18 = "\u7B7E\u540D\u5730\u5740";
    }
    let i18n_20;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_MESSAGE$$APPS_WALLET_SRC_PAGES_AUTHORIZE_PAGES_SIGNATURE_SIGNATURE_COMPONENT_TS___21 = goog.getMsg("Message");
      i18n_20 = MSG_EXTERNAL_MESSAGE$$APPS_WALLET_SRC_PAGES_AUTHORIZE_PAGES_SIGNATURE_SIGNATURE_COMPONENT_TS___21;
    } else {
      i18n_20 = "\u4FE1\u606F";
    }
    let i18n_22;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_SENDING_ADDRESS$$APPS_WALLET_SRC_PAGES_AUTHORIZE_PAGES_SIGNATURE_SIGNATURE_COMPONENT_TS__23 = goog.getMsg("Sending address");
      i18n_22 = MSG_EXTERNAL_SENDING_ADDRESS$$APPS_WALLET_SRC_PAGES_AUTHORIZE_PAGES_SIGNATURE_SIGNATURE_COMPONENT_TS__23;
    } else {
      i18n_22 = "\u53D1\u9001\u5730\u5740";
    }
    let i18n_24;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_RECEIVE_ADDRESS$$APPS_WALLET_SRC_PAGES_AUTHORIZE_PAGES_SIGNATURE_SIGNATURE_COMPONENT_TS__25 = goog.getMsg("Receive address");
      i18n_24 = MSG_EXTERNAL_RECEIVE_ADDRESS$$APPS_WALLET_SRC_PAGES_AUTHORIZE_PAGES_SIGNATURE_SIGNATURE_COMPONENT_TS__25;
    } else {
      i18n_24 = "\u63A5\u6536\u5730\u5740";
    }
    let i18n_26;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_TRANSFER_AMOUNT$$APPS_WALLET_SRC_PAGES_AUTHORIZE_PAGES_SIGNATURE_SIGNATURE_COMPONENT_TS__27 = goog.getMsg("Transfer amount");
      i18n_26 = MSG_EXTERNAL_TRANSFER_AMOUNT$$APPS_WALLET_SRC_PAGES_AUTHORIZE_PAGES_SIGNATURE_SIGNATURE_COMPONENT_TS__27;
    } else {
      i18n_26 = "\u8F6C\u8D26\u91D1\u989D";
    }
    let i18n_28;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_MINER_FEE$$APPS_WALLET_SRC_PAGES_AUTHORIZE_PAGES_SIGNATURE_SIGNATURE_COMPONENT_TS__29 = goog.getMsg("Miner fee");
      i18n_28 = MSG_EXTERNAL_MINER_FEE$$APPS_WALLET_SRC_PAGES_AUTHORIZE_PAGES_SIGNATURE_SIGNATURE_COMPONENT_TS__29;
    } else {
      i18n_28 = "\u77FF\u5DE5\u8D39";
    }
    let i18n_30;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_SENDING_ADDRESS$$APPS_WALLET_SRC_PAGES_AUTHORIZE_PAGES_SIGNATURE_SIGNATURE_COMPONENT_TS__31 = goog.getMsg("Sending address");
      i18n_30 = MSG_EXTERNAL_SENDING_ADDRESS$$APPS_WALLET_SRC_PAGES_AUTHORIZE_PAGES_SIGNATURE_SIGNATURE_COMPONENT_TS__31;
    } else {
      i18n_30 = "\u53D1\u9001\u5730\u5740";
    }
    let i18n_32;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_RECEIVE_ADDRESS$$APPS_WALLET_SRC_PAGES_AUTHORIZE_PAGES_SIGNATURE_SIGNATURE_COMPONENT_TS__33 = goog.getMsg("Receive address");
      i18n_32 = MSG_EXTERNAL_RECEIVE_ADDRESS$$APPS_WALLET_SRC_PAGES_AUTHORIZE_PAGES_SIGNATURE_SIGNATURE_COMPONENT_TS__33;
    } else {
      i18n_32 = "\u63A5\u6536\u5730\u5740";
    }
    let i18n_34;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_CERTIFICATE$$APPS_WALLET_SRC_PAGES_AUTHORIZE_PAGES_SIGNATURE_SIGNATURE_COMPONENT_TS__35 = goog.getMsg("Certificate");
      i18n_34 = MSG_EXTERNAL_CERTIFICATE$$APPS_WALLET_SRC_PAGES_AUTHORIZE_PAGES_SIGNATURE_SIGNATURE_COMPONENT_TS__35;
    } else {
      i18n_34 = "\u8BA4\u8BC1";
    }
    let i18n_36;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_MINER_FEE$$APPS_WALLET_SRC_PAGES_AUTHORIZE_PAGES_SIGNATURE_SIGNATURE_COMPONENT_TS__37 = goog.getMsg("Miner fee");
      i18n_36 = MSG_EXTERNAL_MINER_FEE$$APPS_WALLET_SRC_PAGES_AUTHORIZE_PAGES_SIGNATURE_SIGNATURE_COMPONENT_TS__37;
    } else {
      i18n_36 = "\u77FF\u5DE5\u8D39";
    }
    let i18n_38;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_SENDING_ADDRESS$$APPS_WALLET_SRC_PAGES_AUTHORIZE_PAGES_SIGNATURE_SIGNATURE_COMPONENT_TS__39 = goog.getMsg("Sending address");
      i18n_38 = MSG_EXTERNAL_SENDING_ADDRESS$$APPS_WALLET_SRC_PAGES_AUTHORIZE_PAGES_SIGNATURE_SIGNATURE_COMPONENT_TS__39;
    } else {
      i18n_38 = "\u53D1\u9001\u5730\u5740";
    }
    let i18n_40;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_EVENT_CONTENT$$APPS_WALLET_SRC_PAGES_AUTHORIZE_PAGES_SIGNATURE_SIGNATURE_COMPONENT_TS__41 = goog.getMsg("Event Content");
      i18n_40 = MSG_EXTERNAL_EVENT_CONTENT$$APPS_WALLET_SRC_PAGES_AUTHORIZE_PAGES_SIGNATURE_SIGNATURE_COMPONENT_TS__41;
    } else {
      i18n_40 = "\u4E8B\u4EF6\u5185\u5BB9";
    }
    let i18n_42;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_MINER_FEE$$APPS_WALLET_SRC_PAGES_AUTHORIZE_PAGES_SIGNATURE_SIGNATURE_COMPONENT_TS__43 = goog.getMsg("Miner fee");
      i18n_42 = MSG_EXTERNAL_MINER_FEE$$APPS_WALLET_SRC_PAGES_AUTHORIZE_PAGES_SIGNATURE_SIGNATURE_COMPONENT_TS__43;
    } else {
      i18n_42 = "\u77FF\u5DE5\u8D39";
    }
    let i18n_44;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_RECEIVE_ADDRESS$$APPS_WALLET_SRC_PAGES_AUTHORIZE_PAGES_SIGNATURE_SIGNATURE_COMPONENT_TS___45 = goog.getMsg("Receive address");
      i18n_44 = MSG_EXTERNAL_RECEIVE_ADDRESS$$APPS_WALLET_SRC_PAGES_AUTHORIZE_PAGES_SIGNATURE_SIGNATURE_COMPONENT_TS___45;
    } else {
      i18n_44 = "\u63A5\u6536\u5730\u5740";
    }
    return [["headerTitle", i18n_0, 3, "footerTranslucent", "headerTranslucent", "contentSafeArea", "contentBackground", "footerBackground", "headerBackground", "titleColor"], [1, "text-title", "flex", "min-h-full", "flex-col", "items-center", "justify-start", "text-center"], [1, "mb-8"], [1, "h-17", "w-17", "mx-auto", "mt-4"], [1, "rounded-2", "h-full", "w-full", 3, "src"], [1, "text-title", "mt-2", "text-center", "text-base", "font-bold"], [1, "text-subtext", "text-xs"], ["class", "rounded-3 bg-env mb-6 flex w-full items-center justify-start px-3 py-3", 4, "ngIf"], ["class", "mb-6 w-full text-left text-sm", 4, "ngFor", "ngForOf"], ["footer", "", 1, "my-3", "w-full"], ["class", "text-primary", 3, "loadingTheme", "showLoading"], ["notImported", ""], ["messageView", ""], ["transferView", ""], ["bioforestChainCertificateTransferView", ""], ["entityView", ""], [3, "disableClose", "isOpen", "panelClass", "isOpenChange", 4, "ngIf"], [3, "panelClass", "isOpen", "isOpenChange"], [1, "rounded-3", "bg-env", "mb-6", "flex", "w-full", "items-center", "justify-start", "px-3", "py-3"], [1, "flex", "flex-col"], ["name", "warn-grey", 1, "icon-5", "text-error"], [1, "ml-2", "text-left", "text-sm"], i18n_2, [1, "mb-6", "w-full", "text-left", "text-sm"], [1, "mb-2", "font-bold"], [1, "rounded-3", "bg-env", "mb-2", "flex", "w-full", "items-start", "justify-between", "px-3", "py-3"], [1, "text-subtext", "mr-2", "shrink-0"], i18n_5, [1, "text-title", "break-all", "text-right"], i18n_7, [3, "ngSwitch"], [4, "ngSwitchCase"], [3, "ngTemplateOutlet", "ngTemplateOutletContext"], [1, "text-primary", 3, "loadingTheme", "showLoading"], [4, "ngIf", "ngIfElse"], ["exitBtn", ""], [1, "text-title", 3, "loadingTheme", "contentWidthFull", "waitFor"], [1, "flex", "w-full", "items-center", "justify-between"], ["bnRippleButton", "", 1, "border-tiny", "h-10.5", "text-title", "border-primary", "w-[46.86%]", "rounded-full", "text-center", 3, "click"], i18n_10, ["bnRippleButton", "", 1, "from-purple-gradient-start", "to-purple-gradient-end", "h-10.5", "w-[46.86%]", "rounded-full", "bg-gradient-to-b", "text-center", "text-white", 3, "click"], i18n_12, ["bnRippleButton", "", 1, "h-10.5", "from-purple-gradient-start", "to-purple-gradient-end", "w-full", "rounded-full", "bg-gradient-to-b", "text-center", "text-white", 3, "click"], i18n_14, [1, "text-error", "ml-2", "whitespace-nowrap"], i18n_16, i18n_18, [3, "ngTemplateOutlet", 4, "ngIf"], ["class", "rounded-3 bg-env mb-2 flex w-full items-start justify-between px-3 py-3", 4, "ngIf"], [3, "ngTemplateOutlet"], i18n_20, i18n_22, i18n_24, i18n_26, i18n_28, i18n_30, i18n_32, i18n_34, i18n_36, i18n_38, i18n_40, [1, "overflow-hidden", "text-ellipsis", "whitespace-nowrap", "break-all", "text-right", 3, "ngClass", "click"], i18n_42, i18n_44, [3, "disableClose", "isOpen", "panelClass", "isOpenChange"], [3, "dataInfo", "returnValue$"], ["wTabGroup", "", 1, "no-scrollbar", "relative", "z-[1]", "grid", "h-full", "w-full", "flex-grow", "grid-flow-col", "overflow-x-scroll", 3, "selectedIndex", "selectedIndexChange$"], ["name", "back", "class", "icon-5 text-primary absolute left-2 top-0 z-10", 3, "click", 4, "ngIf"], ["name", "back", "class", "icon-5 text-primary absolute right-2 top-0 z-10 rotate-180", 3, "click", 4, "ngIf"], [1, "absolute", "-bottom-10", "left-1/2", "-translate-x-1/2", 3, "click"], ["name", "trade-failed", 1, "icon-5", 3, "ngStyle"], ["wTab", "", 1, "_slide-item", "w-cqw-100", "relative", "flex", "h-full", "flex-col", "items-center", "justify-start", "overflow-hidden", "p-10"], [1, "h-full", "w-full", 3, "src"], ["name", "back", 1, "icon-5", "text-primary", "absolute", "left-2", "top-0", "z-10", 3, "click"], ["name", "back", 1, "icon-5", "text-primary", "absolute", "right-2", "top-0", "z-10", "rotate-180", 3, "click"], ["class", "_slide-item w-cqw-100 relative flex h-full flex-col items-center justify-start overflow-hidden p-10", "wTab", ""]];
  },
  template: function WalletAuthorizeSignaturePage_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](0, "common-page", 0)(1, "div", 1)(2, "div", 2)(3, "div", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelement"](4, "img", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](5, "div", 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](6);
      _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](7, "div", 6);
      _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](8);
      _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtemplate"](9, WalletAuthorizeSignaturePage_div_9_Template, 6, 6, "div", 7)(10, WalletAuthorizeSignaturePage_div_10_Template, 19, 9, "div", 8);
      _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](11, "div", 9);
      _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtemplate"](12, WalletAuthorizeSignaturePage_Conditional_12_Template, 1, 2, "bn-loading-wrapper", 10)(13, WalletAuthorizeSignaturePage_Conditional_13_Template, 3, 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtemplate"](14, WalletAuthorizeSignaturePage_ng_template_14_Template, 2, 0, "ng-template", null, 11, _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtemplateRefExtractor"])(16, WalletAuthorizeSignaturePage_ng_template_16_Template, 7, 3, "ng-template", null, 12, _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtemplateRefExtractor"])(18, WalletAuthorizeSignaturePage_ng_template_18_Template, 21, 5, "ng-template", null, 13, _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtemplateRefExtractor"])(20, WalletAuthorizeSignaturePage_ng_template_20_Template, 21, 5, "ng-template", null, 14, _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtemplateRefExtractor"])(22, WalletAuthorizeSignaturePage_ng_template_22_Template, 17, 6, "ng-template", null, 15, _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtemplateRefExtractor"])(24, WalletAuthorizeSignaturePage_common_bottom_sheet_24_Template, 2, 3, "common-bottom-sheet", 16);
      _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](25, "common-template-dialog-opener", 17);
      _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵlistener"]("isOpenChange", function WalletAuthorizeSignaturePage_Template_common_template_dialog_opener_isOpenChange_25_listener($event) {
        return ctx.dialog_EntityImgs.is_open = $event;
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtemplate"](26, WalletAuthorizeSignaturePage_ng_template_26_Template, 8, 8, "ng-template");
      _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("footerTranslucent", false)("headerTranslucent", false)("contentSafeArea", true)("contentBackground", "white")("footerBackground", "white")("headerBackground", "transparent")("titleColor", "title");
      _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](4);
      _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("src", ctx.appLogo, _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵsanitizeUrl"]);
      _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtextInterpolate"](ctx.appName);
      _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtextInterpolate"](ctx.appHome);
      _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngIf", !!ctx.appName && ctx.notImportAddress);
      _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngForOf", ctx.signatureDataArray);
      _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵconditional"](12, ctx.runCheckAddressImport || ctx.runCheckFee ? 12 : 13);
      _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](12);
      _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngIf", ctx.paymentDetailInput);
      _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("panelClass", "--overflow-y-display")("isOpen", ctx.dialog_EntityImgs.is_open);
    }
  },
  dependencies: [_modules_page_module__WEBPACK_IMPORTED_MODULE_11__.CommonPageModule, _libs_bnf_modules_bottom_sheet_components_bottom_sheet_component__WEBPACK_IMPORTED_MODULE_13__.BottomSheetComponent, _libs_bnf_components_ripple_button_ripple_button_directive__WEBPACK_IMPORTED_MODULE_14__.RippleButtonDirective, _libs_bnf_directives_tab_directive__WEBPACK_IMPORTED_MODULE_15__.TabGroupDirective, _libs_bnf_directives_tab_directive__WEBPACK_IMPORTED_MODULE_15__.TabDirective, _angular_common__WEBPACK_IMPORTED_MODULE_24__.NgClass, _angular_common__WEBPACK_IMPORTED_MODULE_24__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_24__.NgIf, _angular_common__WEBPACK_IMPORTED_MODULE_24__.NgTemplateOutlet, _angular_common__WEBPACK_IMPORTED_MODULE_24__.NgStyle, _angular_common__WEBPACK_IMPORTED_MODULE_24__.NgSwitch, _angular_common__WEBPACK_IMPORTED_MODULE_24__.NgSwitchCase, _libs_bnf_modules_dialog_components_template_dialog_opener_template_dialog_opener_component__WEBPACK_IMPORTED_MODULE_16__.TemplateDialogOpenerComponent, _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_17__.CommonPageComponent, _components_icon_icon_component__WEBPACK_IMPORTED_MODULE_18__.IconComponent, _libs_bnf_components_loading_wrapper_loading_wrapper_component__WEBPACK_IMPORTED_MODULE_19__.LoadingWrapperComponent, _pipes_color_color_pipe__WEBPACK_IMPORTED_MODULE_20__.ColorPipe, _pages_home_pages_home_payment_details_home_payment_details_component__WEBPACK_IMPORTED_MODULE_12__.PaymentDetailsPage],
  styles: ["[_nghost-%COMP%]   ._bg[_ngcontent-%COMP%] {\n  position: absolute;\n  left: 0rem;\n  top: 0rem;\n  height: 18rem;\n  width: auto;\n  --tw-bg-opacity: 1;\n  background-color: rgb(146 103 254 / var(--tw-bg-opacity));\n  object-fit: cover;\n  z-index: -1\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL2FwcHMvd2FsbGV0L3NyYy9wYWdlcy9hdXRob3JpemUvcGFnZXMvc2lnbmF0dXJlL3NpZ25hdHVyZS5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFFSTtFQUFBLGtCQUFBO0VBQUEsVUFBQTtFQUFBLFNBQUE7RUFBQSxhQUFBO0VBQUEsV0FBQTtFQUFBLGtCQUFBO0VBQUEseURBQUE7RUFBQSxpQkFBQTtFQUNBO0FBREEiLCJzb3VyY2VzQ29udGVudCI6WyI6aG9zdCB7XHJcbiAgLl9iZyB7XHJcbiAgICBAYXBwbHkgYmctcHJpbWFyeSBhYnNvbHV0ZSBsZWZ0LTAgdG9wLTAgaC03MiB3LWF1dG8gb2JqZWN0LWNvdmVyO1xyXG4gICAgei1pbmRleDogLTE7XHJcbiAgfVxyXG59XHJcbiJdLCJzb3VyY2VSb290IjoiIn0= */"],
  changeDetection: 0
});
(0,tslib__WEBPACK_IMPORTED_MODULE_25__.__decorate)([WalletAuthorizeSignaturePage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_25__.__metadata)("design:type", Object)], WalletAuthorizeSignaturePage.prototype, "paymentDetailInput", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_25__.__decorate)([WalletAuthorizeSignaturePage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_25__.__metadata)("design:type", Object)], WalletAuthorizeSignaturePage.prototype, "paymenDetailOutput$", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_25__.__decorate)([WalletAuthorizeSignaturePage.States(), (0,tslib__WEBPACK_IMPORTED_MODULE_25__.__metadata)("design:type", Object)], WalletAuthorizeSignaturePage.prototype, "dialog_EntityImgs", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_25__.__decorate)([WalletAuthorizeSignaturePage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_25__.__metadata)("design:type", Object)], WalletAuthorizeSignaturePage.prototype, "addressKeyList", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_25__.__decorate)([WalletAuthorizeSignaturePage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_25__.__metadata)("design:type", Object)], WalletAuthorizeSignaturePage.prototype, "appHome", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_25__.__decorate)([WalletAuthorizeSignaturePage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_25__.__metadata)("design:type", Object)], WalletAuthorizeSignaturePage.prototype, "appName", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_25__.__decorate)([WalletAuthorizeSignaturePage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_25__.__metadata)("design:type", Object)], WalletAuthorizeSignaturePage.prototype, "appLogo", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_25__.__decorate)([WalletAuthorizeSignaturePage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_25__.__metadata)("design:type", Object)], WalletAuthorizeSignaturePage.prototype, "runCheckAddressImport", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_25__.__decorate)([WalletAuthorizeSignaturePage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_25__.__metadata)("design:type", Object)], WalletAuthorizeSignaturePage.prototype, "runCheckFee", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_25__.__decorate)([WalletAuthorizeSignaturePage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_25__.__metadata)("design:type", Array)], WalletAuthorizeSignaturePage.prototype, "signatureDataArray", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_25__.__decorate)([WalletAuthorizeSignaturePage.OnInit(), (0,tslib__WEBPACK_IMPORTED_MODULE_25__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_25__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_25__.__metadata)("design:returntype", Promise)], WalletAuthorizeSignaturePage.prototype, "init", null);
(0,tslib__WEBPACK_IMPORTED_MODULE_25__.__decorate)([WalletAuthorizeSignaturePage.OnDestroy(), (0,tslib__WEBPACK_IMPORTED_MODULE_25__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_25__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_25__.__metadata)("design:returntype", void 0)], WalletAuthorizeSignaturePage.prototype, "removeEvent", null);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (WalletAuthorizeSignaturePage);

/***/ })

}]);
//# sourceMappingURL=apps_wallet_src_pages_authorize_pages_signature_signature_component_ts.js.map