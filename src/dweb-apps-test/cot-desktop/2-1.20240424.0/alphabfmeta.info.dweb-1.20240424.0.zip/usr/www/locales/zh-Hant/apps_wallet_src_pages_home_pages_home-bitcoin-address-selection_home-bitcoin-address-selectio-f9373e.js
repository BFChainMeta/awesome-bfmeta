"use strict";
(self["webpackChunkwallet"] = self["webpackChunkwallet"] || []).push([["apps_wallet_src_pages_home_pages_home-bitcoin-address-selection_home-bitcoin-address-selectio-f9373e"],{

/***/ 16605:
/*!*********************************************************************************************************************!*\
  !*** ./apps/wallet/src/pages/home/pages/home-bitcoin-address-selection/home-bitcoin-address-selection.component.ts ***!
  \*********************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   HomeBitcoinAddressSelectionPage: () => (/* binding */ HomeBitcoinAddressSelectionPage),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 52542);
/* harmony import */ var D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncIterator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/esm/asyncIterator.js */ 9243);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! tslib */ 90505);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! @angular/core */ 61039);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! @angular/forms */ 7820);
/* harmony import */ var _bnqkl_framework_helpers__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @bnqkl/framework/helpers */ 12169);
/* harmony import */ var _bnqkl_framework_modules__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @bnqkl/framework/modules */ 96454);
/* harmony import */ var _bnqkl_framework_plugins__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @bnqkl/framework/plugins */ 43990);
/* harmony import */ var _bnqkl_util_web_extends_promise__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @bnqkl/util-web/extends-promise */ 87778);
/* harmony import */ var _bnqkl_wallet_base_services__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @bnqkl/wallet-base/services */ 62479);
/* harmony import */ var _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @bnqkl/wallet-base/services/wallet/chain-base */ 27187);
/* harmony import */ var _bnqkl_wallet_base_services_wallet_wallet_data_storage__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @bnqkl/wallet-base/services/wallet/wallet-data-storage */ 63024);
/* harmony import */ var _modules_page_module__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ~modules/page.module */ 77538);
/* harmony import */ var _services_permission_permission_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ~services/permission/permission.service */ 26502);
/* harmony import */ var _libs_bnf_modules_bottom_sheet_components_bottom_sheet_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../../../../../../libs/bnf/modules/bottom-sheet/components/bottom-sheet.component */ 94072);
/* harmony import */ var _libs_bnf_components_ripple_button_ripple_button_directive__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../../../../../../libs/bnf/components/ripple-button/ripple-button.directive */ 16505);
/* harmony import */ var _libs_bnf_directives_click_to_copy_directive__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../../../../../../../libs/bnf/directives/click-to-copy.directive */ 46413);
/* harmony import */ var _libs_bnf_directives_auto_complete_off_directive__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../../../../../../../libs/bnf/directives/auto-complete-off.directive */ 66722);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! @angular/common */ 6729);
/* harmony import */ var _libs_bnf_modules_dialog_components_common_card_common_card_component__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ../../../../../../../libs/bnf/modules/dialog/components/common-card/common-card.component */ 92686);
/* harmony import */ var _libs_bnf_modules_dialog_components_card_footer_confirm_confirm_footer_component__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ../../../../../../../libs/bnf/modules/dialog/components/card-footer-confirm/confirm-footer.component */ 42489);
/* harmony import */ var _libs_bnf_modules_dialog_components_template_dialog_opener_template_dialog_opener_component__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ../../../../../../../libs/bnf/modules/dialog/components/template-dialog-opener/template-dialog-opener.component */ 57628);
/* harmony import */ var _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ../../../../../../../libs/bnf/modules/page/common-page/common-page.component */ 62052);
/* harmony import */ var _components_icon_icon_component__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ../../../../components/icon/icon.component */ 74703);
/* harmony import */ var _pipes_color_color_pipe__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ../../../../pipes/color/color.pipe */ 76489);
/* harmony import */ var _libs_bnf_pipes_address_hidden_address_hidden_pipe__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! ../../../../../../../libs/bnf/pipes/address-hidden/address-hidden.pipe */ 35222);


var _class;


























const _c0 = ["card"];
function HomeBitcoinAddressSelectionPage_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r5 = _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](0, "button", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵlistener"]("click", function HomeBitcoinAddressSelectionPage_Conditional_1_Template_button_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵrestoreView"](_r5);
      const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵresetView"](ctx_r4.addAddress());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](1, "span", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵi18n"](2, 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]()();
  }
}
const _c5 = a0 => ({
  "--color-1": a0
});
function HomeBitcoinAddressSelectionPage_li_3_w_icon_3_Template(rf, ctx) {
  if (rf & 1) {
    const _r11 = _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](0, "w-icon", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵlistener"]("click", function HomeBitcoinAddressSelectionPage_li_3_w_icon_3_Template_w_icon_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵrestoreView"](_r11);
      const item_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵnextContext"]().$implicit;
      const ctx_r9 = _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵresetView"](ctx_r9.selectBitcoinAddress(item_r6.addressKey));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵpipe"](1, "color");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const item_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵnextContext"]().$implicit;
    const ctx_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngStyle", _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵpureFunction1"](3, _c5, (ctx_r8.activedAddress == null ? null : ctx_r8.activedAddress.address) === item_r6.address ? _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵpipeBind1"](1, 1, "primart") : "transparent"));
  }
}
function HomeBitcoinAddressSelectionPage_li_3_Template(rf, ctx) {
  if (rf & 1) {
    const _r14 = _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](0, "li")(1, "button", 8)(2, "div", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](3, HomeBitcoinAddressSelectionPage_li_3_w_icon_3_Template, 2, 5, "w-icon", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](4, "div", 11)(5, "div", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵi18n"](6, 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](7, "div", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](8);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵpipe"](9, "addressHidden");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](10, "button", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelement"](11, "w-icon", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]()()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](12, "button", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵlistener"]("click", function HomeBitcoinAddressSelectionPage_li_3_Template_button_click_12_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵrestoreView"](_r14);
      const item_r6 = restoredCtx.$implicit;
      const ctx_r13 = _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵresetView"](ctx_r13.showPrivateKey(item_r6));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelement"](13, "w-icon", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const item_r6 = ctx.$implicit;
    const i_r7 = ctx.index;
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngIf", ctx_r1.lookPrivateKey === false);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵi18nExp"](i_r7 + 1);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵi18nApply"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtextInterpolate3"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵpipeBind1"](9, 6, item_r6.address), " (m/", item_r6.purpose, "'/0'/0'/0/", item_r6.index, ") ");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("wClickToCopy", item_r6.address);
  }
}
function HomeBitcoinAddressSelectionPage_ng_template_5_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](0, "common-page", 20, 21)(2, "div", 22)(3, "div", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](5, "div", 24)(6, "button", 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵi18n"](7, 26);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("headerTitle", ctx_r2.privateKeyBottomSheetInfo.title);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtextInterpolate1"](" ", ctx_r2.privateKeyBottomSheetInfo.privateKey, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("wClickToCopy", ctx_r2.privateKeyBottomSheetInfo.privateKey);
  }
}
function HomeBitcoinAddressSelectionPage_ng_template_7_Template(rf, ctx) {
  if (rf & 1) {
    const _r18 = _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](0, "common-card", 27, 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵlistener"]("returnValue$", function HomeBitcoinAddressSelectionPage_ng_template_7_Template_common_card_returnValue__0_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵrestoreView"](_r18);
      const ctx_r17 = _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵresetView"](ctx_r17.confirmAddAddress($event));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](2, "div", 29)(3, "div", 30);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵi18n"](4, 31);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](5, "div", 32);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](6, " m/84'/0'/0'/0/ ");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelement"](7, "input", 33);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelement"](8, "common-confirm-footer", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](7);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("defaultValue", ctx_r3.indexInput.value)("formControl", ctx_r3.indexInput);
  }
}
/**
 * 添加钱包第一步页面
 * 选择一条链去做导入
 */
class HomeBitcoinAddressSelectionPage extends _modules_page_module__WEBPACK_IMPORTED_MODULE_9__.CommonPageBase {
  constructor() {
    super(...arguments);
    /** 传入的id, 由于数据是动态变化的，这里只用id就行  */
    this.mainWalletId = '';
    /** 是否只查看地址  */
    this.lookPrivateKey = false;
    this.walletDataStorageV2Service = (0,_angular_core__WEBPACK_IMPORTED_MODULE_22__.inject)(_bnqkl_wallet_base_services_wallet_wallet_data_storage__WEBPACK_IMPORTED_MODULE_8__.WalletDataStorageV2Service);
    /** 添加地址 对话框 控制器 */
    this.dialog_addBitcoinAddress = {
      is_open: false
    };
    /** 私钥显示器 */
    this.privateKeyBottomSheetInfo = {
      title: '',
      privateKey: '',
      open: false
    };
    /** 生物链林--输入的手续费 */
    this.indexInput = new _angular_forms__WEBPACK_IMPORTED_MODULE_23__.FormControl('', {
      nonNullable: true,
      validators: [control => {
        const value = +control.value;
        this.console.log(control.value, value);
        if (isNaN(value) === false) {
          if (String(value).includes('-')) {
            control.setValue(0);
          } else if (value < 0) {
            control.setValue(0);
          } else if (value > 9999) {
            control.setValue(9999);
          } else if (value > 0) {
            const valueStr = String(value);
            const pV = valueStr.split('.')[0] || '0';
            if (pV !== valueStr) {
              control.setValue(pV);
            }
          }
        }
        return null;
      }]
    });
    this.bitcoinAddressList = [];
  }
  /** 初始化 */
  init() {
    var _this = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      if ((0,_bnqkl_framework_helpers__WEBPACK_IMPORTED_MODULE_2__.$isNoEmptyString)(_this.mainWalletId) === false) {
        _this.console.error('not find mainWalletId');
        _this.nav.back();
        return;
      }
      const mainWallet = yield _this.walletDataStorageV2Service.getMainWalletInfo(_this.mainWalletId);
      if (mainWallet === undefined) {
        _this.console.error('not find mainWallet');
        _this.nav.back();
        return;
      }
      _this.activedAddress = mainWallet.addressKeyList.filter(item => item.chainName === _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_7__.CHAIN_NAME.Bitcoin).find(item => {
        if (mainWallet.lastBitcoinAddressKey) {
          return mainWallet.lastBitcoinAddressKey === item.addressKey;
        }
        return item.purpose === 84;
      });
      _this.bitcoinAddressList = mainWallet.addressKeyList.filter(item => {
        var _this$activedAddress2, _this$activedAddress3;
        if (_this.lookPrivateKey) {
          var _this$activedAddress;
          return item.chainName === ((_this$activedAddress = _this.activedAddress) === null || _this$activedAddress === void 0 ? void 0 : _this$activedAddress.chainName);
        }
        return item.chainName === ((_this$activedAddress2 = _this.activedAddress) === null || _this$activedAddress2 === void 0 ? void 0 : _this$activedAddress2.chainName) && item.purpose === ((_this$activedAddress3 = _this.activedAddress) === null || _this$activedAddress3 === void 0 ? void 0 : _this$activedAddress3.purpose);
      });
    })();
  }
  /** 选择地址 */
  selectBitcoinAddress(addressKey) {
    var _this2 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      var _this2$activedAddress;
      if (((_this2$activedAddress = _this2.activedAddress) === null || _this2$activedAddress === void 0 ? void 0 : _this2$activedAddress.addressKey) !== addressKey) {
        _this2.activedAddress = _this2.bitcoinAddressList.find(item => item.addressKey === addressKey);
        const mainWallet = yield _this2.walletDataStorageV2Service.getMainWalletInfo(_this2.mainWalletId);
        const lastBitcoinAddressKey = mainWallet.lastBitcoinAddressKey;
        /// 更新对应钱包的数据
        if (lastBitcoinAddressKey !== addressKey) {
          mainWallet.lastBitcoinAddressKey = addressKey;
          yield _this2.walletDataStorageV2Service.saveMainWalletInfo(mainWallet);
        }
        /// 需要判断当前激活的钱包是否需要替换
        const lastWalletActivate = _this2.walletDataStorageV2Service.walletAppSettings.lastWalletActivate;
        if ((lastWalletActivate === null || lastWalletActivate === void 0 ? void 0 : lastWalletActivate.mainWalletId) === _this2.mainWalletId && (lastWalletActivate === null || lastWalletActivate === void 0 ? void 0 : lastWalletActivate.addressKey) !== addressKey) {
          const walletV2Service = _this2.injectorForceGet(_bnqkl_wallet_base_services__WEBPACK_IMPORTED_MODULE_6__.WalletV2Service);
          _this2.walletDataStorageV2Service.walletAppSettings.lastWalletActivate = yield _this2.walletDataStorageV2Service.getChainAddressInfo(addressKey);
          yield walletV2Service.upDateActivateAddressWallet();
        }
      }
    })();
  }
  /** 添加地址 */
  addAddress() {
    var _this3 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      /// 判断要填入的index
      const indexList = _this3.bitcoinAddressList.map(item => item.index || 0).sort((a, b) => a - b);
      let inputIndexValue = indexList[indexList.length - 1] + 1;
      for (let i = 0; i < indexList.length - 1; i++) {
        const current = indexList[i];
        const next = indexList[i + 1];
        if (next - current > 1) {
          inputIndexValue = current + 1;
          break;
        }
      }
      _this3.dialog_addBitcoinAddress.is_open = true;
      yield (0,_bnqkl_util_web_extends_promise__WEBPACK_IMPORTED_MODULE_5__.sleep)(200);
      _this3.indexInput.setValue(String(inputIndexValue));
      if (_this3.indexInputCardComponent && _this3.indexInputCardComponent.eleRef) {
        var _this3$indexInputCard;
        const indexInput = (_this3$indexInputCard = _this3.indexInputCardComponent.eleRef) === null || _this3$indexInputCard === void 0 ? void 0 : _this3$indexInputCard.nativeElement.querySelector('input');
        indexInput && indexInput.focus();
      }
    })();
  }
  /** 添加地址逻辑 */
  confirmAddAddress(confirm) {
    var _this4 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      if (confirm) {
        const index = _this4.indexInput.value;
        const chainV2Service = _this4.injectorForceGet(_bnqkl_wallet_base_services__WEBPACK_IMPORTED_MODULE_6__.ChainV2Service);
        const metaBoxDataStorageService = _this4.injectorForceGet(_bnqkl_wallet_base_services__WEBPACK_IMPORTED_MODULE_6__.MetaBoxDataStorageService);
        const bitcoinInfo = chainV2Service.getChainInfo(_bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_7__.CHAIN_NAME.Bitcoin);
        const mainWallet = yield _this4.walletDataStorageV2Service.getMainWalletInfo(_this4.mainWalletId);
        /// 先生成本次地址数据
        const newAddressList = [];
        /// 构造存储结构
        const purposes = [44, 49, 84, 86];
        var _iteratorAbruptCompletion = false;
        var _didIteratorError = false;
        var _iteratorError;
        try {
          for (var _iterator = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncIterator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(purposes), _step; _iteratorAbruptCompletion = !(_step = yield _iterator.next()).done; _iteratorAbruptCompletion = false) {
            const purpose = _step.value;
            {
              const {
                address,
                privkey,
                pubkey
              } = yield chainV2Service.createAddressAndPrivkeyFromMnemonic(bitcoinInfo.chain, bitcoinInfo.coinId, mainWallet.importPhrase, +index, purpose);
              if (address && privkey) {
                const name = bitcoinInfo.symbol;
                const prohibitChangeName = false;
                const addressKey = `${bitcoinInfo.chain}-${address}`;
                /// 保存链地址数据
                const assets = [{
                  assetType: bitcoinInfo.symbol,
                  decimals: bitcoinInfo.decimals
                }];
                const addressInfo = {
                  mainWalletId: mainWallet.mainWalletId,
                  addressKey,
                  address,
                  mnemonic: mainWallet.importPhrase,
                  chain: bitcoinInfo.chain,
                  privateKey: privkey,
                  publicKey: pubkey,
                  assets,
                  /** 币种代号 */
                  symbol: bitcoinInfo.symbol,
                  /** 钱包名称 */
                  name,
                  /** 钱包名称是否禁止更改 */
                  prohibitChangeName,
                  index: +index,
                  purpose
                };
                newAddressList.push(addressInfo);
              }
            }
          }
          /// 生成好了，判断下是否有存在的地址（助剂词的）
        } catch (err) {
          _didIteratorError = true;
          _iteratorError = err;
        } finally {
          try {
            if (_iteratorAbruptCompletion && _iterator.return != null) {
              yield _iterator.return();
            }
          } finally {
            if (_didIteratorError) {
              throw _iteratorError;
            }
          }
        }
        const allMainWallet = yield _this4.walletDataStorageV2Service.getAllMainWalletInfo();
        const allMnemonicAddress = allMainWallet.filter(item => item.importType === _bnqkl_wallet_base_services_wallet_wallet_data_storage__WEBPACK_IMPORTED_MODULE_8__.WALLET_IMPORT_TYPE.mnemonic).map(item => item.addressKeyList).flat();
        const allMnemonicAddress_Set = new Set(allMnemonicAddress.map(item => item.address));
        const exist = newAddressList.find(item => allMnemonicAddress_Set.has(item.address));
        if (exist) {
          /// 已存在提升
          _bnqkl_framework_plugins__WEBPACK_IMPORTED_MODULE_4__.Toast.show("\u8A72\u5730\u5740\u5DF2\u5B58\u5728");
          return;
        }
        var _iteratorAbruptCompletion2 = false;
        var _didIteratorError2 = false;
        var _iteratorError2;
        try {
          for (var _iterator2 = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncIterator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(newAddressList), _step2; _iteratorAbruptCompletion2 = !(_step2 = yield _iterator2.next()).done; _iteratorAbruptCompletion2 = false) {
            const item = _step2.value;
            {
              yield _this4.walletDataStorageV2Service.saveChainAddressInfo(item.addressKey, item);
              mainWallet.addressKeyList.push({
                chainName: item.chain,
                address: item.address,
                addressKey: item.addressKey,
                symbol: item.symbol,
                mainWalletId: item.mainWalletId,
                index: +index,
                purpose: item.purpose
              });
              // 生成链授权信息
              if (bitcoinInfo) {
                const device = yield _bnqkl_framework_plugins__WEBPACK_IMPORTED_MODULE_4__.Device.uuid();
                const chainAuthInfo = yield bitcoinInfo.service.getChainAuthInfo(item.privateKey, device);
                // 追加本地链授权信息，但不需要马上去进行授权
                yield metaBoxDataStorageService.appendAuthorized(device, {
                  authInfos: [chainAuthInfo],
                  deviceId: device,
                  dirty: true
                });
              }
            }
          }
        } catch (err) {
          _didIteratorError2 = true;
          _iteratorError2 = err;
        } finally {
          try {
            if (_iteratorAbruptCompletion2 && _iterator2.return != null) {
              yield _iterator2.return();
            }
          } finally {
            if (_didIteratorError2) {
              throw _iteratorError2;
            }
          }
        }
        yield _this4.walletDataStorageV2Service.saveMainWalletInfo(mainWallet);
      }
      _this4.indexInput.setValue('');
      _this4.init();
    })();
  }
  /** 显示私钥 */
  showPrivateKey(info) {
    var _this5 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      /// 校验密码
      const _permissionService = _this5.injectorForceGet(_services_permission_permission_service__WEBPACK_IMPORTED_MODULE_10__.PermissionService);
      const pwdInfo = yield _permissionService.requestPassword();
      if (pwdInfo === false || pwdInfo === null) {
        return;
      }
      _this5.privateKeyBottomSheetInfo.title = "\u79C1\u9470\uFF08" + info.chainName + "\uFF09";
      const addressInfo = yield _this5.walletDataStorageV2Service.getChainAddressInfo(info.addressKey);
      _this5.privateKeyBottomSheetInfo.privateKey = addressInfo.privateKey;
      _this5.privateKeyBottomSheetInfo.open = true;
    })();
  }
}
_class = HomeBitcoinAddressSelectionPage;
_class.ɵfac = /*@__PURE__*/(() => {
  let ɵHomeBitcoinAddressSelectionPage_BaseFactory;
  return function HomeBitcoinAddressSelectionPage_Factory(t) {
    return (ɵHomeBitcoinAddressSelectionPage_BaseFactory || (ɵHomeBitcoinAddressSelectionPage_BaseFactory = _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵgetInheritedFactory"](_class)))(t || _class);
  };
})();
_class.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵdefineComponent"]({
  type: _class,
  selectors: [["w-home-bitcoin-address-selection-page"]],
  viewQuery: function HomeBitcoinAddressSelectionPage_Query(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵviewQuery"](_c0, 5);
    }
    if (rf & 2) {
      let _t;
      _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵloadQuery"]()) && (ctx.indexInputCardComponent = _t.first);
    }
  },
  inputs: {
    mainWalletId: "mainWalletId",
    lookPrivateKey: ["lookPrivateKey", "lookPrivateKey", _angular_core__WEBPACK_IMPORTED_MODULE_22__.booleanAttribute]
  },
  standalone: true,
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵInputTransformsFeature"], _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵInheritDefinitionFeature"], _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵStandaloneFeature"]],
  decls: 8,
  vars: 9,
  consts: () => {
    let i18n_1;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_ADD$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_BITCOIN_ADDRESS_SELECTION_HOME_BITCOIN_ADDRESS_SELECTION_COMPONENT_TS__2 = goog.getMsg("Add");
      i18n_1 = MSG_EXTERNAL_ADD$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_BITCOIN_ADDRESS_SELECTION_HOME_BITCOIN_ADDRESS_SELECTION_COMPONENT_TS__2;
    } else {
      i18n_1 = "\u65B0\u589E";
    }
    let i18n_3;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_BITCOIN$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_BITCOIN_ADDRESS_SELECTION_HOME_BITCOIN_ADDRESS_SELECTION_COMPONENT_TS__4 = goog.getMsg("Bitcoin {$interpolation}", {
        "interpolation": "\uFFFD0\uFFFD"
      }, {
        original_code: {
          "interpolation": "{{ i + 1 }}"
        }
      });
      i18n_3 = MSG_EXTERNAL_BITCOIN$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_BITCOIN_ADDRESS_SELECTION_HOME_BITCOIN_ADDRESS_SELECTION_COMPONENT_TS__4;
    } else {
      i18n_3 = "Bitcoin " + "\uFFFD0\uFFFD" + "";
    }
    let i18n_6;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_COPY_PRIVATE_KEY$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_BITCOIN_ADDRESS_SELECTION_HOME_BITCOIN_ADDRESS_SELECTION_COMPONENT_TS__7 = goog.getMsg(" Copy Private key ");
      i18n_6 = MSG_EXTERNAL_COPY_PRIVATE_KEY$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_BITCOIN_ADDRESS_SELECTION_HOME_BITCOIN_ADDRESS_SELECTION_COMPONENT_TS__7;
    } else {
      i18n_6 = "\u8907\u88FD\u79C1\u9470";
    }
    let i18n_8;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_ADD_BITCOIN_ADDRESS$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_BITCOIN_ADDRESS_SELECTION_HOME_BITCOIN_ADDRESS_SELECTION_COMPONENT_TS__9 = goog.getMsg("Add Bitcoin address");
      i18n_8 = MSG_EXTERNAL_ADD_BITCOIN_ADDRESS$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_BITCOIN_ADDRESS_SELECTION_HOME_BITCOIN_ADDRESS_SELECTION_COMPONENT_TS__9;
    } else {
      i18n_8 = "\u6DFB\u52A0 Bitcoin \u5730\u5740";
    }
    let i18n_10;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_BIP39_INDEX$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_BITCOIN_ADDRESS_SELECTION_HOME_BITCOIN_ADDRESS_SELECTION_COMPONENT_TS__11 = goog.getMsg("Index");
      i18n_10 = MSG_EXTERNAL_BIP39_INDEX$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_BITCOIN_ADDRESS_SELECTION_HOME_BITCOIN_ADDRESS_SELECTION_COMPONENT_TS__11;
    } else {
      i18n_10 = "\u5E8F\u865F";
    }
    let i18n_12;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_NUMERIC$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_BITCOIN_ADDRESS_SELECTION_HOME_BITCOIN_ADDRESS_SELECTION_COMPONENT_TS__13 = goog.getMsg("numeric");
      i18n_12 = MSG_EXTERNAL_NUMERIC$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_BITCOIN_ADDRESS_SELECTION_HOME_BITCOIN_ADDRESS_SELECTION_COMPONENT_TS__13;
    } else {
      i18n_12 = "numeric";
    }
    return [[3, "titleColor", "headerBackground", "contentBackground", "contentSafeArea"], ["endMenu", "", "bnRippleButton", ""], [1, "w-full", "bg-white", "px-5"], [4, "ngFor", "ngForOf", "ngForTrackBy"], [3, "isOpen", "isOpenChange"], ["endMenu", "", "bnRippleButton", "", 3, "click"], [1, "text-primary"], i18n_1, [1, "border-b-tiny", "border-line", "flex", "w-full", "items-center", "justify-between", "py-4", "pl-2"], [1, "flex", "items-center", "justify-start"], ["name", "language-selected-1", "class", "border-tiny border-subtext mr-2 mt-[2px] rounded-[4px] p-[2px]", 3, "ngStyle", "click", 4, "ngIf"], [1, "flex", "flex-col", "items-start", "justify-start"], [1, "font-bold"], i18n_3, [1, "text-subtext", "flex", "text-xs"], ["bnRippleButton", "", 1, "ml-2", "flex", "items-center", "justify-start", 3, "wClickToCopy"], ["name", "copy", 1, "icon-4"], ["bnRippleButton", "", 1, "flex", "items-center", "justify-start", "rounded-full", 3, "click"], ["name", "bitcoin-key", 1, "icon-5"], ["name", "language-selected-1", 1, "border-tiny", "border-subtext", "mr-2", "mt-[2px]", "rounded-[4px]", "p-[2px]", 3, "ngStyle", "click"], [3, "headerTitle"], ["page", ""], [1, "mb-28", "p-5"], [1, "rounded-3", "bg-env", "w-full", "break-words", "px-4", "py-7"], ["footer", ""], ["bnRippleButton", "", 1, "h-10.5", "from-purple-gradient-start", "to-purple-gradient-end", "w-full", "rounded-full", "bg-gradient-to-b", "text-center", "text-sm", "text-white", 3, "wClickToCopy"], i18n_6, ["headerTitle", i18n_8, 1, "overflow-hidden", 3, "returnValue$"], ["card", "card"], [1, "flex", "items-center", "justify-center"], [1, "mr-3"], i18n_10, [1, "bg-env", "text-subtext", "flex", "w-[78%]", "items-center", "justify-center", "rounded-lg", "p-2.5"], ["type", "number", "inputmode", i18n_12, 1, "font-num", "text-primary", "w-[68px]", "bg-transparent", 3, "defaultValue", "formControl"]];
  },
  template: function HomeBitcoinAddressSelectionPage_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](0, "common-page", 0);
      _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](1, HomeBitcoinAddressSelectionPage_Conditional_1_Template, 3, 0, "button", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](2, "ul", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](3, HomeBitcoinAddressSelectionPage_li_3_Template, 14, 8, "li", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](4, "common-bottom-sheet", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵlistener"]("isOpenChange", function HomeBitcoinAddressSelectionPage_Template_common_bottom_sheet_isOpenChange_4_listener($event) {
        return $event || (ctx.privateKeyBottomSheetInfo.open = false);
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](5, HomeBitcoinAddressSelectionPage_ng_template_5_Template, 8, 3, "ng-template");
      _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](6, "common-template-dialog-opener", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵlistener"]("isOpenChange", function HomeBitcoinAddressSelectionPage_Template_common_template_dialog_opener_isOpenChange_6_listener($event) {
        return ctx.dialog_addBitcoinAddress.is_open = $event;
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](7, HomeBitcoinAddressSelectionPage_ng_template_7_Template, 9, 2, "ng-template");
      _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("titleColor", "black")("headerBackground", "white")("contentBackground", "white")("contentSafeArea", false);
      _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵconditional"](1, ctx.lookPrivateKey === false ? 1 : -1);
      _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngForOf", ctx.bitcoinAddressList)("ngForTrackBy", ctx.trackByKey("address"));
      _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("isOpen", ctx.privateKeyBottomSheetInfo.open);
      _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("isOpen", ctx.dialog_addBitcoinAddress.is_open);
    }
  },
  dependencies: [_modules_page_module__WEBPACK_IMPORTED_MODULE_9__.CommonPageModule, _libs_bnf_modules_bottom_sheet_components_bottom_sheet_component__WEBPACK_IMPORTED_MODULE_11__.BottomSheetComponent, _libs_bnf_components_ripple_button_ripple_button_directive__WEBPACK_IMPORTED_MODULE_12__.RippleButtonDirective, _libs_bnf_directives_click_to_copy_directive__WEBPACK_IMPORTED_MODULE_13__.ClickToCopyDirective, _libs_bnf_directives_auto_complete_off_directive__WEBPACK_IMPORTED_MODULE_14__.AutoCompleteOffDirective, _angular_common__WEBPACK_IMPORTED_MODULE_24__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_24__.NgIf, _angular_common__WEBPACK_IMPORTED_MODULE_24__.NgStyle, _angular_forms__WEBPACK_IMPORTED_MODULE_23__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_23__.NumberValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_23__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_23__.FormControlDirective, _libs_bnf_modules_dialog_components_common_card_common_card_component__WEBPACK_IMPORTED_MODULE_15__.CommonCardComponent, _libs_bnf_modules_dialog_components_card_footer_confirm_confirm_footer_component__WEBPACK_IMPORTED_MODULE_16__.ConfirmFooterComponent, _libs_bnf_modules_dialog_components_template_dialog_opener_template_dialog_opener_component__WEBPACK_IMPORTED_MODULE_17__.TemplateDialogOpenerComponent, _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_18__.CommonPageComponent, _components_icon_icon_component__WEBPACK_IMPORTED_MODULE_19__.IconComponent, _pipes_color_color_pipe__WEBPACK_IMPORTED_MODULE_20__.ColorPipe, _libs_bnf_pipes_address_hidden_address_hidden_pipe__WEBPACK_IMPORTED_MODULE_21__.AddressHiddenPipe],
  styles: ["/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsInNvdXJjZVJvb3QiOiIifQ== */"],
  changeDetection: 0
});
(0,tslib__WEBPACK_IMPORTED_MODULE_25__.__decorate)([HomeBitcoinAddressSelectionPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_25__.__metadata)("design:type", Object)], HomeBitcoinAddressSelectionPage.prototype, "lookPrivateKey", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_25__.__decorate)([HomeBitcoinAddressSelectionPage.State({
  depth: 1
}), (0,tslib__WEBPACK_IMPORTED_MODULE_25__.__metadata)("design:type", Object)], HomeBitcoinAddressSelectionPage.prototype, "dialog_addBitcoinAddress", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_25__.__decorate)([HomeBitcoinAddressSelectionPage.States(), (0,tslib__WEBPACK_IMPORTED_MODULE_25__.__metadata)("design:type", Object)], HomeBitcoinAddressSelectionPage.prototype, "privateKeyBottomSheetInfo", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_25__.__decorate)([HomeBitcoinAddressSelectionPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_25__.__metadata)("design:type", Object)], HomeBitcoinAddressSelectionPage.prototype, "indexInput", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_25__.__decorate)([HomeBitcoinAddressSelectionPage.States()
/** BTC地址列表 */, (0,tslib__WEBPACK_IMPORTED_MODULE_25__.__metadata)("design:type", Object)], HomeBitcoinAddressSelectionPage.prototype, "bitcoinAddressList", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_25__.__decorate)([HomeBitcoinAddressSelectionPage.OnReady(), (0,tslib__WEBPACK_IMPORTED_MODULE_25__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_25__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_25__.__metadata)("design:returntype", Promise)], HomeBitcoinAddressSelectionPage.prototype, "init", null);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (HomeBitcoinAddressSelectionPage);

/***/ }),

/***/ 96454:
/*!***********************************!*\
  !*** ./libs/bnf/modules/index.ts ***!
  \***********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   BnqklCompModule: () => (/* reexport safe */ _bnqkl_framework_modules_page__WEBPACK_IMPORTED_MODULE_6__.BnqklCompModule),
/* harmony export */   BnqklDialogModule: () => (/* reexport safe */ _bnqkl_framework_modules_dialog__WEBPACK_IMPORTED_MODULE_3__.BnqklDialogModule),
/* harmony export */   BnqklMappCompModule: () => (/* reexport safe */ _bnqkl_framework_modules_page__WEBPACK_IMPORTED_MODULE_6__.BnqklMappCompModule),
/* harmony export */   BnqklMappPageModule: () => (/* reexport safe */ _bnqkl_framework_modules_page__WEBPACK_IMPORTED_MODULE_6__.BnqklMappPageModule),
/* harmony export */   BnqklPageModule: () => (/* reexport safe */ _bnqkl_framework_modules_page__WEBPACK_IMPORTED_MODULE_6__.BnqklPageModule),
/* harmony export */   BottomSheetComponent: () => (/* reexport safe */ _bnqkl_framework_modules_bottom_sheet__WEBPACK_IMPORTED_MODULE_0__.BottomSheetComponent),
/* harmony export */   CONFIRM_MESSAGE_TOKEN: () => (/* reexport safe */ _bnqkl_framework_modules_dialog__WEBPACK_IMPORTED_MODULE_3__.CONFIRM_MESSAGE_TOKEN),
/* harmony export */   ColorPipe: () => (/* reexport safe */ _bnqkl_framework_modules_color__WEBPACK_IMPORTED_MODULE_2__.ColorPipe),
/* harmony export */   ColorService: () => (/* reexport safe */ _bnqkl_framework_modules_color__WEBPACK_IMPORTED_MODULE_2__.ColorService),
/* harmony export */   ComError: () => (/* reexport safe */ _bnqkl_framework_modules_mapp__WEBPACK_IMPORTED_MODULE_5__.ComError),
/* harmony export */   CommonCardComponent: () => (/* reexport safe */ _bnqkl_framework_modules_dialog__WEBPACK_IMPORTED_MODULE_3__.CommonCardComponent),
/* harmony export */   CommonCardTextBodyComponent: () => (/* reexport safe */ _bnqkl_framework_modules_dialog__WEBPACK_IMPORTED_MODULE_3__.CommonCardTextBodyComponent),
/* harmony export */   CommonCardTipFooterComponent: () => (/* reexport safe */ _bnqkl_framework_modules_dialog__WEBPACK_IMPORTED_MODULE_3__.CommonCardTipFooterComponent),
/* harmony export */   CommonPageComponent: () => (/* reexport safe */ _bnqkl_framework_modules_page__WEBPACK_IMPORTED_MODULE_6__.CommonPageComponent),
/* harmony export */   CommonPageTitleStrategy: () => (/* reexport safe */ _bnqkl_framework_modules_page__WEBPACK_IMPORTED_MODULE_6__.CommonPageTitleStrategy),
/* harmony export */   CommonPagesOutletComponent: () => (/* reexport safe */ _bnqkl_framework_modules_page__WEBPACK_IMPORTED_MODULE_6__.CommonPagesOutletComponent),
/* harmony export */   CommunicationDuplexManager: () => (/* reexport safe */ _bnqkl_framework_modules_mapp__WEBPACK_IMPORTED_MODULE_5__.CommunicationDuplexManager),
/* harmony export */   ConfirmFooterComponent: () => (/* reexport safe */ _bnqkl_framework_modules_dialog__WEBPACK_IMPORTED_MODULE_3__.ConfirmFooterComponent),
/* harmony export */   DEFAULT_STATUSBAR_STYLE_TOKEN: () => (/* reexport safe */ _bnqkl_framework_modules_system__WEBPACK_IMPORTED_MODULE_7__.DEFAULT_STATUSBAR_STYLE_TOKEN),
/* harmony export */   ICON_SETUP_CONFIG_TOKEN: () => (/* reexport safe */ _bnqkl_framework_modules_icon__WEBPACK_IMPORTED_MODULE_4__.ICON_SETUP_CONFIG_TOKEN),
/* harmony export */   IconDirective: () => (/* reexport safe */ _bnqkl_framework_modules_icon__WEBPACK_IMPORTED_MODULE_4__.IconDirective),
/* harmony export */   IconService: () => (/* reexport safe */ _bnqkl_framework_modules_icon__WEBPACK_IMPORTED_MODULE_4__.IconService),
/* harmony export */   MappCommonPageComponent: () => (/* reexport safe */ _bnqkl_framework_modules_page__WEBPACK_IMPORTED_MODULE_6__.MappCommonPageComponent),
/* harmony export */   MappCommonPageTitleStrategy: () => (/* reexport safe */ _bnqkl_framework_modules_page__WEBPACK_IMPORTED_MODULE_6__.MappCommonPageTitleStrategy),
/* harmony export */   MappSdkService: () => (/* reexport safe */ _bnqkl_framework_modules_mapp__WEBPACK_IMPORTED_MODULE_5__.MappSdkService),
/* harmony export */   NAMED_COLOR_TOKEN: () => (/* reexport safe */ _bnqkl_framework_modules_color__WEBPACK_IMPORTED_MODULE_2__.NAMED_COLOR_TOKEN),
/* harmony export */   SideSheetComponent: () => (/* reexport safe */ _bnqkl_framework_modules_side_sheet__WEBPACK_IMPORTED_MODULE_1__.SideSheetComponent),
/* harmony export */   StatusBarService: () => (/* reexport safe */ _bnqkl_framework_modules_system__WEBPACK_IMPORTED_MODULE_7__.StatusBarService),
/* harmony export */   TIP_MESSAGE_TOKEN: () => (/* reexport safe */ _bnqkl_framework_modules_dialog__WEBPACK_IMPORTED_MODULE_3__.TIP_MESSAGE_TOKEN),
/* harmony export */   TemplateDialogAutoCloseDirective: () => (/* reexport safe */ _bnqkl_framework_modules_dialog__WEBPACK_IMPORTED_MODULE_3__.TemplateDialogAutoCloseDirective),
/* harmony export */   TemplateDialogOpenerComponent: () => (/* reexport safe */ _bnqkl_framework_modules_dialog__WEBPACK_IMPORTED_MODULE_3__.TemplateDialogOpenerComponent),
/* harmony export */   TemplateDialogService: () => (/* reexport safe */ _bnqkl_framework_modules_dialog__WEBPACK_IMPORTED_MODULE_3__.TemplateDialogService)
/* harmony export */ });
/* harmony import */ var _bnqkl_framework_modules_bottom_sheet__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @bnqkl/framework/modules/bottom-sheet */ 88751);
/* harmony import */ var _bnqkl_framework_modules_side_sheet__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @bnqkl/framework/modules/side-sheet */ 18514);
/* harmony import */ var _bnqkl_framework_modules_color__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @bnqkl/framework/modules/color */ 59066);
/* harmony import */ var _bnqkl_framework_modules_dialog__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @bnqkl/framework/modules/dialog */ 17021);
/* harmony import */ var _bnqkl_framework_modules_icon__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @bnqkl/framework/modules/icon */ 4064);
/* harmony import */ var _bnqkl_framework_modules_mapp__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @bnqkl/framework/modules/mapp */ 97600);
/* harmony import */ var _bnqkl_framework_modules_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @bnqkl/framework/modules/page */ 23243);
/* harmony import */ var _bnqkl_framework_modules_system__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @bnqkl/framework/modules/system */ 7434);









/***/ })

}]);
//# sourceMappingURL=apps_wallet_src_pages_home_pages_home-bitcoin-address-selection_home-bitcoin-address-selectio-f9373e.js.map