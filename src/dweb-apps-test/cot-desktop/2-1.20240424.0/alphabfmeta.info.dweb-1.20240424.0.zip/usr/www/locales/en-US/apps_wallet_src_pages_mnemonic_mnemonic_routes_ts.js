"use strict";
(self["webpackChunkwallet"] = self["webpackChunkwallet"] || []).push([["apps_wallet_src_pages_mnemonic_mnemonic_routes_ts"],{

/***/ 15451:
/*!***********************************************************!*\
  !*** ./apps/wallet/src/pages/mnemonic/mnemonic.routes.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   routes: () => (/* binding */ routes)
/* harmony export */ });
/* harmony import */ var _pages_home_token_details_home_token_details_resolve__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./pages/home-token-details/home-token-details.resolve */ 24731);
/* harmony import */ var _pages_mnemonics_backup_mnemonics_backup_resolver__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./pages/mnemonics-backup/mnemonics-backup.resolver */ 44861);
/* harmony import */ var _pages_set_transaction_password_set_transaction_password_resolver__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./pages/set-transaction-password/set-transaction-password.resolver */ 98221);



const routes = [{
  path: '',
  loadComponent: () => __webpack_require__.e(/*! import() */ "apps_wallet_src_pages_mnemonic_mnemonic_component_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./mnemonic.component */ 4127))
}, {
  path: 'mnemonics-backup',
  loadComponent: () => __webpack_require__.e(/*! import() */ "apps_wallet_src_pages_mnemonic_pages_mnemonics-backup_mnemonics-backup_component_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/mnemonics-backup/mnemonics-backup.component */ 6280)),
  resolve: _pages_mnemonics_backup_mnemonics_backup_resolver__WEBPACK_IMPORTED_MODULE_1__.mnemonicsBackupResolver
}, {
  path: 'mnemonic-confirm-backup',
  loadComponent: () => __webpack_require__.e(/*! import() */ "default-apps_wallet_src_pages_mnemonic_pages_mnemonic-confirm-backup_mnemonic-confirm-backup_-f6fc5f").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/mnemonic-confirm-backup/mnemonic-confirm-backup.component */ 91879))
}, {
  path: 'mnemonic-backup-tips',
  loadComponent: () => __webpack_require__.e(/*! import() */ "apps_wallet_src_pages_mnemonic_pages_mnemonic-backup-tips_mnemonic-backup-tips_component_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/mnemonic-backup-tips/mnemonic-backup-tips.component */ 99596))
}, {
  path: 'mnemonic-create-wallet',
  title: "Mnemonic create wallet",
  loadComponent: () => __webpack_require__.e(/*! import() */ "apps_wallet_src_pages_mnemonic_pages_mnemonic-create-wallet_mnemonic-create-wallet_component_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/mnemonic-create-wallet/mnemonic-create-wallet.component */ 49674))
}, {
  path: 'mnemonic-recover-wallet',
  loadComponent: () => __webpack_require__.e(/*! import() */ "apps_wallet_src_pages_mnemonic_pages_mnemonic-recover-wallet_mnemonic-recover-wallet_component_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/mnemonic-recover-wallet/mnemonic-recover-wallet.component */ 23449))
}, {
  path: 'export-private-key',
  title: "Export Private Key",
  loadComponent: () => __webpack_require__.e(/*! import() */ "apps_wallet_src_pages_mnemonic_pages_export-private-key_export-private-key_component_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/export-private-key/export-private-key.component */ 772))
}, {
  path: 'export-private-key-tips',
  title: "Export Private Key",
  loadComponent: () => __webpack_require__.e(/*! import() */ "apps_wallet_src_pages_mnemonic_pages_export-private-key-tips_export-private-key-tips_component_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/export-private-key-tips/export-private-key-tips.component */ 25225))
}, {
  path: 'home-transfer',
  title: "Transfer",
  loadComponent: () => Promise.all(/*! import() */[__webpack_require__.e("default-apps_wallet_src_pages_mime_pages_verify-fingerprint_verify-fingerprint_component_ts"), __webpack_require__.e("default-apps_wallet_src_pages_scanner_scanner_component_ts"), __webpack_require__.e("default-apps_wallet_src_pages_home_pages_home-payment-details_home-payment-details_component_ts"), __webpack_require__.e("default-apps_wallet_src_pages_mime_pages_modify-address_modify-address_component_ts"), __webpack_require__.e("default-apps_wallet_src_pages_mime_pages_address-book_address-book_component_ts"), __webpack_require__.e("default-apps_wallet_src_pages_mnemonic_pages_home-select-token_home-select-token_component_ts"), __webpack_require__.e("default-apps_wallet_src_pages_mnemonic_pages_home-transfer_home-transfer_component_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./pages/home-transfer/home-transfer.component */ 7406))
}, {
  path: 'home-select-token',
  title: "Select Asset",
  loadComponent: () => __webpack_require__.e(/*! import() */ "default-apps_wallet_src_pages_mnemonic_pages_home-select-token_home-select-token_component_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/home-select-token/home-select-token.component */ 33299))
}, {
  path: 'home-token-details',
  loadComponent: () => Promise.all(/*! import() */[__webpack_require__.e("default-apps_wallet_src_pages_mime_pages_verify-fingerprint_verify-fingerprint_component_ts"), __webpack_require__.e("default-apps_wallet_src_pages_scanner_scanner_component_ts"), __webpack_require__.e("default-apps_wallet_src_pages_home_pages_home-payment-details_home-payment-details_component_ts"), __webpack_require__.e("default-apps_wallet_src_pages_mime_pages_modify-address_modify-address_component_ts"), __webpack_require__.e("default-apps_wallet_src_pages_mime_pages_address-book_address-book_component_ts"), __webpack_require__.e("default-apps_wallet_src_pages_mnemonic_pages_home-select-token_home-select-token_component_ts"), __webpack_require__.e("default-apps_wallet_src_pages_mnemonic_pages_home-transfer_home-transfer_component_ts"), __webpack_require__.e("apps_wallet_src_pages_mnemonic_pages_home-token-details_home-token-details_component_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./pages/home-token-details/home-token-details.component */ 10519)),
  resolve: _pages_home_token_details_home_token_details_resolve__WEBPACK_IMPORTED_MODULE_0__.homeTokenDetailResolver
}, {
  path: 'home-token-transaction-details',
  loadComponent: () => Promise.all(/*! import() */[__webpack_require__.e("default-node_modules_pnpm_angular_material_17_0_1__angular_animations_17_0_4__angular_cdk_17_-763d68"), __webpack_require__.e("apps_wallet_src_pages_mnemonic_pages_home-token-transaction-details_home-token-transaction-de-7c513e")]).then(__webpack_require__.bind(__webpack_require__, /*! ./pages/home-token-transaction-details/home-token-transaction-details.component */ 5685))
}, {
  path: 'home-entity-details',
  title: "DP Details",
  loadComponent: () => __webpack_require__.e(/*! import() */ "apps_wallet_src_pages_mnemonic_pages_home-entity-details_home-entity-details_component_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/home-entity-details/home-entity-details.component */ 79849))
}, {
  path: 'home-entity-list',
  title: "Limited edition Dp",
  loadComponent: () => __webpack_require__.e(/*! import() */ "apps_wallet_src_pages_mnemonic_pages_home-entity-list_home-entity-list_component_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/home-entity-list/home-entity-list.component */ 10186))
}, {
  path: 'reset-password',
  title: "Reset Password",
  loadComponent: () => Promise.all(/*! import() */[__webpack_require__.e("default-apps_wallet_src_pages_mnemonic_pages_reset-password_reset-password_component_ts"), __webpack_require__.e("libs_bnf_controllers_index_ts-_e7fa1")]).then(__webpack_require__.bind(__webpack_require__, /*! ./pages/reset-password/reset-password.component */ 85652))
}, {
  path: 'reset-password-before',
  title: "Reset Password",
  loadComponent: () => __webpack_require__.e(/*! import() */ "apps_wallet_src_pages_mnemonic_pages_reset-password-before_reset-password-before_component_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/reset-password-before/reset-password-before.component */ 35108))
}, {
  path: 'set-wallet-password',
  title: "Set wallet password",
  loadComponent: () => __webpack_require__.e(/*! import() */ "apps_wallet_src_pages_mnemonic_pages_set-wallet-password_set-wallet-password_component_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/set-wallet-password/set-wallet-password.component */ 65903))
}, {
  path: 'set-wallet-fingerprint-pay',
  title: "Fingerprint unlock",
  loadComponent: () => Promise.all(/*! import() */[__webpack_require__.e("default-apps_wallet_src_pages_mime_pages_verify-fingerprint_verify-fingerprint_component_ts"), __webpack_require__.e("apps_wallet_src_pages_mnemonic_pages_set-wallet-fingerprint-pay_set-wallet-fingerprint-pay_co-05d0b8")]).then(__webpack_require__.bind(__webpack_require__, /*! ./pages/set-wallet-fingerprint-pay/set-wallet-fingerprint-pay.component */ 28711))
}, {
  path: 'create-wallet',
  loadComponent: () => __webpack_require__.e(/*! import() */ "apps_wallet_src_pages_mnemonic_pages_create-wallet_create-wallet_component_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/create-wallet/create-wallet.component */ 39460))
}, {
  path: 'manage',
  title: "Manage",
  loadComponent: () => Promise.all(/*! import() */[__webpack_require__.e("default-apps_wallet_src_pages_mnemonic_pages_mnemonic-confirm-backup_mnemonic-confirm-backup_-f6fc5f"), __webpack_require__.e("default-apps_wallet_src_pages_mnemonic_pages_change-password_change-password_component_ts"), __webpack_require__.e("default-apps_wallet_src_pages_mnemonic_pages_reset-password_reset-password_component_ts"), __webpack_require__.e("default-apps_wallet_src_pages_mnemonic_pages_manage-identity-wallet_manage-identity-wallet_co-0ec9c9"), __webpack_require__.e("default-apps_wallet_src_pages_mnemonic_pages_manage_manage_component_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./pages/manage/manage.component */ 54414))
}, {
  path: 'change-password',
  title: "Change Password",
  loadComponent: () => __webpack_require__.e(/*! import() */ "default-apps_wallet_src_pages_mnemonic_pages_change-password_change-password_component_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/change-password/change-password.component */ 67948))
}, {
  path: 'change-password-before',
  title: "Change Password",
  loadComponent: () => __webpack_require__.e(/*! import() */ "apps_wallet_src_pages_mnemonic_pages_change-password-before_change-password-before_component_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/change-password-before/change-password-before.component */ 86168))
}, {
  path: 'manage-identity-wallet',
  title: "Manage Identity Wallet",
  loadComponent: () => Promise.all(/*! import() */[__webpack_require__.e("default-apps_wallet_src_pages_mnemonic_pages_mnemonic-confirm-backup_mnemonic-confirm-backup_-f6fc5f"), __webpack_require__.e("default-apps_wallet_src_pages_mnemonic_pages_change-password_change-password_component_ts"), __webpack_require__.e("default-apps_wallet_src_pages_mnemonic_pages_reset-password_reset-password_component_ts"), __webpack_require__.e("default-apps_wallet_src_pages_mnemonic_pages_manage-identity-wallet_manage-identity-wallet_co-0ec9c9")]).then(__webpack_require__.bind(__webpack_require__, /*! ./pages/manage-identity-wallet/manage-identity-wallet.component */ 79033))
}, {
  path: 'user-agreement',
  title: "User agreement",
  loadComponent: () => __webpack_require__.e(/*! import() */ "apps_wallet_src_pages_mnemonic_pages_user-agreement_user-agreement_component_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/user-agreement/user-agreement.component */ 29640))
}, {
  path: 'address-password-tips',
  title: "Export Address Password",
  loadComponent: () => __webpack_require__.e(/*! import() */ "apps_wallet_src_pages_mnemonic_pages_address-password-tips_address-password-tips_component_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/address-password-tips/address-password-tips.component */ 29312))
}, {
  path: 'address-password-backup',
  title: "Export Address Password",
  loadComponent: () => __webpack_require__.e(/*! import() */ "apps_wallet_src_pages_mnemonic_pages_address-password-backup_address-password-backup_component_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/address-password-backup/address-password-backup.component */ 66540))
}, {
  path: 'set-transaction-password',
  title: "Set Transaction Password",
  loadComponent: () => Promise.all(/*! import() */[__webpack_require__.e("default-apps_wallet_src_pages_mime_pages_verify-fingerprint_verify-fingerprint_component_ts"), __webpack_require__.e("default-apps_wallet_src_pages_home_pages_home-payment-details_home-payment-details_component_ts"), __webpack_require__.e("apps_wallet_src_pages_mnemonic_pages_set-transaction-password_set-transaction-password_component_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./pages/set-transaction-password/set-transaction-password.component */ 80185)),
  resolve: _pages_set_transaction_password_set_transaction_password_resolver__WEBPACK_IMPORTED_MODULE_2__.SetTransactionPasswordResolver
}];
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (routes);

/***/ }),

/***/ 24731:
/*!***********************************************************************************************!*\
  !*** ./apps/wallet/src/pages/mnemonic/pages/home-token-details/home-token-details.resolve.ts ***!
  \***********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   HomeTokenDetailResolveFn: () => (/* binding */ HomeTokenDetailResolveFn),
/* harmony export */   homeTokenDetailResolver: () => (/* binding */ homeTokenDetailResolver)
/* harmony export */ });
/* harmony import */ var D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 52542);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 61039);
/* harmony import */ var _bnqkl_wallet_base_services_wallet_chain__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @bnqkl/wallet-base/services/wallet/chain */ 27434);



/** 加載是否是生物鏈林標志 */
const HomeTokenDetailResolveFn = /*#__PURE__*/function () {
  var _ref = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (route) {
    const chainV2Service = (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.inject)(_bnqkl_wallet_base_services_wallet_chain__WEBPACK_IMPORTED_MODULE_1__.ChainV2Service);
    const {
      chain
    } = route.queryParams;
    const isBioforestChain = chainV2Service.isBioforestChainByChainName(chain);
    return isBioforestChain;
  });
  return function HomeTokenDetailResolveFn(_x) {
    return _ref.apply(this, arguments);
  };
}();
/** homeTokenDetailResolver */
const homeTokenDetailResolver = {
  isBioforestChain: HomeTokenDetailResolveFn
};

/***/ }),

/***/ 44861:
/*!********************************************************************************************!*\
  !*** ./apps/wallet/src/pages/mnemonic/pages/mnemonics-backup/mnemonics-backup.resolver.ts ***!
  \********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   MnemonicResolver: () => (/* binding */ MnemonicResolver),
/* harmony export */   mnemonicsBackupResolver: () => (/* binding */ mnemonicsBackupResolver)
/* harmony export */ });
/* harmony import */ var D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 52542);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 61039);
/* harmony import */ var _bnqkl_wallet_base_services_wallet_bip39__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @bnqkl/wallet-base/services/wallet/bip39 */ 76659);



/** 备份助记词界面的助记词生成器 */
// @Injectable({ providedIn: 'root' })
// export class MnemonicResolver
//   implements
//     Resolve<{
//       mnemonicArr: string[];
//       mnemonicString: string;
//     }>
// {
//   /**
//    * 引入助记词生成文件
//    */
//   private bip39LibService = inject(Bip39LibService);
//   /** 生成、解析助记词 */
//   async resolve(route: ActivatedRouteSnapshot) {
//     let { mnemonicString } = route.queryParams;
//     let mnemonicArr: string[];
//     if (typeof mnemonicString === 'string') {
//       mnemonicArr = await this.bip39LibService.getMnemonicArray(mnemonicString);
//     } else {
//       mnemonicString = (await this.bip39LibService.createMnemonic()).mnemonic;
//       mnemonicArr = await this.bip39LibService.getMnemonicArray(mnemonicString);
//     }
//     return { mnemonicString, mnemonicArr };
//   }
// }
const MnemonicResolver = /*#__PURE__*/function () {
  var _ref = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (route) {
    const bip39LibService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.inject)(_bnqkl_wallet_base_services_wallet_bip39__WEBPACK_IMPORTED_MODULE_1__.Bip39LibService);
    let {
      mnemonicString
    } = route.queryParams;
    const {
      mnemonic,
      language,
      length
    } = route.queryParams;
    let mnemonicArr;
    mnemonic && (mnemonicString = mnemonic);
    if (typeof mnemonicString === 'string') {
      mnemonicArr = yield bip39LibService.getMnemonicArray(mnemonicString);
    } else {
      mnemonicString = (yield bip39LibService.createMnemonic(Number(length || 12), language)).mnemonic;
      mnemonicArr = yield bip39LibService.getMnemonicArray(mnemonicString);
    }
    return {
      mnemonicString,
      mnemonicArr
    };
  });
  return function MnemonicResolver(_x) {
    return _ref.apply(this, arguments);
  };
}();
/**
 * ResolverData
 */
const mnemonicsBackupResolver = {
  mnemonic: MnemonicResolver
};

/***/ }),

/***/ 98221:
/*!************************************************************************************************************!*\
  !*** ./apps/wallet/src/pages/mnemonic/pages/set-transaction-password/set-transaction-password.resolver.ts ***!
  \************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   SetTransactionPasswordResolver: () => (/* binding */ SetTransactionPasswordResolver)
/* harmony export */ });
/* harmony import */ var D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 52542);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 61039);
/* harmony import */ var _bnqkl_wallet_base_services_wallet__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @bnqkl/wallet-base/services/wallet */ 20609);



/**
 * ResolverData
 */
const SetTransactionPasswordResolver = {
  data: function () {
    var _ref = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (route) {
      const chainService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.inject)(_bnqkl_wallet_base_services_wallet__WEBPACK_IMPORTED_MODULE_1__.ChainService);
      const {
        chain,
        address
      } = route.queryParams;
      const {
        secondPublicKey
      } = yield chainService.getChainService(chain).getAddressInfo(address);
      return {
        secondPublicKey
      };
    });
    return function data(_x) {
      return _ref.apply(this, arguments);
    };
  }()
};

/***/ })

}]);
//# sourceMappingURL=apps_wallet_src_pages_mnemonic_mnemonic_routes_ts.js.map