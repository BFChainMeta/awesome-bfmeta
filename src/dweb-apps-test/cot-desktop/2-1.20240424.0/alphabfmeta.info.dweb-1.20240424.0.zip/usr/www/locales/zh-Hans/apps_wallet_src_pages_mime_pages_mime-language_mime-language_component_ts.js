"use strict";
(self["webpackChunkwallet"] = self["webpackChunkwallet"] || []).push([["apps_wallet_src_pages_mime_pages_mime-language_mime-language_component_ts"],{

/***/ 98702:
/*!***********************************************************************************!*\
  !*** ./apps/wallet/src/pages/mime/pages/mime-language/mime-language.component.ts ***!
  \***********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   MimeLanguagePage: () => (/* binding */ MimeLanguagePage),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 52542);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! tslib */ 90505);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/core */ 61039);
/* harmony import */ var _bnqkl_framework_plugins_toast__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @bnqkl/framework/plugins/toast */ 18030);
/* harmony import */ var _bnqkl_util_web_extends_promise__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @bnqkl/util-web/extends-promise */ 87778);
/* harmony import */ var _bnqkl_wallet_base_services_plaoc__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @bnqkl/wallet-base/services/plaoc */ 63878);
/* harmony import */ var _environments_index__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ~environments/index */ 40014);
/* harmony import */ var _modules_page_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ~modules/page.module */ 77538);
/* harmony import */ var _libs_bnf_components_ripple_button_ripple_button_directive__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../../../../../libs/bnf/components/ripple-button/ripple-button.directive */ 16505);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/common */ 6729);
/* harmony import */ var _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../../../../../libs/bnf/modules/page/common-page/common-page.component */ 62052);
/* harmony import */ var _components_icon_icon_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../../components/icon/icon.component */ 74703);
/* harmony import */ var _pipes_color_color_pipe__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../../../pipes/color/color.pipe */ 76489);

var _class;













const _c4 = a0 => ({
  "--color-1": a0
});
function MimeLanguagePage_ng_container_5_w_icon_6_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](0, "w-icon", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpipe"](1, "color");
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngStyle", _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpureFunction1"](3, _c4, _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpipeBind1"](1, 1, "primary-2")));
  }
}
function MimeLanguagePage_ng_container_5_Template(rf, ctx) {
  if (rf & 1) {
    const _r4 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](1, "button", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("click", function MimeLanguagePage_ng_container_5_Template_button_click_1_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵrestoreView"](_r4);
      const item_r1 = restoredCtx.$implicit;
      const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵresetView"](ctx_r3.selectLanguage(item_r1.value));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](2, "div", 6)(3, "span", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](5, "div", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](6, MimeLanguagePage_ng_container_5_w_icon_6_Template, 2, 5, "w-icon", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const item_r1 = ctx.$implicit;
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtextInterpolate"](item_r1.title);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", ctx_r0.language === item_r1.value);
  }
}
/** 切换语言页面 */
class MimeLanguagePage extends _modules_page_module__WEBPACK_IMPORTED_MODULE_5__.CommonPageBase {
  constructor() {
    super(...arguments);
    /** 原来的语言 */
    this.localeId = (0,_angular_core__WEBPACK_IMPORTED_MODULE_10__.inject)(_angular_core__WEBPACK_IMPORTED_MODULE_10__.LOCALE_ID);
    /** 已选择的语言 */
    this.language = (0,_angular_core__WEBPACK_IMPORTED_MODULE_10__.inject)(_angular_core__WEBPACK_IMPORTED_MODULE_10__.LOCALE_ID);
    /** 语言列表，这边不需要翻译 */
    this.languageList = [{
      title: '简体中文',
      value: 'zh-Hans'
    }, {
      title: '繁体中文',
      value: 'zh-Hant'
    }, {
      title: 'English',
      value: 'en-US'
    }];
  }
  /** 选择语言标识符 */
  selectLanguage(language) {
    this.language = language;
  }
  /** 保存选择语言并刷新页面 */
  saveSelectLanguage() {
    var _this = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      if (_environments_index__WEBPACK_IMPORTED_MODULE_4__.environment.DWEB_APP) {
        const plaoc = _this.injectorForceGet(_bnqkl_wallet_base_services_plaoc__WEBPACK_IMPORTED_MODULE_3__.PlaocService);
        const res = yield plaoc.setLang(_this.language);
        if (res) {
          _bnqkl_framework_plugins_toast__WEBPACK_IMPORTED_MODULE_1__.Toast.show("\u5E94\u7528\u5C06\u91CD\u542F\uFF0C\u8BF7\u7A0D\u7B49\u3002");
          sessionStorage.setItem('SELECT_LANGUAGE', '1');
          yield (0,_bnqkl_util_web_extends_promise__WEBPACK_IMPORTED_MODULE_2__.sleep)(500);
          plaoc.restart();
        }
      } else {
        if ((yield swc.tryRequest(['set-lang', _this.language], () => _this.language)) === _this.language) {
          // 这里会卡一下, 提示用户应用重启
          _bnqkl_framework_plugins_toast__WEBPACK_IMPORTED_MODULE_1__.Toast.show("\u5E94\u7528\u5C06\u91CD\u542F\uFF0C\u8BF7\u7A0D\u7B49\u3002");
          sessionStorage.setItem('SELECT_LANGUAGE', '1');
          // 回到主页，重启应用
          location.href = '/';
        }
      }
    })();
  }
}
_class = MimeLanguagePage;
_class.ɵfac = /*@__PURE__*/(() => {
  let ɵMimeLanguagePage_BaseFactory;
  return function MimeLanguagePage_Factory(t) {
    return (ɵMimeLanguagePage_BaseFactory || (ɵMimeLanguagePage_BaseFactory = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵgetInheritedFactory"](_class)))(t || _class);
  };
})();
_class.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵdefineComponent"]({
  type: _class,
  selectors: [["w-mime-language"]],
  standalone: true,
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵInheritDefinitionFeature"], _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵStandaloneFeature"]],
  decls: 6,
  vars: 3,
  consts: () => {
    let i18n_0;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_LANGUAGE$$APPS_WALLET_SRC_PAGES_MIME_PAGES_MIME_LANGUAGE_MIME_LANGUAGE_COMPONENT_TS_1 = goog.getMsg("Language");
      i18n_0 = MSG_EXTERNAL_LANGUAGE$$APPS_WALLET_SRC_PAGES_MIME_PAGES_MIME_LANGUAGE_MIME_LANGUAGE_COMPONENT_TS_1;
    } else {
      i18n_0 = "\u8BED\u8A00";
    }
    let i18n_2;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_SAVE$$APPS_WALLET_SRC_PAGES_MIME_PAGES_MIME_LANGUAGE_MIME_LANGUAGE_COMPONENT_TS_3 = goog.getMsg("Save");
      i18n_2 = MSG_EXTERNAL_SAVE$$APPS_WALLET_SRC_PAGES_MIME_PAGES_MIME_LANGUAGE_MIME_LANGUAGE_COMPONENT_TS_3;
    } else {
      i18n_2 = "\u4FDD\u5B58";
    }
    return [["headerTitle", i18n_0, 3, "contentBackground"], ["endMenu", "", "bnRippleButton", "", 1, "text-primary", "disabled:opacity-50", 3, "disabled", "click"], i18n_2, [1, "mt-1.5"], [4, "ngFor", "ngForOf"], ["bnRippleButton", "", 1, "px-page-safe-area-inset", "flex", "h-14", "w-full", "items-stretch", "justify-between", "bg-white", 3, "click"], [1, "flex", "items-center"], [1, "to-title", "text-sm"], [1, "flex", "items-center", "justify-end"], ["class", "icon-6", "name", "language-selected-1", 3, "ngStyle", 4, "ngIf"], ["name", "language-selected-1", 1, "icon-6", 3, "ngStyle"]];
  },
  template: function MimeLanguagePage_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "common-page", 0)(1, "button", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("click", function MimeLanguagePage_Template_button_click_1_listener() {
        return ctx.saveSelectLanguage();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](2, "span");
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵi18n"](3, 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](4, "div", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](5, MimeLanguagePage_ng_container_5_Template, 7, 2, "ng-container", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()();
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("contentBackground", "env");
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("disabled", ctx.localeId === ctx.language);
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](4);
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngForOf", ctx.languageList);
    }
  },
  dependencies: [_modules_page_module__WEBPACK_IMPORTED_MODULE_5__.CommonPageModule, _libs_bnf_components_ripple_button_ripple_button_directive__WEBPACK_IMPORTED_MODULE_6__.RippleButtonDirective, _angular_common__WEBPACK_IMPORTED_MODULE_11__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_11__.NgIf, _angular_common__WEBPACK_IMPORTED_MODULE_11__.NgStyle, _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_7__.CommonPageComponent, _components_icon_icon_component__WEBPACK_IMPORTED_MODULE_8__.IconComponent, _pipes_color_color_pipe__WEBPACK_IMPORTED_MODULE_9__.ColorPipe],
  styles: ["/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsInNvdXJjZVJvb3QiOiIifQ== */"],
  changeDetection: 0
});
(0,tslib__WEBPACK_IMPORTED_MODULE_12__.__decorate)([MimeLanguagePage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_12__.__metadata)("design:type", Object)], MimeLanguagePage.prototype, "localeId", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_12__.__decorate)([MimeLanguagePage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_12__.__metadata)("design:type", Object)], MimeLanguagePage.prototype, "language", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_12__.__decorate)([MimeLanguagePage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_12__.__metadata)("design:type", Array)], MimeLanguagePage.prototype, "languageList", void 0);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MimeLanguagePage);

/***/ })

}]);
//# sourceMappingURL=apps_wallet_src_pages_mime_pages_mime-language_mime-language_component_ts.js.map