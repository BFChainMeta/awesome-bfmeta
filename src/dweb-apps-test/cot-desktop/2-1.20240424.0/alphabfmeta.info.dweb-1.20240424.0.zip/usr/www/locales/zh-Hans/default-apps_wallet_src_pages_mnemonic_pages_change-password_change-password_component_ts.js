"use strict";
(self["webpackChunkwallet"] = self["webpackChunkwallet"] || []).push([["default-apps_wallet_src_pages_mnemonic_pages_change-password_change-password_component_ts"],{

/***/ 67948:
/*!*******************************************************************************************!*\
  !*** ./apps/wallet/src/pages/mnemonic/pages/change-password/change-password.component.ts ***!
  \*******************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ChangePasswordPage: () => (/* binding */ ChangePasswordPage),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 52542);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! tslib */ 90505);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/core */ 61039);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/forms */ 7820);
/* harmony import */ var _bnqkl_framework_controllers__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @bnqkl/framework/controllers */ 47919);
/* harmony import */ var _bnqkl_framework_plugins_toast__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @bnqkl/framework/plugins/toast */ 18030);
/* harmony import */ var _bnqkl_util_web_decorator__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @bnqkl/util-web/decorator */ 18112);
/* harmony import */ var _bnqkl_wallet_base_services_wallet_wallet_data_storage__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @bnqkl/wallet-base/services/wallet/wallet-data-storage */ 63024);
/* harmony import */ var _components_input_hidden_icon_swap_input_hidden_icon_swap_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ~components/input-hidden-icon-swap/input-hidden-icon-swap.component */ 68027);
/* harmony import */ var _modules_page_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ~modules/page.module */ 77538);
/* harmony import */ var _libs_bnf_components_ripple_button_ripple_button_directive__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../../../../../libs/bnf/components/ripple-button/ripple-button.directive */ 16505);
/* harmony import */ var _libs_bnf_directives_form_errors_directive__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../../../../../libs/bnf/directives/form-errors.directive */ 29541);
/* harmony import */ var _libs_bnf_directives_auto_complete_off_directive__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../../../../../../libs/bnf/directives/auto-complete-off.directive */ 66722);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @angular/common */ 6729);
/* harmony import */ var _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../../../../../../libs/bnf/modules/page/common-page/common-page.component */ 62052);
/* harmony import */ var _libs_bnf_pipes_errors_errors_pipe__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../../../../../../libs/bnf/pipes/errors/errors.pipe */ 68362);
/* harmony import */ var _pipes_color_color_pipe__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../../../pipes/color/color.pipe */ 76489);

var _class;


















function ChangePasswordPage_ng_template_9_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵi18n"](1, 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementContainerEnd"]();
  }
}
function ChangePasswordPage_ng_template_10_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵi18n"](1, 26);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const error_r9 = ctx.$error;
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵi18nExp"](error_r9.requiredLength);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵi18nApply"](1);
  }
}
function ChangePasswordPage_ng_template_11_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵi18n"](1, 27);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const error_r10 = ctx.$error;
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵi18nExp"](error_r10.requiredLength);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵi18nApply"](1);
  }
}
function ChangePasswordPage_ng_template_12_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵi18n"](1, 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementContainerEnd"]();
  }
}
function ChangePasswordPage_ng_template_13_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵi18n"](1, 29);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementContainerEnd"]();
  }
}
function ChangePasswordPage_ng_template_14_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵi18n"](1, 30);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementContainerEnd"]();
  }
}
function ChangePasswordPage_ng_template_15_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵi18n"](1, 31);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementContainerEnd"]();
  }
}
function ChangePasswordPage_ng_template_16_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](0);
  }
  if (rf & 2) {
    const errors_r12 = ctx.$errors;
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtextInterpolate1"](" ", errors_r12, " ");
  }
}
const _c24 = a0 => ({
  "text-error": a0
});
const _c25 = (a0, a1) => ({
  pwd: a0,
  cpwd: a1
});
const _c26 = a0 => ({
  "--color-1": a0
});
/**
 * 修改安全密码页面
 */
class ChangePasswordPage extends _modules_page_module__WEBPACK_IMPORTED_MODULE_6__.CommonPageBase {
  constructor() {
    var _this;
    /** 页面返回值的类型 */
    super(...arguments);
    _this = this;
    this.returnValue$ = new _modules_page_module__WEBPACK_IMPORTED_MODULE_6__.PageReturnValue();
    /** 引入钱包存储服务 */
    this.walletDataStorageV2Service = (0,_angular_core__WEBPACK_IMPORTED_MODULE_13__.inject)(_bnqkl_wallet_base_services_wallet_wallet_data_storage__WEBPACK_IMPORTED_MODULE_4__.WalletDataStorageV2Service);
    /** 表单验证服务 */
    this.validators = new _bnqkl_framework_controllers__WEBPACK_IMPORTED_MODULE_1__.FormValidatorsController(this);
    /**
     * 密码型内容显示与否
     */
    this.inputPwdContentShow = false;
    /**
     * 确认密码型内容显示与否
     */
    this.inputContentShow = false;
    /** 密码 */
    this.pwd = new _angular_forms__WEBPACK_IMPORTED_MODULE_14__.FormControl('', {
      nonNullable: true,
      validators: [this.validators.whitespace, _angular_forms__WEBPACK_IMPORTED_MODULE_14__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_14__.Validators.minLength(8), _angular_forms__WEBPACK_IMPORTED_MODULE_14__.Validators.maxLength(30)],
      asyncValidators: [( /*#__PURE__*/function () {
        var _ref = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (control) {
          /// 存在其他错误，本次先不判断
          if (control.errors) {
            return null;
          }
          const password = _this._currentPwd;
          if (password === control.value) {
            return {
              pwdErr: "\u5BC6\u7801\u4E0D\u80FD\u76F8\u540C"
            };
          }
          return null;
        });
        return function (_x) {
          return _ref.apply(this, arguments);
        };
      }())]
    });
    /** 确认密码 */
    this.cpwd = new _angular_forms__WEBPACK_IMPORTED_MODULE_14__.FormControl('', {
      nonNullable: true,
      validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_14__.Validators.required, this.validators.equals(this.pwd)]
    });
    /** 密码提示 */
    this.tip = new _angular_forms__WEBPACK_IMPORTED_MODULE_14__.FormControl('', {
      nonNullable: true,
      validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_14__.Validators.maxLength(50)]
    });
    /** 要提交的表单与复合验证 */
    this.form = new _angular_forms__WEBPACK_IMPORTED_MODULE_14__.FormGroup({
      pwd: this.pwd,
      cpwd: this.cpwd,
      tip: this.tip
    }, {
      validators: [],
      asyncValidators: []
    });
  }
  /** 当前密码，缓存 */
  get _currentPwd() {
    return this.walletDataStorageV2Service.walletAppSettings.password;
  }
  /** 提交事件 */
  onSubmit() {
    var _this2 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const data = _this2.form.getRawValue();
      _this2.walletDataStorageV2Service.walletAppSettings.password = data.pwd;
      _this2.walletDataStorageV2Service.walletAppSettings.passwordTips = data.tip;
      _bnqkl_framework_plugins_toast__WEBPACK_IMPORTED_MODULE_2__.Toast.show("\u5BC6\u7801\u4FEE\u6539\u6210\u529F");
      _this2.returnValue$.next({
        result: 'success',
        tipContent: data.tip
      });
      _this2.nav.back();
    })();
  }
}
_class = ChangePasswordPage;
_class.ɵfac = /*@__PURE__*/(() => {
  let ɵChangePasswordPage_BaseFactory;
  return function ChangePasswordPage_Factory(t) {
    return (ɵChangePasswordPage_BaseFactory || (ɵChangePasswordPage_BaseFactory = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵgetInheritedFactory"](_class)))(t || _class);
  };
})();
_class.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdefineComponent"]({
  type: _class,
  selectors: [["w-change-password-page"]],
  outputs: {
    returnValue$: "returnValue$"
  },
  standalone: true,
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵInheritDefinitionFeature"], _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵStandaloneFeature"]],
  decls: 31,
  vars: 35,
  consts: () => {
    let i18n_0;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_NEW_PASSWORD$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_CHANGE_PASSWORD_CHANGE_PASSWORD_COMPONENT_TS_1 = goog.getMsg(" New Password ");
      i18n_0 = MSG_EXTERNAL_NEW_PASSWORD$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_CHANGE_PASSWORD_CHANGE_PASSWORD_COMPONENT_TS_1;
    } else {
      i18n_0 = "\u65B0\u5BC6\u7801";
    }
    let i18n_2;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_PASSWORD_IS_NOT_LESS_THAN_DIGITS$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_CHANGE_PASSWORD_CHANGE_PASSWORD_COMPONENT_TS_3 = goog.getMsg("Password is not less than 8 digits");
      i18n_2 = MSG_EXTERNAL_PASSWORD_IS_NOT_LESS_THAN_DIGITS$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_CHANGE_PASSWORD_CHANGE_PASSWORD_COMPONENT_TS_3;
    } else {
      i18n_2 = "\u5BC6\u7801\u81F3\u5C118\u4E2A\u5B57\u7B26";
    }
    let i18n_4;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_REPEAT_PASSWORD$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_CHANGE_PASSWORD_CHANGE_PASSWORD_COMPONENT_TS_5 = goog.getMsg("Repeat Password");
      i18n_4 = MSG_EXTERNAL_REPEAT_PASSWORD$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_CHANGE_PASSWORD_CHANGE_PASSWORD_COMPONENT_TS_5;
    } else {
      i18n_4 = "\u786E\u8BA4\u5BC6\u7801";
    }
    let i18n_6;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_THE_PASSWORD_WILL_BE_USED_TO_VERIFY_WALLET_TRANSFERS_VIEW_MNEMINIC_PHRASES_AND_OTHER_IMPORTANT_FUNCTIONS__THIS_IS_ALOCAL_PASSWORD_$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_CHANGE_PASSWORD_CHANGE_PASSWORD_COMPONENT_TS_7 = goog.getMsg(" The Password will be used to verify wallet transfers, view mnemonic phrases and other important functions (this is alocal password) ");
      i18n_6 = MSG_EXTERNAL_THE_PASSWORD_WILL_BE_USED_TO_VERIFY_WALLET_TRANSFERS_VIEW_MNEMINIC_PHRASES_AND_OTHER_IMPORTANT_FUNCTIONS__THIS_IS_ALOCAL_PASSWORD_$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_CHANGE_PASSWORD_CHANGE_PASSWORD_COMPONENT_TS_7;
    } else {
      i18n_6 = "\u5BC6\u7801\u5C06\u7528\u4E8E\u94B1\u5305\u8F6C\u8D26\uFF0C\u67E5\u770B\u52A9\u8BB0\u8BCD\u7B49\u91CD\u8981\u529F\u80FD\u7684\u9A8C\u8BC1\uFF08\u6B64\u4E3A\u672C\u5730\u5BC6\u7801\uFF09";
    }
    let i18n_8;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_CONFIRM$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_CHANGE_PASSWORD_CHANGE_PASSWORD_COMPONENT_TS_9 = goog.getMsg(" Confirm ");
      i18n_8 = MSG_EXTERNAL_CONFIRM$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_CHANGE_PASSWORD_CHANGE_PASSWORD_COMPONENT_TS_9;
    } else {
      i18n_8 = "\u786E\u5B9A";
    }
    let i18n_10;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_PLEASE_INPUT_THE_PASSWORD$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_CHANGE_PASSWORD_CHANGE_PASSWORD_COMPONENT_TS__11 = goog.getMsg("Please input the password");
      i18n_10 = MSG_EXTERNAL_PLEASE_INPUT_THE_PASSWORD$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_CHANGE_PASSWORD_CHANGE_PASSWORD_COMPONENT_TS__11;
    } else {
      i18n_10 = "\u8BF7\u8F93\u5165\u5BC6\u7801";
    }
    let i18n_12;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_THE_PASSWORD_IS_AT_LEAST_CHARACTERS_LONG$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_CHANGE_PASSWORD_CHANGE_PASSWORD_COMPONENT_TS__13 = goog.getMsg(" The password is at least {$interpolation} characters long ", {
        "interpolation": "\uFFFD0\uFFFD"
      }, {
        original_code: {
          "interpolation": "{{ error.requiredLength }}"
        }
      });
      i18n_12 = MSG_EXTERNAL_THE_PASSWORD_IS_AT_LEAST_CHARACTERS_LONG$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_CHANGE_PASSWORD_CHANGE_PASSWORD_COMPONENT_TS__13;
    } else {
      i18n_12 = "\u5BC6\u7801\u8BF7\u52FF\u5C11\u4E8E " + "\uFFFD0\uFFFD" + " \u4E2A\u5B57\u7B26 ";
    }
    let i18n_14;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_THE_MAXIMUM_LENGTH_OF_THE_PASSWORD_IS$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_CHANGE_PASSWORD_CHANGE_PASSWORD_COMPONENT_TS__15 = goog.getMsg(" The maximum length of the password is {$interpolation} ", {
        "interpolation": "\uFFFD0\uFFFD"
      }, {
        original_code: {
          "interpolation": "{{ error.requiredLength }}"
        }
      });
      i18n_14 = MSG_EXTERNAL_THE_MAXIMUM_LENGTH_OF_THE_PASSWORD_IS$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_CHANGE_PASSWORD_CHANGE_PASSWORD_COMPONENT_TS__15;
    } else {
      i18n_14 = "\u5BC6\u7801\u8BF7\u52FF\u8D85\u8FC7 " + "\uFFFD0\uFFFD" + " \u4E2A\u5B57\u7B26 ";
    }
    let i18n_16;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_THE_PASSWORD_CANNOT_CONTAINER_SPACES$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_CHANGE_PASSWORD_CHANGE_PASSWORD_COMPONENT_TS__17 = goog.getMsg(" The password cannot container spaces ! ");
      i18n_16 = MSG_EXTERNAL_THE_PASSWORD_CANNOT_CONTAINER_SPACES$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_CHANGE_PASSWORD_CHANGE_PASSWORD_COMPONENT_TS__17;
    } else {
      i18n_16 = "\u5BC6\u7801\u4E2D\u8BF7\u52FF\u5305\u542B\u7A7A\u683C\uFF01";
    }
    let i18n_18;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_PLEASE_INPUT_THE_PASSWORD_AGAIN$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_CHANGE_PASSWORD_CHANGE_PASSWORD_COMPONENT_TS__19 = goog.getMsg("Please input the password again");
      i18n_18 = MSG_EXTERNAL_PLEASE_INPUT_THE_PASSWORD_AGAIN$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_CHANGE_PASSWORD_CHANGE_PASSWORD_COMPONENT_TS__19;
    } else {
      i18n_18 = "\u8BF7\u518D\u6B21\u8F93\u5165\u5BC6\u7801";
    }
    let i18n_20;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_TWO_INPUTSDO_NOT_MATCH$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_CHANGE_PASSWORD_CHANGE_PASSWORD_COMPONENT_TS__21 = goog.getMsg("Two inputs don't match!");
      i18n_20 = MSG_EXTERNAL_TWO_INPUTSDO_NOT_MATCH$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_CHANGE_PASSWORD_CHANGE_PASSWORD_COMPONENT_TS__21;
    } else {
      i18n_20 = "\u4E24\u6B21\u8F93\u5165\u4E0D\u4E00\u81F4\uFF01";
    }
    let i18n_22;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_PASSWORDS_CAN_NOT_BE_THE_SAME$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_CHANGE_PASSWORD_CHANGE_PASSWORD_COMPONENT_TS__23 = goog.getMsg("Passwords can not be the same");
      i18n_22 = MSG_EXTERNAL_PASSWORDS_CAN_NOT_BE_THE_SAME$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_CHANGE_PASSWORD_CHANGE_PASSWORD_COMPONENT_TS__23;
    } else {
      i18n_22 = "\u4E0D\u80FD\u4E0E\u65E7\u5BC6\u7801\u76F8\u540C";
    }
    return [[3, "contentSafeArea", "contentBackground", "headerBackground"], [3, "formGroup", "ngSubmit"], [1, "flex", "h-10", "w-full", "items-end", "justify-between", "text-xs", "font-semibold"], [1, "flex-shrink-0", "pr-2", 3, "ngClass"], i18n_0, [1, "text-error", "text-xss", "text-right", 3, "wSwitchErrors"], ["scope", "pwd", "wCaseKey", "required"], ["scope", "pwd", "wCaseKey", "minlength"], ["scope", "pwd", "wCaseKey", "maxlength"], ["scope", "pwd", "wCaseKey", "whitespace"], ["scope", "cpwd", "wCaseKey", "required"], ["scope", "cpwd", "wCaseKey", "equals"], ["scope", "pwd", "wCaseKey", "pwdErr"], [3, "wCaseDefault"], [1, "mt-1", "flex", "h-10", "items-center", "rounded-lg", "bg-white", "pr-2"], ["formControlName", "pwd", "placeholder", i18n_2, 1, "w-full", "px-2", 3, "type"], [1, "icon-5.5", "text-subtext", "ml-6", "flex-shrink-0", 3, "show", "showChange"], [1, "mt-2", "flex", "h-10", "items-center", "rounded-lg", "bg-white", "pr-2"], ["formControlName", "cpwd", "placeholder", i18n_4, 1, "w-full", "px-2", 3, "type"], ["footer", "", 3, "formGroup", "ngSubmit"], [1, "mb-6", "p-3"], [1, "text-title", "rounded-6", "bg-white", "px-5", "py-4", "shadow-[0_5px_5px_0px_rgba(29,24,228,0.08)]"], i18n_6, ["bnRippleButton", "", "type", "submit", 1, "h-10.5", "bg-primary-2", "w-full", "rounded-full", "text-center", "text-white", 3, "disabled"], i18n_8, i18n_10, i18n_12, i18n_14, i18n_16, i18n_18, i18n_20, i18n_22];
  },
  template: function ChangePasswordPage_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "common-page", 0)(1, "form", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("ngSubmit", function ChangePasswordPage_Template_form_ngSubmit_1_listener() {
        return ctx.onSubmit();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](2, "fieldset")(3, "legend", 2)(4, "div", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵi18n"](5, 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipe"](6, "errors");
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipe"](7, "errors");
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](8, "div", 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](9, ChangePasswordPage_ng_template_9_Template, 2, 0, "ng-template", 6)(10, ChangePasswordPage_ng_template_10_Template, 2, 1, "ng-template", 7)(11, ChangePasswordPage_ng_template_11_Template, 2, 1, "ng-template", 8)(12, ChangePasswordPage_ng_template_12_Template, 2, 0, "ng-template", 9)(13, ChangePasswordPage_ng_template_13_Template, 2, 0, "ng-template", 10)(14, ChangePasswordPage_ng_template_14_Template, 2, 0, "ng-template", 11)(15, ChangePasswordPage_ng_template_15_Template, 2, 0, "ng-template", 12)(16, ChangePasswordPage_ng_template_16_Template, 1, 1, "ng-template", 13);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](17, "div", 14);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](18, "input", 15);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](19, "w-input-hidden-icon-swap", 16);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("showChange", function ChangePasswordPage_Template_w_input_hidden_icon_swap_showChange_19_listener($event) {
        return ctx.inputPwdContentShow = $event;
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipe"](20, "color");
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](21, "div", 17);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](22, "input", 18);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](23, "w-input-hidden-icon-swap", 16);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("showChange", function ChangePasswordPage_Template_w_input_hidden_icon_swap_showChange_23_listener($event) {
        return ctx.inputContentShow = $event;
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipe"](24, "color");
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()()()();
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](25, "form", 19);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("ngSubmit", function ChangePasswordPage_Template_form_ngSubmit_25_listener() {
        return ctx.onSubmit();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](26, "div", 20)(27, "div", 21);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵi18n"](28, 22);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](29, "button", 23);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵi18n"](30, 24);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()()();
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("contentSafeArea", true)("contentBackground", "grey")("headerBackground", "grey");
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("formGroup", ctx.form);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpureFunction1"](26, _c24, _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipeBind1"](6, 18, ctx.pwd) || _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipeBind1"](7, 20, ctx.cpwd)));
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](4);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("wSwitchErrors", _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpureFunction2"](28, _c25, ctx.pwd, ctx.cpwd));
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](10);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("type", ctx.inputPwdContentShow ? "text" : "password");
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpureFunction1"](31, _c26, _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipeBind1"](20, 22, "subtext")));
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("show", ctx.inputPwdContentShow);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("type", ctx.inputContentShow ? "text" : "password");
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpureFunction1"](33, _c26, _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipeBind1"](24, 24, "subtext")));
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("show", ctx.inputContentShow);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("formGroup", ctx.form);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](4);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵclassProp"]("opacity-30", !ctx.form.valid);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("disabled", !ctx.form.valid);
    }
  },
  dependencies: [_modules_page_module__WEBPACK_IMPORTED_MODULE_6__.CommonPageModule, _libs_bnf_components_ripple_button_ripple_button_directive__WEBPACK_IMPORTED_MODULE_7__.RippleButtonDirective, _libs_bnf_directives_form_errors_directive__WEBPACK_IMPORTED_MODULE_8__.SwitchErrorsDirective, _libs_bnf_directives_form_errors_directive__WEBPACK_IMPORTED_MODULE_8__.SwitchCaseDirective, _libs_bnf_directives_form_errors_directive__WEBPACK_IMPORTED_MODULE_8__.SwitchDefaultDirective, _libs_bnf_directives_auto_complete_off_directive__WEBPACK_IMPORTED_MODULE_9__.AutoCompleteOffDirective, _angular_common__WEBPACK_IMPORTED_MODULE_15__.NgClass, _angular_forms__WEBPACK_IMPORTED_MODULE_14__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_14__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_14__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_14__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_14__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_14__.FormControlName, _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_10__.CommonPageComponent, _libs_bnf_pipes_errors_errors_pipe__WEBPACK_IMPORTED_MODULE_11__.ErrorsPipe, _pipes_color_color_pipe__WEBPACK_IMPORTED_MODULE_12__.ColorPipe, _components_input_hidden_icon_swap_input_hidden_icon_swap_component__WEBPACK_IMPORTED_MODULE_5__.InputHiddenIconSwapComponent],
  styles: ["/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsInNvdXJjZVJvb3QiOiIifQ== */"],
  changeDetection: 0
});
(0,tslib__WEBPACK_IMPORTED_MODULE_16__.__decorate)([ChangePasswordPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_16__.__metadata)("design:type", Object)], ChangePasswordPage.prototype, "inputPwdContentShow", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_16__.__decorate)([ChangePasswordPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_16__.__metadata)("design:type", Object)], ChangePasswordPage.prototype, "inputContentShow", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_16__.__decorate)([ChangePasswordPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_16__.__metadata)("design:type", Object)], ChangePasswordPage.prototype, "pwd", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_16__.__decorate)([ChangePasswordPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_16__.__metadata)("design:type", Object)], ChangePasswordPage.prototype, "cpwd", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_16__.__decorate)([_bnqkl_util_web_decorator__WEBPACK_IMPORTED_MODULE_3__.cacheGetter, (0,tslib__WEBPACK_IMPORTED_MODULE_16__.__metadata)("design:type", Object), (0,tslib__WEBPACK_IMPORTED_MODULE_16__.__metadata)("design:paramtypes", [])], ChangePasswordPage.prototype, "_currentPwd", null);
(0,tslib__WEBPACK_IMPORTED_MODULE_16__.__decorate)([ChangePasswordPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_16__.__metadata)("design:type", Object)], ChangePasswordPage.prototype, "form", void 0);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ChangePasswordPage);

/***/ }),

/***/ 11606:
/*!************************************************************!*\
  !*** ./libs/bnf/controllers/form-validators.controller.ts ***!
  \************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   FormValidatorsController: () => (/* binding */ FormValidatorsController)
/* harmony export */ });
/* harmony import */ var _bnqkl_framework_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @bnqkl/framework/core */ 63563);
/* harmony import */ var _bnqkl_util_web_extends_map__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @bnqkl/util-web/extends-map */ 37689);


/**
 * 页面表单扩展验证器
 *
 * > 因为涉及到FromControl的生命周期管理，所以这里需要使用Controller模式来获取组件/页面的生命周期
 *
 * 为了确保类型安全, 请遵循以下规则去定义验证器:
 * 1. 尽可能直接提供 $ValidatorFn,比如 `trimRequired(control: AbstractControl): $ValidationErrors | null {...}`
 * 2. 如果不能直接提供 $ValidatorFn, 那么作为工厂模式,必然要有参数传入,比如 `equals(leaderCtrl: AbstractControl): $ValidatorFn {...}`
 */
class FormValidatorsController {
  /**
   * 通过订阅原页面的生命周期，来对订阅的字段进行监听解除
   */
  constructor(comp) {
    /**
     * 判断两个数据字段相等的时，left===right 中 left的数据订阅
     */
    this._equalsLeaderMap = _bnqkl_util_web_extends_map__WEBPACK_IMPORTED_MODULE_1__.EasyMap.from({
      creater(ctrl) {
        const sub = {
          sub$: ctrl.valueChanges.subscribe(() => {
            for (const ctrl of sub.destControls) {
              ctrl.updateValueAndValidity();
            }
          }),
          destControls: new Set()
        };
        return sub;
      }
    });
    (0,_bnqkl_framework_core__WEBPACK_IMPORTED_MODULE_0__.addLifecycleMethods)(comp, 'ngOnDestroy', {
      origin: 'form-validator',
      method: () => {
        for (const {
          sub$
        } of this._equalsLeaderMap.values()) {
          sub$.unsubscribe();
        }
        this._equalsLeaderMap.clear();
      },
      order: Number.MAX_SAFE_INTEGER /* 最后才做这些事情 */
    });
  }
  /** 两个字段对比 相等就过 不相等返回 {equals:true} */
  equals(leaderCtrl) {
    const leader = this._equalsLeaderMap.forceGet(leaderCtrl);
    // pwdCtrl.val
    return follerCtrl => {
      leader.destControls.add(follerCtrl);
      if (leaderCtrl.value === follerCtrl.value) {
        return null;
      }
      return {
        equals: true
      };
    };
  }
  /** 是否包含空格 */
  whitespace(control) {
    const value = control.value;
    if (typeof value === 'string' && /\s/.test(value)) {
      return {
        whitespace: true
      };
    }
    return null;
  }
  /** required 变体, 左右两边不能包含空格 */
  trimRequired(control) {
    const value = control.value;
    if (typeof value === 'string' && value.trim().length === 0 || value == undefined) {
      return {
        trimRequired: true
      };
    }
    return null;
  }
}

/***/ }),

/***/ 47919:
/*!***************************************!*\
  !*** ./libs/bnf/controllers/index.ts ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   FormValidatorsController: () => (/* reexport safe */ _form_validators_controller__WEBPACK_IMPORTED_MODULE_0__.FormValidatorsController),
/* harmony export */   PageReturnController: () => (/* reexport safe */ _page_return_controller__WEBPACK_IMPORTED_MODULE_1__.PageReturnController)
/* harmony export */ });
/* harmony import */ var _form_validators_controller__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./form-validators.controller */ 11606);
/* harmony import */ var _page_return_controller__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./page-return.controller */ 62893);



/***/ }),

/***/ 62893:
/*!********************************************************!*\
  !*** ./libs/bnf/controllers/page-return.controller.ts ***!
  \********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   PageReturnController: () => (/* binding */ PageReturnController)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 54106);
/* harmony import */ var _bnqkl_util_web_decorator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @bnqkl/util-web/decorator */ 18112);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs */ 19177);



/**
 * 页面数据返回值的订阅功能
 * > Controller 必须在构造函数期间执行
 */
class PageReturnController {
  /** 继承日志 */
  get console() {
    return this.fromPage.console;
  }
  /**
   * 传入源页面与目标页面的构造函数，并通过订阅原页面的生命周期，来初始化对路由的订阅
   * 这里依赖 ion-router-outlet 来获取跳转过去的页面
   * 注：该监听返回是全触发（只要页面没被销毁掉不管页面是否处于激活状态）
   * @param specific 用于指定fromPage触发（需要手动指定），业务需要
   */
  constructor(fromPage, toPageCtor, specific = false) {
    this.fromPage = fromPage;
    /** 当前定阅过的页面 */
    this._toPages = new WeakSet();
    /**
     * 订阅到的返回内容，
     * 类型由对应页面的 returnValue$ 的定义决定
     */
    this.pageReturn$ = new rxjs__WEBPACK_IMPORTED_MODULE_1__.Subject();
    const {
      nav
    } = fromPage;
    fromPage.takeUntilDestroy(nav.pageActiveState$).subscribe(event => {
      /// 只监听新激活的页面
      if (event.type !== 'activate') {
        return;
      }
      const toPage = event.target;
      if (toPage instanceof toPageCtor &&
      // 去重
      this._toPages.has(toPage) === false) {
        if (toPage.returnValue$ === undefined) {
          return;
        }
        this._toPages.add(toPage);
        if (specific) {
          var _toPage$specificRetur;
          (_toPage$specificRetur = toPage.specificReturnPages) === null || _toPage$specificRetur === void 0 || _toPage$specificRetur.add(fromPage);
        }
        fromPage.takeUntilDestroy(toPage.returnValue$).subscribe({
          next: data => {
            /// 这里不用判断specific
            if (toPage.specificReturnPages && toPage.specificReturnPages.size) {
              /// 如果有写入，那么就只需要触发相对应页面就行
              toPage.specificReturnPages.has(fromPage) && this.pageReturn$.next(data);
              return;
            }
            this.pageReturn$.next(data);
          },
          complete: () => {
            var _toPage$specificRetur2;
            // 释放内存引用
            (_toPage$specificRetur2 = toPage.specificReturnPages) === null || _toPage$specificRetur2 === void 0 || _toPage$specificRetur2.delete(fromPage);
            return this._toPages.delete(toPage);
          }
        });
      }
    });
  }
}
(0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([_bnqkl_util_web_decorator__WEBPACK_IMPORTED_MODULE_0__.cacheGetter, (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__metadata)("design:type", Object), (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__metadata)("design:paramtypes", [])], PageReturnController.prototype, "console", null);

/***/ })

}]);
//# sourceMappingURL=default-apps_wallet_src_pages_mnemonic_pages_change-password_change-password_component_ts.js.map