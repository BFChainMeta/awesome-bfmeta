"use strict";
(self["webpackChunkwallet"] = self["webpackChunkwallet"] || []).push([["default-apps_wallet_src_pages_scanner_scanner_component_ts"],{

/***/ 41405:
/*!************************************************************!*\
  !*** ./apps/wallet/src/pages/scanner/scanner.component.ts ***!
  \************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   QRCODE_PROTOCAL_TYPE: () => (/* binding */ QRCODE_PROTOCAL_TYPE),
/* harmony export */   ScannerPage: () => (/* binding */ ScannerPage),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 52542);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! tslib */ 90505);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/core */ 61039);
/* harmony import */ var _bnqkl_util_web_extends_promise__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @bnqkl/util-web/extends-promise */ 87778);
/* harmony import */ var _modules_page_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ~modules/page.module */ 77538);
/* harmony import */ var _environments_index__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ~environments/index */ 40014);
/* harmony import */ var _bnqkl_framework_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @bnqkl/framework/core */ 63563);
/* harmony import */ var _bnqkl_framework_plugins_barcode_scanner__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @bnqkl/framework/plugins/barcode-scanner */ 5005);
/* harmony import */ var _bnqkl_framework_plugins_camera__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @bnqkl/framework/plugins/camera */ 92668);
/* harmony import */ var _bnqkl_framework_plugins_toast__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @bnqkl/framework/plugins/toast */ 18030);
/* harmony import */ var _libs_bnf_components_ripple_button_ripple_button_directive__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../../../libs/bnf/components/ripple-button/ripple-button.directive */ 16505);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/common */ 6729);
/* harmony import */ var _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../../../../libs/bnf/modules/page/common-page/common-page.component */ 62052);

var _class;













const _c0 = ["scanEle"];
const _c1 = ["canvas"];
function ScannerPage_canvas_4_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](0, "canvas", 14, 15);
  }
}
const _c6 = a0 => ({
  "absolute top-0 flex h-full w-full items-center justify-center overflow-hidden": a0
});
/** 二维码内容类型 */
var QRCODE_PROTOCAL_TYPE;
(function (QRCODE_PROTOCAL_TYPE) {
  /** 地址 */
  QRCODE_PROTOCAL_TYPE["ADDRESS"] = "address";
})(QRCODE_PROTOCAL_TYPE || (QRCODE_PROTOCAL_TYPE = {}));
/**
 * 扫一扫页面
 * 传参类型 { scanType: SUPPORTED_FORMAT; cameraDirection: CAMERA_DIRECTION; }
 */
class ScannerPage extends _modules_page_module__WEBPACK_IMPORTED_MODULE_2__.CommonPageBase {
  constructor() {
    super(...arguments);
    this.DWEB_APP = _environments_index__WEBPACK_IMPORTED_MODULE_3__.environment.DWEB_APP;
    /** 背景色 */
    this.contentBackground = 'black';
    /** 扫描中 */
    this._scanning = false;
    /** 页面返回值的类型 */
    this.returnValue$ = new _modules_page_module__WEBPACK_IMPORTED_MODULE_2__.PageReturnValue();
    /** 特定pageReturn收集器 */
    this.specificReturnPages = new Set();
    /** 是否显示canvas元素 */
    this.showCanvas = false;
    /** 条形码解析器 */
    this._qrCodeService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_10__.inject)(_bnqkl_framework_core__WEBPACK_IMPORTED_MODULE_4__.QrCodeDecoderService);
    /** 退出页面时间 单位：秒 */
    this._exitSeconds = 60;
  }
  /** 打开相机 */
  beforeOpenCamera() {
    var _this = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      // 等待300ms, 因为此时页面正处于切换的过程中
      yield (0,_bnqkl_util_web_extends_promise__WEBPACK_IMPORTED_MODULE_1__.sleep)(500);
      // 设置webview背景透明
      yield _bnqkl_framework_plugins_barcode_scanner__WEBPACK_IMPORTED_MODULE_5__.BarcodeScanner.hideBackground();
      // 设置页面背景透明 需要在此之前设置webView背景不透明，这样就不会出现打开摄像头时出现透明闪烁
      _this.contentBackground = 'transparent';
    })();
  }
  /**
   * 将body的背景色设置为透明
   */
  setBodyEleBgTransparent() {
    document.body.style.background = 'transparent';
  }
  /** 页面唤醒，重启定时器 */
  pageResume() {
    this._resetExitTimeout();
  }
  /**
   * 开始扫描界面
   */
  _startScanner() {
    var _this2 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      if (_this2._scanning) {
        return;
      }
      _this2._scanning = true;
      if (_environments_index__WEBPACK_IMPORTED_MODULE_3__.environment.DWEB_APP) {
        try {
          const scanEle = _this2.scanEleRef.nativeElement;
          const res = yield scanEle.startScanning();
          // 解析扫描内容
          if (res.hasContent == true) {
            _this2._handleScanRes(res.content[0]);
          }
        } catch (err) {
          _this2.console.error(err);
          _this2._exitPage();
        }
      } else {
        _this2._scanning = true;
        // 能够进入到这个页面，说明已经请求过权限了，所以这里可以直接启用扫一扫
        const params = _this2._data;
        _this2.text = params.text ? params.text : "\u6383\u63CF\u4E8C\u7DAD\u78BC";
        try {
          // 设定一个定时器，限定时间内，如果无解析动作，那么自动返回上一级页面
          _this2._resetExitTimeout();
          // 准备扫描
          yield _bnqkl_framework_plugins_barcode_scanner__WEBPACK_IMPORTED_MODULE_5__.BarcodeScanner.prepare(params.scanType, params.cameraDirection);
          yield _this2.beforeOpenCamera();
          // 开始扫描
          const scanContent = yield _bnqkl_framework_plugins_barcode_scanner__WEBPACK_IMPORTED_MODULE_5__.BarcodeScanner.startScan(params.scanType, params.cameraDirection);
          // 扫描出结果了，那么清除定时器
          _this2._clearTimeout();
          // 解析扫描内容
          if (scanContent !== undefined) {
            _this2._handleScanRes(scanContent);
          }
        } catch (err) {
          _this2.console.error(err);
          // 停止扫描
          _bnqkl_framework_plugins_barcode_scanner__WEBPACK_IMPORTED_MODULE_5__.BarcodeScanner.stopScan();
        } finally {
          // 扫描完成
          _this2._scanning = false;
        }
      }
    })();
  }
  /**
   * 解析扫面后内容
   * @TODU 后期也许会有解析url，或者参数的情况，目前只考虑字符串
   * @param scanContent
   */
  _handleScanRes(scanContent) {
    var _this3 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      yield (0,_bnqkl_util_web_extends_promise__WEBPACK_IMPORTED_MODULE_1__.sleep)(150);
      let result = scanContent;
      try {
        result = JSON.parse(scanContent);
      } catch (err) {
        _this3.console.warn(err, result);
      } finally {
        // 路由返回之前关闭扫描
        _this3.returnValue$.next(result);
        _this3._exitPage();
      }
    })();
  }
  /**
   * 退出扫描页面
   */
  _exitPage() {
    if (_environments_index__WEBPACK_IMPORTED_MODULE_3__.environment.DWEB_APP) {
      const scanEle = this.scanEleRef.nativeElement;
      scanEle.stopScanning();
    }
    _bnqkl_framework_plugins_barcode_scanner__WEBPACK_IMPORTED_MODULE_5__.BarcodeScanner.stopScan();
    this.nav.back();
  }
  /**
   * 页面销毁时：
   * 1. 停止扫描
   * 2. 恢复导航栏背景色
   */
  recover() {
    var _this4 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      if (_environments_index__WEBPACK_IMPORTED_MODULE_3__.environment.DWEB_APP) {
        const scanEle = _this4.scanEleRef.nativeElement;
        scanEle.stopScanning();
      }
      // 页面销毁前停止扫描
      yield _bnqkl_framework_plugins_barcode_scanner__WEBPACK_IMPORTED_MODULE_5__.BarcodeScanner.stopScan();
      // 页面销毁前停止扫描
      yield _bnqkl_framework_plugins_barcode_scanner__WEBPACK_IMPORTED_MODULE_5__.BarcodeScanner.stopScan();
      // 恢复body的背景色
      document.body.style.backgroundColor = '';
      // 清除定时器
      _this4._clearTimeout();
    })();
  }
  /** 打开相册 */
  openPhotoLibrary() {
    var _this5 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      // 打开相册时，清除定时器
      _this5._clearTimeout();
      // 从当前系统选取图片 开发环境于真机环境不同，需要区分
      const image = yield _bnqkl_framework_plugins_camera__WEBPACK_IMPORTED_MODULE_6__.Camera.pickPhoto();
      if (image.webPath) {
        _this5.showCanvas = true;
        _this5.cdRef.detectChanges();
        yield (0,_bnqkl_util_web_extends_promise__WEBPACK_IMPORTED_MODULE_1__.sleep)(0);
        _this5._parseSingleImage(image.webPath);
      }
    })();
  }
  /**
   * 解析图片
   * @param path 图片路径
   */
  _parseSingleImage(path) {
    var _this6 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      if (_this6._canvas) {
        // 单张图片解析模式
        const canvas = _this6._canvas.nativeElement;
        const ctx = canvas.getContext('2d');
        const image = yield new Promise((reslove, reject) => {
          const img = new Image();
          img.onload = () => {
            reslove(img);
          };
          img.onerror = reject;
          img.src = path;
        });
        const {
          width,
          height
        } = image;
        canvas.width = width;
        canvas.height = height;
        const x = (canvas.width - width) / 2;
        const y = (canvas.height - height) / 2;
        // 绘制图片
        ctx.drawImage(image, x, y, width, height);
        const imgData = ctx.getImageData(x, y, width, height);
        try {
          const code = yield _this6._qrCodeService.decodeImageData(imgData);
          if (code.text) {
            return yield _this6._handleScanRes(code.text);
          }
          _bnqkl_framework_plugins_toast__WEBPACK_IMPORTED_MODULE_7__.Toast.show("\u672A\u627E\u5230\u4E8C\u7DAD\u78BC");
          _this6._exitPageConfirm();
        } catch (err) {
          _bnqkl_framework_plugins_toast__WEBPACK_IMPORTED_MODULE_7__.Toast.show("\u6383\u63CF\u5716\u7247\u5931\u6557");
          _this6.console.error(err);
          _this6._exitPageConfirm("\u5716\u7247\u5206\u6790\u932F\u8AA4");
        } finally {
          yield (0,_bnqkl_util_web_extends_promise__WEBPACK_IMPORTED_MODULE_1__.sleep)(500);
          // 不是二维码图片，那么清除画布
          ctx.clearRect(0, 0, width, height);
          _this6.showCanvas = false;
        }
      }
    })();
  }
  /**
   * 重置倒计时
   */
  _resetExitTimeout() {
    var _this7 = this;
    this._clearTimeout();
    this._exitTimeout = setTimeout( /*#__PURE__*/(0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this7._clearTimeout();
      if (_this7.nav.canGoBack) {
        _this7._exitPageConfirm();
      }
    }), this._exitSeconds * 1000);
  }
  /**
   * 清楚倒计时
   * @param timeout 倒计时实例
   */
  _clearTimeout() {
    if (this._exitTimeout) {
      clearTimeout(this._exitTimeout);
    }
  }
  /**
   * 退出页面确认框
   */
  _exitPageConfirm(message = "\u672A\u627E\u5230\u4E8C\u7DAD\u78BC") {
    var _this8 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const scanAgain = yield _this8.confirm({
        bodyMessage: message,
        confirmText: "\u518D\u6B21\u6383\u63CF",
        cancelText: "\u9000\u51FA"
      });
      if (scanAgain === true) {
        _this8._resetExitTimeout();
      } else {
        yield (0,_bnqkl_util_web_extends_promise__WEBPACK_IMPORTED_MODULE_1__.sleep)(100);
        _this8._exitPage();
      }
    })();
  }
}
_class = ScannerPage;
_class.ɵfac = /*@__PURE__*/(() => {
  let ɵScannerPage_BaseFactory;
  return function ScannerPage_Factory(t) {
    return (ɵScannerPage_BaseFactory || (ɵScannerPage_BaseFactory = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵgetInheritedFactory"](_class)))(t || _class);
  };
})();
_class.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵdefineComponent"]({
  type: _class,
  selectors: [["w-scanner-page"]],
  viewQuery: function ScannerPage_Query(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵviewQuery"](_c0, 7);
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵviewQuery"](_c1, 5);
    }
    if (rf & 2) {
      let _t;
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵloadQuery"]()) && (ctx.scanEleRef = _t.first);
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵloadQuery"]()) && (ctx._canvas = _t.first);
    }
  },
  outputs: {
    returnValue$: "returnValue$"
  },
  standalone: true,
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵInheritDefinitionFeature"], _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵStandaloneFeature"]],
  decls: 15,
  vars: 12,
  consts: () => {
    let i18n_2;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_SCAN$$APPS_WALLET_SRC_PAGES_SCANNER_SCANNER_COMPONENT_TS_3 = goog.getMsg("Scan");
      i18n_2 = MSG_EXTERNAL_SCAN$$APPS_WALLET_SRC_PAGES_SCANNER_SCANNER_COMPONENT_TS_3;
    } else {
      i18n_2 = "\u6383\u63CF";
    }
    let i18n_4;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_ALBUM$$APPS_WALLET_SRC_PAGES_SCANNER_SCANNER_COMPONENT_TS_5 = goog.getMsg("Album");
      i18n_4 = MSG_EXTERNAL_ALBUM$$APPS_WALLET_SRC_PAGES_SCANNER_SCANNER_COMPONENT_TS_5;
    } else {
      i18n_4 = "\u76F8\u518A";
    }
    return [["headerTitle", i18n_2, 3, "headerBackground", "headerOpacity", "titleColor", "headerButtonColor", "contentBackground", "pageBackground", "contentClass"], ["bnRippleButton", "", "endMenu", "", 3, "click"], i18n_4, [1, "absolute", "top-0", "flex", "h-full", "w-full", "items-center", "justify-center", "overflow-hidden"], ["class", "source-canvas absolute", 4, "ngIf"], [1, "mask", "relative", "flex", "h-full", "w-full", "justify-center"], [1, "scan-line"], [1, "scan-border", "top-left", "absolute", "left-0", "top-0"], [1, "scan-border", "top-right", "absolute", "right-0", "top-0"], [1, "scan-border", "bottom-left", "absolute", "bottom-0", "left-0"], [1, "scan-border", "bottom-right", "absolute", "bottom-0", "right-0"], [1, "tip", "absolute", "text-sm", "font-semibold", "text-white"], [3, "ngClass"], ["scanEle", ""], [1, "source-canvas", "absolute"], ["canvas", ""]];
  },
  template: function ScannerPage_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "common-page", 0)(1, "button", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("click", function ScannerPage_Template_button_click_1_listener() {
        return ctx.openPhotoLibrary();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵi18n"](2, 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](3, "div", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](4, ScannerPage_canvas_4_Template, 2, 0, "canvas", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](5, "div", 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](6, "div", 6)(7, "div", 7)(8, "div", 8)(9, "div", 9)(10, "div", 10);
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](11, "div", 11);
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](12);
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()()();
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](13, "dweb-barcode-scanning", 12, 13);
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("headerBackground", "black")("headerOpacity", 0.5)("titleColor", "white")("headerButtonColor", "light")("contentBackground", ctx.contentBackground)("pageBackground", "transparent")("contentClass", "h-full w-full");
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](4);
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", ctx.showCanvas);
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](8);
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtextInterpolate"](ctx.text);
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpureFunction1"](10, _c6, ctx.DWEB_APP));
    }
  },
  dependencies: [_modules_page_module__WEBPACK_IMPORTED_MODULE_2__.CommonPageModule, _libs_bnf_components_ripple_button_ripple_button_directive__WEBPACK_IMPORTED_MODULE_8__.RippleButtonDirective, _angular_common__WEBPACK_IMPORTED_MODULE_11__.NgClass, _angular_common__WEBPACK_IMPORTED_MODULE_11__.NgIf, _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_9__.CommonPageComponent],
  styles: [".source-canvas[_ngcontent-%COMP%] {\n  top: calc(50% - 32px);\n  transform: translateY(-50%);\n  width: 100%;\n}\n\n.mask[_ngcontent-%COMP%] {\n  --mask-color: rgba(0, 0, 0, 0.5);\n  --carved-width: 16.5rem;\n  --border-vertical-width: calc(50vh - var(--carved-width) / 2);\n  --border-horizontal-width: calc(50vw - var(--carved-width) / 2);\n  border-style: solid;\n  border-color: var(--mask-color);\n  border-width: var(--border-vertical-width) var(--border-horizontal-width);\n  box-shadow: inset 0.0625rem 0 0 0.1875rem var(--mask-color);\n}\n.mask[_ngcontent-%COMP%]   .scan-line[_ngcontent-%COMP%] {\n  width: 100%;\n  height: 0.25rem;\n  border-radius: 0.125rem;\n  transform: scale(0.9, 0.3);\n  position: absolute;\n  animation-name: _ngcontent-%COMP%_scan-window;\n  animation-fill-mode: both;\n  animation-duration: 2s;\n  animation-iteration-count: infinite;\n  animation-timing-function: ease-in-out;\n  background-image: linear-gradient(90deg, rgba(255, 255, 255, 0.1), rgb(255, 255, 255) 50%, rgba(255, 255, 255, 0.1));\n}\n@keyframes _ngcontent-%COMP%_scan-window {\n  0% {\n    top: 0;\n    opacity: 0;\n  }\n  30% {\n    opacity: 1;\n  }\n  70% {\n    opacity: 1;\n  }\n  100% {\n    top: 100%;\n    opacity: 0;\n  }\n}\n.mask[_ngcontent-%COMP%]   .scan-border[_ngcontent-%COMP%] {\n  width: 2.5rem;\n  height: 2.5rem;\n  --border-color: #fff;\n  --border-width: 0.25rem;\n}\n.mask[_ngcontent-%COMP%]   .scan-border.top-left[_ngcontent-%COMP%] {\n  border-top: solid var(--border-width) var(--border-color);\n  border-left: solid var(--border-width) var(--border-color);\n}\n.mask[_ngcontent-%COMP%]   .scan-border.top-right[_ngcontent-%COMP%] {\n  border-top: solid var(--border-width) var(--border-color);\n  border-right: solid var(--border-width) var(--border-color);\n}\n.mask[_ngcontent-%COMP%]   .scan-border.bottom-left[_ngcontent-%COMP%] {\n  border-bottom: solid var(--border-width) var(--border-color);\n  border-left: solid var(--border-width) var(--border-color);\n}\n.mask[_ngcontent-%COMP%]   .scan-border.bottom-right[_ngcontent-%COMP%] {\n  border-bottom: solid var(--border-width) var(--border-color);\n  border-right: solid var(--border-width) var(--border-color);\n}\n\n.tip[_ngcontent-%COMP%] {\n  bottom: -2.8125rem;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL2FwcHMvd2FsbGV0L3NyYy9wYWdlcy9zY2FubmVyL3NjYW5uZXIuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxxQkFBQTtFQUNBLDJCQUFBO0VBQ0EsV0FBQTtBQUNGOztBQUNBO0VBQ0UsZ0NBQUE7RUFDQSx1QkFBQTtFQUNBLDZEQUFBO0VBQ0EsK0RBQUE7RUFFQSxtQkFBQTtFQUNBLCtCQUFBO0VBQ0EseUVBQUE7RUFDQSwyREFBQTtBQUNGO0FBQ0U7RUFDRSxXQUFBO0VBQ0EsZUFBQTtFQUNBLHVCQUFBO0VBQ0EsMEJBQUE7RUFDQSxrQkFBQTtFQUNBLDJCQUFBO0VBQ0EseUJBQUE7RUFDQSxzQkFBQTtFQUNBLG1DQUFBO0VBQ0Esc0NBQUE7RUFDQSxvSEFBQTtBQUNKO0FBQ0U7RUFDRTtJQUNFLE1BQUE7SUFDQSxVQUFBO0VBQ0o7RUFDRTtJQUNFLFVBQUE7RUFDSjtFQUNFO0lBQ0UsVUFBQTtFQUNKO0VBQ0U7SUFDRSxTQUFBO0lBQ0EsVUFBQTtFQUNKO0FBQ0Y7QUFFRTtFQUNFLGFBQUE7RUFDQSxjQUFBO0VBQ0Esb0JBQUE7RUFDQSx1QkFBQTtBQUFKO0FBQ0k7RUFDRSx5REFBQTtFQUNBLDBEQUFBO0FBQ047QUFDSTtFQUNFLHlEQUFBO0VBQ0EsMkRBQUE7QUFDTjtBQUNJO0VBQ0UsNERBQUE7RUFDQSwwREFBQTtBQUNOO0FBQ0k7RUFDRSw0REFBQTtFQUNBLDJEQUFBO0FBQ047O0FBR0E7RUFDRSxrQkFBQTtBQUFGIiwic291cmNlc0NvbnRlbnQiOlsiLnNvdXJjZS1jYW52YXMge1xyXG4gIHRvcDogY2FsYyg1MCUgLSAzMnB4KTtcclxuICB0cmFuc2Zvcm06IHRyYW5zbGF0ZVkoLTUwJSk7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbn1cclxuLm1hc2sge1xyXG4gIC0tbWFzay1jb2xvcjogcmdiYSgwLCAwLCAwLCAwLjUpO1xyXG4gIC0tY2FydmVkLXdpZHRoOiAxNi41cmVtO1xyXG4gIC0tYm9yZGVyLXZlcnRpY2FsLXdpZHRoOiBjYWxjKDUwdmggLSB2YXIoLS1jYXJ2ZWQtd2lkdGgpIC8gMik7XHJcbiAgLS1ib3JkZXItaG9yaXpvbnRhbC13aWR0aDogY2FsYyg1MHZ3IC0gdmFyKC0tY2FydmVkLXdpZHRoKSAvIDIpO1xyXG5cclxuICBib3JkZXItc3R5bGU6IHNvbGlkO1xyXG4gIGJvcmRlci1jb2xvcjogdmFyKC0tbWFzay1jb2xvcik7XHJcbiAgYm9yZGVyLXdpZHRoOiB2YXIoLS1ib3JkZXItdmVydGljYWwtd2lkdGgpIHZhcigtLWJvcmRlci1ob3Jpem9udGFsLXdpZHRoKTtcclxuICBib3gtc2hhZG93OiBpbnNldCAwLjA2MjVyZW0gMCAwIDAuMTg3NXJlbSB2YXIoLS1tYXNrLWNvbG9yKTtcclxuXHJcbiAgLnNjYW4tbGluZSB7XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICAgIGhlaWdodDogMC4yNXJlbTtcclxuICAgIGJvcmRlci1yYWRpdXM6IDAuMTI1cmVtO1xyXG4gICAgdHJhbnNmb3JtOiBzY2FsZSgwLjksIDAuMyk7XHJcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICBhbmltYXRpb24tbmFtZTogc2Nhbi13aW5kb3c7XHJcbiAgICBhbmltYXRpb24tZmlsbC1tb2RlOiBib3RoO1xyXG4gICAgYW5pbWF0aW9uLWR1cmF0aW9uOiAycztcclxuICAgIGFuaW1hdGlvbi1pdGVyYXRpb24tY291bnQ6IGluZmluaXRlO1xyXG4gICAgYW5pbWF0aW9uLXRpbWluZy1mdW5jdGlvbjogZWFzZS1pbi1vdXQ7XHJcbiAgICBiYWNrZ3JvdW5kLWltYWdlOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsIHJnYigyNTUgMjU1IDI1NSAvIDEwJSksIHJnYigyNTUgMjU1IDI1NSkgNTAlLCByZ2IoMjU1IDI1NSAyNTUgLyAxMCUpKTtcclxuICB9XHJcbiAgQGtleWZyYW1lcyBzY2FuLXdpbmRvdyB7XHJcbiAgICAwJSB7XHJcbiAgICAgIHRvcDogMDtcclxuICAgICAgb3BhY2l0eTogMDtcclxuICAgIH1cclxuICAgIDMwJSB7XHJcbiAgICAgIG9wYWNpdHk6IDE7XHJcbiAgICB9XHJcbiAgICA3MCUge1xyXG4gICAgICBvcGFjaXR5OiAxO1xyXG4gICAgfVxyXG4gICAgMTAwJSB7XHJcbiAgICAgIHRvcDogMTAwJTtcclxuICAgICAgb3BhY2l0eTogMDtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIC5zY2FuLWJvcmRlciB7XHJcbiAgICB3aWR0aDogMi41cmVtO1xyXG4gICAgaGVpZ2h0OiAyLjVyZW07XHJcbiAgICAtLWJvcmRlci1jb2xvcjogI2ZmZjtcclxuICAgIC0tYm9yZGVyLXdpZHRoOiAwLjI1cmVtO1xyXG4gICAgJi50b3AtbGVmdCB7XHJcbiAgICAgIGJvcmRlci10b3A6IHNvbGlkIHZhcigtLWJvcmRlci13aWR0aCkgdmFyKC0tYm9yZGVyLWNvbG9yKTtcclxuICAgICAgYm9yZGVyLWxlZnQ6IHNvbGlkIHZhcigtLWJvcmRlci13aWR0aCkgdmFyKC0tYm9yZGVyLWNvbG9yKTtcclxuICAgIH1cclxuICAgICYudG9wLXJpZ2h0IHtcclxuICAgICAgYm9yZGVyLXRvcDogc29saWQgdmFyKC0tYm9yZGVyLXdpZHRoKSB2YXIoLS1ib3JkZXItY29sb3IpO1xyXG4gICAgICBib3JkZXItcmlnaHQ6IHNvbGlkIHZhcigtLWJvcmRlci13aWR0aCkgdmFyKC0tYm9yZGVyLWNvbG9yKTtcclxuICAgIH1cclxuICAgICYuYm90dG9tLWxlZnQge1xyXG4gICAgICBib3JkZXItYm90dG9tOiBzb2xpZCB2YXIoLS1ib3JkZXItd2lkdGgpIHZhcigtLWJvcmRlci1jb2xvcik7XHJcbiAgICAgIGJvcmRlci1sZWZ0OiBzb2xpZCB2YXIoLS1ib3JkZXItd2lkdGgpIHZhcigtLWJvcmRlci1jb2xvcik7XHJcbiAgICB9XHJcbiAgICAmLmJvdHRvbS1yaWdodCB7XHJcbiAgICAgIGJvcmRlci1ib3R0b206IHNvbGlkIHZhcigtLWJvcmRlci13aWR0aCkgdmFyKC0tYm9yZGVyLWNvbG9yKTtcclxuICAgICAgYm9yZGVyLXJpZ2h0OiBzb2xpZCB2YXIoLS1ib3JkZXItd2lkdGgpIHZhcigtLWJvcmRlci1jb2xvcik7XHJcbiAgICB9XHJcbiAgfVxyXG59XHJcbi50aXAge1xyXG4gIGJvdHRvbTogLTIuODEyNXJlbTtcclxufVxyXG4iXSwic291cmNlUm9vdCI6IiJ9 */"],
  changeDetection: 0
});
(0,tslib__WEBPACK_IMPORTED_MODULE_12__.__decorate)([ScannerPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_12__.__metadata)("design:type", String)], ScannerPage.prototype, "contentBackground", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_12__.__decorate)([ScannerPage.QueryParams(), (0,tslib__WEBPACK_IMPORTED_MODULE_12__.__metadata)("design:type", Object)], ScannerPage.prototype, "_data", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_12__.__decorate)([ScannerPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_12__.__metadata)("design:type", String)], ScannerPage.prototype, "text", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_12__.__decorate)([ScannerPage.OnInit(), (0,tslib__WEBPACK_IMPORTED_MODULE_12__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_12__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_12__.__metadata)("design:returntype", void 0)], ScannerPage.prototype, "setBodyEleBgTransparent", null);
(0,tslib__WEBPACK_IMPORTED_MODULE_12__.__decorate)([ScannerPage.OnResume(), (0,tslib__WEBPACK_IMPORTED_MODULE_12__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_12__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_12__.__metadata)("design:returntype", void 0)], ScannerPage.prototype, "pageResume", null);
(0,tslib__WEBPACK_IMPORTED_MODULE_12__.__decorate)([ScannerPage.OnReady(), (0,tslib__WEBPACK_IMPORTED_MODULE_12__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_12__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_12__.__metadata)("design:returntype", Promise)], ScannerPage.prototype, "_startScanner", null);
(0,tslib__WEBPACK_IMPORTED_MODULE_12__.__decorate)([ScannerPage.OnDestroy(), (0,tslib__WEBPACK_IMPORTED_MODULE_12__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_12__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_12__.__metadata)("design:returntype", Promise)], ScannerPage.prototype, "recover", null);
(0,tslib__WEBPACK_IMPORTED_MODULE_12__.__decorate)([ScannerPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_12__.__metadata)("design:type", Object)], ScannerPage.prototype, "showCanvas", void 0);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ScannerPage);

/***/ })

}]);
//# sourceMappingURL=default-apps_wallet_src_pages_scanner_scanner_component_ts.js.map