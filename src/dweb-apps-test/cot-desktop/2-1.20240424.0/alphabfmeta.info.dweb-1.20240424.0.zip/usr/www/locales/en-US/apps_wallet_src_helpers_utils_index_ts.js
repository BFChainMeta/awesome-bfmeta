"use strict";
(self["webpackChunkwallet"] = self["webpackChunkwallet"] || []).push([["apps_wallet_src_helpers_utils_index_ts"],{

/***/ 6596:
/*!************************************************!*\
  !*** ./apps/wallet/src/helpers/utils/index.ts ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   isMobile: () => (/* binding */ isMobile)
/* harmony export */ });
/* harmony import */ var _plaoc_is_dweb__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @plaoc/is-dweb */ 69899);
/* harmony import */ var _environments_index__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ~environments/index */ 40014);


/** 判断是否是移动端 */
const isMobile = () => {
  if (_environments_index__WEBPACK_IMPORTED_MODULE_1__.environment.DWEB_APP) {
    return (0,_plaoc_is_dweb__WEBPACK_IMPORTED_MODULE_0__.isMobile)();
  } else {
    return true;
  }
};

/***/ }),

/***/ 69899:
/*!*****************************************************************************************!*\
  !*** ./node_modules/.pnpm/@plaoc+is-dweb@0.1.0/node_modules/@plaoc/is-dweb/esm/main.js ***!
  \*****************************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   dwebTarget: () => (/* binding */ dwebTarget),
/* harmony export */   isDweb: () => (/* binding */ isDweb),
/* harmony export */   isMobile: () => (/* binding */ isMobile)
/* harmony export */ });
/**
 * 判断是不是dweb
 * * @returns boolean
 */
const isDweb = () => {
  const isDweb = self.navigator.userAgent.includes("Dweb");
  // @ts-ignore
  const isPlaoc = self.__native_close_watcher_kit__ !== void 0;
  if (isDweb || isPlaoc) {
    return true;
  }
  const userAgentData = self.navigator.userAgentData;
  if (!userAgentData) {
    return false;
  }
  const brands = userAgentData.brands.filter(value => {
    return value.brand === "DwebBrowser";
  });
  return Array.isArray(brands) && brands.length > 0;
};
/**
 * 判断dweb大版本
 * @returns boolean
 */
const dwebTarget = () => {
  if (isDweb()) {
    const userAgentData = self.navigator.userAgentData;
    if (!userAgentData) {
      return 2.0;
    }
    const brands = userAgentData.brands.filter(value => {
      return value.brand === "jmm.browser.dweb";
    });
    if (Array.isArray(brands) && brands.length > 0) {
      return parseFloat(brands[0].version);
    }
  }
  return 1.0;
};
/**
 * 判断是否是移动端
 * @returns boolean
 */
const isMobile = () => {
  if (!navigator.userAgentData) {
    return true;
  }
  return !!navigator.userAgentData.mobile;
};

/***/ })

}]);
//# sourceMappingURL=apps_wallet_src_helpers_utils_index_ts.js.map