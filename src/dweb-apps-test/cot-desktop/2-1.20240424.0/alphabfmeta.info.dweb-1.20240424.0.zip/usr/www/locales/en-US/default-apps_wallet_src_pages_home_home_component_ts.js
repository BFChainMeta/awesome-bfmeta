"use strict";
(self["webpackChunkwallet"] = self["webpackChunkwallet"] || []).push([["default-apps_wallet_src_pages_home_home_component_ts"],{

/***/ 6596:
/*!************************************************!*\
  !*** ./apps/wallet/src/helpers/utils/index.ts ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   isMobile: () => (/* binding */ isMobile)
/* harmony export */ });
/* harmony import */ var _plaoc_is_dweb__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @plaoc/is-dweb */ 69899);
/* harmony import */ var _environments_index__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ~environments/index */ 40014);


/** 判断是否是移动端 */
const isMobile = () => {
  if (_environments_index__WEBPACK_IMPORTED_MODULE_1__.environment.DWEB_APP) {
    return (0,_plaoc_is_dweb__WEBPACK_IMPORTED_MODULE_0__.isMobile)();
  } else {
    return true;
  }
};

/***/ }),

/***/ 87552:
/*!******************************************************!*\
  !*** ./apps/wallet/src/pages/home/home.component.ts ***!
  \******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   HomePage: () => (/* binding */ HomePage),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 52542);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_49__ = __webpack_require__(/*! tslib */ 90505);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_43__ = __webpack_require__(/*! @angular/core */ 61039);
/* harmony import */ var _angular_material_button__WEBPACK_IMPORTED_MODULE_48__ = __webpack_require__(/*! @angular/material/button */ 12300);
/* harmony import */ var _angular_material_expansion__WEBPACK_IMPORTED_MODULE_44__ = __webpack_require__(/*! @angular/material/expansion */ 5101);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_47__ = __webpack_require__(/*! @angular/router */ 56776);
/* harmony import */ var _bnqkl_framework_animations__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @bnqkl/framework/animations */ 43127);
/* harmony import */ var _bnqkl_framework_controllers__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @bnqkl/framework/controllers */ 47919);
/* harmony import */ var _bnqkl_framework_helpers__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @bnqkl/framework/helpers */ 12169);
/* harmony import */ var _bnqkl_framework_plugins_browser__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @bnqkl/framework/plugins/browser */ 93173);
/* harmony import */ var _bnqkl_framework_plugins_network__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @bnqkl/framework/plugins/network */ 510);
/* harmony import */ var _bnqkl_util_web_extends_promise__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @bnqkl/util-web/extends-promise */ 87778);
/* harmony import */ var _bnqkl_wallet_base_services__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @bnqkl/wallet-base/services */ 62479);
/* harmony import */ var _bnqkl_wallet_base_services_wallet__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @bnqkl/wallet-base/services/wallet */ 20609);
/* harmony import */ var _bnqkl_wallet_base_services_wallet_bitcoin__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @bnqkl/wallet-base/services/wallet/bitcoin */ 59132);
/* harmony import */ var _bnqkl_wallet_base_services_wallet_chain__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @bnqkl/wallet-base/services/wallet/chain */ 27434);
/* harmony import */ var _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @bnqkl/wallet-base/services/wallet/chain-base */ 27187);
/* harmony import */ var _bnqkl_wallet_base_services_wallet_wallet__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @bnqkl/wallet-base/services/wallet/wallet */ 21789);
/* harmony import */ var _bnqkl_wallet_base_services_wallet_wallet_data_storage__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @bnqkl/wallet-base/services/wallet/wallet-data-storage */ 63024);
/* harmony import */ var _plaoc_is_dweb__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @plaoc/is-dweb */ 69899);
/* harmony import */ var _plaoc_plugins__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @plaoc/plugins */ 14680);
/* harmony import */ var _modules_page_module__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ~modules/page.module */ 77538);
/* harmony import */ var _pages_home_pages_home_add_token_home_add_token_component__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ~pages/home/pages/home-add-token/home-add-token.component */ 89539);
/* harmony import */ var _pages_mnemonic_pages_mnemonic_confirm_backup_mnemonic_confirm_backup_component__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ~pages/mnemonic/pages/mnemonic-confirm-backup/mnemonic-confirm-backup.component */ 91879);
/* harmony import */ var _pages_scanner_scanner_component__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ~pages/scanner/scanner.component */ 41405);
/* harmony import */ var _services_permission_permission_service__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ~services/permission/permission.service */ 26502);
/* harmony import */ var _pages_home_main_wallet_edit_home_main_wallet_edit_component__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! ./pages/home-main-wallet-edit/home-main-wallet-edit.component */ 22486);
/* harmony import */ var _pages_home_select_chain_address_home_select_chain_address_component__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! ./pages/home-select-chain-address/home-select-chain-address.component */ 15298);
/* harmony import */ var _pages_home_select_wallet_home_select_wallet_component__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! ./pages/home-select-wallet/home-select-wallet.component */ 57278);
/* harmony import */ var _pages_select_wallet_transation_select_wallet_transation_component__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! ./pages/select-wallet-transation/select-wallet-transation.component */ 96535);
/* harmony import */ var _pages_select_wallet_transation_select_wallet_transation_resolver__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! ./pages/select-wallet-transation/select-wallet-transation.resolver */ 13691);
/* harmony import */ var _helpers_utils__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! ~helpers/utils */ 6596);
/* harmony import */ var _libs_bnf_modules_bottom_sheet_components_bottom_sheet_component__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! ../../../../../libs/bnf/modules/bottom-sheet/components/bottom-sheet.component */ 94072);
/* harmony import */ var _libs_bnf_components_ripple_button_ripple_button_directive__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! ../../../../../libs/bnf/components/ripple-button/ripple-button.directive */ 16505);
/* harmony import */ var _libs_bnf_components_pull_to_refresh_pull_to_refresh_directive__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! ../../../../../libs/bnf/components/pull-to-refresh/pull-to-refresh.directive */ 97063);
/* harmony import */ var _libs_bnf_components_pull_to_refresh_pull_to_refresh_spinner_component__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(/*! ../../../../../libs/bnf/components/pull-to-refresh/pull-to-refresh-spinner.component */ 75387);
/* harmony import */ var _libs_bnf_components_infinite_scroll_infinite_scroll_spinner_component__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(/*! ../../../../../libs/bnf/components/infinite-scroll/infinite-scroll-spinner.component */ 66560);
/* harmony import */ var _libs_bnf_directives_click_to_copy_directive__WEBPACK_IMPORTED_MODULE_32__ = __webpack_require__(/*! ../../../../../libs/bnf/directives/click-to-copy.directive */ 46413);
/* harmony import */ var _libs_bnf_directives_auto_complete_off_directive__WEBPACK_IMPORTED_MODULE_33__ = __webpack_require__(/*! ../../../../../libs/bnf/directives/auto-complete-off.directive */ 66722);
/* harmony import */ var _libs_bnf_components_infinite_scroll_infinite_scroll_directive__WEBPACK_IMPORTED_MODULE_34__ = __webpack_require__(/*! ../../../../../libs/bnf/components/infinite-scroll/infinite-scroll.directive */ 10320);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_45__ = __webpack_require__(/*! @angular/common */ 6729);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_46__ = __webpack_require__(/*! @angular/forms */ 7820);
/* harmony import */ var _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_35__ = __webpack_require__(/*! ../../../../../libs/bnf/modules/page/common-page/common-page.component */ 62052);
/* harmony import */ var _components_icon_icon_component__WEBPACK_IMPORTED_MODULE_36__ = __webpack_require__(/*! ../../components/icon/icon.component */ 74703);
/* harmony import */ var _libs_bnf_components_loading_wrapper_loading_wrapper_component__WEBPACK_IMPORTED_MODULE_37__ = __webpack_require__(/*! ../../../../../libs/bnf/components/loading-wrapper/loading-wrapper.component */ 51263);
/* harmony import */ var _libs_bnf_pipes_number_format_number_format_pipe__WEBPACK_IMPORTED_MODULE_38__ = __webpack_require__(/*! ../../../../../libs/bnf/pipes/number-format/number-format.pipe */ 89873);
/* harmony import */ var _pipes_color_color_pipe__WEBPACK_IMPORTED_MODULE_39__ = __webpack_require__(/*! ../../pipes/color/color.pipe */ 76489);
/* harmony import */ var _libs_bnf_pipes_address_hidden_address_hidden_pipe__WEBPACK_IMPORTED_MODULE_40__ = __webpack_require__(/*! ../../../../../libs/bnf/pipes/address-hidden/address-hidden.pipe */ 35222);
/* harmony import */ var _libs_bnf_pipes_amountFixed_amount_fixed_pipe__WEBPACK_IMPORTED_MODULE_41__ = __webpack_require__(/*! ../../../../../libs/bnf/pipes/amountFixed/amount-fixed.pipe */ 44070);
/* harmony import */ var _pipes_chainIcon_chain_icon_pipe__WEBPACK_IMPORTED_MODULE_42__ = __webpack_require__(/*! ../../pipes/chainIcon/chain-icon.pipe */ 43040);

var _class;




















































const _c8 = a0 => ({
  "--color-1": a0
});
const _c9 = a0 => ({
  "rotate-90": a0
});
function HomePage_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r15 = _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵelementStart"](0, "button", 38);
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵlistener"]("click", function HomePage_Conditional_1_Template_button_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵrestoreView"](_r15);
      const ctx_r14 = _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵresetView"](ctx_r14.openSelectWallet());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵelement"](1, "img", 39);
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵelementStart"](2, "div", 40);
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵelement"](4, "w-icon", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵpipe"](5, "color");
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵproperty"]("src", ctx_r0.mainWalletInfo.headSculpture, _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵsanitizeUrl"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵtextInterpolate"](ctx_r0.mainWalletInfo.name);
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵpureFunction1"](8, _c8, _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵpipeBind1"](5, 6, "text-title")));
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵclassMap"](_angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵpureFunction1"](10, _c9, ctx_r0.isMobile));
  }
}
function HomePage_div_3_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵelementStart"](0, "div", 41);
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵelement"](1, "div", 42);
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵelementEnd"]();
  }
}
function HomePage_div_17_Template(rf, ctx) {
  if (rf & 1) {
    const _r17 = _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵelementStart"](0, "div", 43);
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵlistener"]("click", function HomePage_div_17_Template_div_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵrestoreView"](_r17);
      const ctx_r16 = _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵresetView"](ctx_r16.goBackup());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵelement"](1, "w-icon", 44);
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵpipe"](2, "color");
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵelementStart"](3, "span", 45);
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵi18n"](4, 46);
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵpureFunction1"](4, _c8, _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵpipeBind1"](2, 2, "error")));
  }
}
function HomePage_Conditional_19_Template(rf, ctx) {
  if (rf & 1) {
    const _r19 = _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵelementStart"](0, "button", 47);
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵlistener"]("click", function HomePage_Conditional_19_Template_button_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵrestoreView"](_r19);
      const ctx_r18 = _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵresetView"](ctx_r18.goToBitcoinAddressSettings());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵelement"](1, "w-icon", 48);
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵpipe"](2, "color");
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵpureFunction1"](4, _c8, _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵpipeBind1"](2, 2, "white/[0.6]")));
  }
}
function HomePage_div_25_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵelementStart"](0, "div", 49);
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵelement"](1, "span", 50);
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵelementStart"](2, "span", 51);
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵi18n"](3, 52);
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵelementEnd"]()();
  }
}
const _c16 = (a0, a1, a2) => ({
  "_asset-type-active": a0,
  "text-2xl font-semibold": a1,
  "pt-[4px] text-lg": a2
});
function HomePage_Conditional_44_Template(rf, ctx) {
  if (rf & 1) {
    const _r21 = _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵelementStart"](0, "h2", 53);
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵlistener"]("click", function HomePage_Conditional_44_Template_h2_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵrestoreView"](_r21);
      const ctx_r20 = _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵresetView"](ctx_r20.changeParentAssetType(ctx_r20.PARENT_ASSET_TYPE.ENTITY));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵi18n"](1, 54);
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵpureFunction3"](1, _c16, ctx_r6.showParentAssetTypeEntity && ctx_r6.activeParentAssetType === ctx_r6.PARENT_ASSET_TYPE.ENTITY, ctx_r6.activeParentAssetType === ctx_r6.PARENT_ASSET_TYPE.ENTITY, ctx_r6.activeParentAssetType !== ctx_r6.PARENT_ASSET_TYPE.ENTITY));
  }
}
function HomePage_Conditional_46_Conditional_0_Template(rf, ctx) {
  if (rf & 1) {
    const _r24 = _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵelementStart"](0, "w-icon", 56);
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵlistener"]("click", function HomePage_Conditional_46_Conditional_0_Template_w_icon_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵrestoreView"](_r24);
      const ctx_r23 = _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵresetView"](ctx_r23.goToAddToken());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵelementEnd"]();
  }
}
function HomePage_Conditional_46_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵtemplate"](0, HomePage_Conditional_46_Conditional_0_Template, 1, 0, "w-icon", 55);
  }
  if (rf & 2) {
    const ctx_r7 = _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵconditional"](0, (ctx_r7.activeWalletAddressInfo == null ? null : ctx_r7.activeWalletAddressInfo.chain) !== ctx_r7.CHAIN_NAME.Bitcoin ? 0 : -1);
  }
}
function HomePage_Conditional_47_Template(rf, ctx) {
  if (rf & 1) {
    const _r26 = _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵelementStart"](0, "w-icon", 57);
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵlistener"]("click", function HomePage_Conditional_47_Template_w_icon_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵrestoreView"](_r26);
      const ctx_r25 = _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵresetView"](ctx_r25.handleShowSearch());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵpipe"](1, "color");
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵpureFunction1"](4, _c8, _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵpipeBind1"](1, 2, "text-title")));
  }
}
function HomePage_Conditional_48_li_1_ng_container_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵelement"](1, "img", 65);
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const item_r28 = _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵnextContext"]().$implicit;
    const ctx_r30 = _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵclassProp"]("rounded-full", ctx_r30.isBioforestChain);
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵproperty"]("src", item_r28.logoUrl, _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵsanitizeUrl"]);
  }
}
const _c17 = a1 => ({
  prefix: "icon",
  chain: a1
});
function HomePage_Conditional_48_li_1_ng_template_3_ng_container_0_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵelement"](1, "w-icon", 67);
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵpipe"](2, "chainIcon");
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const item_r28 = _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵnextContext"](2).$implicit;
    const ctx_r34 = _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵproperty"]("name", _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵpipeBind2"](2, 1, item_r28.assetType, _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵpureFunction1"](4, _c17, ctx_r34.activeWalletAddressInfo.chain)));
  }
}
function HomePage_Conditional_48_li_1_ng_template_3_ng_template_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵelement"](0, "w-icon", 68);
  }
}
function HomePage_Conditional_48_li_1_ng_template_3_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵtemplate"](0, HomePage_Conditional_48_li_1_ng_template_3_ng_container_0_Template, 3, 6, "ng-container", 61)(1, HomePage_Conditional_48_li_1_ng_template_3_ng_template_1_Template, 1, 0, "ng-template", null, 66, _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵtemplateRefExtractor"]);
  }
  if (rf & 2) {
    const _r36 = _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵreference"](2);
    const item_r28 = _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵnextContext"]().$implicit;
    const ctx_r31 = _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵproperty"]("ngIf", ctx_r31.isLocalLogo(item_r28.assetType, ctx_r31.activeWalletAddressInfo.chain))("ngIfElse", _r36);
  }
}
function HomePage_Conditional_48_li_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r40 = _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵelementStart"](0, "li")(1, "button", 60);
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵlistener"]("click", function HomePage_Conditional_48_li_1_Template_button_click_1_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵrestoreView"](_r40);
      const item_r28 = restoredCtx.$implicit;
      const ctx_r39 = _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵresetView"](ctx_r39.goToTokenDetails(item_r28));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵtemplate"](2, HomePage_Conditional_48_li_1_ng_container_2_Template, 2, 3, "ng-container", 61)(3, HomePage_Conditional_48_li_1_ng_template_3_Template, 3, 2, "ng-template", null, 62, _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵtemplateRefExtractor"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵelementStart"](5, "div", 63);
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵtext"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵelementStart"](7, "div", 64);
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵtext"](8);
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵpipe"](9, "numberFormat");
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵpipe"](10, "amountFixed");
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const item_r28 = ctx.$implicit;
    const _r32 = _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵreference"](4);
    let tmp_3_0;
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵproperty"]("ngIf", item_r28.logoUrl)("ngIfElse", _r32);
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵtextInterpolate1"](" ", item_r28.assetType, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵpipeBind1"](9, 4, _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵpipeBind2"](10, 6, (tmp_3_0 = item_r28.amount) !== null && tmp_3_0 !== undefined ? tmp_3_0 : "------", item_r28.decimals)), " ");
  }
}
function HomePage_Conditional_48_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵelementStart"](0, "ul", 58);
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵtemplate"](1, HomePage_Conditional_48_li_1_Template, 11, 9, "li", 59);
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r9 = _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵproperty"]("@listFadeInRight", (ctx_r9.activeWalletAddressInfo == null ? null : ctx_r9.activeWalletAddressInfo.chain) + ":" + (ctx_r9.activeWalletAddressInfo == null ? null : ctx_r9.activeWalletAddressInfo.assets == null ? null : ctx_r9.activeWalletAddressInfo.assets.length));
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵproperty"]("ngForOf", ctx_r9.activeWalletAddressInfo == null ? null : ctx_r9.activeWalletAddressInfo.assets)("ngForTrackBy", ctx_r9.trackByKey("assetType"));
  }
}
function HomePage_Conditional_49_Conditional_0_w_icon_3_Template(rf, ctx) {
  if (rf & 1) {
    const _r46 = _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵelementStart"](0, "w-icon", 76);
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵlistener"]("click", function HomePage_Conditional_49_Conditional_0_w_icon_3_Template_w_icon_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵrestoreView"](_r46);
      const ctx_r45 = _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵnextContext"](3);
      return _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵresetView"](ctx_r45.cleanSearchContent());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵelementEnd"]();
  }
}
const _c22 = a0 => ({
  "opacity-50": a0
});
function HomePage_Conditional_49_Conditional_0_Template(rf, ctx) {
  if (rf & 1) {
    const _r48 = _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵelementStart"](0, "div", 70)(1, "div", 71)(2, "input", 72);
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵlistener"]("ngModelChange", function HomePage_Conditional_49_Conditional_0_Template_input_ngModelChange_2_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵrestoreView"](_r48);
      const ctx_r47 = _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵresetView"](ctx_r47.inputSearchContent = $event);
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵtemplate"](3, HomePage_Conditional_49_Conditional_0_w_icon_3_Template, 1, 0, "w-icon", 73);
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵelementStart"](4, "button", 74);
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵlistener"]("click", function HomePage_Conditional_49_Conditional_0_Template_button_click_4_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵrestoreView"](_r48);
      const ctx_r49 = _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵresetView"](ctx_r49.searchEntity());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵi18n"](5, 75);
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r41 = _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵpureFunction1"](5, _c22, !ctx_r41.addressEntityInfo.init));
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵproperty"]("ngModel", ctx_r41.inputSearchContent)("disabled", !ctx_r41.addressEntityInfo.init);
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵproperty"]("ngIf", ctx_r41.inputSearchContent);
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵproperty"]("disabled", !ctx_r41.addressEntityInfo.init);
  }
}
const _forTrack23 = ($index, $item) => $item.entityId;
function HomePage_Conditional_49_Conditional_1_Conditional_0_li_2_ng_template_10_Conditional_1_For_3_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵelementStart"](0, "div", 96)(1, "div", 97);
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵelement"](2, "img", 98);
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵelementStart"](3, "span", 99);
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵi18n"](4, 100);
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const dpItem_r63 = _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵi18nExp"](dpItem_r63.quantity);
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵi18nApply"](4);
  }
}
function HomePage_Conditional_49_Conditional_1_Conditional_0_li_2_ng_template_10_Conditional_1_For_3_Template(rf, ctx) {
  if (rf & 1) {
    const _r71 = _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵelementStart"](0, "div", 91);
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵlistener"]("click", function HomePage_Conditional_49_Conditional_1_Conditional_0_li_2_ng_template_10_Conditional_1_For_3_Template_div_click_0_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵrestoreView"](_r71);
      const dpItem_r63 = restoredCtx.$implicit;
      const ctx_r70 = _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵnextContext"](7);
      return _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵresetView"](ctx_r70.goToDpDetails(dpItem_r63, dpItem_r63.type === ctx_r70.DpType.homogenization));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵelement"](1, "img", 92);
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵtemplate"](2, HomePage_Conditional_49_Conditional_1_Conditional_0_li_2_ng_template_10_Conditional_1_For_3_Conditional_2_Template, 5, 1, "div", 93);
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵelementStart"](3, "div", 94)(4, "div", 95);
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵtext"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const dpItem_r63 = ctx.$implicit;
    const $index_r64 = ctx.$index;
    const $count_r66 = ctx.$count;
    const ctx_r60 = _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵnextContext"](7);
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵclassProp"]("mb-3", !($index_r64 === $count_r66 - 1));
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵproperty"]("src", dpItem_r63.pic, _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵsanitizeUrl"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵconditional"](2, dpItem_r63.type === ctx_r60.DpType.homogenization ? 2 : -1);
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵtextInterpolate1"](" ", dpItem_r63.name, " ");
  }
}
function HomePage_Conditional_49_Conditional_1_Conditional_0_li_2_ng_template_10_Conditional_1_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵelement"](0, "div", 101);
  }
}
function HomePage_Conditional_49_Conditional_1_Conditional_0_li_2_ng_template_10_Conditional_1_bn_infinite_scroll_spinner_5_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵelementStart"](0, "bn-infinite-scroll-spinner")(1, "span", 102);
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵi18n"](2, 103);
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵelementEnd"]()();
  }
}
function HomePage_Conditional_49_Conditional_1_Conditional_0_li_2_ng_template_10_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r74 = _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵelementStart"](0, "div", 88, 89);
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵlistener"]("infinited$", function HomePage_Conditional_49_Conditional_1_Conditional_0_li_2_ng_template_10_Conditional_1_Template_div_infinited__0_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵrestoreView"](_r74);
      const item_r54 = _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵnextContext"](2).$implicit;
      const ctx_r72 = _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵnextContext"](4);
      return _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵresetView"]($event.waitFor(ctx_r72.loadMoreGetFactoryList(item_r54.factoryInfo, item_r54.factoryId, true)));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵrepeaterCreate"](2, HomePage_Conditional_49_Conditional_1_Conditional_0_li_2_ng_template_10_Conditional_1_For_3_Template, 6, 5, "div", 104, _forTrack23);
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵtemplate"](4, HomePage_Conditional_49_Conditional_1_Conditional_0_li_2_ng_template_10_Conditional_1_Conditional_4_Template, 1, 0, "div", 90)(5, HomePage_Conditional_49_Conditional_1_Conditional_0_li_2_ng_template_10_Conditional_1_bn_infinite_scroll_spinner_5_Template, 3, 0, "bn-infinite-scroll-spinner", 80);
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const _r59 = _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵreference"](1);
    const item_r54 = _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵnextContext"](2).$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵproperty"]("infiniteScrollElement", _r59)("hasMore", item_r54.factoryInfo.hasMore);
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵrepeater"](item_r54.factoryInfo.list);
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵconditional"](4, item_r54.factoryInfo.list.length % 2 ? 4 : -1);
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵproperty"]("ngIf", item_r54.factoryInfo.hasMore);
  }
}
function HomePage_Conditional_49_Conditional_1_Conditional_0_li_2_ng_template_10_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵelement"](0, "bn-loading-wrapper", 105);
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵproperty"]("loadingTheme", "spinner")("showLoading", true);
  }
}
function HomePage_Conditional_49_Conditional_1_Conditional_0_li_2_ng_template_10_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵtemplate"](1, HomePage_Conditional_49_Conditional_1_Conditional_0_li_2_ng_template_10_Conditional_1_Template, 6, 4, "div", 87)(2, HomePage_Conditional_49_Conditional_1_Conditional_0_li_2_ng_template_10_Conditional_2_Template, 1, 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const item_r54 = _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵconditional"](1, item_r54.factoryInfo.init ? 1 : 2);
  }
}
function HomePage_Conditional_49_Conditional_1_Conditional_0_li_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r78 = _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵelementStart"](0, "li")(1, "mat-expansion-panel", 81);
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵlistener"]("opened", function HomePage_Conditional_49_Conditional_1_Conditional_0_li_2_Template_mat_expansion_panel_opened_1_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵrestoreView"](_r78);
      const item_r54 = restoredCtx.$implicit;
      const ctx_r77 = _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵnextContext"](4);
      return _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵresetView"](ctx_r77.entityOpen(item_r54.factoryInfo, item_r54.factoryId));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵelementStart"](2, "mat-expansion-panel-header", 82)(3, "mat-panel-title", 83)(4, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵtext"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵelementStart"](6, "div", 84);
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵtext"](7);
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵelement"](8, "w-icon", 85);
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵpipe"](9, "color");
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵelementEnd"]()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵtemplate"](10, HomePage_Conditional_49_Conditional_1_Conditional_0_li_2_ng_template_10_Template, 3, 1, "ng-template", 86);
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const item_r54 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵtextInterpolate"](item_r54.name);
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵtextInterpolate1"](" ", item_r54.dpAmount, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵpureFunction1"](6, _c8, _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵpipeBind1"](9, 4, "text-line")));
  }
}
function HomePage_Conditional_49_Conditional_1_Conditional_0_bn_infinite_scroll_spinner_3_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵelementStart"](0, "bn-infinite-scroll-spinner")(1, "span", 102);
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵi18n"](2, 106);
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵelementEnd"]()();
  }
}
function HomePage_Conditional_49_Conditional_1_Conditional_0_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵelementStart"](0, "ul", 78)(1, "mat-accordion", 79);
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵtemplate"](2, HomePage_Conditional_49_Conditional_1_Conditional_0_li_2_Template, 11, 8, "li", 59);
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵtemplate"](3, HomePage_Conditional_49_Conditional_1_Conditional_0_bn_infinite_scroll_spinner_3_Template, 3, 0, "bn-infinite-scroll-spinner", 80);
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r50 = _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵproperty"]("ngForOf", ctx_r50.addressEntityInfo == null ? null : ctx_r50.addressEntityInfo.list)("ngForTrackBy", ctx_r50.trackByKey("factoryId"));
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵproperty"]("ngIf", ctx_r50.activeParentAssetType === ctx_r50.PARENT_ASSET_TYPE.ENTITY && !ctx_r50.refreshAssetsTask && ctx_r50.addressEntityInfo.hasMore);
  }
}
function HomePage_Conditional_49_Conditional_1_Conditional_1_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵelementStart"](0, "div", 109);
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵi18n"](1, 110);
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵelementEnd"]();
  }
}
function HomePage_Conditional_49_Conditional_1_Conditional_1_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r82 = _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵelementStart"](0, "button", 111);
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵlistener"]("click", function HomePage_Conditional_49_Conditional_1_Conditional_1_Conditional_2_Template_button_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵrestoreView"](_r82);
      const ctx_r81 = _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵnextContext"](4);
      return _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵresetView"](ctx_r81.goToCosmicDp());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵelement"](2, "w-icon", 85);
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵpipe"](3, "color");
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r80 = _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵnextContext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵtextInterpolate1"](" ", ctx_r80.tip, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵpureFunction1"](5, _c8, _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵpipeBind1"](3, 3, "text-title")));
  }
}
function HomePage_Conditional_49_Conditional_1_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵelement"](0, "img", 107);
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵtemplate"](1, HomePage_Conditional_49_Conditional_1_Conditional_1_Conditional_1_Template, 2, 0, "div", 108)(2, HomePage_Conditional_49_Conditional_1_Conditional_1_Conditional_2_Template, 4, 7);
  }
  if (rf & 2) {
    const ctx_r51 = _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵconditional"](1, ctx_r51.addressEntityInfo.searchContent ? 1 : 2);
  }
}
function HomePage_Conditional_49_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵtemplate"](0, HomePage_Conditional_49_Conditional_1_Conditional_0_Template, 4, 3, "ul", 77)(1, HomePage_Conditional_49_Conditional_1_Conditional_1_Template, 3, 1);
  }
  if (rf & 2) {
    const ctx_r42 = _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵconditional"](0, !!ctx_r42.addressEntityInfo.list.length ? 0 : 1);
  }
}
function HomePage_Conditional_49_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵelement"](0, "bn-loading-wrapper", 105);
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵproperty"]("loadingTheme", "spinner")("showLoading", true);
  }
}
function HomePage_Conditional_49_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵtemplate"](0, HomePage_Conditional_49_Conditional_0_Template, 6, 7, "div", 69)(1, HomePage_Conditional_49_Conditional_1_Template, 2, 1)(2, HomePage_Conditional_49_Conditional_2_Template, 1, 2);
  }
  if (rf & 2) {
    const ctx_r10 = _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵconditional"](0, ctx_r10.addressEntityInfo.showSearch ? 0 : -1);
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵconditional"](1, ctx_r10.addressEntityInfo.init ? 1 : 2);
  }
}
function HomePage_ng_template_51_Template(rf, ctx) {
  if (rf & 1) {
    const _r84 = _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵelementStart"](0, "w-home-select-wallet-transation-page", 112);
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵlistener"]("returnValue$", function HomePage_ng_template_51_Template_w_home_select_wallet_transation_page_returnValue__0_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵrestoreView"](_r84);
      const ctx_r83 = _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵresetView"](ctx_r83.scanAddressGoToTransfer($event));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r11 = _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵproperty"]("filter", ctx_r11.sheet_selectWalletTransaction.filter)("walletList", ctx_r11.sheet_selectWalletTransaction.walletList);
  }
}
function HomePage_ng_template_53_Template(rf, ctx) {
  if (rf & 1) {
    const _r86 = _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵelementStart"](0, "w-home-select-wallet-page", 113);
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵlistener"]("returnValue$", function HomePage_ng_template_53_Template_w_home_select_wallet_page_returnValue__0_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵrestoreView"](_r86);
      const ctx_r85 = _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵresetView"](ctx_r85.onSelectMainWallet($event));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r12 = _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵproperty"]("mainWalletList", ctx_r12.sheet_selectWallet.mainWalletList);
  }
}
function HomePage_ng_template_55_Template(rf, ctx) {
  if (rf & 1) {
    const _r88 = _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵelementStart"](0, "w-home-select-chain-address-page", 114);
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵlistener"]("returnValue$", function HomePage_ng_template_55_Template_w_home_select_chain_address_page_returnValue__0_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵrestoreView"](_r88);
      const ctx_r87 = _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵresetView"](ctx_r87.onSelectChainAddress($event));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵelementEnd"]();
  }
}
const _c32 = a1 => ({
  prefix: "bg",
  chain: a1
});
const _c33 = () => ["/mnemonic/home-transfer"];
const _c34 = () => ["/home-receive"];
const _c35 = (a0, a1, a2, a3) => ({
  chain: a0,
  symbol: a1,
  address: a2,
  assetType: a3,
  agreement: ""
});
const _c36 = (a0, a1, a2) => ({
  "_asset-type-active": a0,
  "text-2xl font-semibold": a1,
  "text-lg": a2
});
/** 钱包主页面 */
class HomePage extends _modules_page_module__WEBPACK_IMPORTED_MODULE_16__.CommonPageBase {
  constructor() {
    var _this;
    // #region 助记词跟TRX地址
    super(...arguments);
    _this = this;
    this.walletV2Service = (0,_angular_core__WEBPACK_IMPORTED_MODULE_43__.inject)(_bnqkl_wallet_base_services_wallet_wallet__WEBPACK_IMPORTED_MODULE_12__.WalletV2Service);
    /** 网络状态监听 */
    this.online$ = _bnqkl_framework_plugins_network__WEBPACK_IMPORTED_MODULE_5__.Network.getOnlineStatus$();
    /** 链服务 */
    this.chainV2Service = (0,_angular_core__WEBPACK_IMPORTED_MODULE_43__.inject)(_bnqkl_wallet_base_services_wallet_chain__WEBPACK_IMPORTED_MODULE_10__.ChainV2Service);
    /** DP服务 */
    this.walletDpService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_43__.inject)(_bnqkl_wallet_base_services_wallet__WEBPACK_IMPORTED_MODULE_8__.WalletDpService);
    /** 钱包存储服务 */
    this.walletDataStorageV2Service = (0,_angular_core__WEBPACK_IMPORTED_MODULE_43__.inject)(_bnqkl_wallet_base_services_wallet_wallet_data_storage__WEBPACK_IMPORTED_MODULE_13__.WalletDataStorageV2Service);
    /** 资产类型 */
    this.PARENT_ASSET_TYPE = _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_11__.PARENT_ASSET_TYPE;
    /** 激活的资产类型 */
    this.activeParentAssetType = _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_11__.PARENT_ASSET_TYPE.ASSETS;
    this.CHAIN_NAME = _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_11__.CHAIN_NAME;
    this.WALLET_IMPORT_TYPE = _bnqkl_wallet_base_services_wallet_wallet_data_storage__WEBPACK_IMPORTED_MODULE_13__.WALLET_IMPORT_TYPE;
    /** 是否是移动端 */
    this.isMobile = (0,_helpers_utils__WEBPACK_IMPORTED_MODULE_26__.isMobile)();
    /** 编辑钱包成功后触发更新 */
    this.homeMainWalletEditPageReturnController = new _bnqkl_framework_controllers__WEBPACK_IMPORTED_MODULE_2__.PageReturnController(this, _pages_home_main_wallet_edit_home_main_wallet_edit_component__WEBPACK_IMPORTED_MODULE_21__.HomeMainWalletEditPage);
    /** 修改自选币种后触发更新 */
    this.homeAddTokenPageReturnController = new _bnqkl_framework_controllers__WEBPACK_IMPORTED_MODULE_2__.PageReturnController(this, _pages_home_pages_home_add_token_home_add_token_component__WEBPACK_IMPORTED_MODULE_17__.HomeAddTokenPage);
    /** 备份过助记词 */
    this.mnemonicConfirmBackupPageturnController = new _bnqkl_framework_controllers__WEBPACK_IMPORTED_MODULE_2__.PageReturnController(this, _pages_mnemonic_pages_mnemonic_confirm_backup_mnemonic_confirm_backup_component__WEBPACK_IMPORTED_MODULE_18__.MnemonicConfirmBackupPage);
    /** 跳过备份 */
    this.skipBackup = false;
    /**
     * 扫码后触发弹窗
     */
    this.scannerPageReturnController = new _bnqkl_framework_controllers__WEBPACK_IMPORTED_MODULE_2__.PageReturnController(this, _pages_scanner_scanner_component__WEBPACK_IMPORTED_MODULE_19__.ScannerPage);
    /** 记录获取地址详情请求间隔 */
    this._recordGetAddressInfoInterval_Map = new Map();
    /** 订阅监听激活的钱包变动 */
    this.lastWalletActivate$ = this.walletV2Service.lastWalletActivate_subject.subscribe( /*#__PURE__*/function () {
      var _ref = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (wallet) {
        if (wallet !== undefined) {
          var _this$mainWalletInfo;
          if (_this.activeWalletAddressInfo && _this.activeWalletAddressInfo.address === wallet.address && _this.activeWalletAddressInfo.chain === wallet.chain) {
            // 同一个钱包就不在继续往下了
            return;
          }
          const addressKey = wallet.addressKey;
          _this.activeWalletAddressInfo = yield _this.chainV2Service.getChainAddressInfoByAddressKey(addressKey);
          // 判断资产类型显示
          if (_this.showParentAssetTypeEntity === false) {
            /// 不支持dp 且是dp激活状态 切回去
            if (_this.activeParentAssetType != _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_11__.PARENT_ASSET_TYPE.ASSETS) {
              _this.activeParentAssetType = _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_11__.PARENT_ASSET_TYPE.ASSETS;
            }
          } else {
            /// 支持dp 且是激活状态，就需要重置
            if (_this.activeParentAssetType === _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_11__.PARENT_ASSET_TYPE.ENTITY) {
              _this.initGetEntityList(_this.activeWalletAddressInfo.address, _this.activeWalletAddressInfo.chain);
            }
          }
          _this.mainWalletInfo = yield _this.walletDataStorageV2Service.getMainWalletInfo(wallet.mainWalletId);
          _this.skipBackup = !!((_this$mainWalletInfo = _this.mainWalletInfo) !== null && _this$mainWalletInfo !== void 0 && _this$mainWalletInfo.skipBackup);
          _this.assetTypeBalance$ && _this.assetTypeBalance$.unsubscribe();
          _this.checkAddressHasFreezed(wallet);
          _this.assetTypeBalance$ = _this.chainV2Service.getChainBalanceSubject(wallet.chain).subscribe( /*#__PURE__*/function () {
            var _ref2 = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (data) {
              if (_this.activeWalletAddressInfo === undefined) {
                return;
              }
              const assets = data[_this.activeWalletAddressInfo.address] || {};
              /// 检查是否存在新资产
              for (const assetType in assets) {
                const walletAsset = _this.activeWalletAddressInfo.assets.find(item => item.assetType === assetType);
                if (walletAsset === undefined) {
                  /// 找不到，那么可能是新资产，重新拉下数据
                  _this.activeWalletAddressInfo = yield _this.chainV2Service.getChainAddressInfoByAddressKey(addressKey);
                  break;
                }
              }
              /// 更新资产数据
              for (const item of _this.activeWalletAddressInfo.assets) {
                item.amount = assets[item.assetType];
              }
              _this.cdRef.detectChanges();
            });
            return function (_x2) {
              return _ref2.apply(this, arguments);
            };
          }());
        }
        return wallet;
      });
      return function (_x) {
        return _ref.apply(this, arguments);
      };
    }());
    /** 钱包选择器的数据 */
    this.sheet_selectWallet = {
      is_open: false,
      mainWalletList: undefined
    };
    /** 钱包链地址选择器 */
    this.sheet_selectChainAddress = {
      is_open: false
    };
    /** 下拉刷新任务 */
    this.refreshAssetsTask = undefined;
    /** DP显示列表（先不做缓存） */
    this.addressEntityInfo = {
      init: false,
      list: [],
      page: 1,
      pageSize: 20,
      hasMore: false,
      address: '',
      chain: '',
      loadingPromiseOut: undefined,
      id: Date.now(),
      showSearch: false,
      searchContent: ''
    };
    /** 输入搜索内容 */
    this.inputSearchContent = '';
    /** dp类型 */
    this.DpType = _bnqkl_wallet_base_services_wallet__WEBPACK_IMPORTED_MODULE_8__.DpType;
  }
  /** 前往DP交易 */
  get tip() {
    return (0,_helpers_utils__WEBPACK_IMPORTED_MODULE_26__.isMobile)() ? "Go to CosmicDP for trading" : "Please go to CosmicDP  trading";
  }
  /** 是否展示dp类型 */
  get showParentAssetTypeEntity() {
    var _this$activeWalletAdd;
    return [_bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_11__.CHAIN_NAME.ETHMeta, _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_11__.CHAIN_NAME.BTGMeta, _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_11__.CHAIN_NAME.BFMeta, _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_11__.CHAIN_NAME.BFChainV2, _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_11__.CHAIN_NAME.CCChain].includes((_this$activeWalletAdd = this.activeWalletAddressInfo) === null || _this$activeWalletAdd === void 0 ? void 0 : _this$activeWalletAdd.chain);
  }
  /** 更改激活的资产类型 */
  changeParentAssetType(type) {
    if (this.activeParentAssetType !== type) {
      var _this$refreshAssetsTa;
      this.activeParentAssetType = type;
      if (type === _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_11__.PARENT_ASSET_TYPE.ENTITY) {
        var _this$activeWalletAdd2, _this$activeWalletAdd3;
        this.initGetEntityList(((_this$activeWalletAdd2 = this.activeWalletAddressInfo) === null || _this$activeWalletAdd2 === void 0 ? void 0 : _this$activeWalletAdd2.address) || '', ((_this$activeWalletAdd3 = this.activeWalletAddressInfo) === null || _this$activeWalletAdd3 === void 0 ? void 0 : _this$activeWalletAdd3.chain) || '');
      }
      (_this$refreshAssetsTa = this.refreshAssetsTask) === null || _this$refreshAssetsTa === void 0 || _this$refreshAssetsTa.reject(false);
      this.refreshAssetsTask = undefined;
    }
  }
  /**
   * 判断地址是否冻结，需要先清除之前的监听才对该地址进行数据请求，冻结状态不是高频率的，所以在切换钱包的时候拉下数据就行
   * 拉取间隔最少3分钟一次，避免频繁切换钱包所带来的过多频率请求
   */
  checkAddressHasFreezed(wallet) {
    var _this2 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      if (_this2.chainV2Service.isBioforestChainByChainName(wallet.chain) && _this2.activeWalletAddressInfo) {
        const lastTimestamp = _this2._recordGetAddressInfoInterval_Map.get(wallet.addressKey) || 0;
        if (lastTimestamp + 3 * 60 * 1000 > Date.now()) {
          return;
        }
        _this2._recordGetAddressInfoInterval_Map.set(wallet.addressKey, Date.now());
        /// 只对生物链林判断
        const _recordAddressInfo = _this2.activeWalletAddressInfo;
        let isFreezed = _recordAddressInfo.isFreezed;
        try {
          isFreezed = (yield _this2.chainV2Service.getChainService(_recordAddressInfo.chain).getAddressInfo(_recordAddressInfo.address)).isFreezed;
        } finally {
          if (isFreezed !== _recordAddressInfo.isFreezed) {
            /// 两者不相等，保存信息
            yield _this2.chainV2Service.updateChainAddressInfo(_recordAddressInfo.addressKey, {
              isFreezed
            });
          }
          if (_recordAddressInfo.addressKey === _this2.activeWalletAddressInfo.addressKey) {
            /// 是当前的钱包，更新界面显示
            _this2.activeWalletAddressInfo.isFreezed = isFreezed;
            _this2.cdRef.detectChanges();
          }
        }
      }
    })();
  }
  /** 清除订阅监听 */
  _clearQueryTask() {
    this.console.log('清除 订阅 lastWalletActivate$,assetTypeBalance$');
    this.lastWalletActivate$.unsubscribe();
    this.assetTypeBalance$ && this.assetTypeBalance$.unsubscribe();
  }
  /** 初始化获取数据 */
  initMainWallet() {
    var _this3 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      yield _this3.walletV2Service.initMainWallet();
      const addressInfo = yield _this3.walletV2Service.getActivateAddressWalletInfo();
      _this3.console.log(addressInfo);
      return addressInfo;
    })();
  }
  /** 初始化页面监听 */
  watchPageReturn() {
    var _this4 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this4.scannerPageReturnController.pageReturn$.subscribe( /*#__PURE__*/function () {
        var _ref3 = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (data) {
          yield (0,_bnqkl_util_web_extends_promise__WEBPACK_IMPORTED_MODULE_6__.sleep)(350);
          const isString = typeof data === 'string';
          if (isString || data.protocal === _pages_scanner_scanner_component__WEBPACK_IMPORTED_MODULE_19__.QRCODE_PROTOCAL_TYPE.ADDRESS) {
            const address = isString ? data : data['address'];
            _this4.console.log('scan qrCore:', address);
            const chainList = yield _this4.chainV2Service.findChainWhichAddress(address);
            if (chainList.length) {
              _this4.openSelectWalletTransation(chainList, address);
            }
          }
        });
        return function (_x3) {
          return _ref3.apply(this, arguments);
        };
      }());
      _this4.homeMainWalletEditPageReturnController.pageReturn$.subscribe( /*#__PURE__*/function () {
        var _ref4 = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (data) {
          var _this4$mainWalletInfo;
          if (data === 'delete') {
            _this4.initMainWallet();
          } else if (data.mainWalletId === ((_this4$mainWalletInfo = _this4.mainWalletInfo) === null || _this4$mainWalletInfo === void 0 ? void 0 : _this4$mainWalletInfo.mainWalletId)) {
            /// 刷新下当前钱包信息
            yield _this4.initMainWallet();
            if (_this4.mainWalletInfo && _this4.mainWalletInfo.name !== data.name) {
              _this4.mainWalletInfo.name = data.name;
            }
            _this4.cdRef.detectChanges();
          }
        });
        return function (_x4) {
          return _ref4.apply(this, arguments);
        };
      }());
      _this4.homeAddTokenPageReturnController.pageReturn$.subscribe( /*#__PURE__*/function () {
        var _ref5 = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (data) {
          if (data.isChange) {
            // 重新拉一下本地缓存
            if (_this4.activeWalletAddressInfo) {
              _this4.activeWalletAddressInfo = yield _this4.chainV2Service.getChainAddressInfoByAddressKey(_this4.activeWalletAddressInfo.addressKey);
              _this4.refreshAssets();
              _this4.cdRef.detectChanges();
            }
          }
        });
        return function (_x5) {
          return _ref5.apply(this, arguments);
        };
      }());
      /** 备份助记词页 */
      _this4.mnemonicConfirmBackupPageturnController.pageReturn$.subscribe( /*#__PURE__*/function () {
        var _ref6 = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (data) {
          if (data.mainWalletId && _this4.mainWalletInfo) {
            _this4.mainWalletInfo.skipBackup = false;
            _this4.skipBackup = false;
          }
        });
        return function (_x6) {
          return _ref6.apply(this, arguments);
        };
      }());
    })();
  }
  /** 打开扫码钱包弹窗 */
  openSelectWalletTransation(chainList, QR_address) {
    var _this5 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const filter = {
        _chainType: chainList,
        QR_address: QR_address
      };
      const walletList = yield _this5.injectorForceGet(_pages_select_wallet_transation_select_wallet_transation_resolver__WEBPACK_IMPORTED_MODULE_25__.SelectWalletTransationComResolver)._resolve(filter);
      _this5.sheet_selectWalletTransaction = {
        filter,
        walletList
      };
    })();
  }
  /** 打开钱包选择器 */
  openSelectWallet() {
    var _this6 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      if (_this6.isMobile) {
        const {
          sheet_selectWallet
        } = _this6;
        if (sheet_selectWallet.is_open) {
          return;
        }
        sheet_selectWallet.mainWalletList = yield _this6.walletDataStorageV2Service.getAllMainWalletInfo();
        sheet_selectWallet.is_open = true;
      } else {
        _this6.nav.routeTo('/mime');
      }
    })();
  }
  checkHomeSelectWalletOpen(open) {
    const {
      sheet_selectWallet
    } = this;
    if (open && sheet_selectWallet.is_open) {
      return;
    }
    sheet_selectWallet.is_open = open;
  }
  /** 打开钱包选择器 */
  openSelectChainAddress() {
    var _this7 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const {
        sheet_selectChainAddress
      } = _this7;
      if (sheet_selectChainAddress.is_open) {
        return;
      }
      sheet_selectChainAddress.is_open = true;
    })();
  }
  checkHomeSelectChainAddressOpen(open) {
    const {
      sheet_selectChainAddress
    } = this;
    if (open && sheet_selectChainAddress.is_open) {
      return;
    }
    sheet_selectChainAddress.is_open = open;
  }
  /** 扫一扫进行转账 */
  scanAddressGoToTransfer(data) {
    var _this8 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      if (data) {
        const selectAddress = data.addressInfo;
        /// 更换了激活的钱包，需要更新下数据a
        const walletDataStorageV2Service = _this8.injectorForceGet(_bnqkl_wallet_base_services_wallet_wallet_data_storage__WEBPACK_IMPORTED_MODULE_13__.WalletDataStorageV2Service);
        const mainWalleter = yield walletDataStorageV2Service.getLastWalletActivate();
        if (mainWalleter === undefined) {
          throw new Error(`not find mainWalleter`);
        }
        const addressInfo = yield walletDataStorageV2Service.getChainAddressInfo(selectAddress.addressKey);
        walletDataStorageV2Service.walletAppSettings.lastWalletActivate = addressInfo;
        yield _this8.walletV2Service.upDateActivateAddressWallet();
        _this8.cdRef.detectChanges();
        _this8.initMainWallet();
        _this8.nav.routeTo('/mnemonic/home-transfer', {
          QR_address: data.address
        });
      }
    })();
  }
  /** 切换身份钱包 */
  onSelectMainWallet(selectMainWallet) {
    var _this9 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      if (selectMainWallet) {
        var _this9$activeWalletAd, _ref7, _selectMainWallet$add;
        /// 更换了激活的钱包，需要更新下数据a
        const walletDataStorageV2Service = _this9.injectorForceGet(_bnqkl_wallet_base_services_wallet_wallet_data_storage__WEBPACK_IMPORTED_MODULE_13__.WalletDataStorageV2Service);
        /// 切换身份钱包 但是 链不变
        const activeChainName = (_this9$activeWalletAd = _this9.activeWalletAddressInfo) === null || _this9$activeWalletAd === void 0 ? void 0 : _this9$activeWalletAd.chain;
        const addressKeyInfo = (_ref7 = (_selectMainWallet$add = selectMainWallet.addressKeyList.find(item => {
          if (activeChainName === _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_11__.CHAIN_NAME.Bitcoin) {
            /// 判断之前激活哪个地址
            if (selectMainWallet.lastBitcoinAddressKey) {
              return item.addressKey === selectMainWallet.lastBitcoinAddressKey;
            }
            return item.purpose === _bnqkl_wallet_base_services_wallet_bitcoin__WEBPACK_IMPORTED_MODULE_9__.DEFAULT_PURPOSE && item.index === 0;
          }
          return item.chainName === activeChainName;
        })) !== null && _selectMainWallet$add !== void 0 ? _selectMainWallet$add : selectMainWallet.addressKeyList.find(item => item.chainName === _this9.walletV2Service.getAppDefaultChainName())) !== null && _ref7 !== void 0 ? _ref7 :
        /// 如果是私钥导入的，找不到就直接取第一个
        selectMainWallet.addressKeyList[0];
        /// 如果还找不到那问题就大喽
        if (addressKeyInfo === undefined) {
          throw new Error(`not find ${activeChainName} in mainWallet:${selectMainWallet.mainWalletId}!!!`);
        }
        const addressInfo = yield walletDataStorageV2Service.getChainAddressInfo(addressKeyInfo.addressKey);
        walletDataStorageV2Service.walletAppSettings.lastWalletActivate = addressInfo;
        yield _this9.walletV2Service.upDateActivateAddressWallet();
        _this9.cdRef.detectChanges();
        _this9.initMainWallet();
      }
    })();
  }
  /** 切换地址 */
  onSelectChainAddress(selectChainAddress) {
    var _this10 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      if (selectChainAddress) {
        /// 更换了激活的钱包，需要更新下数据a
        const walletDataStorageV2Service = _this10.injectorForceGet(_bnqkl_wallet_base_services_wallet_wallet_data_storage__WEBPACK_IMPORTED_MODULE_13__.WalletDataStorageV2Service);
        walletDataStorageV2Service.walletAppSettings.lastWalletActivate = selectChainAddress;
        if (selectChainAddress.chain === _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_11__.CHAIN_NAME.Bitcoin) {
          const mainWallet = yield _this10.walletDataStorageV2Service.getMainWalletInfo(selectChainAddress.mainWalletId);
          if (mainWallet) {
            mainWallet.lastBitcoinAddressKey = selectChainAddress.addressKey;
            _this10.walletDataStorageV2Service.saveMainWalletInfo(mainWallet);
          }
        }
        yield _this10.walletV2Service.upDateActivateAddressWallet();
        _this10.cdRef.detectChanges();
        _this10.initMainWallet();
      }
    })();
  }
  /** 点击token跳转到详情 */
  goToTokenDetails(item) {
    var _this11 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      var _this11$activeWalletA, _this11$activeWalletA2;
      return _this11.nav.routeTo('/mnemonic/home-token-details', {
        assetType: item.assetType,
        decimals: item.decimals,
        addressKey: ((_this11$activeWalletA = _this11.activeWalletAddressInfo) === null || _this11$activeWalletA === void 0 ? void 0 : _this11$activeWalletA.addressKey) || '',
        chain: ((_this11$activeWalletA2 = _this11.activeWalletAddressInfo) === null || _this11$activeWalletA2 === void 0 ? void 0 : _this11$activeWalletA2.chain) || ''
      });
    })();
  }
  /** 刷新资产 */
  refreshAssets() {
    var _this12 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      if (_this12.refreshAssetsTask) {
        return _this12.refreshAssetsTask.promise;
      }
      try {
        const task = _this12.refreshAssetsTask = new _bnqkl_util_web_extends_promise__WEBPACK_IMPORTED_MODULE_6__.PromiseOut();
        _this12.activeParentAssetType === _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_11__.PARENT_ASSET_TYPE.ASSETS ? _this12.walletV2Service.getActivateWalletAssets().then(() => task.resolve(true)).catch(err => {
          _this12.console.error(err);
          task.reject(err);
        }) : _this12.resetGetEntityList().then(() => task.resolve(true)).catch(err => {
          _this12.console.error(err);
          task.reject(err);
        });
        return yield task.promise;
      } finally {
        _this12.refreshAssetsTask = undefined;
      }
    })();
  }
  /**  是否是生物链林-链 */
  get isBioforestChain() {
    if (this.activeWalletAddressInfo) {
      return this.chainV2Service.isBioforestChainByChainName(this.activeWalletAddressInfo.chain);
    } else {
      return false;
    }
  }
  /**  跳转到新增币种页面 */
  goToAddToken() {
    var _this$activeWalletAdd4, _this$activeWalletAdd5, _this$activeWalletAdd6, _this$walletV2Service;
    this.nav.routeTo('/home-add-token', {
      chain: (_this$activeWalletAdd4 = this.activeWalletAddressInfo) === null || _this$activeWalletAdd4 === void 0 ? void 0 : _this$activeWalletAdd4.chain,
      walletName: (_this$activeWalletAdd5 = this.activeWalletAddressInfo) === null || _this$activeWalletAdd5 === void 0 ? void 0 : _this$activeWalletAdd5.name,
      addressKey: ((_this$activeWalletAdd6 = this.activeWalletAddressInfo) === null || _this$activeWalletAdd6 === void 0 ? void 0 : _this$activeWalletAdd6.addressKey) || '',
      chainSymbol: (_this$walletV2Service = this.walletV2Service.lastWalletActivate_subject.getValue()) === null || _this$walletV2Service === void 0 ? void 0 : _this$walletV2Service.symbol
    });
  }
  /** 本地是否存在图标 */
  isLocalLogo(assetType, chain) {
    return (0,_bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_11__.CHECK_LOCAL_ASSET_LOGO)(assetType, chain);
  }
  /** 进行备份 */
  goBackup() {
    var _this13 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      if (_this13.mainWalletInfo === undefined) {
        return;
      }
      const permissionService = _this13.injectorForceGet(_services_permission_permission_service__WEBPACK_IMPORTED_MODULE_20__.PermissionService);
      const pwdInfo = yield permissionService.requestPassword();
      if (pwdInfo === null || pwdInfo === false) {
        return;
      }
      let hasGoMnemonicBackup = false;
      if (hasGoMnemonicBackup === false) {
        /// 我们自己的链跳转到地址备份页面，但是助剂词不一定是地址密码，需要判断一下
        try {
          const bip39LibService = _this13.injectorForceGet(_bnqkl_wallet_base_services_wallet__WEBPACK_IMPORTED_MODULE_8__.Bip39LibService);
          yield bip39LibService.checkMnemonic(_this13.mainWalletInfo.importPhrase);
          hasGoMnemonicBackup = true;
        } catch (err) {
          hasGoMnemonicBackup = false;
        }
      }
      if (hasGoMnemonicBackup) {
        _this13.nav.routeTo('/mnemonic/mnemonic-backup-tips', {
          export: true,
          backUrl: '/tabs',
          mnemonicString: _this13.mainWalletInfo.importPhrase,
          mainWalletId: _this13.mainWalletInfo.mainWalletId,
          backup: true
        });
      } else {
        _this13.nav.routeTo('/mnemonic/address-password-tips', {
          export: true,
          backUrl: '/tabs',
          mnemonicString: _this13.mainWalletInfo.importPhrase
        });
      }
      return;
    })();
  }
  /** 搜索框 */
  handleShowSearch() {
    this.addressEntityInfo.showSearch = !this.addressEntityInfo.showSearch;
  }
  searchEntity() {
    if (this.addressEntityInfo.init === false) {
      return;
    }
    /** 直接当成初始化的 */
    return this.initGetEntityList(this.addressEntityInfo.address, this.addressEntityInfo.chain, true);
  }
  /** 初始化 */
  initGetEntityList(address, chain, hasSearch = false) {
    var _this14 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      var _this14$refreshAssets;
      /// 判断传入的值是否跟现在的一致
      if (_this14.addressEntityInfo.address === address && _this14.addressEntityInfo.chain === chain && hasSearch === false) {
        return;
      }
      /// 如果是搜索模式，输入跟已搜索一样的话退出
      if (hasSearch && _this14.inputSearchContent === _this14.addressEntityInfo.searchContent) {
        return;
      }
      /// 清除下拉加载
      (_this14$refreshAssets = _this14.refreshAssetsTask) === null || _this14$refreshAssets === void 0 || _this14$refreshAssets.reject(false);
      _this14.refreshAssetsTask = undefined;
      if (hasSearch === false) {
        _this14.addressEntityInfo.searchContent = '';
        _this14.inputSearchContent = '';
      } else {
        _this14.addressEntityInfo.searchContent = _this14.inputSearchContent;
      }
      if ((0,_bnqkl_framework_helpers__WEBPACK_IMPORTED_MODULE_3__.$isNoEmptyString)(address) === false || (0,_bnqkl_framework_helpers__WEBPACK_IMPORTED_MODULE_3__.$isNoEmptyString)(chain) === false) {
        _this14.addressEntityInfo.list.length = 0;
        _this14.addressEntityInfo.init = true;
        return;
      }
      _this14.addressEntityInfo.hasMore = false;
      _this14.addressEntityInfo.init = false;
      _this14.addressEntityInfo.page = 1;
      _this14.addressEntityInfo.address = address;
      _this14.addressEntityInfo.chain = chain;
      _this14.addressEntityInfo.loadingPromiseOut && _this14.addressEntityInfo.loadingPromiseOut.resolve(false);
      _this14.addressEntityInfo.loadingPromiseOut = undefined;
      _this14.addressEntityInfo.id = Date.now();
      return _this14.queryGetEntityList(false);
    })();
  }
  /** 重置列表 */
  resetGetEntityList() {
    var _this15 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      if (_this15.addressEntityInfo.loadingPromiseOut) {
        /// 在加载中的话，就不运行下拉加载 避免数据出错
        return;
      }
      /// 刷新交易列表
      _this15.addressEntityInfo.hasMore = false;
      _this15.addressEntityInfo.page = 1;
      return _this15.queryGetEntityList(false);
    })();
  }
  /** 加载更多 */
  loadMoreGetEntityList() {
    var _this16 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      return _this16.queryGetEntityList(true);
    })();
  }
  /**
   * 查询数据
   * */
  queryGetEntityList(loadMore = false) {
    var _this17 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      var _this17$activeWalletA;
      const info = _this17.addressEntityInfo;
      if (info.loadingPromiseOut || ((_this17$activeWalletA = _this17.activeWalletAddressInfo) === null || _this17$activeWalletA === void 0 ? void 0 : _this17$activeWalletA.chain) != info.chain || _this17.activeWalletAddressInfo.address != info.address) {
        return;
      }
      info.loadingPromiseOut = new _bnqkl_util_web_extends_promise__WEBPACK_IMPORTED_MODULE_6__.PromiseOut();
      if (loadMore) {
        info.page++;
      }
      try {
        let queryTask;
        const queryId = info.id;
        // eslint-disable-next-line prefer-const
        queryTask = _this17.walletDpService.getAddressCollection({
          address: info.address,
          page: info.page,
          pageSize: info.pageSize,
          keyword: (info.searchContent || '').trim()
        }, info.chain);
        /// 没数据的时候 延时一下，避免闪屏不好看
        info.list.length === 0 && (yield (0,_bnqkl_util_web_extends_promise__WEBPACK_IMPORTED_MODULE_6__.sleep)(350));
        /** 查询到的已确认列表 */
        const {
          dataList,
          hasMore
        } = yield queryTask;
        if (queryId === info.id) {
          /// 判断新的列表是否包含原有的，如果有证明数据更新，需要重置
          const factoryId_Set = new Set(dataList.map(item => item.factoryId));
          const hasRepeat = info.list.some(item => factoryId_Set.has(item.factoryId));
          if (hasRepeat && info.page !== 1) {
            return _this17.resetGetEntityList();
          }
          /// 重置就直接清数据
          if (info.page === 1 && info.list.length) {
            var _this17$matAccordion;
            /// 重置的话需要判断是否已有的专辑，需要更新数量，直接关闭手风琴
            const dataList_Map = new Map(dataList.map(item => [item.factoryId, item]));
            /// 过滤出相同项
            const filterList = info.list.filter(item => dataList_Map.has(item.factoryId));
            /// 判断是否数量有改变
            const hasChange = filterList.some(item => {
              const newItem = dataList_Map.get(item.factoryId);
              if (newItem) {
                return newItem.dpAmount !== item.dpAmount;
              }
              return false;
            });
            /// 如果有改变, 关闭全部
            hasChange && ((_this17$matAccordion = _this17.matAccordion) === null || _this17$matAccordion === void 0 ? void 0 : _this17$matAccordion.closeAll());
            info.list.length = 0;
            info.list.push(...dataList.map(item => {
              const oldItem = filterList.find(filterItem => filterItem.factoryId === item.factoryId);
              const factoryInfo = hasChange === false && oldItem ? oldItem.factoryInfo : {
                init: false,
                page: 1,
                pageSize: 10,
                hasMore: false,
                list: []
              };
              return {
                ...item,
                factoryInfo
              };
            }));
          } else {
            /// 这里跟上面有重复代码，但为了避免page = 1的判断情况需要将里面的变量提出，故意这么做
            info.list.push(...dataList.map(item => {
              return {
                ...item,
                factoryInfo: {
                  init: false,
                  page: 1,
                  pageSize: 10,
                  hasMore: false,
                  list: []
                }
              };
            }));
          }
          _this17.cdRef.detectChanges();
          yield (0,_bnqkl_util_web_extends_promise__WEBPACK_IMPORTED_MODULE_6__.sleep)(150);
          info.hasMore = hasMore;
          _this17.cdRef.detectChanges();
        }
      } finally {
        info.loadingPromiseOut && info.loadingPromiseOut.resolve(true);
        info.loadingPromiseOut = undefined;
        info.init = true;
        _this17.cdRef.detectChanges();
      }
    })();
  }
  /** 跳转app */
  goToCosmicDp() {
    var _this18 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      /// 判断是否存在
      if (_this18.environment.DWEB_APP) {
        /** 注入plaoc服务 */
        const plaoc = _this18.injectorForceGet(_bnqkl_wallet_base_services__WEBPACK_IMPORTED_MODULE_7__.PlaocService);
        const cosmicDpId = `${_this18.environment.production ? '' : 'alpha'}cosmicdp.com.dweb`;
        const canOpen = yield plaoc.canOpenUrl(cosmicDpId);
        if (canOpen.success === false) {
          /// 没安装，跳转下载
          const url = new URL(_this18.environment.production ? 'https://source.dwebdapp.com/dweb-browser-apps/dweb-apps/applist.json' : 'https://source.dwebdapp.com/dweb-browser-apps/dweb-apps-test/applist.json');
          url.searchParams.append('time', String(Date.now()));
          const result = yield fetch(url.toString()).then(res => res.json()).catch(err => {
            _this18.console.log('获取applist', err);
            return;
          });
          if (result) {
            const baseUrl = result.base_config.base_url + result.base_config.app_path;
            const walletName = 'CosmicDP'.toLowerCase();
            const targetPath = result.applist[walletName][`dwebTarget${(0,_plaoc_is_dweb__WEBPACK_IMPORTED_MODULE_14__.dwebTarget)()}`];
            const downloadUrl = `${baseUrl}/${walletName}/${targetPath}/metadata.json`;
            _plaoc_plugins__WEBPACK_IMPORTED_MODULE_15__.updateControllerPlugin.download(downloadUrl);
          } else {
            _bnqkl_framework_plugins_browser__WEBPACK_IMPORTED_MODULE_4__.Browser.open({
              url: _this18.environment.production ? 'https://dwebdapp.com' : 'https://test.dwebdapp.com'
            });
          }
          return;
        }
        /// 安装就直接打开
        const url = new URL('', document.baseURI);
        _plaoc_plugins__WEBPACK_IMPORTED_MODULE_15__.dwebServiceWorker.externalFetch(cosmicDpId, url);
        return;
      } else {
        _bnqkl_framework_plugins_browser__WEBPACK_IMPORTED_MODULE_4__.Browser.open({
          url: _this18.environment.production ? 'https://dwebdapp.com' : 'https://test.dwebdapp.com'
        });
      }
    })();
  }
  /** 开始查询 */
  entityOpen(info, factoryId) {
    var _this19 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      if (info.init) {
        return;
      }
      return _this19.loadMoreGetFactoryList(info, factoryId, false);
    })();
  }
  /** 开始查询 */
  loadMoreGetFactoryList(info, factoryId, loadMore) {
    var _this20 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      if (info.loadingPromiseOut) {
        return;
      }
      info.loadingPromiseOut = new _bnqkl_util_web_extends_promise__WEBPACK_IMPORTED_MODULE_6__.PromiseOut();
      if (loadMore) {
        info.page++;
      }
      try {
        let queryTask;
        // eslint-disable-next-line prefer-const
        queryTask = _this20.walletDpService.getAddressCollectiondpSet({
          address: _this20.addressEntityInfo.address,
          page: info.page,
          factoryId,
          pageSize: info.pageSize,
          keyword: (_this20.addressEntityInfo.searchContent || '').trim()
        }, _this20.addressEntityInfo.chain);
        /// 没数据的时候 延时一下，避免闪屏不好看
        info.list.length === 0 && (yield (0,_bnqkl_util_web_extends_promise__WEBPACK_IMPORTED_MODULE_6__.sleep)(350));
        /** 查询到的已确认列表 */
        const {
          dataList,
          hasMore
        } = yield queryTask;
        if (info.page === 1 && info.list.length) {
          info.list.length = 0;
        }
        info.list.push(...dataList);
        info.hasMore = hasMore;
        info.init = true;
        _this20.cdRef.detectChanges();
      } finally {
        var _info$loadingPromiseO;
        (_info$loadingPromiseO = info.loadingPromiseOut) === null || _info$loadingPromiseO === void 0 || _info$loadingPromiseO.resolve(true);
        info.loadingPromiseOut = undefined;
      }
    })();
  }
  /** 进入dp详情 */
  goToDpDetails(item, hasHomogenization) {
    if (hasHomogenization) {
      this.nav.routeTo('/mnemonic/home-entity-list', {
        entityId: item.entityId,
        chain: this.activeWalletAddressInfo.chain,
        pic: item.pic,
        quantity: item.quantity,
        dpName: item.name,
        address: this.activeWalletAddressInfo.address
      });
    } else {
      this.nav.routeTo('/mnemonic/home-entity-details', {
        entityId: item.entityId,
        chain: this.activeWalletAddressInfo.chain
      });
    }
  }
  /** 情况搜索 */
  cleanSearchContent() {
    this.inputSearchContent = '';
  }
  // #endregion
  /** 进入btc地址设置页面 */
  goToBitcoinAddressSettings() {
    var _this$mainWalletInfo2;
    if ((_this$mainWalletInfo2 = this.mainWalletInfo) !== null && _this$mainWalletInfo2 !== void 0 && _this$mainWalletInfo2.mainWalletId) {
      this.nav.routeTo('/home-bitcoin-address-settings', {
        mainWalletId: this.mainWalletInfo.mainWalletId
      });
    }
  }
}
_class = HomePage;
_class.ɵfac = /*@__PURE__*/(() => {
  let ɵHomePage_BaseFactory;
  return function HomePage_Factory(t) {
    return (ɵHomePage_BaseFactory || (ɵHomePage_BaseFactory = _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵgetInheritedFactory"](_class)))(t || _class);
  };
})();
_class.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵdefineComponent"]({
  type: _class,
  selectors: [["w-home-page"]],
  viewQuery: function HomePage_Query(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵviewQuery"](_angular_material_expansion__WEBPACK_IMPORTED_MODULE_44__.MatAccordion, 5);
    }
    if (rf & 2) {
      let _t;
      _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵloadQuery"]()) && (ctx.matAccordion = _t.first);
    }
  },
  standalone: true,
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵInheritDefinitionFeature"], _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵStandaloneFeature"]],
  decls: 56,
  vars: 60,
  consts: () => {
    let i18n_0;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_FLEX$$APPS_WALLET_SRC_PAGES_HOME_HOME_COMPONENT_TS_1 = goog.getMsg("flex");
      i18n_0 = MSG_EXTERNAL_FLEX$$APPS_WALLET_SRC_PAGES_HOME_HOME_COMPONENT_TS_1;
    } else {
      i18n_0 = "flex";
    }
    let i18n_2;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_TRANSFER$$APPS_WALLET_SRC_PAGES_HOME_HOME_COMPONENT_TS_3 = goog.getMsg("Transfer");
      i18n_2 = MSG_EXTERNAL_TRANSFER$$APPS_WALLET_SRC_PAGES_HOME_HOME_COMPONENT_TS_3;
    } else {
      i18n_2 = "Transfer";
    }
    let i18n_4;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_RECEIVE$$APPS_WALLET_SRC_PAGES_HOME_HOME_COMPONENT_TS_5 = goog.getMsg("Receive");
      i18n_4 = MSG_EXTERNAL_RECEIVE$$APPS_WALLET_SRC_PAGES_HOME_HOME_COMPONENT_TS_5;
    } else {
      i18n_4 = "Receive";
    }
    let i18n_6;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_ASSETS$$APPS_WALLET_SRC_PAGES_HOME_HOME_COMPONENT_TS_7 = goog.getMsg(" Assets ");
      i18n_6 = MSG_EXTERNAL_ASSETS$$APPS_WALLET_SRC_PAGES_HOME_HOME_COMPONENT_TS_7;
    } else {
      i18n_6 = " Assets ";
    }
    let i18n_10;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_NO_BACKUP$$APPS_WALLET_SRC_PAGES_HOME_HOME_COMPONENT_TS__11 = goog.getMsg("No Backup");
      i18n_10 = MSG_EXTERNAL_NO_BACKUP$$APPS_WALLET_SRC_PAGES_HOME_HOME_COMPONENT_TS__11;
    } else {
      i18n_10 = "No Backup";
    }
    let i18n_12;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_FROZEN$$APPS_WALLET_SRC_PAGES_HOME_HOME_COMPONENT_TS__13 = goog.getMsg("Frozen");
      i18n_12 = MSG_EXTERNAL_FROZEN$$APPS_WALLET_SRC_PAGES_HOME_HOME_COMPONENT_TS__13;
    } else {
      i18n_12 = "Frozen";
    }
    let i18n_14;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_DP$$APPS_WALLET_SRC_PAGES_HOME_HOME_COMPONENT_TS__15 = goog.getMsg(" DP ");
      i18n_14 = MSG_EXTERNAL_DP$$APPS_WALLET_SRC_PAGES_HOME_HOME_COMPONENT_TS__15;
    } else {
      i18n_14 = " DP ";
    }
    let i18n_18;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_PLEASE_ENTER_DP_NAME_OR_ID$$APPS_WALLET_SRC_PAGES_HOME_HOME_COMPONENT_TS___19 = goog.getMsg("Please enter DP name or ID");
      i18n_18 = MSG_EXTERNAL_PLEASE_ENTER_DP_NAME_OR_ID$$APPS_WALLET_SRC_PAGES_HOME_HOME_COMPONENT_TS___19;
    } else {
      i18n_18 = "Please enter DP name or ID";
    }
    let i18n_20;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_SEARCH$$APPS_WALLET_SRC_PAGES_HOME_HOME_COMPONENT_TS___21 = goog.getMsg(" Search ");
      i18n_20 = MSG_EXTERNAL_SEARCH$$APPS_WALLET_SRC_PAGES_HOME_HOME_COMPONENT_TS___21;
    } else {
      i18n_20 = " Search ";
    }
    let i18n_24;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_ENTITY_LIMIT___amount__$$APPS_WALLET_SRC_PAGES_HOME_HOME_COMPONENT_TS_________25 = goog.getMsg("Limit ({$interpolation})", {
        "interpolation": "\uFFFD0\uFFFD"
      }, {
        original_code: {
          "interpolation": "{{ dpItem.quantity }}"
        }
      });
      i18n_24 = MSG_EXTERNAL_ENTITY_LIMIT___amount__$$APPS_WALLET_SRC_PAGES_HOME_HOME_COMPONENT_TS_________25;
    } else {
      i18n_24 = "Limit (" + "\uFFFD0\uFFFD" + ")";
    }
    let i18n_26;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_LOADING$$APPS_WALLET_SRC_PAGES_HOME_HOME_COMPONENT_TS________27 = goog.getMsg("Loading");
      i18n_26 = MSG_EXTERNAL_LOADING$$APPS_WALLET_SRC_PAGES_HOME_HOME_COMPONENT_TS________27;
    } else {
      i18n_26 = "Loading";
    }
    let i18n_28;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_LOADING$$APPS_WALLET_SRC_PAGES_HOME_HOME_COMPONENT_TS_____29 = goog.getMsg("Loading");
      i18n_28 = MSG_EXTERNAL_LOADING$$APPS_WALLET_SRC_PAGES_HOME_HOME_COMPONENT_TS_____29;
    } else {
      i18n_28 = "Loading";
    }
    let i18n_30;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @desc THERE_ARE_CURRENTLY_NO_SEARCH_RESULTS_AVAILABLE
       */
      const MSG_EXTERNAL_THERE_ARE_CURRENTLY_NO_SEARCH_RESULTS_AVAILABLE$$APPS_WALLET_SRC_PAGES_HOME_HOME_COMPONENT_TS_____31 = goog.getMsg(" There are currently no search results available ");
      i18n_30 = MSG_EXTERNAL_THERE_ARE_CURRENTLY_NO_SEARCH_RESULTS_AVAILABLE$$APPS_WALLET_SRC_PAGES_HOME_HOME_COMPONENT_TS_____31;
    } else {
      i18n_30 = " There are currently no search results available ";
    }
    return [["headerTitle", "", "contentClass", i18n_0, 1, "cursor-pointer", 3, "headerBackground", "headerTranslucent", "backButtonDisable", "contentBackground", "contentSafeArea"], ["startMenu", "", "bnRippleButton", "", "class", "text-title mt-2 !flex items-center justify-center !text-base"], ["endMenu", "", "bnRippleButton", "", 1, "text-title", "mt-2", "!flex", "items-center", "justify-center", "!text-base", "font-bold", 3, "click"], ["class", "ml-1 flex items-center justify-start text-xs", 4, "ngIf"], ["name", "right", 1, "icon-3", "ml-1", "mt-[2px]", "rotate-90"], [1, "flex", "w-full", "flex-col", "items-center", "justify-start", "overflow-y-scroll", "pt-5"], ["homeScrollView", ""], [1, "w-full"], [1, "h-43", "_card-bg", "relative", "z-10", "mx-5", "flex", "flex-col", "items-start", "justify-between", "rounded-3xl", "p-6", "pb-4"], [1, "relative"], [1, "mb-2"], [1, "flex", "items-center", "justify-start", "text-2xl", "font-semibold", "text-white"], ["class", "text-error border-tiny border-error ml-2 ml-3 flex shrink-0 items-center rounded-full bg-white px-2 py-[2px]", 3, "click", 4, "ngIf"], [1, "mt-1", "flex", "items-center", "text-white/[0.6]"], ["bnRippleButton", "", "class", "mr-1 flex items-center"], [1, "text-base"], ["bnRippleButton", "", 1, "ml-2", "flex", "items-center", 3, "wClickToCopy"], ["name", "copy", 1, "icon-4"], ["class", "ml-2 flex items-center justify-start", 4, "ngIf"], [1, "w-17", "h-17", "icon-16.5", "absolute", "right-8", "top-7", "-z-10", "justify-self-end", "text-white/[0.3]", 3, "name"], [1, "flex", "w-full", "items-center", "justify-between", "rounded-3xl", "bg-gradient-to-r", "text-white"], ["bnRippleButton", "", 1, "h-10.5", "from-blue-gradient-start", "to-blue-gradient-end", "flex", "w-[46%]", "items-center", "justify-center", "rounded-full", "bg-gradient-to-b", "text-center", 3, "animationType", "routerLink"], ["name", "transfer", 1, "icon-5", "mr-2"], i18n_2, ["bnRippleButton", "", 1, "h-10.5", "from-red-gradient-start", "to-red-gradient-end", "flex", "w-[46%]", "items-center", "justify-center", "rounded-full", "bg-gradient-to-b", "text-center", 3, "animationType", "routerLink", "queryParams"], ["name", "receive", 1, "icon-5", "mr-2"], i18n_4, ["wPullToRefresh", "", "wInfiniteScroll", "", 1, "px-page-safe-area-inset", "w-full", "grow", "pb-5", "pt-6", 3, "pullScrollElement", "infiniteScrollElement", "hasMore", "pulled$", "infinited$"], [1, "text-title", "mb-2"], [1, "text-title", "rounded-8", "min-h-full", "w-full", "bg-white", "p-5"], [1, "flex", "items-center", "justify-between", "pb-3"], [1, "flex", "items-center", "justify-start", "align-baseline"], [1, "mr-5", 3, "ngClass", "click"], i18n_6, [3, "ngClass"], [1, "ml-4", "flex", "items-center", "justify-center"], ["class", "flex grid-flow-row flex-col overflow-x-hidden py-2"], [3, "isOpen", "panelClass", "isOpenChange"], ["startMenu", "", "bnRippleButton", "", 1, "text-title", "mt-2", "!flex", "items-center", "justify-center", "!text-base", 3, "click"], ["alt", "", "srcset", "", 1, "h-[32px]", "w-[32px]", "rounded-full", 3, "src"], [1, "mx-1", "max-w-[120px]", "overflow-hidden", "text-ellipsis", "whitespace-nowrap"], [1, "ml-1", "flex", "items-center", "justify-start", "text-xs"], [1, "bg-error", "rounded-50", "mr-1", "h-1", "w-1"], [1, "text-error", "border-tiny", "border-error", "ml-2", "ml-3", "flex", "shrink-0", "items-center", "rounded-full", "bg-white", "px-2", "py-[2px]", 3, "click"], ["name", "warn-grey", 1, "icon-4"], [1, "text-xss", "pt-[1px]", "font-normal"], i18n_10, ["bnRippleButton", "", 1, "mr-1", "flex", "items-center", 3, "click"], ["name", "change", 1, "icon-4"], [1, "ml-2", "flex", "items-center", "justify-start"], [1, "bg-error", "inline-block", "h-1", "w-1", "rounded-full"], [1, "rounded-2", "text-error", "ml-1", "bg-white/[0.15]", "px-2", "text-xs"], i18n_12, [3, "ngClass", "click"], i18n_14, ["name", "add-token", "class", "icon-5 font-semibold"], ["name", "add-token", 1, "icon-5", "font-semibold", 3, "click"], ["name", "search", 1, "icon-7", "font-semibold", 3, "click"], [1, "flex", "grid-flow-row", "flex-col", "overflow-x-hidden", "py-2"], [4, "ngFor", "ngForOf", "ngForTrackBy"], ["bnRippleButton", "", 1, "h-15", "flex", "w-full", "items-center", "rounded-lg", "px-4", "text-sm", 3, "click"], [4, "ngIf", "ngIfElse"], ["wIconViewByToken", ""], [1, "mx-2", "justify-self-start", "text-sm", "font-semibold"], [1, "wight-100", "ml-auto", "justify-self-end", "overflow-hidden", "text-ellipsis", "text-right", "font-bold"], [1, "_bioforest_asset_logo", "text-3xl", 3, "src"], ["wIconViewBySymbol", ""], [1, "justify-self-start", "text-3xl", 3, "name"], ["name", "icon-default", 1, "text-3xl"], ["headerTitle", "", "class", "flex w-full pb-2 pt-1", 3, "ngClass"], ["headerTitle", "", 1, "flex", "w-full", "pb-2", "pt-1", 3, "ngClass"], [1, "bg-grey", "box-border", "flex", "h-8", "w-full", "items-center", "rounded-full", "px-3", "py-0"], ["type", "text", "placeholder", i18n_18, 1, "w-full", "font-normal", "text-black", 3, "ngModel", "disabled", "ngModelChange"], ["class", "mr-1 text-sm", "name", "fail", 3, "click", 4, "ngIf"], ["bnRippleButton", "", 1, "w-18", "from-purple-gradient-start", "to-purple-gradient-end", "ml-2", "shrink-0", "rounded-full", "bg-gradient-to-b", "text-center", "text-white", 3, "disabled", "click"], i18n_20, ["name", "fail", 1, "mr-1", "text-sm", 3, "click"], ["class", "_e flex grid-flow-row flex-col overflow-x-hidden py-2"], [1, "_e", "flex", "grid-flow-row", "flex-col", "overflow-x-hidden", "py-2"], ["multi", ""], [4, "ngIf"], ["hideToggle", "", 1, "_entity-expansion-panel", "!border-b-tiny", "!border-line", 3, "opened"], [1, "!p-0"], [1, "h-13", "text-title", "!m-0", "flex", "items-center", "justify-between", "text-base", "font-bold"], [1, "flex", "items-center", "justify-end"], ["name", "right", 1, "icon-4", "ml-1"], ["matExpansionPanelContent", ""], ["class", "flex max-h-[518px] w-full flex-wrap items-start justify-around overflow-y-scroll", "wInfiniteScroll", "", 3, "infiniteScrollElement", "hasMore"], ["wInfiniteScroll", "", 1, "flex", "max-h-[518px]", "w-full", "flex-wrap", "items-start", "justify-around", "overflow-y-scroll", 3, "infiniteScrollElement", "hasMore", "infinited$"], ["factoryScrollView", ""], ["class", "w-[46%] max-w-[168px] opacity-0"], [1, "rounded-5", "border-tiny", "border-title", "relative", "aspect-square", "w-[46%]", "max-w-[168px]", "overflow-hidden", 3, "click"], ["alt", "", 1, "h-full", "w-full", 3, "src"], ["class", "absolute top-1 flex w-full items-start justify-center"], [1, "absolute", "bottom-1", "left-0", "w-full", "px-1"], [1, "border-tiny", "text-title", "w-full", "overflow-hidden", "text-ellipsis", "whitespace-nowrap", "rounded-full", "border-white", "bg-white/80", "px-3", "text-center", "text-sm", "leading-7"], [1, "absolute", "top-1", "flex", "w-full", "items-start", "justify-center"], [1, "from-purple-gradient-start", "to-purple-gradient-end", "flex", "h-5", "items-center", "justify-center", "rounded-full", "bg-gradient-to-b", "px-3", "text-white"], ["src", "./assets/images/home-dp-limit.svg", "alt", "", 1, "inline-block"], [1, "text-xs"], i18n_24, [1, "w-[46%]", "max-w-[168px]", "opacity-0"], [1, "text-sm"], i18n_26, ["class", "rounded-5 border-tiny border-title relative aspect-square w-[46%] max-w-[168px] overflow-hidden", 3, "mb-3"], [1, "text-primary", "my-8", "text-[2rem]", 3, "loadingTheme", "showLoading"], i18n_28, ["src", "./assets/images/home-empty-dp-list.png", "alt", "", "srcset", "", 1, "mx-auto", "mt-4", "h-auto", "w-[50%]", "max-w-[160px]"], ["class", "text-primary mx-auto mb-3 block flex items-center justify-center"], [1, "text-primary", "mx-auto", "mb-3", "block", "flex", "items-center", "justify-center"], i18n_30, ["bnRippleButton", "", 1, "text-primary", "mx-auto", "mb-3", "block", "flex", "items-center", "justify-center", 3, "click"], [3, "filter", "walletList", "returnValue$"], [3, "mainWalletList", "returnValue$"], [3, "returnValue$"]];
  },
  template: function HomePage_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵelementStart"](0, "common-page", 0);
      _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵtemplate"](1, HomePage_Conditional_1_Template, 6, 12, "button", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵelementStart"](2, "button", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵlistener"]("click", function HomePage_Template_button_click_2_listener() {
        return ctx.openSelectChainAddress();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵtemplate"](3, HomePage_div_3_Template, 2, 0, "div", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵpipe"](4, "async");
      _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵtext"](5);
      _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵelement"](6, "w-icon", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵpipe"](7, "color");
      _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵelementStart"](8, "div", 5, 6)(10, "header", 7)(11, "div", 8)(12, "div", 9)(13, "div", 10)(14, "div", 11)(15, "div");
      _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵtext"](16);
      _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵtemplate"](17, HomePage_div_17_Template, 5, 6, "div", 12);
      _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵelementStart"](18, "div", 13);
      _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵtemplate"](19, HomePage_Conditional_19_Template, 3, 6, "button", 14);
      _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵelementStart"](20, "span", 15);
      _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵtext"](21);
      _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵpipe"](22, "addressHidden");
      _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵelementStart"](23, "button", 16);
      _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵelement"](24, "w-icon", 17);
      _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵtemplate"](25, HomePage_div_25_Template, 4, 0, "div", 18);
      _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵelementEnd"]()()();
      _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵelement"](26, "w-icon", 19);
      _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵpipe"](27, "chainIcon");
      _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵelementStart"](28, "div", 20)(29, "button", 21);
      _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵelement"](30, "w-icon", 22);
      _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵelementStart"](31, "div", 15);
      _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵi18n"](32, 23);
      _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵelementStart"](33, "button", 24);
      _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵelement"](34, "w-icon", 25);
      _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵelementStart"](35, "div", 15);
      _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵi18n"](36, 26);
      _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵelementEnd"]()()()()();
      _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵelementStart"](37, "section", 27);
      _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵlistener"]("pulled$", function HomePage_Template_section_pulled__37_listener($event) {
        return $event.waitFor(ctx.refreshAssets());
      })("infinited$", function HomePage_Template_section_infinited__37_listener($event) {
        return $event.waitFor(ctx.loadMoreGetEntityList());
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵelement"](38, "bn-pull-to-refresh-spinner", 28);
      _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵelementStart"](39, "div", 29)(40, "div", 30)(41, "div", 31)(42, "h2", 32);
      _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵlistener"]("click", function HomePage_Template_h2_click_42_listener() {
        return ctx.changeParentAssetType(ctx.PARENT_ASSET_TYPE.ASSETS);
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵi18n"](43, 33);
      _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵtemplate"](44, HomePage_Conditional_44_Template, 2, 5, "h2", 34);
      _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵelementStart"](45, "button", 35);
      _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵtemplate"](46, HomePage_Conditional_46_Template, 1, 1)(47, HomePage_Conditional_47_Template, 2, 6);
      _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵtemplate"](48, HomePage_Conditional_48_Template, 2, 3, "ul", 36)(49, HomePage_Conditional_49_Template, 3, 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵelementEnd"]()()()();
      _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵelementStart"](50, "common-bottom-sheet", 37);
      _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵlistener"]("isOpenChange", function HomePage_Template_common_bottom_sheet_isOpenChange_50_listener($event) {
        return $event || (ctx.sheet_selectWalletTransaction = undefined);
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵtemplate"](51, HomePage_ng_template_51_Template, 1, 2, "ng-template");
      _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵelementStart"](52, "common-bottom-sheet", 37);
      _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵlistener"]("isOpenChange", function HomePage_Template_common_bottom_sheet_isOpenChange_52_listener($event) {
        return ctx.sheet_selectWallet.is_open = $event;
      })("isOpenChange", function HomePage_Template_common_bottom_sheet_isOpenChange_52_listener($event) {
        return ctx.checkHomeSelectWalletOpen($event);
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵtemplate"](53, HomePage_ng_template_53_Template, 1, 1, "ng-template");
      _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵelementStart"](54, "common-bottom-sheet", 37);
      _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵlistener"]("isOpenChange", function HomePage_Template_common_bottom_sheet_isOpenChange_54_listener($event) {
        return ctx.sheet_selectChainAddress.is_open = $event;
      })("isOpenChange", function HomePage_Template_common_bottom_sheet_isOpenChange_54_listener($event) {
        return ctx.checkHomeSelectChainAddressOpen($event);
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵtemplate"](55, HomePage_ng_template_55_Template, 1, 0, "ng-template");
      _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵelementEnd"]();
    }
    if (rf & 2) {
      const _r2 = _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵreference"](9);
      _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵproperty"]("headerBackground", "grey")("headerTranslucent", false)("backButtonDisable", true)("contentBackground", "grey")("contentSafeArea", false);
      _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵconditional"](1, ctx.mainWalletInfo ? 1 : -1);
      _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵproperty"]("ngIf", _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵpipeBind1"](4, 36, ctx.online$) === false);
      _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵtextInterpolate1"](" ", ctx.activeWalletAddressInfo == null ? null : ctx.activeWalletAddressInfo.chain, " ");
      _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵpureFunction1"](45, _c8, _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵpipeBind1"](7, 38, "text-title")));
      _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵadvance"](4);
      _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵproperty"]("@fadeInDown", undefined);
      _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵadvance"](6);
      _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵtextInterpolate"](ctx.activeWalletAddressInfo == null ? null : ctx.activeWalletAddressInfo.name);
      _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵproperty"]("ngIf", ctx.skipBackup);
      _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵconditional"](19, (ctx.mainWalletInfo == null ? null : ctx.mainWalletInfo.importType) === ctx.WALLET_IMPORT_TYPE.mnemonic && (ctx.activeWalletAddressInfo == null ? null : ctx.activeWalletAddressInfo.chain) === ctx.CHAIN_NAME.Bitcoin ? 19 : -1);
      _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵtextInterpolate"]((ctx.activeWalletAddressInfo == null ? null : ctx.activeWalletAddressInfo.address) ? _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵpipeBind1"](22, 40, ctx.activeWalletAddressInfo == null ? null : ctx.activeWalletAddressInfo.address) : "");
      _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵproperty"]("wClickToCopy", ctx.activeWalletAddressInfo == null ? null : ctx.activeWalletAddressInfo.address);
      _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵproperty"]("ngIf", !!(ctx.activeWalletAddressInfo == null ? null : ctx.activeWalletAddressInfo.isFreezed));
      _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵproperty"]("name", _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵpipeBind2"](27, 42, ctx.activeWalletAddressInfo == null ? null : ctx.activeWalletAddressInfo.symbol, _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵpureFunction1"](47, _c32, ctx.activeWalletAddressInfo == null ? null : ctx.activeWalletAddressInfo.chain)));
      _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵproperty"]("animationType", "none")("routerLink", _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵpureFunction0"](49, _c33));
      _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵadvance"](4);
      _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵproperty"]("animationType", "none")("routerLink", _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵpureFunction0"](50, _c34))("queryParams", _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵpureFunction4"](51, _c35, ctx.activeWalletAddressInfo == null ? null : ctx.activeWalletAddressInfo.chain, ctx.activeWalletAddressInfo == null ? null : ctx.activeWalletAddressInfo.symbol, ctx.activeWalletAddressInfo == null ? null : ctx.activeWalletAddressInfo.address, ctx.activeWalletAddressInfo == null ? null : ctx.activeWalletAddressInfo.symbol));
      _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵadvance"](4);
      _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵproperty"]("pullScrollElement", _r2)("infiniteScrollElement", _r2)("hasMore", ctx.activeParentAssetType === ctx.PARENT_ASSET_TYPE.ENTITY && !ctx.refreshAssetsTask && ctx.addressEntityInfo.hasMore);
      _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵadvance"](5);
      _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵpureFunction3"](56, _c36, ctx.showParentAssetTypeEntity && ctx.activeParentAssetType === ctx.PARENT_ASSET_TYPE.ASSETS, ctx.activeParentAssetType === ctx.PARENT_ASSET_TYPE.ASSETS, ctx.activeParentAssetType !== ctx.PARENT_ASSET_TYPE.ASSETS));
      _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵconditional"](44, ctx.showParentAssetTypeEntity ? 44 : -1);
      _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵconditional"](46, ctx.activeParentAssetType === ctx.PARENT_ASSET_TYPE.ASSETS ? 46 : 47);
      _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵconditional"](48, ctx.activeParentAssetType === ctx.PARENT_ASSET_TYPE.ASSETS ? 48 : 49);
      _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵproperty"]("isOpen", ctx.sheet_selectWalletTransaction)("panelClass", "h-2/3");
      _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵproperty"]("isOpen", ctx.sheet_selectWallet.is_open)("panelClass", "h-5/6");
      _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_43__["ɵɵproperty"]("isOpen", ctx.sheet_selectChainAddress.is_open)("panelClass", "h-5/6");
    }
  },
  dependencies: [_pages_select_wallet_transation_select_wallet_transation_component__WEBPACK_IMPORTED_MODULE_24__.SelectWalletTransationPage, _pages_home_select_chain_address_home_select_chain_address_component__WEBPACK_IMPORTED_MODULE_22__.HomeSelectChainAddressPage, _pages_home_select_wallet_home_select_wallet_component__WEBPACK_IMPORTED_MODULE_23__.HomeSelectWalletPage, _modules_page_module__WEBPACK_IMPORTED_MODULE_16__.CommonPageModule, _libs_bnf_modules_bottom_sheet_components_bottom_sheet_component__WEBPACK_IMPORTED_MODULE_27__.BottomSheetComponent, _libs_bnf_components_ripple_button_ripple_button_directive__WEBPACK_IMPORTED_MODULE_28__.RippleButtonDirective, _libs_bnf_components_pull_to_refresh_pull_to_refresh_directive__WEBPACK_IMPORTED_MODULE_29__.PullToRefreshDirective, _libs_bnf_components_pull_to_refresh_pull_to_refresh_spinner_component__WEBPACK_IMPORTED_MODULE_30__.PullToRefreshSpinnerComponent, _libs_bnf_components_infinite_scroll_infinite_scroll_spinner_component__WEBPACK_IMPORTED_MODULE_31__.InfiniteScrollSpinnerComponent, _libs_bnf_directives_click_to_copy_directive__WEBPACK_IMPORTED_MODULE_32__.ClickToCopyDirective, _libs_bnf_directives_auto_complete_off_directive__WEBPACK_IMPORTED_MODULE_33__.AutoCompleteOffDirective, _libs_bnf_components_infinite_scroll_infinite_scroll_directive__WEBPACK_IMPORTED_MODULE_34__.InfiniteScrollDirective, _angular_common__WEBPACK_IMPORTED_MODULE_45__.NgClass, _angular_common__WEBPACK_IMPORTED_MODULE_45__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_45__.NgIf, _angular_forms__WEBPACK_IMPORTED_MODULE_46__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_46__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_46__.NgModel, _angular_router__WEBPACK_IMPORTED_MODULE_47__.RouterLink, _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_35__.CommonPageComponent, _components_icon_icon_component__WEBPACK_IMPORTED_MODULE_36__.IconComponent, _libs_bnf_components_loading_wrapper_loading_wrapper_component__WEBPACK_IMPORTED_MODULE_37__.LoadingWrapperComponent, _libs_bnf_pipes_number_format_number_format_pipe__WEBPACK_IMPORTED_MODULE_38__.NumberFormatPipe, _angular_common__WEBPACK_IMPORTED_MODULE_45__.AsyncPipe, _pipes_color_color_pipe__WEBPACK_IMPORTED_MODULE_39__.ColorPipe, _libs_bnf_pipes_address_hidden_address_hidden_pipe__WEBPACK_IMPORTED_MODULE_40__.AddressHiddenPipe, _libs_bnf_pipes_amountFixed_amount_fixed_pipe__WEBPACK_IMPORTED_MODULE_41__.AmountFixedPipe, _pipes_chainIcon_chain_icon_pipe__WEBPACK_IMPORTED_MODULE_42__.ChainIconPipe, _angular_router__WEBPACK_IMPORTED_MODULE_47__.RouterModule, _angular_material_button__WEBPACK_IMPORTED_MODULE_48__.MatButtonModule, _angular_material_expansion__WEBPACK_IMPORTED_MODULE_44__.MatExpansionModule, _angular_material_expansion__WEBPACK_IMPORTED_MODULE_44__.MatAccordion, _angular_material_expansion__WEBPACK_IMPORTED_MODULE_44__.MatExpansionPanel, _angular_material_expansion__WEBPACK_IMPORTED_MODULE_44__.MatExpansionPanelHeader, _angular_material_expansion__WEBPACK_IMPORTED_MODULE_44__.MatExpansionPanelTitle, _angular_material_expansion__WEBPACK_IMPORTED_MODULE_44__.MatExpansionPanelContent],
  styles: ["[_nghost-%COMP%]   ._bioforest_asset_logo[_ngcontent-%COMP%] {\n  width: 1em;\n  height: 1em;\n}\n[_nghost-%COMP%]   ._card-bg[_ngcontent-%COMP%] {\n  background-repeat: no-repeat;\n  background-image: url('home-card-bg.png');\n  background-size: 100% 100%;\n}\n[_nghost-%COMP%]   ._asset-type-active[_ngcontent-%COMP%] {\n  position: relative;\n}\n[_nghost-%COMP%]   ._asset-type-active[_ngcontent-%COMP%]::after {\n  bottom: -0.25rem;\n  height: 2px;\n  width: 100%;\n  border-radius: 9999px;\n  --tw-bg-opacity: 1;\n  background-color: rgb(146 103 254 / var(--tw-bg-opacity));\n  content: \" \";\n  position: absolute;\n  left: 0;\n}\n[_nghost-%COMP%]     ._entity-expansion-panel {\n  box-shadow: none !important;\n}\n[_nghost-%COMP%]     ._entity-expansion-panel w-icon[name=right] {\n  transform: rotateZ(0);\n  transition: transform 300ms;\n}\n[_nghost-%COMP%]     ._entity-expansion-panel.mat-expanded w-icon[name=right] {\n  transform: rotateZ(90deg);\n}\n[_nghost-%COMP%]     ._entity-expansion-panel .mat-expansion-panel-body {\n  padding-inline: 0 !important;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL2FwcHMvd2FsbGV0L3NyYy9wYWdlcy9ob21lL2hvbWUuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQ0U7RUFDRSxVQUFBO0VBQ0EsV0FBQTtBQUFKO0FBR0k7RUFBQSw0QkFBQTtFQUNBLHlDQUFBO0VBQ0E7QUFGQTtBQUlGO0VBQ0Usa0JBQUE7QUFBSjtBQUVNO0VBQUEsZ0JBQUE7RUFBQSxXQUFBO0VBQUEsV0FBQTtFQUFBLHFCQUFBO0VBQUEsa0JBQUE7RUFBQSx5REFBQTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtFQUNBO0FBSEE7QUFPRjtFQUNFLDJCQUFBO0FBRE47QUFFTTtFQUNFLHFCQUFBO0VBQ0EsMkJBQUE7QUFBUjtBQUdRO0VBQ0UseUJBQUE7QUFEVjtBQUlNO0VBQ0UsNEJBQUE7QUFGUiIsInNvdXJjZXNDb250ZW50IjpbIjpob3N0IHtcclxuICAuX2Jpb2ZvcmVzdF9hc3NldF9sb2dvIHtcclxuICAgIHdpZHRoOiAxZW07XHJcbiAgICBoZWlnaHQ6IDFlbTtcclxuICB9XHJcbiAgLl9jYXJkLWJnIHtcclxuICAgIEBhcHBseSBiZy1uby1yZXBlYXQ7XHJcbiAgICBiYWNrZ3JvdW5kLWltYWdlOiB1cmwoJy4vYXNzZXRzL2ltYWdlcy9ob21lLWNhcmQtYmcucG5nJyk7XHJcbiAgICBiYWNrZ3JvdW5kLXNpemU6IDEwMCUgMTAwJTtcclxuICB9XHJcbiAgLl9hc3NldC10eXBlLWFjdGl2ZSB7XHJcbiAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgICAmOjphZnRlciB7XHJcbiAgICAgIEBhcHBseSBiZy1wcmltYXJ5IHctZnVsbCBoLVsycHhdIHJvdW5kZWQtZnVsbCAtYm90dG9tLTE7XHJcbiAgICAgIGNvbnRlbnQ6IFwiIFwiO1xyXG4gICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICAgIGxlZnQ6IDA7XHJcbiAgICB9XHJcbiAgfVxyXG4gIDo6bmctZGVlcCB7XHJcbiAgICAuX2VudGl0eS1leHBhbnNpb24tcGFuZWwge1xyXG4gICAgICBib3gtc2hhZG93OiBub25lICFpbXBvcnRhbnQ7XHJcbiAgICAgIHctaWNvbltuYW1lPVwicmlnaHRcIl0ge1xyXG4gICAgICAgIHRyYW5zZm9ybTogcm90YXRlWigwKTtcclxuICAgICAgICB0cmFuc2l0aW9uOiB0cmFuc2Zvcm0gMzAwbXM7XHJcbiAgICAgIH1cclxuICAgICAgJi5tYXQtZXhwYW5kZWQge1xyXG4gICAgICAgIHctaWNvbltuYW1lPVwicmlnaHRcIl0ge1xyXG4gICAgICAgICAgdHJhbnNmb3JtOiByb3RhdGVaKDkwZGVnKTtcclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgICAgLm1hdC1leHBhbnNpb24tcGFuZWwtYm9keSB7XHJcbiAgICAgICAgcGFkZGluZy1pbmxpbmU6IDAgIWltcG9ydGFudDtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH1cclxufVxyXG4iXSwic291cmNlUm9vdCI6IiJ9 */"],
  data: {
    animation: [_bnqkl_framework_animations__WEBPACK_IMPORTED_MODULE_1__.fadeInDownTrigger, _bnqkl_framework_animations__WEBPACK_IMPORTED_MODULE_1__.listFadeInRightTrigger]
  },
  changeDetection: 0
});
(0,tslib__WEBPACK_IMPORTED_MODULE_49__.__decorate)([HomePage.States(), (0,tslib__WEBPACK_IMPORTED_MODULE_49__.__metadata)("design:type", Object)], HomePage.prototype, "activeParentAssetType", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_49__.__decorate)([HomePage.States(), (0,tslib__WEBPACK_IMPORTED_MODULE_49__.__metadata)("design:type", Object)], HomePage.prototype, "activeWalletAddressInfo", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_49__.__decorate)([HomePage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_49__.__metadata)("design:type", Object)], HomePage.prototype, "mainWalletInfo", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_49__.__decorate)([HomePage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_49__.__metadata)("design:type", Object)], HomePage.prototype, "homeMainWalletEditPageReturnController", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_49__.__decorate)([HomePage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_49__.__metadata)("design:type", Object)], HomePage.prototype, "homeAddTokenPageReturnController", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_49__.__decorate)([HomePage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_49__.__metadata)("design:type", Object)], HomePage.prototype, "mnemonicConfirmBackupPageturnController", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_49__.__decorate)([HomePage.States(), (0,tslib__WEBPACK_IMPORTED_MODULE_49__.__metadata)("design:type", Object)], HomePage.prototype, "skipBackup", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_49__.__decorate)([HomePage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_49__.__metadata)("design:type", Object)], HomePage.prototype, "scannerPageReturnController", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_49__.__decorate)([HomePage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_49__.__metadata)("design:type", Object)], HomePage.prototype, "lastWalletActivate$", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_49__.__decorate)([HomePage.OnDestroy(), (0,tslib__WEBPACK_IMPORTED_MODULE_49__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_49__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_49__.__metadata)("design:returntype", void 0)], HomePage.prototype, "_clearQueryTask", null);
(0,tslib__WEBPACK_IMPORTED_MODULE_49__.__decorate)([HomePage.OnReady(), (0,tslib__WEBPACK_IMPORTED_MODULE_49__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_49__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_49__.__metadata)("design:returntype", Promise)], HomePage.prototype, "initMainWallet", null);
(0,tslib__WEBPACK_IMPORTED_MODULE_49__.__decorate)([HomePage.OnInit(), (0,tslib__WEBPACK_IMPORTED_MODULE_49__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_49__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_49__.__metadata)("design:returntype", Promise)], HomePage.prototype, "watchPageReturn", null);
(0,tslib__WEBPACK_IMPORTED_MODULE_49__.__decorate)([HomePage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_49__.__metadata)("design:type", Object)], HomePage.prototype, "sheet_selectWalletTransaction", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_49__.__decorate)([HomePage.States(1), (0,tslib__WEBPACK_IMPORTED_MODULE_49__.__metadata)("design:type", Object)], HomePage.prototype, "sheet_selectWallet", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_49__.__decorate)([HomePage.States(1), (0,tslib__WEBPACK_IMPORTED_MODULE_49__.__metadata)("design:type", Object)], HomePage.prototype, "sheet_selectChainAddress", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_49__.__decorate)([HomePage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_49__.__metadata)("design:type", Object)], HomePage.prototype, "refreshAssetsTask", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_49__.__decorate)([HomePage.States(), (0,tslib__WEBPACK_IMPORTED_MODULE_49__.__metadata)("design:type", Object)], HomePage.prototype, "addressEntityInfo", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_49__.__decorate)([HomePage.States(), (0,tslib__WEBPACK_IMPORTED_MODULE_49__.__metadata)("design:type", Object)], HomePage.prototype, "inputSearchContent", void 0);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (HomePage);

/***/ }),

/***/ 15298:
/*!***********************************************************************************************************!*\
  !*** ./apps/wallet/src/pages/home/pages/home-select-chain-address/home-select-chain-address.component.ts ***!
  \***********************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   HomeSelectChainAddressPage: () => (/* binding */ HomeSelectChainAddressPage),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 52542);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! tslib */ 90505);
/* harmony import */ var _bnqkl_framework_animations__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @bnqkl/framework/animations */ 43127);
/* harmony import */ var _bnqkl_wallet_base_services_wallet__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @bnqkl/wallet-base/services/wallet */ 20609);
/* harmony import */ var _bnqkl_wallet_base_services_wallet_bitcoin__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @bnqkl/wallet-base/services/wallet/bitcoin */ 59132);
/* harmony import */ var _modules_page_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ~modules/page.module */ 77538);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/core */ 61039);
/* harmony import */ var _libs_bnf_components_ripple_button_ripple_button_directive__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../../../../../libs/bnf/components/ripple-button/ripple-button.directive */ 16505);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/common */ 6729);
/* harmony import */ var _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../../../../../libs/bnf/modules/page/common-page/common-page.component */ 62052);
/* harmony import */ var _components_icon_icon_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../../components/icon/icon.component */ 74703);
/* harmony import */ var _pipes_color_color_pipe__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../../pipes/color/color.pipe */ 76489);
/* harmony import */ var _pipes_chainIcon_chain_icon_pipe__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../../../pipes/chainIcon/chain-icon.pipe */ 43040);

var _class;












const _c2 = a0 => ({
  "--color-1": a0
});
const _c3 = a1 => ({
  prefix: "icon",
  chain: a1
});
function HomeSelectChainAddressPage_li_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r3 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "li")(1, "button", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("click", function HomeSelectChainAddressPage_li_2_Template_button_click_1_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵrestoreView"](_r3);
      const item_r1 = restoredCtx.$implicit;
      const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵresetView"](ctx_r2.onClickChainItem(item_r1));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](2, "div", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](3, "w-icon", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpipe"](4, "color");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](5, "div", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](6, "w-icon", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpipe"](7, "chainIcon");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](8, "div", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](9);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()()()()();
  }
  if (rf & 2) {
    const item_r1 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngStyle", _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpureFunction1"](8, _c2, item_r1.actived ? _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpipeBind1"](4, 3, "primart") : "transparent"));
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("name", _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpipeBind2"](7, 5, item_r1.symbol, _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpureFunction1"](10, _c3, item_r1.chain)));
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtextInterpolate"](item_r1.chain);
  }
}
/**
 * 管理钱包的页面
 */
class HomeSelectChainAddressPage extends _modules_page_module__WEBPACK_IMPORTED_MODULE_4__.CommonPageBase {
  constructor() {
    super(...arguments);
    /** 返回类型 */
    this.returnValue$ = new _modules_page_module__WEBPACK_IMPORTED_MODULE_4__.PageReturnValue();
    this.chainAddressList = [];
    this.allChainAddressList = [];
  }
  /** 获取激活的钱包对应的链地址列表 */
  init() {
    var _this = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const walletDataStorageV2Service = _this.injectorForceGet(_bnqkl_wallet_base_services_wallet__WEBPACK_IMPORTED_MODULE_2__.WalletDataStorageV2Service);
      const activedChainAddress = walletDataStorageV2Service.getLastWalletActivate();
      _this.mainWallet = yield walletDataStorageV2Service.getMainWalletInfo(activedChainAddress.mainWalletId);
      const chainName_Set = new Set();
      _this.allChainAddressList = _this.mainWallet.addressKeyList.map(item => {
        return {
          chain: item.chainName,
          symbol: item.symbol,
          actived: item.chainName === activedChainAddress.chain,
          addressKey: item.addressKey,
          index: item.index,
          purpose: item.purpose
        };
      }).sort((a, b) => a.chain > b.chain ? 1 : -1);
      _this.chainAddressList = _this.allChainAddressList.filter(item => {
        if (chainName_Set.has(item.chain)) {
          return false;
        }
        chainName_Set.add(item.chain);
        return true;
      });
      _this.cdRef.detectChanges();
    })();
  }
  /** 选择身份钱包 */
  onClickChainItem(event) {
    var _this2 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      var _this2$chainAddressLi;
      let addressKey = event.addressKey;
      const walletDataStorageV2Service = _this2.injectorForceGet(_bnqkl_wallet_base_services_wallet__WEBPACK_IMPORTED_MODULE_2__.WalletDataStorageV2Service);
      const activedChainAddress = walletDataStorageV2Service.getLastWalletActivate();
      if (activedChainAddress.chain === event.chain) {
        return _this2.returnValue$.return(undefined);
      }
      (_this2$chainAddressLi = _this2.chainAddressList) === null || _this2$chainAddressLi === void 0 || _this2$chainAddressLi.forEach(item => item.actived = false);
      event.actived = true;
      _this2.cdRef.detectChanges();
      /// 由于有bitcoin多地址的情况，这边要判断一次
      if (event.chain === _bnqkl_wallet_base_services_wallet__WEBPACK_IMPORTED_MODULE_2__.CHAIN_NAME.Bitcoin) {
        /// 判断之前激活哪个地址
        if (_this2.mainWallet && _this2.mainWallet.lastBitcoinAddressKey) {
          addressKey = _this2.mainWallet.lastBitcoinAddressKey;
        } else {
          const find = _this2.allChainAddressList.find(item => item.purpose === _bnqkl_wallet_base_services_wallet_bitcoin__WEBPACK_IMPORTED_MODULE_3__.DEFAULT_PURPOSE && item.index === 0);
          find && (addressKey = find.addressKey);
        }
      }
      const addressInfo = yield walletDataStorageV2Service.getChainAddressInfo(addressKey);
      _this2.returnValue$.return(addressInfo);
    })();
  }
}
_class = HomeSelectChainAddressPage;
_class.ɵfac = /*@__PURE__*/(() => {
  let ɵHomeSelectChainAddressPage_BaseFactory;
  return function HomeSelectChainAddressPage_Factory(t) {
    return (ɵHomeSelectChainAddressPage_BaseFactory || (ɵHomeSelectChainAddressPage_BaseFactory = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵgetInheritedFactory"](_class)))(t || _class);
  };
})();
_class.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵdefineComponent"]({
  type: _class,
  selectors: [["w-home-select-chain-address-page"]],
  outputs: {
    returnValue$: "returnValue$"
  },
  standalone: true,
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵInheritDefinitionFeature"], _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵStandaloneFeature"]],
  decls: 3,
  vars: 7,
  consts: () => {
    let i18n_0;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_SELECTION_CHAIN$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_SELECT_CHAIN_ADDRESS_HOME_SELECT_CHAIN_ADDRESS_COMPONENT_TS_1 = goog.getMsg("Selection Chain");
      i18n_0 = MSG_EXTERNAL_SELECTION_CHAIN$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_SELECT_CHAIN_ADDRESS_HOME_SELECT_CHAIN_ADDRESS_COMPONENT_TS_1;
    } else {
      i18n_0 = "Selection Chain";
    }
    return [["headerTitle", i18n_0, 3, "contentBackground", "contentSafeArea", "titleColor", "headerBackground"], [1, "w-full", "bg-white"], [4, "ngFor", "ngForOf", "ngForTrackBy"], ["bnRippleButton", "", 1, "border-b-tiny", "border-line", "flex", "w-full", "items-center", "justify-start", "px-2", "py-4", 3, "click"], [1, "flex", "items-center", "justify-start"], ["name", "language-selected-1", 1, "border-tiny", "border-subtext", "mr-2", "mt-[2px]", "rounded-[4px]", "p-[2px]", 3, "ngStyle"], [1, "ml-2", "flex", "items-center", "justify-start"], [1, "mr-2", "justify-self-start", "text-3xl", 3, "name"], [1, "text-xs", "font-bold"]];
  },
  template: function HomeSelectChainAddressPage_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "common-page", 0)(1, "ul", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](2, HomeSelectChainAddressPage_li_2_Template, 10, 12, "li", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()();
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("contentBackground", "white")("contentSafeArea", true)("titleColor", "title")("headerBackground", "white");
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("@listFadeInRight", ctx.chainAddressList.length);
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngForOf", ctx.chainAddressList)("ngForTrackBy", ctx.trackByKey("addressKey"));
    }
  },
  dependencies: [_modules_page_module__WEBPACK_IMPORTED_MODULE_4__.CommonPageModule, _libs_bnf_components_ripple_button_ripple_button_directive__WEBPACK_IMPORTED_MODULE_5__.RippleButtonDirective, _angular_common__WEBPACK_IMPORTED_MODULE_11__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_11__.NgStyle, _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_6__.CommonPageComponent, _components_icon_icon_component__WEBPACK_IMPORTED_MODULE_7__.IconComponent, _pipes_color_color_pipe__WEBPACK_IMPORTED_MODULE_8__.ColorPipe, _pipes_chainIcon_chain_icon_pipe__WEBPACK_IMPORTED_MODULE_9__.ChainIconPipe],
  styles: ["/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsInNvdXJjZVJvb3QiOiIifQ== */"],
  data: {
    animation: [_bnqkl_framework_animations__WEBPACK_IMPORTED_MODULE_1__.listFadeInRightTrigger]
  },
  changeDetection: 0
});
(0,tslib__WEBPACK_IMPORTED_MODULE_12__.__decorate)([HomeSelectChainAddressPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_12__.__metadata)("design:type", Object)], HomeSelectChainAddressPage.prototype, "chainAddressList", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_12__.__decorate)([HomeSelectChainAddressPage.OnInit(), (0,tslib__WEBPACK_IMPORTED_MODULE_12__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_12__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_12__.__metadata)("design:returntype", Promise)], HomeSelectChainAddressPage.prototype, "init", null);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (HomeSelectChainAddressPage);

/***/ }),

/***/ 96535:
/*!*********************************************************************************************************!*\
  !*** ./apps/wallet/src/pages/home/pages/select-wallet-transation/select-wallet-transation.component.ts ***!
  \*********************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   SelectWalletTransationPage: () => (/* binding */ SelectWalletTransationPage),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 52542);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! tslib */ 90505);
/* harmony import */ var _bnqkl_framework_plugins_toast__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @bnqkl/framework/plugins/toast */ 18030);
/* harmony import */ var _modules_page_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ~modules/page.module */ 77538);
/* harmony import */ var _pages_home_components_wallet_list_wallet_list_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ~pages/home/components/wallet-list/wallet-list.component */ 79345);
/* harmony import */ var _select_wallet_transation_resolver__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./select-wallet-transation.resolver */ 13691);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 61039);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common */ 6729);
/* harmony import */ var _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../../../../../libs/bnf/modules/page/common-page/common-page.component */ 62052);

var _class;








const _c2 = a0 => [a0];
function SelectWalletTransationPage_w_home_wallet_list_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r2 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "w-home-wallet-list", 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("clickWalletItem", function SelectWalletTransationPage_w_home_wallet_list_1_Template_w_home_wallet_list_clickWalletItem_0_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵrestoreView"](_r2);
      const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵresetView"](ctx_r1.selectWallet($event));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("mainWalletList", ctx_r0.walletList.mainWalletList)("disabledAddressList", _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵpureFunction1"](7, _c2, ctx_r0.filter.QR_address))("selectable", false)("paddingTop", "var(--page-content-padding-top, 0px)")("paddingBottom", "var(--page-content-padding-bottom, 0px)")("paddingLeft", "var(--page-safe-area-inset-left, 0px)")("paddingRight", "var(--page-safe-area-inset-right, 0px)");
  }
}
class SelectWalletTransationPage extends _modules_page_module__WEBPACK_IMPORTED_MODULE_2__.CommonPageBase {
  constructor() {
    super(...arguments);
    /** 返回类型是一个钱包 */
    this.returnValue$ = new _modules_page_module__WEBPACK_IMPORTED_MODULE_2__.PageReturnValue();
  }
  /** 初始化数据 */
  initWalletData() {
    var _this = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      var _this$resolveData$wal, _this$resolveData;
      _this.walletList = /// TODO 这里应该基于路由检测来获取 walletList
      (_this$resolveData$wal = (_this$resolveData = _this.resolveData) === null || _this$resolveData === void 0 ? void 0 : _this$resolveData.walletList) !== null && _this$resolveData$wal !== void 0 ? _this$resolveData$wal : yield _this.injectorForceGet(_select_wallet_transation_resolver__WEBPACK_IMPORTED_MODULE_4__.SelectWalletTransationComResolver)._resolve(_this.filter);
    })();
  }
  /** 初始化数据 */
  destroyReturn() {
    var _this2 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this2.returnValue$.next(undefined);
    })();
  }
  /** 选择钱包, 返回内容 */
  selectWallet(item) {
    var _this3 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      if (_this3.filter.QR_address === item.address) {
        _bnqkl_framework_plugins_toast__WEBPACK_IMPORTED_MODULE_1__.Toast.show("Receive cannot be the same", 'short');
      } else {
        _this3.returnValue$.next({
          addressInfo: item,
          address: _this3.filter.QR_address
        });
      }
      _this3.returnValue$.complete();
    })();
  }
}
_class = SelectWalletTransationPage;
_class.ɵfac = /*@__PURE__*/(() => {
  let ɵSelectWalletTransationPage_BaseFactory;
  return function SelectWalletTransationPage_Factory(t) {
    return (ɵSelectWalletTransationPage_BaseFactory || (ɵSelectWalletTransationPage_BaseFactory = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵgetInheritedFactory"](_class)))(t || _class);
  };
})();
_class.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdefineComponent"]({
  type: _class,
  selectors: [["w-home-select-wallet-transation-page"]],
  inputs: {
    filter: "filter",
    walletList: "walletList"
  },
  outputs: {
    returnValue$: "returnValue$"
  },
  standalone: true,
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵInheritDefinitionFeature"], _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵStandaloneFeature"]],
  decls: 2,
  vars: 4,
  consts: () => {
    let i18n_0;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_SELECT_TRANSFER_CHAIN$$APPS_WALLET_SRC_PAGES_HOME_PAGES_SELECT_WALLET_TRANSATION_SELECT_WALLET_TRANSATION_COMPONENT_TS_1 = goog.getMsg("Select transfer chain");
      i18n_0 = MSG_EXTERNAL_SELECT_TRANSFER_CHAIN$$APPS_WALLET_SRC_PAGES_HOME_PAGES_SELECT_WALLET_TRANSATION_SELECT_WALLET_TRANSATION_COMPONENT_TS_1;
    } else {
      i18n_0 = "Select transfer chain";
    }
    return [["headerTitle", i18n_0, 3, "contentBackground", "contentSafeArea", "contentClass"], ["class", "h-full", 3, "mainWalletList", "disabledAddressList", "selectable", "paddingTop", "paddingBottom", "paddingLeft", "paddingRight", "clickWalletItem", 4, "ngIf"], [1, "h-full", 3, "mainWalletList", "disabledAddressList", "selectable", "paddingTop", "paddingBottom", "paddingLeft", "paddingRight", "clickWalletItem"]];
  },
  template: function SelectWalletTransationPage_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "common-page", 0);
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](1, SelectWalletTransationPage_w_home_wallet_list_1_Template, 1, 9, "w-home-wallet-list", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("contentBackground", "white")("contentSafeArea", true)("contentClass", "!p-0");
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx.walletList);
    }
  },
  dependencies: [_modules_page_module__WEBPACK_IMPORTED_MODULE_2__.CommonPageModule, _angular_common__WEBPACK_IMPORTED_MODULE_7__.NgIf, _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_5__.CommonPageComponent, _pages_home_components_wallet_list_wallet_list_component__WEBPACK_IMPORTED_MODULE_3__.WalletListComponent],
  styles: ["/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsInNvdXJjZVJvb3QiOiIifQ== */"],
  changeDetection: 0
});
(0,tslib__WEBPACK_IMPORTED_MODULE_8__.__decorate)([SelectWalletTransationPage.State(), SelectWalletTransationPage.QueryParams(), (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__metadata)("design:type", Object)], SelectWalletTransationPage.prototype, "filter", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_8__.__decorate)([SelectWalletTransationPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__metadata)("design:type", Object)], SelectWalletTransationPage.prototype, "walletList", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_8__.__decorate)([SelectWalletTransationPage.OnReady(), (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__metadata)("design:returntype", Promise)], SelectWalletTransationPage.prototype, "initWalletData", null);
(0,tslib__WEBPACK_IMPORTED_MODULE_8__.__decorate)([SelectWalletTransationPage.OnDestroy(), (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__metadata)("design:returntype", Promise)], SelectWalletTransationPage.prototype, "destroyReturn", null);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SelectWalletTransationPage);

/***/ }),

/***/ 13691:
/*!********************************************************************************************************!*\
  !*** ./apps/wallet/src/pages/home/pages/select-wallet-transation/select-wallet-transation.resolver.ts ***!
  \********************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   SelectWalletTransationComResolver: () => (/* binding */ SelectWalletTransationComResolver),
/* harmony export */   SelectWalletTransationResolver: () => (/* binding */ SelectWalletTransationResolver),
/* harmony export */   selectWalletTransationComResolver: () => (/* binding */ selectWalletTransationComResolver),
/* harmony export */   selectWalletTransationResolver: () => (/* binding */ selectWalletTransationResolver)
/* harmony export */ });
/* harmony import */ var D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 52542);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 61039);
/* harmony import */ var _bnqkl_wallet_base_services_wallet_chain__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @bnqkl/wallet-base/services/wallet/chain */ 27434);
/* harmony import */ var _bnqkl_wallet_base_services_wallet_wallet_data_storage__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @bnqkl/wallet-base/services/wallet/wallet-data-storage */ 63024);

var _class;




/** 选择地址进行交易 组件的数据解析器 */
class SelectWalletTransationComResolver {
  constructor() {
    /** 链服务 */
    this.chainV2Service = (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.inject)(_bnqkl_wallet_base_services_wallet_chain__WEBPACK_IMPORTED_MODULE_1__.ChainV2Service);
    /** 钱包数据服务 */
    this.walletDataStorageV2Service = (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.inject)(_bnqkl_wallet_base_services_wallet_wallet_data_storage__WEBPACK_IMPORTED_MODULE_2__.WalletDataStorageV2Service);
  }
  /** 尝试获取可以与目标地址交易的的钱包列表信息  */
  resolve(route) {
    const filter = route.queryParams;
    if (filter._chainType && filter.QR_address) {
      return this._resolve(filter);
    }
  }
  /** 获取可以与目标地址交易的的钱包列表信息 */
  _resolve(filter) {
    var _this = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const supportChainList = yield _this.chainV2Service.supportChainList();
      /** 根据二维码扫描的地址类型查找出相同类型的链 */
      const _filterChainList = supportChainList.filter(chain => {
        var _filter$_chainType;
        return (_filter$_chainType = filter._chainType) === null || _filter$_chainType === void 0 ? void 0 : _filter$_chainType.find(item => item === chain.chain);
      }).map(item => item.chain);
      const allMainList = yield _this.walletDataStorageV2Service.getAllMainWalletInfo();
      const filterMainList = allMainList.map(main => {
        return {
          ...main,
          addressKeyList: main.addressKeyList.filter(value => _filterChainList.includes(value.chainName))
        };
      });
      /** 默认选中的钱包,这里其实不需要选中 */
      const selectedWallet = _this.walletDataStorageV2Service.getLastWalletActivate();
      return {
        mainWalletList: filterMainList.filter(item => !!item.addressKeyList.length),
        selectedWallet
      };
    })();
  }
}
/** 选择地址进行交易 数据解析器 */
_class = SelectWalletTransationComResolver;
_class.ɵfac = function SelectWalletTransationComResolver_Factory(t) {
  return new (t || _class)();
};
_class.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineInjectable"]({
  token: _class,
  factory: _class.ɵfac,
  providedIn: 'root'
});
const SelectWalletTransationResolver = /*#__PURE__*/function () {
  var _ref = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (route) {
    const filter = route.queryParams;
    const walletDataStorageV2Service = (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.inject)(_bnqkl_wallet_base_services_wallet_wallet_data_storage__WEBPACK_IMPORTED_MODULE_2__.WalletDataStorageV2Service);
    const chainV2Service = (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.inject)(_bnqkl_wallet_base_services_wallet_chain__WEBPACK_IMPORTED_MODULE_1__.ChainV2Service);
    if (filter._chainType && filter.QR_address) {
      const supportChainList = yield chainV2Service.supportChainList();
      /** 根据二维码扫描的地址类型查找出相同类型的链 */
      const _filterChainList = supportChainList.filter(chain => {
        var _filter$_chainType2;
        return (_filter$_chainType2 = filter._chainType) === null || _filter$_chainType2 === void 0 ? void 0 : _filter$_chainType2.find(item => item === chain.chain);
      }).map(item => item.chain);
      const allMainList = yield walletDataStorageV2Service.getAllMainWalletInfo();
      const filterMainList = allMainList.map(main => {
        return {
          ...main,
          addressKeyList: main.addressKeyList.filter(value => _filterChainList.includes(value.chainName))
        };
      });
      /** 默认选中的钱包,这里其实不需要选中 */
      const selectedWallet = walletDataStorageV2Service.getLastWalletActivate();
      return {
        mainWalletList: filterMainList.filter(item => !!item.addressKeyList.length),
        selectedWallet
      };
    }
  });
  return function SelectWalletTransationResolver(_x) {
    return _ref.apply(this, arguments);
  };
}();
/** ResolveData */
const selectWalletTransationResolver = {
  walletList: SelectWalletTransationResolver
};
/** Com ResolveData */
const selectWalletTransationComResolver = {
  walletList: SelectWalletTransationComResolver
};

/***/ }),

/***/ 69899:
/*!*****************************************************************************************!*\
  !*** ./node_modules/.pnpm/@plaoc+is-dweb@0.1.0/node_modules/@plaoc/is-dweb/esm/main.js ***!
  \*****************************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   dwebTarget: () => (/* binding */ dwebTarget),
/* harmony export */   isDweb: () => (/* binding */ isDweb),
/* harmony export */   isMobile: () => (/* binding */ isMobile)
/* harmony export */ });
/**
 * 判断是不是dweb
 * * @returns boolean
 */
const isDweb = () => {
  const isDweb = self.navigator.userAgent.includes("Dweb");
  // @ts-ignore
  const isPlaoc = self.__native_close_watcher_kit__ !== void 0;
  if (isDweb || isPlaoc) {
    return true;
  }
  const userAgentData = self.navigator.userAgentData;
  if (!userAgentData) {
    return false;
  }
  const brands = userAgentData.brands.filter(value => {
    return value.brand === "DwebBrowser";
  });
  return Array.isArray(brands) && brands.length > 0;
};
/**
 * 判断dweb大版本
 * @returns boolean
 */
const dwebTarget = () => {
  if (isDweb()) {
    const userAgentData = self.navigator.userAgentData;
    if (!userAgentData) {
      return 2.0;
    }
    const brands = userAgentData.brands.filter(value => {
      return value.brand === "jmm.browser.dweb";
    });
    if (Array.isArray(brands) && brands.length > 0) {
      return parseFloat(brands[0].version);
    }
  }
  return 1.0;
};
/**
 * 判断是否是移动端
 * @returns boolean
 */
const isMobile = () => {
  if (!navigator.userAgentData) {
    return true;
  }
  return !!navigator.userAgentData.mobile;
};

/***/ })

}]);
//# sourceMappingURL=default-apps_wallet_src_pages_home_home_component_ts.js.map