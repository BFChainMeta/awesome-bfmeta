"use strict";
(self["webpackChunkwallet"] = self["webpackChunkwallet"] || []).push([["default-apps_wallet_src_pages_mime_pages_address-book_address-book_component_ts"],{

/***/ 35866:
/*!*********************************************************************************!*\
  !*** ./apps/wallet/src/pages/mime/pages/address-book/address-book.component.ts ***!
  \*********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AddressBookPage: () => (/* binding */ AddressBookPage),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 52542);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! tslib */ 90505);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/core */ 61039);
/* harmony import */ var _bnqkl_framework_controllers__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @bnqkl/framework/controllers */ 47919);
/* harmony import */ var _modules_page_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ~modules/page.module */ 77538);
/* harmony import */ var _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @bnqkl/wallet-base/services/wallet/chain-base */ 27187);
/* harmony import */ var _bnqkl_wallet_base_services_wallet_chain__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @bnqkl/wallet-base/services/wallet/chain */ 27434);
/* harmony import */ var _modify_address_modify_address_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../modify-address/modify-address.component */ 48072);
/* harmony import */ var _operate_address_operate_address_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../operate-address/operate-address.component */ 70343);
/* harmony import */ var _bnqkl_wallet_base_services_wallet__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @bnqkl/wallet-base/services/wallet */ 20609);
/* harmony import */ var _libs_bnf_modules_bottom_sheet_components_bottom_sheet_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../../../../../libs/bnf/modules/bottom-sheet/components/bottom-sheet.component */ 94072);
/* harmony import */ var _libs_bnf_components_ripple_button_ripple_button_directive__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../../../../../../libs/bnf/components/ripple-button/ripple-button.directive */ 16505);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/common */ 6729);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @angular/router */ 56776);
/* harmony import */ var _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../../../../../../libs/bnf/modules/page/common-page/common-page.component */ 62052);
/* harmony import */ var _components_icon_icon_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../../../components/icon/icon.component */ 74703);
/* harmony import */ var _pipes_chainIcon_chain_icon_pipe__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../../../pipes/chainIcon/chain-icon.pipe */ 43040);

var _class;

















function AddressBookPage_ng_container_5_label_8_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "label", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const item_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtextInterpolate"](item_r2.remarks);
  }
}
const _c4 = a1 => ({
  prefix: "icon",
  chain: a1
});
function AddressBookPage_ng_container_5_For_11_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](0, "w-icon", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipe"](1, "chainIcon");
  }
  if (rf & 2) {
    const chain_r6 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("name", _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipeBind2"](1, 1, chain_r6.symbol, _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpureFunction1"](4, _c4, chain_r6.chain)));
  }
}
function AddressBookPage_ng_container_5_Template(rf, ctx) {
  if (rf & 1) {
    const _r12 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](1, "div", 7)(2, "div", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("click", function AddressBookPage_ng_container_5_Template_div_click_2_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r12);
      const item_r2 = restoredCtx.$implicit;
      const ctx_r11 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵresetView"](ctx_r11.selectSheet(item_r2));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](3, "div", 9)(4, "label", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](6, "label", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](7);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](8, AddressBookPage_ng_container_5_label_8_Template, 2, 1, "label", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](9, "div", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrepeaterCreate"](10, AddressBookPage_ng_container_5_For_11_Template, 2, 6, "w-icon", 16, _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrepeaterTrackByIdentity"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const item_r2 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtextInterpolate1"](" ", item_r2.name, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtextInterpolate"](item_r2.address);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", item_r2.remarks);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrepeater"](item_r2.chainList);
  }
}
function AddressBookPage_common_bottom_sheet_6_ng_template_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r16 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "w-operate-address-page", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("returnValue$", function AddressBookPage_common_bottom_sheet_6_ng_template_1_Template_w_operate_address_page_returnValue__0_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r16);
      const ctx_r15 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵresetView"](ctx_r15.getChange($event));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const data_r13 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"]().ngIf;
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("data", data_r13);
  }
}
function AddressBookPage_common_bottom_sheet_6_Template(rf, ctx) {
  if (rf & 1) {
    const _r19 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "common-bottom-sheet", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("isOpenChange", function AddressBookPage_common_bottom_sheet_6_Template_common_bottom_sheet_isOpenChange_0_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r19);
      const ctx_r18 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵresetView"]($event || (ctx_r18.selectdAddress = undefined));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](1, AddressBookPage_common_bottom_sheet_6_ng_template_1_Template, 1, 1, "ng-template");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("isOpen", true);
  }
}
const _c5 = () => ["/mime/modify-address"];
const _c6 = (a0, a1) => ({
  chain: a0,
  symbol: a1
});
/** 地址簿 */
class AddressBookPage extends _modules_page_module__WEBPACK_IMPORTED_MODULE_2__.CommonPageBase {
  constructor() {
    super(...arguments);
    /** 链服务 */
    this.chainV2Service = (0,_angular_core__WEBPACK_IMPORTED_MODULE_13__.inject)(_bnqkl_wallet_base_services_wallet_chain__WEBPACK_IMPORTED_MODULE_4__.ChainV2Service);
    /** 地址薄存储服务 */
    this.chainAddressBookStorageService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_13__.inject)(_bnqkl_wallet_base_services_wallet__WEBPACK_IMPORTED_MODULE_7__.ChainAddressBookStorageService);
    /** 添加币种类型页面返回 */
    this.modifyAddressPageReturnController = new _bnqkl_framework_controllers__WEBPACK_IMPORTED_MODULE_1__.PageReturnController(this, _modify_address_modify_address_component__WEBPACK_IMPORTED_MODULE_5__.ModifyAddressPage);
    /** 页面返回值的类型 */
    this.returnValue$ = new _modules_page_module__WEBPACK_IMPORTED_MODULE_2__.PageReturnValue();
    /** 地址列表 */
    this.addressList = [];
  }
  /** 初始化返回值监听 */
  watchPageReturn() {
    var _this = this;
    /** 监听新增/编辑地址簿返回 */
    this.modifyAddressPageReturnController.pageReturn$.subscribe( /*#__PURE__*/function () {
      var _ref = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (data) {
        if (data.isChange === true) {
          yield _this.initMenu();
          _this.cdRef.detectChanges();
        }
      });
      return function (_x) {
        return _ref.apply(this, arguments);
      };
    }());
  }
  /** 初始化返回值监听 */
  initMenu() {
    var _this2 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const addressList = _this2.chain ? (yield _this2.chainAddressBookStorageService.getAllChainAddressBook()).filter(item => item.chainList.map(item => item.chain).includes(_this2.chain)) : yield _this2.chainAddressBookStorageService.getAllChainAddressBook();
      // 先name字段排序
      addressList.sort(_this2.compare);
      _this2.addressList = addressList;
    })();
  }
  /** 打开添加弹出层 */
  selectSheet(item) {
    if (this.chain) {
      this.returnValue$.next({
        selectAddress: item.address
      });
      this.nav.back();
    } else {
      this.selectdAddress = {
        ...item
      };
    }
  }
  /** 检测弹窗返回修改 */
  getChange(item) {
    var _this3 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      if (item.isRefresh) {
        yield _this3.initMenu();
        _this3.cdRef.detectChanges();
      }
    })();
  }
  /** name升序字母拼音排序 先中文拼音 再大写最后小写 */
  compare(current, next) {
    const currentName = current.name.toLowerCase();
    const nextName = next.name.toLowerCase();
    const result = currentName.localeCompare(nextName, 'zh-CN', {
      sensitivity: 'accent'
    });
    if (result !== 0) {
      return result;
    }
    const currentNameUpper = currentName.toUpperCase();
    const nextNameUpper = nextName.toUpperCase();
    if (currentNameUpper !== currentName || nextNameUpper !== nextName) {
      return currentNameUpper.localeCompare(nextNameUpper);
    }
    return currentName.localeCompare(nextName);
  }
}
_class = AddressBookPage;
_class.ɵfac = /*@__PURE__*/(() => {
  let ɵAddressBookPage_BaseFactory;
  return function AddressBookPage_Factory(t) {
    return (ɵAddressBookPage_BaseFactory || (ɵAddressBookPage_BaseFactory = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵgetInheritedFactory"](_class)))(t || _class);
  };
})();
_class.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdefineComponent"]({
  type: _class,
  selectors: [["w-address-book-page"]],
  outputs: {
    returnValue$: "returnValue$"
  },
  standalone: true,
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵInheritDefinitionFeature"], _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵStandaloneFeature"]],
  decls: 7,
  vars: 9,
  consts: () => {
    let i18n_0;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_ADDRESS_BOOK$$APPS_WALLET_SRC_PAGES_MIME_PAGES_ADDRESS_BOOK_ADDRESS_BOOK_COMPONENT_TS_1 = goog.getMsg("Address Book");
      i18n_0 = MSG_EXTERNAL_ADDRESS_BOOK$$APPS_WALLET_SRC_PAGES_MIME_PAGES_ADDRESS_BOOK_ADDRESS_BOOK_COMPONENT_TS_1;
    } else {
      i18n_0 = "\u5730\u5740\u7C3F";
    }
    let i18n_2;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_ADD$$APPS_WALLET_SRC_PAGES_MIME_PAGES_ADDRESS_BOOK_ADDRESS_BOOK_COMPONENT_TS_3 = goog.getMsg("Add");
      i18n_2 = MSG_EXTERNAL_ADD$$APPS_WALLET_SRC_PAGES_MIME_PAGES_ADDRESS_BOOK_ADDRESS_BOOK_COMPONENT_TS_3;
    } else {
      i18n_2 = "\u65B0\u589E";
    }
    return [["headerTitle", i18n_0, 3, "contentBackground"], ["endMenu", "", "bnRippleButton", "", 3, "routerLink", "queryParams"], [1, "text-primary"], i18n_2, [1, "flex", "w-full", "flex-col"], [4, "ngFor", "ngForOf"], [3, "isOpen", "isOpenChange", 4, "ngIf"], [1, "bg-white", "px-2"], [1, "border-b-tiny", "border-line", "box-border", "flex", "w-full", "items-start", "justify-between", "bg-white", "px-5", "py-4", 3, "click"], [1, "text-text-300", "text-xss", "flex", "shrink-0", "flex-col", "overflow-hidden", "font-normal"], [1, "_ellipsis", "mb-0.5", "overflow-hidden", "whitespace-nowrap", "text-sm", "font-semibold", "text-black"], [1, "mb-0.5"], ["class", "_ellipsis overflow-hidden whitespace-nowrap", 4, "ngIf"], [1, "mt-1", "text-left"], [1, "_ellipsis", "overflow-hidden", "whitespace-nowrap"], [1, "icon-6", "mr-2", 3, "name"], ["class", "icon-6 mr-2", 3, "name"], [3, "isOpen", "isOpenChange"], [3, "data", "returnValue$"]];
  },
  template: function AddressBookPage_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "common-page", 0)(1, "button", 1)(2, "span", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵi18n"](3, 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](4, "div", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](5, AddressBookPage_ng_container_5_Template, 12, 3, "ng-container", 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](6, AddressBookPage_common_bottom_sheet_6_Template, 2, 1, "common-bottom-sheet", 6);
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("contentBackground", "env");
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("routerLink", _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpureFunction0"](5, _c5))("queryParams", _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpureFunction2"](6, _c6, ctx.chain, ctx.symbol));
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](4);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngForOf", ctx.addressList);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", ctx.selectdAddress);
    }
  },
  dependencies: [_modules_page_module__WEBPACK_IMPORTED_MODULE_2__.CommonPageModule, _libs_bnf_modules_bottom_sheet_components_bottom_sheet_component__WEBPACK_IMPORTED_MODULE_8__.BottomSheetComponent, _libs_bnf_components_ripple_button_ripple_button_directive__WEBPACK_IMPORTED_MODULE_9__.RippleButtonDirective, _angular_common__WEBPACK_IMPORTED_MODULE_14__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_14__.NgIf, _angular_router__WEBPACK_IMPORTED_MODULE_15__.RouterLink, _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_10__.CommonPageComponent, _components_icon_icon_component__WEBPACK_IMPORTED_MODULE_11__.IconComponent, _pipes_chainIcon_chain_icon_pipe__WEBPACK_IMPORTED_MODULE_12__.ChainIconPipe, _operate_address_operate_address_component__WEBPACK_IMPORTED_MODULE_6__.OperateAddressPage],
  styles: ["[_nghost-%COMP%]   ._ellipsis[_ngcontent-%COMP%] {\n  text-overflow: ellipsis;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL2FwcHMvd2FsbGV0L3NyYy9wYWdlcy9taW1lL3BhZ2VzL2FkZHJlc3MtYm9vay9hZGRyZXNzLWJvb2suY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQ0U7RUFDRSx1QkFBQTtBQUFKIiwic291cmNlc0NvbnRlbnQiOlsiOmhvc3Qge1xyXG4gIC5fZWxsaXBzaXMge1xyXG4gICAgdGV4dC1vdmVyZmxvdzogZWxsaXBzaXM7XHJcbiAgfVxyXG59XHJcbiJdLCJzb3VyY2VSb290IjoiIn0= */"],
  changeDetection: 0
});
(0,tslib__WEBPACK_IMPORTED_MODULE_16__.__decorate)([AddressBookPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_16__.__metadata)("design:type", Object)], AddressBookPage.prototype, "modifyAddressPageReturnController", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_16__.__decorate)([AddressBookPage.QueryParam('chain'), (0,tslib__WEBPACK_IMPORTED_MODULE_16__.__metadata)("design:type", String)], AddressBookPage.prototype, "chain", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_16__.__decorate)([AddressBookPage.QueryParam('symbol'), (0,tslib__WEBPACK_IMPORTED_MODULE_16__.__metadata)("design:type", String)], AddressBookPage.prototype, "symbol", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_16__.__decorate)([AddressBookPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_16__.__metadata)("design:type", Array)], AddressBookPage.prototype, "addressList", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_16__.__decorate)([AddressBookPage.OnInit(), (0,tslib__WEBPACK_IMPORTED_MODULE_16__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_16__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_16__.__metadata)("design:returntype", void 0)], AddressBookPage.prototype, "watchPageReturn", null);
(0,tslib__WEBPACK_IMPORTED_MODULE_16__.__decorate)([AddressBookPage.OnInit(), (0,tslib__WEBPACK_IMPORTED_MODULE_16__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_16__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_16__.__metadata)("design:returntype", Promise)], AddressBookPage.prototype, "initMenu", null);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (AddressBookPage);

/***/ }),

/***/ 70343:
/*!***************************************************************************************!*\
  !*** ./apps/wallet/src/pages/mime/pages/operate-address/operate-address.component.ts ***!
  \***************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   OperateAddressPage: () => (/* binding */ OperateAddressPage),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 52542);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 61039);
/* harmony import */ var _bnqkl_util_web_extends_promise__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @bnqkl/util-web/extends-promise */ 87778);
/* harmony import */ var _modules_page_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ~modules/page.module */ 77538);
/* harmony import */ var _bnqkl_wallet_base_services_wallet_wallet_data_storage__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @bnqkl/wallet-base/services/wallet/wallet-data-storage */ 63024);
/* harmony import */ var _libs_bnf_components_ripple_button_ripple_button_directive__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../../../../../libs/bnf/components/ripple-button/ripple-button.directive */ 16505);
/* harmony import */ var _libs_bnf_directives_click_to_copy_directive__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../../../../../libs/bnf/directives/click-to-copy.directive */ 46413);
/* harmony import */ var _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../../../../../libs/bnf/modules/page/common-page/common-page.component */ 62052);

var _class;








/** 地址簿操作底部弹窗 */
class OperateAddressPage extends _modules_page_module__WEBPACK_IMPORTED_MODULE_2__.CommonPageBase {
  constructor() {
    super(...arguments);
    /** 钱包存储服务 */
    this.chainAddressBookStorageService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_7__.inject)(_bnqkl_wallet_base_services_wallet_wallet_data_storage__WEBPACK_IMPORTED_MODULE_3__.ChainAddressBookStorageService);
    /** 页面返回值的类型 */
    this.returnValue$ = new _modules_page_module__WEBPACK_IMPORTED_MODULE_2__.PageReturnValue();
  }
  /** 编辑地址 */
  editAddress() {
    var _this = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this.nav.routeTo('/mime/modify-address', {
        ..._this.data,
        chain: _this.data.chainList[0].chain
      });
    })();
  }
  /** 删除地址 */
  deleteAddress() {
    var _this2 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const confirmed = yield _this2.confirm({
        headerTitle: "\u78BA\u5B9A\u522A\u9664\u8A72\u5730\u5740\uFF1F",
        bodyMessage: '',
        footerTheme: 'warn'
      });
      if (confirmed === false) {
        return;
      }
      yield _this2.chainAddressBookStorageService.deleteChainAddressBook(_this2.data.addressBookId);
      _this2.returnValue$.next({
        isRefresh: true
      });
      yield (0,_bnqkl_util_web_extends_promise__WEBPACK_IMPORTED_MODULE_1__.sleep)(350);
      _this2.nav.back();
    })();
  }
  /** 关闭弹窗 */
  cancel() {
    this.nav.back();
  }
}
_class = OperateAddressPage;
_class.ɵfac = /*@__PURE__*/(() => {
  let ɵOperateAddressPage_BaseFactory;
  return function OperateAddressPage_Factory(t) {
    return (ɵOperateAddressPage_BaseFactory || (ɵOperateAddressPage_BaseFactory = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵgetInheritedFactory"](_class)))(t || _class);
  };
})();
_class.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdefineComponent"]({
  type: _class,
  selectors: [["w-operate-address-page"]],
  inputs: {
    data: "data"
  },
  outputs: {
    returnValue$: "returnValue$"
  },
  standalone: true,
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵInheritDefinitionFeature"], _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵStandaloneFeature"]],
  decls: 14,
  vars: 2,
  consts: () => {
    let i18n_0;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_COPY_ADDRESS$$APPS_WALLET_SRC_PAGES_MIME_PAGES_OPERATE_ADDRESS_OPERATE_ADDRESS_COMPONENT_TS_1 = goog.getMsg(" Copy Address ");
      i18n_0 = MSG_EXTERNAL_COPY_ADDRESS$$APPS_WALLET_SRC_PAGES_MIME_PAGES_OPERATE_ADDRESS_OPERATE_ADDRESS_COMPONENT_TS_1;
    } else {
      i18n_0 = "\u8907\u88FD\u5730\u5740";
    }
    let i18n_2;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_EDIT$$APPS_WALLET_SRC_PAGES_MIME_PAGES_OPERATE_ADDRESS_OPERATE_ADDRESS_COMPONENT_TS_3 = goog.getMsg(" Edit ");
      i18n_2 = MSG_EXTERNAL_EDIT$$APPS_WALLET_SRC_PAGES_MIME_PAGES_OPERATE_ADDRESS_OPERATE_ADDRESS_COMPONENT_TS_3;
    } else {
      i18n_2 = "\u7DE8\u8F2F";
    }
    let i18n_4;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_DELETE$$APPS_WALLET_SRC_PAGES_MIME_PAGES_OPERATE_ADDRESS_OPERATE_ADDRESS_COMPONENT_TS_5 = goog.getMsg(" Delete ");
      i18n_4 = MSG_EXTERNAL_DELETE$$APPS_WALLET_SRC_PAGES_MIME_PAGES_OPERATE_ADDRESS_OPERATE_ADDRESS_COMPONENT_TS_5;
    } else {
      i18n_4 = "\u522A\u9664";
    }
    let i18n_6;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_CANCEL$$APPS_WALLET_SRC_PAGES_MIME_PAGES_OPERATE_ADDRESS_OPERATE_ADDRESS_COMPONENT_TS_7 = goog.getMsg(" Cancel ");
      i18n_6 = MSG_EXTERNAL_CANCEL$$APPS_WALLET_SRC_PAGES_MIME_PAGES_OPERATE_ADDRESS_OPERATE_ADDRESS_COMPONENT_TS_7;
    } else {
      i18n_6 = "\u53D6\u6D88";
    }
    return [[3, "hideHeader"], [1, "box-border", "flex", "flex-col"], [1, "border-line", "text-title", "box-border", "flex", "w-full", "flex-col", "border-b-4", "border-solid", "py-0"], ["bnRippleButton", "", 1, "h-12", "w-full", "px-5", "text-sm", 3, "wClickToCopy", "click"], [1, "border-line", "flex", "h-full", "w-full", "items-center", "justify-center", "border-b-[0.5px]"], i18n_0, ["bnRippleButton", "", 1, "h-12", "w-full", "px-5", "text-sm", 3, "click"], i18n_2, ["bnRippleButton", "", 1, "flex", "h-12", "w-full", "items-center", "justify-center", "text-sm", 3, "click"], i18n_4, ["bnRippleButton", "", 1, "text-error", "flex", "h-12", "w-full", "items-center", "justify-center", "text-sm", 3, "click"], i18n_6];
  },
  template: function OperateAddressPage_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](0, "common-page", 0)(1, "div", 1)(2, "div", 2)(3, "button", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("click", function OperateAddressPage_Template_button_click_3_listener() {
        return ctx.cancel();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](4, "div", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵi18n"](5, 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](6, "button", 6);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("click", function OperateAddressPage_Template_button_click_6_listener() {
        return ctx.editAddress();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](7, "div", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵi18n"](8, 7);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](9, "button", 8);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("click", function OperateAddressPage_Template_button_click_9_listener() {
        return ctx.deleteAddress();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵi18n"](10, 9);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](11, "div")(12, "button", 10);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("click", function OperateAddressPage_Template_button_click_12_listener() {
        return ctx.cancel();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵi18n"](13, 11);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]()()()();
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("hideHeader", true);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("wClickToCopy", ctx.data.address);
    }
  },
  dependencies: [_modules_page_module__WEBPACK_IMPORTED_MODULE_2__.CommonPageModule, _libs_bnf_components_ripple_button_ripple_button_directive__WEBPACK_IMPORTED_MODULE_4__.RippleButtonDirective, _libs_bnf_directives_click_to_copy_directive__WEBPACK_IMPORTED_MODULE_5__.ClickToCopyDirective, _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_6__.CommonPageComponent],
  styles: ["/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsInNvdXJjZVJvb3QiOiIifQ== */"],
  changeDetection: 0
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (OperateAddressPage);

/***/ })

}]);
//# sourceMappingURL=default-apps_wallet_src_pages_mime_pages_address-book_address-book_component_ts.js.map