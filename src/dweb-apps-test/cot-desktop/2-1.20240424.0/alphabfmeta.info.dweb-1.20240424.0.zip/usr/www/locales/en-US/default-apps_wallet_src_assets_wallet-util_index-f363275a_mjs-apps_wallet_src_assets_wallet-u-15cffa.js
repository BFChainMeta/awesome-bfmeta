"use strict";
(self["webpackChunkwallet"] = self["webpackChunkwallet"] || []).push([["default-apps_wallet_src_assets_wallet-util_index-f363275a_mjs-apps_wallet_src_assets_wallet-u-15cffa"],{

/***/ 89279:
/*!***************************************************************!*\
  !*** ./apps/wallet/src/assets/wallet-util/index-f363275a.mjs ***!
  \***************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   b: () => (/* binding */ c)
/* harmony export */ });
/* harmony import */ var _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./index-766bdb76.mjs */ 59809);
/* harmony import */ var _sha256_e58017d9_mjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./sha256-e58017d9.mjs */ 6612);


var n = function (r) {
  if (r.length >= 255) throw new TypeError("Alphabet too long");
  for (var e = new Uint8Array(256), n = 0; n < e.length; n++) e[n] = 255;
  for (var t = 0; t < r.length; t++) {
    var o = r.charAt(t),
      a = o.charCodeAt(0);
    if (255 !== e[a]) throw new TypeError(o + " is ambiguous");
    e[a] = t;
  }
  var f = r.length,
    i = r.charAt(0),
    c = Math.log(f) / Math.log(256),
    h = Math.log(256) / Math.log(f);
  function u(r) {
    if ("string" != typeof r) throw new TypeError("Expected String");
    if (0 === r.length) return new Uint8Array();
    for (var n = 0, t = 0, o = 0; r[n] === i;) t++, n++;
    for (var a = (r.length - n) * c + 1 >>> 0, h = new Uint8Array(a); r[n];) {
      var u = e[r.charCodeAt(n)];
      if (255 === u) return;
      for (var s = 0, d = a - 1; (0 !== u || s < o) && -1 !== d; d--, s++) u += f * h[d] >>> 0, h[d] = u % 256 >>> 0, u = u / 256 >>> 0;
      if (0 !== u) throw new Error("Non-zero carry");
      o = s, n++;
    }
    for (var v = a - o; v !== a && 0 === h[v];) v++;
    for (var w = new Uint8Array(t + (a - v)), y = t; v !== a;) w[y++] = h[v++];
    return w;
  }
  return {
    encode: function (e) {
      if (e instanceof Uint8Array || (ArrayBuffer.isView(e) ? e = new Uint8Array(e.buffer, e.byteOffset, e.byteLength) : Array.isArray(e) && (e = Uint8Array.from(e))), !(e instanceof Uint8Array)) throw new TypeError("Expected Uint8Array");
      if (0 === e.length) return "";
      for (var n = 0, t = 0, o = 0, a = e.length; o !== a && 0 === e[o];) o++, n++;
      for (var c = (a - o) * h + 1 >>> 0, u = new Uint8Array(c); o !== a;) {
        for (var s = e[o], d = 0, v = c - 1; (0 !== s || d < t) && -1 !== v; v--, d++) s += 256 * u[v] >>> 0, u[v] = s % f >>> 0, s = s / f >>> 0;
        if (0 !== s) throw new Error("Non-zero carry");
        t = d, o++;
      }
      for (var w = c - t; w !== c && 0 === u[w];) w++;
      for (var y = i.repeat(n); w < c; ++w) y += r.charAt(u[w]);
      return y;
    },
    decodeUnsafe: u,
    decode: function (r) {
      var e = u(r);
      if (e) return e;
      throw new Error("Non-base" + f + " character");
    }
  };
};
var t = n("123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz");
const o = t.decode,
  a = t.decodeUnsafe,
  f = t.encode;
function i(n) {
  return _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_0__.B.from((0,_sha256_e58017d9_mjs__WEBPACK_IMPORTED_MODULE_1__.c)().update(n).digest());
}
const c = (e => {
  function n(n) {
    var t = n.slice(0, -4),
      o = n.slice(-4),
      a = e(t);
    if (!(o[0] ^ a[0] | o[1] ^ a[1] | o[2] ^ a[2] | o[3] ^ a[3])) return _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_0__.B.from(t);
  }
  return {
    encode: function (n) {
      var t = e(n);
      return f(_index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_0__.B.concat([n, t], n.length + 4));
    },
    decode: function (r) {
      var e = n(o(r));
      if (!e) throw new Error("Invalid checksum");
      return e;
    },
    decodeUnsafe: function (r) {
      var e = a(r);
      if (e) return n(e);
    }
  };
})(function (r) {
  return i(i(r));
});


/***/ }),

/***/ 26139:
/*!*******************************************************************!*\
  !*** ./apps/wallet/src/assets/wallet-util/typeforce-9b266dd0.mjs ***!
  \*******************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   t: () => (/* binding */ E)
/* harmony export */ });
/* harmony import */ var _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./index-766bdb76.mjs */ 59809);

var n = {},
  r = {
    Array: function (t) {
      return null != t && t.constructor === Array;
    },
    Boolean: function (t) {
      return "boolean" == typeof t;
    },
    Function: function (t) {
      return "function" == typeof t;
    },
    Nil: function (t) {
      return null == t;
    },
    Number: function (t) {
      return "number" == typeof t;
    },
    Object: function (t) {
      return "object" == typeof t;
    },
    String: function (t) {
      return "string" == typeof t;
    },
    "": function () {
      return !0;
    }
  };
for (var e in r.Null = r.Nil, r) r[e].toJSON = function (t) {
  return t;
}.bind(null, e);
var o,
  u,
  i = r,
  f = i;
function c(t) {
  return t.name || t.toString().match(/function (.*?)\s*\(/)[1];
}
function a(t) {
  return f.Nil(t) ? "" : c(t.constructor);
}
function l(t, n) {
  Error.captureStackTrace && Error.captureStackTrace(t, n);
}
function p(t) {
  return f.Function(t) ? t.toJSON ? t.toJSON() : c(t) : f.Array(t) ? "Array" : t && f.Object(t) ? "Object" : void 0 !== t ? t : "";
}
function y(t, n, r) {
  var e = function (t) {
    return f.Function(t) ? "" : f.String(t) ? JSON.stringify(t) : t && f.Object(t) ? "" : t;
  }(n);
  return "Expected " + p(t) + ", got" + ("" !== r ? " " + r : "") + ("" !== e ? " " + e : "");
}
function h(t, n, r) {
  r = r || a(n), this.message = y(t, n, r), l(this, h), this.__type = t, this.__value = n, this.__valueTypeName = r;
}
function m(t, n, r, e, o) {
  t ? (o = o || a(e), this.message = function (t, n, r, e, o) {
    var u = '" of type ';
    return "key" === n && (u = '" with key type '), y('property "' + p(r) + u + p(t), e, o);
  }(t, r, n, e, o)) : this.message = 'Unexpected property "' + n + '"', l(this, h), this.__label = r, this.__property = n, this.__type = t, this.__value = e, this.__valueTypeName = o;
}
h.prototype = Object.create(Error.prototype), h.prototype.constructor = h, m.prototype = Object.create(Error.prototype), m.prototype.constructor = h, n.TfTypeError = h, n.TfPropertyTypeError = m, n.tfCustomError = function (t, n) {
  return new h(t, {}, n);
}, n.tfSubError = function (t, n, r) {
  return t instanceof m ? (n = n + "." + t.__property, t = new m(t.__type, n, t.__label, t.__value, t.__valueTypeName)) : t instanceof h && (t = new m(t.__type, n, r, t.__value, t.__valueTypeName)), l(t), t;
}, n.tfJSON = p, n.getValueTypeName = a;
var s = n,
  v = i,
  g = s.tfJSON,
  N = s.TfTypeError,
  O = s.TfPropertyTypeError,
  b = s.tfSubError,
  _ = s.getValueTypeName,
  S = {
    arrayOf: function (t, n) {
      function r(r, e) {
        return !!v.Array(r) && !v.Nil(r) && !(void 0 !== n.minLength && r.length < n.minLength) && !(void 0 !== n.maxLength && r.length > n.maxLength) && (void 0 === n.length || r.length === n.length) && r.every(function (n, r) {
          try {
            return d(t, n, e);
          } catch (t) {
            throw b(t, r);
          }
        });
      }
      return t = T(t), n = n || {}, r.toJSON = function () {
        var r = "[" + g(t) + "]";
        return void 0 !== n.length ? r += "{" + n.length + "}" : void 0 === n.minLength && void 0 === n.maxLength || (r += "{" + (void 0 === n.minLength ? 0 : n.minLength) + "," + (void 0 === n.maxLength ? 1 / 0 : n.maxLength) + "}"), r;
      }, r;
    },
    maybe: function t(n) {
      function r(r, e) {
        return v.Nil(r) || n(r, e, t);
      }
      return n = T(n), r.toJSON = function () {
        return "?" + g(n);
      }, r;
    },
    map: function (t, n) {
      function r(r, e) {
        if (!v.Object(r)) return !1;
        if (v.Nil(r)) return !1;
        for (var o in r) {
          try {
            n && d(n, o, e);
          } catch (t) {
            throw b(t, o, "key");
          }
          try {
            var u = r[o];
            d(t, u, e);
          } catch (t) {
            throw b(t, o);
          }
        }
        return !0;
      }
      return t = T(t), n && (n = T(n)), r.toJSON = n ? function () {
        return "{" + g(n) + ": " + g(t) + "}";
      } : function () {
        return "{" + g(t) + "}";
      }, r;
    },
    object: function (t) {
      var n = {};
      for (var r in t) n[r] = T(t[r]);
      function e(t, r) {
        if (!v.Object(t)) return !1;
        if (v.Nil(t)) return !1;
        var e;
        try {
          for (e in n) {
            d(n[e], t[e], r);
          }
        } catch (t) {
          throw b(t, e);
        }
        if (r) for (e in t) if (!n[e]) throw new O(void 0, e);
        return !0;
      }
      return e.toJSON = function () {
        return g(n);
      }, e;
    },
    anyOf: function () {
      var t = [].slice.call(arguments).map(T);
      function n(n, r) {
        return t.some(function (t) {
          try {
            return d(t, n, r);
          } catch (t) {
            return !1;
          }
        });
      }
      return n.toJSON = function () {
        return t.map(g).join("|");
      }, n;
    },
    allOf: function () {
      var t = [].slice.call(arguments).map(T);
      function n(n, r) {
        return t.every(function (t) {
          try {
            return d(t, n, r);
          } catch (t) {
            return !1;
          }
        });
      }
      return n.toJSON = function () {
        return t.map(g).join(" & ");
      }, n;
    },
    quacksLike: function (t) {
      function n(n) {
        return t === _(n);
      }
      return n.toJSON = function () {
        return t;
      }, n;
    },
    tuple: function () {
      var t = [].slice.call(arguments).map(T);
      function n(n, r) {
        return !v.Nil(n) && !v.Nil(n.length) && (!r || n.length === t.length) && t.every(function (t, e) {
          try {
            return d(t, n[e], r);
          } catch (t) {
            throw b(t, e);
          }
        });
      }
      return n.toJSON = function () {
        return "(" + t.map(g).join(", ") + ")";
      }, n;
    },
    value: function (t) {
      function n(n) {
        return n === t;
      }
      return n.toJSON = function () {
        return t;
      }, n;
    }
  };
function T(t) {
  if (v.String(t)) return "?" === t[0] ? S.maybe(t.slice(1)) : v[t] || S.quacksLike(t);
  if (t && v.Object(t)) {
    if (v.Array(t)) {
      if (1 !== t.length) throw new TypeError("Expected compile() parameter of type Array of length 1");
      return S.arrayOf(t[0]);
    }
    return S.object(t);
  }
  return v.Function(t) ? t : S.value(t);
}
function d(t, n, r, e) {
  if (v.Function(t)) {
    if (t(n, r)) return !0;
    throw new N(e || t, n);
  }
  return d(T(t), n, r);
}
for (var J in S.oneOf = S.anyOf, v) d[J] = v[J];
for (J in S) d[J] = S[J];
var w = function () {
  if (u) return o;
  u = 1;
  var r = i,
    e = n,
    {
      Buffer: f
    } = _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_0__.b;
  function c(t) {
    return f.isBuffer(t);
  }
  function a(t) {
    return "string" == typeof t && /^([0-9a-f]{2})+$/i.test(t);
  }
  function l(t, n) {
    var r = t.toJSON();
    function o(o) {
      if (!t(o)) return !1;
      if (o.length === n) return !0;
      throw e.tfCustomError(r + "(Length: " + n + ")", r + "(Length: " + o.length + ")");
    }
    return o.toJSON = function () {
      return r;
    }, o;
  }
  var p = l.bind(null, r.Array),
    y = l.bind(null, c),
    h = l.bind(null, a),
    m = l.bind(null, r.String),
    s = Math.pow(2, 53) - 1,
    v = {
      ArrayN: p,
      Buffer: c,
      BufferN: y,
      Finite: function (t) {
        return "number" == typeof t && isFinite(t);
      },
      Hex: a,
      HexN: h,
      Int8: function (t) {
        return t << 24 >> 24 === t;
      },
      Int16: function (t) {
        return t << 16 >> 16 === t;
      },
      Int32: function (t) {
        return (0 | t) === t;
      },
      Int53: function (t) {
        return "number" == typeof t && t >= -s && t <= s && Math.floor(t) === t;
      },
      Range: function (t, n, e) {
        function o(r, o) {
          return e(r, o) && r > t && r < n;
        }
        return e = e || r.Number, o.toJSON = function () {
          return `${e.toJSON()} between [${t}, ${n}]`;
        }, o;
      },
      StringN: m,
      UInt8: function (t) {
        return (255 & t) === t;
      },
      UInt16: function (t) {
        return (65535 & t) === t;
      },
      UInt32: function (t) {
        return t >>> 0 === t;
      },
      UInt53: function (t) {
        return "number" == typeof t && t >= 0 && t <= s && Math.floor(t) === t;
      }
    };
  for (var g in v) v[g].toJSON = function (t) {
    return t;
  }.bind(null, g);
  return o = v;
}();
for (J in w) d[J] = w[J];
d.compile = T, d.TfTypeError = N, d.TfPropertyTypeError = O;
const E = d;


/***/ })

}]);
//# sourceMappingURL=default-apps_wallet_src_assets_wallet-util_index-f363275a_mjs-apps_wallet_src_assets_wallet-u-15cffa.js.map