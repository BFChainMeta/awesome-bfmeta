"use strict";
(self["webpackChunkwallet"] = self["webpackChunkwallet"] || []).push([["default-apps_wallet_src_pages_mime_pages_modify-address_modify-address_component_ts"],{

/***/ 6596:
/*!************************************************!*\
  !*** ./apps/wallet/src/helpers/utils/index.ts ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   isMobile: () => (/* binding */ isMobile)
/* harmony export */ });
/* harmony import */ var _plaoc_is_dweb__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @plaoc/is-dweb */ 69899);
/* harmony import */ var _environments_index__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ~environments/index */ 40014);


/** 判断是否是移动端 */
const isMobile = () => {
  if (_environments_index__WEBPACK_IMPORTED_MODULE_1__.environment.DWEB_APP) {
    return (0,_plaoc_is_dweb__WEBPACK_IMPORTED_MODULE_0__.isMobile)();
  } else {
    return true;
  }
};

/***/ }),

/***/ 48072:
/*!*************************************************************************************!*\
  !*** ./apps/wallet/src/pages/mime/pages/modify-address/modify-address.component.ts ***!
  \*************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ModifyAddressPage: () => (/* binding */ ModifyAddressPage),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 52542);
/* harmony import */ var D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncIterator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/esm/asyncIterator.js */ 9243);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! tslib */ 90505);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! @angular/core */ 61039);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! @angular/forms */ 7820);
/* harmony import */ var _bnqkl_framework_controllers__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @bnqkl/framework/controllers */ 47919);
/* harmony import */ var _bnqkl_framework_helpers__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @bnqkl/framework/helpers */ 12169);
/* harmony import */ var _bnqkl_framework_plugins_barcode_scanner__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @bnqkl/framework/plugins/barcode-scanner */ 5005);
/* harmony import */ var _bnqkl_framework_plugins_toast__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @bnqkl/framework/plugins/toast */ 18030);
/* harmony import */ var _bnqkl_util_web_extends_promise__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @bnqkl/util-web/extends-promise */ 87778);
/* harmony import */ var _modules_page_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ~modules/page.module */ 77538);
/* harmony import */ var _pages_scanner_scanner_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ~pages/scanner/scanner.component */ 41405);
/* harmony import */ var _bnqkl_wallet_base_services_wallet_chain__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @bnqkl/wallet-base/services/wallet/chain */ 27434);
/* harmony import */ var _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @bnqkl/wallet-base/services/wallet/chain-base */ 27187);
/* harmony import */ var _bnqkl_wallet_base_services_wallet_wallet_data_storage__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @bnqkl/wallet-base/services/wallet/wallet-data-storage */ 63024);
/* harmony import */ var _select_address_type_select_address_type_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../select-address-type/select-address-type.component */ 26390);
/* harmony import */ var _helpers_utils__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ~helpers/utils */ 6596);
/* harmony import */ var _libs_bnf_components_ripple_button_ripple_button_directive__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../../../../../../../libs/bnf/components/ripple-button/ripple-button.directive */ 16505);
/* harmony import */ var _libs_bnf_directives_form_errors_directive__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ../../../../../../../libs/bnf/directives/form-errors.directive */ 29541);
/* harmony import */ var _libs_bnf_directives_auto_complete_off_directive__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ../../../../../../../libs/bnf/directives/auto-complete-off.directive */ 66722);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! @angular/common */ 6729);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! @angular/router */ 56776);
/* harmony import */ var _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ../../../../../../../libs/bnf/modules/page/common-page/common-page.component */ 62052);
/* harmony import */ var _components_icon_icon_component__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ../../../../components/icon/icon.component */ 74703);
/* harmony import */ var _libs_bnf_pipes_errors_errors_pipe__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ../../../../../../../libs/bnf/pipes/errors/errors.pipe */ 68362);


var _class;

























function ModifyAddressPage_div_16_div_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](0, "div", 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵi18n"](1, 26);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
  }
}
function ModifyAddressPage_div_16_div_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](0, "div", 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const errors_r7 = _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵnextContext"]().ngIf;
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtextInterpolate1"](" ", errors_r7["address"], " ");
  }
}
function ModifyAddressPage_div_16_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](0, "div", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtemplate"](1, ModifyAddressPage_div_16_div_1_Template, 2, 0, "div", 24)(2, ModifyAddressPage_div_16_div_2_Template, 2, 1, "div", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const errors_r7 = ctx.ngIf;
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵproperty"]("ngIf", errors_r7["required"] || errors_r7["trimRequired"] || errors_r7["whitespace"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵproperty"]("ngIf", errors_r7["address"]);
  }
}
function ModifyAddressPage_Conditional_20_Template(rf, ctx) {
  if (rf & 1) {
    const _r12 = _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](0, "w-icon", 27);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵlistener"]("click", function ModifyAddressPage_Conditional_20_Template_w_icon_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵrestoreView"](_r12);
      const ctx_r11 = _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵresetView"](ctx_r11.routeToScanner());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
  }
}
function ModifyAddressPage_ng_template_24_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵi18n"](1, 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementContainerEnd"]();
  }
}
function ModifyAddressPage_ng_template_25_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵi18n"](1, 29);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const error_r14 = ctx.$error;
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵi18nExp"](error_r14.requiredLength);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵi18nApply"](1);
  }
}
function ModifyAddressPage_ng_template_26_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵi18n"](1, 30);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementContainerEnd"]();
  }
}
function ModifyAddressPage_ng_template_32_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵi18n"](1, 31);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const error_r16 = ctx.$error;
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵi18nExp"](error_r16.requiredLength);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵi18nApply"](1);
  }
}
function ModifyAddressPage_ng_template_33_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵi18n"](1, 32);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementContainerEnd"]();
  }
}
const _c22 = () => ["/mime/select-address-type"];
/** 新增/编辑地址簿 */
class ModifyAddressPage extends _modules_page_module__WEBPACK_IMPORTED_MODULE_7__.CommonPageBase {
  constructor() {
    var _this;
    /** 表单验证服务 */
    super(...arguments);
    _this = this;
    this.validators = new _bnqkl_framework_controllers__WEBPACK_IMPORTED_MODULE_2__.FormValidatorsController(this);
    /** 钱包链服务 */
    this.chainV2Service = (0,_angular_core__WEBPACK_IMPORTED_MODULE_20__.inject)(_bnqkl_wallet_base_services_wallet_chain__WEBPACK_IMPORTED_MODULE_9__.ChainV2Service);
    /** 是否是移动端 */
    this.isMobile = (0,_helpers_utils__WEBPACK_IMPORTED_MODULE_13__.isMobile)();
    /** 钱包存储服务 */
    this.chainAddressBookStorageService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_20__.inject)(_bnqkl_wallet_base_services_wallet_wallet_data_storage__WEBPACK_IMPORTED_MODULE_11__.ChainAddressBookStorageService);
    /** 页面返回值的类型 */
    this.returnValue$ = new _modules_page_module__WEBPACK_IMPORTED_MODULE_7__.PageReturnValue();
    /** 添加币种类型页面返回 */
    this.selectAddressTypePageReturnController = new _bnqkl_framework_controllers__WEBPACK_IMPORTED_MODULE_2__.PageReturnController(this, _select_address_type_select_address_type_component__WEBPACK_IMPORTED_MODULE_12__.SelectAddressTypePage);
    this.scannerPageReturnController = new _bnqkl_framework_controllers__WEBPACK_IMPORTED_MODULE_2__.PageReturnController(this, _pages_scanner_scanner_component__WEBPACK_IMPORTED_MODULE_8__["default"], true);
    /** 地址 */
    this.address = new _angular_forms__WEBPACK_IMPORTED_MODULE_21__.FormControl('', {
      nonNullable: true,
      validators: [() => {
        // 初始化状态
        return null;
      }, _angular_forms__WEBPACK_IMPORTED_MODULE_21__.Validators.required, this.validators.whitespace, this.validators.trimRequired],
      asyncValidators: [( /*#__PURE__*/function () {
        var _ref = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (control) {
          /// 有其它错误了
          if (control.errors) {
            return null;
          }
          try {
            const address = control.value;
            /// 检查地址格式
            if ((yield _this.chainApiService.isAddress(address)) === false) {
              // 地址格式错误
              throw new Error("Incorrect Wallet Address");
            } else if ((0,_bnqkl_framework_helpers__WEBPACK_IMPORTED_MODULE_3__.$isNoEmptyString)(_this.data.addressBookId) === false) {
              /// 去重
              const addressList = yield _this.chainAddressBookStorageService.getAllChainAddressBook();
              const addressInfo = addressList.find(item => {
                return item.address === address;
              });
              if (addressInfo) {
                throw new Error("The Address already exists");
              }
            }
          } catch (err) {
            return {
              address: err instanceof Error ? err.message : String(err)
            };
          }
          return null;
        });
        return function (_x) {
          return _ref.apply(this, arguments);
        };
      }())]
    });
    /** 地址簿名称 */
    this.name = new _angular_forms__WEBPACK_IMPORTED_MODULE_21__.FormControl('', {
      nonNullable: true,
      validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_21__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_21__.Validators.maxLength(25), this.validators.whitespace]
    });
    /** 备注 */
    this.remarks = new _angular_forms__WEBPACK_IMPORTED_MODULE_21__.FormControl('', {
      nonNullable: true,
      validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_21__.Validators.maxLength(25), this.validators.whitespace]
    });
    /** 要提交的表单与复合验证 */
    this.form = new _angular_forms__WEBPACK_IMPORTED_MODULE_21__.FormGroup({
      name: this.name,
      address: this.address,
      remarks: this.remarks
    });
  }
  /** 链的接口服务 */
  get chainApiService() {
    return this.chainV2Service.getChainService(this.data.chain);
  }
  /** 自定义title */
  get title() {
    return this.data.addressBookId ? "Edit Address" : "Address Book";
  }
  /** 初始化返回值监听 */
  watchPageReturn() {
    var _this2 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      /** 监听币种类型选择 */
      _this2.selectAddressTypePageReturnController.pageReturn$.subscribe(data => {
        _this2.iconName = data.iconName;
        _this2.chain = data.chain;
        _this2.data.chain = data.chain;
        _this2.symbol = data.symbol;
        /// 链改变，需要判断地址
        if (_this2.address.value) {
          _this2.address.dirty === false && _this2.address.markAsDirty();
          _this2.address.setValue(_this2.address.value);
        }
      });
      _this2.scannerPageReturnController.pageReturn$.subscribe( /*#__PURE__*/function () {
        var _ref2 = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (data) {
          yield (0,_bnqkl_util_web_extends_promise__WEBPACK_IMPORTED_MODULE_6__.sleep)(350);
          const isString = typeof data === 'string';
          if (isString || data.protocal === _pages_scanner_scanner_component__WEBPACK_IMPORTED_MODULE_8__.QRCODE_PROTOCAL_TYPE.ADDRESS) {
            const address = isString ? data : data['address'];
            _this2.console.log('scan qrCore:', address);
            const isAddress = yield _this2.chainApiService.isAddress(address);
            if (isAddress) {
              _this2.address.dirty === false && _this2.address.markAsDirty();
              _this2.address.setValue(address);
              return;
            } else {
              _bnqkl_framework_plugins_toast__WEBPACK_IMPORTED_MODULE_5__.Toast.show("Scan results do not match address rules");
              return;
            }
          } else {
            _bnqkl_framework_plugins_toast__WEBPACK_IMPORTED_MODULE_5__.Toast.show("Scan results do not match address rules");
            return;
          }
        });
        return function (_x2) {
          return _ref2.apply(this, arguments);
        };
      }());
    })();
  }
  /** 初始化数据 */
  initMenu() {
    var _this3 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const resolveData = _this3.resolveData;
      _this3.iconName = resolveData.address.iconName;
      _this3.symbol = resolveData.address.symbol;
      _this3.chain = _this3.data.chain = resolveData.address.chain;
      if ((0,_bnqkl_framework_helpers__WEBPACK_IMPORTED_MODULE_3__.$isNoEmptyString)(resolveData.address.addressBookId) === true) {
        _this3.form.patchValue({
          address: resolveData.address.address,
          name: resolveData.address.name,
          remarks: resolveData.address.remarks || ''
        });
      }
      _this3.cdRef.detectChanges();
    })();
  }
  /** 保存地址 */
  saveAddress() {
    var _this4 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const {
        address,
        name,
        remarks
      } = _this4.form.getRawValue();
      try {
        var _this4$data$addressBo;
        const chainConfigList = [..._this4.chainV2Service.chainConfig_Map.values()];
        const chainList = [];
        var _iteratorAbruptCompletion = false;
        var _didIteratorError = false;
        var _iteratorError;
        try {
          for (var _iterator = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncIterator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(chainConfigList), _step; _iteratorAbruptCompletion = !(_step = yield _iterator.next()).done; _iteratorAbruptCompletion = false) {
            const item = _step.value;
            {
              const isAddress = yield item.service.isAddress(address);
              if (isAddress) {
                chainList.push({
                  chain: item.chain,
                  symbol: item.symbol
                });
              }
            }
          }
        } catch (err) {
          _didIteratorError = true;
          _iteratorError = err;
        } finally {
          try {
            if (_iteratorAbruptCompletion && _iterator.return != null) {
              yield _iterator.return();
            }
          } finally {
            if (_didIteratorError) {
              throw _iteratorError;
            }
          }
        }
        const addressBookInfo = {
          addressBookId: (_this4$data$addressBo = _this4.data.addressBookId) !== null && _this4$data$addressBo !== void 0 ? _this4$data$addressBo : Math.floor(Math.random() * Number.MAX_SAFE_INTEGER).toString(16),
          iconName: _this4.iconName,
          symbol: _this4.symbol,
          chainList,
          address: address,
          name: name,
          remarks: remarks
        };
        yield _this4.chainAddressBookStorageService.updateChainAddressBook(addressBookInfo);
        _this4.address.dirty && _this4.address.markAsPristine();
        _this4.form.reset();
        _this4.returnValue$.next({
          isChange: true
        });
        _this4.nav.back();
      } catch (error) {
        _bnqkl_framework_plugins_toast__WEBPACK_IMPORTED_MODULE_5__.Toast.show(error instanceof Error ? error.message : String(error));
      }
    })();
  }
  /**
   * 跳转到扫一扫页面
   */
  routeToScanner() {
    // 暂时只提供QR_CODE
    this.nav.routeTo('scanner', {
      scanType: _bnqkl_framework_plugins_barcode_scanner__WEBPACK_IMPORTED_MODULE_4__.SUPPORTED_FORMAT.QR_CODE,
      cameraDirection: _bnqkl_framework_plugins_barcode_scanner__WEBPACK_IMPORTED_MODULE_4__.CAMERA_DIRECTION.BACK,
      text: "Scan " + this.data.chain + " address QR code"
    });
  }
}
_class = ModifyAddressPage;
_class.ɵfac = /*@__PURE__*/(() => {
  let ɵModifyAddressPage_BaseFactory;
  return function ModifyAddressPage_Factory(t) {
    return (ɵModifyAddressPage_BaseFactory || (ɵModifyAddressPage_BaseFactory = _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵgetInheritedFactory"](_class)))(t || _class);
  };
})();
_class.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵdefineComponent"]({
  type: _class,
  selectors: [["w-modify-address-page"]],
  outputs: {
    returnValue$: "returnValue$"
  },
  standalone: true,
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵInheritDefinitionFeature"], _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵStandaloneFeature"]],
  decls: 36,
  vars: 16,
  consts: () => {
    let i18n_0;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_SAVE$$APPS_WALLET_SRC_PAGES_MIME_PAGES_MODIFY_ADDRESS_MODIFY_ADDRESS_COMPONENT_TS_1 = goog.getMsg("Save");
      i18n_0 = MSG_EXTERNAL_SAVE$$APPS_WALLET_SRC_PAGES_MIME_PAGES_MODIFY_ADDRESS_MODIFY_ADDRESS_COMPONENT_TS_1;
    } else {
      i18n_0 = "Save";
    }
    let i18n_2;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_ADDRESS_INFORMATION$$APPS_WALLET_SRC_PAGES_MIME_PAGES_MODIFY_ADDRESS_MODIFY_ADDRESS_COMPONENT_TS_3 = goog.getMsg("Address Information");
      i18n_2 = MSG_EXTERNAL_ADDRESS_INFORMATION$$APPS_WALLET_SRC_PAGES_MIME_PAGES_MODIFY_ADDRESS_MODIFY_ADDRESS_COMPONENT_TS_3;
    } else {
      i18n_2 = "Address Information";
    }
    let i18n_4;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_PLEASE_ENTER_ADDRESS$$APPS_WALLET_SRC_PAGES_MIME_PAGES_MODIFY_ADDRESS_MODIFY_ADDRESS_COMPONENT_TS_5 = goog.getMsg("Please enter address");
      i18n_4 = MSG_EXTERNAL_PLEASE_ENTER_ADDRESS$$APPS_WALLET_SRC_PAGES_MIME_PAGES_MODIFY_ADDRESS_MODIFY_ADDRESS_COMPONENT_TS_5;
    } else {
      i18n_4 = "Please enter address";
    }
    let i18n_6;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_NAME$$APPS_WALLET_SRC_PAGES_MIME_PAGES_MODIFY_ADDRESS_MODIFY_ADDRESS_COMPONENT_TS_7 = goog.getMsg("Name");
      i18n_6 = MSG_EXTERNAL_NAME$$APPS_WALLET_SRC_PAGES_MIME_PAGES_MODIFY_ADDRESS_MODIFY_ADDRESS_COMPONENT_TS_7;
    } else {
      i18n_6 = "Name";
    }
    let i18n_8;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_REMARKS_OPTIONAL_$$APPS_WALLET_SRC_PAGES_MIME_PAGES_MODIFY_ADDRESS_MODIFY_ADDRESS_COMPONENT_TS_9 = goog.getMsg("Remarks(optional)");
      i18n_8 = MSG_EXTERNAL_REMARKS_OPTIONAL_$$APPS_WALLET_SRC_PAGES_MIME_PAGES_MODIFY_ADDRESS_MODIFY_ADDRESS_COMPONENT_TS_9;
    } else {
      i18n_8 = "Remarks(optional)";
    }
    let i18n_10;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_DOES_NOT_MATCH_ADDRESS_RULE$$APPS_WALLET_SRC_PAGES_MIME_PAGES_MODIFY_ADDRESS_MODIFY_ADDRESS_COMPONENT_TS___11 = goog.getMsg(" Does not match address rule ");
      i18n_10 = MSG_EXTERNAL_DOES_NOT_MATCH_ADDRESS_RULE$$APPS_WALLET_SRC_PAGES_MIME_PAGES_MODIFY_ADDRESS_MODIFY_ADDRESS_COMPONENT_TS___11;
    } else {
      i18n_10 = " Does not match address rule ";
    }
    let i18n_12;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_PLEASE_INPUT_THE_NAME$$APPS_WALLET_SRC_PAGES_MIME_PAGES_MODIFY_ADDRESS_MODIFY_ADDRESS_COMPONENT_TS__13 = goog.getMsg("Please input the name");
      i18n_12 = MSG_EXTERNAL_PLEASE_INPUT_THE_NAME$$APPS_WALLET_SRC_PAGES_MIME_PAGES_MODIFY_ADDRESS_MODIFY_ADDRESS_COMPONENT_TS__13;
    } else {
      i18n_12 = "Please input the name";
    }
    let i18n_14;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_THE_MAXIMUM_LENGTH_OF_THE_NAME_IS$$APPS_WALLET_SRC_PAGES_MIME_PAGES_MODIFY_ADDRESS_MODIFY_ADDRESS_COMPONENT_TS__15 = goog.getMsg(" The maximum length of the name is {$interpolation} ", {
        "interpolation": "\uFFFD0\uFFFD"
      }, {
        original_code: {
          "interpolation": "{{ error.requiredLength }}"
        }
      });
      i18n_14 = MSG_EXTERNAL_THE_MAXIMUM_LENGTH_OF_THE_NAME_IS$$APPS_WALLET_SRC_PAGES_MIME_PAGES_MODIFY_ADDRESS_MODIFY_ADDRESS_COMPONENT_TS__15;
    } else {
      i18n_14 = " The maximum length of the name is " + "\uFFFD0\uFFFD" + " ";
    }
    let i18n_16;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_THE_NAME_CANNOT_CONTAINER_SPACES$$APPS_WALLET_SRC_PAGES_MIME_PAGES_MODIFY_ADDRESS_MODIFY_ADDRESS_COMPONENT_TS__17 = goog.getMsg("The name cannot container spaces !");
      i18n_16 = MSG_EXTERNAL_THE_NAME_CANNOT_CONTAINER_SPACES$$APPS_WALLET_SRC_PAGES_MIME_PAGES_MODIFY_ADDRESS_MODIFY_ADDRESS_COMPONENT_TS__17;
    } else {
      i18n_16 = "The name cannot container spaces !";
    }
    let i18n_18;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_THE_MAXIMUM_LENGTH_OF_THE_REMARKS_IS$$APPS_WALLET_SRC_PAGES_MIME_PAGES_MODIFY_ADDRESS_MODIFY_ADDRESS_COMPONENT_TS__19 = goog.getMsg(" The maximum length of the remarks is {$interpolation} ", {
        "interpolation": "\uFFFD0\uFFFD"
      }, {
        original_code: {
          "interpolation": "{{ error.requiredLength }}"
        }
      });
      i18n_18 = MSG_EXTERNAL_THE_MAXIMUM_LENGTH_OF_THE_REMARKS_IS$$APPS_WALLET_SRC_PAGES_MIME_PAGES_MODIFY_ADDRESS_MODIFY_ADDRESS_COMPONENT_TS__19;
    } else {
      i18n_18 = " The maximum length of the remarks is " + "\uFFFD0\uFFFD" + " ";
    }
    let i18n_20;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_THE_REMARKS_CANNOT_CONTAINER_SPACES$$APPS_WALLET_SRC_PAGES_MIME_PAGES_MODIFY_ADDRESS_MODIFY_ADDRESS_COMPONENT_TS__21 = goog.getMsg(" The remarks cannot container spaces ! ");
      i18n_20 = MSG_EXTERNAL_THE_REMARKS_CANNOT_CONTAINER_SPACES$$APPS_WALLET_SRC_PAGES_MIME_PAGES_MODIFY_ADDRESS_MODIFY_ADDRESS_COMPONENT_TS__21;
    } else {
      i18n_20 = " The remarks cannot container spaces ! ";
    }
    return [[3, "headerTitle", "contentBackground"], ["endMenu", "", "bnRippleButton", "", 1, "disabled:opacity-50", 3, "disabled", "click"], [1, "text-primary"], i18n_0, ["bnRippleButton", "", 1, "px-page-safe-area-inset", "mt-1.5", "flex", "w-full", "items-center", "bg-white", "py-4", 3, "routerLink"], [1, "text-3xl", 3, "name"], [1, "ml-2"], [1, "text-sm", "font-semibold", "text-black"], ["name", "right", 1, "ml-auto"], [1, "mt-1.5", "box-border", "flex", "w-full", "flex-col", "bg-white", "px-5", "pb-5", "pt-3", 3, "formGroup"], [1, "mb-1", "text-sm", "font-semibold", "text-black"], i18n_2, [1, "mb-1", "flex", "h-4", "w-full", "items-end", "justify-end", "text-xs", "font-semibold"], ["class", "text-red text-right", 4, "ngIf"], [1, "bg-env", "h-10.5", "flex", "w-full", "items-center", "rounded-lg"], ["formControlName", "address", "placeholder", i18n_4, 1, "flex-grow", "px-3", "font-normal"], ["name", "scan", "class", "text-subtext mr-3 text-xl"], [1, "text-error", "text-xss", "text-right", "font-normal", 3, "wSwitchErrors"], ["wCaseKey", "required"], ["wCaseKey", "maxlength"], ["wCaseKey", "whitespace"], ["formControlName", "name", "placeholder", i18n_6, 1, "w-full", "px-3", "font-normal"], ["formControlName", "remarks", "placeholder", i18n_8, 1, "w-full", "px-3", "font-normal"], [1, "text-red", "text-right"], ["class", "text-error text-xss font-normal", 4, "ngIf"], [1, "text-error", "text-xss", "font-normal"], i18n_10, ["name", "scan", 1, "text-subtext", "mr-3", "text-xl", 3, "click"], i18n_12, i18n_14, i18n_16, i18n_18, i18n_20];
  },
  template: function ModifyAddressPage_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](0, "common-page", 0)(1, "button", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵlistener"]("click", function ModifyAddressPage_Template_button_click_1_listener() {
        return ctx.saveAddress();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵpipe"](2, "async");
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](3, "span", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵi18n"](4, 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](5, "button", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelement"](6, "w-icon", 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](7, "div", 6)(8, "div", 7);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtext"](9);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelement"](10, "w-icon", 8);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](11, "form", 9)(12, "div", 10);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵi18n"](13, 11);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](14, "fieldset")(15, "legend", 12);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtemplate"](16, ModifyAddressPage_div_16_Template, 3, 2, "div", 13);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵpipe"](17, "errors");
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](18, "div", 14);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelement"](19, "input", 15);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtemplate"](20, ModifyAddressPage_Conditional_20_Template, 1, 0, "w-icon", 16);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](21, "fieldset")(22, "legend", 12)(23, "div", 17);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtemplate"](24, ModifyAddressPage_ng_template_24_Template, 2, 0, "ng-template", 18)(25, ModifyAddressPage_ng_template_25_Template, 2, 1, "ng-template", 19)(26, ModifyAddressPage_ng_template_26_Template, 2, 0, "ng-template", 20);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](27, "div", 14);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelement"](28, "input", 21);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](29, "fieldset")(30, "legend", 12)(31, "div", 17);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtemplate"](32, ModifyAddressPage_ng_template_32_Template, 2, 1, "ng-template", 19)(33, ModifyAddressPage_ng_template_33_Template, 2, 0, "ng-template", 20);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](34, "div", 14);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelement"](35, "input", 22);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]()()()();
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵproperty"]("headerTitle", ctx.title)("contentBackground", "env");
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵproperty"]("disabled", _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵpipeBind1"](2, 11, ctx.form.statusChanges) !== "VALID");
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](4);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵproperty"]("routerLink", _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵpureFunction0"](15, _c22));
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵproperty"]("name", ctx.iconName);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtextInterpolate"](ctx.chain);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵproperty"]("formGroup", ctx.form);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](5);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵproperty"]("ngIf", _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵpipeBind1"](17, 13, ctx.address));
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](4);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵconditional"](20, ctx.isMobile ? 20 : -1);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵproperty"]("wSwitchErrors", ctx.name);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](8);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵproperty"]("wSwitchErrors", ctx.remarks);
    }
  },
  dependencies: [_modules_page_module__WEBPACK_IMPORTED_MODULE_7__.CommonPageModule, _libs_bnf_components_ripple_button_ripple_button_directive__WEBPACK_IMPORTED_MODULE_14__.RippleButtonDirective, _libs_bnf_directives_form_errors_directive__WEBPACK_IMPORTED_MODULE_15__.SwitchErrorsDirective, _libs_bnf_directives_form_errors_directive__WEBPACK_IMPORTED_MODULE_15__.SwitchCaseDirective, _libs_bnf_directives_auto_complete_off_directive__WEBPACK_IMPORTED_MODULE_16__.AutoCompleteOffDirective, _angular_common__WEBPACK_IMPORTED_MODULE_22__.NgIf, _angular_forms__WEBPACK_IMPORTED_MODULE_21__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_21__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_21__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_21__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_21__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_21__.FormControlName, _angular_router__WEBPACK_IMPORTED_MODULE_23__.RouterLink, _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_17__.CommonPageComponent, _components_icon_icon_component__WEBPACK_IMPORTED_MODULE_18__.IconComponent, _libs_bnf_pipes_errors_errors_pipe__WEBPACK_IMPORTED_MODULE_19__.ErrorsPipe, _angular_common__WEBPACK_IMPORTED_MODULE_22__.AsyncPipe],
  styles: ["/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsInNvdXJjZVJvb3QiOiIifQ== */"],
  changeDetection: 0
});
(0,tslib__WEBPACK_IMPORTED_MODULE_24__.__decorate)([ModifyAddressPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_24__.__metadata)("design:type", Object)], ModifyAddressPage.prototype, "selectAddressTypePageReturnController", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_24__.__decorate)([ModifyAddressPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_24__.__metadata)("design:type", Object)], ModifyAddressPage.prototype, "scannerPageReturnController", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_24__.__decorate)([ModifyAddressPage.QueryParams(), (0,tslib__WEBPACK_IMPORTED_MODULE_24__.__metadata)("design:type", Object)], ModifyAddressPage.prototype, "data", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_24__.__decorate)([ModifyAddressPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_24__.__metadata)("design:type", Object), (0,tslib__WEBPACK_IMPORTED_MODULE_24__.__metadata)("design:paramtypes", [])], ModifyAddressPage.prototype, "title", null);
(0,tslib__WEBPACK_IMPORTED_MODULE_24__.__decorate)([ModifyAddressPage.OnInit(), (0,tslib__WEBPACK_IMPORTED_MODULE_24__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_24__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_24__.__metadata)("design:returntype", Promise)], ModifyAddressPage.prototype, "watchPageReturn", null);
(0,tslib__WEBPACK_IMPORTED_MODULE_24__.__decorate)([ModifyAddressPage.OnInit(), (0,tslib__WEBPACK_IMPORTED_MODULE_24__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_24__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_24__.__metadata)("design:returntype", Promise)], ModifyAddressPage.prototype, "initMenu", null);
(0,tslib__WEBPACK_IMPORTED_MODULE_24__.__decorate)([ModifyAddressPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_24__.__metadata)("design:type", String)], ModifyAddressPage.prototype, "iconName", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_24__.__decorate)([ModifyAddressPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_24__.__metadata)("design:type", String)], ModifyAddressPage.prototype, "chain", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_24__.__decorate)([ModifyAddressPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_24__.__metadata)("design:type", String)], ModifyAddressPage.prototype, "symbol", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_24__.__decorate)([ModifyAddressPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_24__.__metadata)("design:type", Object)], ModifyAddressPage.prototype, "address", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_24__.__decorate)([ModifyAddressPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_24__.__metadata)("design:type", Object)], ModifyAddressPage.prototype, "name", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_24__.__decorate)([ModifyAddressPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_24__.__metadata)("design:type", Object)], ModifyAddressPage.prototype, "remarks", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_24__.__decorate)([ModifyAddressPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_24__.__metadata)("design:type", _angular_forms__WEBPACK_IMPORTED_MODULE_21__.FormGroup)], ModifyAddressPage.prototype, "form", void 0);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ModifyAddressPage);

/***/ }),

/***/ 26390:
/*!***********************************************************************************************!*\
  !*** ./apps/wallet/src/pages/mime/pages/select-address-type/select-address-type.component.ts ***!
  \***********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   SelectAddressTypePage: () => (/* binding */ SelectAddressTypePage),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 52542);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! tslib */ 90505);
/* harmony import */ var _bnqkl_framework_animations__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @bnqkl/framework/animations */ 43127);
/* harmony import */ var _modules_page_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ~modules/page.module */ 77538);
/* harmony import */ var _bnqkl_wallet_base_services_wallet__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @bnqkl/wallet-base/services/wallet */ 20609);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 61039);
/* harmony import */ var _libs_bnf_components_ripple_button_ripple_button_directive__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../../../../../libs/bnf/components/ripple-button/ripple-button.directive */ 16505);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/common */ 6729);
/* harmony import */ var _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../../../../../libs/bnf/modules/page/common-page/common-page.component */ 62052);
/* harmony import */ var _components_icon_icon_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../../components/icon/icon.component */ 74703);

var _class;









function SelectAddressTypePage_li_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r3 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](0, "li")(1, "button", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("click", function SelectAddressTypePage_li_2_Template_button_click_1_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵrestoreView"](_r3);
      const item_r1 = restoredCtx.$implicit;
      const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵresetView"](ctx_r2.select(item_r1));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](2, "w-icon", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](3, "div", 5)(4, "div", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]()()()();
  }
  if (rf & 2) {
    const item_r1 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("name", item_r1.iconName);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtextInterpolate"](item_r1.chain);
  }
}
/**  选择主币种类型 */
class SelectAddressTypePage extends _modules_page_module__WEBPACK_IMPORTED_MODULE_2__.CommonPageBase {
  constructor() {
    super(...arguments);
    /** 页面返回值的类型 */
    this.returnValue$ = new _modules_page_module__WEBPACK_IMPORTED_MODULE_2__.PageReturnValue();
    /** 主币种列表 */
    this.chainList = [];
  }
  /** 初始化钱包支持的链列表 */
  initMenu() {
    var _this = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const chainV2Service = _this.injectorForceGet(_bnqkl_wallet_base_services_wallet__WEBPACK_IMPORTED_MODULE_3__.ChainV2Service);
      const list = [...chainV2Service.chainConfig_Map.values()].sort((a, b) => a.chain > b.chain ? 1 : -1);
      _this.chainList = list.map(item => {
        return {
          iconName: `icon-${item.chain}-${item.symbol.toLowerCase()}`,
          symbol: item.symbol,
          chain: item.chain
        };
      });
    })();
  }
  /** 选择类型 */
  select(item) {
    this.returnValue$.next({
      iconName: item.iconName,
      symbol: item.symbol,
      chain: item.chain
    });
    this.nav.back();
  }
}
_class = SelectAddressTypePage;
_class.ɵfac = /*@__PURE__*/(() => {
  let ɵSelectAddressTypePage_BaseFactory;
  return function SelectAddressTypePage_Factory(t) {
    return (ɵSelectAddressTypePage_BaseFactory || (ɵSelectAddressTypePage_BaseFactory = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵgetInheritedFactory"](_class)))(t || _class);
  };
})();
_class.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdefineComponent"]({
  type: _class,
  selectors: [["w-select-address-type-page"]],
  outputs: {
    returnValue$: "returnValue$"
  },
  standalone: true,
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵInheritDefinitionFeature"], _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵStandaloneFeature"]],
  decls: 3,
  vars: 7,
  consts: [[3, "titleColor", "headerBackground", "contentBackground", "contentSafeArea"], [1, "w-full", "bg-white"], [4, "ngFor", "ngForOf", "ngForTrackBy"], ["bnRippleButton", "", 1, "px-page-safe-area-inset", "flex", "w-full", "items-center", "py-4", 3, "click"], [1, "text-3xl", 3, "name"], [1, "ml-2"], [1, "text-sm", "font-semibold"]],
  template: function SelectAddressTypePage_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](0, "common-page", 0)(1, "ul", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtemplate"](2, SelectAddressTypePage_li_2_Template, 6, 2, "li", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]()();
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("titleColor", "black")("headerBackground", "white")("contentBackground", "env")("contentSafeArea", false);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("@listFadeInRight", ctx.chainList.length);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("ngForOf", ctx.chainList)("ngForTrackBy", ctx.trackByKey("chain"));
    }
  },
  dependencies: [_modules_page_module__WEBPACK_IMPORTED_MODULE_2__.CommonPageModule, _libs_bnf_components_ripple_button_ripple_button_directive__WEBPACK_IMPORTED_MODULE_4__.RippleButtonDirective, _angular_common__WEBPACK_IMPORTED_MODULE_8__.NgForOf, _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_5__.CommonPageComponent, _components_icon_icon_component__WEBPACK_IMPORTED_MODULE_6__.IconComponent],
  styles: ["/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsInNvdXJjZVJvb3QiOiIifQ== */"],
  data: {
    animation: [_bnqkl_framework_animations__WEBPACK_IMPORTED_MODULE_1__.listFadeInRightTrigger]
  },
  changeDetection: 0
});
(0,tslib__WEBPACK_IMPORTED_MODULE_9__.__decorate)([SelectAddressTypePage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__metadata)("design:type", Array)], SelectAddressTypePage.prototype, "chainList", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_9__.__decorate)([SelectAddressTypePage.OnReady(), (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__metadata)("design:returntype", Promise)], SelectAddressTypePage.prototype, "initMenu", null);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SelectAddressTypePage);

/***/ }),

/***/ 11606:
/*!************************************************************!*\
  !*** ./libs/bnf/controllers/form-validators.controller.ts ***!
  \************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   FormValidatorsController: () => (/* binding */ FormValidatorsController)
/* harmony export */ });
/* harmony import */ var _bnqkl_framework_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @bnqkl/framework/core */ 63563);
/* harmony import */ var _bnqkl_util_web_extends_map__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @bnqkl/util-web/extends-map */ 37689);


/**
 * 页面表单扩展验证器
 *
 * > 因为涉及到FromControl的生命周期管理，所以这里需要使用Controller模式来获取组件/页面的生命周期
 *
 * 为了确保类型安全, 请遵循以下规则去定义验证器:
 * 1. 尽可能直接提供 $ValidatorFn,比如 `trimRequired(control: AbstractControl): $ValidationErrors | null {...}`
 * 2. 如果不能直接提供 $ValidatorFn, 那么作为工厂模式,必然要有参数传入,比如 `equals(leaderCtrl: AbstractControl): $ValidatorFn {...}`
 */
class FormValidatorsController {
  /**
   * 通过订阅原页面的生命周期，来对订阅的字段进行监听解除
   */
  constructor(comp) {
    /**
     * 判断两个数据字段相等的时，left===right 中 left的数据订阅
     */
    this._equalsLeaderMap = _bnqkl_util_web_extends_map__WEBPACK_IMPORTED_MODULE_1__.EasyMap.from({
      creater(ctrl) {
        const sub = {
          sub$: ctrl.valueChanges.subscribe(() => {
            for (const ctrl of sub.destControls) {
              ctrl.updateValueAndValidity();
            }
          }),
          destControls: new Set()
        };
        return sub;
      }
    });
    (0,_bnqkl_framework_core__WEBPACK_IMPORTED_MODULE_0__.addLifecycleMethods)(comp, 'ngOnDestroy', {
      origin: 'form-validator',
      method: () => {
        for (const {
          sub$
        } of this._equalsLeaderMap.values()) {
          sub$.unsubscribe();
        }
        this._equalsLeaderMap.clear();
      },
      order: Number.MAX_SAFE_INTEGER /* 最后才做这些事情 */
    });
  }
  /** 两个字段对比 相等就过 不相等返回 {equals:true} */
  equals(leaderCtrl) {
    const leader = this._equalsLeaderMap.forceGet(leaderCtrl);
    // pwdCtrl.val
    return follerCtrl => {
      leader.destControls.add(follerCtrl);
      if (leaderCtrl.value === follerCtrl.value) {
        return null;
      }
      return {
        equals: true
      };
    };
  }
  /** 是否包含空格 */
  whitespace(control) {
    const value = control.value;
    if (typeof value === 'string' && /\s/.test(value)) {
      return {
        whitespace: true
      };
    }
    return null;
  }
  /** required 变体, 左右两边不能包含空格 */
  trimRequired(control) {
    const value = control.value;
    if (typeof value === 'string' && value.trim().length === 0 || value == undefined) {
      return {
        trimRequired: true
      };
    }
    return null;
  }
}

/***/ }),

/***/ 47919:
/*!***************************************!*\
  !*** ./libs/bnf/controllers/index.ts ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   FormValidatorsController: () => (/* reexport safe */ _form_validators_controller__WEBPACK_IMPORTED_MODULE_0__.FormValidatorsController),
/* harmony export */   PageReturnController: () => (/* reexport safe */ _page_return_controller__WEBPACK_IMPORTED_MODULE_1__.PageReturnController)
/* harmony export */ });
/* harmony import */ var _form_validators_controller__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./form-validators.controller */ 11606);
/* harmony import */ var _page_return_controller__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./page-return.controller */ 62893);



/***/ }),

/***/ 62893:
/*!********************************************************!*\
  !*** ./libs/bnf/controllers/page-return.controller.ts ***!
  \********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   PageReturnController: () => (/* binding */ PageReturnController)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 54106);
/* harmony import */ var _bnqkl_util_web_decorator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @bnqkl/util-web/decorator */ 18112);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs */ 19177);



/**
 * 页面数据返回值的订阅功能
 * > Controller 必须在构造函数期间执行
 */
class PageReturnController {
  /** 继承日志 */
  get console() {
    return this.fromPage.console;
  }
  /**
   * 传入源页面与目标页面的构造函数，并通过订阅原页面的生命周期，来初始化对路由的订阅
   * 这里依赖 ion-router-outlet 来获取跳转过去的页面
   * 注：该监听返回是全触发（只要页面没被销毁掉不管页面是否处于激活状态）
   * @param specific 用于指定fromPage触发（需要手动指定），业务需要
   */
  constructor(fromPage, toPageCtor, specific = false) {
    this.fromPage = fromPage;
    /** 当前定阅过的页面 */
    this._toPages = new WeakSet();
    /**
     * 订阅到的返回内容，
     * 类型由对应页面的 returnValue$ 的定义决定
     */
    this.pageReturn$ = new rxjs__WEBPACK_IMPORTED_MODULE_1__.Subject();
    const {
      nav
    } = fromPage;
    fromPage.takeUntilDestroy(nav.pageActiveState$).subscribe(event => {
      /// 只监听新激活的页面
      if (event.type !== 'activate') {
        return;
      }
      const toPage = event.target;
      if (toPage instanceof toPageCtor &&
      // 去重
      this._toPages.has(toPage) === false) {
        if (toPage.returnValue$ === undefined) {
          return;
        }
        this._toPages.add(toPage);
        if (specific) {
          var _toPage$specificRetur;
          (_toPage$specificRetur = toPage.specificReturnPages) === null || _toPage$specificRetur === void 0 || _toPage$specificRetur.add(fromPage);
        }
        fromPage.takeUntilDestroy(toPage.returnValue$).subscribe({
          next: data => {
            /// 这里不用判断specific
            if (toPage.specificReturnPages && toPage.specificReturnPages.size) {
              /// 如果有写入，那么就只需要触发相对应页面就行
              toPage.specificReturnPages.has(fromPage) && this.pageReturn$.next(data);
              return;
            }
            this.pageReturn$.next(data);
          },
          complete: () => {
            var _toPage$specificRetur2;
            // 释放内存引用
            (_toPage$specificRetur2 = toPage.specificReturnPages) === null || _toPage$specificRetur2 === void 0 || _toPage$specificRetur2.delete(fromPage);
            return this._toPages.delete(toPage);
          }
        });
      }
    });
  }
}
(0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([_bnqkl_util_web_decorator__WEBPACK_IMPORTED_MODULE_0__.cacheGetter, (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__metadata)("design:type", Object), (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__metadata)("design:paramtypes", [])], PageReturnController.prototype, "console", null);

/***/ }),

/***/ 69899:
/*!*****************************************************************************************!*\
  !*** ./node_modules/.pnpm/@plaoc+is-dweb@0.1.0/node_modules/@plaoc/is-dweb/esm/main.js ***!
  \*****************************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   dwebTarget: () => (/* binding */ dwebTarget),
/* harmony export */   isDweb: () => (/* binding */ isDweb),
/* harmony export */   isMobile: () => (/* binding */ isMobile)
/* harmony export */ });
/**
 * 判断是不是dweb
 * * @returns boolean
 */
const isDweb = () => {
  const isDweb = self.navigator.userAgent.includes("Dweb");
  // @ts-ignore
  const isPlaoc = self.__native_close_watcher_kit__ !== void 0;
  if (isDweb || isPlaoc) {
    return true;
  }
  const userAgentData = self.navigator.userAgentData;
  if (!userAgentData) {
    return false;
  }
  const brands = userAgentData.brands.filter(value => {
    return value.brand === "DwebBrowser";
  });
  return Array.isArray(brands) && brands.length > 0;
};
/**
 * 判断dweb大版本
 * @returns boolean
 */
const dwebTarget = () => {
  if (isDweb()) {
    const userAgentData = self.navigator.userAgentData;
    if (!userAgentData) {
      return 2.0;
    }
    const brands = userAgentData.brands.filter(value => {
      return value.brand === "jmm.browser.dweb";
    });
    if (Array.isArray(brands) && brands.length > 0) {
      return parseFloat(brands[0].version);
    }
  }
  return 1.0;
};
/**
 * 判断是否是移动端
 * @returns boolean
 */
const isMobile = () => {
  if (!navigator.userAgentData) {
    return true;
  }
  return !!navigator.userAgentData.mobile;
};

/***/ })

}]);
//# sourceMappingURL=default-apps_wallet_src_pages_mime_pages_modify-address_modify-address_component_ts.js.map