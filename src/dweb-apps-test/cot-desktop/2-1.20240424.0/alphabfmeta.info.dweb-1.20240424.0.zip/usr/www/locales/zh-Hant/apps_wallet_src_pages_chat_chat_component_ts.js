"use strict";
(self["webpackChunkwallet"] = self["webpackChunkwallet"] || []).push([["apps_wallet_src_pages_chat_chat_component_ts"],{

/***/ 92805:
/*!******************************************************!*\
  !*** ./apps/wallet/src/pages/chat/chat.component.ts ***!
  \******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ChatPage: () => (/* binding */ ChatPage),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _modules_page_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ~modules/page.module */ 77538);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 61039);
/* harmony import */ var _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../../../libs/bnf/modules/page/common-page/common-page.component */ 62052);
var _class;



/**
 * chat 业务相关的汇总页面
 */
class ChatPage extends _modules_page_module__WEBPACK_IMPORTED_MODULE_0__.CommonPageBase {}
_class = ChatPage;
_class.ɵfac = /*@__PURE__*/(() => {
  let ɵChatPage_BaseFactory;
  return function ChatPage_Factory(t) {
    return (ɵChatPage_BaseFactory || (ɵChatPage_BaseFactory = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵgetInheritedFactory"](_class)))(t || _class);
  };
})();
_class.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineComponent"]({
  type: _class,
  selectors: [["w-chat-page"]],
  standalone: true,
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵInheritDefinitionFeature"], _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵStandaloneFeature"]],
  decls: 5,
  vars: 1,
  consts: () => {
    let i18n_0;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_CHAT$$APPS_WALLET_SRC_PAGES_CHAT_CHAT_COMPONENT_TS_1 = goog.getMsg("Chat");
      i18n_0 = MSG_EXTERNAL_CHAT$$APPS_WALLET_SRC_PAGES_CHAT_CHAT_COMPONENT_TS_1;
    } else {
      i18n_0 = "\u804A\u5929";
    }
    let i18n_2;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_STAY_TUNED$$APPS_WALLET_SRC_PAGES_CHAT_CHAT_COMPONENT_TS_3 = goog.getMsg("Stay Tuned");
      i18n_2 = MSG_EXTERNAL_STAY_TUNED$$APPS_WALLET_SRC_PAGES_CHAT_CHAT_COMPONENT_TS_3;
    } else {
      i18n_2 = "\u656C\u8ACB\u671F\u5F85";
    }
    return [["headerTitle", i18n_0, 3, "contentBackground"], [1, "flex", "h-full", "w-full", "flex-col", "items-center", "justify-center"], ["src", "./assets/state-chat.png", "alt", "", "srcset", "", 1, "w-46", "mb-4", "flex", "h-auto"], [1, "text-text", "text-center"], i18n_2];
  },
  template: function ChatPage_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "common-page", 0)(1, "div", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](2, "img", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](3, "p", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵi18n"](4, 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()()();
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("contentBackground", "env");
    }
  },
  dependencies: [_modules_page_module__WEBPACK_IMPORTED_MODULE_0__.CommonPageModule, _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_1__.CommonPageComponent],
  styles: ["/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsInNvdXJjZVJvb3QiOiIifQ== */"],
  changeDetection: 0
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ChatPage);

/***/ })

}]);
//# sourceMappingURL=apps_wallet_src_pages_chat_chat_component_ts.js.map