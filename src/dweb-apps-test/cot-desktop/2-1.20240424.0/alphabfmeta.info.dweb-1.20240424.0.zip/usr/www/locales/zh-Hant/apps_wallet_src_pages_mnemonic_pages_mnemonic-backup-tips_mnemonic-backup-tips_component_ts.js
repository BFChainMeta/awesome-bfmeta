"use strict";
(self["webpackChunkwallet"] = self["webpackChunkwallet"] || []).push([["apps_wallet_src_pages_mnemonic_pages_mnemonic-backup-tips_mnemonic-backup-tips_component_ts"],{

/***/ 99596:
/*!*****************************************************************************************************!*\
  !*** ./apps/wallet/src/pages/mnemonic/pages/mnemonic-backup-tips/mnemonic-backup-tips.component.ts ***!
  \*****************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   MnemonicBackupTipsPage: () => (/* binding */ MnemonicBackupTipsPage),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 52542);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 90505);
/* harmony import */ var _modules_page_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ~modules/page.module */ 77538);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 61039);
/* harmony import */ var _libs_bnf_components_ripple_button_ripple_button_directive__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../../../libs/bnf/components/ripple-button/ripple-button.directive */ 16505);
/* harmony import */ var _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../../../../libs/bnf/modules/page/common-page/common-page.component */ 62052);

var _class;





/**
 * 备份助记词提示页面
 * @FIXME
 */
/** 助记词备份提示页 */
class MnemonicBackupTipsPage extends _modules_page_module__WEBPACK_IMPORTED_MODULE_1__.CommonPageBase {
  constructor() {
    super(...arguments);
    /** 跳过备份 */
    // @MnemonicBackupTipsPage.QueryParam('skipBackup')
    this.skipBackup = false;
  }
  /** 询问是否跳过备份 */
  // readonly askSkipBackup = $singleton(async () => {
  //   const confirmed = await this.confirm({
  //     headerTitle: $localize`:@@ARE_YOU_SURE_YOU_WANT_TO_SKIP_BACKUP:Are you sure you want to skip backup?`,
  //     bodyMessage: $localize`:@@IF_IT_IS_NOT_BACKED_UP_THE_WALLET_CANNOT_BE_RESTORED_AND_ASSET_LOSS_MAY_RESULT:If it not backed up, the wallet cannot be restored, and asset loss may result.`,
  //     bodyTheme: 'error',
  //     confirmText: $localize`:@@GIVE_UP_BACKUP:Give Up Backup`,
  //     cancelText: $localize`:@@CANCEL:Cancel`,
  //     footerTheme: 'error',
  //   });
  //   if (confirmed) {
  //     const bip39LibService = this.injectorForceGet(Bip39LibService);
  //     const walletService = this.injectorForceGet(WalletService);
  //     const mnemonic = (await bip39LibService.createMnemonic(Number(this._data.length || 12), this._data.language))
  //       .mnemonic;
  //     await walletService.createMainWallet(
  //       {
  //         /** 钱包名称 */
  //         name: this._data.name,
  //         /** 助记词 */
  //         mnemonic,
  //         /** 密码 */
  //         password: this._data.pwd,
  //         /** 密码提示 */
  //         passwordTips: this._data.tip,
  //       },
  //       true
  //     );
  //     return this.nav.setPageRoot('tabs');
  //   }
  // });
  /** 进入都创建助记词页面 */
  goToBackup() {
    var _this = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      // 基本参数传递到
      return _this.nav.routeTo('/mnemonic/mnemonics-backup', _this._data, true);
    })();
  }
}
_class = MnemonicBackupTipsPage;
_class.ɵfac = /*@__PURE__*/(() => {
  let ɵMnemonicBackupTipsPage_BaseFactory;
  return function MnemonicBackupTipsPage_Factory(t) {
    return (ɵMnemonicBackupTipsPage_BaseFactory || (ɵMnemonicBackupTipsPage_BaseFactory = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵgetInheritedFactory"](_class)))(t || _class);
  };
})();
_class.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineComponent"]({
  type: _class,
  selectors: [["w-mnemonic-backup-tips-page"]],
  standalone: true,
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵInheritDefinitionFeature"], _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵStandaloneFeature"]],
  decls: 19,
  vars: 6,
  consts: () => {
    let i18n_0;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_PLEASE_BACKUP_YOUR_WALLET_NOW$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_MNEMONIC_BACKUP_TIPS_MNEMONIC_BACKUP_TIPS_COMPONENT_TS_1 = goog.getMsg(" Please backup your wallet now ");
      i18n_0 = MSG_EXTERNAL_PLEASE_BACKUP_YOUR_WALLET_NOW$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_MNEMONIC_BACKUP_TIPS_MNEMONIC_BACKUP_TIPS_COMPONENT_TS_1;
    } else {
      i18n_0 = "\u8ACB\u7ACB\u5373\u5099\u4EFD\u9322\u5305";
    }
    let i18n_2;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_IN_THE_NEXT_STEP_YOU_CAN_SEE_THE_MNEMONIC_WORDS_USED_TO_RESTORE_THE_WALLET_IN_ORDER_TO_ENSURE_THE_SECURITY_OF_THE_WALLET_PLEASE_BE_SURE_TO_COMPLETE_THE_BACKUP_OF_THE_MNEMONIC_PHRASE_AS_SOON_AS_POSSIBLE$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_MNEMONIC_BACKUP_TIPS_MNEMONIC_BACKUP_TIPS_COMPONENT_TS_3 = goog.getMsg(" In the next step you can see the mnemonic (12 words) used to restore the wallet. In order to ensure the security of the wallet, please be sure to complete the backup of the mnemonic phrase as soon as possible. ");
      i18n_2 = MSG_EXTERNAL_IN_THE_NEXT_STEP_YOU_CAN_SEE_THE_MNEMONIC_WORDS_USED_TO_RESTORE_THE_WALLET_IN_ORDER_TO_ENSURE_THE_SECURITY_OF_THE_WALLET_PLEASE_BE_SURE_TO_COMPLETE_THE_BACKUP_OF_THE_MNEMONIC_PHRASE_AS_SOON_AS_POSSIBLE$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_MNEMONIC_BACKUP_TIPS_MNEMONIC_BACKUP_TIPS_COMPONENT_TS_3;
    } else {
      i18n_2 = "\u5728\u4E0B\u4E00\u6B65\u4E2D\uFF0C\u60A8\u53EF\u770B\u5230\u7528\u65BC\u6062\u5FA9\u9322\u5305\u7684\u52A9\u8A18\u8A5E\uFF0812\u500B\u55AE\u8A5E\uFF09\u3002\u70BA\u4E86\u4FDD\u969C\u9322\u5305\u5B89\u5168\uFF0C\u8ACB\u52D9\u5FC5\u5118\u5FEB\u5B8C\u6210\u52A9\u8A18\u8A5E\u5099\u4EFD\u3002";
    }
    let i18n_4;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_IMPORTANT_HINT$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_MNEMONIC_BACKUP_TIPS_MNEMONIC_BACKUP_TIPS_COMPONENT_TS_5 = goog.getMsg("Important Hint !");
      i18n_4 = MSG_EXTERNAL_IMPORTANT_HINT$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_MNEMONIC_BACKUP_TIPS_MNEMONIC_BACKUP_TIPS_COMPONENT_TS_5;
    } else {
      i18n_4 = "\u91CD\u8981\u63D0\u793A\uFF01";
    }
    let i18n_6;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_IF_YOU_LOSE_YOUR_MNEMONIC_PHRASE_YOUR_ASSETS_ARE_LOST_FOREVER$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_MNEMONIC_BACKUP_TIPS_MNEMONIC_BACKUP_TIPS_COMPONENT_TS_7 = goog.getMsg(" If you lose your mnemonic phrase, your assets are lost forever. ");
      i18n_6 = MSG_EXTERNAL_IF_YOU_LOSE_YOUR_MNEMONIC_PHRASE_YOUR_ASSETS_ARE_LOST_FOREVER$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_MNEMONIC_BACKUP_TIPS_MNEMONIC_BACKUP_TIPS_COMPONENT_TS_7;
    } else {
      i18n_6 = "\u5982\u679C\u4E1F\u5931\u4E86\u52A9\u8A18\u8A5E\uFF0C\u60A8\u7684\u8CC7\u7522\u5C07\u6C38\u9060\u4E1F\u5931\u3002";
    }
    let i18n_8;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_DO_NOT_DISCLOSE_OR_SHARE_THE_MNEMONIC_PHRASE_WITH_OTHERS$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_MNEMONIC_BACKUP_TIPS_MNEMONIC_BACKUP_TIPS_COMPONENT_TS_9 = goog.getMsg(" Do not disclose or share the mnemonic phrase with others. ");
      i18n_8 = MSG_EXTERNAL_DO_NOT_DISCLOSE_OR_SHARE_THE_MNEMONIC_PHRASE_WITH_OTHERS$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_MNEMONIC_BACKUP_TIPS_MNEMONIC_BACKUP_TIPS_COMPONENT_TS_9;
    } else {
      i18n_8 = "\u8ACB\u52FF\u5411\u4ED6\u4EBA\u516C\u958B\u6216\u5206\u4EAB\u52A9\u8A18\u8A5E\u3002";
    }
    let i18n_10;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_PAGE_FOOTER$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_MNEMONIC_BACKUP_TIPS_MNEMONIC_BACKUP_TIPS_COMPONENT_TS_11 = goog.getMsg("Page footer");
      i18n_10 = MSG_EXTERNAL_PAGE_FOOTER$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_MNEMONIC_BACKUP_TIPS_MNEMONIC_BACKUP_TIPS_COMPONENT_TS_11;
    } else {
      i18n_10 = "\u9801\u8173";
    }
    let i18n_12;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_BACKUP_YOUR_MNEMONIC_NOW$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_MNEMONIC_BACKUP_TIPS_MNEMONIC_BACKUP_TIPS_COMPONENT_TS_13 = goog.getMsg(" Backup Your Mnemonic Now ");
      i18n_12 = MSG_EXTERNAL_BACKUP_YOUR_MNEMONIC_NOW$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_MNEMONIC_BACKUP_TIPS_MNEMONIC_BACKUP_TIPS_COMPONENT_TS_13;
    } else {
      i18n_12 = "\u7ACB\u5373\u5099\u4EFD\u52A9\u8A18\u8A5E";
    }
    return [[3, "contentSafeArea", "contentBackground", "headerBackground", "headerTranslucent", "footerTranslucent", "footerOpacity"], [1, "mt-6", "grid", "place-items-center"], ["src", "./assets/images/icon_mnemonic.svg", 1, "w-45", "h-45"], [1, "text-title", "text-center"], [1, "mb-1.5", "mt-3", "text-base", "font-semibold"], i18n_0, [1, "text-sm"], i18n_2, [1, "bg-error/10", "mt-6", "rounded", "px-5", "py-4", "text-center"], [1, "text-error", "mb-1.5", "font-semibold"], i18n_4, [1, "text-error", "text-xs"], i18n_6, [1, "mt-1"], i18n_8, ["footer", "", "aria-label", i18n_10, 1, "grid", "place-items-center", "gap-5", "pt-3"], ["bnRippleButton", "", 1, "h-10.5", "from-purple-gradient-start", "to-purple-gradient-end", "mb-4", "w-full", "rounded-full", "bg-gradient-to-b", "text-center", "text-sm", "text-white", 3, "click"], i18n_12];
  },
  template: function MnemonicBackupTipsPage_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "common-page", 0)(1, "div", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](2, "img", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](3, "div", 3)(4, "h4", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵi18n"](5, 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](6, "div", 6);
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵi18n"](7, 7);
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](8, "div", 8)(9, "h4", 9);
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵi18n"](10, 10);
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](11, "div", 11);
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementContainerStart"](12);
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵi18n"](13, 12);
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementContainerEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](14, "div", 13);
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵi18n"](15, 14);
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()();
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](16, "div", 15)(17, "button", 16);
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function MnemonicBackupTipsPage_Template_button_click_17_listener() {
        return ctx.goToBackup();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵi18n"](18, 17);
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()();
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("contentSafeArea", true)("contentBackground", "white")("headerBackground", "transparent")("headerTranslucent", false)("footerTranslucent", false)("footerOpacity", 0.8);
    }
  },
  dependencies: [_modules_page_module__WEBPACK_IMPORTED_MODULE_1__.CommonPageModule, _libs_bnf_components_ripple_button_ripple_button_directive__WEBPACK_IMPORTED_MODULE_2__.RippleButtonDirective, _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_3__.CommonPageComponent],
  styles: ["/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsInNvdXJjZVJvb3QiOiIifQ== */"],
  changeDetection: 0
});
(0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([MnemonicBackupTipsPage.QueryParams(), (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__metadata)("design:type", Object)], MnemonicBackupTipsPage.prototype, "_data", void 0);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MnemonicBackupTipsPage);

/***/ })

}]);
//# sourceMappingURL=apps_wallet_src_pages_mnemonic_pages_mnemonic-backup-tips_mnemonic-backup-tips_component_ts.js.map