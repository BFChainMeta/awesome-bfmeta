"use strict";
(self["webpackChunkwallet"] = self["webpackChunkwallet"] || []).push([["apps_wallet_src_pages_demo_demo_routes_ts"],{

/***/ 54617:
/*!*****************************************************!*\
  !*** ./apps/wallet/src/pages/demo/demo.resolver.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AssetsResolver: () => (/* binding */ AssetsResolver),
/* harmony export */   PeopleResolver: () => (/* binding */ PeopleResolver),
/* harmony export */   demoResolver: () => (/* binding */ demoResolver)
/* harmony export */ });
/* harmony import */ var D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 52542);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 61039);
/* harmony import */ var _bnqkl_framework_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @bnqkl/framework/core */ 63563);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ 14115);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs */ 96121);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs */ 41720);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs */ 30494);




/**
 * People Resolver
 */
// @Injectable({ providedIn: 'root' })
// export class PeopleResolver implements Resolve<$People> {
//   /**
//    * 不论是使用 Promise 还是 Observable， resolve 只会 takeFirstValue，所以不能再resolve中做数据订阅，它也没有生命周期来管理数据订阅。
//    * resolve 只能用作 [一次性] [获取] [页面关键数据] 的方案
//    * @param route
//    * @param state
//    * @returns
//    */
//   async resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
//     await new Promise((cb) => setTimeout(cb, 1000));
//     return { age: 12, route, state };
//   }
// }
const PeopleResolver = /*#__PURE__*/function () {
  var _ref = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (route, state) {
    yield new Promise(cb => setTimeout(cb, 1000));
    return {
      age: 12,
      route,
      state
    };
  });
  return function PeopleResolver(_x, _x2) {
    return _ref.apply(this, arguments);
  };
}();
/**
 * Asset Resolver
 */
// @Injectable({ providedIn: 'root' })
// export class AssetsResolver implements Resolve<$Assets> {
//   /** 日志 */
//   readonly console = inject(LoggerService).createLoggerForResolver('demo/assets');
//   /**
//    * use Observable
//    */
//   resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
//     const assetList: $Assets = [
//       { type: 'ethereum', balance: 56.66 },
//       { type: 'tron', balance: 45.12 },
//       { type: 'binance', balance: 82.12 },
//     ];
//     /// 这里只会被 take 一次
//     return of(...Array.from({ length: 10 }, (_, i) => i)).pipe(
//       map((v) => timeout(v * 1000)),
//       map((_, i) => {
//         this.console.log('demo: take assets resolver', i);
//         return assetList.map((asset) => {
//           return {
//             ...asset,
//             balance: asset.balance + i,
//             route,
//             state,
//           };
//         });
//       })
//     );
//   }
// }
const AssetsResolver = /*#__PURE__*/function () {
  var _ref2 = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (route, state) {
    const console = (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.inject)(_bnqkl_framework_core__WEBPACK_IMPORTED_MODULE_1__.LoggerService).createLoggerForResolver('demo/assets');
    const assetList = [{
      type: 'ethereum',
      balance: 56.66
    }, {
      type: 'tron',
      balance: 45.12
    }, {
      type: 'binance',
      balance: 82.12
    }];
    /// 这里只会被 take 一次
    return (0,rxjs__WEBPACK_IMPORTED_MODULE_3__.firstValueFrom)((0,rxjs__WEBPACK_IMPORTED_MODULE_4__.of)(...Array.from({
      length: 10
    }, (_, i) => i)).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_5__.map)(v => (0,rxjs__WEBPACK_IMPORTED_MODULE_6__.timeout)(v * 1000)), (0,rxjs__WEBPACK_IMPORTED_MODULE_5__.map)((_, i) => {
      console.log('demo: take assets resolver', i);
      return assetList.map(asset => {
        return {
          ...asset,
          balance: asset.balance + i,
          route,
          state
        };
      });
    })));
  });
  return function AssetsResolver(_x3, _x4) {
    return _ref2.apply(this, arguments);
  };
}();
/**
 * 用于 Route.resolve
 * 用于 MixinNavigator.resolve
 */
const demoResolver = {
  people: PeopleResolver,
  assets: AssetsResolver
};

/***/ }),

/***/ 20969:
/*!***************************************************!*\
  !*** ./apps/wallet/src/pages/demo/demo.routes.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   routes: () => (/* binding */ routes)
/* harmony export */ });
/* harmony import */ var _demo_resolver__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./demo.resolver */ 54617);

const routes = [{
  path: '',
  loadComponent: () => Promise.all(/*! import() */[__webpack_require__.e("common"), __webpack_require__.e("apps_wallet_src_pages_demo_demo_component_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./demo.component */ 83602)),
  resolve: _demo_resolver__WEBPACK_IMPORTED_MODULE_0__.demoResolver
}, {
  path: 'to',
  loadComponent: () => __webpack_require__.e(/*! import() */ "common").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/to/to.component */ 86977))
}];
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (routes);

/***/ }),

/***/ 30494:
/*!************************************************************************************************!*\
  !*** ./node_modules/.pnpm/rxjs@7.8.1/node_modules/rxjs/dist/esm/internal/operators/timeout.js ***!
  \************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   TimeoutError: () => (/* binding */ TimeoutError),
/* harmony export */   timeout: () => (/* binding */ timeout)
/* harmony export */ });
/* harmony import */ var _scheduler_async__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../scheduler/async */ 43617);
/* harmony import */ var _util_isDate__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../util/isDate */ 48892);
/* harmony import */ var _util_lift__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../util/lift */ 56932);
/* harmony import */ var _observable_innerFrom__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../observable/innerFrom */ 15259);
/* harmony import */ var _util_createErrorClass__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../util/createErrorClass */ 72294);
/* harmony import */ var _OperatorSubscriber__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./OperatorSubscriber */ 6949);
/* harmony import */ var _util_executeSchedule__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../util/executeSchedule */ 70837);







const TimeoutError = (0,_util_createErrorClass__WEBPACK_IMPORTED_MODULE_0__.createErrorClass)(_super => function TimeoutErrorImpl(info = null) {
  _super(this);
  this.message = 'Timeout has occurred';
  this.name = 'TimeoutError';
  this.info = info;
});
function timeout(config, schedulerArg) {
  const {
    first,
    each,
    with: _with = timeoutErrorFactory,
    scheduler = schedulerArg !== null && schedulerArg !== void 0 ? schedulerArg : _scheduler_async__WEBPACK_IMPORTED_MODULE_1__.asyncScheduler,
    meta = null
  } = (0,_util_isDate__WEBPACK_IMPORTED_MODULE_2__.isValidDate)(config) ? {
    first: config
  } : typeof config === 'number' ? {
    each: config
  } : config;
  if (first == null && each == null) {
    throw new TypeError('No timeout provided.');
  }
  return (0,_util_lift__WEBPACK_IMPORTED_MODULE_3__.operate)((source, subscriber) => {
    let originalSourceSubscription;
    let timerSubscription;
    let lastValue = null;
    let seen = 0;
    const startTimer = delay => {
      timerSubscription = (0,_util_executeSchedule__WEBPACK_IMPORTED_MODULE_4__.executeSchedule)(subscriber, scheduler, () => {
        try {
          originalSourceSubscription.unsubscribe();
          (0,_observable_innerFrom__WEBPACK_IMPORTED_MODULE_5__.innerFrom)(_with({
            meta,
            lastValue,
            seen
          })).subscribe(subscriber);
        } catch (err) {
          subscriber.error(err);
        }
      }, delay);
    };
    originalSourceSubscription = source.subscribe((0,_OperatorSubscriber__WEBPACK_IMPORTED_MODULE_6__.createOperatorSubscriber)(subscriber, value => {
      timerSubscription === null || timerSubscription === void 0 ? void 0 : timerSubscription.unsubscribe();
      seen++;
      subscriber.next(lastValue = value);
      each > 0 && startTimer(each);
    }, undefined, undefined, () => {
      if (!(timerSubscription === null || timerSubscription === void 0 ? void 0 : timerSubscription.closed)) {
        timerSubscription === null || timerSubscription === void 0 ? void 0 : timerSubscription.unsubscribe();
      }
      lastValue = null;
    }));
    !seen && startTimer(first != null ? typeof first === 'number' ? first : +first - scheduler.now() : each);
  });
}
function timeoutErrorFactory(info) {
  throw new TimeoutError(info);
}

/***/ })

}]);
//# sourceMappingURL=apps_wallet_src_pages_demo_demo_routes_ts.js.map