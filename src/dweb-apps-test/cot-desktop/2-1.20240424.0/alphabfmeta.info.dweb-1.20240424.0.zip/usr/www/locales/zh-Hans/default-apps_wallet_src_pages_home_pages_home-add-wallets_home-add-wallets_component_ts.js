"use strict";
(self["webpackChunkwallet"] = self["webpackChunkwallet"] || []).push([["default-apps_wallet_src_pages_home_pages_home-add-wallets_home-add-wallets_component_ts"],{

/***/ 93982:
/*!***************************************************************************************************!*\
  !*** ./apps/wallet/src/pages/home/pages/home-add-wallet-step2/home-add-wallet-step2.component.ts ***!
  \***************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   HomeAddWalletStep2Page: () => (/* binding */ HomeAddWalletStep2Page),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 52542);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! tslib */ 90505);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/core */ 61039);
/* harmony import */ var lodash_sortBy__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! lodash/sortBy */ 88675);
/* harmony import */ var lodash_sortBy__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(lodash_sortBy__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _modules_page_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ~modules/page.module */ 77538);
/* harmony import */ var _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @bnqkl/wallet-base/services/wallet/chain-base */ 27187);
/* harmony import */ var _bnqkl_wallet_base_services_wallet_chain__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @bnqkl/wallet-base/services/wallet/chain */ 27434);
/* harmony import */ var _bnqkl_wallet_base_services_wallet_wallet_data_storage__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @bnqkl/wallet-base/services/wallet/wallet-data-storage */ 63024);
/* harmony import */ var _libs_bnf_components_ripple_button_ripple_button_directive__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../../../../../libs/bnf/components/ripple-button/ripple-button.directive */ 16505);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/common */ 6729);
/* harmony import */ var _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../../../../../libs/bnf/modules/page/common-page/common-page.component */ 62052);
/* harmony import */ var _components_icon_icon_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../../components/icon/icon.component */ 74703);

var _class;












function HomeAddWalletStep2Page_div_12_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](0, "div", 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵi18n"](1, 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
  }
}
function HomeAddWalletStep2Page_div_13_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](0, "div", 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵi18n"](1, 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
  }
}
function HomeAddWalletStep2Page_button_17_Template(rf, ctx) {
  if (rf & 1) {
    const _r4 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](0, "button", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵlistener"]("click", function HomeAddWalletStep2Page_button_17_Template_button_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵrestoreView"](_r4);
      const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵresetView"](ctx_r3.toImportWallet("privateKey"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](1, "div")(2, "div", 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵi18n"](3, 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](4, "div", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵi18n"](5, 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](6, "w-icon", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
  }
}
/**
 * 添加钱包第二步页面
 * 选择一种方式来添加钱包
 */
class HomeAddWalletStep2Page extends _modules_page_module__WEBPACK_IMPORTED_MODULE_2__.CommonPageBase {
  constructor() {
    super(...arguments);
    /**
     * 钱包数据存储服务
     */
    this.walletDataStorageService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_9__.inject)(_bnqkl_wallet_base_services_wallet_wallet_data_storage__WEBPACK_IMPORTED_MODULE_5__.WalletDataStorageService);
    /** 生物链林 没有私钥导入 需要做判断 */
    this.showPrivateImport = true;
    /** 链服务 */
    this._chainService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_9__.inject)(_bnqkl_wallet_base_services_wallet_chain__WEBPACK_IMPORTED_MODULE_4__.ChainService);
  }
  onInit() {
    this.showPrivateImport = !this._chainService.isBioforestChainByChainName(this.data.chainName);
  }
  /** 跳转到导入钱包页面  */
  toImportWallet(params) {
    var _this = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const walletName = yield _this.createWalletName();
      const {
        notMainWalletKey,
        chainName,
        symbol
      } = _this.data;
      _this.nav.routeTo('/home-import-wallet', {
        type: params,
        walletName: walletName,
        notMainWalletKey: notMainWalletKey,
        chain: chainName,
        symbol: symbol
      });
    })();
  }
  /** 跳转到创建钱包页面 */
  toCreateWallet() {
    var _this2 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const walletName = yield _this2.createWalletName();
      const {
        notMainWalletKey,
        chainName,
        symbol
      } = _this2.data;
      _this2.nav.routeTo('/home-create-wallet', {
        walletName: walletName,
        notMainWalletKey: notMainWalletKey,
        token: chainName,
        symbol: symbol
      });
    })();
  }
  /** 创建钱包名称 */
  createWalletName() {
    var _this3 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const {
        symbol,
        chainName
      } = _this3.data;
      const walletSymbol = chainName === _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_3__.CHAIN_NAME.Binance ? 'BSC' : symbol;
      const list = yield _this3.walletDataStorageService.getNotMainWalletListById(_this3.data.notMainWalletKey);
      const rightList = list.filter(item => item.name.startsWith(`${walletSymbol}-`));
      const sortList = lodash_sortBy__WEBPACK_IMPORTED_MODULE_1___default()(rightList, item => {
        var _item$name;
        return +((_item$name = item.name) === null || _item$name === void 0 ? void 0 : _item$name.split('-')[1]);
      });
      let index = sortList.length;
      for (let i = 0; i < sortList.length; i++) {
        const name = `${walletSymbol}-${i + 1}`;
        const item = sortList[i];
        if (item.name !== name) {
          index = i;
          break;
        }
      }
      return `${walletSymbol}-${index + 1}`;
    })();
  }
}
_class = HomeAddWalletStep2Page;
_class.ɵfac = /*@__PURE__*/(() => {
  let ɵHomeAddWalletStep2Page_BaseFactory;
  return function HomeAddWalletStep2Page_Factory(t) {
    return (ɵHomeAddWalletStep2Page_BaseFactory || (ɵHomeAddWalletStep2Page_BaseFactory = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵgetInheritedFactory"](_class)))(t || _class);
  };
})();
_class.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdefineComponent"]({
  type: _class,
  selectors: [["w-home-add-wallet-step2-page"]],
  inputs: {
    data: "data"
  },
  standalone: true,
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵInheritDefinitionFeature"], _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵStandaloneFeature"]],
  decls: 18,
  vars: 6,
  consts: () => {
    let i18n_0;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_CREAT_WALLET$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_ADD_WALLET_STEP2_HOME_ADD_WALLET_STEP2_COMPONENT_TS_1 = goog.getMsg("Create Wallet");
      i18n_0 = MSG_EXTERNAL_CREAT_WALLET$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_ADD_WALLET_STEP2_HOME_ADD_WALLET_STEP2_COMPONENT_TS_1;
    } else {
      i18n_0 = "\u521B\u5EFA\u94B1\u5305";
    }
    let i18n_2;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_IMPORT_WALLET_BY_CREATING_MNEMONIC$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_ADD_WALLET_STEP2_HOME_ADD_WALLET_STEP2_COMPONENT_TS_3 = goog.getMsg(" Import wallet by creating mnemonic ");
      i18n_2 = MSG_EXTERNAL_IMPORT_WALLET_BY_CREATING_MNEMONIC$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_ADD_WALLET_STEP2_HOME_ADD_WALLET_STEP2_COMPONENT_TS_3;
    } else {
      i18n_2 = "\u4F7F\u7528\u65B0\u52A9\u8BB0\u8BCD\u6765\u5BFC\u5165\u94B1\u5305";
    }
    let i18n_4;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_IMPORT_WALLET$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_ADD_WALLET_STEP2_HOME_ADD_WALLET_STEP2_COMPONENT_TS_5 = goog.getMsg("Import Wallet");
      i18n_4 = MSG_EXTERNAL_IMPORT_WALLET$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_ADD_WALLET_STEP2_HOME_ADD_WALLET_STEP2_COMPONENT_TS_5;
    } else {
      i18n_4 = "\u5BFC\u5165\u94B1\u5305";
    }
    let i18n_6;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_IMPORT_THE_ACCOUNT_WITH_THE_MNEMONIC$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_ADD_WALLET_STEP2_HOME_ADD_WALLET_STEP2_COMPONENT_TS_7 = goog.getMsg(" Import the account with the mnemonic ");
      i18n_6 = MSG_EXTERNAL_IMPORT_THE_ACCOUNT_WITH_THE_MNEMONIC$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_ADD_WALLET_STEP2_HOME_ADD_WALLET_STEP2_COMPONENT_TS_7;
    } else {
      i18n_6 = "\u4F7F\u7528\u52A9\u8BB0\u8BCD\u6765\u5BFC\u5165\u94B1\u5305";
    }
    let i18n_8;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_MNEMONIC$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_ADD_WALLET_STEP2_HOME_ADD_WALLET_STEP2_COMPONENT_TS__9 = goog.getMsg("Mnemonic");
      i18n_8 = MSG_EXTERNAL_MNEMONIC$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_ADD_WALLET_STEP2_HOME_ADD_WALLET_STEP2_COMPONENT_TS__9;
    } else {
      i18n_8 = "\u52A9\u8BB0\u8BCD";
    }
    let i18n_10;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_MNEMONIC___ADDRESS_PASSWORD$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_ADD_WALLET_STEP2_HOME_ADD_WALLET_STEP2_COMPONENT_TS__11 = goog.getMsg(" Mnemonic / Address Password ");
      i18n_10 = MSG_EXTERNAL_MNEMONIC___ADDRESS_PASSWORD$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_ADD_WALLET_STEP2_HOME_ADD_WALLET_STEP2_COMPONENT_TS__11;
    } else {
      i18n_10 = "\u52A9\u8BB0\u8BCD/\u5730\u5740\u5BC6\u7801";
    }
    let i18n_12;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_PRIVATE_KEY$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_ADD_WALLET_STEP2_HOME_ADD_WALLET_STEP2_COMPONENT_TS__13 = goog.getMsg("Private Key");
      i18n_12 = MSG_EXTERNAL_PRIVATE_KEY$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_ADD_WALLET_STEP2_HOME_ADD_WALLET_STEP2_COMPONENT_TS__13;
    } else {
      i18n_12 = "\u79C1\u94A5";
    }
    let i18n_14;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_IMPORT_THE_ACCOUNT_WITH_THE_PRIVATE_KEY$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_ADD_WALLET_STEP2_HOME_ADD_WALLET_STEP2_COMPONENT_TS__15 = goog.getMsg(" Import the account with the private key ");
      i18n_14 = MSG_EXTERNAL_IMPORT_THE_ACCOUNT_WITH_THE_PRIVATE_KEY$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_ADD_WALLET_STEP2_HOME_ADD_WALLET_STEP2_COMPONENT_TS__15;
    } else {
      i18n_14 = "\u4F7F\u7528\u79C1\u94A5\u6765\u5BFC\u5165\u94B1\u5305";
    }
    return [[3, "headerTitle", "contentSafeArea", "titleColor"], ["bnRippleButton", "", 1, "border-tiny", "border-line", "px-4.5", "mt-5", "flex", "w-full", "items-center", "justify-between", "rounded-lg", "py-2", 3, "click"], [1, "text-title", "font-semibold"], i18n_0, [1, "text-subtext", "mt-1", "text-sm"], i18n_2, ["name", "right"], [1, "text-subtext", "pb-3", "pt-6", "text-xs"], i18n_4, ["bnRippleButton", "", 1, "border-tiny", "border-line", "px-4.5", "mb-4", "flex", "w-full", "items-center", "justify-between", "rounded-lg", "py-2", 3, "click"], ["class", "text-title font-semibold", 4, "ngIf"], i18n_6, ["bnRippleButton", "", "class", "border-tiny border-line px-4.5 flex w-full items-center justify-between rounded-lg py-2", 3, "click", 4, "ngIf"], i18n_8, i18n_10, ["bnRippleButton", "", 1, "border-tiny", "border-line", "px-4.5", "flex", "w-full", "items-center", "justify-between", "rounded-lg", "py-2", 3, "click"], i18n_12, i18n_14];
  },
  template: function HomeAddWalletStep2Page_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](0, "common-page", 0)(1, "button", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵlistener"]("click", function HomeAddWalletStep2Page_Template_button_click_1_listener() {
        return ctx.toCreateWallet();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](2, "div")(3, "div", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵi18n"](4, 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](5, "div", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵi18n"](6, 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](7, "w-icon", 6);
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](8, "div", 7);
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵi18n"](9, 8);
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](10, "button", 9);
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵlistener"]("click", function HomeAddWalletStep2Page_Template_button_click_10_listener() {
        return ctx.toImportWallet("mnemonic");
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](11, "div");
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtemplate"](12, HomeAddWalletStep2Page_div_12_Template, 2, 0, "div", 10)(13, HomeAddWalletStep2Page_div_13_Template, 2, 0, "div", 10);
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](14, "div", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵi18n"](15, 11);
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](16, "w-icon", 6);
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtemplate"](17, HomeAddWalletStep2Page_button_17_Template, 7, 0, "button", 12);
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("headerTitle", ctx.data.chainName)("contentSafeArea", true)("titleColor", "title");
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](12);
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("ngIf", ctx.showPrivateImport);
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("ngIf", !ctx.showPrivateImport);
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](4);
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("ngIf", ctx.showPrivateImport);
    }
  },
  dependencies: [_modules_page_module__WEBPACK_IMPORTED_MODULE_2__.CommonPageModule, _libs_bnf_components_ripple_button_ripple_button_directive__WEBPACK_IMPORTED_MODULE_6__.RippleButtonDirective, _angular_common__WEBPACK_IMPORTED_MODULE_10__.NgIf, _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_7__.CommonPageComponent, _components_icon_icon_component__WEBPACK_IMPORTED_MODULE_8__.IconComponent],
  styles: ["/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsInNvdXJjZVJvb3QiOiIifQ== */"],
  changeDetection: 0
});
(0,tslib__WEBPACK_IMPORTED_MODULE_11__.__decorate)([HomeAddWalletStep2Page.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_11__.__metadata)("design:type", Object)], HomeAddWalletStep2Page.prototype, "showPrivateImport", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_11__.__decorate)([HomeAddWalletStep2Page.QueryParams(), (0,tslib__WEBPACK_IMPORTED_MODULE_11__.__metadata)("design:type", Object)], HomeAddWalletStep2Page.prototype, "data", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_11__.__decorate)([HomeAddWalletStep2Page.OnInit(), (0,tslib__WEBPACK_IMPORTED_MODULE_11__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_11__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_11__.__metadata)("design:returntype", void 0)], HomeAddWalletStep2Page.prototype, "onInit", null);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (HomeAddWalletStep2Page);

/***/ }),

/***/ 61007:
/*!*****************************************************************************************!*\
  !*** ./apps/wallet/src/pages/home/pages/home-add-wallets/home-add-wallets.component.ts ***!
  \*****************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   HomeAddWalletsPage: () => (/* binding */ HomeAddWalletsPage),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 52542);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! tslib */ 90505);
/* harmony import */ var _bnqkl_framework_animations__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @bnqkl/framework/animations */ 43127);
/* harmony import */ var _modules_page_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ~modules/page.module */ 77538);
/* harmony import */ var _pages_home_pages_home_add_wallet_step2_home_add_wallet_step2_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ~pages/home/pages/home-add-wallet-step2/home-add-wallet-step2.component */ 93982);
/* harmony import */ var _bnqkl_wallet_base_services_wallet_wallet_data_storage__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @bnqkl/wallet-base/services/wallet/wallet-data-storage */ 63024);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/core */ 61039);
/* harmony import */ var _libs_bnf_modules_bottom_sheet_components_bottom_sheet_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../../../../../libs/bnf/modules/bottom-sheet/components/bottom-sheet.component */ 94072);
/* harmony import */ var _libs_bnf_components_ripple_button_ripple_button_directive__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../../../../../libs/bnf/components/ripple-button/ripple-button.directive */ 16505);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/common */ 6729);
/* harmony import */ var _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../../../../../libs/bnf/modules/page/common-page/common-page.component */ 62052);
/* harmony import */ var _components_icon_icon_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../../components/icon/icon.component */ 74703);

var _class;











function HomeAddWalletsPage_li_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r4 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](0, "li")(1, "button", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵlistener"]("click", function HomeAddWalletsPage_li_2_Template_button_click_1_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵrestoreView"](_r4);
      const item_r2 = restoredCtx.$implicit;
      const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵresetView"](ctx_r3.openAddSheet(item_r2));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](2, "w-icon", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](3, "div", 6)(4, "div", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtext"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](6, "div", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtext"](7);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](8, "w-icon", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const item_r2 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("name", item_r2.icon);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtextInterpolate"](item_r2.symbol);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtextInterpolate"](item_r2.chain);
  }
}
function HomeAddWalletsPage_common_bottom_sheet_3_ng_template_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](0, "w-home-add-wallet-step2-page", 11);
  }
  if (rf & 2) {
    const data_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnextContext"]().ngIf;
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("data", data_r5);
  }
}
function HomeAddWalletsPage_common_bottom_sheet_3_Template(rf, ctx) {
  if (rf & 1) {
    const _r9 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](0, "common-bottom-sheet", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵlistener"]("isOpenChange", function HomeAddWalletsPage_common_bottom_sheet_3_Template_common_bottom_sheet_isOpenChange_0_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵrestoreView"](_r9);
      const ctx_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵresetView"]($event || (ctx_r8.selectdChain = undefined));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtemplate"](1, HomeAddWalletsPage_common_bottom_sheet_3_ng_template_1_Template, 1, 1, "ng-template");
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("isOpen", true)("panelClass", "h-2/3");
  }
}
/**
 * 添加钱包第一步页面
 * 选择一条链去做导入
 */
class HomeAddWalletsPage extends _modules_page_module__WEBPACK_IMPORTED_MODULE_2__.CommonPageBase {
  constructor() {
    super(...arguments);
    /** 页面返回值的类型 */
    this.returnValue$ = new _modules_page_module__WEBPACK_IMPORTED_MODULE_2__.PageReturnValue();
    /**
     * 临时数据
     */
    this.chainList = [];
  }
  /** 初始化钱包支持的链列表 */
  initMenu() {
    var _this = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const walletDataStorageService = _this.injectorForceGet(_bnqkl_wallet_base_services_wallet_wallet_data_storage__WEBPACK_IMPORTED_MODULE_4__.WalletDataStorageService);
      const list = yield walletDataStorageService.getAllChainMainWallet();
      _this.chainList = list.map(item => {
        return {
          icon: `icon-${item.chain}-${item.symbol.toLowerCase()}`,
          symbol: item.symbol,
          chain: item.chain,
          notMainWalletKey: item.notMainWalletKey
        };
      });
    })();
  }
  /** 打开添加弹出层 */
  openAddSheet(value) {
    this.selectdChain = {
      chainName: value.chain,
      notMainWalletKey: value.notMainWalletKey,
      symbol: value.symbol
    };
  }
}
_class = HomeAddWalletsPage;
_class.ɵfac = /*@__PURE__*/(() => {
  let ɵHomeAddWalletsPage_BaseFactory;
  return function HomeAddWalletsPage_Factory(t) {
    return (ɵHomeAddWalletsPage_BaseFactory || (ɵHomeAddWalletsPage_BaseFactory = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵgetInheritedFactory"](_class)))(t || _class);
  };
})();
_class.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdefineComponent"]({
  type: _class,
  selectors: [["w-home-add-wallets-page"]],
  outputs: {
    returnValue$: "returnValue$"
  },
  standalone: true,
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵInheritDefinitionFeature"], _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵStandaloneFeature"]],
  decls: 4,
  vars: 8,
  consts: [[3, "titleColor", "headerBackground", "contentBackground", "contentSafeArea"], [1, "w-full", "bg-white"], [4, "ngFor", "ngForOf", "ngForTrackBy"], [3, "isOpen", "panelClass", "isOpenChange", 4, "ngIf"], ["bnRippleButton", "", 1, "px-page-safe-area-inset", "flex", "w-full", "items-center", "py-4", 3, "click"], [1, "text-3xl", 3, "name"], [1, "ml-2"], [1, "text-xs", "font-semibold"], [1, "text-subtext", "text-xss"], ["name", "right", 1, "text-subtext", "ml-auto"], [3, "isOpen", "panelClass", "isOpenChange"], [3, "data"]],
  template: function HomeAddWalletsPage_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](0, "common-page", 0)(1, "ul", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtemplate"](2, HomeAddWalletsPage_li_2_Template, 9, 3, "li", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtemplate"](3, HomeAddWalletsPage_common_bottom_sheet_3_Template, 2, 2, "common-bottom-sheet", 3);
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("titleColor", "black")("headerBackground", "white")("contentBackground", "env")("contentSafeArea", false);
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("@listFadeInRight", ctx.chainList.length);
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("ngForOf", ctx.chainList)("ngForTrackBy", ctx.trackByKey("chain"));
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("ngIf", ctx.selectdChain);
    }
  },
  dependencies: [_modules_page_module__WEBPACK_IMPORTED_MODULE_2__.CommonPageModule, _libs_bnf_modules_bottom_sheet_components_bottom_sheet_component__WEBPACK_IMPORTED_MODULE_5__.BottomSheetComponent, _libs_bnf_components_ripple_button_ripple_button_directive__WEBPACK_IMPORTED_MODULE_6__.RippleButtonDirective, _angular_common__WEBPACK_IMPORTED_MODULE_10__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_10__.NgIf, _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_7__.CommonPageComponent, _components_icon_icon_component__WEBPACK_IMPORTED_MODULE_8__.IconComponent, _pages_home_pages_home_add_wallet_step2_home_add_wallet_step2_component__WEBPACK_IMPORTED_MODULE_3__.HomeAddWalletStep2Page],
  styles: ["/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsInNvdXJjZVJvb3QiOiIifQ== */"],
  data: {
    animation: [_bnqkl_framework_animations__WEBPACK_IMPORTED_MODULE_1__.listFadeInRightTrigger]
  },
  changeDetection: 0
});
(0,tslib__WEBPACK_IMPORTED_MODULE_11__.__decorate)([HomeAddWalletsPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_11__.__metadata)("design:type", Array)], HomeAddWalletsPage.prototype, "chainList", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_11__.__decorate)([HomeAddWalletsPage.OnReady(), (0,tslib__WEBPACK_IMPORTED_MODULE_11__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_11__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_11__.__metadata)("design:returntype", Promise)], HomeAddWalletsPage.prototype, "initMenu", null);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (HomeAddWalletsPage);

/***/ })

}]);
//# sourceMappingURL=default-apps_wallet_src_pages_home_pages_home-add-wallets_home-add-wallets_component_ts.js.map