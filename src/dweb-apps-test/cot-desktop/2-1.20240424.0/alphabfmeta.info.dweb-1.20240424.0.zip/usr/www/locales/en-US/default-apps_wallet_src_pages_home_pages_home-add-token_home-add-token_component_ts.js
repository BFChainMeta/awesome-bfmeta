"use strict";
(self["webpackChunkwallet"] = self["webpackChunkwallet"] || []).push([["default-apps_wallet_src_pages_home_pages_home-add-token_home-add-token_component_ts"],{

/***/ 89539:
/*!*************************************************************************************!*\
  !*** ./apps/wallet/src/pages/home/pages/home-add-token/home-add-token.component.ts ***!
  \*************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   HomeAddTokenPage: () => (/* binding */ HomeAddTokenPage),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 52542);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! tslib */ 90505);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @angular/core */ 61039);
/* harmony import */ var _bnqkl_framework_animations__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @bnqkl/framework/animations */ 43127);
/* harmony import */ var _bnqkl_framework_helpers__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @bnqkl/framework/helpers */ 12169);
/* harmony import */ var _bnqkl_util_web_extends_promise__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @bnqkl/util-web/extends-promise */ 87778);
/* harmony import */ var _modules_page_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ~modules/page.module */ 77538);
/* harmony import */ var _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @bnqkl/wallet-base/services/wallet/chain-base */ 27187);
/* harmony import */ var _bnqkl_wallet_base_services_wallet_chain__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @bnqkl/wallet-base/services/wallet/chain */ 27434);
/* harmony import */ var _bnqkl_wallet_base_services_wallet_wallet_data_storage__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @bnqkl/wallet-base/services/wallet/wallet-data-storage */ 63024);
/* harmony import */ var _libs_bnf_components_ripple_button_ripple_button_directive__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../../../../../libs/bnf/components/ripple-button/ripple-button.directive */ 16505);
/* harmony import */ var _libs_bnf_components_infinite_scroll_infinite_scroll_spinner_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../../../../../../libs/bnf/components/infinite-scroll/infinite-scroll-spinner.component */ 66560);
/* harmony import */ var _libs_bnf_directives_auto_complete_off_directive__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../../../../../../libs/bnf/directives/auto-complete-off.directive */ 66722);
/* harmony import */ var _libs_bnf_components_infinite_scroll_infinite_scroll_directive__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../../../../../../libs/bnf/components/infinite-scroll/infinite-scroll.directive */ 10320);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! @angular/common */ 6729);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! @angular/forms */ 7820);
/* harmony import */ var _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../../../../../../libs/bnf/modules/page/common-page/common-page.component */ 62052);
/* harmony import */ var _components_icon_icon_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../../../../components/icon/icon.component */ 74703);
/* harmony import */ var _libs_bnf_components_loading_wrapper_loading_wrapper_component__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../../../../../../../libs/bnf/components/loading-wrapper/loading-wrapper.component */ 51263);
/* harmony import */ var _pipes_color_color_pipe__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ../../../../pipes/color/color.pipe */ 76489);
/* harmony import */ var _libs_bnf_pipes_address_hidden_address_hidden_pipe__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ../../../../../../../libs/bnf/pipes/address-hidden/address-hidden.pipe */ 35222);
/* harmony import */ var _pipes_chainIcon_chain_icon_pipe__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ../../../../pipes/chainIcon/chain-icon.pipe */ 43040);

var _class;






















const _c0 = ["tokenListContent"];
function HomeAddTokenPage_w_icon_6_Template(rf, ctx) {
  if (rf & 1) {
    const _r9 = _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](0, "w-icon", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵlistener"]("click", function HomeAddTokenPage_w_icon_6_Template_w_icon_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵrestoreView"](_r9);
      const ctx_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵresetView"](ctx_r8.cleanQuery());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
  }
}
const _c3 = a0 => ({
  list: a0
});
function HomeAddTokenPage_div_11_ng_container_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementContainer"](0, 19);
  }
  if (rf & 2) {
    const ctx_r11 = _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵnextContext"](2);
    const _r5 = _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵreference"](15);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵproperty"]("ngTemplateOutlet", _r5)("ngTemplateOutletContext", _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵpureFunction1"](2, _c3, ctx_r11.tokenListInfo.list));
  }
}
function HomeAddTokenPage_div_11_bn_infinite_scroll_spinner_3_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](0, "bn-infinite-scroll-spinner")(1, "span", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵi18n"](2, 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]()();
  }
}
function HomeAddTokenPage_div_11_Template(rf, ctx) {
  if (rf & 1) {
    const _r14 = _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](0, "div", 15, 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵlistener"]("infinited$", function HomeAddTokenPage_div_11_Template_div_infinited__0_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵrestoreView"](_r14);
      const ctx_r13 = _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵresetView"]($event.waitFor(ctx_r13.loadMoreTokenList()));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵtemplate"](2, HomeAddTokenPage_div_11_ng_container_2_Template, 1, 4, "ng-container", 17)(3, HomeAddTokenPage_div_11_bn_infinite_scroll_spinner_3_Template, 3, 0, "bn-infinite-scroll-spinner", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵnextContext"]();
    const _r7 = _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵreference"](17);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵproperty"]("hasMore", ctx_r1.tokenListInfo.hasMore)("@listFadeInRight", ctx_r1.tokenListInfo.list);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵproperty"]("ngIf", ctx_r1.tokenListInfo.list.length)("ngIfElse", _r7);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵproperty"]("ngIf", ctx_r1.tokenListInfo.hasMore);
  }
}
function HomeAddTokenPage_ng_template_12_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](0, "div", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelement"](1, "bn-loading-wrapper", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](2, "p", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵi18n"](3, 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵproperty"]("showLoading", true);
  }
}
function HomeAddTokenPage_ng_template_14_ng_container_0_ng_container_4_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelement"](1, "img", 34);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const item_r17 = _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵnextContext"]().$implicit;
    const ctx_r18 = _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵclassProp"]("rounded-full", ctx_r18.isBioforestChain);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵproperty"]("src", item_r17.logoUrl, _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵsanitizeUrl"]);
  }
}
const _c8 = a0 => ({
  chain: a0,
  prefix: "icon"
});
function HomeAddTokenPage_ng_template_14_ng_container_0_ng_template_5_ng_container_0_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelement"](1, "w-icon", 36);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵpipe"](2, "chainIcon");
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const item_r17 = _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵnextContext"](2).$implicit;
    const ctx_r24 = _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵproperty"]("name", _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵpipeBind2"](2, 1, item_r17.assetType, _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵpureFunction1"](4, _c8, ctx_r24.tokenInfo.chain)));
  }
}
function HomeAddTokenPage_ng_template_14_ng_container_0_ng_template_5_ng_template_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelement"](0, "w-icon", 37);
  }
}
function HomeAddTokenPage_ng_template_14_ng_container_0_ng_template_5_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵtemplate"](0, HomeAddTokenPage_ng_template_14_ng_container_0_ng_template_5_ng_container_0_Template, 3, 6, "ng-container", 29)(1, HomeAddTokenPage_ng_template_14_ng_container_0_ng_template_5_ng_template_1_Template, 1, 0, "ng-template", null, 35, _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵtemplateRefExtractor"]);
  }
  if (rf & 2) {
    const _r26 = _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵreference"](2);
    const item_r17 = _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵnextContext"]().$implicit;
    const ctx_r19 = _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵproperty"]("ngIf", ctx_r19.isLocalLogo(item_r17.assetType, ctx_r19.tokenInfo.chain))("ngIfElse", _r26);
  }
}
function HomeAddTokenPage_ng_template_14_ng_container_0_div_10_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](0, "div", 38);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵpipe"](2, "addressHidden");
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const item_r17 = _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵpipeBind1"](2, 1, item_r17.applyAddress), " ");
  }
}
const _c9 = (a0, a1, a2) => ({
  "--color-1": a0,
  "--color-2": a1,
  "--color-3": a2
});
function HomeAddTokenPage_ng_template_14_ng_container_0_ng_container_12_Template(rf, ctx) {
  if (rf & 1) {
    const _r32 = _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](1, "w-icon", 39);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵlistener"]("click", function HomeAddTokenPage_ng_template_14_ng_container_0_ng_container_12_Template_w_icon_click_1_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵrestoreView"](_r32);
      const item_r17 = _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵnextContext"]().$implicit;
      const ctx_r30 = _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵresetView"](ctx_r30.changeIcon(item_r17));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵpipe"](2, "color");
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵpipe"](3, "color");
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵpipe"](4, "color");
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const item_r17 = _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵproperty"]("name", item_r17.isSelect ? "reduce-n" : "add-n")("ngStyle", _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵpureFunction3"](8, _c9, _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵpipeBind1"](2, 2, "line"), _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵpipeBind1"](3, 4, "primary"), _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵpipeBind1"](4, 6, "primary")));
  }
}
function HomeAddTokenPage_ng_template_14_ng_container_0_Template(rf, ctx) {
  if (rf & 1) {
    const _r35 = _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](1, "button", 26)(2, "div", 27);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵlistener"]("click", function HomeAddTokenPage_ng_template_14_ng_container_0_Template_div_click_2_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵrestoreView"](_r35);
      const item_r17 = restoredCtx.$implicit;
      const ctx_r34 = _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵresetView"](ctx_r34.gotoTokenDetail(item_r17));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](3, "div", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵtemplate"](4, HomeAddTokenPage_ng_template_14_ng_container_0_ng_container_4_Template, 2, 3, "ng-container", 29)(5, HomeAddTokenPage_ng_template_14_ng_container_0_ng_template_5_Template, 3, 2, "ng-template", null, 30, _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵtemplateRefExtractor"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](7, "div", 31)(8, "div", 32);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵtext"](9);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵtemplate"](10, HomeAddTokenPage_ng_template_14_ng_container_0_div_10_Template, 3, 3, "div", 33);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](11, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵtemplate"](12, HomeAddTokenPage_ng_template_14_ng_container_0_ng_container_12_Template, 5, 12, "ng-container", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const item_r17 = ctx.$implicit;
    const _r20 = _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵreference"](6);
    const ctx_r16 = _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵproperty"]("ngIf", item_r17.logoUrl)("ngIfElse", _r20);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵtextInterpolate1"](" ", item_r17.assetType, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵproperty"]("ngIf", !ctx_r16.isBioforestChain);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵproperty"]("ngIf", ctx_r16.tokenInfo.chainSymbol !== item_r17.assetType);
  }
}
function HomeAddTokenPage_ng_template_14_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵtemplate"](0, HomeAddTokenPage_ng_template_14_ng_container_0_Template, 13, 5, "ng-container", 25);
  }
  if (rf & 2) {
    const list_r15 = ctx.list;
    const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵproperty"]("ngForOf", list_r15)("ngForTrackBy", ctx_r4.trackByKey("assetType"));
  }
}
function HomeAddTokenPage_ng_template_16_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](0, "div", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelement"](1, "w-icon", 40);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](2, "span", 41);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵi18n"](3, 42);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]()();
  }
}
const _c12 = a0 => ({
  "--color-1": a0
});
/**
 * 添加币种到首页预览
 */
class HomeAddTokenPage extends _modules_page_module__WEBPACK_IMPORTED_MODULE_4__.CommonPageBase {
  constructor() {
    super(...arguments);
    /** 链服务 */
    this.chainService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_18__.inject)(_bnqkl_wallet_base_services_wallet_chain__WEBPACK_IMPORTED_MODULE_6__.ChainService);
    /** 钱包的存储服务 */
    this.walletDataStorageV2Service = (0,_angular_core__WEBPACK_IMPORTED_MODULE_18__.inject)(_bnqkl_wallet_base_services_wallet_wallet_data_storage__WEBPACK_IMPORTED_MODULE_7__.WalletDataStorageV2Service);
    this.tokenListInfo = {
      page: 1,
      pageSize: 200,
      hasMore: false,
      loading: false,
      list: [],
      init: false
    };
    /** 币种检索信息 */
    this.tokenInfo = {
      chain: '',
      walletName: '',
      addressKey: '',
      // 主权益币种
      chainSymbol: '',
      // 本地缓存里已选择的币种
      showAsset: []
    };
    /** 输入的检索关键词 生物链林是模糊搜索币种名称，外链是模糊搜索名称+精确搜索合约地址 */
    this.inputKeywords = '';
    /** 搜索的检索关键词 */
    this.searchKeywords = '';
    /** 是否操作过 */
    this.isChange = false;
    /** 页面返回值的类型 */
    this.returnValue$ = new _modules_page_module__WEBPACK_IMPORTED_MODULE_4__.PageReturnValue();
    this.searching = false;
  }
  /** 自定义placeholder */
  get placeholder() {
    return this.isBioforestChain ? "Token Name" : "Token Name/Contract Address";
  }
  /** 初始化获取传参 */
  getTokenList(search = false) {
    var _this = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      /** 设置页面信息 */
      const setTokenInfo = /*#__PURE__*/function () {
        var _ref = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (info) {
          /// 基本信息
          _this.tokenInfo.chain = info.chain;
          _this.tokenInfo.walletName = info.walletName;
          _this.tokenInfo.addressKey = info.addressKey;
          _this.tokenInfo.chainSymbol = info.chainSymbol;
          const {
            assets
          } = yield _this.walletDataStorageV2Service.getChainAddressInfo(_this.tokenInfo.addressKey);
          _this.tokenInfo.showAsset = assets.map(item => {
            return item.assetType;
          });
          /// 刷新币种列表
          _this.tokenListInfo.hasMore = false;
          _this.tokenListInfo.page = 1;
          _this.tokenListInfo.init = false;
          search === false && (_this.tokenListInfo.list.length = 0);
        });
        return function setTokenInfo(_x) {
          return _ref.apply(this, arguments);
        };
      }();
      const {
        _data
      } = _this;
      yield setTokenInfo(_data);
      _this.queryTokenList();
      _this.cdRef.detectChanges();
    })();
  }
  /** 退出时检测是否修改并出发首页重新获取资产数据 */
  destroyReturn() {
    var _this2 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this2.returnValue$.next({
        isChange: _this2.isChange
      });
    })();
  }
  /** 加载更多 */
  loadMoreTokenList() {
    return this.queryTokenList(true);
  }
  /** 查询币种列表 */
  queryTokenList(loadMore = false) {
    var _this3 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      if (_this3.tokenListInfo.loading) {
        return;
      }
      const apiChain = _this3.chainService.getChainService(_this3.tokenInfo.chain);
      if (loadMore) {
        _this3.tokenListInfo.page++;
      }
      _this3.tokenListInfo.loading = true;
      try {
        const queryTask = apiChain.getTokenList({
          page: _this3.tokenListInfo.page,
          pageSize: _this3.tokenListInfo.pageSize,
          chainSymbol: _this3.tokenInfo.chainSymbol,
          keywords: _this3.searchKeywords = _this3.inputKeywords
        });
        /// 没数据的时候 延时一下，避免闪屏不好看
        _this3.tokenListInfo.list.length === 0 && (yield (0,_bnqkl_util_web_extends_promise__WEBPACK_IMPORTED_MODULE_3__.sleep)(350));
        const {
          dataList
        } = yield queryTask;
        const autoAddSymbol = /*#__PURE__*/function () {
          var _ref2 = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
            const chainInfo = _this3.chainService.getChainInfo(_this3.tokenInfo.chain);
            let applyAddress = '';
            // 外链采用chain+symbol的形式查询，不需要address
            if (_this3.isBioforestChain) {
              const service = chainInfo.service;
              applyAddress = yield service.getAddressByPublicKeyString(service.config.generatorPublicKey);
            }
            _this3.tokenListInfo.list[0] = {
              applyAddress,
              assetType: chainInfo.symbol,
              decimals: chainInfo.decimals
            };
          });
          return function autoAddSymbol() {
            return _ref2.apply(this, arguments);
          };
        }();
        if (_this3.tokenListInfo.page === 1) {
          if ((0,_bnqkl_framework_helpers__WEBPACK_IMPORTED_MODULE_2__.$isNoEmptyString)(_this3.searchKeywords) === false) {
            _this3.tokenListInfo.list.length = 1;
            yield autoAddSymbol();
          } else {
            /// searchKeywords 存在值，需要判断下
            if (_this3.tokenInfo.chainSymbol.toLowerCase().includes(_this3.searchKeywords.toLowerCase())) {
              _this3.tokenListInfo.list.length = 1;
              yield autoAddSymbol();
            } else {
              _this3.tokenListInfo.list.length = 0;
            }
          }
        }
        if (dataList.length) {
          dataList.forEach(item => {
            if (_this3.tokenInfo.showAsset.includes(item.assetType)) {
              item.isSelect = true;
            } else {
              item.isSelect = false;
            }
          });
          if (_this3.tokenListInfo.page === 1) {
            var _this3$tokenListConte;
            (_this3$tokenListConte = _this3.tokenListContentRef) === null || _this3$tokenListConte === void 0 || _this3$tokenListConte.nativeElement.scrollTo({
              top: 0
            });
          }
          _this3.tokenListInfo.list.push(...dataList.filter(item => item.assetType !== _this3.tokenInfo.chainSymbol));
          if (_this3.tokenListInfo.list.length > 1) {
            const index = _this3.tokenListInfo.list.findIndex(item => {
              if (_this3.tokenInfo.chainSymbol === item.assetType) {
                return true;
              }
              return false;
            });
            if (index > 0) {
              const symbolItem = _this3.tokenListInfo.list[index];
              _this3.tokenListInfo.list[index] = _this3.tokenListInfo.list[0];
              _this3.tokenListInfo.list[0] = symbolItem;
            }
          }
        }
        _this3.tokenListInfo.hasMore = dataList.length >= _this3.tokenListInfo.pageSize;
        _this3.tokenListInfo.init = true;
        _this3.cdRef.detectChanges();
      } catch {
        _this3.tokenListInfo.init = true;
        _this3.tokenListInfo.hasMore = false;
      } finally {
        _this3.tokenListInfo.loading = false;
      }
    })();
  }
  /** 跳转到代币资产详情 */
  gotoTokenDetail(item) {
    this.nav.routeTo('/home-token-info', {
      chain: this.tokenInfo.chain,
      applyAddress: item.applyAddress,
      assetType: item.assetType,
      decimals: item.decimals
    });
  }
  /** 是否是生物链林-链 */
  get isBioforestChain() {
    return this.chainService.isBioforestChainByChainName(this.tokenInfo.chain);
  }
  /** 搜索 */
  search() {
    var _this4 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      if (_this4.searching || _this4.searchKeywords === _this4.inputKeywords) {
        return;
      }
      const page = _this4.tokenListInfo.page;
      const hasMore = _this4.tokenListInfo.hasMore;
      try {
        _this4.searching = true;
        yield _this4.getTokenList(true);
      } catch {
        _this4.tokenListInfo.page = page;
        _this4.tokenListInfo.hasMore = hasMore;
      } finally {
        _this4.searching = false;
      }
    })();
  }
  /** 清空搜索条件 */
  cleanQuery() {
    this.inputKeywords = '';
    if (this.searchKeywords) {
      this.getTokenList();
    }
  }
  /** 修改币种到首页展示的状态，同步到本地缓存 */
  changeIcon(item) {
    var _this5 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      // 更新操作过的数据
      if (item.isSelect) {
        yield _this5.walletDataStorageV2Service.updateChainAddressAssetsInfo(_this5.tokenInfo.addressKey, [], {
          delAssets: [{
            assetType: item.assetType,
            decimals: item.decimals,
            logoUrl: item.logoUrl
          }],
          isCustomAssets: true
        });
        _this5.tokenInfo.showAsset.splice(_this5.tokenInfo.showAsset.indexOf(item.assetType), 1);
      } else {
        const logoUrl = _this5.isBioforestChain && _this5.tokenInfo.chainSymbol === item.assetType ? '' : item.logoUrl;
        yield _this5.walletDataStorageV2Service.updateChainAddressAssetsInfo(_this5.tokenInfo.addressKey, [{
          assetType: item.assetType,
          decimals: item.decimals,
          logoUrl: logoUrl,
          contractAddress: item.applyAddress
        }], {
          isCustomAssets: true
        });
        _this5.tokenInfo.showAsset.push(item.assetType);
      }
      item.isSelect = !item.isSelect;
      _this5.isChange = true;
      _this5.cdRef.detectChanges();
    })();
  }
  /** 键盘enter触发搜索 */
  searchByEnter(event) {
    const keyCode = window.event ? event.keyCode : event.which;
    if (keyCode === 13) {
      this.search();
    }
  }
  /** 本地是否存在图标 */
  isLocalLogo(assetType, chain) {
    return (0,_bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_5__.CHECK_LOCAL_ASSET_LOGO)(assetType, chain);
  }
}
_class = HomeAddTokenPage;
_class.ɵfac = /*@__PURE__*/(() => {
  let ɵHomeAddTokenPage_BaseFactory;
  return function HomeAddTokenPage_Factory(t) {
    return (ɵHomeAddTokenPage_BaseFactory || (ɵHomeAddTokenPage_BaseFactory = _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵgetInheritedFactory"](_class)))(t || _class);
  };
})();
_class.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵdefineComponent"]({
  type: _class,
  selectors: [["w-home-add-token-page"]],
  viewQuery: function HomeAddTokenPage_Query(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵviewQuery"](_c0, 5);
    }
    if (rf & 2) {
      let _t;
      _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵloadQuery"]()) && (ctx.tokenListContentRef = _t.first);
    }
  },
  outputs: {
    returnValue$: "returnValue$"
  },
  standalone: true,
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵInheritDefinitionFeature"], _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵStandaloneFeature"]],
  decls: 18,
  vars: 16,
  consts: () => {
    let i18n_1;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_SEARCH$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_ADD_TOKEN_HOME_ADD_TOKEN_COMPONENT_TS_2 = goog.getMsg(" Search ");
      i18n_1 = MSG_EXTERNAL_SEARCH$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_ADD_TOKEN_HOME_ADD_TOKEN_COMPONENT_TS_2;
    } else {
      i18n_1 = " Search ";
    }
    let i18n_4;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_LOADING$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_ADD_TOKEN_HOME_ADD_TOKEN_COMPONENT_TS___5 = goog.getMsg("Loading");
      i18n_4 = MSG_EXTERNAL_LOADING$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_ADD_TOKEN_HOME_ADD_TOKEN_COMPONENT_TS___5;
    } else {
      i18n_4 = "Loading";
    }
    let i18n_6;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_LOADING$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_ADD_TOKEN_HOME_ADD_TOKEN_COMPONENT_TS__7 = goog.getMsg("Loading");
      i18n_6 = MSG_EXTERNAL_LOADING$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_ADD_TOKEN_HOME_ADD_TOKEN_COMPONENT_TS__7;
    } else {
      i18n_6 = "Loading";
    }
    let i18n_10;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_NO_DATA$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_ADD_TOKEN_HOME_ADD_TOKEN_COMPONENT_TS__11 = goog.getMsg("No Data");
      i18n_10 = MSG_EXTERNAL_NO_DATA$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_ADD_TOKEN_HOME_ADD_TOKEN_COMPONENT_TS__11;
    } else {
      i18n_10 = "No Data";
    }
    return [[3, "contentBackground", "headerTitle", "hideHeaderRightNav", "footerBackground"], ["headerTitle", "", 1, "flex", "w-full"], [1, "bg-env", "rounded-4", "box-border", "flex", "h-7", "w-full", "items-center", "px-3", "py-0"], ["name", "search", 1, "mr-1.5", "text-lg"], ["type", "text", 1, "w-full", "text-xs", "font-normal", "text-black", 3, "ngModel", "placeholder", "ngModelChange", "keydown"], ["class", "mr-1 text-xs", "name", "fail", 3, "click", 4, "ngIf"], ["bnRippleButton", "", 1, "text-primary-2", "ml-2", "shrink-0", "text-sm", 3, "click"], i18n_1, [1, "bg-env", "flex", "h-full", "w-full", "flex-col"], [1, "h-full", "w-full", "overflow-hidden"], ["class", "no-scrollbar h-full w-full overflow-y-scroll", "wInfiniteScroll", "", 3, "hasMore", "infinited$", 4, "ngIf", "ngIfElse"], ["initLoadingView", ""], ["tokenListView", ""], ["emptyListView", ""], ["name", "fail", 1, "mr-1", "text-xs", 3, "click"], ["wInfiniteScroll", "", 1, "no-scrollbar", "h-full", "w-full", "overflow-y-scroll", 3, "hasMore", "infinited$"], ["tokenListContent", ""], [3, "ngTemplateOutlet", "ngTemplateOutletContext", 4, "ngIf", "ngIfElse"], [4, "ngIf"], [3, "ngTemplateOutlet", "ngTemplateOutletContext"], [1, "text-sm"], i18n_4, [1, "flex", "h-full", "w-full", "flex-col", "items-center", "justify-center"], [1, "icon-6", 3, "showLoading"], i18n_6, [4, "ngFor", "ngForOf", "ngForTrackBy"], ["bnRippleButton", "", 1, "box-border", "flex", "h-16", "w-full", "items-center", "justify-between", "bg-white", "px-5"], [1, "flex", "flex-grow", "items-center", 3, "click"], [1, "relative", "mr-1", "flex", "h-9", "w-9", "items-center", "rounded-full"], [4, "ngIf", "ngIfElse"], ["wIconViewByToken", ""], [1, "flex", "flex-grow", "flex-col", "items-start"], [1, "text-title", "text-sm", "font-semibold", "tracking-normal"], ["class", "text-subtext text-xss font-normal tracking-normal", 4, "ngIf"], [1, "_bioforest_asset_logo", "text-3xl", 3, "src"], ["wIconViewBySymbol", ""], [1, "text-3xl", 3, "name"], ["name", "icon-default", 1, "text-3xl"], [1, "text-subtext", "text-xss", "font-normal", "tracking-normal"], [1, "ml-2", "shrink-0", "text-2xl", 3, "name", "ngStyle", "click"], ["name", "no-data", 1, "pb-2", "text-4xl"], [1, "text-line", "text-sm"], i18n_10];
  },
  template: function HomeAddTokenPage_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](0, "common-page", 0)(1, "div", 1)(2, "div", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelement"](3, "w-icon", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵpipe"](4, "color");
      _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](5, "input", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵlistener"]("ngModelChange", function HomeAddTokenPage_Template_input_ngModelChange_5_listener($event) {
        return ctx.inputKeywords = $event;
      })("keydown", function HomeAddTokenPage_Template_input_keydown_5_listener($event) {
        return ctx.searchByEnter($event);
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵtemplate"](6, HomeAddTokenPage_w_icon_6_Template, 1, 0, "w-icon", 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](7, "button", 6);
      _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵlistener"]("click", function HomeAddTokenPage_Template_button_click_7_listener() {
        return ctx.search();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵi18n"](8, 7);
      _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](9, "div", 8)(10, "div", 9);
      _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵtemplate"](11, HomeAddTokenPage_div_11_Template, 4, 5, "div", 10)(12, HomeAddTokenPage_ng_template_12_Template, 4, 1, "ng-template", null, 11, _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵtemplateRefExtractor"]);
      _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]()()();
      _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵtemplate"](14, HomeAddTokenPage_ng_template_14_Template, 1, 2, "ng-template", null, 12, _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵtemplateRefExtractor"])(16, HomeAddTokenPage_ng_template_16_Template, 4, 0, "ng-template", null, 13, _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵtemplateRefExtractor"]);
    }
    if (rf & 2) {
      const _r3 = _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵreference"](13);
      _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵproperty"]("contentBackground", "#eff5ff")("headerTitle", "")("hideHeaderRightNav", true)("footerBackground", "env")("contentBackground", "env");
      _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵpureFunction1"](14, _c12, _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵpipeBind1"](4, 12, "subtext")));
      _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵproperty"]("ngModel", ctx.inputKeywords)("placeholder", ctx.placeholder);
      _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵproperty"]("ngIf", ctx.inputKeywords);
      _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵadvance"](5);
      _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵproperty"]("ngIf", ctx.tokenListInfo.init)("ngIfElse", _r3);
    }
  },
  dependencies: [_modules_page_module__WEBPACK_IMPORTED_MODULE_4__.CommonPageModule, _libs_bnf_components_ripple_button_ripple_button_directive__WEBPACK_IMPORTED_MODULE_8__.RippleButtonDirective, _libs_bnf_components_infinite_scroll_infinite_scroll_spinner_component__WEBPACK_IMPORTED_MODULE_9__.InfiniteScrollSpinnerComponent, _libs_bnf_directives_auto_complete_off_directive__WEBPACK_IMPORTED_MODULE_10__.AutoCompleteOffDirective, _libs_bnf_components_infinite_scroll_infinite_scroll_directive__WEBPACK_IMPORTED_MODULE_11__.InfiniteScrollDirective, _angular_common__WEBPACK_IMPORTED_MODULE_19__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_19__.NgIf, _angular_common__WEBPACK_IMPORTED_MODULE_19__.NgTemplateOutlet, _angular_common__WEBPACK_IMPORTED_MODULE_19__.NgStyle, _angular_forms__WEBPACK_IMPORTED_MODULE_20__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_20__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_20__.NgModel, _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_12__.CommonPageComponent, _components_icon_icon_component__WEBPACK_IMPORTED_MODULE_13__.IconComponent, _libs_bnf_components_loading_wrapper_loading_wrapper_component__WEBPACK_IMPORTED_MODULE_14__.LoadingWrapperComponent, _pipes_color_color_pipe__WEBPACK_IMPORTED_MODULE_15__.ColorPipe, _libs_bnf_pipes_address_hidden_address_hidden_pipe__WEBPACK_IMPORTED_MODULE_16__.AddressHiddenPipe, _pipes_chainIcon_chain_icon_pipe__WEBPACK_IMPORTED_MODULE_17__.ChainIconPipe],
  styles: ["[_nghost-%COMP%]   ._bioforest_asset_logo[_ngcontent-%COMP%] {\n  width: 1em;\n  height: 1em;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL2FwcHMvd2FsbGV0L3NyYy9wYWdlcy9ob21lL3BhZ2VzL2hvbWUtYWRkLXRva2VuL2hvbWUtYWRkLXRva2VuLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUNFO0VBQ0UsVUFBQTtFQUNBLFdBQUE7QUFBSiIsInNvdXJjZXNDb250ZW50IjpbIjpob3N0IHtcclxuICAuX2Jpb2ZvcmVzdF9hc3NldF9sb2dvIHtcclxuICAgIHdpZHRoOiAxZW07XHJcbiAgICBoZWlnaHQ6IDFlbTtcclxuICB9XHJcbn1cclxuIl0sInNvdXJjZVJvb3QiOiIifQ== */"],
  data: {
    animation: [_bnqkl_framework_animations__WEBPACK_IMPORTED_MODULE_1__.listFadeInRightTrigger]
  },
  changeDetection: 0
});
(0,tslib__WEBPACK_IMPORTED_MODULE_21__.__decorate)([HomeAddTokenPage.State()
/** 币种列表 */, (0,tslib__WEBPACK_IMPORTED_MODULE_21__.__metadata)("design:type", Object)], HomeAddTokenPage.prototype, "tokenListInfo", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_21__.__decorate)([HomeAddTokenPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_21__.__metadata)("design:type", Object)], HomeAddTokenPage.prototype, "tokenInfo", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_21__.__decorate)([HomeAddTokenPage.QueryParams(), (0,tslib__WEBPACK_IMPORTED_MODULE_21__.__metadata)("design:type", Object)], HomeAddTokenPage.prototype, "_data", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_21__.__decorate)([HomeAddTokenPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_21__.__metadata)("design:type", Object)], HomeAddTokenPage.prototype, "inputKeywords", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_21__.__decorate)([HomeAddTokenPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_21__.__metadata)("design:type", Object), (0,tslib__WEBPACK_IMPORTED_MODULE_21__.__metadata)("design:paramtypes", [])], HomeAddTokenPage.prototype, "placeholder", null);
(0,tslib__WEBPACK_IMPORTED_MODULE_21__.__decorate)([HomeAddTokenPage.OnInit(), (0,tslib__WEBPACK_IMPORTED_MODULE_21__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_21__.__metadata)("design:paramtypes", [Object]), (0,tslib__WEBPACK_IMPORTED_MODULE_21__.__metadata)("design:returntype", Promise)], HomeAddTokenPage.prototype, "getTokenList", null);
(0,tslib__WEBPACK_IMPORTED_MODULE_21__.__decorate)([HomeAddTokenPage.OnDestroy(), (0,tslib__WEBPACK_IMPORTED_MODULE_21__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_21__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_21__.__metadata)("design:returntype", Promise)], HomeAddTokenPage.prototype, "destroyReturn", null);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (HomeAddTokenPage);

/***/ })

}]);
//# sourceMappingURL=default-apps_wallet_src_pages_home_pages_home-add-token_home-add-token_component_ts.js.map