"use strict";
(self["webpackChunkwallet"] = self["webpackChunkwallet"] || []).push([["apps_wallet_src_assets_wallet-util_index-f943adc9_mjs"],{

/***/ 43670:
/*!***********************************************************************!*\
  !*** ./apps/wallet/src/assets/wallet-util/WASMInterface-b9f2203b.mjs ***!
  \***********************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   a: () => (/* binding */ b),
/* harmony export */   b: () => (/* binding */ c),
/* harmony export */   c: () => (/* binding */ S),
/* harmony export */   d: () => (/* binding */ d),
/* harmony export */   e: () => (/* binding */ y),
/* harmony export */   f: () => (/* binding */ w),
/* harmony export */   g: () => (/* binding */ f),
/* harmony export */   h: () => (/* binding */ p),
/* harmony export */   i: () => (/* binding */ s),
/* harmony export */   j: () => (/* binding */ A),
/* harmony export */   v: () => (/* binding */ g),
/* harmony export */   w: () => (/* binding */ o)
/* harmony export */ });
/* harmony import */ var D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 52542);
/* harmony import */ var _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./index-766bdb76.mjs */ 59809);

var _r$Buffer;

var t = class {
  constructor() {
    this.mutex = Promise.resolve();
  }
  lock() {
    let e = () => {};
    return this.mutex = this.mutex.then(() => new Promise(e)), new Promise(t => {
      e = t;
    });
  }
  dispatch(e) {
    var _this = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const t = yield _this.lock();
      try {
        return yield e();
      } finally {
        t();
      }
    })();
  }
};
const r = "undefined" != typeof globalThis ? globalThis : "undefined" != typeof self ? self : "undefined" != typeof window ? window : global,
  n = (_r$Buffer = r.Buffer) !== null && _r$Buffer !== void 0 ? _r$Buffer : null,
  a = r.TextEncoder ? new r.TextEncoder() : null;
function s(e, t) {
  return String.fromCharCode(...e.subarray(0, t));
}
function o(e, t) {
  const r = t.length >> 1;
  for (let s = 0; s < r; s++) {
    const r = s << 1;
    e[s] = (n = t.charCodeAt(r), a = t.charCodeAt(r + 1), (15 & n) + (n >> 6 | n >> 3 & 8) << 4 | (15 & a) + (a >> 6 | a >> 3 & 8));
  }
  var n, a;
}
const i = "a".charCodeAt(0) - 10,
  h = "0".charCodeAt(0);
function c(e, t, r) {
  let n = 0;
  for (let a = 0; a < r; a++) {
    let r = t[a] >>> 4;
    e[n++] = r > 9 ? r + i : r + h, r = 15 & t[a], e[n++] = r > 9 ? r + i : r + h;
  }
  return String.fromCharCode.apply(null, e);
}
const f = null !== n ? e => {
    if ("string" == typeof e) {
      const t = n.from(e, "utf8");
      return new Uint8Array(t.buffer, t.byteOffset, t.length);
    }
    if (n.isBuffer(e)) return new Uint8Array(e.buffer, e.byteOffset, e.length);
    if (ArrayBuffer.isView(e)) return new Uint8Array(e.buffer, e.byteOffset, e.byteLength);
    throw new Error("Invalid data type!");
  } : e => {
    if ("string" == typeof e) return a.encode(e);
    if (ArrayBuffer.isView(e)) return new Uint8Array(e.buffer, e.byteOffset, e.byteLength);
    throw new Error("Invalid data type!");
  },
  l = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/",
  u = new Uint8Array(256);
for (let e = 0; e < 64; e++) u[l.charCodeAt(e)] = e;
function w(e, t = !0) {
  const r = e.length,
    n = r % 3,
    a = [],
    s = r - n;
  for (let t = 0; t < s; t += 3) {
    const r = (e[t] << 16 & 16711680) + (e[t + 1] << 8 & 65280) + (255 & e[t + 2]),
      n = l.charAt(r >> 18 & 63) + l.charAt(r >> 12 & 63) + l.charAt(r >> 6 & 63) + l.charAt(63 & r);
    a.push(n);
  }
  if (1 === n) {
    const n = e[r - 1],
      s = l.charAt(n >> 2),
      o = l.charAt(n << 4 & 63);
    a.push(`${s}${o}`), t && a.push("==");
  } else if (2 === n) {
    const n = (e[r - 2] << 8) + e[r - 1],
      s = l.charAt(n >> 10),
      o = l.charAt(n >> 4 & 63),
      i = l.charAt(n << 2 & 63);
    a.push(`${s}${o}${i}`), t && a.push("=");
  }
  return a.join("");
}
function y(e) {
  let t = Math.floor(.75 * e.length);
  const r = e.length;
  return "=" === e[r - 1] && (t -= 1, "=" === e[r - 2] && (t -= 1)), t;
}
function d(e) {
  const t = y(e),
    r = e.length,
    n = new Uint8Array(t);
  let a = 0;
  for (let t = 0; t < r; t += 4) {
    const r = u[e.charCodeAt(t)],
      s = u[e.charCodeAt(t + 1)],
      o = u[e.charCodeAt(t + 2)],
      i = u[e.charCodeAt(t + 3)];
    n[a] = r << 2 | s >> 4, a += 1, n[a] = (15 & s) << 4 | o >> 2, a += 1, n[a] = (3 & o) << 6 | 63 & i, a += 1;
  }
  return n;
}
function g(e, t) {
  if (!Number.isInteger(e) || e < 8 || e > t || e % 8 != 0) throw `Invalid variant! Valid values: 8, 16, ..., ${t}`;
}
function b(e, t) {
  return e | t << 16;
}
const m = e => !Number.isInteger(e) || e < 0 || e > 4294967295,
  A = e => {
    if (m(e)) throw new Error("Seed must be a valid 32-bit long unsigned integer.");
  },
  p = (e, t) => {
    if (m(e) || m(t)) throw new Error("Seed must be given as two valid 32-bit long unsigned integers (lo + high).");
  };
const x = 16384,
  v = new t(),
  U = new Map(),
  E = /*#__PURE__*/function () {
    var _ref = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (t) {
      let r = U.get(t);
      return void 0 === r && (r = v.dispatch(() => function () {
        var _ref2 = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (t) {
          const r = `${_index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_1__.c.wasmBaseUrl}/hash-wasm/${t}.wasm`,
            n = yield _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_1__.c.wasmLoader(r);
          return {
            data: n,
            sha1: yield crypto.subtle.digest("SHA-1", n)
          };
        });
        return function (_x2) {
          return _ref2.apply(this, arguments);
        };
      }()(t).then( /*#__PURE__*/function () {
        var _ref3 = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (e) {
          const r = new Uint8Array(e.sha1.slice(0, 4)),
            n = yield WebAssembly.compile(e.data),
            a = {
              hash: r,
              module: n,
              instance: yield WebAssembly.instantiate(n, {})
            };
          return U.set(t, a), a;
        });
        return function (_x3) {
          return _ref3.apply(this, arguments);
        };
      }())), U.set(t, r)), yield r;
    });
    return function E(_x) {
      return _ref.apply(this, arguments);
    };
  }(),
  C = (e, t, r) => {
    const {
        instance: n,
        hash: a
      } = e,
      s = n.exports;
    let o = new Uint8Array(s.memory.buffer, s.Hash_GetBuffer(), x),
      i = !1;
    const h = () => o,
      l = () => new DataView(s.memory.buffer).getUint32(s.STATE_SIZE, !0),
      u = e => {
        i = !0, s.Hash_Init(e);
      },
      w = e => {
        if (!i) throw new Error("update() called before init()");
        (e => {
          let t = 0;
          for (; t < e.length;) {
            const r = e.subarray(t, t + x);
            t += r.length, h().set(r), s.Hash_Update(r.length);
          }
        })(f(e));
      },
      y = new Uint8Array(2 * r),
      d = (e = "binary", t) => {
        if (!i) throw new Error("digest() called before init()");
        return i = !1, s.Hash_Final(t), "hex" === e ? c(y, h(), r) : h().slice(0, r);
      },
      g = e => "string" == typeof e ? e.length < 4096 : e.byteLength < x;
    let b = g;
    switch (t) {
      case "argon2":
      case "scrypt":
        b = () => !0;
        break;
      case "blake2b":
      case "blake2s":
        b = (e, t) => "number" == typeof t && t <= 512 && g(e);
        break;
      case "blake3":
        b = (e, t) => 0 === t && g(e);
        break;
      case "xxhash64":
      case "xxhash3":
      case "xxhash128":
        b = () => !1;
    }
    return {
      getMemory: h,
      writeMemory: (e, t = 0) => {
        h().set(e, t);
      },
      getExports: () => s,
      setMemorySize: e => {
        s.Hash_SetMemorySize(e), o = new Uint8Array(s.memory.buffer, s.Hash_GetBuffer(), e);
      },
      init: u,
      update: w,
      digest: d,
      save: () => {
        if (!i) throw new Error("save() can only be called after init() and before digest()");
        const e = s.Hash_GetState(),
          t = l(),
          r = s.memory.buffer,
          n = new Uint8Array(r, e, t),
          o = new Uint8Array(4 + t);
        return o.set(a, 0), o.set(n, 4), o;
      },
      load: e => {
        if (!(e instanceof Uint8Array)) throw new Error("load() expects an Uint8Array generated by save()");
        const t = s.Hash_GetState(),
          r = l(),
          n = 4 + r,
          o = s.memory.buffer;
        if (e.length !== n) throw new Error(`Bad state length (expected ${n} bytes, got ${e.length})`);
        if (!function (e, t) {
          if (e.length !== t.length) return !1;
          for (let r = 0; r < e.length; r++) if (e[r] !== t[r]) return !1;
          return !0;
        }(a, e.subarray(0, 4))) throw new Error("This state was written by an incompatible hash implementation");
        const h = e.subarray(4);
        new Uint8Array(o, t, r).set(h), i = !0;
      },
      calculate: (e, t, n) => {
        if (!b(e, t)) return u(t), w(e), d("hex", n);
        const a = f(e);
        return h().set(a), s.Hash_Calculate(a.length, t, n), c(y, h(), r);
      },
      hashLength: r
    };
  },
  S = (e, t) => {
    const r = () => function () {
      var _ref4 = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (e, t) {
        return C(yield E(e), e, t);
      });
      return function (_x4, _x5) {
        return _ref4.apply(this, arguments);
      };
    }()(e, t);
    return Object.defineProperties(r, {
      wasm: {
        get() {
          const r = U.get(e);
          if (void 0 === r || r instanceof Promise) throw new Error(`wasm instance ${e} is not yet ready.`);
          return C(r, e, t);
        }
      },
      prepare: {
        value: function () {
          var _ref5 = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
            yield E(e);
          });
          return function value() {
            return _ref5.apply(this, arguments);
          };
        }()
      }
    }), r;
  };


/***/ }),

/***/ 76279:
/*!***************************************************************!*\
  !*** ./apps/wallet/src/assets/wallet-util/index-f943adc9.mjs ***!
  \***************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   entropyToMnemonic: () => (/* binding */ x),
/* harmony export */   generateMnemonic: () => (/* binding */ S),
/* harmony export */   mnemonicToEntropy: () => (/* binding */ E),
/* harmony export */   mnemonicToSeed: () => (/* binding */ j),
/* harmony export */   mnemonicToSeedSync: () => (/* binding */ y),
/* harmony export */   normalize: () => (/* binding */ l),
/* harmony export */   validateMnemonic: () => (/* binding */ b)
/* harmony export */ });
/* harmony import */ var D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 52542);
/* harmony import */ var _pbkdf2_96cac7bc_mjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./pbkdf2-96cac7bc.mjs */ 44615);
/* harmony import */ var _sha256_e58017d9_mjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./sha256-e58017d9.mjs */ 6612);
/* harmony import */ var _sha512_0b4c0803_mjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./sha512-0b4c0803.mjs */ 89918);
/* harmony import */ var _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./index-766bdb76.mjs */ 59809);
/* harmony import */ var _wordlists_b107198c_mjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./wordlists-b107198c.mjs */ 12091);
/* harmony import */ var _hmac_68b6dab4_mjs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./hmac-68b6dab4.mjs */ 84816);
/* harmony import */ var _WASMInterface_b9f2203b_mjs__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./WASMInterface-b9f2203b.mjs */ 43670);








const f = r => (0,_sha256_e58017d9_mjs__WEBPACK_IMPORTED_MODULE_2__.c)().update(r).digest(),
  u = "Invalid mnemonic",
  c = "Invalid entropy",
  m = "Invalid mnemonic checksum",
  h = "A wordlist is required but a default could not be found.\nPlease pass a 2048 word array explicitly.";
function l(r) {
  return (r || "").normalize("NFKD");
}
function p(r) {
  return parseInt(r, 2);
}
function w(r) {
  let t = "";
  for (let n = 0; n < r.length; n++) {
    t += r[n].toString(2).padStart(8, "0");
  }
  return t;
}
function d(r) {
  const t = 8 * r.length / 32;
  return w(f(r)).slice(0, t);
}
function g(r) {
  return "mnemonic" + (r || "");
}
function y(t, n) {
  return ((t, n, e, s, a) => {
    const f = (0,_pbkdf2_96cac7bc_mjs__WEBPACK_IMPORTED_MODULE_1__.p)({
      hashFunction: (0,_sha512_0b4c0803_mjs__WEBPACK_IMPORTED_MODULE_3__.c)(),
      password: t,
      salt: n,
      iterations: e,
      hashLength: s,
      outputType: "binary"
    });
    return _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_4__.B.from(f);
  })(_index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_4__.B.from(l(t), "utf8"), _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_4__.B.from(g(l(n)), "utf8"), 2048, 64);
}
function j(r, n) {
  return function () {
    var _ref = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (r, n, o, s, a) {
      const f = yield (0,_pbkdf2_96cac7bc_mjs__WEBPACK_IMPORTED_MODULE_1__.a)({
        hashFunction: (0,_sha512_0b4c0803_mjs__WEBPACK_IMPORTED_MODULE_3__.a)(),
        password: r,
        salt: n,
        iterations: o,
        hashLength: s,
        outputType: "binary"
      });
      return _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_4__.B.from(f);
    });
    return function (_x, _x2, _x3, _x4, _x5) {
      return _ref.apply(this, arguments);
    };
  }()(_index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_4__.B.from(l(r), "utf8"), _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_4__.B.from(g(l(n)), "utf8"), 2048, 64);
}
function E(r, t) {
  var _a;
  if (!(t = t || ((_a = (0,_wordlists_b107198c_mjs__WEBPACK_IMPORTED_MODULE_5__.getDefaultWordlist)()) === null || _a === void 0 ? void 0 : _a.wordlist))) throw new Error(h);
  const n = l(r).split(" ");
  if (n.length % 3 != 0) throw new Error(u);
  const o = n.map(r => {
      const n = t.indexOf(r);
      if (-1 === n) throw new Error(u);
      return n.toString(2).padStart(11, "0");
    }).join(""),
    e = 32 * Math.floor(o.length / 33),
    s = o.slice(0, e),
    f = o.slice(e),
    w = s.match(/(.{1,8})/g).map(p);
  if (w.length < 16) throw new Error(c);
  if (w.length % 4 != 0) throw new Error(c);
  const g = _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_4__.B.from(w);
  if (d(g) !== f) throw new Error(m);
  return g.toString("hex");
}
function x(r, t) {
  var _a2;
  if (_index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_4__.B.isBuffer(r) || (r = _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_4__.B.from(r, "hex")), !(t = t || ((_a2 = (0,_wordlists_b107198c_mjs__WEBPACK_IMPORTED_MODULE_5__.getDefaultWordlist)()) === null || _a2 === void 0 ? void 0 : _a2.wordlist))) throw new Error(h);
  if (r.length < 16) throw new TypeError(c);
  if (r.length % 4 != 0) throw new TypeError(c);
  const n = (w(Array.from(r)) + d(r)).match(/(.{1,11})/g).map(r => {
    const n = p(r);
    return t[n];
  });
  return "あいこくしん" === t[0] ? n.join("　") : n.join(" ");
}
function S(r, t = _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_4__.r, n) {
  if ((r = r || 128) % 32 != 0) throw new TypeError(c);
  return x(_index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_4__.B.from(t(r / 8)), n);
}
function b(r, t) {
  try {
    E(r, t);
  } catch (r) {
    return !1;
  }
  return !0;
}


/***/ }),

/***/ 6612:
/*!****************************************************************!*\
  !*** ./apps/wallet/src/assets/wallet-util/sha256-e58017d9.mjs ***!
  \****************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   a: () => (/* binding */ e),
/* harmony export */   c: () => (/* binding */ i),
/* harmony export */   p: () => (/* binding */ s),
/* harmony export */   s: () => (/* binding */ t)
/* harmony export */ });
/* harmony import */ var D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 52542);
/* harmony import */ var _WASMInterface_b9f2203b_mjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./WASMInterface-b9f2203b.mjs */ 43670);


const s = (0,_WASMInterface_b9f2203b_mjs__WEBPACK_IMPORTED_MODULE_1__.c)("sha256", 32),
  t = /*#__PURE__*/function () {
    var _ref = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (a) {
      return (yield s()).calculate(a, 256);
    });
    return function t(_x) {
      return _ref.apply(this, arguments);
    };
  }(),
  e = /*#__PURE__*/function () {
    var _ref2 = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      return i(yield s());
    });
    return function e() {
      return _ref2.apply(this, arguments);
    };
  }(),
  i = (a = s.wasm) => {
    a.init(256);
    const t = {
      init: () => (a.init(256), t),
      update: s => (a.update(s), t),
      digest: s => a.digest(s),
      save: () => a.save(),
      load: s => (a.load(s), t),
      blockSize: 64,
      digestSize: 32
    };
    return t;
  };


/***/ })

}]);
//# sourceMappingURL=apps_wallet_src_assets_wallet-util_index-f943adc9_mjs.js.map