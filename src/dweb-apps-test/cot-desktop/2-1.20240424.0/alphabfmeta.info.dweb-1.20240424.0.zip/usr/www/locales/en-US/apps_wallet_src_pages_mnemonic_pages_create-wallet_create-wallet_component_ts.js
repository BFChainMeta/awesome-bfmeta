"use strict";
(self["webpackChunkwallet"] = self["webpackChunkwallet"] || []).push([["apps_wallet_src_pages_mnemonic_pages_create-wallet_create-wallet_component_ts"],{

/***/ 39460:
/*!***************************************************************************************!*\
  !*** ./apps/wallet/src/pages/mnemonic/pages/create-wallet/create-wallet.component.ts ***!
  \***************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   CreateWalletPage: () => (/* binding */ CreateWalletPage),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 52542);
/* harmony import */ var D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncIterator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/esm/asyncIterator.js */ 9243);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! tslib */ 90505);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/core */ 61039);
/* harmony import */ var _bnqkl_framework_animations__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @bnqkl/framework/animations */ 43127);
/* harmony import */ var _bnqkl_framework_helpers__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @bnqkl/framework/helpers */ 12169);
/* harmony import */ var _bnqkl_framework_plugins_toast__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @bnqkl/framework/plugins/toast */ 18030);
/* harmony import */ var _bnqkl_util_web_extends_promise__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @bnqkl/util-web/extends-promise */ 87778);
/* harmony import */ var _bnqkl_wallet_base_services_wallet__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @bnqkl/wallet-base/services/wallet */ 20609);
/* harmony import */ var _modules_page_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ~modules/page.module */ 77538);
/* harmony import */ var _libs_bnf_components_ripple_button_ripple_button_directive__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../../../../../libs/bnf/components/ripple-button/ripple-button.directive */ 16505);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/common */ 6729);
/* harmony import */ var _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../../../../../../libs/bnf/modules/page/common-page/common-page.component */ 62052);
/* harmony import */ var _libs_bnf_components_loading_wrapper_loading_wrapper_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../../../../../../libs/bnf/components/loading-wrapper/loading-wrapper.component */ 51263);


var _class;













function CreateWalletPage_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "div", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵi18n"](1, 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("@fadeInUp", undefined);
  }
}
function CreateWalletPage_Conditional_5_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r5 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "button", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵlistener"]("click", function CreateWalletPage_Conditional_5_Conditional_2_Template_button_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵrestoreView"](_r5);
      const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵresetView"](ctx_r4.goBackup());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵi18n"](1, 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
  }
}
function CreateWalletPage_Conditional_5_Template(rf, ctx) {
  if (rf & 1) {
    const _r7 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "button", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵlistener"]("click", function CreateWalletPage_Conditional_5_Template_button_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵrestoreView"](_r7);
      const ctx_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵresetView"](ctx_r6.nextStep());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](2, CreateWalletPage_Conditional_5_Conditional_2_Template, 2, 0, "button", 8);
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate1"](" ", ctx_r1.nextBtcText, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵconditional"](2, ctx_r1.showBackupBtn ? 2 : -1);
  }
}
function CreateWalletPage_Conditional_6_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](0, "bn-loading-wrapper", 11);
  }
  if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("loadingTheme", "ellipsis")("showLoading", !ctx_r2.done);
  }
}
const _c4 = a0 => ({
  "_create-wallet-steps-run": a0
});
/** 成功页面 */
class CreateWalletPage extends _modules_page_module__WEBPACK_IMPORTED_MODULE_7__.CommonPageBase {
  constructor() {
    super(...arguments);
    /** 设置的密码 */
    this.pwd = '';
    /** 传进来的助剂词 */
    this.mnemonic = '';
    /** 是否开启指纹 */
    this.fingerprint = false;
    /** 新增钱包 */
    this.addWallet = false;
    /** 传进来的返回路由 */
    this.backUrl = '';
    /** 传进来的导入类型 */
    this.importType = '';
    /** 传进来的链 */
    this.chainName = '';
    /** 要删除的身份钱包ID */
    this.deleteMainWalletId = '';
    /** 传进来的助剂词长度 */
    this.mnemonicLength = NaN;
    /** 传进来的助剂词语言 */
    this.mnemonicLanguage = '';
    /** 传进来的路径 */
    this.path = 44;
    /** 传进来的助剂词 */
    this.showBackupBtn = true;
    /** 显示成功文字 */
    this.showSuccessText = false;
    /** 创建成功 */
    this.done = false;
    this.showImg = false;
    this.mainWalletId = '';
  }
  init() {
    var _this = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      yield (0,_bnqkl_util_web_extends_promise__WEBPACK_IMPORTED_MODULE_5__.sleep)(1780);
      _this.createWallte();
      _this.showSuccessText = true;
    })();
  }
  show() {
    var _this2 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      /// 预加载动效图，不然太大了, 动效图太小又会有锯齿。。。
      const cImg = new Image();
      cImg.src = './assets/images/create-new-wallet-steps.png';
      cImg.onload = /*#__PURE__*/(0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
        yield (0,_bnqkl_util_web_extends_promise__WEBPACK_IMPORTED_MODULE_5__.sleep)(188);
        _this2.showImg = true;
      });
    })();
  }
  /** 创建钱包 */
  createWallte() {
    var _this3 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const walletDataStorageV2Service = _this3.injectorForceGet(_bnqkl_wallet_base_services_wallet__WEBPACK_IMPORTED_MODULE_6__.WalletDataStorageV2Service);
      const bip39LibService = _this3.injectorForceGet(_bnqkl_wallet_base_services_wallet__WEBPACK_IMPORTED_MODULE_6__.Bip39LibService);
      const walletV2Service = _this3.injectorForceGet(_bnqkl_wallet_base_services_wallet__WEBPACK_IMPORTED_MODULE_6__.WalletV2Service);
      if ((0,_bnqkl_framework_helpers__WEBPACK_IMPORTED_MODULE_3__.$isNoEmptyString)(_this3.mnemonic) === false) {
        _this3.mnemonic = (yield bip39LibService.createMnemonic(_this3.mnemonicLength || 12, _this3.mnemonicLanguage || 'english')).mnemonic;
      }
      /// 从这里进入的 说明只有这个钱包数据，确保不出现数据移除，先清除下存储数据
      if (_this3.addWallet == false) {
        try {
          yield walletDataStorageV2Service.clearAll();
        } catch (err) {
          _this3.console.log(err);
        }
      }
      const {
        defaultWallet,
        mainWalletId
      } = yield walletV2Service.createMainWallet({
        /** 助记词 */
        importPhrase: _this3.mnemonic,
        chainName: _this3.chainName,
        importType: _this3.importType || _bnqkl_wallet_base_services_wallet__WEBPACK_IMPORTED_MODULE_6__.WALLET_IMPORT_TYPE.mnemonic,
        path: _this3.path || 44
      }, {
        skipBackup: _this3.showBackupBtn
      });
      _this3.defaultWallet = defaultWallet;
      if (_this3.addWallet === false) {
        walletDataStorageV2Service.walletAppSettings.fingerprintLock = _this3.fingerprint;
        if (_this3.fingerprint) {
          walletDataStorageV2Service.walletAppSettings.passwordLock = true;
        }
        walletDataStorageV2Service.walletAppSettings.lastWalletActivate = defaultWallet;
        walletDataStorageV2Service.walletAppSettings.password = _this3.pwd;
      }
      _this3.mainWalletId = mainWalletId;
      if ((0,_bnqkl_framework_helpers__WEBPACK_IMPORTED_MODULE_3__.$isNoEmptyString)(_this3.deleteMainWalletId)) {
        const mainWallet = yield walletDataStorageV2Service.getMainWalletInfo(_this3.deleteMainWalletId);
        if (mainWallet) {
          var _walletDataStorageV2S;
          /// 删除该钱包
          yield walletDataStorageV2Service.removeMainWalletInfo(_this3.deleteMainWalletId);
          /// 删除对应地址
          var _iteratorAbruptCompletion = false;
          var _didIteratorError = false;
          var _iteratorError;
          try {
            for (var _iterator = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncIterator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(mainWallet.addressKeyList), _step; _iteratorAbruptCompletion = !(_step = yield _iterator.next()).done; _iteratorAbruptCompletion = false) {
              const info = _step.value;
              {
                const oldAddressInfo = yield walletDataStorageV2Service.getChainAddressInfo(info.addressKey);
                if (oldAddressInfo) {
                  oldAddressInfo.mainWalletId === _this3.deleteMainWalletId && (yield walletDataStorageV2Service.deleteChainAddressInfo(info.addressKey));
                }
              }
            }
            /// 如果是当前地址，要调整
          } catch (err) {
            _didIteratorError = true;
            _iteratorError = err;
          } finally {
            try {
              if (_iteratorAbruptCompletion && _iterator.return != null) {
                yield _iterator.return();
              }
            } finally {
              if (_didIteratorError) {
                throw _iteratorError;
              }
            }
          }
          if (((_walletDataStorageV2S = walletDataStorageV2Service.walletAppSettings.lastWalletActivate) === null || _walletDataStorageV2S === void 0 ? void 0 : _walletDataStorageV2S.mainWalletId) === _this3.deleteMainWalletId) {
            const allMainWalletList = yield walletDataStorageV2Service.getAllMainWalletInfo();
            const defaultMainWallet = allMainWalletList[0];
            const activate = defaultMainWallet.addressKeyList[0];
            const addressInfo = yield walletDataStorageV2Service.getChainAddressInfo(activate.addressKey);
            walletDataStorageV2Service.walletAppSettings.lastWalletActivate = addressInfo;
            yield walletV2Service.upDateActivateAddressWallet(addressInfo);
            yield (0,_bnqkl_util_web_extends_promise__WEBPACK_IMPORTED_MODULE_5__.sleep)(100);
          }
        }
      }
      yield (0,_bnqkl_util_web_extends_promise__WEBPACK_IMPORTED_MODULE_5__.sleep)(380);
      _this3.done = true;
    })();
  }
  /** 下一步按钮显示文本 */
  get nextBtcText() {
    return "Enter wallet";
  }
  /** 后续操作进入主页 */
  nextStep() {
    const walletDataStorageV2Service = this.injectorForceGet(_bnqkl_wallet_base_services_wallet__WEBPACK_IMPORTED_MODULE_6__.WalletDataStorageV2Service);
    if (this.addWallet) {
      walletDataStorageV2Service.walletAppSettings.lastWalletActivate = this.defaultWallet;
      this.nav.routeBack('tabs');
    } else {
      this.nav.setPageRoot('tabs');
    }
  }
  /** 备份助剂词 */
  goBackup() {
    try {
      /// 返回根页面
      this.nav.routeTo('/mnemonic/mnemonic-backup-tips', {
        importType: _bnqkl_wallet_base_services_wallet__WEBPACK_IMPORTED_MODULE_6__.WALLET_IMPORT_TYPE.mnemonic,
        mnemonic: this.mnemonic,
        mainWalletId: this.mainWalletId,
        backUrl: this.backUrl || '',
        backup: true
      });
    } catch (error) {
      _bnqkl_framework_plugins_toast__WEBPACK_IMPORTED_MODULE_4__.Toast.show(error instanceof Error ? error.message : String(error));
    }
  }
}
_class = CreateWalletPage;
_class.ɵfac = /*@__PURE__*/(() => {
  let ɵCreateWalletPage_BaseFactory;
  return function CreateWalletPage_Factory(t) {
    return (ɵCreateWalletPage_BaseFactory || (ɵCreateWalletPage_BaseFactory = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵgetInheritedFactory"](_class)))(t || _class);
  };
})();
_class.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdefineComponent"]({
  type: _class,
  selectors: [["w-create-wallet-page"]],
  inputs: {
    pwd: "pwd",
    mnemonic: "mnemonic",
    fingerprint: ["fingerprint", "fingerprint", _angular_core__WEBPACK_IMPORTED_MODULE_11__.booleanAttribute],
    addWallet: ["addWallet", "addWallet", _angular_core__WEBPACK_IMPORTED_MODULE_11__.booleanAttribute],
    backUrl: "backUrl",
    importType: "importType",
    chainName: "chainName",
    deleteMainWalletId: "deleteMainWalletId",
    mnemonicLength: ["mnemonicLength", "mnemonicLength", _angular_core__WEBPACK_IMPORTED_MODULE_11__.numberAttribute],
    mnemonicLanguage: "mnemonicLanguage",
    path: ["path", "path", value => {
      // eslint-disable-next-line @angular-eslint/no-input-rename
      if (value === undefined || value === 'undefined') {
        // eslint-disable-next-line @angular-eslint/no-input-rename
        return 44;
      }
      // eslint-disable-next-line @angular-eslint/no-input-rename
      const v = isNaN(+value) ? 44 : +value;
      // eslint-disable-next-line @angular-eslint/no-input-rename
      return [44, 86, 84, 49].includes(v) ? v : 44;
    }],
    showBackupBtn: ["showBackupBtn", "showBackupBtn", value => {
      if (value === undefined) {
        return !value;
      }
      try {
        return !!JSON.parse(value);
      } catch {
        value = undefined;
        return !value;
      }
    }]
  },
  standalone: true,
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵInputTransformsFeature"], _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵInheritDefinitionFeature"], _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵStandaloneFeature"]],
  decls: 7,
  vars: 9,
  consts: () => {
    let i18n_0;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_CONGRATULATIONS_YOU_HAVE_SUCCESSFULLY_CREATED_A_NEW_WALLET$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_CREATE_WALLET_CREATE_WALLET_COMPONENT_TS__1 = goog.getMsg(" Congratulations you have successfully created a new wallet ");
      i18n_0 = MSG_EXTERNAL_CONGRATULATIONS_YOU_HAVE_SUCCESSFULLY_CREATED_A_NEW_WALLET$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_CREATE_WALLET_CREATE_WALLET_COMPONENT_TS__1;
    } else {
      i18n_0 = " Congratulations you have successfully created a new wallet ";
    }
    let i18n_2;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_BACKUP_MNEMONIC$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_CREATE_WALLET_CREATE_WALLET_COMPONENT_TS___3 = goog.getMsg(" Backup mnenonic ");
      i18n_2 = MSG_EXTERNAL_BACKUP_MNEMONIC$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_CREATE_WALLET_CREATE_WALLET_COMPONENT_TS___3;
    } else {
      i18n_2 = " Backup mnenonic ";
    }
    return [[3, "contentBackground", "headerBackground", "headerTranslucent", "contentSafeArea"], [1, "flex", "min-h-full", "flex-col", "items-center", "justify-start", "text-center"], [1, "_create-wallet-steps", "mb-6", 3, "ngClass"], ["class", "text-title text-base"], ["footer", ""], [1, "text-title", "text-base"], i18n_0, ["bnRippleButton", "", 1, "h-10.5", "from-purple-gradient-start", "to-purple-gradient-end", "mb-4", "w-full", "rounded-full", "bg-gradient-to-b", "text-center", "text-sm", "text-white", 3, "click"], ["bnRippleButton", "", "class", "h-10.5 text-title border-tiny border-primary w-full rounded-full text-center text-sm"], ["bnRippleButton", "", 1, "h-10.5", "text-title", "border-tiny", "border-primary", "w-full", "rounded-full", "text-center", "text-sm", 3, "click"], i18n_2, [1, "text-primary", 3, "loadingTheme", "showLoading"]];
  },
  template: function CreateWalletPage_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "common-page", 0)(1, "div", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](2, "div", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](3, CreateWalletPage_Conditional_3_Template, 2, 1, "div", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](4, "div", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](5, CreateWalletPage_Conditional_5_Template, 3, 2)(6, CreateWalletPage_Conditional_6_Template, 1, 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()();
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("contentBackground", "grey")("headerBackground", "grey")("headerTranslucent", false)("contentSafeArea", true);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpureFunction1"](7, _c4, ctx.showImg));
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵconditional"](3, ctx.showSuccessText ? 3 : -1);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵconditional"](5, ctx.showSuccessText && ctx.done ? 5 : 6);
    }
  },
  dependencies: [_modules_page_module__WEBPACK_IMPORTED_MODULE_7__.CommonPageModule, _libs_bnf_components_ripple_button_ripple_button_directive__WEBPACK_IMPORTED_MODULE_8__.RippleButtonDirective, _angular_common__WEBPACK_IMPORTED_MODULE_12__.NgClass, _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_9__.CommonPageComponent, _libs_bnf_components_loading_wrapper_loading_wrapper_component__WEBPACK_IMPORTED_MODULE_10__.LoadingWrapperComponent],
  styles: ["[_nghost-%COMP%]   ._create-wallet-steps[_ngcontent-%COMP%] {\n  width: 243px;\n  height: 160px;\n  background-image: url('create-new-wallet-steps.png');\n  background-size: 11178px 160px;\n  animation-fill-mode: forwards;\n  background-repeat: no-repeat;\n}\n[_nghost-%COMP%]   ._create-wallet-steps-run[_ngcontent-%COMP%] {\n  animation: _ngcontent-%COMP%_play 1.5s steps(45) 1;\n}\n@keyframes _ngcontent-%COMP%_play {\n  from {\n    background-position-x: 0px;\n  }\n  to {\n    background-position-x: -10935px;\n  }\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL2FwcHMvd2FsbGV0L3NyYy9wYWdlcy9tbmVtb25pYy9wYWdlcy9jcmVhdGUtd2FsbGV0L2NyZWF0ZS13YWxsZXQuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQ0U7RUFDRSxZQUFBO0VBQ0EsYUFBQTtFQUNBLG9EQUFBO0VBQ0EsOEJBQUE7RUFFQSw2QkFBQTtFQUNBLDRCQUFBO0FBREo7QUFHRTtFQUNFLGdDQUFBO0FBREo7QUFHRTtFQUNFO0lBQ0UsMEJBQUE7RUFESjtFQUdFO0lBQ0UsK0JBQUE7RUFESjtBQUNGIiwic291cmNlc0NvbnRlbnQiOlsiOmhvc3Qge1xyXG4gIC5fY3JlYXRlLXdhbGxldC1zdGVwcyB7XHJcbiAgICB3aWR0aDogMjQzcHg7XHJcbiAgICBoZWlnaHQ6IDE2MHB4O1xyXG4gICAgYmFja2dyb3VuZC1pbWFnZTogdXJsKCcuL2Fzc2V0cy9pbWFnZXMvY3JlYXRlLW5ldy13YWxsZXQtc3RlcHMucG5nJyk7XHJcbiAgICBiYWNrZ3JvdW5kLXNpemU6IGNhbGMoMjQzcHggKiA0NikgMTYwcHg7XHJcblxyXG4gICAgYW5pbWF0aW9uLWZpbGwtbW9kZTogZm9yd2FyZHM7XHJcbiAgICBiYWNrZ3JvdW5kLXJlcGVhdDogbm8tcmVwZWF0O1xyXG4gIH1cclxuICAuX2NyZWF0ZS13YWxsZXQtc3RlcHMtcnVuIHtcclxuICAgIGFuaW1hdGlvbjogcGxheSAxLjVzIHN0ZXBzKDQ1KSAxO1xyXG4gIH1cclxuICBAa2V5ZnJhbWVzIHBsYXkge1xyXG4gICAgZnJvbSB7XHJcbiAgICAgIGJhY2tncm91bmQtcG9zaXRpb24teDogMHB4O1xyXG4gICAgfVxyXG4gICAgdG8ge1xyXG4gICAgICBiYWNrZ3JvdW5kLXBvc2l0aW9uLXg6IGNhbGMoLTI0M3B4ICogNDUpO1xyXG4gICAgfVxyXG4gIH1cclxufVxyXG4iXSwic291cmNlUm9vdCI6IiJ9 */"],
  data: {
    animation: [_bnqkl_framework_animations__WEBPACK_IMPORTED_MODULE_2__.fadeInUpTrigger]
  },
  changeDetection: 0
});
(0,tslib__WEBPACK_IMPORTED_MODULE_13__.__decorate)([CreateWalletPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_13__.__metadata)("design:type", Object)], CreateWalletPage.prototype, "showSuccessText", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_13__.__decorate)([CreateWalletPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_13__.__metadata)("design:type", Object)], CreateWalletPage.prototype, "done", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_13__.__decorate)([CreateWalletPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_13__.__metadata)("design:type", Object)], CreateWalletPage.prototype, "showImg", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_13__.__decorate)([CreateWalletPage.OnInit(), (0,tslib__WEBPACK_IMPORTED_MODULE_13__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_13__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_13__.__metadata)("design:returntype", Promise)], CreateWalletPage.prototype, "init", null);
(0,tslib__WEBPACK_IMPORTED_MODULE_13__.__decorate)([CreateWalletPage.OnReady(), (0,tslib__WEBPACK_IMPORTED_MODULE_13__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_13__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_13__.__metadata)("design:returntype", Promise)], CreateWalletPage.prototype, "show", null);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CreateWalletPage);

/***/ })

}]);
//# sourceMappingURL=apps_wallet_src_pages_mnemonic_pages_create-wallet_create-wallet_component_ts.js.map