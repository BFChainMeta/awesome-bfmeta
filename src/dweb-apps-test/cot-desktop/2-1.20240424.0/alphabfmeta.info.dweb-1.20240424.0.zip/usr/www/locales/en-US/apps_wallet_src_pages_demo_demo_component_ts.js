"use strict";
(self["webpackChunkwallet"] = self["webpackChunkwallet"] || []).push([["apps_wallet_src_pages_demo_demo_component_ts"],{

/***/ 83602:
/*!******************************************************!*\
  !*** ./apps/wallet/src/pages/demo/demo.component.ts ***!
  \******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   DemoPage: () => (/* binding */ DemoPage),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 52542);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! tslib */ 90505);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @angular/forms */ 7820);
/* harmony import */ var _bnqkl_framework_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @bnqkl/framework/components */ 24182);
/* harmony import */ var _bnqkl_framework_controllers__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @bnqkl/framework/controllers */ 47919);
/* harmony import */ var _bnqkl_util_web_extends_promise__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @bnqkl/util-web/extends-promise */ 87778);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! rxjs */ 47973);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! rxjs */ 41720);
/* harmony import */ var _modules_page_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ~modules/page.module */ 77538);
/* harmony import */ var _pages_to_to_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./pages/to/to.component */ 86977);
/* harmony import */ var _pipes_yellow_yellow_pipe__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./pipes/yellow/yellow.pipe */ 53578);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @angular/core */ 61039);
/* harmony import */ var _libs_bnf_components_ripple_button_ripple_button_directive__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../../../libs/bnf/components/ripple-button/ripple-button.directive */ 16505);
/* harmony import */ var _libs_bnf_components_pull_to_refresh_pull_to_refresh_directive__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../../../libs/bnf/components/pull-to-refresh/pull-to-refresh.directive */ 97063);
/* harmony import */ var _libs_bnf_components_pull_to_refresh_pull_to_refresh_spinner_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../../../../libs/bnf/components/pull-to-refresh/pull-to-refresh-spinner.component */ 75387);
/* harmony import */ var _libs_bnf_components_infinite_scroll_infinite_scroll_spinner_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../../../../libs/bnf/components/infinite-scroll/infinite-scroll-spinner.component */ 66560);
/* harmony import */ var _libs_bnf_directives_auto_complete_off_directive__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../../../../libs/bnf/directives/auto-complete-off.directive */ 66722);
/* harmony import */ var _libs_bnf_components_infinite_scroll_infinite_scroll_directive__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../../../../libs/bnf/components/infinite-scroll/infinite-scroll.directive */ 10320);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! @angular/common */ 6729);
/* harmony import */ var _angular_material_button__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! @angular/material/button */ 12300);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! @angular/router */ 56776);
/* harmony import */ var _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../../../../../libs/bnf/modules/page/common-page/common-page.component */ 62052);
/* harmony import */ var _libs_bnf_components_loading_wrapper_loading_wrapper_component__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../../../../../libs/bnf/components/loading-wrapper/loading-wrapper.component */ 51263);
/* harmony import */ var _pipes_color_color_pipe__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ../../pipes/color/color.pipe */ 76489);

var _class;























function DemoPage_option_15_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](0, "option", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const theme_r7 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵproperty"]("value", theme_r7);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtextInterpolate"](theme_r7);
  }
}
function DemoPage_option_20_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](0, "option", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const animation_r8 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵproperty"]("value", animation_r8);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtextInterpolate"](animation_r8);
  }
}
function DemoPage_li_26_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](0, "li", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const item_r9 = ctx.$implicit;
    const index_r10 = ctx.index;
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtextInterpolate2"](" ", index_r10, ": ", item_r9.value, " ");
  }
}
function DemoPage_ng_container_31_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](1, "h2");
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtext"](2, "ResolveData:");
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](3, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const data_r11 = ctx.ngIf;
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtextInterpolate1"]("AGE: ", data_r11.people.age, "");
  }
}
function DemoPage_ng_container_64_ul_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](0, "ul")(1, "li")(2, "span", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](4, "span", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtext"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const asset_r14 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtextInterpolate1"]("", asset_r14.type, ":");
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtextInterpolate"](asset_r14.balance);
  }
}
function DemoPage_ng_container_64_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtemplate"](1, DemoPage_ng_container_64_ul_1_Template, 6, 2, "ul", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const assets_r12 = ctx.ngIf;
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵproperty"]("ngForOf", assets_r12);
  }
}
function DemoPage_ng_template_66_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](0, "p", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtext"](1, "loading assets...");
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
  }
}
const _c0 = () => ["to"];
/** 测试数据 */
const assetList = [{
  type: 'ethereum',
  balance: 56.66
}, {
  type: 'tron',
  balance: 45.12
}, {
  type: 'binance',
  balance: 82.12
}];
assetList.push(...assetList, ...assetList, ...assetList);
assetList.push(...assetList, ...assetList, ...assetList);
/**
 * 测试页面
 *
 * 这里可以看到bfm这个项目说搭建的框架说带来的常用的配置
 */
class DemoPage extends _modules_page_module__WEBPACK_IMPORTED_MODULE_4__.CommonPageBase {
  constructor() {
    super(...arguments);
    /** 测试表单 */
    this.form = new _angular_forms__WEBPACK_IMPORTED_MODULE_17__.FormGroup({
      field1: new _angular_forms__WEBPACK_IMPORTED_MODULE_17__.FormControl('')
    });
    /**
     * toPage 的返回值获取控制器
     */
    this.toPageReturnController = new _bnqkl_framework_controllers__WEBPACK_IMPORTED_MODULE_2__.PageReturnController(this, _pages_to_to_component__WEBPACK_IMPORTED_MODULE_5__.ToPage);
    /**
     * 测试 Rxjs 绑定
     */
    this.assets$ = (0,rxjs__WEBPACK_IMPORTED_MODULE_18__.interval)(1000).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_19__.map)(i => {
      this.console.log(i);
      return assetList.map(asset => ({
        ...asset,
        balance: asset.balance + i
      }));
    }));
    /**
     * 测试延迟加载的列表
     */
    this.lazyList = [...this._getLazyList(), ...this._getLazyList()];
    /** 是否显示加载器包裹组件 */
    this.showLoading = false;
    /** 加载器的风格 */
    this.loadingTheme = 'spinner';
    /** 加载器的所有风格 */
    this.loadingThemes = _bnqkl_framework_components__WEBPACK_IMPORTED_MODULE_1__.LOADING_THEMES;
    /** 加载器的动画 */
    this.loadingAnimation = 'content-zoom-out';
    /** 加载器的所有动画 */
    this.loadingAnimations = _bnqkl_framework_components__WEBPACK_IMPORTED_MODULE_1__.LOADING_ANIMATIONS;
  }
  /** 打块对话框 */
  openDiaog() {
    this.alert({
      headerTitle: '你好世界',
      bodyMessage: '嘻嘻',
      buttonText: '你好'
    });
  }
  setLang() {
    var _this = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const {
        controller
      } = navigator.serviceWorker;
      if (controller === null) {
        _this.console.log('开发模式下不可以动态修改语言');
      } else {
        if ((yield swc.request('set-lang', 'zh-Hans')) === 'zh-Hans') {
          _this.console.log('ook!');
        }
      }
    })();
  }
  /**
   * 打印 toPage.returnValue$ 输出的结果
   */
  watchToPageReturn() {
    this.toPageReturnController.pageReturn$.subscribe(data => {
      this.console.log('to return:', data);
    });
  }
  /**
   * 测试表单绑定
   */
  testForm() {
    setInterval(() => {
      this.form.setValue({
        field1: Math.random().toString()
      });
    }, 500);
  }
  /** 获取虚拟列表数据 */
  _getLazyList() {
    return Array.from({
      length: 10
    }, () => {
      return {
        value: Math.random()
      };
    });
  }
  /** 加载更多虚拟数据 */
  loadMore() {
    var _this2 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      if (_this2.hasMore()) {
        yield (0,_bnqkl_util_web_extends_promise__WEBPACK_IMPORTED_MODULE_3__.sleep)(1000);
        _this2.lazyList.push(..._this2._getLazyList());
      }
    })();
  }
  /** 是否到达测试边界 */
  hasMore() {
    return this.lazyList.length < 100;
  }
}
_class = DemoPage;
_class.ɵfac = /*@__PURE__*/(() => {
  let ɵDemoPage_BaseFactory;
  return function DemoPage_Factory(t) {
    return (ɵDemoPage_BaseFactory || (ɵDemoPage_BaseFactory = _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵgetInheritedFactory"](_class)))(t || _class);
  };
})();
_class.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵdefineComponent"]({
  type: _class,
  selectors: [["w-demo-page"]],
  standalone: true,
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵInheritDefinitionFeature"], _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵStandaloneFeature"]],
  decls: 68,
  vars: 32,
  consts: [[3, "headerBackground", "headerOpacity", "contentSafeArea"], [1, "bg-env", "m-4", "rounded-md", "p-4"], ["bnRippleButton", "", 3, "rippleColor"], ["bnRippleButton", "", 1, "bg-primary", "rounded-lg", "px-8", "py-2", "text-white", 3, "click"], [3, "showLoading", "loadingTheme", "loadingAnimation"], ["name", "loading-theme", 3, "ngModel", "ngModelChange"], [3, "value", 4, "ngFor", "ngForOf"], ["name", "loading-animation", 3, "ngModel", "ngModelChange"], ["wInfiniteScroll", "", 1, "h-50", "overflow-auto", 3, "hasMore", "infinited$"], ["class", "border-b-tiny h-5 border-solid", 4, "ngFor", "ngForOf"], [1, "text-sm"], [4, "ngIf"], ["mat-raised-button", "", 3, "click"], ["mat-button", "", 3, "routerLink"], [1, "bg-env", "m-4", "rounded-md", "p-4", 3, "formGroup"], ["type", "text", "formControlName", "field1"], [1, "text-subtext"], ["wPullToRefresh", "", 1, "bg-env", "m-4", "rounded-md", "p-4", 3, "pulled$"], [4, "ngIf", "ngIfElse"], ["loadingAssets", ""], [3, "value"], [1, "border-b-tiny", "h-5", "border-solid"], [4, "ngFor", "ngForOf"], [1, "pr-2", "font-semibold"], [1, "tabular-nums"]],
  template: function DemoPage_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](0, "common-page", 0)(1, "div", 1)(2, "button", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipe"](3, "color");
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtext"](4, "w-button");
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](5, "div", 1)(6, "h2");
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtext"](7, "\u52A0\u8F7D\u5668\u5305\u88F9\u7EC4\u4EF6");
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](8, "button", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵlistener"]("click", function DemoPage_Template_button_click_8_listener() {
        return ctx.showLoading = !ctx.showLoading;
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](9, "bn-loading-wrapper", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtext"](10, " \u70B9\u51FB\u6211 ");
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](11, "div")(12, "label");
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtext"](13, "\u98CE\u683C");
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](14, "select", 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵlistener"]("ngModelChange", function DemoPage_Template_select_ngModelChange_14_listener($event) {
        return ctx.loadingTheme = $event;
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtemplate"](15, DemoPage_option_15_Template, 2, 2, "option", 6);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](16, "div")(17, "label");
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtext"](18, "\u52A8\u753B");
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](19, "select", 7);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵlistener"]("ngModelChange", function DemoPage_Template_select_ngModelChange_19_listener($event) {
        return ctx.loadingAnimation = $event;
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtemplate"](20, DemoPage_option_20_Template, 2, 2, "option", 6);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]()()();
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](21, "div", 1)(22, "h2");
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtext"](23, "\u5EF6\u8FDF\u52A0\u8F7D\u5217\u8868");
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](24, "div", 8);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵlistener"]("infinited$", function DemoPage_Template_div_infinited__24_listener($event) {
        return $event.waitFor(ctx.loadMore());
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](25, "ul");
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtemplate"](26, DemoPage_li_26_Template, 2, 2, "li", 9);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](27, "bn-infinite-scroll-spinner")(28, "span", 10);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtext"](29, "\u52A0\u8F7D\u4E2D");
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]()()()();
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](30, "div", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtemplate"](31, DemoPage_ng_container_31_Template, 5, 1, "ng-container", 11);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipe"](32, "async");
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](33, "div", 1)(34, "h2");
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtext"](35, "Dialog");
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](36, "div")(37, "button", 12);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵlistener"]("click", function DemoPage_Template_button_click_37_listener() {
        return ctx.openDiaog();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtext"](38, "\u6253\u5F00\u5F39\u7A97");
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]()()();
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](39, "div", 1)(40, "h2");
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtext"](41, "Return Valuee");
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](42, "div")(43, "button", 13);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtext"](44, "go to page");
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](45, "div");
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtext"](46);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipe"](47, "async");
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]()()();
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](48, "div", 1)(49, "h2");
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtext"](50, "Pipe");
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](51, "div");
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtext"](52);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipe"](53, "yellow");
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](54, "form", 14)(55, "h2");
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtext"](56, "FormGroup");
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelement"](57, "input", 15);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](58, "div", 16);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtext"](59);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](60, "div", 17);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵlistener"]("pulled$", function DemoPage_Template_div_pulled__60_listener($event) {
        return $event.loaded();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelement"](61, "bn-pull-to-refresh-spinner");
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](62, "h2");
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtext"](63, "PageData:");
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtemplate"](64, DemoPage_ng_container_64_Template, 2, 1, "ng-container", 18);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipe"](65, "async");
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtemplate"](66, DemoPage_ng_template_66_Template, 2, 0, "ng-template", null, 19, _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtemplateRefExtractor"]);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]()();
    }
    if (rf & 2) {
      const _r6 = _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵreference"](67);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵproperty"]("headerBackground", "primary")("headerOpacity", 0.3)("contentSafeArea", true);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵproperty"]("rippleColor", _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipeBind1"](3, 21, "primary"));
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](7);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵproperty"]("showLoading", ctx.showLoading)("loadingTheme", ctx.loadingTheme)("loadingAnimation", ctx.loadingAnimation);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](5);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵproperty"]("ngModel", ctx.loadingTheme);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵproperty"]("ngForOf", ctx.loadingThemes);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](4);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵproperty"]("ngModel", ctx.loadingAnimation);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵproperty"]("ngForOf", ctx.loadingAnimations);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](4);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵproperty"]("hasMore", ctx.hasMore());
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵproperty"]("ngForOf", ctx.lazyList);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](5);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵproperty"]("ngIf", _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipeBind1"](32, 23, ctx.resolveData$));
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](12);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵproperty"]("routerLink", _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpureFunction0"](31, _c0));
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtextInterpolate1"]("return value:", _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipeBind1"](47, 25, ctx.toPageReturnController.pageReturn$), "");
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](6);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipeBind1"](53, 27, "\u4F60\u597D"));
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵproperty"]("formGroup", ctx.form);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](5);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtextInterpolate"](ctx.form.value.field1);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](5);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵproperty"]("ngIf", _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipeBind1"](65, 29, ctx.assets$))("ngIfElse", _r6);
    }
  },
  dependencies: [_modules_page_module__WEBPACK_IMPORTED_MODULE_4__.CommonPageModule, _libs_bnf_components_ripple_button_ripple_button_directive__WEBPACK_IMPORTED_MODULE_7__.RippleButtonDirective, _libs_bnf_components_pull_to_refresh_pull_to_refresh_directive__WEBPACK_IMPORTED_MODULE_8__.PullToRefreshDirective, _libs_bnf_components_pull_to_refresh_pull_to_refresh_spinner_component__WEBPACK_IMPORTED_MODULE_9__.PullToRefreshSpinnerComponent, _libs_bnf_components_infinite_scroll_infinite_scroll_spinner_component__WEBPACK_IMPORTED_MODULE_10__.InfiniteScrollSpinnerComponent, _libs_bnf_directives_auto_complete_off_directive__WEBPACK_IMPORTED_MODULE_11__.AutoCompleteOffDirective, _libs_bnf_components_infinite_scroll_infinite_scroll_directive__WEBPACK_IMPORTED_MODULE_12__.InfiniteScrollDirective, _angular_common__WEBPACK_IMPORTED_MODULE_20__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_20__.NgIf, _angular_forms__WEBPACK_IMPORTED_MODULE_17__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_17__.NgSelectOption, _angular_forms__WEBPACK_IMPORTED_MODULE_17__["ɵNgSelectMultipleOption"], _angular_forms__WEBPACK_IMPORTED_MODULE_17__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_17__.SelectControlValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_17__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_17__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_17__.NgModel, _angular_forms__WEBPACK_IMPORTED_MODULE_17__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_17__.FormControlName, _angular_material_button__WEBPACK_IMPORTED_MODULE_21__.MatButton, _angular_router__WEBPACK_IMPORTED_MODULE_22__.RouterLink, _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_13__.CommonPageComponent, _libs_bnf_components_loading_wrapper_loading_wrapper_component__WEBPACK_IMPORTED_MODULE_14__.LoadingWrapperComponent, _angular_common__WEBPACK_IMPORTED_MODULE_20__.AsyncPipe, _pipes_color_color_pipe__WEBPACK_IMPORTED_MODULE_15__.ColorPipe, _pipes_yellow_yellow_pipe__WEBPACK_IMPORTED_MODULE_6__.YellowPipe],
  styles: ["/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsInNvdXJjZVJvb3QiOiIifQ== */"],
  changeDetection: 0
});
(0,tslib__WEBPACK_IMPORTED_MODULE_23__.__decorate)([DemoPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_23__.__metadata)("design:type", Object)], DemoPage.prototype, "form", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_23__.__decorate)([DemoPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_23__.__metadata)("design:type", Object)], DemoPage.prototype, "toPageReturnController", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_23__.__decorate)([DemoPage.OnInit(), (0,tslib__WEBPACK_IMPORTED_MODULE_23__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_23__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_23__.__metadata)("design:returntype", void 0)], DemoPage.prototype, "watchToPageReturn", null);
(0,tslib__WEBPACK_IMPORTED_MODULE_23__.__decorate)([DemoPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_23__.__metadata)("design:type", Object)], DemoPage.prototype, "assets$", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_23__.__decorate)([DemoPage.OnInit(), (0,tslib__WEBPACK_IMPORTED_MODULE_23__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_23__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_23__.__metadata)("design:returntype", void 0)], DemoPage.prototype, "testForm", null);
(0,tslib__WEBPACK_IMPORTED_MODULE_23__.__decorate)([DemoPage.States(1), (0,tslib__WEBPACK_IMPORTED_MODULE_23__.__metadata)("design:type", Object)], DemoPage.prototype, "lazyList", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_23__.__decorate)([DemoPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_23__.__metadata)("design:type", Object)], DemoPage.prototype, "showLoading", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_23__.__decorate)([DemoPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_23__.__metadata)("design:type", String)], DemoPage.prototype, "loadingTheme", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_23__.__decorate)([DemoPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_23__.__metadata)("design:type", String)], DemoPage.prototype, "loadingAnimation", void 0);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (DemoPage);

/***/ }),

/***/ 53578:
/*!****************************************************************!*\
  !*** ./apps/wallet/src/pages/demo/pipes/yellow/yellow.pipe.ts ***!
  \****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   YellowPipe: () => (/* binding */ YellowPipe)
/* harmony export */ });
/* harmony import */ var _modules_pipe_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ~modules/pipe.module */ 99936);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 61039);
var _class;


/**
 * A Pipe Just For Demo
 */
class YellowPipe extends _modules_pipe_module__WEBPACK_IMPORTED_MODULE_0__.CommonPipeBase {
  /** 转换 */
  transform(value, ...args) {
    this.console.log('value', args);
    return value;
  }
}
_class = YellowPipe;
_class.ɵfac = /*@__PURE__*/(() => {
  let ɵYellowPipe_BaseFactory;
  return function YellowPipe_Factory(t) {
    return (ɵYellowPipe_BaseFactory || (ɵYellowPipe_BaseFactory = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵgetInheritedFactory"](_class)))(t || _class);
  };
})();
_class.ɵpipe = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefinePipe"]({
  name: "yellow",
  type: _class,
  pure: true,
  standalone: true
});

/***/ }),

/***/ 11606:
/*!************************************************************!*\
  !*** ./libs/bnf/controllers/form-validators.controller.ts ***!
  \************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   FormValidatorsController: () => (/* binding */ FormValidatorsController)
/* harmony export */ });
/* harmony import */ var _bnqkl_framework_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @bnqkl/framework/core */ 63563);
/* harmony import */ var _bnqkl_util_web_extends_map__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @bnqkl/util-web/extends-map */ 37689);


/**
 * 页面表单扩展验证器
 *
 * > 因为涉及到FromControl的生命周期管理，所以这里需要使用Controller模式来获取组件/页面的生命周期
 *
 * 为了确保类型安全, 请遵循以下规则去定义验证器:
 * 1. 尽可能直接提供 $ValidatorFn,比如 `trimRequired(control: AbstractControl): $ValidationErrors | null {...}`
 * 2. 如果不能直接提供 $ValidatorFn, 那么作为工厂模式,必然要有参数传入,比如 `equals(leaderCtrl: AbstractControl): $ValidatorFn {...}`
 */
class FormValidatorsController {
  /**
   * 通过订阅原页面的生命周期，来对订阅的字段进行监听解除
   */
  constructor(comp) {
    /**
     * 判断两个数据字段相等的时，left===right 中 left的数据订阅
     */
    this._equalsLeaderMap = _bnqkl_util_web_extends_map__WEBPACK_IMPORTED_MODULE_1__.EasyMap.from({
      creater(ctrl) {
        const sub = {
          sub$: ctrl.valueChanges.subscribe(() => {
            for (const ctrl of sub.destControls) {
              ctrl.updateValueAndValidity();
            }
          }),
          destControls: new Set()
        };
        return sub;
      }
    });
    (0,_bnqkl_framework_core__WEBPACK_IMPORTED_MODULE_0__.addLifecycleMethods)(comp, 'ngOnDestroy', {
      origin: 'form-validator',
      method: () => {
        for (const {
          sub$
        } of this._equalsLeaderMap.values()) {
          sub$.unsubscribe();
        }
        this._equalsLeaderMap.clear();
      },
      order: Number.MAX_SAFE_INTEGER /* 最后才做这些事情 */
    });
  }
  /** 两个字段对比 相等就过 不相等返回 {equals:true} */
  equals(leaderCtrl) {
    const leader = this._equalsLeaderMap.forceGet(leaderCtrl);
    // pwdCtrl.val
    return follerCtrl => {
      leader.destControls.add(follerCtrl);
      if (leaderCtrl.value === follerCtrl.value) {
        return null;
      }
      return {
        equals: true
      };
    };
  }
  /** 是否包含空格 */
  whitespace(control) {
    const value = control.value;
    if (typeof value === 'string' && /\s/.test(value)) {
      return {
        whitespace: true
      };
    }
    return null;
  }
  /** required 变体, 左右两边不能包含空格 */
  trimRequired(control) {
    const value = control.value;
    if (typeof value === 'string' && value.trim().length === 0 || value == undefined) {
      return {
        trimRequired: true
      };
    }
    return null;
  }
}

/***/ }),

/***/ 47919:
/*!***************************************!*\
  !*** ./libs/bnf/controllers/index.ts ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   FormValidatorsController: () => (/* reexport safe */ _form_validators_controller__WEBPACK_IMPORTED_MODULE_0__.FormValidatorsController),
/* harmony export */   PageReturnController: () => (/* reexport safe */ _page_return_controller__WEBPACK_IMPORTED_MODULE_1__.PageReturnController)
/* harmony export */ });
/* harmony import */ var _form_validators_controller__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./form-validators.controller */ 11606);
/* harmony import */ var _page_return_controller__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./page-return.controller */ 62893);



/***/ }),

/***/ 62893:
/*!********************************************************!*\
  !*** ./libs/bnf/controllers/page-return.controller.ts ***!
  \********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   PageReturnController: () => (/* binding */ PageReturnController)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 54106);
/* harmony import */ var _bnqkl_util_web_decorator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @bnqkl/util-web/decorator */ 18112);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs */ 19177);



/**
 * 页面数据返回值的订阅功能
 * > Controller 必须在构造函数期间执行
 */
class PageReturnController {
  /** 继承日志 */
  get console() {
    return this.fromPage.console;
  }
  /**
   * 传入源页面与目标页面的构造函数，并通过订阅原页面的生命周期，来初始化对路由的订阅
   * 这里依赖 ion-router-outlet 来获取跳转过去的页面
   * 注：该监听返回是全触发（只要页面没被销毁掉不管页面是否处于激活状态）
   * @param specific 用于指定fromPage触发（需要手动指定），业务需要
   */
  constructor(fromPage, toPageCtor, specific = false) {
    this.fromPage = fromPage;
    /** 当前定阅过的页面 */
    this._toPages = new WeakSet();
    /**
     * 订阅到的返回内容，
     * 类型由对应页面的 returnValue$ 的定义决定
     */
    this.pageReturn$ = new rxjs__WEBPACK_IMPORTED_MODULE_1__.Subject();
    const {
      nav
    } = fromPage;
    fromPage.takeUntilDestroy(nav.pageActiveState$).subscribe(event => {
      /// 只监听新激活的页面
      if (event.type !== 'activate') {
        return;
      }
      const toPage = event.target;
      if (toPage instanceof toPageCtor &&
      // 去重
      this._toPages.has(toPage) === false) {
        if (toPage.returnValue$ === undefined) {
          return;
        }
        this._toPages.add(toPage);
        if (specific) {
          var _toPage$specificRetur;
          (_toPage$specificRetur = toPage.specificReturnPages) === null || _toPage$specificRetur === void 0 || _toPage$specificRetur.add(fromPage);
        }
        fromPage.takeUntilDestroy(toPage.returnValue$).subscribe({
          next: data => {
            /// 这里不用判断specific
            if (toPage.specificReturnPages && toPage.specificReturnPages.size) {
              /// 如果有写入，那么就只需要触发相对应页面就行
              toPage.specificReturnPages.has(fromPage) && this.pageReturn$.next(data);
              return;
            }
            this.pageReturn$.next(data);
          },
          complete: () => {
            var _toPage$specificRetur2;
            // 释放内存引用
            (_toPage$specificRetur2 = toPage.specificReturnPages) === null || _toPage$specificRetur2 === void 0 || _toPage$specificRetur2.delete(fromPage);
            return this._toPages.delete(toPage);
          }
        });
      }
    });
  }
}
(0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([_bnqkl_util_web_decorator__WEBPACK_IMPORTED_MODULE_0__.cacheGetter, (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__metadata)("design:type", Object), (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__metadata)("design:paramtypes", [])], PageReturnController.prototype, "console", null);

/***/ }),

/***/ 47973:
/*!**************************************************************************************************!*\
  !*** ./node_modules/.pnpm/rxjs@7.8.1/node_modules/rxjs/dist/esm/internal/observable/interval.js ***!
  \**************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   interval: () => (/* binding */ interval)
/* harmony export */ });
/* harmony import */ var _scheduler_async__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../scheduler/async */ 43617);
/* harmony import */ var _timer__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./timer */ 91317);


function interval(period = 0, scheduler = _scheduler_async__WEBPACK_IMPORTED_MODULE_0__.asyncScheduler) {
  if (period < 0) {
    period = 0;
  }
  return (0,_timer__WEBPACK_IMPORTED_MODULE_1__.timer)(period, period, scheduler);
}

/***/ })

}]);
//# sourceMappingURL=apps_wallet_src_pages_demo_demo_component_ts.js.map