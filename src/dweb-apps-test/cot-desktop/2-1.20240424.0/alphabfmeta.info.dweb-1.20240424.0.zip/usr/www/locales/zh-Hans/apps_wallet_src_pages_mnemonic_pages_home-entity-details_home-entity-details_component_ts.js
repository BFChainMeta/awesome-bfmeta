"use strict";
(self["webpackChunkwallet"] = self["webpackChunkwallet"] || []).push([["apps_wallet_src_pages_mnemonic_pages_home-entity-details_home-entity-details_component_ts"],{

/***/ 6596:
/*!************************************************!*\
  !*** ./apps/wallet/src/helpers/utils/index.ts ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   isMobile: () => (/* binding */ isMobile)
/* harmony export */ });
/* harmony import */ var _plaoc_is_dweb__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @plaoc/is-dweb */ 69899);
/* harmony import */ var _environments_index__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ~environments/index */ 40014);


/** 判断是否是移动端 */
const isMobile = () => {
  if (_environments_index__WEBPACK_IMPORTED_MODULE_1__.environment.DWEB_APP) {
    return (0,_plaoc_is_dweb__WEBPACK_IMPORTED_MODULE_0__.isMobile)();
  } else {
    return true;
  }
};

/***/ }),

/***/ 79849:
/*!***************************************************************************************************!*\
  !*** ./apps/wallet/src/pages/mnemonic/pages/home-entity-details/home-entity-details.component.ts ***!
  \***************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   HomeEntityDetailsPage: () => (/* binding */ HomeEntityDetailsPage),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 52542);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! tslib */ 90505);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @angular/core */ 61039);
/* harmony import */ var _bnqkl_framework_plugins__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @bnqkl/framework/plugins */ 43990);
/* harmony import */ var _bnqkl_util_web_extends_promise__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @bnqkl/util-web/extends-promise */ 87778);
/* harmony import */ var _bnqkl_wallet_base_services__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @bnqkl/wallet-base/services */ 62479);
/* harmony import */ var _plaoc_is_dweb__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @plaoc/is-dweb */ 69899);
/* harmony import */ var _plaoc_plugins__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @plaoc/plugins */ 14680);
/* harmony import */ var _helpers_utils__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ~helpers/utils */ 6596);
/* harmony import */ var _modules_page_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ~modules/page.module */ 77538);
/* harmony import */ var _libs_bnf_components_ripple_button_ripple_button_directive__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../../../../../libs/bnf/components/ripple-button/ripple-button.directive */ 16505);
/* harmony import */ var _libs_bnf_directives_click_to_copy_directive__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../../../../../../libs/bnf/directives/click-to-copy.directive */ 46413);
/* harmony import */ var _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../../../../../../libs/bnf/modules/page/common-page/common-page.component */ 62052);
/* harmony import */ var _components_icon_icon_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../../../components/icon/icon.component */ 74703);
/* harmony import */ var _libs_bnf_components_loading_wrapper_loading_wrapper_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../../../../../../libs/bnf/components/loading-wrapper/loading-wrapper.component */ 51263);
/* harmony import */ var _libs_bnf_pipes_day_format_day_format_pipe__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../../../../../../../libs/bnf/pipes/day-format/day-format.pipe */ 24562);
/* harmony import */ var _libs_bnf_pipes_address_hidden_address_hidden_pipe__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../../../../../../../libs/bnf/pipes/address-hidden/address-hidden.pipe */ 35222);

var _class;

















function HomeEntityDetailsPage_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r3 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](0, "div", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelement"](1, "img", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](2, "div", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](4, "div", 7)(5, "div", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵi18n"](6, 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](7, "div", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](8);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](9, "div", 7)(10, "div", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵi18n"](11, 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](12, "div", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](13);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](14, "div", 7)(15, "div", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵi18n"](16, 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](17, "div", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](18);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](19, "div", 7)(20, "div", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵi18n"](21, 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](22, "div", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](23);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](24, "div", 14)(25, "div", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵi18n"](26, 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](27, "div", 16)(28, "span", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](29);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](30, "button", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelement"](31, "w-icon", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelement"](32, "div", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](33, "div", 7)(34, "div", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵi18n"](35, 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](36, "div", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](37);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipe"](38, "addressHidden");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](39, "div", 7)(40, "div", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵi18n"](41, 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](42, "div", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](43);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipe"](44, "dayFormat");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](45, "div", 7)(46, "div", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵi18n"](47, 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](48, "div", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](49);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipe"](50, "addressHidden");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](51, "div", 14)(52, "div", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵi18n"](53, 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](54, "div", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](55);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipe"](56, "dayFormat");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelement"](57, "div", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](58, "div", 7)(59, "div", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵi18n"](60, 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](61, "div", 26);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("click", function HomeEntityDetailsPage_Conditional_1_Template_div_click_61_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵrestoreView"](_r3);
      const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵresetView"](ctx_r2.goScanDetail());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵi18nStart"](62, 27);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelement"](63, "img", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵi18nEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("src", ctx_r0.dpInfo.pic, _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵsanitizeUrl"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtextInterpolate"](ctx_r0.dpInfo.dpName);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtextInterpolate1"](" ", ctx_r0.dpInfo.dpName, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtextInterpolate1"](" ", ctx_r0.dpInfo.collectionName, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtextInterpolate1"](" ", ctx_r0.showDpType, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtextInterpolate1"](" ", ctx_r0.chain, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtextInterpolate1"](" ", ctx_r0.dpInfo.entityId || ctx_r0.entityId, "");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("wClickToCopy", ctx_r0.dpInfo.entityId || ctx_r0.entityId);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](7);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipeBind1"](38, 12, ctx_r0.dpInfo.creator), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipeBind1"](44, 14, ctx_r0.dpInfo.issueAt), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipeBind1"](50, 16, ctx_r0.dpInfo.owner), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipeBind1"](56, 18, ctx_r0.dpInfo.ownAt), " ");
  }
}
function HomeEntityDetailsPage_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelement"](0, "bn-loading-wrapper", 29);
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("loadingTheme", "spinner")("showLoading", true);
  }
}
class HomeEntityDetailsPage extends _modules_page_module__WEBPACK_IMPORTED_MODULE_7__.CommonPageBase {
  constructor() {
    super(...arguments);
    /** 链服务 */
    this._chainService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_15__.inject)(_bnqkl_wallet_base_services__WEBPACK_IMPORTED_MODULE_3__.ChainV2Service);
    /** dp服务 */
    this._dpSerivce = (0,_angular_core__WEBPACK_IMPORTED_MODULE_15__.inject)(_bnqkl_wallet_base_services__WEBPACK_IMPORTED_MODULE_3__.WalletDpService);
    /** 资产信息 */
    this.dpInfo = {
      collectionName: '',
      creator: '',
      dpName: '',
      dpType: 0,
      issueAt: '',
      network: '',
      ownAt: '',
      owner: '',
      pic: '',
      entityId: this.entityId,
      signature: ''
    };
  }
  get showDpType() {
    return this.dpInfo.dpType === _bnqkl_wallet_base_services__WEBPACK_IMPORTED_MODULE_3__.DpType.homogenization ? "\u9650\u91CF\u7248DP" : "\u975E\u9650\u91CF\u7248DP";
  }
  get tip() {
    return (0,_helpers_utils__WEBPACK_IMPORTED_MODULE_6__.isMobile)() ? "\u524D\u5F80 CosmicDP \u4EA4\u6613" : "\u8BF7\u524D\u5F80 CosmicDP \u8FDB\u884C\u4EA4\u6613";
  }
  pageInit() {
    var _this = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      try {
        const info = yield _this._dpSerivce.getDpDetail(_this.entityId, _this.chain);
        yield (0,_bnqkl_util_web_extends_promise__WEBPACK_IMPORTED_MODULE_2__.sleep)(350);
        _this.dpInfo = info;
      } catch (err) {
        yield (0,_bnqkl_util_web_extends_promise__WEBPACK_IMPORTED_MODULE_2__.sleep)(2000);
        _bnqkl_framework_plugins__WEBPACK_IMPORTED_MODULE_1__.Toast.show(String(err));
        _this.nav.back();
      }
    })();
  }
  /** 跳转app */
  goToCosmicDp() {
    var _this2 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      /// 判断是否存在
      if (_this2.environment.DWEB_APP) {
        /** 注入plaoc服务 */
        const plaoc = _this2.injectorForceGet(_bnqkl_wallet_base_services__WEBPACK_IMPORTED_MODULE_3__.PlaocService);
        const cosmicDpId = `${_this2.environment.production ? '' : 'alpha'}cosmicdp.com.dweb`;
        const canOpen = yield plaoc.canOpenUrl(cosmicDpId);
        if (canOpen.success === false) {
          /// 没安装，跳转下载
          const url = new URL(_this2.environment.production ? 'https://source.dwebdapp.com/dweb-browser-apps/dweb-apps/applist.json' : 'https://source.dwebdapp.com/dweb-browser-apps/dweb-apps-test/applist.json');
          url.searchParams.append('time', String(Date.now()));
          const result = yield fetch(url.toString()).then(res => res.json()).catch(err => {
            _this2.console.log('获取applist', err);
            return;
          });
          if (result) {
            const baseUrl = result.base_config.base_url + result.base_config.app_path;
            const walletName = 'CosmicDP'.toLowerCase();
            const targetPath = result.applist[walletName][`dwebTarget${(0,_plaoc_is_dweb__WEBPACK_IMPORTED_MODULE_4__.dwebTarget)()}`];
            const downloadUrl = `${baseUrl}/${walletName}/${targetPath}/metadata.json`;
            _plaoc_plugins__WEBPACK_IMPORTED_MODULE_5__.updateControllerPlugin.download(downloadUrl);
          } else {
            _bnqkl_framework_plugins__WEBPACK_IMPORTED_MODULE_1__.Browser.open({
              url: _this2.environment.production ? 'https://dwebdapp.com' : 'https://test.dwebdapp.com'
            });
          }
          return;
        }
        /// 安装就直接打开
        const url = new URL('', document.baseURI);
        _plaoc_plugins__WEBPACK_IMPORTED_MODULE_5__.dwebServiceWorker.externalFetch(cosmicDpId, url);
        return;
      } else {
        _bnqkl_framework_plugins__WEBPACK_IMPORTED_MODULE_1__.Browser.open({
          url: _this2.environment.production ? 'https://dwebdapp.com' : 'https://test.dwebdapp.com'
        });
      }
    })();
  }
  /** 浏览器 */
  goScanDetail() {
    const chainInfo = this._chainService.getChainInfo(this.chain);
    _bnqkl_framework_plugins__WEBPACK_IMPORTED_MODULE_1__.Browser.open({
      url: `${chainInfo.scan}info/event?signature=${this.dpInfo.signature}&trsType=1`
    });
  }
}
_class = HomeEntityDetailsPage;
_class.ɵfac = /*@__PURE__*/(() => {
  let ɵHomeEntityDetailsPage_BaseFactory;
  return function HomeEntityDetailsPage_Factory(t) {
    return (ɵHomeEntityDetailsPage_BaseFactory || (ɵHomeEntityDetailsPage_BaseFactory = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵgetInheritedFactory"](_class)))(t || _class);
  };
})();
_class.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵdefineComponent"]({
  type: _class,
  selectors: [["w-home-entity-details-page"]],
  standalone: true,
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵInheritDefinitionFeature"], _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵStandaloneFeature"]],
  decls: 6,
  vars: 3,
  consts: () => {
    let i18n_0;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_DP_TRANSACTION_DETAILS$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_HOME_ENTITY_DETAILS_HOME_ENTITY_DETAILS_COMPONENT_TS_1 = goog.getMsg("DP Details");
      i18n_0 = MSG_EXTERNAL_DP_TRANSACTION_DETAILS$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_HOME_ENTITY_DETAILS_HOME_ENTITY_DETAILS_COMPONENT_TS_1;
    } else {
      i18n_0 = "DP\u8BE6\u60C5";
    }
    let i18n_2;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_DP_NAME$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_HOME_ENTITY_DETAILS_HOME_ENTITY_DETAILS_COMPONENT_TS__3 = goog.getMsg("DP Name");
      i18n_2 = MSG_EXTERNAL_DP_NAME$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_HOME_ENTITY_DETAILS_HOME_ENTITY_DETAILS_COMPONENT_TS__3;
    } else {
      i18n_2 = "DP\u540D\u79F0";
    }
    let i18n_4;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_BELONGING_ALBUM$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_HOME_ENTITY_DETAILS_HOME_ENTITY_DETAILS_COMPONENT_TS__5 = goog.getMsg("Belonging album");
      i18n_4 = MSG_EXTERNAL_BELONGING_ALBUM$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_HOME_ENTITY_DETAILS_HOME_ENTITY_DETAILS_COMPONENT_TS__5;
    } else {
      i18n_4 = "\u6240\u5C5E\u4E13\u8F91";
    }
    let i18n_6;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_DP_TYPE$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_HOME_ENTITY_DETAILS_HOME_ENTITY_DETAILS_COMPONENT_TS__7 = goog.getMsg("Type");
      i18n_6 = MSG_EXTERNAL_DP_TYPE$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_HOME_ENTITY_DETAILS_HOME_ENTITY_DETAILS_COMPONENT_TS__7;
    } else {
      i18n_6 = "\u7C7B\u578B";
    }
    let i18n_8;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_BELONGING_CHAIN$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_HOME_ENTITY_DETAILS_HOME_ENTITY_DETAILS_COMPONENT_TS__9 = goog.getMsg("Belonging chain");
      i18n_8 = MSG_EXTERNAL_BELONGING_CHAIN$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_HOME_ENTITY_DETAILS_HOME_ENTITY_DETAILS_COMPONENT_TS__9;
    } else {
      i18n_8 = "\u6240\u5C5E\u94FE";
    }
    let i18n_10;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_ASSET_ID$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_HOME_ENTITY_DETAILS_HOME_ENTITY_DETAILS_COMPONENT_TS__11 = goog.getMsg("Asset ID");
      i18n_10 = MSG_EXTERNAL_ASSET_ID$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_HOME_ENTITY_DETAILS_HOME_ENTITY_DETAILS_COMPONENT_TS__11;
    } else {
      i18n_10 = "\u8D44\u4EA7ID";
    }
    let i18n_12;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_CREATOR$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_HOME_ENTITY_DETAILS_HOME_ENTITY_DETAILS_COMPONENT_TS__13 = goog.getMsg("Creator");
      i18n_12 = MSG_EXTERNAL_CREATOR$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_HOME_ENTITY_DETAILS_HOME_ENTITY_DETAILS_COMPONENT_TS__13;
    } else {
      i18n_12 = "\u521B\u4F5C\u8005";
    }
    let i18n_14;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_RELEASE_TIME$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_HOME_ENTITY_DETAILS_HOME_ENTITY_DETAILS_COMPONENT_TS__15 = goog.getMsg("Release time");
      i18n_14 = MSG_EXTERNAL_RELEASE_TIME$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_HOME_ENTITY_DETAILS_HOME_ENTITY_DETAILS_COMPONENT_TS__15;
    } else {
      i18n_14 = "\u53D1\u884C\u65F6\u95F4";
    }
    let i18n_16;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_HOLDER$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_HOME_ENTITY_DETAILS_HOME_ENTITY_DETAILS_COMPONENT_TS__17 = goog.getMsg("Holder");
      i18n_16 = MSG_EXTERNAL_HOLDER$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_HOME_ENTITY_DETAILS_HOME_ENTITY_DETAILS_COMPONENT_TS__17;
    } else {
      i18n_16 = "\u6301\u6709\u8005";
    }
    let i18n_18;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_ACQUISITION_TIME$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_HOME_ENTITY_DETAILS_HOME_ENTITY_DETAILS_COMPONENT_TS__19 = goog.getMsg("Acquisition time");
      i18n_18 = MSG_EXTERNAL_ACQUISITION_TIME$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_HOME_ENTITY_DETAILS_HOME_ENTITY_DETAILS_COMPONENT_TS__19;
    } else {
      i18n_18 = "\u5165\u624B\u65F6\u95F4";
    }
    let i18n_20;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_TRANSACTION_HISTORY$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_HOME_ENTITY_DETAILS_HOME_ENTITY_DETAILS_COMPONENT_TS__21 = goog.getMsg("Transaction history");
      i18n_20 = MSG_EXTERNAL_TRANSACTION_HISTORY$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_HOME_ENTITY_DETAILS_HOME_ENTITY_DETAILS_COMPONENT_TS__21;
    } else {
      i18n_20 = "\u4EA4\u6613\u5386\u53F2";
    }
    let i18n_22;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_VIEW_IN_BROWSER$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_HOME_ENTITY_DETAILS_HOME_ENTITY_DETAILS_COMPONENT_TS__23 = goog.getMsg("{$tagImg} View in browser ", {
        "tagImg": "\uFFFD#63\uFFFD\uFFFD/#63\uFFFD"
      }, {
        original_code: {
          "tagImg": "<img class=\"rounded-full bg-primary w-4 h-4 p-[1px] mr-1\" src=\"./assets/images/deity-details-browser.svg\" alt=\"\" srcset=\"\">"
        }
      });
      i18n_22 = MSG_EXTERNAL_VIEW_IN_BROWSER$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_HOME_ENTITY_DETAILS_HOME_ENTITY_DETAILS_COMPONENT_TS__23;
    } else {
      i18n_22 = "" + "\uFFFD#63\uFFFD\uFFFD/#63\uFFFD" + " \u5728\u6D4F\u89C8\u5668\u4E2D\u67E5\u770B ";
    }
    return [["headerTitle", i18n_0, 3, "contentSafeArea"], ["class", "flex flex-col items-center justify-center"], ["footer", "", 1, "flex", "items-center", "justify-center"], ["bnRippleButton", "", 1, "text-primary", "mt-3", "text-center", "text-xs", 3, "click"], [1, "flex", "flex-col", "items-center", "justify-center"], ["alt", "", 1, "mt-4", "w-[58%]", "max-w-[13.75rem]", "border-tiny", "border-title", "rounded-5", 3, "src"], [1, "text-title", "text-base", "mt-3", "mb-7", "font-bold"], [1, "mb-6", "w-full", "flex", "justify-between", "items-center"], [1, "text-subtext", "shrink-0", "mr-4"], i18n_2, [1, "text-text", "overflow-hidden", "text-ellipsis", "whitespace-nowrap", "break-all"], i18n_4, i18n_6, i18n_8, [1, "mb-3", "w-full", "flex", "justify-between", "items-center"], i18n_10, [1, "text-text", "break-all", "max-w-[48%]"], [1, "text-primary"], ["bnRippleButton", "", 1, "ml-2", "inline-block", "relative", "top-[2px]", 3, "wClickToCopy"], ["name", "copy", 1, "icon-4", "leading-5", "text-primary"], [1, "mb-3", "w-full", "border-b-tiny", "border-line"], i18n_12, i18n_14, i18n_16, i18n_18, i18n_20, [1, "text-primary", "flex", "justify-end", "items-center", "overflow-hidden", "text-ellipsis", "whitespace-nowrap", "break-all", 3, "click"], i18n_22, ["src", "./assets/images/deity-details-browser.svg", "alt", "", "srcset", "", 1, "rounded-full", "bg-primary", "w-4", "h-4", "p-[1px]", "mr-1"], [1, "mt-10", "text-[48px]", "text-primary", 3, "loadingTheme", "showLoading"]];
  },
  template: function HomeEntityDetailsPage_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](0, "common-page", 0);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](1, HomeEntityDetailsPage_Conditional_1_Template, 64, 20, "div", 1)(2, HomeEntityDetailsPage_Conditional_2_Template, 1, 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](3, "div", 2)(4, "button", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("click", function HomeEntityDetailsPage_Template_button_click_4_listener() {
        return ctx.goToCosmicDp();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](5);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]()()();
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("contentSafeArea", true);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵconditional"](1, ctx.dpInfo.dpName ? 1 : 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](4);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtextInterpolate1"](" ", ctx.tip, " ");
    }
  },
  dependencies: [_modules_page_module__WEBPACK_IMPORTED_MODULE_7__.CommonPageModule, _libs_bnf_components_ripple_button_ripple_button_directive__WEBPACK_IMPORTED_MODULE_8__.RippleButtonDirective, _libs_bnf_directives_click_to_copy_directive__WEBPACK_IMPORTED_MODULE_9__.ClickToCopyDirective, _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_10__.CommonPageComponent, _components_icon_icon_component__WEBPACK_IMPORTED_MODULE_11__.IconComponent, _libs_bnf_components_loading_wrapper_loading_wrapper_component__WEBPACK_IMPORTED_MODULE_12__.LoadingWrapperComponent, _libs_bnf_pipes_day_format_day_format_pipe__WEBPACK_IMPORTED_MODULE_13__.DayFormatPipe, _libs_bnf_pipes_address_hidden_address_hidden_pipe__WEBPACK_IMPORTED_MODULE_14__.AddressHiddenPipe],
  styles: ["/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsInNvdXJjZVJvb3QiOiIifQ== */"],
  changeDetection: 0
});
(0,tslib__WEBPACK_IMPORTED_MODULE_16__.__decorate)([HomeEntityDetailsPage.QueryParam('chain'), (0,tslib__WEBPACK_IMPORTED_MODULE_16__.__metadata)("design:type", String)], HomeEntityDetailsPage.prototype, "chain", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_16__.__decorate)([HomeEntityDetailsPage.QueryParam('entityId'), (0,tslib__WEBPACK_IMPORTED_MODULE_16__.__metadata)("design:type", String)], HomeEntityDetailsPage.prototype, "entityId", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_16__.__decorate)([HomeEntityDetailsPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_16__.__metadata)("design:type", Object)], HomeEntityDetailsPage.prototype, "dpInfo", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_16__.__decorate)([HomeEntityDetailsPage.OnInit(), (0,tslib__WEBPACK_IMPORTED_MODULE_16__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_16__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_16__.__metadata)("design:returntype", Promise)], HomeEntityDetailsPage.prototype, "pageInit", null);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (HomeEntityDetailsPage);

/***/ }),

/***/ 69899:
/*!*****************************************************************************************!*\
  !*** ./node_modules/.pnpm/@plaoc+is-dweb@0.1.0/node_modules/@plaoc/is-dweb/esm/main.js ***!
  \*****************************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   dwebTarget: () => (/* binding */ dwebTarget),
/* harmony export */   isDweb: () => (/* binding */ isDweb),
/* harmony export */   isMobile: () => (/* binding */ isMobile)
/* harmony export */ });
/**
 * 判断是不是dweb
 * * @returns boolean
 */
const isDweb = () => {
  const isDweb = self.navigator.userAgent.includes("Dweb");
  // @ts-ignore
  const isPlaoc = self.__native_close_watcher_kit__ !== void 0;
  if (isDweb || isPlaoc) {
    return true;
  }
  const userAgentData = self.navigator.userAgentData;
  if (!userAgentData) {
    return false;
  }
  const brands = userAgentData.brands.filter(value => {
    return value.brand === "DwebBrowser";
  });
  return Array.isArray(brands) && brands.length > 0;
};
/**
 * 判断dweb大版本
 * @returns boolean
 */
const dwebTarget = () => {
  if (isDweb()) {
    const userAgentData = self.navigator.userAgentData;
    if (!userAgentData) {
      return 2.0;
    }
    const brands = userAgentData.brands.filter(value => {
      return value.brand === "jmm.browser.dweb";
    });
    if (Array.isArray(brands) && brands.length > 0) {
      return parseFloat(brands[0].version);
    }
  }
  return 1.0;
};
/**
 * 判断是否是移动端
 * @returns boolean
 */
const isMobile = () => {
  if (!navigator.userAgentData) {
    return true;
  }
  return !!navigator.userAgentData.mobile;
};

/***/ })

}]);
//# sourceMappingURL=apps_wallet_src_pages_mnemonic_pages_home-entity-details_home-entity-details_component_ts.js.map