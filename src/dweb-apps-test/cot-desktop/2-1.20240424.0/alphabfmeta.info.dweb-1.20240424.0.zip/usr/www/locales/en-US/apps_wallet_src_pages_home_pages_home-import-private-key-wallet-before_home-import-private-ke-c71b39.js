"use strict";
(self["webpackChunkwallet"] = self["webpackChunkwallet"] || []).push([["apps_wallet_src_pages_home_pages_home-import-private-key-wallet-before_home-import-private-ke-c71b39"],{

/***/ 27025:
/*!***********************************************************************************************************************************!*\
  !*** ./apps/wallet/src/pages/home/pages/home-import-private-key-wallet-before/home-import-private-key-wallet-before.component.ts ***!
  \***********************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   HomeImportPrivateKeyWalletBeforePage: () => (/* binding */ HomeImportPrivateKeyWalletBeforePage),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 52542);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! tslib */ 90505);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/core */ 61039);
/* harmony import */ var _modules_page_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ~modules/page.module */ 77538);
/* harmony import */ var _bnqkl_wallet_base_services_wallet__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @bnqkl/wallet-base/services/wallet */ 20609);
/* harmony import */ var _bnqkl_framework_animations__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @bnqkl/framework/animations */ 43127);
/* harmony import */ var _libs_bnf_modules_bottom_sheet_components_bottom_sheet_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../../../../../libs/bnf/modules/bottom-sheet/components/bottom-sheet.component */ 94072);
/* harmony import */ var _libs_bnf_components_ripple_button_ripple_button_directive__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../../../../../libs/bnf/components/ripple-button/ripple-button.directive */ 16505);
/* harmony import */ var _libs_bnf_directives_click_to_copy_directive__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../../../../../libs/bnf/directives/click-to-copy.directive */ 46413);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/common */ 6729);
/* harmony import */ var _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../../../../../libs/bnf/modules/page/common-page/common-page.component */ 62052);
/* harmony import */ var _components_icon_icon_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../../components/icon/icon.component */ 74703);

var _class;












function HomeImportPrivateKeyWalletBeforePage_li_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r5 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](0, "li")(1, "button", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵlistener"]("click", function HomeImportPrivateKeyWalletBeforePage_li_2_Template_button_click_1_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵrestoreView"](_r5);
      const item_r3 = restoredCtx.$implicit;
      const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵresetView"](ctx_r4.selectChain(item_r3));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](2, "w-icon", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](3, "div", 6)(4, "div", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtext"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](6, "div", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtext"](7);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](8, "w-icon", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const item_r3 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("name", item_r3.icon);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtextInterpolate"](item_r3.symbol);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtextInterpolate"](item_r3.chain);
  }
}
function HomeImportPrivateKeyWalletBeforePage_ng_template_4_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](0, "common-page", 10, 11)(2, "div", 12)(3, "div", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](5, "div", 14)(6, "button", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵi18n"](7, 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("headerTitle", ctx_r1.privateKeyBottomSheetInfo.title);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtextInterpolate1"](" ", ctx_r1.privateKeyBottomSheetInfo.privateKey, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("wClickToCopy", ctx_r1.privateKeyBottomSheetInfo.privateKey);
  }
}
function HomeImportPrivateKeyWalletBeforePage_ng_template_6_li_3_Template(rf, ctx) {
  if (rf & 1) {
    const _r11 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](0, "li")(1, "button", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵlistener"]("click", function HomeImportPrivateKeyWalletBeforePage_ng_template_6_li_3_Template_button_click_1_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵrestoreView"](_r11);
      const item_r9 = restoredCtx.$implicit;
      const ctx_r10 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵresetView"](ctx_r10.selectBitcoinAddressType(item_r9.path));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](2, "div", 19)(3, "div", 20)(4, "div", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵi18n"](5, 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]()()()()();
  }
  if (rf & 2) {
    const item_r9 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵi18nExp"](item_r9.type)(item_r9.path);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵi18nApply"](5);
  }
}
function HomeImportPrivateKeyWalletBeforePage_ng_template_6_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](0, "common-page", 10, 11)(2, "ul", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtemplate"](3, HomeImportPrivateKeyWalletBeforePage_ng_template_6_li_3_Template, 6, 2, "li", 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("headerTitle", "Select address type");
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("ngForOf", ctx_r2.bitcoinSelectAddressTypeBottomSheetInfo.list)("ngForTrackBy", ctx_r2.trackByKey("type"));
  }
}
class HomeImportPrivateKeyWalletBeforePage extends _modules_page_module__WEBPACK_IMPORTED_MODULE_1__.CommonPageBase {
  constructor() {
    super(...arguments);
    this.viewPrivateKey = false;
    this.mainWalletId = '';
    this.viewBioforestChain = false;
    /**
     * 临时数据
     */
    this.chainList = [];
    this.privateKeyBottomSheetInfo = {
      title: '',
      privateKey: '',
      open: false
    };
    this.bitcoinSelectAddressTypeBottomSheetInfo = {
      open: false,
      list: [{
        type: 'Native SegWit',
        path: 84
      }, {
        type: 'Nested SegWit',
        path: 49
      }, {
        type: 'Taproot',
        path: 86
      }, {
        type: 'Legacy',
        path: 44
      }]
    };
  }
  /** 初始化钱包支持的链列表 */
  initMenu() {
    var _this = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const chainV2Service = _this.injectorForceGet(_bnqkl_wallet_base_services_wallet__WEBPACK_IMPORTED_MODULE_2__.ChainV2Service);
      const list = [...chainV2Service.chainConfig_Map.values()].filter(item => !chainV2Service.isBioforestChainByChainName(item.chain)).sort((a, b) => a.chain > b.chain ? 1 : -1);
      if (_this.viewPrivateKey || _this.viewBioforestChain) {
        const walletDataStorageV2Service = _this.injectorForceGet(_bnqkl_wallet_base_services_wallet__WEBPACK_IMPORTED_MODULE_2__.WalletDataStorageV2Service);
        const mainWallet = yield walletDataStorageV2Service.getMainWalletInfo(_this.mainWalletId);
        if (mainWallet === undefined) {
          throw new Error(`not found main wallet:${_this.mainWalletId}`);
        }
        const chainName_Set = new Set();
        _this.chainList = mainWallet === null || mainWallet === void 0 ? void 0 : mainWallet.addressKeyList.filter(item => {
          if (_this.viewBioforestChain) {
            return chainV2Service.isBioforestChainByChainName(item.chainName);
          }
          return chainV2Service.isBioforestChainByChainName(item.chainName) === false;
        }).filter(item => {
          if (chainName_Set.has(item.chainName)) {
            return false;
          }
          chainName_Set.add(item.chainName);
          return true;
        }).map(item => {
          return {
            icon: `icon-${item.chainName}-${item.symbol.toLowerCase()}`,
            symbol: item.symbol,
            chain: item.chainName
          };
        });
      } else {
        _this.chainList = list.map(item => {
          return {
            icon: `icon-${item.chain}-${item.symbol.toLowerCase()}`,
            symbol: item.symbol,
            chain: item.chain
          };
        });
      }
    })();
  }
  selectChain(info) {
    var _this2 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      if (_this2.viewPrivateKey || _this2.viewBioforestChain) {
        const walletDataStorageV2Service = _this2.injectorForceGet(_bnqkl_wallet_base_services_wallet__WEBPACK_IMPORTED_MODULE_2__.WalletDataStorageV2Service);
        const mainWallet = yield walletDataStorageV2Service.getMainWalletInfo(_this2.mainWalletId);
        if (mainWallet === undefined) {
          throw new Error(`not found main wallet:${_this2.mainWalletId}`);
        }
        const addressKeyInfo = mainWallet.addressKeyList.find(item => item.chainName === info.chain);
        if (addressKeyInfo) {
          const addressInfo = yield walletDataStorageV2Service.getChainAddressInfo(addressKeyInfo.addressKey);
          if (_this2.viewPrivateKey) {
            if (info.chain !== _bnqkl_wallet_base_services_wallet__WEBPACK_IMPORTED_MODULE_2__.CHAIN_NAME.Bitcoin) {
              _this2.privateKeyBottomSheetInfo.title = "Private key (" + info.chain + ")";
              _this2.privateKeyBottomSheetInfo.privateKey = addressInfo.privateKey;
              _this2.privateKeyBottomSheetInfo.open = true;
            } else {
              _this2.nav.routeTo('/home-bitcoin-address-selection', {
                mainWalletId: _this2.mainWalletId,
                lookPrivateKey: true
              });
            }
          } else {
            _this2.nav.routeTo('/mnemonic/set-transaction-password', {
              address: addressInfo.address,
              addressKey: addressInfo.addressKey,
              chain: addressInfo.chain,
              symbol: addressInfo.symbol
            });
          }
        }
      } else {
        if (info.chain === _bnqkl_wallet_base_services_wallet__WEBPACK_IMPORTED_MODULE_2__.CHAIN_NAME.Bitcoin) {
          _this2.bitcoinSelectAddressTypeBottomSheetInfo.open = true;
          return;
        }
        _this2.nav.routeTo('home-import-private-key-wallet', {
          chainName: info.chain,
          symbol: info.symbol,
          path: 44
        }, true);
      }
    })();
  }
  selectBitcoinAddressType(path) {
    this.bitcoinSelectAddressTypeBottomSheetInfo.open = false;
    const chainV2Service = this.injectorForceGet(_bnqkl_wallet_base_services_wallet__WEBPACK_IMPORTED_MODULE_2__.ChainV2Service);
    const bitcoinInfo = chainV2Service.getChainInfo(_bnqkl_wallet_base_services_wallet__WEBPACK_IMPORTED_MODULE_2__.CHAIN_NAME.Bitcoin);
    this.nav.routeTo('home-import-private-key-wallet', {
      chainName: bitcoinInfo.chain,
      symbol: bitcoinInfo.symbol,
      path,
      lookPrivateKey: true
    }, true);
  }
}
_class = HomeImportPrivateKeyWalletBeforePage;
_class.ɵfac = /*@__PURE__*/(() => {
  let ɵHomeImportPrivateKeyWalletBeforePage_BaseFactory;
  return function HomeImportPrivateKeyWalletBeforePage_Factory(t) {
    return (ɵHomeImportPrivateKeyWalletBeforePage_BaseFactory || (ɵHomeImportPrivateKeyWalletBeforePage_BaseFactory = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵgetInheritedFactory"](_class)))(t || _class);
  };
})();
_class.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdefineComponent"]({
  type: _class,
  selectors: [["w-home-import-private-key-wallet-before-page"]],
  inputs: {
    viewPrivateKey: ["viewPrivateKey", "viewPrivateKey", _angular_core__WEBPACK_IMPORTED_MODULE_9__.booleanAttribute],
    mainWalletId: "mainWalletId",
    viewBioforestChain: ["viewBioforestChain", "viewBioforestChain", _angular_core__WEBPACK_IMPORTED_MODULE_9__.booleanAttribute]
  },
  standalone: true,
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵInputTransformsFeature"], _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵInheritDefinitionFeature"], _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵStandaloneFeature"]],
  decls: 7,
  vars: 9,
  consts: () => {
    let i18n_0;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_COPY_PRIVATE_KEY$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_IMPORT_PRIVATE_KEY_WALLET_BEFORE_HOME_IMPORT_PRIVATE_KEY_WALLET_BEFORE_COMPONENT_TS__1 = goog.getMsg(" Copy Private key ");
      i18n_0 = MSG_EXTERNAL_COPY_PRIVATE_KEY$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_IMPORT_PRIVATE_KEY_WALLET_BEFORE_HOME_IMPORT_PRIVATE_KEY_WALLET_BEFORE_COMPONENT_TS__1;
    } else {
      i18n_0 = " Copy Private key ";
    }
    let i18n_2;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_M_0_0$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_IMPORT_PRIVATE_KEY_WALLET_BEFORE_HOME_IMPORT_PRIVATE_KEY_WALLET_BEFORE_COMPONENT_TS___3 = goog.getMsg("{$interpolation}(m/{$interpolation_1}'/0'/0')", {
        "interpolation": "\uFFFD0\uFFFD",
        "interpolation_1": "\uFFFD1\uFFFD"
      }, {
        original_code: {
          "interpolation": "{{ item.type }}",
          "interpolation_1": "{{ item.path }}"
        }
      });
      i18n_2 = MSG_EXTERNAL_M_0_0$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_IMPORT_PRIVATE_KEY_WALLET_BEFORE_HOME_IMPORT_PRIVATE_KEY_WALLET_BEFORE_COMPONENT_TS___3;
    } else {
      i18n_2 = "" + "\uFFFD0\uFFFD" + "(m/" + "\uFFFD1\uFFFD" + "'/0'/0')";
    }
    return [[3, "titleColor", "headerBackground", "contentBackground", "contentSafeArea"], [1, "w-full", "bg-white"], [4, "ngFor", "ngForOf", "ngForTrackBy"], [3, "isOpen", "isOpenChange"], ["bnRippleButton", "", 1, "px-page-safe-area-inset", "flex", "w-full", "items-center", "py-4", 3, "click"], [1, "text-3xl", 3, "name"], [1, "ml-2"], [1, "text-xs", "font-semibold"], [1, "text-subtext", "text-xss"], ["name", "right", 1, "text-subtext", "ml-auto"], [3, "headerTitle"], ["page", ""], [1, "mb-28", "p-5"], [1, "rounded-3", "bg-env", "w-full", "break-words", "px-4", "py-7"], ["footer", ""], ["bnRippleButton", "", 1, "h-10.5", "from-purple-gradient-start", "to-purple-gradient-end", "w-full", "rounded-full", "bg-gradient-to-b", "text-center", "text-sm", "text-white", 3, "wClickToCopy"], i18n_0, [1, "w-full", "bg-white", "px-5"], ["bnRippleButton", "", 1, "border-b-tiny", "border-line", "flex", "w-full", "items-center", "justify-start", "px-2", "py-4", 3, "click"], [1, "flex", "items-center", "justify-start"], [1, "ml-2", "flex", "items-center", "justify-start"], [1, "font-bold"], i18n_2];
  },
  template: function HomeImportPrivateKeyWalletBeforePage_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](0, "common-page", 0)(1, "ul", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtemplate"](2, HomeImportPrivateKeyWalletBeforePage_li_2_Template, 9, 3, "li", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](3, "common-bottom-sheet", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵlistener"]("isOpenChange", function HomeImportPrivateKeyWalletBeforePage_Template_common_bottom_sheet_isOpenChange_3_listener($event) {
        return $event || (ctx.privateKeyBottomSheetInfo.open = false);
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtemplate"](4, HomeImportPrivateKeyWalletBeforePage_ng_template_4_Template, 8, 3, "ng-template");
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](5, "common-bottom-sheet", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵlistener"]("isOpenChange", function HomeImportPrivateKeyWalletBeforePage_Template_common_bottom_sheet_isOpenChange_5_listener($event) {
        return $event || (ctx.bitcoinSelectAddressTypeBottomSheetInfo.open = false);
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtemplate"](6, HomeImportPrivateKeyWalletBeforePage_ng_template_6_Template, 4, 3, "ng-template");
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("titleColor", "black")("headerBackground", "white")("contentBackground", "env")("contentSafeArea", false);
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("@listFadeInRight", ctx.chainList.length);
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("ngForOf", ctx.chainList)("ngForTrackBy", ctx.trackByKey("chain"));
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("isOpen", ctx.privateKeyBottomSheetInfo.open);
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("isOpen", ctx.bitcoinSelectAddressTypeBottomSheetInfo.open);
    }
  },
  dependencies: [_modules_page_module__WEBPACK_IMPORTED_MODULE_1__.CommonPageModule, _libs_bnf_modules_bottom_sheet_components_bottom_sheet_component__WEBPACK_IMPORTED_MODULE_4__.BottomSheetComponent, _libs_bnf_components_ripple_button_ripple_button_directive__WEBPACK_IMPORTED_MODULE_5__.RippleButtonDirective, _libs_bnf_directives_click_to_copy_directive__WEBPACK_IMPORTED_MODULE_6__.ClickToCopyDirective, _angular_common__WEBPACK_IMPORTED_MODULE_10__.NgForOf, _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_7__.CommonPageComponent, _components_icon_icon_component__WEBPACK_IMPORTED_MODULE_8__.IconComponent],
  styles: ["/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsInNvdXJjZVJvb3QiOiIifQ== */"],
  data: {
    animation: [_bnqkl_framework_animations__WEBPACK_IMPORTED_MODULE_3__.listFadeInRightTrigger]
  },
  changeDetection: 0
});
(0,tslib__WEBPACK_IMPORTED_MODULE_11__.__decorate)([HomeImportPrivateKeyWalletBeforePage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_11__.__metadata)("design:type", Array)], HomeImportPrivateKeyWalletBeforePage.prototype, "chainList", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_11__.__decorate)([HomeImportPrivateKeyWalletBeforePage.States(), (0,tslib__WEBPACK_IMPORTED_MODULE_11__.__metadata)("design:type", Object)], HomeImportPrivateKeyWalletBeforePage.prototype, "privateKeyBottomSheetInfo", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_11__.__decorate)([HomeImportPrivateKeyWalletBeforePage.States(), (0,tslib__WEBPACK_IMPORTED_MODULE_11__.__metadata)("design:type", Object)], HomeImportPrivateKeyWalletBeforePage.prototype, "bitcoinSelectAddressTypeBottomSheetInfo", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_11__.__decorate)([HomeImportPrivateKeyWalletBeforePage.OnReady(), (0,tslib__WEBPACK_IMPORTED_MODULE_11__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_11__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_11__.__metadata)("design:returntype", Promise)], HomeImportPrivateKeyWalletBeforePage.prototype, "initMenu", null);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (HomeImportPrivateKeyWalletBeforePage);

/***/ })

}]);
//# sourceMappingURL=apps_wallet_src_pages_home_pages_home-import-private-key-wallet-before_home-import-private-ke-c71b39.js.map