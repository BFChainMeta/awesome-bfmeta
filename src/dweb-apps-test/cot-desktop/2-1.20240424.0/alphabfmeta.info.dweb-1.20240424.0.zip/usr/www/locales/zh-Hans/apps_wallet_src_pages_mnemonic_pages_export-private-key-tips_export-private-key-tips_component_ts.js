"use strict";
(self["webpackChunkwallet"] = self["webpackChunkwallet"] || []).push([["apps_wallet_src_pages_mnemonic_pages_export-private-key-tips_export-private-key-tips_component_ts"],{

/***/ 25225:
/*!***********************************************************************************************************!*\
  !*** ./apps/wallet/src/pages/mnemonic/pages/export-private-key-tips/export-private-key-tips.component.ts ***!
  \***********************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ExportPrivateKeyTipsPage: () => (/* binding */ ExportPrivateKeyTipsPage),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 90505);
/* harmony import */ var _modules_page_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ~modules/page.module */ 77538);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 61039);
/* harmony import */ var _libs_bnf_components_ripple_button_ripple_button_directive__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../../../../../libs/bnf/components/ripple-button/ripple-button.directive */ 16505);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ 56776);
/* harmony import */ var _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../../../libs/bnf/modules/page/common-page/common-page.component */ 62052);
var _class;






const _c10 = () => ["/mnemonic/export-private-key"];
const _c11 = a0 => ({
  importPhrase: a0
});
/**
 * 导出私钥提示页
 */
/**
 * 导出私钥提示页
 */
class ExportPrivateKeyTipsPage extends _modules_page_module__WEBPACK_IMPORTED_MODULE_0__.CommonPageBase {
  constructor() {
    super(...arguments);
    /** 导入的短语 */
    this.importPhrase = '';
  }
}
_class = ExportPrivateKeyTipsPage;
_class.ɵfac = /*@__PURE__*/(() => {
  let ɵExportPrivateKeyTipsPage_BaseFactory;
  return function ExportPrivateKeyTipsPage_Factory(t) {
    return (ɵExportPrivateKeyTipsPage_BaseFactory || (ɵExportPrivateKeyTipsPage_BaseFactory = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵgetInheritedFactory"](_class)))(t || _class);
  };
})();
_class.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineComponent"]({
  type: _class,
  selectors: [["w-export-private-key-tips-page"]],
  standalone: true,
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵInheritDefinitionFeature"], _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵStandaloneFeature"]],
  decls: 18,
  vars: 7,
  consts: () => {
    let i18n_0;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_BACKUP_PRIVATE_KEY$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_EXPORT_PRIVATE_KEY_TIPS_EXPORT_PRIVATE_KEY_TIPS_COMPONENT_TS_1 = goog.getMsg("Backup Private Key");
      i18n_0 = MSG_EXTERNAL_BACKUP_PRIVATE_KEY$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_EXPORT_PRIVATE_KEY_TIPS_EXPORT_PRIVATE_KEY_TIPS_COMPONENT_TS_1;
    } else {
      i18n_0 = "\u5907\u4EFD\u79C1\u94A5";
    }
    let i18n_2;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_OBTAINING_THE_PRIVATE_KEY_IS_EQUIVALENT_TO_OWNING_THE_WALLET_ASSET$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_EXPORT_PRIVATE_KEY_TIPS_EXPORT_PRIVATE_KEY_TIPS_COMPONENT_TS_3 = goog.getMsg(" Obtaining the private key is equivalent to owning the wallet asset ");
      i18n_2 = MSG_EXTERNAL_OBTAINING_THE_PRIVATE_KEY_IS_EQUIVALENT_TO_OWNING_THE_WALLET_ASSET$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_EXPORT_PRIVATE_KEY_TIPS_EXPORT_PRIVATE_KEY_TIPS_COMPONENT_TS_3;
    } else {
      i18n_2 = "\u83B7\u5F97\u79C1\u94A5\u7B49\u540C\u4E8E\u62E5\u6709\u94B1\u5305\u8D44\u4EA7\u6240\u6709\u6743";
    }
    let i18n_4;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_IMPORTANT_HINT$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_EXPORT_PRIVATE_KEY_TIPS_EXPORT_PRIVATE_KEY_TIPS_COMPONENT_TS_5 = goog.getMsg("Important Hint !");
      i18n_4 = MSG_EXTERNAL_IMPORTANT_HINT$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_EXPORT_PRIVATE_KEY_TIPS_EXPORT_PRIVATE_KEY_TIPS_COMPONENT_TS_5;
    } else {
      i18n_4 = "\u91CD\u8981\u63D0\u793A\uFF01";
    }
    let i18n_6;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_BE_SURE_TO_KEEP_THE_PRIVATE_KEY_IN_A_SAFE_PLACE_IF_THE_PRIVATE_KEY_IS_LOST_IT_CANNOT_BE_RETRIEVED$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_EXPORT_PRIVATE_KEY_TIPS_EXPORT_PRIVATE_KEY_TIPS_COMPONENT_TS_7 = goog.getMsg(" Be sure to keep the private key in a safe place. {$lineBreak} If the private key is lost,it cannot be retrieved ", {
        "lineBreak": "\uFFFD#14\uFFFD\uFFFD/#14\uFFFD"
      }, {
        original_code: {
          "lineBreak": "<br />"
        }
      });
      i18n_6 = MSG_EXTERNAL_BE_SURE_TO_KEEP_THE_PRIVATE_KEY_IN_A_SAFE_PLACE_IF_THE_PRIVATE_KEY_IS_LOST_IT_CANNOT_BE_RETRIEVED$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_EXPORT_PRIVATE_KEY_TIPS_EXPORT_PRIVATE_KEY_TIPS_COMPONENT_TS_7;
    } else {
      i18n_6 = "\u8BF7\u52A1\u5FC5\u5C06\u79C1\u94A5\u4FDD\u5B58\u81F3\u5B89\u5168\u7684\u5730\u65B9 " + "\uFFFD#14\uFFFD\uFFFD/#14\uFFFD" + " \u79C1\u94A5\u4E22\u5931\u5C06\u65E0\u6CD5\u627E\u56DE ";
    }
    let i18n_8;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_NEXT$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_EXPORT_PRIVATE_KEY_TIPS_EXPORT_PRIVATE_KEY_TIPS_COMPONENT_TS_9 = goog.getMsg(" Next ");
      i18n_8 = MSG_EXTERNAL_NEXT$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_EXPORT_PRIVATE_KEY_TIPS_EXPORT_PRIVATE_KEY_TIPS_COMPONENT_TS_9;
    } else {
      i18n_8 = "\u4E0B\u4E00\u6B65";
    }
    return [[3, "contentSafeArea"], [1, "w-45", "mx-auto", "pt-6"], ["src", "./assets/images/icon_key.png"], [1, "py-0", "text-center"], [1, "mb-2", "mt-6", "text-base", "font-semibold"], i18n_0, [1, "text-text", "text-xs"], i18n_2, [1, "mt-6", "rounded", "bg-[#fff0ee]", "px-5", "py-4"], [1, "text-error", "mb-6px", "font-semibold"], i18n_4, [1, "text-error", "text-xs"], [1, "mt-1", "text-xs", "leading-6"], i18n_6, ["footer", ""], ["bnRippleButton", "", 1, "bg-primary-2", "h-10.5", "w-full", "rounded-full", "text-center", "text-white", 3, "routerLink", "queryParams", "replaceUrl"], i18n_8];
  },
  template: function ExportPrivateKeyTipsPage_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "common-page", 0)(1, "div", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](2, "img", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](3, "div", 3)(4, "div", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵi18n"](5, 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](6, "div", 6);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵi18n"](7, 7);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](8, "div", 8)(9, "div", 9);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵi18n"](10, 10);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](11, "div", 11)(12, "div", 12);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵi18nStart"](13, 13);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](14, "br");
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵi18nEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()()()();
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](15, "div", 14)(16, "button", 15);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵi18n"](17, 16);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()()();
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("contentSafeArea", true);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](16);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("routerLink", _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpureFunction0"](4, _c10))("queryParams", _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpureFunction1"](5, _c11, ctx.importPhrase))("replaceUrl", true);
    }
  },
  dependencies: [_modules_page_module__WEBPACK_IMPORTED_MODULE_0__.CommonPageModule, _libs_bnf_components_ripple_button_ripple_button_directive__WEBPACK_IMPORTED_MODULE_1__.RippleButtonDirective, _angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterLink, _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_2__.CommonPageComponent],
  styles: ["[_nghost-%COMP%]   .boxStyle1[_ngcontent-%COMP%] {\n  width: 11.25rem;\n  margin: 0 auto;\n  margin-bottom: 0.6875rem;\n}\n[_nghost-%COMP%]   .fontStyle1[_ngcontent-%COMP%] {\n  font-family: PingFangSC-Semibold;\n}\n[_nghost-%COMP%]   .fontStyle2[_ngcontent-%COMP%] {\n  font-family: PingFangSC-Regular;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL2FwcHMvd2FsbGV0L3NyYy9wYWdlcy9tbmVtb25pYy9wYWdlcy9leHBvcnQtcHJpdmF0ZS1rZXktdGlwcy9leHBvcnQtcHJpdmF0ZS1rZXktdGlwcy5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFDRTtFQUNFLGVBQUE7RUFDQSxjQUFBO0VBQ0Esd0JBQUE7QUFBSjtBQUdFO0VBQ0UsZ0NBQUE7QUFESjtBQUlFO0VBQ0UsK0JBQUE7QUFGSiIsInNvdXJjZXNDb250ZW50IjpbIjpob3N0IHtcclxuICAuYm94U3R5bGUxIHtcclxuICAgIHdpZHRoOiAxMS4yNXJlbTtcclxuICAgIG1hcmdpbjogMCBhdXRvO1xyXG4gICAgbWFyZ2luLWJvdHRvbTogMC42ODc1cmVtO1xyXG4gIH1cclxuXHJcbiAgLmZvbnRTdHlsZTEge1xyXG4gICAgZm9udC1mYW1pbHk6IFBpbmdGYW5nU0MtU2VtaWJvbGQ7XHJcbiAgfVxyXG5cclxuICAuZm9udFN0eWxlMiB7XHJcbiAgICBmb250LWZhbWlseTogUGluZ0ZhbmdTQy1SZWd1bGFyO1xyXG4gIH1cclxufVxyXG4iXSwic291cmNlUm9vdCI6IiJ9 */"],
  changeDetection: 0
});
(0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([ExportPrivateKeyTipsPage.QueryParam('importPhrase'), ExportPrivateKeyTipsPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__metadata)("design:type", Object)], ExportPrivateKeyTipsPage.prototype, "importPhrase", void 0);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ExportPrivateKeyTipsPage);

/***/ })

}]);
//# sourceMappingURL=apps_wallet_src_pages_mnemonic_pages_export-private-key-tips_export-private-key-tips_component_ts.js.map