"use strict";
(self["webpackChunkwallet"] = self["webpackChunkwallet"] || []).push([["apps_wallet_src_pages_authorize_authorize_routes_ts"],{

/***/ 848:
/*!*************************************************************!*\
  !*** ./apps/wallet/src/pages/authorize/authorize.routes.ts ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   routes: () => (/* binding */ routes)
/* harmony export */ });
/* harmony import */ var _pages_address_address_resolver__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./pages/address/address.resolver */ 35505);
/* harmony import */ var _pages_signature_signature_resolver__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./pages/signature/signature.resolver */ 52645);


const routes = [{
  path: 'address/:id',
  loadComponent: () => __webpack_require__.e(/*! import() */ "apps_wallet_src_pages_authorize_pages_address_address_component_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/address/address.component */ 45604)),
  resolve: _pages_address_address_resolver__WEBPACK_IMPORTED_MODULE_0__.AuthorizeAddressResolver
}, {
  path: 'signature/:id',
  loadComponent: () => Promise.all(/*! import() */[__webpack_require__.e("default-apps_wallet_src_pages_mime_pages_verify-fingerprint_verify-fingerprint_component_ts"), __webpack_require__.e("default-apps_wallet_src_pages_home_pages_home-payment-details_home-payment-details_component_ts"), __webpack_require__.e("apps_wallet_src_pages_authorize_pages_signature_signature_component_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./pages/signature/signature.component */ 78819)),
  resolve: _pages_signature_signature_resolver__WEBPACK_IMPORTED_MODULE_1__.AuthorizeSignatureResolver
}];
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (routes);

/***/ }),

/***/ 35505:
/*!***************************************************************************!*\
  !*** ./apps/wallet/src/pages/authorize/pages/address/address.resolver.ts ***!
  \***************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AuthorizeAddressResolver: () => (/* binding */ AuthorizeAddressResolver)
/* harmony export */ });
/* harmony import */ var D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 52542);
/* harmony import */ var _bnqkl_wallet_base_services_plaoc__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @bnqkl/wallet-base/services/plaoc */ 63878);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 61039);
/* harmony import */ var _bnqkl_wallet_base_services_wallet__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @bnqkl/wallet-base/services/wallet */ 20609);




/**
 * ResolverData
 */
const AuthorizeAddressResolver = {
  data: function () {
    var _ref = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (route) {
      const plaoc = (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.inject)(_bnqkl_wallet_base_services_plaoc__WEBPACK_IMPORTED_MODULE_1__.PlaocService);
      const {
        chainName = _bnqkl_wallet_base_services_wallet__WEBPACK_IMPORTED_MODULE_2__.CHAIN_NAME.BFMeta,
        type = _bnqkl_wallet_base_services_plaoc__WEBPACK_IMPORTED_MODULE_1__.$WALLET_AUTHORIZE_ADDRESS_TYPE.main,
        eventId,
        signMessage = ""
      } = route.queryParams;
      const info = yield plaoc.getCallerAppInfo(eventId);
      const appName = (info === null || info === void 0 ? void 0 : info.short_name) || APP_NAME || '';
      const appHome = (info === null || info === void 0 ? void 0 : info.home) || (info === null || info === void 0 ? void 0 : info.homepage_url) || '';
      const appLogo = (((info === null || info === void 0 ? void 0 : info.icons) || [])[0] || {
        src: ''
      }).src;
      return {
        chainName,
        signMessage,
        type,
        eventId,
        appName,
        appHome,
        appLogo
      };
    });
    return function data(_x) {
      return _ref.apply(this, arguments);
    };
  }()
};

/***/ }),

/***/ 52645:
/*!*******************************************************************************!*\
  !*** ./apps/wallet/src/pages/authorize/pages/signature/signature.resolver.ts ***!
  \*******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AuthorizeSignatureResolver: () => (/* binding */ AuthorizeSignatureResolver)
/* harmony export */ });
/* harmony import */ var D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 52542);
/* harmony import */ var _bnqkl_wallet_base_services_plaoc__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @bnqkl/wallet-base/services/plaoc */ 63878);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 61039);



/**
 * ResolverData
 */
const AuthorizeSignatureResolver = {
  data: function () {
    var _ref = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (route) {
      const plaoc = (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.inject)(_bnqkl_wallet_base_services_plaoc__WEBPACK_IMPORTED_MODULE_1__.PlaocService);
      const {
        signaturedata,
        eventId
      } = route.queryParams;
      const data = JSON.parse(signaturedata);
      const info = yield plaoc.getCallerAppInfo(eventId);
      const appName = (info === null || info === void 0 ? void 0 : info.short_name) || APP_NAME || '';
      const appHome = (info === null || info === void 0 ? void 0 : info.home) || (info === null || info === void 0 ? void 0 : info.homepage_url) || '';
      const appLogo = (((info === null || info === void 0 ? void 0 : info.icons) || [])[0] || {
        src: ''
      }).src;
      return {
        eventId,
        appName,
        appHome,
        appLogo,
        signatureData: data
      };
    });
    return function data(_x) {
      return _ref.apply(this, arguments);
    };
  }()
};

/***/ })

}]);
//# sourceMappingURL=apps_wallet_src_pages_authorize_authorize_routes_ts.js.map