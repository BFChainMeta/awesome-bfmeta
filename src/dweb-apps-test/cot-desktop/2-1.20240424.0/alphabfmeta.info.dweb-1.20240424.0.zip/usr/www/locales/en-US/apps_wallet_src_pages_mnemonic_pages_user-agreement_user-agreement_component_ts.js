"use strict";
(self["webpackChunkwallet"] = self["webpackChunkwallet"] || []).push([["apps_wallet_src_pages_mnemonic_pages_user-agreement_user-agreement_component_ts"],{

/***/ 29640:
/*!*****************************************************************************************!*\
  !*** ./apps/wallet/src/pages/mnemonic/pages/user-agreement/user-agreement.component.ts ***!
  \*****************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   UserAgreementPage: () => (/* binding */ UserAgreementPage),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 52542);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 90505);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 61039);
/* harmony import */ var showdown__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! showdown */ 52161);
/* harmony import */ var showdown__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(showdown__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _modules_page_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ~modules/page.module */ 77538);
/* harmony import */ var _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../../../../libs/bnf/modules/page/common-page/common-page.component */ 62052);

var _class;






/** 用户协议 */
class UserAgreementPage extends _modules_page_module__WEBPACK_IMPORTED_MODULE_2__.CommonPageBase {
  constructor() {
    super(...arguments);
    /** 当前系统语言 */
    this.locale_id = (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.inject)(_angular_core__WEBPACK_IMPORTED_MODULE_4__.LOCALE_ID);
    /** 解析用户协议 */
    this.makeHtml = '';
    /** 加载内容 */
    this._content = fetch(`./assets/user-agreement/${this.locale_id}.md`).then(res => res.text());
  }
  /**
   * 用户协议初始化
   */
  init() {
    var _this = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const content = yield _this._content;
      const converter = new showdown__WEBPACK_IMPORTED_MODULE_1__.Converter();
      _this.makeHtml = converter.makeHtml(content);
    })();
  }
}
_class = UserAgreementPage;
_class.ɵfac = /*@__PURE__*/(() => {
  let ɵUserAgreementPage_BaseFactory;
  return function UserAgreementPage_Factory(t) {
    return (ɵUserAgreementPage_BaseFactory || (ɵUserAgreementPage_BaseFactory = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵgetInheritedFactory"](_class)))(t || _class);
  };
})();
_class.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineComponent"]({
  type: _class,
  selectors: [["w-user-agreement-page"]],
  standalone: true,
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵInheritDefinitionFeature"], _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵStandaloneFeature"]],
  decls: 2,
  vars: 2,
  consts: [[3, "contentBackground"], [1, "markdowm-view", 3, "innerHtml"]],
  template: function UserAgreementPage_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "common-page", 0);
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](1, "div", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("contentBackground", "env");
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("innerHtml", ctx.makeHtml, _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵsanitizeHtml"]);
    }
  },
  dependencies: [_modules_page_module__WEBPACK_IMPORTED_MODULE_2__.CommonPageModule, _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_3__.CommonPageComponent],
  styles: [".markdowm-view[_ngcontent-%COMP%]     {\n    word-break: break-all\n}\n.markdowm-view[_ngcontent-%COMP%]     h1 {\n    margin-top: 2rem;\n    text-align: center;\n    font-size: 1rem;\n    font-weight: 600;\n    font-style: italic;\n    line-height: 2.5rem;\n    --tw-text-opacity: 1;\n    color: rgb(2 17 35 / var(--tw-text-opacity))\n}\n.markdowm-view[_ngcontent-%COMP%]     blockquote p {\n    margin-bottom: 1.5rem;\n    text-align: center;\n    font-size: 0.625rem;\n    line-height: 0.875rem;\n    --tw-text-opacity: 1;\n    color: rgb(137 122 163 / var(--tw-text-opacity))\n}\n.markdowm-view[_ngcontent-%COMP%]     p {\n    margin-left: 1.25rem;\n    margin-right: 1.25rem;\n    text-align: left;\n    font-size: 0.75rem;\n    line-height: 1.5rem;\n    --tw-text-opacity: 1;\n    color: rgb(85 76 111 / var(--tw-text-opacity))\n}\n.markdowm-view[_ngcontent-%COMP%]     h2 {\n    margin-left: 1.25rem;\n    margin-right: 1.25rem;\n    margin-bottom: 0.5rem;\n    margin-top: 1.5rem;\n    font-size: 0.875rem;\n    line-height: 1.25rem;\n    font-weight: 600;\n    --tw-text-opacity: 1;\n    color: rgb(2 17 35 / var(--tw-text-opacity))\n}\n.markdowm-view[_ngcontent-%COMP%]     ol {\n    margin-left: 1.25rem;\n    margin-right: 1.25rem;\n    --tw-text-opacity: 1;\n    color: rgb(85 76 111 / var(--tw-text-opacity))\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL2FwcHMvd2FsbGV0L3NyYy9wYWdlcy9tbmVtb25pYy9wYWdlcy91c2VyLWFncmVlbWVudC91c2VyLWFncmVlbWVudC5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFDRTtJQUFBO0FBQUE7QUFFRTtJQUFBLGdCQUFBO0lBQUEsa0JBQUE7SUFBQSxlQUFBO0lBQUEsZ0JBQUE7SUFBQSxrQkFBQTtJQUFBLG1CQUFBO0lBQUEsb0JBQUE7SUFBQTtBQUFBO0FBR0E7SUFBQSxxQkFBQTtJQUFBLGtCQUFBO0lBQUEsbUJBQUE7SUFBQSxxQkFBQTtJQUFBLG9CQUFBO0lBQUE7QUFBQTtBQUdBO0lBQUEsb0JBQUE7SUFBQSxxQkFBQTtJQUFBLGdCQUFBO0lBQUEsa0JBQUE7SUFBQSxtQkFBQTtJQUFBLG9CQUFBO0lBQUE7QUFBQTtBQUdBO0lBQUEsb0JBQUE7SUFBQSxxQkFBQTtJQUFBLHFCQUFBO0lBQUEsa0JBQUE7SUFBQSxtQkFBQTtJQUFBLG9CQUFBO0lBQUEsZ0JBQUE7SUFBQSxvQkFBQTtJQUFBO0FBQUE7QUFHQTtJQUFBLG9CQUFBO0lBQUEscUJBQUE7SUFBQSxvQkFBQTtJQUFBO0FBQUEiLCJzb3VyY2VzQ29udGVudCI6WyIubWFya2Rvd20tdmlldyA6Om5nLWRlZXAge1xyXG4gIEBhcHBseSBicmVhay1hbGw7XHJcbiAgaDEge1xyXG4gICAgQGFwcGx5IHRleHQtdGl0bGUgbXQtOCB0ZXh0LWNlbnRlciB0ZXh0LWJhc2UgZm9udC1zZW1pYm9sZCBpdGFsaWMgbGVhZGluZy0xMDtcclxuICB9XHJcbiAgYmxvY2txdW90ZSBwIHtcclxuICAgIEBhcHBseSB0ZXh0LXN1YnRleHQgdGV4dC14c3MgbWItNiB0ZXh0LWNlbnRlcjtcclxuICB9XHJcbiAgcCB7XHJcbiAgICBAYXBwbHkgdGV4dC10ZXh0IG14LTUgdGV4dC1sZWZ0IHRleHQteHMgbGVhZGluZy02O1xyXG4gIH1cclxuICBoMiB7XHJcbiAgICBAYXBwbHkgdGV4dC10aXRsZSBteC01IG1iLTIgbXQtNiB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQ7XHJcbiAgfVxyXG4gIG9sIHtcclxuICAgIEBhcHBseSB0ZXh0LXRleHQgbXgtNTtcclxuICB9XHJcbn1cclxuIl0sInNvdXJjZVJvb3QiOiIifQ== */"],
  changeDetection: 0
});
(0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([UserAgreementPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__metadata)("design:type", Object)], UserAgreementPage.prototype, "makeHtml", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([UserAgreementPage.OnReady(), (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__metadata)("design:returntype", Promise)], UserAgreementPage.prototype, "init", null);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (UserAgreementPage);

/***/ })

}]);
//# sourceMappingURL=apps_wallet_src_pages_mnemonic_pages_user-agreement_user-agreement_component_ts.js.map