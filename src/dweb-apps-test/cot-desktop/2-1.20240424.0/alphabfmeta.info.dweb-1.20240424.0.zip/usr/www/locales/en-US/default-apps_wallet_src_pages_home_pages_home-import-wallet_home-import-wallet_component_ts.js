"use strict";
(self["webpackChunkwallet"] = self["webpackChunkwallet"] || []).push([["default-apps_wallet_src_pages_home_pages_home-import-wallet_home-import-wallet_component_ts"],{

/***/ 72710:
/*!*********************************************************************************************!*\
  !*** ./apps/wallet/src/pages/home/pages/home-import-wallet/home-import-wallet.component.ts ***!
  \*********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   HomeImportWalletPage: () => (/* binding */ HomeImportWalletPage),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 52542);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! tslib */ 90505);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @angular/core */ 61039);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @angular/forms */ 7820);
/* harmony import */ var _bnqkl_framework_controllers__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @bnqkl/framework/controllers */ 47919);
/* harmony import */ var _bnqkl_framework_plugins_toast__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @bnqkl/framework/plugins/toast */ 18030);
/* harmony import */ var _components_input_hidden_icon_swap_input_hidden_icon_swap_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ~components/input-hidden-icon-swap/input-hidden-icon-swap.component */ 68027);
/* harmony import */ var _modules_page_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ~modules/page.module */ 77538);
/* harmony import */ var _bnqkl_wallet_base_services_wallet_bip39__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @bnqkl/wallet-base/services/wallet/bip39 */ 76659);
/* harmony import */ var _bnqkl_wallet_base_services_wallet_chain__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @bnqkl/wallet-base/services/wallet/chain */ 27434);
/* harmony import */ var _bnqkl_wallet_base_services_wallet_wallet_data_storage__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @bnqkl/wallet-base/services/wallet/wallet-data-storage */ 63024);
/* harmony import */ var _bnqkl_wallet_base_services_wallet_wallet__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @bnqkl/wallet-base/services/wallet/wallet */ 21789);
/* harmony import */ var _libs_bnf_components_ripple_button_ripple_button_directive__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../../../../../../libs/bnf/components/ripple-button/ripple-button.directive */ 16505);
/* harmony import */ var _libs_bnf_directives_form_errors_directive__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../../../../../../libs/bnf/directives/form-errors.directive */ 29541);
/* harmony import */ var _libs_bnf_directives_auto_complete_off_directive__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../../../../../../libs/bnf/directives/auto-complete-off.directive */ 66722);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! @angular/common */ 6729);
/* harmony import */ var _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../../../../../../libs/bnf/modules/page/common-page/common-page.component */ 62052);
/* harmony import */ var _components_icon_icon_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../../../../components/icon/icon.component */ 74703);
/* harmony import */ var _components_form_validation_top_tips_form_validation_top_tips_component__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../../../../components/form-validation-top-tips/form-validation-top-tips.component */ 34113);
/* harmony import */ var _libs_bnf_pipes_errors_errors_pipe__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ../../../../../../../libs/bnf/pipes/errors/errors.pipe */ 68362);
/* harmony import */ var _pipes_color_color_pipe__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ../../../../pipes/color/color.pipe */ 76489);

var _class;






















function HomeImportWalletPage_textarea_10_Template(rf, ctx) {
  if (rf & 1) {
    const _r14 = _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](0, "textarea", 35, 36);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵlistener"]("ngModelChange", function HomeImportWalletPage_textarea_10_Template_textarea_ngModelChange_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵrestoreView"](_r14);
      const _r12 = _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵreference"](1);
      const ctx_r13 = _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵresetView"](ctx_r13.handleTextareaChange(_r12));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵproperty"]("placeholder", ctx_r0.importValuePlaceholder);
  }
}
function HomeImportWalletPage_ng_template_17_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵi18n"](1, 37);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementContainerEnd"]();
  }
}
function HomeImportWalletPage_ng_template_18_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵi18n"](1, 38);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const error_r15 = ctx.$error;
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵi18nExp"](error_r15.requiredLength);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵi18nApply"](1);
  }
}
function HomeImportWalletPage_ng_template_28_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵi18n"](1, 39);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementContainerEnd"]();
  }
}
function HomeImportWalletPage_ng_template_29_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵi18n"](1, 40);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const error_r17 = ctx.$error;
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵi18nExp"](error_r17.requiredLength);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵi18nApply"](1);
  }
}
function HomeImportWalletPage_ng_template_30_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵi18n"](1, 41);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const error_r18 = ctx.$error;
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵi18nExp"](error_r18.requiredLength);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵi18nApply"](1);
  }
}
function HomeImportWalletPage_ng_template_31_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵi18n"](1, 42);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementContainerEnd"]();
  }
}
function HomeImportWalletPage_ng_template_32_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵi18n"](1, 43);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementContainerEnd"]();
  }
}
function HomeImportWalletPage_ng_template_33_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵi18n"](1, 44);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementContainerEnd"]();
  }
}
function HomeImportWalletPage_ng_template_34_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtext"](0);
  }
  if (rf & 2) {
    const errors_r20 = ctx.$errors;
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtextInterpolate1"](" ", errors_r20, " ");
  }
}
function HomeImportWalletPage_div_39_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](0, "div", 45);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelement"](1, "w-icon", 46);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](2, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵi18n"](3, 47);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]()();
  }
}
function HomeImportWalletPage_div_49_div_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵi18n"](1, 50);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const errors_r21 = _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵnextContext"]().ngIf;
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵi18nExp"](errors_r21 == null ? null : errors_r21["maxlength"] == null ? null : errors_r21["maxlength"].requiredLength);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵi18nApply"](1);
  }
}
function HomeImportWalletPage_div_49_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](0, "div", 48);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtemplate"](1, HomeImportWalletPage_div_49_div_1_Template, 2, 1, "div", 49);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r11 = _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵproperty"]("ngIf", ctx_r11.tip.errors == null ? null : ctx_r11.tip.errors["maxlength"]);
  }
}
const _c38 = a0 => ({
  "text-error": a0
});
const _c39 = (a0, a1) => ({
  pwd: a0,
  cpwd: a1
});
const _c40 = a0 => ({
  "--color-1": a0
});
class HomeImportWalletPage extends _modules_page_module__WEBPACK_IMPORTED_MODULE_4__.CommonPageBase {
  constructor() {
    var _this;
    /** 页面返回值的类型 */
    super(...arguments);
    _this = this;
    this.returnValue$ = new _modules_page_module__WEBPACK_IMPORTED_MODULE_4__.PageReturnValue();
    /** 助记词服务 */
    this.bip39LibService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_17__.inject)(_bnqkl_wallet_base_services_wallet_bip39__WEBPACK_IMPORTED_MODULE_5__.Bip39LibService);
    /** 链服务 */
    this.chainService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_17__.inject)(_bnqkl_wallet_base_services_wallet_chain__WEBPACK_IMPORTED_MODULE_6__.ChainService);
    /** 是否显示密码的顶部提示 */
    this.showPwdTip = false;
    /** 是否显示助记词的顶部提示 */
    this.showMneTip = false;
    /** 顶部密码提示的内容 */
    this.pwdTip = '';
    /** 顶部助记词提示的内容 */
    this.mneTip = '';
    /** 表单验证服务 */
    this.validators = new _bnqkl_framework_controllers__WEBPACK_IMPORTED_MODULE_1__.FormValidatorsController(this);
    this.importType = '';
    /** 存储key */
    this.notMainWalletKey = '';
    /** 是否显示密码 */
    this.showPwd = false;
    /** 是否显示确认密码 */
    this.showCPwd = false;
    /** 名称 */
    this.name = new _angular_forms__WEBPACK_IMPORTED_MODULE_18__.FormControl('', {
      nonNullable: true,
      validators: [this.validators.trimRequired, _angular_forms__WEBPACK_IMPORTED_MODULE_18__.Validators.maxLength(12)]
    });
    /** 输入的内容 */
    this.importValue = new _angular_forms__WEBPACK_IMPORTED_MODULE_18__.FormControl('', {
      nonNullable: true,
      validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_18__.Validators.required],
      asyncValidators: [(
      /*#__PURE__*/
      /** 判断助记词是否正确 */
      function () {
        var _ref = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (control) {
          /// 没有其它错误了
          if (control.errors) {
            return null;
          }
          try {
            const value = control.value.trim() || '';
            if (_this.importType === _bnqkl_wallet_base_services_wallet_wallet_data_storage__WEBPACK_IMPORTED_MODULE_7__.WALLET_IMPORT_TYPE.mnemonic) {
              if (_this.chainService.isBioforestChainByChainName(_this.chain) === false) {
                try {
                  yield _this.bip39LibService.checkMnemonic(value);
                } catch (err) {
                  _this.console.error(err);
                  throw new Error("Mnemonic input error, please re-enter");
                }
              }
            } else {
              yield _this.chainService.getChainAddressByPrivateKey(value, _this.chain);
            }
            _this.showMneTip = false;
          } catch (err) {
            _this.showMneTip = true;
            _this.console.error(err instanceof Error ? err.message : String(err));
            /// 来这里统一说明输入错误，避免依赖包里面的抛错包含未翻译内容
            _this.mneTip = _this.importType === 'privateKey' ? "PrivateKey input error" : "Mnemonic input error, please re-enter";
            let phrase = err instanceof Error ? err.message : String(err);
            /// 错误信息翻译
            {
              const bytes_long_error = phrase.match(/Private must be (\d+) bytes long/);
              if (bytes_long_error) {
                const bytes = bytes_long_error[1];
                phrase = "Private must be " + bytes + " bytes long";
              }
            }
            return {
              phrase
            };
          }
          return null;
        });
        return function (_x) {
          return _ref.apply(this, arguments);
        };
      }())]
    });
    /** 密码 */
    this.pwd = new _angular_forms__WEBPACK_IMPORTED_MODULE_18__.FormControl('', {
      nonNullable: true,
      validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_18__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_18__.Validators.minLength(8), _angular_forms__WEBPACK_IMPORTED_MODULE_18__.Validators.maxLength(30), this.validators.whitespace]
    });
    /** 确认密码 */
    this.cpwd = new _angular_forms__WEBPACK_IMPORTED_MODULE_18__.FormControl('', {
      nonNullable: true,
      validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_18__.Validators.required, this.validators.equals(this.pwd)]
    });
    /** 密码提示 */
    this.tip = new _angular_forms__WEBPACK_IMPORTED_MODULE_18__.FormControl('', {
      nonNullable: true,
      validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_18__.Validators.maxLength(50)]
    });
    /** 要提交的表单与复合验证 */
    this.form = new _angular_forms__WEBPACK_IMPORTED_MODULE_18__.FormGroup({
      importValue: this.importValue,
      name: this.name,
      pwd: this.pwd,
      cpwd: this.cpwd,
      tip: this.tip
    }, {
      validators: [],
      asyncValidators: []
    });
  }
  /** 输入参数 */
  set walletName(value) {
    this.name.patchValue(value);
  }
  /** 动态判断输入提示语 */
  get importValuePlaceholder() {
    return this.importType === 'privateKey' ? "Enter plaintext private Key" : "Enter the mnemonic, separated by spaces";
  }
  /** 根据链类型判断文字 */
  get importTypeLabel() {
    if (this.importType === 'privateKey') {
      return "Private Key";
    }
    return this.chainService.isBioforestChainByChainName(this.chain) ? "Mnemonic / Address Password" : "Mnemonic";
  }
  /** 提交表单 */
  onSubmit() {
    /** @TODO 提交前还要校验一次 */
    this.createNotMainWallet();
  }
  /** 创建非身份钱包 */
  createNotMainWallet() {
    var _this2 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const walletService = _this2.injectorForceGet(_bnqkl_wallet_base_services_wallet_wallet__WEBPACK_IMPORTED_MODULE_8__.WalletService);
      const chainService = _this2.injectorForceGet(_bnqkl_wallet_base_services_wallet_chain__WEBPACK_IMPORTED_MODULE_6__.ChainService);
      const chainInfo = chainService.getChainInfo(_this2.chain);
      const {
        name,
        pwd,
        tip,
        importValue
      } = _this2.form.getRawValue();
      try {
        yield walletService.createNotMainWallet(_this2.notMainWalletKey, {
          /** 钱包名称 */
          name: name.trim(),
          /** 助记词 或 私钥 */
          importPhrase: importValue.trim(),
          /** 导入的类型 */
          importType: _this2.importType === 'mnemonic' ? _bnqkl_wallet_base_services_wallet_wallet_data_storage__WEBPACK_IMPORTED_MODULE_7__.WALLET_IMPORT_TYPE.mnemonic : _bnqkl_wallet_base_services_wallet_wallet_data_storage__WEBPACK_IMPORTED_MODULE_7__.WALLET_IMPORT_TYPE.privateKey,
          /** 密码 */
          password: pwd,
          /** 密码提示 */
          passwordTips: tip.trim(),
          chain: chainInfo.chain,
          symbol: chainInfo.symbol,
          coinId: chainInfo.coinId,
          notMainWalletKey: _this2.notMainWalletKey
        });
        _this2.form.reset();
        _this2.returnValue$.next({
          result: true
        });
        /// 返回根页面
        _this2.nav.routeBack('/home-manage-wallets');
      } catch (error) {
        _bnqkl_framework_plugins_toast__WEBPACK_IMPORTED_MODULE_2__.Toast.show(error instanceof Error ? error.message : String(error));
      }
    })();
  }
  /** 显示顶部密码提示框 */
  openPwdTip(show) {
    this.pwdTip = show ? "This password is only used for the security protection of the wallet. COT will not save your password, nor will it be able to help you retrieve it. Please remember and keep your password!" : '';
    this.showPwdTip = show;
  }
  handleTextareaChange(textarea) {
    if (textarea.scrollHeight < 150) {
      textarea.style.height = 'auto';
      textarea.style.height = textarea.scrollHeight + 'px';
    }
  }
}
_class = HomeImportWalletPage;
_class.ɵfac = /*@__PURE__*/(() => {
  let ɵHomeImportWalletPage_BaseFactory;
  return function HomeImportWalletPage_Factory(t) {
    return (ɵHomeImportWalletPage_BaseFactory || (ɵHomeImportWalletPage_BaseFactory = _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵgetInheritedFactory"](_class)))(t || _class);
  };
})();
_class.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵdefineComponent"]({
  type: _class,
  selectors: [["w-home-import-wallet-page"]],
  outputs: {
    returnValue$: "returnValue$"
  },
  standalone: true,
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵInheritDefinitionFeature"], _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵStandaloneFeature"]],
  decls: 56,
  vars: 59,
  consts: () => {
    let i18n_0;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_IMPORT_WALLET__SYMBOL_$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_IMPORT_WALLET_HOME_IMPORT_WALLET_COMPONENT_TS_1 = goog.getMsg("import Wallet ({$interpolation})", {
        "interpolation": "\uFFFD0\uFFFD"
      }, {
        original_code: {
          "interpolation": "{{ symbol }}"
        }
      });
      i18n_0 = MSG_EXTERNAL_IMPORT_WALLET__SYMBOL_$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_IMPORT_WALLET_HOME_IMPORT_WALLET_COMPONENT_TS_1;
    } else {
      i18n_0 = "import Wallet (" + "\uFFFD0\uFFFD" + ")";
    }
    let i18n_2;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_WALLET_NAME$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_IMPORT_WALLET_HOME_IMPORT_WALLET_COMPONENT_TS_3 = goog.getMsg(" Wallet Name ");
      i18n_2 = MSG_EXTERNAL_WALLET_NAME$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_IMPORT_WALLET_HOME_IMPORT_WALLET_COMPONENT_TS_3;
    } else {
      i18n_2 = " Wallet Name ";
    }
    let i18n_4;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_ENTER_CHARACTERS$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_IMPORT_WALLET_HOME_IMPORT_WALLET_COMPONENT_TS_5 = goog.getMsg("Enter 1-12 characters");
      i18n_4 = MSG_EXTERNAL_ENTER_CHARACTERS$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_IMPORT_WALLET_HOME_IMPORT_WALLET_COMPONENT_TS_5;
    } else {
      i18n_4 = "Enter 1-12 characters";
    }
    let i18n_6;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_WALLET_PASSWORD$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_IMPORT_WALLET_HOME_IMPORT_WALLET_COMPONENT_TS_7 = goog.getMsg(" Wallet Password ");
      i18n_6 = MSG_EXTERNAL_WALLET_PASSWORD$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_IMPORT_WALLET_HOME_IMPORT_WALLET_COMPONENT_TS_7;
    } else {
      i18n_6 = " Wallet Password ";
    }
    let i18n_8;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_PASSWORD_IS_NOT_LESS_THAN_DIGITS$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_IMPORT_WALLET_HOME_IMPORT_WALLET_COMPONENT_TS_9 = goog.getMsg("Password is not less than 8 digits");
      i18n_8 = MSG_EXTERNAL_PASSWORD_IS_NOT_LESS_THAN_DIGITS$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_IMPORT_WALLET_HOME_IMPORT_WALLET_COMPONENT_TS_9;
    } else {
      i18n_8 = "Password is not less than 8 digits";
    }
    let i18n_10;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_REPEAT_PASSWORD$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_IMPORT_WALLET_HOME_IMPORT_WALLET_COMPONENT_TS_11 = goog.getMsg("Repeat Password");
      i18n_10 = MSG_EXTERNAL_REPEAT_PASSWORD$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_IMPORT_WALLET_HOME_IMPORT_WALLET_COMPONENT_TS_11;
    } else {
      i18n_10 = "Repeat Password";
    }
    let i18n_12;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_PASSWORD_HINT_OPTIONAL$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_IMPORT_WALLET_HOME_IMPORT_WALLET_COMPONENT_TS_13 = goog.getMsg(" Password Hint (optional) ");
      i18n_12 = MSG_EXTERNAL_PASSWORD_HINT_OPTIONAL$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_IMPORT_WALLET_HOME_IMPORT_WALLET_COMPONENT_TS_13;
    } else {
      i18n_12 = " Password Hint (optional) ";
    }
    let i18n_14;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_ENTER_PASSWORD_PROMPT_INFORMATION$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_IMPORT_WALLET_HOME_IMPORT_WALLET_COMPONENT_TS_15 = goog.getMsg("Enter password prompt information");
      i18n_14 = MSG_EXTERNAL_ENTER_PASSWORD_PROMPT_INFORMATION$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_IMPORT_WALLET_HOME_IMPORT_WALLET_COMPONENT_TS_15;
    } else {
      i18n_14 = "Enter password prompt information";
    }
    let i18n_16;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_CONFIRM$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_IMPORT_WALLET_HOME_IMPORT_WALLET_COMPONENT_TS_17 = goog.getMsg(" Confirm ");
      i18n_16 = MSG_EXTERNAL_CONFIRM$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_IMPORT_WALLET_HOME_IMPORT_WALLET_COMPONENT_TS_17;
    } else {
      i18n_16 = " Confirm ";
    }
    let i18n_18;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_PLEASE_ENTER_IDENTITY_NAME$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_IMPORT_WALLET_HOME_IMPORT_WALLET_COMPONENT_TS__19 = goog.getMsg("Please enter Identity name");
      i18n_18 = MSG_EXTERNAL_PLEASE_ENTER_IDENTITY_NAME$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_IMPORT_WALLET_HOME_IMPORT_WALLET_COMPONENT_TS__19;
    } else {
      i18n_18 = "Please enter Identity name";
    }
    let i18n_20;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_THE_MAXIMUM_LENGTH_OF_THE_NAME_IS_REQUIRED_LENGTH$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_IMPORT_WALLET_HOME_IMPORT_WALLET_COMPONENT_TS__21 = goog.getMsg(" The maximum length of the name is {$interpolation} ", {
        "interpolation": "\uFFFD0\uFFFD"
      }, {
        original_code: {
          "interpolation": "{{ error.requiredLength }}"
        }
      });
      i18n_20 = MSG_EXTERNAL_THE_MAXIMUM_LENGTH_OF_THE_NAME_IS_REQUIRED_LENGTH$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_IMPORT_WALLET_HOME_IMPORT_WALLET_COMPONENT_TS__21;
    } else {
      i18n_20 = " The maximum length of the name is " + "\uFFFD0\uFFFD" + " ";
    }
    let i18n_22;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_PLEASE_INPUT_THE_PASSWORD$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_IMPORT_WALLET_HOME_IMPORT_WALLET_COMPONENT_TS__23 = goog.getMsg("Please input the password");
      i18n_22 = MSG_EXTERNAL_PLEASE_INPUT_THE_PASSWORD$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_IMPORT_WALLET_HOME_IMPORT_WALLET_COMPONENT_TS__23;
    } else {
      i18n_22 = "Please input the password";
    }
    let i18n_24;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_THE_PASSWORD_IS_AT_LEAST_CHARACTERS_LONG$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_IMPORT_WALLET_HOME_IMPORT_WALLET_COMPONENT_TS__25 = goog.getMsg(" The password is at least {$interpolation} characters long ", {
        "interpolation": "\uFFFD0\uFFFD"
      }, {
        original_code: {
          "interpolation": "{{ error.requiredLength }}"
        }
      });
      i18n_24 = MSG_EXTERNAL_THE_PASSWORD_IS_AT_LEAST_CHARACTERS_LONG$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_IMPORT_WALLET_HOME_IMPORT_WALLET_COMPONENT_TS__25;
    } else {
      i18n_24 = " The password is at least " + "\uFFFD0\uFFFD" + " characters long ";
    }
    let i18n_26;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_THE_MAXIMUM_LENGTH_OF_THE_PASSWORD_IS$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_IMPORT_WALLET_HOME_IMPORT_WALLET_COMPONENT_TS__27 = goog.getMsg(" The maximum length of the password is {$interpolation} ", {
        "interpolation": "\uFFFD0\uFFFD"
      }, {
        original_code: {
          "interpolation": "{{ error.requiredLength }}"
        }
      });
      i18n_26 = MSG_EXTERNAL_THE_MAXIMUM_LENGTH_OF_THE_PASSWORD_IS$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_IMPORT_WALLET_HOME_IMPORT_WALLET_COMPONENT_TS__27;
    } else {
      i18n_26 = " The maximum length of the password is " + "\uFFFD0\uFFFD" + " ";
    }
    let i18n_28;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_THE_PASSWORD_CANNOT_CONTAINER_SPACES$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_IMPORT_WALLET_HOME_IMPORT_WALLET_COMPONENT_TS__29 = goog.getMsg(" The password cannot container spaces ! ");
      i18n_28 = MSG_EXTERNAL_THE_PASSWORD_CANNOT_CONTAINER_SPACES$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_IMPORT_WALLET_HOME_IMPORT_WALLET_COMPONENT_TS__29;
    } else {
      i18n_28 = " The password cannot container spaces ! ";
    }
    let i18n_30;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_PLEASE_INPUT_THE_PASSWORD_AGAIN$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_IMPORT_WALLET_HOME_IMPORT_WALLET_COMPONENT_TS__31 = goog.getMsg("Please input the password again");
      i18n_30 = MSG_EXTERNAL_PLEASE_INPUT_THE_PASSWORD_AGAIN$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_IMPORT_WALLET_HOME_IMPORT_WALLET_COMPONENT_TS__31;
    } else {
      i18n_30 = "Please input the password again";
    }
    let i18n_32;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_TWO_INPUTSDO_NOT_MATCH$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_IMPORT_WALLET_HOME_IMPORT_WALLET_COMPONENT_TS__33 = goog.getMsg("Two inputs don't match!");
      i18n_32 = MSG_EXTERNAL_TWO_INPUTSDO_NOT_MATCH$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_IMPORT_WALLET_HOME_IMPORT_WALLET_COMPONENT_TS__33;
    } else {
      i18n_32 = "Two inputs don't match!";
    }
    let i18n_34;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_THIS_PASSWORD_IS_ONLY_USED_FOR_THE_SECURITY_PROTECTION_OF_THE_WALLET_COT_WILL_NOT_SAVE_YOUR_PASSWORD_NOR_WILL_IT_BE_ABLE_TO_HELP_YOU_RETRIEVE_IT_PLEASE_REMEMBER_AND_KEEP_YOUR_PASSWORD$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_IMPORT_WALLET_HOME_IMPORT_WALLET_COMPONENT_TS__35 = goog.getMsg(" This password is only used for the security protection of the wallet. COT will not save your password, nor will it be able to help you retrieve it. Please remember and keep your password! ");
      i18n_34 = MSG_EXTERNAL_THIS_PASSWORD_IS_ONLY_USED_FOR_THE_SECURITY_PROTECTION_OF_THE_WALLET_COT_WILL_NOT_SAVE_YOUR_PASSWORD_NOR_WILL_IT_BE_ABLE_TO_HELP_YOU_RETRIEVE_IT_PLEASE_REMEMBER_AND_KEEP_YOUR_PASSWORD$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_IMPORT_WALLET_HOME_IMPORT_WALLET_COMPONENT_TS__35;
    } else {
      i18n_34 = " This password is only used for the security protection of the wallet. COT will not save your password, nor will it be able to help you retrieve it. Please remember and keep your password! ";
    }
    let i18n_36;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_THE_MAXIMUM_LENGTH_OF_THE_HINT_IS$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_IMPORT_WALLET_HOME_IMPORT_WALLET_COMPONENT_TS___37 = goog.getMsg(" The maximum length of the hint is {$interpolation} ", {
        "interpolation": "\uFFFD0\uFFFD"
      }, {
        original_code: {
          "interpolation": "{{errors?.['maxlength']?.requiredLength}}"
        }
      });
      i18n_36 = MSG_EXTERNAL_THE_MAXIMUM_LENGTH_OF_THE_HINT_IS$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_IMPORT_WALLET_HOME_IMPORT_WALLET_COMPONENT_TS___37;
    } else {
      i18n_36 = " The maximum length of the hint is " + "\uFFFD0\uFFFD" + " ";
    }
    return [[3, "open", "backgroundClass", "tips"], [3, "contentSafeArea", 6, "headerTitle"], ["headerTitle", i18n_0], [3, "formGroup", "ngSubmit"], [1, "flex", "h-10", "w-full", "items-end", "justify-between", "text-xs", "font-semibold"], [1, "flex-shrink-0", "pr-2", 3, "ngClass"], [1, "bg-env", "mt-1", "flex", "rounded-lg", "py-2"], ["class", "w-full px-2", "rows", "3", "formControlName", "importValue", 3, "placeholder", "ngModelChange", 4, "ngIf"], [1, "mb-2", "flex", "h-10", "w-full", "items-end", "justify-between", "text-xs", "font-semibold"], i18n_2, [1, "text-error", "text-xss", "text-right", 3, "wSwitchErrors"], ["wCaseKey", "trimRequired"], ["wCaseKey", "maxlength"], [1, "bg-env", "flex", "h-10", "rounded-lg"], ["formControlName", "name", "type", "text", "placeholder", i18n_4, 1, "w-full", "pl-2"], i18n_6, ["scope", "pwd", "wCaseKey", "required"], ["scope", "pwd", "wCaseKey", "minlength"], ["scope", "pwd", "wCaseKey", "maxlength"], ["scope", "pwd", "wCaseKey", "whitespace"], ["scope", "cpwd", "wCaseKey", "required"], ["scope", "cpwd", "wCaseKey", "equals"], [3, "wCaseDefault"], [1, "bg-env", "flex", "h-10", "items-center", "rounded-lg", "pr-4"], ["formControlName", "pwd", "placeholder", i18n_8, 1, "w-full", "pl-2", 3, "type", "focus", "blur"], [1, "text-subtext", "text-2xl", 3, "show", "showChange"], ["class", "text-error my-2 text-xs", 4, "ngIf"], [1, "bg-env", "mt-2", "flex", "h-10", "items-center", "rounded-lg", "pr-4"], ["formControlName", "cpwd", "placeholder", i18n_10, 1, "w-full", "pl-2", 3, "type"], i18n_12, ["class", "text-error text-xss text-right", 4, "ngIf"], ["formControlName", "tip", "type", "text", "placeholder", i18n_14, 1, "w-full", "pl-2"], ["footer", "", 1, "w-full", 3, "formGroup", "ngSubmit"], ["bnRippleButton", "", "type", "submit", 1, "h-10.5", "bg-primary-2", "w-full", "rounded-full", "text-center", "text-sm", "text-white", 3, "disabled"], i18n_16, ["rows", "3", "formControlName", "importValue", 1, "w-full", "px-2", 3, "placeholder", "ngModelChange"], ["textarea", ""], i18n_18, i18n_20, i18n_22, i18n_24, i18n_26, i18n_28, i18n_30, i18n_32, [1, "text-error", "my-2", "text-xs"], ["name", "warn-grey", 1, "icon-4"], i18n_34, [1, "text-error", "text-xss", "text-right"], [4, "ngIf"], i18n_36];
  },
  template: function HomeImportWalletPage_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelement"](0, "w-form-validation-top-tips", 0);
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](1, "common-page", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵi18nAttributes"](2, 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](3, "form", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵlistener"]("ngSubmit", function HomeImportWalletPage_Template_form_ngSubmit_3_listener() {
        return ctx.onSubmit();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](4, "fieldset")(5, "legend", 4)(6, "div", 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵpipe"](7, "errors");
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtext"](8);
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](9, "div", 6);
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtemplate"](10, HomeImportWalletPage_textarea_10_Template, 2, 1, "textarea", 7);
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](11, "fieldset")(12, "legend", 8)(13, "div", 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵi18n"](14, 9);
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵpipe"](15, "errors");
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](16, "div", 10);
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtemplate"](17, HomeImportWalletPage_ng_template_17_Template, 2, 0, "ng-template", 11)(18, HomeImportWalletPage_ng_template_18_Template, 2, 1, "ng-template", 12);
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](19, "div", 13);
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelement"](20, "input", 14);
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](21, "fieldset")(22, "legend", 8)(23, "div", 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵi18n"](24, 15);
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵpipe"](25, "errors");
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵpipe"](26, "errors");
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](27, "div", 10);
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtemplate"](28, HomeImportWalletPage_ng_template_28_Template, 2, 0, "ng-template", 16)(29, HomeImportWalletPage_ng_template_29_Template, 2, 1, "ng-template", 17)(30, HomeImportWalletPage_ng_template_30_Template, 2, 1, "ng-template", 18)(31, HomeImportWalletPage_ng_template_31_Template, 2, 0, "ng-template", 19)(32, HomeImportWalletPage_ng_template_32_Template, 2, 0, "ng-template", 20)(33, HomeImportWalletPage_ng_template_33_Template, 2, 0, "ng-template", 21)(34, HomeImportWalletPage_ng_template_34_Template, 1, 1, "ng-template", 22);
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](35, "div", 23)(36, "input", 24);
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵlistener"]("focus", function HomeImportWalletPage_Template_input_focus_36_listener() {
        return ctx.openPwdTip(true);
      })("blur", function HomeImportWalletPage_Template_input_blur_36_listener() {
        return ctx.openPwdTip(false);
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](37, "w-input-hidden-icon-swap", 25);
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵlistener"]("showChange", function HomeImportWalletPage_Template_w_input_hidden_icon_swap_showChange_37_listener($event) {
        return ctx.showPwd = $event;
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵpipe"](38, "color");
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtemplate"](39, HomeImportWalletPage_div_39_Template, 4, 0, "div", 26);
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](40, "div", 27);
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelement"](41, "input", 28);
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](42, "w-input-hidden-icon-swap", 25);
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵlistener"]("showChange", function HomeImportWalletPage_Template_w_input_hidden_icon_swap_showChange_42_listener($event) {
        return ctx.showCPwd = $event;
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵpipe"](43, "color");
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]()()();
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](44, "fieldset")(45, "legend", 8)(46, "div", 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵi18n"](47, 29);
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵpipe"](48, "errors");
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtemplate"](49, HomeImportWalletPage_div_49_Template, 2, 1, "div", 30);
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵpipe"](50, "errors");
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](51, "div", 13);
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelement"](52, "input", 31);
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]()()();
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](53, "form", 32);
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵlistener"]("ngSubmit", function HomeImportWalletPage_Template_form_ngSubmit_53_listener() {
        return ctx.onSubmit();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](54, "button", 33);
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵi18n"](55, 34);
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]()()();
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵproperty"]("open", ctx.showMneTip && !(ctx.importValue.errors == null ? null : ctx.importValue.errors["required"]))("backgroundClass", "bg-error")("tips", ctx.mneTip);
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵi18nExp"](ctx.symbol);
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵi18nApply"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵproperty"]("contentSafeArea", true);
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵproperty"]("formGroup", ctx.form);
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵpureFunction1"](44, _c38, _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵpipeBind1"](7, 28, ctx.importValue)));
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtextInterpolate1"](" ", ctx.importTypeLabel, " ");
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵproperty"]("ngIf", ctx.importType);
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵpureFunction1"](46, _c38, _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵpipeBind1"](15, 30, ctx.name)));
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵproperty"]("wSwitchErrors", ctx.name);
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](7);
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵpureFunction1"](48, _c38, _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵpipeBind1"](25, 32, ctx.pwd) || _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵpipeBind1"](26, 34, ctx.cpwd)));
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](4);
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵproperty"]("wSwitchErrors", _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵpureFunction2"](50, _c39, ctx.pwd, ctx.cpwd));
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](9);
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵproperty"]("type", ctx.showPwd ? "text" : "password");
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵpureFunction1"](53, _c40, _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵpipeBind1"](38, 36, "subtext")));
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵproperty"]("show", ctx.showPwd);
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵproperty"]("ngIf", ctx.showPwdTip);
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵproperty"]("type", ctx.showCPwd ? "text" : "password");
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵpureFunction1"](55, _c40, _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵpipeBind1"](43, 38, "subtext")));
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵproperty"]("show", ctx.showCPwd);
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](4);
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵpureFunction1"](57, _c38, _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵpipeBind1"](48, 40, ctx.tip)));
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵproperty"]("ngIf", _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵpipeBind1"](50, 42, ctx.tip));
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](4);
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵproperty"]("formGroup", ctx.form);
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵclassProp"]("opacity-30", !ctx.form.valid);
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵproperty"]("disabled", !ctx.form.valid);
    }
  },
  dependencies: [_modules_page_module__WEBPACK_IMPORTED_MODULE_4__.CommonPageModule, _libs_bnf_components_ripple_button_ripple_button_directive__WEBPACK_IMPORTED_MODULE_9__.RippleButtonDirective, _libs_bnf_directives_form_errors_directive__WEBPACK_IMPORTED_MODULE_10__.SwitchErrorsDirective, _libs_bnf_directives_form_errors_directive__WEBPACK_IMPORTED_MODULE_10__.SwitchCaseDirective, _libs_bnf_directives_form_errors_directive__WEBPACK_IMPORTED_MODULE_10__.SwitchDefaultDirective, _libs_bnf_directives_auto_complete_off_directive__WEBPACK_IMPORTED_MODULE_11__.AutoCompleteOffDirective, _angular_common__WEBPACK_IMPORTED_MODULE_19__.NgClass, _angular_common__WEBPACK_IMPORTED_MODULE_19__.NgIf, _angular_forms__WEBPACK_IMPORTED_MODULE_18__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_18__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_18__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_18__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_18__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_18__.FormControlName, _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_12__.CommonPageComponent, _components_icon_icon_component__WEBPACK_IMPORTED_MODULE_13__.IconComponent, _components_form_validation_top_tips_form_validation_top_tips_component__WEBPACK_IMPORTED_MODULE_14__.FormValidationTopTipsComponent, _libs_bnf_pipes_errors_errors_pipe__WEBPACK_IMPORTED_MODULE_15__.ErrorsPipe, _pipes_color_color_pipe__WEBPACK_IMPORTED_MODULE_16__.ColorPipe, _components_input_hidden_icon_swap_input_hidden_icon_swap_component__WEBPACK_IMPORTED_MODULE_3__["default"]],
  styles: ["/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsInNvdXJjZVJvb3QiOiIifQ== */"],
  changeDetection: 0
});
(0,tslib__WEBPACK_IMPORTED_MODULE_20__.__decorate)([HomeImportWalletPage.QueryParam('chain'), (0,tslib__WEBPACK_IMPORTED_MODULE_20__.__metadata)("design:type", String)], HomeImportWalletPage.prototype, "chain", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_20__.__decorate)([HomeImportWalletPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_20__.__metadata)("design:type", Object)], HomeImportWalletPage.prototype, "showPwdTip", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_20__.__decorate)([HomeImportWalletPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_20__.__metadata)("design:type", Object)], HomeImportWalletPage.prototype, "showMneTip", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_20__.__decorate)([HomeImportWalletPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_20__.__metadata)("design:type", Object)], HomeImportWalletPage.prototype, "pwdTip", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_20__.__decorate)([HomeImportWalletPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_20__.__metadata)("design:type", Object)], HomeImportWalletPage.prototype, "mneTip", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_20__.__decorate)([HomeImportWalletPage.State(), HomeImportWalletPage.QueryParam('symbol'), (0,tslib__WEBPACK_IMPORTED_MODULE_20__.__metadata)("design:type", String)], HomeImportWalletPage.prototype, "symbol", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_20__.__decorate)([HomeImportWalletPage.QueryParam('walletName'), (0,tslib__WEBPACK_IMPORTED_MODULE_20__.__metadata)("design:type", String), (0,tslib__WEBPACK_IMPORTED_MODULE_20__.__metadata)("design:paramtypes", [String])], HomeImportWalletPage.prototype, "walletName", null);
(0,tslib__WEBPACK_IMPORTED_MODULE_20__.__decorate)([HomeImportWalletPage.State(), HomeImportWalletPage.QueryParam('type'), (0,tslib__WEBPACK_IMPORTED_MODULE_20__.__metadata)("design:type", Object)], HomeImportWalletPage.prototype, "importType", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_20__.__decorate)([HomeImportWalletPage.QueryParam('notMainWalletKey'), (0,tslib__WEBPACK_IMPORTED_MODULE_20__.__metadata)("design:type", Object)], HomeImportWalletPage.prototype, "notMainWalletKey", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_20__.__decorate)([HomeImportWalletPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_20__.__metadata)("design:type", Object)], HomeImportWalletPage.prototype, "showPwd", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_20__.__decorate)([HomeImportWalletPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_20__.__metadata)("design:type", Object)], HomeImportWalletPage.prototype, "showCPwd", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_20__.__decorate)([HomeImportWalletPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_20__.__metadata)("design:type", Object)], HomeImportWalletPage.prototype, "name", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_20__.__decorate)([HomeImportWalletPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_20__.__metadata)("design:type", Object)], HomeImportWalletPage.prototype, "importValue", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_20__.__decorate)([HomeImportWalletPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_20__.__metadata)("design:type", Object)], HomeImportWalletPage.prototype, "pwd", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_20__.__decorate)([HomeImportWalletPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_20__.__metadata)("design:type", Object)], HomeImportWalletPage.prototype, "cpwd", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_20__.__decorate)([HomeImportWalletPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_20__.__metadata)("design:type", Object)], HomeImportWalletPage.prototype, "tip", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_20__.__decorate)([HomeImportWalletPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_20__.__metadata)("design:type", Object)], HomeImportWalletPage.prototype, "form", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_20__.__decorate)([HomeImportWalletPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_20__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_20__.__metadata)("design:paramtypes", [Boolean]), (0,tslib__WEBPACK_IMPORTED_MODULE_20__.__metadata)("design:returntype", void 0)], HomeImportWalletPage.prototype, "openPwdTip", null);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (HomeImportWalletPage);

/***/ })

}]);
//# sourceMappingURL=default-apps_wallet_src_pages_home_pages_home-import-wallet_home-import-wallet_component_ts.js.map