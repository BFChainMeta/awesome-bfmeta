"use strict";
(self["webpackChunkwallet"] = self["webpackChunkwallet"] || []).push([["default-apps_wallet_src_pages_home_pages_home-main-wallet-edit_home-main-wallet-edit_component_ts"],{

/***/ 22486:
/*!***************************************************************************************************!*\
  !*** ./apps/wallet/src/pages/home/pages/home-main-wallet-edit/home-main-wallet-edit.component.ts ***!
  \***************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   HomeMainWalletEditPage: () => (/* binding */ HomeMainWalletEditPage),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 52542);
/* harmony import */ var D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncIterator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/esm/asyncIterator.js */ 9243);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! tslib */ 90505);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/core */ 61039);
/* harmony import */ var _bnqkl_framework_controllers__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @bnqkl/framework/controllers */ 47919);
/* harmony import */ var _bnqkl_framework_plugins__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @bnqkl/framework/plugins */ 43990);
/* harmony import */ var _bnqkl_wallet_base_services_wallet__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @bnqkl/wallet-base/services/wallet */ 20609);
/* harmony import */ var _modules_page_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ~modules/page.module */ 77538);
/* harmony import */ var _pages_mnemonic_pages_mnemonic_confirm_backup_mnemonic_confirm_backup_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ~pages/mnemonic/pages/mnemonic-confirm-backup/mnemonic-confirm-backup.component */ 91879);
/* harmony import */ var _services_permission_permission_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ~services/permission/permission.service */ 26502);
/* harmony import */ var _home_select_wallet_home_select_wallet_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../home-select-wallet/home-select-wallet.component */ 57278);
/* harmony import */ var _libs_bnf_modules_bottom_sheet_components_bottom_sheet_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../../../../../../libs/bnf/modules/bottom-sheet/components/bottom-sheet.component */ 94072);
/* harmony import */ var _libs_bnf_components_ripple_button_ripple_button_directive__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../../../../../../libs/bnf/components/ripple-button/ripple-button.directive */ 16505);
/* harmony import */ var _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../../../../../../libs/bnf/modules/page/common-page/common-page.component */ 62052);
/* harmony import */ var _components_icon_icon_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../../../components/icon/icon.component */ 74703);
/* harmony import */ var _pipes_color_color_pipe__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../../../../pipes/color/color.pipe */ 76489);


var _class;















const _c8 = a0 => ({
  "--color-1": a0
});
function HomeMainWalletEditPage_Conditional_16_Conditional_5_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](0, "div", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelement"](1, "w-icon", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipe"](2, "color");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](3, "span", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵi18n"](4, 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpureFunction1"](4, _c8, _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipeBind1"](2, 2, "error")));
  }
}
function HomeMainWalletEditPage_Conditional_16_Template(rf, ctx) {
  if (rf & 1) {
    const _r7 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](0, "button", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵlistener"]("click", function HomeMainWalletEditPage_Conditional_16_Template_button_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵrestoreView"](_r7);
      const ctx_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵresetView"](ctx_r6.backup());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](1, "div", 6)(2, "span", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵi18n"](3, 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](4, "div", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtemplate"](5, HomeMainWalletEditPage_Conditional_16_Conditional_5_Template, 5, 6, "div", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelement"](6, "w-icon", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipe"](7, "color");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵconditional"](5, !!(ctx_r0.mainWallet == null ? null : ctx_r0.mainWallet.skipBackup) ? 5 : -1);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpureFunction1"](6, _c8, _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipeBind1"](7, 4, "subtext")));
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("name", "right");
  }
}
function HomeMainWalletEditPage_Conditional_17_Template(rf, ctx) {
  if (rf & 1) {
    const _r9 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](0, "button", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵlistener"]("click", function HomeMainWalletEditPage_Conditional_17_Template_button_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵrestoreView"](_r9);
      const ctx_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵresetView"](ctx_r8.viewPrivateKey());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](1, "div", 6)(2, "span", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵi18n"](3, 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](4, "div", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelement"](5, "w-icon", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipe"](6, "color");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpureFunction1"](5, _c8, _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipeBind1"](6, 3, "subtext")));
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("name", "right");
  }
}
function HomeMainWalletEditPage_Conditional_18_Template(rf, ctx) {
  if (rf & 1) {
    const _r11 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](0, "button", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵlistener"]("click", function HomeMainWalletEditPage_Conditional_18_Template_button_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵrestoreView"](_r11);
      const ctx_r10 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵresetView"](ctx_r10.goBioforestChain());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](1, "div", 6)(2, "span", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵi18n"](3, 26);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](4, "div", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelement"](5, "w-icon", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipe"](6, "color");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpureFunction1"](5, _c8, _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipeBind1"](6, 3, "subtext")));
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("name", "right");
  }
}
function HomeMainWalletEditPage_ng_template_24_Template(rf, ctx) {
  if (rf & 1) {
    const _r14 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](0, "common-page", 27, 28)(2, "div", 29)(3, "div", 30)(4, "button", 31);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵlistener"]("click", function HomeMainWalletEditPage_ng_template_24_Template_button_click_4_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵrestoreView"](_r14);
      const ctx_r13 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵresetView"](ctx_r13.deleteWallet(false));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](5, "div", 32);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵi18n"](6, 33);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](7, "button", 31);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵlistener"]("click", function HomeMainWalletEditPage_ng_template_24_Template_button_click_7_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵrestoreView"](_r14);
      const ctx_r15 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵresetView"](ctx_r15.deleteWallet(true));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](8, "div", 32);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](9);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](10, "div")(11, "button", 34);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵlistener"]("click", function HomeMainWalletEditPage_ng_template_24_Template_button_click_11_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵrestoreView"](_r14);
      const ctx_r16 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵresetView"](ctx_r16.deleteWalletBottomSheetInfo.open = false);
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵi18n"](12, 35);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]()()()();
  }
  if (rf & 2) {
    const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("hideHeader", true);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵi18nExp"](ctx_r3.mainWallet == null ? null : ctx_r3.mainWallet.name);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵi18nApply"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtextInterpolate1"](" ", ctx_r3.exitAllWalletText, " ");
  }
}
function HomeMainWalletEditPage_ng_template_26_Template(rf, ctx) {
  if (rf & 1) {
    const _r18 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](0, "w-home-select-wallet-page", 36);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵlistener"]("returnValue$", function HomeMainWalletEditPage_ng_template_26_Template_w_home_select_wallet_page_returnValue__0_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵrestoreView"](_r18);
      const ctx_r17 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵresetView"](ctx_r17.onSelectMainWallet($event));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("mainWalletList", ctx_r4.sheet_selectWallet.mainWalletList)("activateMainWalletId", ctx_r4.mainWalletId)("hiddenAdd", true)("hiddenEdit", true);
  }
}
class HomeMainWalletEditPage extends _modules_page_module__WEBPACK_IMPORTED_MODULE_5__.CommonPageBase {
  constructor() {
    super(...arguments);
    /** 页面返回值的类型 */
    this.returnValue$ = new _modules_page_module__WEBPACK_IMPORTED_MODULE_5__.PageReturnValue();
    /** 权限服务 */
    this._permissionService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_14__.inject)(_services_permission_permission_service__WEBPACK_IMPORTED_MODULE_7__.PermissionService);
    this.chainV2Service = (0,_angular_core__WEBPACK_IMPORTED_MODULE_14__.inject)(_bnqkl_wallet_base_services_wallet__WEBPACK_IMPORTED_MODULE_4__.ChainV2Service);
    /** 传入的钱包ID */
    this.mainWalletId = '';
    /**
     * 备份后更新数据
     */
    this.mnemonicConfirmBackupPageReturnController = new _bnqkl_framework_controllers__WEBPACK_IMPORTED_MODULE_2__.PageReturnController(this, _pages_mnemonic_pages_mnemonic_confirm_backup_mnemonic_confirm_backup_component__WEBPACK_IMPORTED_MODULE_6__["default"]);
    this.deleteWalletBottomSheetInfo = {
      open: false
    };
    /** 钱包选择器的数据 */
    this.sheet_selectWallet = {
      is_open: false,
      mainWalletList: undefined
    };
  }
  init() {
    var _this = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const walletDataStorageV2Service = _this.injectorForceGet(_bnqkl_wallet_base_services_wallet__WEBPACK_IMPORTED_MODULE_4__.WalletDataStorageV2Service);
      _this.mainWallet = yield walletDataStorageV2Service.getMainWalletInfo(_this.mainWalletId);
    })();
  }
  /** 显示私钥 */
  get showViewPrivateKey() {
    var _this$mainWallet;
    return !!((_this$mainWallet = this.mainWallet) !== null && _this$mainWallet !== void 0 && _this$mainWallet.addressKeyList.filter(item => this.chainV2Service.isBioforestChainByChainName(item.chainName) === false).length);
  }
  /** 查看私钥 */
  viewPrivateKey() {
    var _this2 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const pwdInfo = yield _this2._permissionService.requestPassword();
      if (pwdInfo === null || pwdInfo === false) {
        return;
      }
      _this2.nav.routeTo('home-import-private-key-wallet-before', {
        viewPrivateKey: true,
        mainWalletId: _this2.mainWalletId
      });
    })();
  }
  /** 显示生物链 */
  get showBioforestChain() {
    var _this$mainWallet2;
    return !!((_this$mainWallet2 = this.mainWallet) !== null && _this$mainWallet2 !== void 0 && _this$mainWallet2.addressKeyList.filter(item => this.chainV2Service.isBioforestChainByChainName(item.chainName)).length);
  }
  /** 查看私钥 */
  goBioforestChain() {
    var _this3 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this3.nav.routeTo('home-import-private-key-wallet-before', {
        viewBioforestChain: true,
        mainWalletId: _this3.mainWalletId
      });
    })();
  }
  /** 显示备份 */
  get showBackup() {
    var _this$mainWallet3;
    return ((_this$mainWallet3 = this.mainWallet) === null || _this$mainWallet3 === void 0 ? void 0 : _this$mainWallet3.importType) === _bnqkl_wallet_base_services_wallet__WEBPACK_IMPORTED_MODULE_4__.WALLET_IMPORT_TYPE.mnemonic;
  }
  /** 修改名字 */
  editName() {
    var _this4 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const result = yield _this4.prompt({
        headerTitle: "Modify name",
        value: _this4.mainWallet.name
      });
      if (result === null) {
        return;
      }
      const newUserNickName = result.trim();
      if (newUserNickName.length > 12 || newUserNickName.length === 0) {
        _bnqkl_framework_plugins__WEBPACK_IMPORTED_MODULE_3__.Toast.show("wallet name must be 1~12 characters long");
        return;
      }
      const oldName = _this4.mainWallet.name;
      /** 引入钱包本地存储服务 */
      const walletDataStorageV2Service = _this4.injectorForceGet(_bnqkl_wallet_base_services_wallet__WEBPACK_IMPORTED_MODULE_4__.WalletDataStorageV2Service);
      const oldMainWallet = yield walletDataStorageV2Service.getMainWalletInfo(_this4.mainWalletId);
      if (_this4.mainWallet && oldMainWallet) {
        try {
          oldMainWallet.name = _this4.mainWallet.name = newUserNickName;
          yield walletDataStorageV2Service.saveMainWalletInfo(oldMainWallet);
          _bnqkl_framework_plugins__WEBPACK_IMPORTED_MODULE_3__.Toast.show("success");
          _this4.mainWallet.name = newUserNickName;
          _this4.returnValue$.next(_this4.mainWallet);
        } catch (err) {
          _this4.mainWallet.name = oldName;
          _this4.console.error(err);
          _bnqkl_framework_plugins__WEBPACK_IMPORTED_MODULE_3__.Toast.show("fail");
        }
      }
    })();
  }
  /** 备份 */
  backup() {
    var _this5 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      // 需要先验证密码
      const pwdInfo = yield _this5._permissionService.requestPassword();
      if (pwdInfo === false || pwdInfo === null) {
        return;
      }
      /** 引入钱包本地存储服务 */
      const walletDataStorage = _this5.injectorForceGet(_bnqkl_wallet_base_services_wallet__WEBPACK_IMPORTED_MODULE_4__.WalletDataStorageV2Service);
      /** 获取当前使用者的助记词 */
      const walleter = yield walletDataStorage.getMainWalletInfo(_this5.mainWalletId);
      if (walleter === undefined) {
        throw new Error(`not find wallet`);
      }
      let hasGoMnemonicBackup = false;
      if (hasGoMnemonicBackup === false) {
        /// 我们自己的链跳转到地址备份页面，但是助剂词不一定是地址密码，需要判断一下
        try {
          const bip39LibService = _this5.injectorForceGet(_bnqkl_wallet_base_services_wallet__WEBPACK_IMPORTED_MODULE_4__.Bip39LibService);
          yield bip39LibService.checkMnemonic(walleter.importPhrase);
          hasGoMnemonicBackup = true;
        } catch (err) {
          hasGoMnemonicBackup = false;
        }
      }
      if (hasGoMnemonicBackup) {
        _this5.nav.routeTo('/mnemonic/mnemonic-backup-tips', {
          export: true,
          backUrl: '/home-main-wallet-edit',
          mnemonicString: walleter.importPhrase,
          mainWalletId: _this5.mainWalletId,
          backup: true
        });
      } else {
        _this5.nav.routeTo('/mnemonic/address-password-tips', {
          export: true,
          backUrl: '/home-main-wallet-edit',
          mnemonicString: walleter.importPhrase
        });
      }
    })();
  }
  /** 初始化页面监听 */
  watchPageReturn() {
    var _this6 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this6.mnemonicConfirmBackupPageReturnController.pageReturn$.subscribe( /*#__PURE__*/function () {
        var _ref = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (data) {
          if (data.mainWalletId === _this6.mainWalletId) {
            /// 备份助剂词模式，更新数据
            const walletDataStorageV2Service = _this6.injectorForceGet(_bnqkl_wallet_base_services_wallet__WEBPACK_IMPORTED_MODULE_4__.WalletDataStorageV2Service);
            const mainWalletV2 = yield walletDataStorageV2Service.getMainWalletInfo(_this6.mainWalletId);
            if (_this6.mainWallet) {
              _this6.mainWallet.skipBackup = !!mainWalletV2.skipBackup;
            }
          }
        });
        return function (_x) {
          return _ref.apply(this, arguments);
        };
      }());
    })();
  }
  get exitAllWalletText() {
    return "Exit all wallet In " + APP_NAME + "";
  }
  /** 删除钱包 */
  deleteWallet(all) {
    var _this7 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this7.deleteWalletBottomSheetInfo.open = false;
      const walletDataStorageV2Service = _this7.injectorForceGet(_bnqkl_wallet_base_services_wallet__WEBPACK_IMPORTED_MODULE_4__.WalletDataStorageV2Service);
      if (all) {
        /// 找下是否有未备份
        const allMainWalletList = yield walletDataStorageV2Service.getAllMainWalletInfo();
        const notBackup = allMainWalletList.find(item => !!item.skipBackup);
        if (notBackup) {
          const confirmed = yield _this7.confirm({
            headerTitle: "Hint",
            bodyMessage: "There is an unbacked up wallet in " + APP_NAME + ". If you continue to exit, you may lose the wallet permanently. Are you sure you want to continue?",
            footerTheme: 'blank',
            confirmText: "Continue"
          });
          if (confirmed === false) {
            return;
          }
        }
        const confirmed = yield _this7.confirm({
          headerTitle: "Hint",
          bodyMessage: "After confirmation, " + APP_NAME + " will delete all local data and all wallets will be removed locally. Are you sure to exit?",
          footerTheme: 'blank'
        });
        if (confirmed === false) {
          return;
        }
        /// 校验密码
        const pwdInfo = yield _this7._permissionService.requestPassword();
        if (pwdInfo === false || pwdInfo === null) {
          return;
        }
        /// 删除钱包
        const walletV2Service = _this7.injectorForceGet(_bnqkl_wallet_base_services_wallet__WEBPACK_IMPORTED_MODULE_4__.WalletV2Service);
        yield walletV2Service.mainWalletSignOut();
        yield _this7.nav.setPageRoot('mnemonic');
        return _this7.returnValue$.next('delete');
      } else {
        const notBackup = _this7.mainWallet.skipBackup;
        if (notBackup) {
          const confirmed = yield _this7.confirm({
            headerTitle: "Hint",
            bodyMessage: "The wallet is not backed up. If you continue to exit, you may lose the wallet permanently. Are you sure you want to continue?",
            footerTheme: 'blank',
            confirmText: "Continue"
          });
          if (confirmed === false) {
            return;
          }
        }
        const confirmed = yield _this7.confirm({
          headerTitle: "Hint",
          bodyMessage: "After confirmation, this wallet data will be removed locally. Are you sure to exit?",
          footerTheme: 'blank'
        });
        if (confirmed === false) {
          return;
        }
        /// 校验密码
        const pwdInfo = yield _this7._permissionService.requestPassword();
        if (pwdInfo === false || pwdInfo === null) {
          return;
        }
        /// 删除该钱包
        yield walletDataStorageV2Service.removeMainWalletInfo(_this7.mainWalletId);
        /// 删除对应地址
        var _iteratorAbruptCompletion = false;
        var _didIteratorError = false;
        var _iteratorError;
        try {
          for (var _iterator = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncIterator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(_this7.mainWallet.addressKeyList), _step; _iteratorAbruptCompletion = !(_step = yield _iterator.next()).done; _iteratorAbruptCompletion = false) {
            const info = _step.value;
            {
              yield walletDataStorageV2Service.deleteChainAddressInfo(info.addressKey);
            }
          }
          /// 判断下是否没钱包了
        } catch (err) {
          _didIteratorError = true;
          _iteratorError = err;
        } finally {
          try {
            if (_iteratorAbruptCompletion && _iterator.return != null) {
              yield _iterator.return();
            }
          } finally {
            if (_didIteratorError) {
              throw _iteratorError;
            }
          }
        }
        const allMainWalletList = yield walletDataStorageV2Service.getAllMainWalletInfo();
        const notMainWallet = !allMainWalletList.length;
        if (notMainWallet) {
          const walletV2Service = _this7.injectorForceGet(_bnqkl_wallet_base_services_wallet__WEBPACK_IMPORTED_MODULE_4__.WalletV2Service);
          yield walletV2Service.mainWalletSignOut();
          yield _this7.nav.setPageRoot('mnemonic');
        } else {
          var _walletDataStorageV2S;
          /// 判断是否为当前激活地址
          if (((_walletDataStorageV2S = walletDataStorageV2Service.walletAppSettings.lastWalletActivate) === null || _walletDataStorageV2S === void 0 ? void 0 : _walletDataStorageV2S.mainWalletId) === _this7.mainWalletId) {
            const walletV2Service = _this7.injectorForceGet(_bnqkl_wallet_base_services_wallet__WEBPACK_IMPORTED_MODULE_4__.WalletV2Service);
            const defaultChain = walletV2Service.getAppDefaultChainName();
            const defaultMainWallet = allMainWalletList[0];
            const defaultAddressInfo = defaultMainWallet.addressKeyList.find(item => {
              if (item.chainName === defaultChain) {
                return true;
              }
              return false;
            });
            const activate = defaultAddressInfo !== null && defaultAddressInfo !== void 0 ? defaultAddressInfo : defaultMainWallet.addressKeyList[0];
            const addressInfo = yield walletDataStorageV2Service.getChainAddressInfo(activate.addressKey);
            walletDataStorageV2Service.walletAppSettings.lastWalletActivate = addressInfo;
            yield walletV2Service.upDateActivateAddressWallet(addressInfo);
          }
          yield _this7.nav.routeBack('tabs');
        }
        return _this7.returnValue$.next('delete');
      }
    })();
  }
  /** 打开钱包选择器 */
  openSelectWallet() {
    var _this8 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const {
        sheet_selectWallet
      } = _this8;
      if (sheet_selectWallet.is_open) {
        return;
      }
      const walletDataStorageV2Service = _this8.injectorForceGet(_bnqkl_wallet_base_services_wallet__WEBPACK_IMPORTED_MODULE_4__.WalletDataStorageV2Service);
      sheet_selectWallet.mainWalletList = yield walletDataStorageV2Service.getAllMainWalletInfo();
      sheet_selectWallet.is_open = true;
    })();
  }
  checkHomeSelectWalletOpen(open) {
    const {
      sheet_selectWallet
    } = this;
    if (open && sheet_selectWallet.is_open) {
      return;
    }
    sheet_selectWallet.is_open = open;
  }
  /** 切换身份钱包 */
  onSelectMainWallet(selectMainWallet) {
    var _this9 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      if (selectMainWallet) {
        /// 更换了激活的钱包，需要更新下数据a
        const walletDataStorageV2Service = _this9.injectorForceGet(_bnqkl_wallet_base_services_wallet__WEBPACK_IMPORTED_MODULE_4__.WalletDataStorageV2Service);
        _this9.mainWallet = yield walletDataStorageV2Service.getMainWalletInfo(selectMainWallet.mainWalletId);
        _this9.mainWalletId = selectMainWallet.mainWalletId;
      }
    })();
  }
}
_class = HomeMainWalletEditPage;
_class.ɵfac = /*@__PURE__*/(() => {
  let ɵHomeMainWalletEditPage_BaseFactory;
  return function HomeMainWalletEditPage_Factory(t) {
    return (ɵHomeMainWalletEditPage_BaseFactory || (ɵHomeMainWalletEditPage_BaseFactory = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵgetInheritedFactory"](_class)))(t || _class);
  };
})();
_class.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵdefineComponent"]({
  type: _class,
  selectors: [["w-home-main-wallet-edit-page"]],
  inputs: {
    mainWalletId: "mainWalletId"
  },
  outputs: {
    returnValue$: "returnValue$"
  },
  standalone: true,
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵInheritDefinitionFeature"], _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵStandaloneFeature"]],
  decls: 27,
  vars: 24,
  consts: () => {
    let i18n_0;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_MODIFY_NAME$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_MAIN_WALLET_EDIT_HOME_MAIN_WALLET_EDIT_COMPONENT_TS_1 = goog.getMsg("Modify name");
      i18n_0 = MSG_EXTERNAL_MODIFY_NAME$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_MAIN_WALLET_EDIT_HOME_MAIN_WALLET_EDIT_COMPONENT_TS_1;
    } else {
      i18n_0 = "Modify name";
    }
    let i18n_2;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_DELETE_WALLET$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_MAIN_WALLET_EDIT_HOME_MAIN_WALLET_EDIT_COMPONENT_TS_3 = goog.getMsg("Delete Wallet");
      i18n_2 = MSG_EXTERNAL_DELETE_WALLET$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_MAIN_WALLET_EDIT_HOME_MAIN_WALLET_EDIT_COMPONENT_TS_3;
    } else {
      i18n_2 = "Delete Wallet";
    }
    let i18n_4;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_BACKUP_MNEMONIC$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_MAIN_WALLET_EDIT_HOME_MAIN_WALLET_EDIT_COMPONENT_TS__5 = goog.getMsg("Backup mnemonic");
      i18n_4 = MSG_EXTERNAL_BACKUP_MNEMONIC$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_MAIN_WALLET_EDIT_HOME_MAIN_WALLET_EDIT_COMPONENT_TS__5;
    } else {
      i18n_4 = "Backup mnemonic";
    }
    let i18n_6;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_NO_BACKUP$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_MAIN_WALLET_EDIT_HOME_MAIN_WALLET_EDIT_COMPONENT_TS___7 = goog.getMsg("No Backup");
      i18n_6 = MSG_EXTERNAL_NO_BACKUP$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_MAIN_WALLET_EDIT_HOME_MAIN_WALLET_EDIT_COMPONENT_TS___7;
    } else {
      i18n_6 = "No Backup";
    }
    let i18n_9;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_VIEW_PRIVATE_KEY$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_MAIN_WALLET_EDIT_HOME_MAIN_WALLET_EDIT_COMPONENT_TS__10 = goog.getMsg("View private key");
      i18n_9 = MSG_EXTERNAL_VIEW_PRIVATE_KEY$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_MAIN_WALLET_EDIT_HOME_MAIN_WALLET_EDIT_COMPONENT_TS__10;
    } else {
      i18n_9 = "View private key";
    }
    let i18n_11;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_BIOFOREST_CHAIN_TRANSACTION_PASSWORD$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_MAIN_WALLET_EDIT_HOME_MAIN_WALLET_EDIT_COMPONENT_TS__12 = goog.getMsg("Bioforest Chain transaction password");
      i18n_11 = MSG_EXTERNAL_BIOFOREST_CHAIN_TRANSACTION_PASSWORD$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_MAIN_WALLET_EDIT_HOME_MAIN_WALLET_EDIT_COMPONENT_TS__12;
    } else {
      i18n_11 = "Bioforest Chain transaction password";
    }
    let i18n_13;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_EXIT__MAINWALLET_$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_MAIN_WALLET_EDIT_HOME_MAIN_WALLET_EDIT_COMPONENT_TS__14 = goog.getMsg(" Exit \"{$interpolation}\" ", {
        "interpolation": "\uFFFD0\uFFFD"
      }, {
        original_code: {
          "interpolation": "{{ mainWallet?.name }}"
        }
      });
      i18n_13 = MSG_EXTERNAL_EXIT__MAINWALLET_$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_MAIN_WALLET_EDIT_HOME_MAIN_WALLET_EDIT_COMPONENT_TS__14;
    } else {
      i18n_13 = " Exit \"" + "\uFFFD0\uFFFD" + "\" ";
    }
    let i18n_15;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_CANCEL$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_MAIN_WALLET_EDIT_HOME_MAIN_WALLET_EDIT_COMPONENT_TS__16 = goog.getMsg(" Cancel ");
      i18n_15 = MSG_EXTERNAL_CANCEL$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_MAIN_WALLET_EDIT_HOME_MAIN_WALLET_EDIT_COMPONENT_TS__16;
    } else {
      i18n_15 = " Cancel ";
    }
    return [[3, "titleColor", "contentSafeArea"], ["alt", "", "srcset", "", 1, "h-22", "w-22", "mx-auto", "mb-4", "mt-6", "rounded-full", 3, "src"], [1, "mb-2", "flex", "items-center", "justify-center", "text-center"], [3, "click"], ["name", "right", 1, "icon-3", "ml-1", "mt-[2px]", "rotate-90"], ["bnRippleButton", "", 1, "px-page-safe-area-inset", "flex", "h-14", "w-full", "items-stretch", "justify-between", "px-5", 3, "click"], [1, "flex", "items-center"], [1, "text-sm", "font-bold"], i18n_0, [1, "flex", "items-center", "justify-end"], [1, "text-subtext"], [1, "icon-4", "ml-1.5", 3, "name"], ["bnRippleButton", "", "class", "px-page-safe-area-inset flex h-14 w-full items-stretch justify-between px-5"], ["footer", ""], ["bnRippleButton", "", 1, "h-10.5", "text-error", "border-tiny", "border-error", "w-full", "rounded-full", "text-center", 3, "click"], [1, "text-error"], i18n_2, [3, "isOpen", "isOpenChange"], [3, "isOpen", "panelClass", "isOpenChange"], i18n_4, ["class", "text-error border-tiny border-error ml-2 flex shrink-0 items-center rounded-full bg-white px-2 py-[2px]"], [1, "text-error", "border-tiny", "border-error", "ml-2", "flex", "shrink-0", "items-center", "rounded-full", "bg-white", "px-2", "py-[2px]"], ["name", "warn-grey", 1, "icon-4"], [1, "text-xss", "pt-[1px]", "font-normal"], i18n_6, i18n_9, i18n_11, [3, "hideHeader"], ["page", ""], [1, "box-border", "flex", "flex-col"], [1, "border-line", "text-title", "box-border", "flex", "w-full", "flex-col", "border-b-4", "border-solid", "py-0"], ["bnRippleButton", "", 1, "h-15", "w-full", "px-5", "text-sm", 3, "click"], [1, "border-line", "flex", "h-full", "w-full", "items-center", "justify-center", "border-b-[0.5px]"], i18n_13, ["bnRippleButton", "", 1, "text-error", "h-15", "flex", "w-full", "items-center", "justify-center", "text-sm", 3, "click"], i18n_15, [3, "mainWalletList", "activateMainWalletId", "hiddenAdd", "hiddenEdit", "returnValue$"]];
  },
  template: function HomeMainWalletEditPage_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](0, "common-page", 0);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelement"](1, "img", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](2, "div", 2)(3, "div", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵlistener"]("click", function HomeMainWalletEditPage_Template_div_click_3_listener() {
        return ctx.openSelectWallet();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](4);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelement"](5, "w-icon", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipe"](6, "color");
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](7, "button", 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵlistener"]("click", function HomeMainWalletEditPage_Template_button_click_7_listener() {
        return ctx.editName();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](8, "div", 6)(9, "span", 7);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵi18n"](10, 8);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](11, "div", 9)(12, "span", 10);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](13);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelement"](14, "w-icon", 11);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipe"](15, "color");
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtemplate"](16, HomeMainWalletEditPage_Conditional_16_Template, 8, 8, "button", 12)(17, HomeMainWalletEditPage_Conditional_17_Template, 7, 7, "button", 12)(18, HomeMainWalletEditPage_Conditional_18_Template, 7, 7, "button", 12);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](19, "div", 13)(20, "button", 14);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵlistener"]("click", function HomeMainWalletEditPage_Template_button_click_20_listener() {
        return ctx.deleteWalletBottomSheetInfo.open = true;
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](21, "span", 15);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵi18n"](22, 16);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]()()()();
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](23, "common-bottom-sheet", 17);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵlistener"]("isOpenChange", function HomeMainWalletEditPage_Template_common_bottom_sheet_isOpenChange_23_listener($event) {
        return $event || (ctx.deleteWalletBottomSheetInfo.open = false);
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtemplate"](24, HomeMainWalletEditPage_ng_template_24_Template, 13, 3, "ng-template");
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](25, "common-bottom-sheet", 18);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵlistener"]("isOpenChange", function HomeMainWalletEditPage_Template_common_bottom_sheet_isOpenChange_25_listener($event) {
        return ctx.sheet_selectWallet.is_open = $event;
      })("isOpenChange", function HomeMainWalletEditPage_Template_common_bottom_sheet_isOpenChange_25_listener($event) {
        return ctx.checkHomeSelectWalletOpen($event);
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtemplate"](26, HomeMainWalletEditPage_ng_template_26_Template, 1, 4, "ng-template");
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("titleColor", "title")("contentSafeArea", false);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("src", ctx.mainWallet == null ? null : ctx.mainWallet.headSculpture, _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵsanitizeUrl"]);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtextInterpolate1"](" ", ctx.mainWallet == null ? null : ctx.mainWallet.name, " ");
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpureFunction1"](20, _c8, _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipeBind1"](6, 16, "text-title")));
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](8);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtextInterpolate"](ctx.mainWallet == null ? null : ctx.mainWallet.name);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpureFunction1"](22, _c8, _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipeBind1"](15, 18, "subtext")));
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("name", "right");
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵconditional"](16, ctx.showBackup ? 16 : -1);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵconditional"](17, ctx.showViewPrivateKey ? 17 : -1);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵconditional"](18, ctx.showBioforestChain ? 18 : -1);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](5);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("isOpen", ctx.deleteWalletBottomSheetInfo.open);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("isOpen", ctx.sheet_selectWallet.is_open)("panelClass", "h-5/6");
    }
  },
  dependencies: [_modules_page_module__WEBPACK_IMPORTED_MODULE_5__.CommonPageModule, _libs_bnf_modules_bottom_sheet_components_bottom_sheet_component__WEBPACK_IMPORTED_MODULE_9__.BottomSheetComponent, _libs_bnf_components_ripple_button_ripple_button_directive__WEBPACK_IMPORTED_MODULE_10__.RippleButtonDirective, _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_11__.CommonPageComponent, _components_icon_icon_component__WEBPACK_IMPORTED_MODULE_12__.IconComponent, _pipes_color_color_pipe__WEBPACK_IMPORTED_MODULE_13__.ColorPipe, _home_select_wallet_home_select_wallet_component__WEBPACK_IMPORTED_MODULE_8__["default"]],
  styles: ["/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsInNvdXJjZVJvb3QiOiIifQ== */"],
  changeDetection: 0
});
(0,tslib__WEBPACK_IMPORTED_MODULE_15__.__decorate)([HomeMainWalletEditPage.States(), (0,tslib__WEBPACK_IMPORTED_MODULE_15__.__metadata)("design:type", Object)], HomeMainWalletEditPage.prototype, "mainWallet", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_15__.__decorate)([HomeMainWalletEditPage.OnInit(), (0,tslib__WEBPACK_IMPORTED_MODULE_15__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_15__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_15__.__metadata)("design:returntype", Promise)], HomeMainWalletEditPage.prototype, "init", null);
(0,tslib__WEBPACK_IMPORTED_MODULE_15__.__decorate)([HomeMainWalletEditPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_15__.__metadata)("design:type", Object), (0,tslib__WEBPACK_IMPORTED_MODULE_15__.__metadata)("design:paramtypes", [])], HomeMainWalletEditPage.prototype, "showViewPrivateKey", null);
(0,tslib__WEBPACK_IMPORTED_MODULE_15__.__decorate)([HomeMainWalletEditPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_15__.__metadata)("design:type", Object), (0,tslib__WEBPACK_IMPORTED_MODULE_15__.__metadata)("design:paramtypes", [])], HomeMainWalletEditPage.prototype, "showBioforestChain", null);
(0,tslib__WEBPACK_IMPORTED_MODULE_15__.__decorate)([HomeMainWalletEditPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_15__.__metadata)("design:type", Object), (0,tslib__WEBPACK_IMPORTED_MODULE_15__.__metadata)("design:paramtypes", [])], HomeMainWalletEditPage.prototype, "showBackup", null);
(0,tslib__WEBPACK_IMPORTED_MODULE_15__.__decorate)([HomeMainWalletEditPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_15__.__metadata)("design:type", Object)], HomeMainWalletEditPage.prototype, "mnemonicConfirmBackupPageReturnController", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_15__.__decorate)([HomeMainWalletEditPage.OnInit(), (0,tslib__WEBPACK_IMPORTED_MODULE_15__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_15__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_15__.__metadata)("design:returntype", Promise)], HomeMainWalletEditPage.prototype, "watchPageReturn", null);
(0,tslib__WEBPACK_IMPORTED_MODULE_15__.__decorate)([HomeMainWalletEditPage.States(), (0,tslib__WEBPACK_IMPORTED_MODULE_15__.__metadata)("design:type", Object)], HomeMainWalletEditPage.prototype, "deleteWalletBottomSheetInfo", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_15__.__decorate)([HomeMainWalletEditPage.States(1), (0,tslib__WEBPACK_IMPORTED_MODULE_15__.__metadata)("design:type", Object)], HomeMainWalletEditPage.prototype, "sheet_selectWallet", void 0);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (HomeMainWalletEditPage);

/***/ }),

/***/ 57278:
/*!*********************************************************************************************!*\
  !*** ./apps/wallet/src/pages/home/pages/home-select-wallet/home-select-wallet.component.ts ***!
  \*********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   HomeSelectWalletPage: () => (/* binding */ HomeSelectWalletPage),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 52542);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! tslib */ 90505);
/* harmony import */ var _bnqkl_util_web_extends_promise__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @bnqkl/util-web/extends-promise */ 87778);
/* harmony import */ var _modules_page_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ~modules/page.module */ 77538);
/* harmony import */ var _bnqkl_wallet_base_services_wallet__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @bnqkl/wallet-base/services/wallet */ 20609);
/* harmony import */ var _services_permission_permission_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ~services/permission/permission.service */ 26502);
/* harmony import */ var _bnqkl_framework_animations__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @bnqkl/framework/animations */ 43127);
/* harmony import */ var _bnqkl_framework_helpers__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @bnqkl/framework/helpers */ 12169);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/core */ 61039);
/* harmony import */ var _libs_bnf_components_ripple_button_ripple_button_directive__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../../../../../libs/bnf/components/ripple-button/ripple-button.directive */ 16505);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/common */ 6729);
/* harmony import */ var _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../../../../../libs/bnf/modules/page/common-page/common-page.component */ 62052);
/* harmony import */ var _components_icon_icon_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../../../components/icon/icon.component */ 74703);
/* harmony import */ var _pipes_color_color_pipe__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../../../pipes/color/color.pipe */ 76489);

var _class;













const _c4 = a0 => ({
  "--color-1": a0
});
function HomeSelectWalletPage_li_2_Conditional_10_Template(rf, ctx) {
  if (rf & 1) {
    const _r7 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "button", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵlistener"]("click", function HomeSelectWalletPage_li_2_Conditional_10_Template_button_click_0_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵrestoreView"](_r7);
      const item_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"]().$implicit;
      const ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"]();
      $event.stopPropagation();
      return _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵresetView"](ctx_r5.goBackup(item_r2));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](1, "w-icon", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](2, "color");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](3, "span", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵi18n"](4, 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpureFunction1"](4, _c4, _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind1"](2, 2, "error")));
  }
}
function HomeSelectWalletPage_li_2_w_icon_11_Template(rf, ctx) {
  if (rf & 1) {
    const _r10 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "w-icon", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵlistener"]("click", function HomeSelectWalletPage_li_2_w_icon_11_Template_w_icon_click_0_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵrestoreView"](_r10);
      const item_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"]().$implicit;
      const ctx_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"]();
      $event.stopPropagation();
      return _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵresetView"](ctx_r8.goMainWalletEdit(item_r2));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
  }
}
function HomeSelectWalletPage_li_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r12 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "li")(1, "button", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵlistener"]("click", function HomeSelectWalletPage_li_2_Template_button_click_1_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵrestoreView"](_r12);
      const item_r2 = restoredCtx.$implicit;
      const ctx_r11 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵresetView"](ctx_r11.onClickWalletItem(item_r2));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](2, "div", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](3, "w-icon", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](4, "color");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](5, "img", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](6, "div", 9)(7, "div", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](8);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](9, "div", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](10, HomeSelectWalletPage_li_2_Conditional_10_Template, 5, 6, "button", 12)(11, HomeSelectWalletPage_li_2_w_icon_11_Template, 1, 0, "w-icon", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const item_r2 = ctx.$implicit;
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngStyle", _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpureFunction1"](7, _c4, item_r2.actived ? _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind1"](4, 5, "primart") : "transparent"));
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("src", item_r2.headSculpture, _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵsanitizeUrl"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](item_r2.name);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵconditional"](10, !!item_r2.skipBackup ? 10 : -1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngIf", !ctx_r0.hiddenEdit);
  }
}
function HomeSelectWalletPage_button_4_Template(rf, ctx) {
  if (rf & 1) {
    const _r14 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "button", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵlistener"]("click", function HomeSelectWalletPage_button_4_Template_button_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵrestoreView"](_r14);
      const ctx_r13 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵresetView"](ctx_r13.addMainWallet());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵi18n"](1, 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
  }
}
/**
 * 管理钱包的页面
 */
class HomeSelectWalletPage extends _modules_page_module__WEBPACK_IMPORTED_MODULE_2__.CommonPageBase {
  constructor() {
    super(...arguments);
    /** 返回类型 */
    this.returnValue$ = new _modules_page_module__WEBPACK_IMPORTED_MODULE_2__.PageReturnValue();
    this.hiddenAdd = false;
    this.hiddenEdit = false;
  }
  /** 获取激活的钱包 */
  init() {
    var _this = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      var _this$mainWalletList;
      const walletDataStorageV2Service = _this.injectorForceGet(_bnqkl_wallet_base_services_wallet__WEBPACK_IMPORTED_MODULE_3__.WalletDataStorageV2Service);
      if ((0,_bnqkl_framework_helpers__WEBPACK_IMPORTED_MODULE_6__.$isNoEmptyString)(_this.activateMainWalletId) === false) {
        const activedChainAddress = walletDataStorageV2Service.getLastWalletActivate();
        _this.activateMainWalletId = activedChainAddress === null || activedChainAddress === void 0 ? void 0 : activedChainAddress.mainWalletId;
      }
      (_this$mainWalletList = _this.mainWalletList) === null || _this$mainWalletList === void 0 || _this$mainWalletList.forEach(item => item.actived = item.mainWalletId === _this.activateMainWalletId);
      _this.cdRef.detectChanges();
    })();
  }
  /** 选择身份钱包 */
  onClickWalletItem(event) {
    var _this$mainWalletList2;
    (_this$mainWalletList2 = this.mainWalletList) === null || _this$mainWalletList2 === void 0 || _this$mainWalletList2.forEach(item => item.actived = false);
    event.actived = true;
    this.cdRef.detectChanges();
    this.returnValue$.return(event);
  }
  /** 进行备份 */
  goBackup(mainWallet) {
    var _this2 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this2.returnValue$.return(undefined);
      yield (0,_bnqkl_util_web_extends_promise__WEBPACK_IMPORTED_MODULE_1__.sleep)(128);
      const permissionService = _this2.injectorForceGet(_services_permission_permission_service__WEBPACK_IMPORTED_MODULE_4__.PermissionService);
      const pwdInfo = yield permissionService.requestPassword();
      if (pwdInfo === null || pwdInfo === false) {
        return;
      }
      _this2.nav.routeBack('/mnemonic/mnemonic-backup-tips', {
        export: true,
        backUrl: 'tabs',
        mnemonic: mainWallet.importPhrase,
        /** 备份 */
        backup: true,
        mainWalletId: mainWallet.mainWalletId,
        importType: _bnqkl_wallet_base_services_wallet__WEBPACK_IMPORTED_MODULE_3__.WALLET_IMPORT_TYPE.mnemonic
      });
      return;
    })();
  }
  /** 新增钱包 */
  addMainWallet() {
    var _this3 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const permissionService = _this3.injectorForceGet(_services_permission_permission_service__WEBPACK_IMPORTED_MODULE_4__.PermissionService);
      const pwdInfo = yield permissionService.requestPassword();
      if (pwdInfo === null || pwdInfo === false) {
        return;
      }
      _this3.nav.routeTo('/home-create-or-import-wallet');
    })();
  }
  /** 编辑钱包 */
  goMainWalletEdit(item) {
    this.nav.routeTo('/home-main-wallet-edit', {
      mainWalletId: item.mainWalletId
    });
  }
}
_class = HomeSelectWalletPage;
_class.ɵfac = /*@__PURE__*/(() => {
  let ɵHomeSelectWalletPage_BaseFactory;
  return function HomeSelectWalletPage_Factory(t) {
    return (ɵHomeSelectWalletPage_BaseFactory || (ɵHomeSelectWalletPage_BaseFactory = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵgetInheritedFactory"](_class)))(t || _class);
  };
})();
_class.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdefineComponent"]({
  type: _class,
  selectors: [["w-home-select-wallet-page"]],
  inputs: {
    mainWalletList: "mainWalletList",
    hiddenAdd: "hiddenAdd",
    hiddenEdit: "hiddenEdit",
    activateMainWalletId: "activateMainWalletId"
  },
  outputs: {
    returnValue$: "returnValue$"
  },
  standalone: true,
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵInheritDefinitionFeature"], _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵStandaloneFeature"]],
  decls: 5,
  vars: 8,
  consts: () => {
    let i18n_0;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_SELECTION_WALLET$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_SELECT_WALLET_HOME_SELECT_WALLET_COMPONENT_TS_1 = goog.getMsg("Selection Wallet");
      i18n_0 = MSG_EXTERNAL_SELECTION_WALLET$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_SELECT_WALLET_HOME_SELECT_WALLET_COMPONENT_TS_1;
    } else {
      i18n_0 = "Selection Wallet";
    }
    let i18n_2;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_NO_BACKUP$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_SELECT_WALLET_HOME_SELECT_WALLET_COMPONENT_TS___3 = goog.getMsg("No Backup");
      i18n_2 = MSG_EXTERNAL_NO_BACKUP$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_SELECT_WALLET_HOME_SELECT_WALLET_COMPONENT_TS___3;
    } else {
      i18n_2 = "No Backup";
    }
    let i18n_5;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_ADD_WALLET$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_SELECT_WALLET_HOME_SELECT_WALLET_COMPONENT_TS__6 = goog.getMsg(" Add Wallet ");
      i18n_5 = MSG_EXTERNAL_ADD_WALLET$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_SELECT_WALLET_HOME_SELECT_WALLET_COMPONENT_TS__6;
    } else {
      i18n_5 = " Add Wallet ";
    }
    return [["headerTitle", i18n_0, 3, "contentBackground", "contentSafeArea", "titleColor", "headerBackground"], [1, "w-full", "bg-white"], [4, "ngFor", "ngForOf", "ngForTrackBy"], ["footer", "", 1, "p-2"], ["bnRippleButton", "", "class", "h-10.5 from-purple-gradient-start to-purple-gradient-end w-full rounded-full bg-gradient-to-b text-center text-sm text-white", 3, "click", 4, "ngIf"], ["bnRippleButton", "", 1, "border-b-tiny", "border-line", "flex", "w-full", "items-center", "justify-between", "px-2", "py-4", 3, "click"], [1, "flex", "items-center", "justify-start"], ["name", "language-selected-1", 1, "border-tiny", "border-subtext", "mr-2", "mt-[2px]", "rounded-[4px]", "p-[2px]", 3, "ngStyle"], ["alt", "", "srcset", "", 1, "h-[32px]", "w-[32px]", "rounded-full", 3, "src"], [1, "ml-2"], [1, "overflow-hidden", "text-ellipsis", "whitespace-nowrap", "text-xs", "font-semibold"], [1, "flex", "items-center", "justify-end"], ["class", "text-error border-tiny border-error ml-2 mr-3 inline-block flex shrink-0 items-center rounded-full bg-white px-2 py-[2px]"], ["name", "edit", "class", "text-subtext icon-5 ml-auto", 3, "click", 4, "ngIf"], [1, "text-error", "border-tiny", "border-error", "ml-2", "mr-3", "inline-block", "flex", "shrink-0", "items-center", "rounded-full", "bg-white", "px-2", "py-[2px]", 3, "click"], ["name", "warn-grey", 1, "icon-4"], [1, "text-xss", "pt-[1px]", "font-normal"], i18n_2, ["name", "edit", 1, "text-subtext", "icon-5", "ml-auto", 3, "click"], ["bnRippleButton", "", 1, "h-10.5", "from-purple-gradient-start", "to-purple-gradient-end", "w-full", "rounded-full", "bg-gradient-to-b", "text-center", "text-sm", "text-white", 3, "click"], i18n_5];
  },
  template: function HomeSelectWalletPage_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "common-page", 0)(1, "ul", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](2, HomeSelectWalletPage_li_2_Template, 12, 9, "li", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](3, "div", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](4, HomeSelectWalletPage_button_4_Template, 2, 0, "button", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()();
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("contentBackground", "white")("contentSafeArea", true)("titleColor", "title")("headerBackground", "white");
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("@listFadeInRight", ctx.mainWalletList == null ? null : ctx.mainWalletList.length);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngForOf", ctx.mainWalletList)("ngForTrackBy", ctx.trackByKey("mainWalletId"));
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngIf", !ctx.hiddenAdd);
    }
  },
  dependencies: [_modules_page_module__WEBPACK_IMPORTED_MODULE_2__.CommonPageModule, _libs_bnf_components_ripple_button_ripple_button_directive__WEBPACK_IMPORTED_MODULE_7__.RippleButtonDirective, _angular_common__WEBPACK_IMPORTED_MODULE_12__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_12__.NgIf, _angular_common__WEBPACK_IMPORTED_MODULE_12__.NgStyle, _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_8__.CommonPageComponent, _components_icon_icon_component__WEBPACK_IMPORTED_MODULE_9__.IconComponent, _pipes_color_color_pipe__WEBPACK_IMPORTED_MODULE_10__.ColorPipe],
  styles: ["/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsInNvdXJjZVJvb3QiOiIifQ== */"],
  data: {
    animation: [_bnqkl_framework_animations__WEBPACK_IMPORTED_MODULE_5__.listFadeInRightTrigger]
  },
  changeDetection: 0
});
(0,tslib__WEBPACK_IMPORTED_MODULE_13__.__decorate)([HomeSelectWalletPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_13__.__metadata)("design:type", Object)], HomeSelectWalletPage.prototype, "mainWalletList", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_13__.__decorate)([HomeSelectWalletPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_13__.__metadata)("design:type", Object)], HomeSelectWalletPage.prototype, "hiddenAdd", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_13__.__decorate)([HomeSelectWalletPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_13__.__metadata)("design:type", Object)], HomeSelectWalletPage.prototype, "hiddenEdit", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_13__.__decorate)([HomeSelectWalletPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_13__.__metadata)("design:type", String)], HomeSelectWalletPage.prototype, "activateMainWalletId", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_13__.__decorate)([HomeSelectWalletPage.OnInit(), (0,tslib__WEBPACK_IMPORTED_MODULE_13__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_13__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_13__.__metadata)("design:returntype", Promise)], HomeSelectWalletPage.prototype, "init", null);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (HomeSelectWalletPage);

/***/ }),

/***/ 11606:
/*!************************************************************!*\
  !*** ./libs/bnf/controllers/form-validators.controller.ts ***!
  \************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   FormValidatorsController: () => (/* binding */ FormValidatorsController)
/* harmony export */ });
/* harmony import */ var _bnqkl_framework_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @bnqkl/framework/core */ 63563);
/* harmony import */ var _bnqkl_util_web_extends_map__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @bnqkl/util-web/extends-map */ 37689);


/**
 * 页面表单扩展验证器
 *
 * > 因为涉及到FromControl的生命周期管理，所以这里需要使用Controller模式来获取组件/页面的生命周期
 *
 * 为了确保类型安全, 请遵循以下规则去定义验证器:
 * 1. 尽可能直接提供 $ValidatorFn,比如 `trimRequired(control: AbstractControl): $ValidationErrors | null {...}`
 * 2. 如果不能直接提供 $ValidatorFn, 那么作为工厂模式,必然要有参数传入,比如 `equals(leaderCtrl: AbstractControl): $ValidatorFn {...}`
 */
class FormValidatorsController {
  /**
   * 通过订阅原页面的生命周期，来对订阅的字段进行监听解除
   */
  constructor(comp) {
    /**
     * 判断两个数据字段相等的时，left===right 中 left的数据订阅
     */
    this._equalsLeaderMap = _bnqkl_util_web_extends_map__WEBPACK_IMPORTED_MODULE_1__.EasyMap.from({
      creater(ctrl) {
        const sub = {
          sub$: ctrl.valueChanges.subscribe(() => {
            for (const ctrl of sub.destControls) {
              ctrl.updateValueAndValidity();
            }
          }),
          destControls: new Set()
        };
        return sub;
      }
    });
    (0,_bnqkl_framework_core__WEBPACK_IMPORTED_MODULE_0__.addLifecycleMethods)(comp, 'ngOnDestroy', {
      origin: 'form-validator',
      method: () => {
        for (const {
          sub$
        } of this._equalsLeaderMap.values()) {
          sub$.unsubscribe();
        }
        this._equalsLeaderMap.clear();
      },
      order: Number.MAX_SAFE_INTEGER /* 最后才做这些事情 */
    });
  }
  /** 两个字段对比 相等就过 不相等返回 {equals:true} */
  equals(leaderCtrl) {
    const leader = this._equalsLeaderMap.forceGet(leaderCtrl);
    // pwdCtrl.val
    return follerCtrl => {
      leader.destControls.add(follerCtrl);
      if (leaderCtrl.value === follerCtrl.value) {
        return null;
      }
      return {
        equals: true
      };
    };
  }
  /** 是否包含空格 */
  whitespace(control) {
    const value = control.value;
    if (typeof value === 'string' && /\s/.test(value)) {
      return {
        whitespace: true
      };
    }
    return null;
  }
  /** required 变体, 左右两边不能包含空格 */
  trimRequired(control) {
    const value = control.value;
    if (typeof value === 'string' && value.trim().length === 0 || value == undefined) {
      return {
        trimRequired: true
      };
    }
    return null;
  }
}

/***/ }),

/***/ 47919:
/*!***************************************!*\
  !*** ./libs/bnf/controllers/index.ts ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   FormValidatorsController: () => (/* reexport safe */ _form_validators_controller__WEBPACK_IMPORTED_MODULE_0__.FormValidatorsController),
/* harmony export */   PageReturnController: () => (/* reexport safe */ _page_return_controller__WEBPACK_IMPORTED_MODULE_1__.PageReturnController)
/* harmony export */ });
/* harmony import */ var _form_validators_controller__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./form-validators.controller */ 11606);
/* harmony import */ var _page_return_controller__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./page-return.controller */ 62893);



/***/ }),

/***/ 62893:
/*!********************************************************!*\
  !*** ./libs/bnf/controllers/page-return.controller.ts ***!
  \********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   PageReturnController: () => (/* binding */ PageReturnController)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 54106);
/* harmony import */ var _bnqkl_util_web_decorator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @bnqkl/util-web/decorator */ 18112);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs */ 19177);



/**
 * 页面数据返回值的订阅功能
 * > Controller 必须在构造函数期间执行
 */
class PageReturnController {
  /** 继承日志 */
  get console() {
    return this.fromPage.console;
  }
  /**
   * 传入源页面与目标页面的构造函数，并通过订阅原页面的生命周期，来初始化对路由的订阅
   * 这里依赖 ion-router-outlet 来获取跳转过去的页面
   * 注：该监听返回是全触发（只要页面没被销毁掉不管页面是否处于激活状态）
   * @param specific 用于指定fromPage触发（需要手动指定），业务需要
   */
  constructor(fromPage, toPageCtor, specific = false) {
    this.fromPage = fromPage;
    /** 当前定阅过的页面 */
    this._toPages = new WeakSet();
    /**
     * 订阅到的返回内容，
     * 类型由对应页面的 returnValue$ 的定义决定
     */
    this.pageReturn$ = new rxjs__WEBPACK_IMPORTED_MODULE_1__.Subject();
    const {
      nav
    } = fromPage;
    fromPage.takeUntilDestroy(nav.pageActiveState$).subscribe(event => {
      /// 只监听新激活的页面
      if (event.type !== 'activate') {
        return;
      }
      const toPage = event.target;
      if (toPage instanceof toPageCtor &&
      // 去重
      this._toPages.has(toPage) === false) {
        if (toPage.returnValue$ === undefined) {
          return;
        }
        this._toPages.add(toPage);
        if (specific) {
          var _toPage$specificRetur;
          (_toPage$specificRetur = toPage.specificReturnPages) === null || _toPage$specificRetur === void 0 || _toPage$specificRetur.add(fromPage);
        }
        fromPage.takeUntilDestroy(toPage.returnValue$).subscribe({
          next: data => {
            /// 这里不用判断specific
            if (toPage.specificReturnPages && toPage.specificReturnPages.size) {
              /// 如果有写入，那么就只需要触发相对应页面就行
              toPage.specificReturnPages.has(fromPage) && this.pageReturn$.next(data);
              return;
            }
            this.pageReturn$.next(data);
          },
          complete: () => {
            var _toPage$specificRetur2;
            // 释放内存引用
            (_toPage$specificRetur2 = toPage.specificReturnPages) === null || _toPage$specificRetur2 === void 0 || _toPage$specificRetur2.delete(fromPage);
            return this._toPages.delete(toPage);
          }
        });
      }
    });
  }
}
(0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([_bnqkl_util_web_decorator__WEBPACK_IMPORTED_MODULE_0__.cacheGetter, (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__metadata)("design:type", Object), (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__metadata)("design:paramtypes", [])], PageReturnController.prototype, "console", null);

/***/ })

}]);
//# sourceMappingURL=default-apps_wallet_src_pages_home_pages_home-main-wallet-edit_home-main-wallet-edit_component_ts.js.map