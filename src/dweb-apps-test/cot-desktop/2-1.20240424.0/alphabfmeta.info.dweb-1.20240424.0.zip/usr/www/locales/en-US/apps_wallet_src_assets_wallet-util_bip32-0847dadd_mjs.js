"use strict";
(self["webpackChunkwallet"] = self["webpackChunkwallet"] || []).push([["apps_wallet_src_assets_wallet-util_bip32-0847dadd_mjs"],{

/***/ 10718:
/*!***************************************************************!*\
  !*** ./apps/wallet/src/assets/wallet-util/bip32-0847dadd.mjs ***!
  \***************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   BIP32Factory: () => (/* binding */ p)
/* harmony export */ });
/* harmony import */ var _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./index-766bdb76.mjs */ 59809);
/* harmony import */ var _sha512_0b4c0803_mjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./sha512-0b4c0803.mjs */ 89918);
/* harmony import */ var _hmac_68b6dab4_mjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./hmac-68b6dab4.mjs */ 84816);
/* harmony import */ var _index_f363275a_mjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./index-f363275a.mjs */ 89279);
/* harmony import */ var _typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./typeforce-9b266dd0.mjs */ 26139);
/* harmony import */ var _index_c6d6a521_mjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./index-c6d6a521.mjs */ 76536);
/* harmony import */ var _crypto_2c4d5428_mjs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./crypto-2c4d5428.mjs */ 8319);
/* harmony import */ var _WASMInterface_b9f2203b_mjs__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./WASMInterface-b9f2203b.mjs */ 43670);
/* harmony import */ var _sha256_e58017d9_mjs__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./sha256-e58017d9.mjs */ 6612);
/* harmony import */ var _ripemd160_3baa091d_mjs__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./ripemd160-3baa091d.mjs */ 70972);
/* harmony import */ var _sha1_e1635d39_mjs__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./sha1-e1635d39.mjs */ 57);











function h(i, n) {
  return _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_0__.B.from((0,_hmac_68b6dab4_mjs__WEBPACK_IMPORTED_MODULE_2__.c)((0,_sha512_0b4c0803_mjs__WEBPACK_IMPORTED_MODULE_1__.c)(), i).update(n).digest());
}
function p(r) {
  const t = _typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_4__.t.BufferN(32),
    p = _typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_4__.t.compile({
      wif: _typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_4__.t.UInt8,
      bip32: {
        public: _typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_4__.t.UInt32,
        private: _typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_4__.t.UInt32
      }
    }),
    a = {
      messagePrefix: "Bitcoin Signed Message:\n",
      bech32: "bc",
      bip32: {
        public: 76067358,
        private: 76066276
      },
      pubKeyHash: 0,
      scriptHash: 5,
      wif: 128
    },
    c = 2147483648,
    u = Math.pow(2, 31) - 1;
  function d(e) {
    return _typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_4__.t.String(e) && null !== e.match(/^(m\/)?(\d+'?\/)*\d+'?$/);
  }
  function f(e) {
    return _typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_4__.t.UInt32(e) && e <= u;
  }
  function l(e) {
    return 32 === e.length ? e : e.slice(1, 33);
  }
  class y {
    constructor(e, r) {
      this.__D = e, this.__Q = r, this.lowR = !1;
    }
    get publicKey() {
      return void 0 === this.__Q && (this.__Q = _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_0__.B.from(r.pointFromScalar(this.__D, !0))), this.__Q;
    }
    get privateKey() {
      return this.__D;
    }
    sign(t, i) {
      if (!this.privateKey) throw new Error("Missing private key");
      if (void 0 === i && (i = this.lowR), !1 === i) return _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_0__.B.from(r.sign(t, this.privateKey));
      {
        let i = _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_0__.B.from(r.sign(t, this.privateKey));
        const n = _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_0__.B.alloc(32, 0);
        let s = 0;
        for (; i[0] > 127;) s++, n.writeUIntLE(s, 0, 6), i = _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_0__.B.from(r.sign(t, this.privateKey, n));
        return i;
      }
    }
    signSchnorr(t) {
      if (!this.privateKey) throw new Error("Missing private key");
      if (!r.signSchnorr) throw new Error("signSchnorr not supported by ecc library");
      return _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_0__.B.from(r.signSchnorr(t, this.privateKey));
    }
    verify(e, t) {
      return r.verify(e, this.publicKey, t);
    }
    verifySchnorr(e, t) {
      if (!r.verifySchnorr) throw new Error("verifySchnorr not supported by ecc library");
      return r.verifySchnorr(e, this.publicKey.subarray(1, 33), t);
    }
  }
  class w extends y {
    constructor(e, r, t, i, s = 0, o = 0, h = 0) {
      super(e, r), this.chainCode = t, this.network = i, this.__DEPTH = s, this.__INDEX = o, this.__PARENT_FINGERPRINT = h, (0,_typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_4__.t)(p, i);
    }
    get depth() {
      return this.__DEPTH;
    }
    get index() {
      return this.__INDEX;
    }
    get parentFingerprint() {
      return this.__PARENT_FINGERPRINT;
    }
    get identifier() {
      return (0,_crypto_2c4d5428_mjs__WEBPACK_IMPORTED_MODULE_6__.hash160)(this.publicKey);
    }
    get fingerprint() {
      return this.identifier.slice(0, 4);
    }
    get compressed() {
      return !0;
    }
    isNeutered() {
      return void 0 === this.__D;
    }
    neutered() {
      return b(this.publicKey, this.chainCode, this.network, this.depth, this.index, this.parentFingerprint);
    }
    toBase58() {
      const r = this.network,
        t = this.isNeutered() ? r.bip32.public : r.bip32.private,
        n = _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_0__.B.allocUnsafe(78);
      return n.writeUInt32BE(t, 0), n.writeUInt8(this.depth, 4), n.writeUInt32BE(this.parentFingerprint, 5), n.writeUInt32BE(this.index, 9), this.chainCode.copy(n, 13), this.isNeutered() ? this.publicKey.copy(n, 45) : (n.writeUInt8(0, 45), this.privateKey.copy(n, 46)), _index_f363275a_mjs__WEBPACK_IMPORTED_MODULE_3__.b.encode(n);
    }
    toWIF() {
      if (!this.privateKey) throw new TypeError("Missing private key");
      return (0,_index_c6d6a521_mjs__WEBPACK_IMPORTED_MODULE_5__.e)(this.network.wif, this.privateKey, !0);
    }
    derive(t) {
      (0,_typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_4__.t)(_typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_4__.t.UInt32, t);
      const i = t >= c,
        s = _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_0__.B.allocUnsafe(37);
      if (i) {
        if (this.isNeutered()) throw new TypeError("Missing private key for hardened child key");
        s[0] = 0, this.privateKey.copy(s, 1), s.writeUInt32BE(t, 33);
      } else this.publicKey.copy(s, 0), s.writeUInt32BE(t, 33);
      const o = h(this.chainCode, s),
        p = o.slice(0, 32),
        a = o.slice(32);
      if (!r.isPrivate(p)) return this.derive(t + 1);
      let u;
      if (this.isNeutered()) {
        const i = _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_0__.B.from(r.pointAddScalar(this.publicKey, p, !0));
        if (null === i) return this.derive(t + 1);
        u = b(i, a, this.network, this.depth + 1, t, this.fingerprint.readUInt32BE(0));
      } else {
        const i = _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_0__.B.from(r.privateAdd(this.privateKey, p));
        if (null == i) return this.derive(t + 1);
        u = m(i, a, this.network, this.depth + 1, t, this.fingerprint.readUInt32BE(0));
      }
      return u;
    }
    deriveHardened(e) {
      return (0,_typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_4__.t)(f, e), this.derive(e + c);
    }
    derivePath(e) {
      (0,_typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_4__.t)(d, e);
      let r = e.split("/");
      if ("m" === r[0]) {
        if (this.parentFingerprint) throw new TypeError("Expected master, got child");
        r = r.slice(1);
      }
      return r.reduce((e, r) => {
        let t;
        return "'" === r.slice(-1) ? (t = parseInt(r.slice(0, -1), 10), e.deriveHardened(t)) : (t = parseInt(r, 10), e.derive(t));
      }, this);
    }
    tweak(e) {
      return this.privateKey ? this.tweakFromPrivateKey(e) : this.tweakFromPublicKey(e);
    }
    tweakFromPublicKey(t) {
      const i = l(this.publicKey),
        n = r.xOnlyPointAddTweak(i, t);
      if (!n || null === n.xOnlyPubkey) throw new Error("Cannot tweak public key!");
      const s = _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_0__.B.from([0 === n.parity ? 2 : 3]),
        o = _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_0__.B.concat([s, n.xOnlyPubkey]);
      return new y(void 0, o);
    }
    tweakFromPrivateKey(t) {
      const i = 3 === this.publicKey[0] || 4 === this.publicKey[0] && 1 == (1 & this.publicKey[64]) ? r.privateNegate(this.privateKey) : this.privateKey,
        n = r.privateAdd(i, t);
      if (!n) throw new Error("Invalid tweaked private key!");
      return new y(_index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_0__.B.from(n), void 0);
    }
  }
  function v(e, r, t) {
    return m(e, r, t);
  }
  function m(e, i, s, o, h, p) {
    if ((0,_typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_4__.t)({
      privateKey: t,
      chainCode: t
    }, {
      privateKey: e,
      chainCode: i
    }), s = s || a, !r.isPrivate(e)) throw new TypeError("Private key not in range [1, n)");
    return new w(e, void 0, i, s, o, h, p);
  }
  function b(e, i, s, o, h, p) {
    if ((0,_typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_4__.t)({
      publicKey: _typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_4__.t.BufferN(33),
      chainCode: t
    }, {
      publicKey: e,
      chainCode: i
    }), s = s || a, !r.isPoint(e)) throw new TypeError("Point is not on the curve");
    return new w(void 0, e, i, s, o, h, p);
  }
  return {
    fromSeed: function (r, t) {
      if ((0,_typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_4__.t)(_typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_4__.t.Buffer, r), r.length < 16) throw new TypeError("Seed should be at least 128 bits");
      if (r.length > 64) throw new TypeError("Seed should be at most 512 bits");
      t = t || a;
      const i = h(_index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_0__.B.from("Bitcoin seed", "utf8"), r);
      return v(i.slice(0, 32), i.slice(32), t);
    },
    fromBase58: function (e, r) {
      const t = _index_f363275a_mjs__WEBPACK_IMPORTED_MODULE_3__.b.decode(e);
      if (78 !== t.length) throw new TypeError("Invalid buffer length");
      r = r || a;
      const n = t.readUInt32BE(0);
      if (n !== r.bip32.private && n !== r.bip32.public) throw new TypeError("Invalid network version");
      const s = t[4],
        o = t.readUInt32BE(5);
      if (0 === s && 0 !== o) throw new TypeError("Invalid parent fingerprint");
      const h = t.readUInt32BE(9);
      if (0 === s && 0 !== h) throw new TypeError("Invalid index");
      const p = t.slice(13, 45);
      let c;
      if (n === r.bip32.private) {
        if (0 !== t.readUInt8(45)) throw new TypeError("Invalid private key");
        c = m(t.slice(46, 78), p, r, s, h, o);
      } else {
        c = b(t.slice(45, 78), p, r, s, h, o);
      }
      return c;
    },
    fromPublicKey: function (e, r, t) {
      return b(e, r, t);
    },
    fromPrivateKey: v,
    toXOnly: l
  };
}


/***/ }),

/***/ 8319:
/*!****************************************************************!*\
  !*** ./apps/wallet/src/assets/wallet-util/crypto-2c4d5428.mjs ***!
  \****************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   hash160: () => (/* binding */ i),
/* harmony export */   hash256: () => (/* binding */ m),
/* harmony export */   ripemd160: () => (/* binding */ o),
/* harmony export */   sha1: () => (/* binding */ a),
/* harmony export */   sha256: () => (/* binding */ c),
/* harmony export */   taggedHash: () => (/* binding */ s)
/* harmony export */ });
/* harmony import */ var _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./index-766bdb76.mjs */ 59809);
/* harmony import */ var _ripemd160_3baa091d_mjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./ripemd160-3baa091d.mjs */ 70972);
/* harmony import */ var _sha1_e1635d39_mjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./sha1-e1635d39.mjs */ 57);
/* harmony import */ var _sha256_e58017d9_mjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./sha256-e58017d9.mjs */ 6612);
/* harmony import */ var _WASMInterface_b9f2203b_mjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./WASMInterface-b9f2203b.mjs */ 43670);





function o(n) {
  return _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_0__.B.from((0,_ripemd160_3baa091d_mjs__WEBPACK_IMPORTED_MODULE_1__.c)().update(n).digest());
}
function a(t) {
  return _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_0__.B.from((0,_sha1_e1635d39_mjs__WEBPACK_IMPORTED_MODULE_2__.c)().update(t).digest());
}
function c(t) {
  return _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_0__.B.from((0,_sha256_e58017d9_mjs__WEBPACK_IMPORTED_MODULE_3__.c)().update(t).digest());
}
function i(r) {
  return o(c(r));
}
function m(r) {
  return c(c(r));
}
const f = Object.fromEntries(["BIP0340/challenge", "BIP0340/aux", "BIP0340/nonce", "TapLeaf", "TapBranch", "TapSighash", "TapTweak", "KeyAgg list", "KeyAgg coefficient"].map(t => {
  const n = c(_index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_0__.B.from(t));
  return [t, _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_0__.B.concat([n, n])];
}));
function s(t, n) {
  return c(_index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_0__.B.concat([f[t], n]));
}


/***/ }),

/***/ 57:
/*!**************************************************************!*\
  !*** ./apps/wallet/src/assets/wallet-util/sha1-e1635d39.mjs ***!
  \**************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   a: () => (/* binding */ e),
/* harmony export */   c: () => (/* binding */ i),
/* harmony export */   p: () => (/* binding */ s),
/* harmony export */   s: () => (/* binding */ t)
/* harmony export */ });
/* harmony import */ var D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 52542);
/* harmony import */ var _WASMInterface_b9f2203b_mjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./WASMInterface-b9f2203b.mjs */ 43670);


const s = (0,_WASMInterface_b9f2203b_mjs__WEBPACK_IMPORTED_MODULE_1__.c)("sha1", 20),
  t = /*#__PURE__*/function () {
    var _ref = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (a) {
      return (yield s()).calculate(a);
    });
    return function t(_x) {
      return _ref.apply(this, arguments);
    };
  }(),
  e = /*#__PURE__*/function () {
    var _ref2 = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      return i(yield s());
    });
    return function e() {
      return _ref2.apply(this, arguments);
    };
  }(),
  i = (a = s.wasm) => {
    a.init();
    const t = {
      init: () => (a.init(), t),
      update: s => (a.update(s), t),
      digest: s => a.digest(s),
      save: () => a.save(),
      load: s => (a.load(s), t),
      blockSize: 64,
      digestSize: 20
    };
    return t;
  };


/***/ })

}]);
//# sourceMappingURL=apps_wallet_src_assets_wallet-util_bip32-0847dadd_mjs.js.map