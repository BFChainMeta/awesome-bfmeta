"use strict";
(self["webpackChunkwallet"] = self["webpackChunkwallet"] || []).push([["apps_wallet_src_pages_mime_pages_application-lock_application-lock_component_ts"],{

/***/ 6596:
/*!************************************************!*\
  !*** ./apps/wallet/src/helpers/utils/index.ts ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   isMobile: () => (/* binding */ isMobile)
/* harmony export */ });
/* harmony import */ var _plaoc_is_dweb__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @plaoc/is-dweb */ 69899);
/* harmony import */ var _environments_index__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ~environments/index */ 40014);


/** 判断是否是移动端 */
const isMobile = () => {
  if (_environments_index__WEBPACK_IMPORTED_MODULE_1__.environment.DWEB_APP) {
    return (0,_plaoc_is_dweb__WEBPACK_IMPORTED_MODULE_0__.isMobile)();
  } else {
    return true;
  }
};

/***/ }),

/***/ 18296:
/*!*****************************************************************************************!*\
  !*** ./apps/wallet/src/pages/mime/pages/application-lock/application-lock.component.ts ***!
  \*****************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ApplicationLockPage: () => (/* binding */ ApplicationLockPage),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 52542);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! tslib */ 90505);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/core */ 61039);
/* harmony import */ var _bnqkl_framework_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @bnqkl/framework/components */ 24182);
/* harmony import */ var _bnqkl_framework_controllers__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @bnqkl/framework/controllers */ 47919);
/* harmony import */ var _bnqkl_framework_plugins_biometric__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @bnqkl/framework/plugins/biometric */ 52583);
/* harmony import */ var _bnqkl_framework_plugins_toast__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @bnqkl/framework/plugins/toast */ 18030);
/* harmony import */ var _bnqkl_wallet_base_services_wallet_wallet_data_storage__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @bnqkl/wallet-base/services/wallet/wallet-data-storage */ 63024);
/* harmony import */ var _helpers_utils__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ~helpers/utils */ 6596);
/* harmony import */ var _modules_page_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ~modules/page.module */ 77538);
/* harmony import */ var _pages_mime_pages_verify_fingerprint_verify_fingerprint_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ~pages/mime/pages/verify-fingerprint/verify-fingerprint.component */ 5780);
/* harmony import */ var _pages_wallet_sign_in_wallet_sign_in_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ~pages/wallet-sign-in/wallet-sign-in.component */ 38905);
/* harmony import */ var _services_permission_permission_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ~services/permission/permission.service */ 26502);
/* harmony import */ var _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../../../../../../libs/bnf/modules/page/common-page/common-page.component */ 62052);
/* harmony import */ var _components_icon_icon_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../../../components/icon/icon.component */ 74703);

var _class;















/** 切换语言页面 */
class ApplicationLockPage extends _modules_page_module__WEBPACK_IMPORTED_MODULE_7__.CommonPageBase {
  constructor() {
    super(...arguments);
    /** verifyFingerprintPage页面返回 */
    this.verifyFingerprintPageReturnController = new _bnqkl_framework_controllers__WEBPACK_IMPORTED_MODULE_2__.PageReturnController(this, _pages_mime_pages_verify_fingerprint_verify_fingerprint_component__WEBPACK_IMPORTED_MODULE_8__.VerifyFingerprintPage);
    /** wallet-sign-in页面返回 */
    this.walletSignInPageReturnController = new _bnqkl_framework_controllers__WEBPACK_IMPORTED_MODULE_2__.PageReturnController(this, _pages_wallet_sign_in_wallet_sign_in_component__WEBPACK_IMPORTED_MODULE_9__.WalletSignInPage);
    /** 启用密码锁 */
    this.enablePasswordLock = false;
    /** 启用指纹识别 */
    this.enableFingerprint = false;
    /** 存储服务 */
    this.walletDataStorageV2Service = (0,_angular_core__WEBPACK_IMPORTED_MODULE_13__.inject)(_bnqkl_wallet_base_services_wallet_wallet_data_storage__WEBPACK_IMPORTED_MODULE_5__.WalletDataStorageV2Service);
  }
  /** 获取身份钱包信息 */
  getMainWalletInfo() {
    var _this = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this.enablePasswordLock = !!_this.walletDataStorageV2Service.walletAppSettings.passwordLock;
      _this.enableFingerprint = !!_this.walletDataStorageV2Service.walletAppSettings.fingerprintLock;
      const saveCheckFingerprint = /*#__PURE__*/function () {
        var _ref = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (check) {
          if (check === true) {
            _this.walletDataStorageV2Service.walletAppSettings.fingerprintLock = _this.enableFingerprint = !_this.enableFingerprint;
          }
        });
        return function saveCheckFingerprint(_x) {
          return _ref.apply(this, arguments);
        };
      }();
      /** 监听 */
      _this.verifyFingerprintPageReturnController.pageReturn$.subscribe( /*#__PURE__*/function () {
        var _ref2 = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (data) {
          saveCheckFingerprint(data);
        });
        return function (_x2) {
          return _ref2.apply(this, arguments);
        };
      }());
      /** 监听 */
      _this.walletSignInPageReturnController.pageReturn$.subscribe( /*#__PURE__*/function () {
        var _ref3 = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (data) {
          saveCheckFingerprint(data);
        });
        return function (_x3) {
          return _ref3.apply(this, arguments);
        };
      }());
    })();
  }
  /** 开启关闭密码锁 */
  switchPasswordLock() {
    var _this2 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      if (_this2.enablePasswordLock) {
        const hasOff = yield _this2.confirm({
          bodyMessage: "\u78BA\u5B9A\u8981\u95DC\u9589\u5BC6\u78BC\u9396\u55CE\uFF1F",
          confirmText: "\u78BA\u5B9A",
          cancelText: "\u53D6\u6D88",
          footerTheme: 'blank'
        });
        if (hasOff !== true) {
          /// 不关闭,就退出
          return;
        }
      }
      /// 未开启/确认关闭,验证密码就行
      const permissionService = _this2.injectorForceGet(_services_permission_permission_service__WEBPACK_IMPORTED_MODULE_10__.PermissionService);
      const title = (0,_helpers_utils__WEBPACK_IMPORTED_MODULE_6__.isMobile)() ? "\u8EAB\u4EFD\u9322\u5305\u5BC6\u78BC\u9A8C\u8BC1" : "\u9322\u5305\u5BC6\u78BC\u9A8C\u8BC1";
      const pwdInfo = yield permissionService.requestPassword({
        title: title,
        placeholder: "\u8F38\u5165\u8EAB\u4EFD\u9322\u5305\u5BC6\u78BC"
      });
      if (pwdInfo === null || pwdInfo === false) {
        if (pwdInfo === false) {
          _bnqkl_framework_plugins_toast__WEBPACK_IMPORTED_MODULE_4__.Toast.show("\u5BC6\u78BC\u8F38\u5165\u932F\u8AA4");
        }
        return;
      }
      /// 保存相应设置
      _this2.enablePasswordLock = _this2.walletDataStorageV2Service.walletAppSettings.passwordLock = !_this2.enablePasswordLock;
      if (_this2.walletDataStorageV2Service.walletAppSettings.passwordLock === false) {
        _this2.enableFingerprint = _this2.walletDataStorageV2Service.walletAppSettings.fingerprintLock = false;
      }
    })();
  }
  /** 开启关闭指纹识别 */
  switchFingerprint() {
    var _this3 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      if (_this3.enablePasswordLock === false) {
        _bnqkl_framework_plugins_toast__WEBPACK_IMPORTED_MODULE_4__.Toast.show("\u8ACB\u5148\u6253\u958B\u5BC6\u78BC\u9396");
        return;
      }
      /// 判断是否被系统禁用
      const isProhibited = sessionStorage.getItem(_pages_mime_pages_verify_fingerprint_verify_fingerprint_component__WEBPACK_IMPORTED_MODULE_8__.FINGERPRINT_PROHIBITION_OF_USE);
      if (isProhibited) {
        if (_this3.enableFingerprint) {
          /// 开启了，但是系统取消了，需要使用密码关闭
          yield _this3.alert({
            bodyMessage: "\u6307\u7D0B\u9A57\u8B49\u7121\u6CD5\u555F\u52D5\uFF0C\u8ACB\u4F7F\u7528\u5BC6\u78BC\u9A57\u8B49"
          });
          return _this3.nav.routeTo('wallet/wallet-sign-in', {
            onlyPwd: true
          });
        } else {
          _bnqkl_framework_plugins_toast__WEBPACK_IMPORTED_MODULE_4__.Toast.show("\u7CFB\u7D71\u6307\u7D0B\u5DF2\u88AB\u7981\u6B62");
        }
        return;
      }
      /// 判断下间隔
      const fingerprintTimestamp = Number(sessionStorage.getItem(_pages_mime_pages_verify_fingerprint_verify_fingerprint_component__WEBPACK_IMPORTED_MODULE_8__.FINGERPRINT_INTERVAL_SESSION_KEY) || 0);
      if (fingerprintTimestamp > 0) {
        const interval = Date.now() - fingerprintTimestamp;
        if (interval < 30 * 1000) {
          const waiting = 30 - Math.floor(interval / 1000);
          _bnqkl_framework_plugins_toast__WEBPACK_IMPORTED_MODULE_4__.Toast.show("\u591A\u6B21\u9A57\u8B49\u5931\u6557\uFF0C\u8ACB " + waiting + " \u79D2\u5F8C\u91CD\u8A66");
          return;
        }
      }
      /// 判断是否开启
      try {
        const info = yield _bnqkl_framework_plugins_biometric__WEBPACK_IMPORTED_MODULE_3__.NativeBiometric.isAvailable();
        _this3.console.log(info);
        if (info.isAvailable === false) {
          if (_this3.enableFingerprint) {
            /// 开启了，但是系统取消了，需要使用密码关闭
            yield _this3.alert({
              bodyMessage: "\u6307\u7D0B\u9A57\u8B49\u7121\u6CD5\u555F\u52D5\uFF0C\u8ACB\u4F7F\u7528\u5BC6\u78BC\u9A57\u8B49"
            });
            return _this3.nav.routeTo('/wallet-sign-in', {
              onlyPwd: true
            });
          } else {
            _this3.alert({
              bodyMessage: "\u8ACB\u5148\u524D\u5F80\u624B\u6A5F\u7CFB\u7D71\u4E2D\u9304\u5165\u6307\u7D0B"
            });
          }
          return;
        }
      } catch (error) {
        if (_this3.enableFingerprint === true) {
          /// 用不了的情况下，提示用密码
          _this3.console.error('NativeBiometric.isAvailable:', error);
          /// 开启了，但是系统取消了，需要使用密码关闭
          yield _this3.alert({
            bodyMessage: "\u6307\u7D0B\u9A57\u8B49\u7121\u6CD5\u555F\u52D5\uFF0C\u8ACB\u4F7F\u7528\u5BC6\u78BC\u9A57\u8B49"
          });
          return _this3.nav.routeTo('/wallet-sign-in', {
            onlyPwd: true
          });
        } else {
          _this3.alert({
            bodyMessage: "\u8ACB\u5148\u524D\u5F80\u624B\u6A5F\u7CFB\u7D71\u4E2D\u9304\u5165\u6307\u7D0B"
          });
          return;
        }
      }
      let goVerify = true;
      if (_this3.enableFingerprint) {
        goVerify = yield _this3.confirm({
          bodyMessage: "\u78BA\u5B9A\u8981\u95DC\u9589\u6307\u7D0B\u9396\u55CE\uFF1F",
          confirmText: "\u78BA\u5B9A",
          cancelText: "\u53D6\u6D88",
          footerTheme: 'blank'
        });
      }
      if (goVerify) {
        _this3.nav.routeTo('/mime/verify-fingerprint');
      }
    })();
  }
}
_class = ApplicationLockPage;
_class.ɵfac = /*@__PURE__*/(() => {
  let ɵApplicationLockPage_BaseFactory;
  return function ApplicationLockPage_Factory(t) {
    return (ɵApplicationLockPage_BaseFactory || (ɵApplicationLockPage_BaseFactory = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵgetInheritedFactory"](_class)))(t || _class);
  };
})();
_class.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdefineComponent"]({
  type: _class,
  selectors: [["w-application-lock"]],
  standalone: true,
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵInheritDefinitionFeature"], _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵStandaloneFeature"]],
  decls: 17,
  vars: 4,
  consts: () => {
    let i18n_0;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_APPLICATION_LOCK$$APPS_WALLET_SRC_PAGES_MIME_PAGES_APPLICATION_LOCK_APPLICATION_LOCK_COMPONENT_TS_1 = goog.getMsg("Application lock");
      i18n_0 = MSG_EXTERNAL_APPLICATION_LOCK$$APPS_WALLET_SRC_PAGES_MIME_PAGES_APPLICATION_LOCK_APPLICATION_LOCK_COMPONENT_TS_1;
    } else {
      i18n_0 = "\u61C9\u7528\u9396";
    }
    let i18n_2;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_PASSWORD_LOCK$$APPS_WALLET_SRC_PAGES_MIME_PAGES_APPLICATION_LOCK_APPLICATION_LOCK_COMPONENT_TS_3 = goog.getMsg("Password Lock");
      i18n_2 = MSG_EXTERNAL_PASSWORD_LOCK$$APPS_WALLET_SRC_PAGES_MIME_PAGES_APPLICATION_LOCK_APPLICATION_LOCK_COMPONENT_TS_3;
    } else {
      i18n_2 = "\u5BC6\u78BC\u9396";
    }
    let i18n_4;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_TOUCH_ID$$APPS_WALLET_SRC_PAGES_MIME_PAGES_APPLICATION_LOCK_APPLICATION_LOCK_COMPONENT_TS_5 = goog.getMsg("Touch ID");
      i18n_4 = MSG_EXTERNAL_TOUCH_ID$$APPS_WALLET_SRC_PAGES_MIME_PAGES_APPLICATION_LOCK_APPLICATION_LOCK_COMPONENT_TS_5;
    } else {
      i18n_4 = "\u6307\u7D0B\u9396";
    }
    return [["headerTitle", i18n_0, 3, "headerTranslucent", "contentBackground"], [1, "px-page-safe-area-inset", "mt-[0.375rem]", "h-14", "w-full", "bg-white"], [1, "flex", "h-14", "items-center", "justify-between"], [1, "flex", "items-center"], ["name", "lock", 1, "icon-5.5", "mr-1.5"], [1, "text-title"], i18n_2, [1, "flex", "items-center", "justify-end"], [3, "checked", "click"], [1, "px-page-safe-area-inset", "h-14", "w-full", "bg-white"], ["name", "al-touch-id", 1, "icon-5.5", "mr-1.5"], i18n_4];
  },
  template: function ApplicationLockPage_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "common-page", 0)(1, "div", 1)(2, "div", 2)(3, "div", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](4, "w-icon", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](5, "span", 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵi18n"](6, 6);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](7, "div", 7)(8, "bn-toggle", 8);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("click", function ApplicationLockPage_Template_bn_toggle_click_8_listener() {
        return ctx.switchPasswordLock();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()()()();
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](9, "div", 9)(10, "div", 2)(11, "div", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](12, "w-icon", 10);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](13, "span", 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵi18n"](14, 11);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](15, "div", 7)(16, "bn-toggle", 8);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("click", function ApplicationLockPage_Template_bn_toggle_click_16_listener() {
        return ctx.switchFingerprint();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()()()()();
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("headerTranslucent", false)("contentBackground", "env");
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](8);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("checked", ctx.enablePasswordLock);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](8);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("checked", ctx.enableFingerprint);
    }
  },
  dependencies: [_modules_page_module__WEBPACK_IMPORTED_MODULE_7__.CommonPageModule, _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_11__.CommonPageComponent, _components_icon_icon_component__WEBPACK_IMPORTED_MODULE_12__.IconComponent, _bnqkl_framework_components__WEBPACK_IMPORTED_MODULE_1__.ToggleComponent],
  styles: ["[_nghost-%COMP%]   bn-toggle[_ngcontent-%COMP%] {\n  --checked-background: #897aa3;\n  --unchecked-background: #ffffff;\n  --border-color: #897aa3;\n  --handle-background: #897aa3;\n  --handle-background-checked: #ffffff;\n  --height: 1.25rem;\n  --width: 2.25rem;\n  --handle-width: 0.75rem;\n  --handle-height: 0.75rem;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL2FwcHMvd2FsbGV0L3NyYy9wYWdlcy9taW1lL3BhZ2VzL2FwcGxpY2F0aW9uLWxvY2svYXBwbGljYXRpb24tbG9jay5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFDRTtFQUNFLDZCQUFBO0VBQ0EsK0JBQUE7RUFDQSx1QkFBQTtFQUNBLDRCQUFBO0VBQ0Esb0NBQUE7RUFDQSxpQkFBQTtFQUNBLGdCQUFBO0VBQ0EsdUJBQUE7RUFDQSx3QkFBQTtBQUFKIiwic291cmNlc0NvbnRlbnQiOlsiOmhvc3Qge1xyXG4gIGJuLXRvZ2dsZSB7XHJcbiAgICAtLWNoZWNrZWQtYmFja2dyb3VuZDogIzg5N2FhMztcclxuICAgIC0tdW5jaGVja2VkLWJhY2tncm91bmQ6ICNmZmZmZmY7XHJcbiAgICAtLWJvcmRlci1jb2xvcjogIzg5N2FhMztcclxuICAgIC0taGFuZGxlLWJhY2tncm91bmQ6ICM4OTdhYTM7XHJcbiAgICAtLWhhbmRsZS1iYWNrZ3JvdW5kLWNoZWNrZWQ6ICNmZmZmZmY7XHJcbiAgICAtLWhlaWdodDogMS4yNXJlbTtcclxuICAgIC0td2lkdGg6IDIuMjVyZW07XHJcbiAgICAtLWhhbmRsZS13aWR0aDogMC43NXJlbTtcclxuICAgIC0taGFuZGxlLWhlaWdodDogMC43NXJlbTtcclxuICB9XHJcbn1cclxuIl0sInNvdXJjZVJvb3QiOiIifQ== */"],
  changeDetection: 0
});
(0,tslib__WEBPACK_IMPORTED_MODULE_14__.__decorate)([ApplicationLockPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_14__.__metadata)("design:type", Object)], ApplicationLockPage.prototype, "verifyFingerprintPageReturnController", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_14__.__decorate)([ApplicationLockPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_14__.__metadata)("design:type", Object)], ApplicationLockPage.prototype, "walletSignInPageReturnController", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_14__.__decorate)([ApplicationLockPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_14__.__metadata)("design:type", Object)], ApplicationLockPage.prototype, "enablePasswordLock", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_14__.__decorate)([ApplicationLockPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_14__.__metadata)("design:type", Object)], ApplicationLockPage.prototype, "enableFingerprint", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_14__.__decorate)([ApplicationLockPage.OnInit(), (0,tslib__WEBPACK_IMPORTED_MODULE_14__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_14__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_14__.__metadata)("design:returntype", Promise)], ApplicationLockPage.prototype, "getMainWalletInfo", null);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ApplicationLockPage);

/***/ }),

/***/ 11606:
/*!************************************************************!*\
  !*** ./libs/bnf/controllers/form-validators.controller.ts ***!
  \************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   FormValidatorsController: () => (/* binding */ FormValidatorsController)
/* harmony export */ });
/* harmony import */ var _bnqkl_framework_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @bnqkl/framework/core */ 63563);
/* harmony import */ var _bnqkl_util_web_extends_map__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @bnqkl/util-web/extends-map */ 37689);


/**
 * 页面表单扩展验证器
 *
 * > 因为涉及到FromControl的生命周期管理，所以这里需要使用Controller模式来获取组件/页面的生命周期
 *
 * 为了确保类型安全, 请遵循以下规则去定义验证器:
 * 1. 尽可能直接提供 $ValidatorFn,比如 `trimRequired(control: AbstractControl): $ValidationErrors | null {...}`
 * 2. 如果不能直接提供 $ValidatorFn, 那么作为工厂模式,必然要有参数传入,比如 `equals(leaderCtrl: AbstractControl): $ValidatorFn {...}`
 */
class FormValidatorsController {
  /**
   * 通过订阅原页面的生命周期，来对订阅的字段进行监听解除
   */
  constructor(comp) {
    /**
     * 判断两个数据字段相等的时，left===right 中 left的数据订阅
     */
    this._equalsLeaderMap = _bnqkl_util_web_extends_map__WEBPACK_IMPORTED_MODULE_1__.EasyMap.from({
      creater(ctrl) {
        const sub = {
          sub$: ctrl.valueChanges.subscribe(() => {
            for (const ctrl of sub.destControls) {
              ctrl.updateValueAndValidity();
            }
          }),
          destControls: new Set()
        };
        return sub;
      }
    });
    (0,_bnqkl_framework_core__WEBPACK_IMPORTED_MODULE_0__.addLifecycleMethods)(comp, 'ngOnDestroy', {
      origin: 'form-validator',
      method: () => {
        for (const {
          sub$
        } of this._equalsLeaderMap.values()) {
          sub$.unsubscribe();
        }
        this._equalsLeaderMap.clear();
      },
      order: Number.MAX_SAFE_INTEGER /* 最后才做这些事情 */
    });
  }
  /** 两个字段对比 相等就过 不相等返回 {equals:true} */
  equals(leaderCtrl) {
    const leader = this._equalsLeaderMap.forceGet(leaderCtrl);
    // pwdCtrl.val
    return follerCtrl => {
      leader.destControls.add(follerCtrl);
      if (leaderCtrl.value === follerCtrl.value) {
        return null;
      }
      return {
        equals: true
      };
    };
  }
  /** 是否包含空格 */
  whitespace(control) {
    const value = control.value;
    if (typeof value === 'string' && /\s/.test(value)) {
      return {
        whitespace: true
      };
    }
    return null;
  }
  /** required 变体, 左右两边不能包含空格 */
  trimRequired(control) {
    const value = control.value;
    if (typeof value === 'string' && value.trim().length === 0 || value == undefined) {
      return {
        trimRequired: true
      };
    }
    return null;
  }
}

/***/ }),

/***/ 47919:
/*!***************************************!*\
  !*** ./libs/bnf/controllers/index.ts ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   FormValidatorsController: () => (/* reexport safe */ _form_validators_controller__WEBPACK_IMPORTED_MODULE_0__.FormValidatorsController),
/* harmony export */   PageReturnController: () => (/* reexport safe */ _page_return_controller__WEBPACK_IMPORTED_MODULE_1__.PageReturnController)
/* harmony export */ });
/* harmony import */ var _form_validators_controller__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./form-validators.controller */ 11606);
/* harmony import */ var _page_return_controller__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./page-return.controller */ 62893);



/***/ }),

/***/ 62893:
/*!********************************************************!*\
  !*** ./libs/bnf/controllers/page-return.controller.ts ***!
  \********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   PageReturnController: () => (/* binding */ PageReturnController)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 54106);
/* harmony import */ var _bnqkl_util_web_decorator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @bnqkl/util-web/decorator */ 18112);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs */ 19177);



/**
 * 页面数据返回值的订阅功能
 * > Controller 必须在构造函数期间执行
 */
class PageReturnController {
  /** 继承日志 */
  get console() {
    return this.fromPage.console;
  }
  /**
   * 传入源页面与目标页面的构造函数，并通过订阅原页面的生命周期，来初始化对路由的订阅
   * 这里依赖 ion-router-outlet 来获取跳转过去的页面
   * 注：该监听返回是全触发（只要页面没被销毁掉不管页面是否处于激活状态）
   * @param specific 用于指定fromPage触发（需要手动指定），业务需要
   */
  constructor(fromPage, toPageCtor, specific = false) {
    this.fromPage = fromPage;
    /** 当前定阅过的页面 */
    this._toPages = new WeakSet();
    /**
     * 订阅到的返回内容，
     * 类型由对应页面的 returnValue$ 的定义决定
     */
    this.pageReturn$ = new rxjs__WEBPACK_IMPORTED_MODULE_1__.Subject();
    const {
      nav
    } = fromPage;
    fromPage.takeUntilDestroy(nav.pageActiveState$).subscribe(event => {
      /// 只监听新激活的页面
      if (event.type !== 'activate') {
        return;
      }
      const toPage = event.target;
      if (toPage instanceof toPageCtor &&
      // 去重
      this._toPages.has(toPage) === false) {
        if (toPage.returnValue$ === undefined) {
          return;
        }
        this._toPages.add(toPage);
        if (specific) {
          var _toPage$specificRetur;
          (_toPage$specificRetur = toPage.specificReturnPages) === null || _toPage$specificRetur === void 0 || _toPage$specificRetur.add(fromPage);
        }
        fromPage.takeUntilDestroy(toPage.returnValue$).subscribe({
          next: data => {
            /// 这里不用判断specific
            if (toPage.specificReturnPages && toPage.specificReturnPages.size) {
              /// 如果有写入，那么就只需要触发相对应页面就行
              toPage.specificReturnPages.has(fromPage) && this.pageReturn$.next(data);
              return;
            }
            this.pageReturn$.next(data);
          },
          complete: () => {
            var _toPage$specificRetur2;
            // 释放内存引用
            (_toPage$specificRetur2 = toPage.specificReturnPages) === null || _toPage$specificRetur2 === void 0 || _toPage$specificRetur2.delete(fromPage);
            return this._toPages.delete(toPage);
          }
        });
      }
    });
  }
}
(0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([_bnqkl_util_web_decorator__WEBPACK_IMPORTED_MODULE_0__.cacheGetter, (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__metadata)("design:type", Object), (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__metadata)("design:paramtypes", [])], PageReturnController.prototype, "console", null);

/***/ }),

/***/ 69899:
/*!*****************************************************************************************!*\
  !*** ./node_modules/.pnpm/@plaoc+is-dweb@0.1.0/node_modules/@plaoc/is-dweb/esm/main.js ***!
  \*****************************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   dwebTarget: () => (/* binding */ dwebTarget),
/* harmony export */   isDweb: () => (/* binding */ isDweb),
/* harmony export */   isMobile: () => (/* binding */ isMobile)
/* harmony export */ });
/**
 * 判断是不是dweb
 * * @returns boolean
 */
const isDweb = () => {
  const isDweb = self.navigator.userAgent.includes("Dweb");
  // @ts-ignore
  const isPlaoc = self.__native_close_watcher_kit__ !== void 0;
  if (isDweb || isPlaoc) {
    return true;
  }
  const userAgentData = self.navigator.userAgentData;
  if (!userAgentData) {
    return false;
  }
  const brands = userAgentData.brands.filter(value => {
    return value.brand === "DwebBrowser";
  });
  return Array.isArray(brands) && brands.length > 0;
};
/**
 * 判断dweb大版本
 * @returns boolean
 */
const dwebTarget = () => {
  if (isDweb()) {
    const userAgentData = self.navigator.userAgentData;
    if (!userAgentData) {
      return 2.0;
    }
    const brands = userAgentData.brands.filter(value => {
      return value.brand === "jmm.browser.dweb";
    });
    if (Array.isArray(brands) && brands.length > 0) {
      return parseFloat(brands[0].version);
    }
  }
  return 1.0;
};
/**
 * 判断是否是移动端
 * @returns boolean
 */
const isMobile = () => {
  if (!navigator.userAgentData) {
    return true;
  }
  return !!navigator.userAgentData.mobile;
};

/***/ })

}]);
//# sourceMappingURL=apps_wallet_src_pages_mime_pages_application-lock_application-lock_component_ts.js.map