"use strict";
(self["webpackChunkwallet"] = self["webpackChunkwallet"] || []).push([["apps_wallet_src_pages_mnemonic_pages_home-token-details_home-token-details_component_ts"],{

/***/ 10519:
/*!*************************************************************************************************!*\
  !*** ./apps/wallet/src/pages/mnemonic/pages/home-token-details/home-token-details.component.ts ***!
  \*************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   HomeTokenDetailsPage: () => (/* binding */ HomeTokenDetailsPage),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 52542);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! tslib */ 90505);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! @angular/core */ 61039);
/* harmony import */ var _bnqkl_framework_controllers__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @bnqkl/framework/controllers */ 47919);
/* harmony import */ var _bnqkl_framework_pipes__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @bnqkl/framework/pipes */ 80909);
/* harmony import */ var _bnqkl_framework_plugins_browser__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @bnqkl/framework/plugins/browser */ 93173);
/* harmony import */ var _bnqkl_util_web_extends_promise__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @bnqkl/util-web/extends-promise */ 87778);
/* harmony import */ var _bnqkl_wallet_base_services_wallet_chain__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @bnqkl/wallet-base/services/wallet/chain */ 27434);
/* harmony import */ var _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @bnqkl/wallet-base/services/wallet/chain-base */ 27187);
/* harmony import */ var _modules_page_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ~modules/page.module */ 77538);
/* harmony import */ var _home_transfer_home_transfer_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../home-transfer/home-transfer.component */ 7406);
/* harmony import */ var _libs_bnf_components_ripple_button_ripple_button_directive__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../../../../../../libs/bnf/components/ripple-button/ripple-button.directive */ 16505);
/* harmony import */ var _libs_bnf_components_pull_to_refresh_pull_to_refresh_directive__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../../../../../../libs/bnf/components/pull-to-refresh/pull-to-refresh.directive */ 97063);
/* harmony import */ var _libs_bnf_components_pull_to_refresh_pull_to_refresh_spinner_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../../../../../../libs/bnf/components/pull-to-refresh/pull-to-refresh-spinner.component */ 75387);
/* harmony import */ var _libs_bnf_components_infinite_scroll_infinite_scroll_spinner_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../../../../../../libs/bnf/components/infinite-scroll/infinite-scroll-spinner.component */ 66560);
/* harmony import */ var _libs_bnf_components_infinite_scroll_infinite_scroll_directive__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../../../../../../../libs/bnf/components/infinite-scroll/infinite-scroll.directive */ 10320);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! @angular/common */ 6729);
/* harmony import */ var _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../../../../../../../libs/bnf/modules/page/common-page/common-page.component */ 62052);
/* harmony import */ var _components_icon_icon_component__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ../../../../components/icon/icon.component */ 74703);
/* harmony import */ var _libs_bnf_components_loading_wrapper_loading_wrapper_component__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ../../../../../../../libs/bnf/components/loading-wrapper/loading-wrapper.component */ 51263);
/* harmony import */ var _libs_bnf_pipes_day_format_day_format_pipe__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ../../../../../../../libs/bnf/pipes/day-format/day-format.pipe */ 24562);
/* harmony import */ var _pipes_color_color_pipe__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ../../../../pipes/color/color.pipe */ 76489);

var _class;






















const _c0 = ["transactionListContent"];
const _c13 = a0 => ({
  "--index": a0
});
function HomeTokenDetailsPage_div_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r9 = _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementStart"](0, "div", 14)(1, "div", 15)(2, "button", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵlistener"]("click", function HomeTokenDetailsPage_div_2_Template_button_click_2_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵrestoreView"](_r9);
      const ctx_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵresetView"](ctx_r8.selectTransType(ctx_r8.FIND_TRANS_TYPE.ALL));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵi18n"](3, 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementStart"](4, "button", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵlistener"]("click", function HomeTokenDetailsPage_div_2_Template_button_click_4_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵrestoreView"](_r9);
      const ctx_r10 = _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵresetView"](ctx_r10.selectTransType(ctx_r10.FIND_TRANS_TYPE.INTO));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵi18n"](5, 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementStart"](6, "button", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵlistener"]("click", function HomeTokenDetailsPage_div_2_Template_button_click_6_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵrestoreView"](_r9);
      const ctx_r11 = _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵresetView"](ctx_r11.selectTransType(ctx_r11.FIND_TRANS_TYPE.OUT));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵi18n"](7, 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementStart"](8, "button", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵlistener"]("click", function HomeTokenDetailsPage_div_2_Template_button_click_8_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵrestoreView"](_r9);
      const ctx_r12 = _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵresetView"](ctx_r12.selectTransType(ctx_r12.FIND_TRANS_TYPE.FAIL));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵi18n"](9, 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelement"](10, "div", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"](10);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵproperty"]("ngStyle", _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpureFunction1"](1, _c13, ctx_r0.selectIndex));
  }
}
const _c14 = a0 => ({
  list: a0
});
function HomeTokenDetailsPage_div_4_ng_container_3_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementContainer"](0, 27);
  }
  if (rf & 2) {
    const ctx_r14 = _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵnextContext"](2);
    const _r5 = _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵreference"](14);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵproperty"]("ngTemplateOutlet", _r5)("ngTemplateOutletContext", _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpureFunction1"](2, _c14, ctx_r14.currentConfig.list));
  }
}
function HomeTokenDetailsPage_div_4_bn_infinite_scroll_spinner_4_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementStart"](0, "bn-infinite-scroll-spinner")(1, "span", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵi18n"](2, 29);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementEnd"]()();
  }
}
function HomeTokenDetailsPage_div_4_Template(rf, ctx) {
  if (rf & 1) {
    const _r17 = _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementStart"](0, "div", 22, 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵlistener"]("pulled$", function HomeTokenDetailsPage_div_4_Template_div_pulled__0_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵrestoreView"](_r17);
      const ctx_r16 = _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵresetView"]($event.waitFor(ctx_r16.resetTransList()));
    })("infinited$", function HomeTokenDetailsPage_div_4_Template_div_infinited__0_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵrestoreView"](_r17);
      const ctx_r18 = _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵresetView"]($event.waitFor(ctx_r18.loadMoreTransList()));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelement"](2, "bn-pull-to-refresh-spinner", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtemplate"](3, HomeTokenDetailsPage_div_4_ng_container_3_Template, 1, 4, "ng-container", 25)(4, HomeTokenDetailsPage_div_4_bn_infinite_scroll_spinner_4_Template, 3, 0, "bn-infinite-scroll-spinner", 26);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵnextContext"]();
    const _r7 = _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵreference"](16);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵproperty"]("hasMore", ctx_r1.resetTransListLoading === false && ctx_r1.currentConfig.hasMore);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵproperty"]("ngIf", ctx_r1.currentConfig.list.length)("ngIfElse", _r7);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵproperty"]("ngIf", ctx_r1.resetTransListLoading === false && ctx_r1.currentConfig.hasMore);
  }
}
function HomeTokenDetailsPage_ng_template_5_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementStart"](0, "div", 30);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelement"](1, "bn-loading-wrapper", 31);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementStart"](2, "p", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵi18n"](3, 32);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵproperty"]("showLoading", true);
  }
}
function HomeTokenDetailsPage_ng_template_13_ng_container_0_button_1_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelement"](1, "w-icon", 47);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementContainerEnd"]();
  }
}
const _c19 = (a0, a1) => ({
  "--color-1": a0,
  "--color-2": a1
});
function HomeTokenDetailsPage_ng_template_13_ng_container_0_button_1_ng_template_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelement"](0, "w-icon", 48);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipe"](1, "color");
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipe"](2, "color");
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵproperty"]("ngStyle", _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpureFunction2"](5, _c19, _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipeBind1"](1, 1, "primary"), _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipeBind1"](2, 3, "primary")));
  }
}
function HomeTokenDetailsPage_ng_template_13_ng_container_0_button_1_ng_container_9_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementStart"](1, "div", 49);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵi18n"](2, 50);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementContainerEnd"]();
  }
}
function HomeTokenDetailsPage_ng_template_13_ng_container_0_button_1_ng_container_10_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementContainer"](0);
  }
}
function HomeTokenDetailsPage_ng_template_13_ng_container_0_button_1_ng_container_11_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementStart"](1, "div", 51);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵi18n"](2, 52);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementContainerEnd"]();
  }
}
function HomeTokenDetailsPage_ng_template_13_ng_container_0_button_1_ng_container_12_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementStart"](1, "div", 53);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵi18n"](2, 54);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementContainerEnd"]();
  }
}
function HomeTokenDetailsPage_ng_template_13_ng_container_0_button_1_Conditional_14_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementStart"](0, "div", 55);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const item_r21 = _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵnextContext"](2).$implicit;
    const ctx_r30 = _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtextInterpolate"](ctx_r30.getTranscationTypeName(item_r21));
  }
}
function HomeTokenDetailsPage_ng_template_13_ng_container_0_button_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r34 = _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementStart"](0, "button", 35);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵlistener"]("click", function HomeTokenDetailsPage_ng_template_13_ng_container_0_button_1_Template_button_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵrestoreView"](_r34);
      const item_r21 = _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵnextContext"]().$implicit;
      const ctx_r32 = _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵresetView"](ctx_r32.goToTrsDetails(item_r21));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtemplate"](1, HomeTokenDetailsPage_ng_template_13_ng_container_0_button_1_ng_container_1_Template, 2, 0, "ng-container", 36)(2, HomeTokenDetailsPage_ng_template_13_ng_container_0_button_1_ng_template_2_Template, 3, 8, "ng-template", null, 37, _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtemplateRefExtractor"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementStart"](4, "div", 38)(5, "div", 39)(6, "div", 40);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtext"](7);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementContainerStart"](8, 41);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtemplate"](9, HomeTokenDetailsPage_ng_template_13_ng_container_0_button_1_ng_container_9_Template, 3, 0, "ng-container", 42)(10, HomeTokenDetailsPage_ng_template_13_ng_container_0_button_1_ng_container_10_Template, 1, 0, "ng-container", 42)(11, HomeTokenDetailsPage_ng_template_13_ng_container_0_button_1_ng_container_11_Template, 3, 0, "ng-container", 42)(12, HomeTokenDetailsPage_ng_template_13_ng_container_0_button_1_ng_container_12_Template, 3, 0, "ng-container", 43);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementContainerEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementStart"](13, "div", 44);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtemplate"](14, HomeTokenDetailsPage_ng_template_13_ng_container_0_button_1_Conditional_14_Template, 2, 1, "div", 45);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementStart"](15, "div", 46);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtext"](16);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipe"](17, "dayFormat");
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementEnd"]()()()();
  }
  if (rf & 2) {
    const _r25 = _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵreference"](3);
    const item_r21 = _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵnextContext"]().$implicit;
    const ctx_r22 = _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵproperty"]("ngIf", ctx_r22.getInOrOutIcon(item_r21))("ngIfElse", _r25);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtextInterpolate1"](" ", ctx_r22.getShowTransactionAmount(item_r21), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵproperty"]("ngSwitch", item_r21.status);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵproperty"]("ngSwitchCase", ctx_r22.TRANS_STATUS.BROADCASTED);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵproperty"]("ngSwitchCase", ctx_r22.TRANS_STATUS.CONFIRM);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵproperty"]("ngSwitchCase", ctx_r22.TRANS_STATUS.EFFECTIVED);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵconditional"](14, item_r21.chain !== ctx_r22.CHAIN_NAME.Bitcoin ? 14 : -1);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipeBind1"](17, 9, item_r21.timestamp));
  }
}
function HomeTokenDetailsPage_ng_template_13_ng_container_0_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtemplate"](1, HomeTokenDetailsPage_ng_template_13_ng_container_0_button_1_Template, 18, 11, "button", 34);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const item_r21 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵproperty"]("ngIf", !item_r21.hidden);
  }
}
function HomeTokenDetailsPage_ng_template_13_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtemplate"](0, HomeTokenDetailsPage_ng_template_13_ng_container_0_Template, 2, 1, "ng-container", 33);
  }
  if (rf & 2) {
    const list_r19 = ctx.list;
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵproperty"]("ngForOf", list_r19);
  }
}
function HomeTokenDetailsPage_ng_template_15_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementStart"](0, "div", 30);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelement"](1, "w-icon", 56);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementStart"](2, "span", 57);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵi18n"](3, 58);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementEnd"]()();
  }
}
class HomeTokenDetailsPage extends _modules_page_module__WEBPACK_IMPORTED_MODULE_7__.CommonPageBase {
  constructor() {
    super(...arguments);
    this.CHAIN_NAME = _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_6__.CHAIN_NAME;
    /** 链服务 */
    this.chainV2Service = (0,_angular_core__WEBPACK_IMPORTED_MODULE_19__.inject)(_bnqkl_wallet_base_services_wallet_chain__WEBPACK_IMPORTED_MODULE_5__.ChainV2Service);
    /** 资产信息 */
    this.assetInfo = {
      symbol: '',
      assetType: '',
      chain: '',
      decimals: 0,
      address: '',
      contractAddress: undefined,
      fingerprint: undefined
    };
    /** 获取地址信息的key */
    this.addressKey = '';
    /** 转账页面返回 */
    this.homeTransferPageReturnController = new _bnqkl_framework_controllers__WEBPACK_IMPORTED_MODULE_1__.PageReturnController(this, _home_transfer_home_transfer_component__WEBPACK_IMPORTED_MODULE_8__["default"]);
    /**  是否是生物链林-链 */
    this.isBioforestChain = false;
    /** 交易状态 */
    this.TRANS_STATUS = _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_6__.TRANS_STATUS;
    /** 列表查询类别 */
    this.FIND_TRANS_TYPE = _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_6__.FIND_TRANS_TYPE;
    /** 当前选择类别 */
    this.selectType = _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_6__.FIND_TRANS_TYPE.ALL;
    /**
     * 状态列表信息
     */
    this.findConfigList = [{
      page: 1,
      pageSize: 50,
      hasMore: false,
      type: _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_6__.FIND_TRANS_TYPE.ALL,
      list: [],
      init: false
    }, {
      page: 1,
      pageSize: 50,
      hasMore: false,
      type: _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_6__.FIND_TRANS_TYPE.INTO,
      list: [],
      init: false
    }, {
      page: 1,
      pageSize: 50,
      hasMore: false,
      type: _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_6__.FIND_TRANS_TYPE.OUT,
      list: [],
      init: false
    }, {
      page: 1,
      pageSize: 50,
      hasMore: false,
      type: _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_6__.FIND_TRANS_TYPE.FAIL,
      list: [],
      init: false
    }];
    /** 是否处于下拉刷新中 */
    this.resetTransListLoading = false;
  }
  /** 自定义title */
  get title() {
    return "" + this.assetInfo.assetType + " Details";
  }
  pageInit() {
    this.isBioforestChain = this.resolveData.isBioforestChain;
  }
  /** 初始化获取传参 */
  getWalletInfoAndMnemonic() {
    var _this = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      /** 设置页面信息 */
      const setAssetInfo = /*#__PURE__*/function () {
        var _ref = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (info) {
          /// 基本信息
          _this.assetInfo.assetType = info.assetType;
          _this.assetInfo.decimals = info.decimals;
          _this.addressKey = info.addressKey;
          _this.assetInfo.chain = info.chain;
          /// 根据基本信息获取相关数据
          const addressInfo = yield _this.chainV2Service.getChainAddressInfoByAddressKey(_this.addressKey);
          _this.assetInfo.address = addressInfo.address;
          _this.assetInfo.symbol = _this.chainV2Service.getChainInfo(info.chain).symbol;
          const asset = addressInfo.assets.find(item => item.assetType === info.assetType);
          asset && (_this.assetInfo.contractAddress = asset.contractAddress || '');
          if (info.fromTransaction === true || info.fromTransaction === 'true') {
            /// 刷新交易列表
            _this.findConfigList.forEach(item => {
              item.hasMore = false;
              item.page = 1;
              item.list.length = 0;
              item.loadingPromiseOut && item.loadingPromiseOut.reject(false);
              item.loadingPromiseOut = undefined;
            });
            _this._pendingListPromise = undefined;
            _this.queryTransList();
          }
          _this.cdRef.detectChanges();
        });
        return function setAssetInfo(_x) {
          return _ref.apply(this, arguments);
        };
      }();
      /// 通过页面进入
      const {
        _data
      } = _this;
      yield setAssetInfo(_data);
      /// 通过页面返回值触发
      _this.homeTransferPageReturnController.pageReturn$.subscribe( /*#__PURE__*/function () {
        var _ref2 = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (data) {
          return data && setAssetInfo(data);
        });
        return function (_x2) {
          return _ref2.apply(this, arguments);
        };
      }());
      _this.queryTransList();
      _this.cdRef.detectChanges();
    })();
  }
  /** 跳转到资产详情 */
  goToDetails() {
    var _this2 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const addressInfo = yield _this2.chainV2Service.getChainAddressInfoByAddressKey(_this2.addressKey);
      _bnqkl_framework_plugins_browser__WEBPACK_IMPORTED_MODULE_3__.Browser.open({
        url: _this2.chainV2Service.getChainScanAddressInfoURL(_this2.assetInfo.chain, addressInfo.address)
      });
    })();
  }
  /** 跳转到转账页 */
  goToTransfer() {
    return this.nav.routeTo('/mnemonic/home-transfer', {
      assetType: this.assetInfo.assetType
    });
  }
  /** 跳转到收款页 */
  goToReceive() {
    var _this3 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const addressInfo = yield _this3.chainV2Service.getChainAddressInfoByAddressKey(_this3.addressKey);
      return _this3.nav.routeTo('/home-receive', {
        chain: _this3.assetInfo.chain,
        address: addressInfo.address,
        assetType: _this3.assetInfo.assetType
      });
    })();
  }
  /**
   * 获取地址在本次交易的资产变化
   * @param transaction 交易
   * @param address 关联的地址
   */
  getBitconTransferAmountChanges(transaction, address) {
    const vin = transaction.vin;
    const vout = transaction.vout;
    const inList = vin.filter(item => {
      return item.addresses.includes(address);
    });
    const outList = vout.filter(item => {
      return item.addresses.includes(address);
    });
    const inAmount_BI = inList.reduce((v, item) => {
      return v + BigInt(item.value);
    }, BigInt(0));
    const outAmount_BI = outList.reduce((v, item) => {
      return v + BigInt(item.value);
    }, BigInt(0));
    return outAmount_BI - inAmount_BI;
  }
  /** 根据当前状态选择，返回对应↑↓图标 */
  getInOrOutIcon(item) {
    let {
      recipientId,
      senderId
    } = item;
    let walletAddress = this.assetInfo.address;
    if (item.chain === _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_6__.CHAIN_NAME.Bitcoin) {
      const amountChanges_BI = this.getBitconTransferAmountChanges(item.transaction, walletAddress);
      return BigInt(0) <= amountChanges_BI;
    }
    if (item.chain === _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_6__.CHAIN_NAME.Binance || item.chain === _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_6__.CHAIN_NAME.Ethereum) {
      recipientId && (recipientId = recipientId.toLowerCase());
      senderId = senderId.toLowerCase();
      walletAddress = walletAddress.toLowerCase();
    }
    switch (this.selectType) {
      case _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_6__.FIND_TRANS_TYPE.INTO:
        return recipientId === walletAddress ? true : false;
      case _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_6__.FIND_TRANS_TYPE.OUT:
      default:
        return senderId === walletAddress ? false : true;
    }
  }
  // #region 查询记录
  selectTransType(type) {
    var _this$transactionList;
    if (type === this.selectType) {
      return;
    }
    this.selectType = type;
    /// 如果没有数据重新拉取一下
    if (this.currentConfig.list.length === 0 && this.currentConfig.loadingPromiseOut === undefined) {
      this.queryTransList();
    }
    (_this$transactionList = this.transactionListContentRef) === null || _this$transactionList === void 0 || _this$transactionList.nativeElement.scrollTo({
      top: 0
    });
  }
  /** 当前激活的索引 */
  get selectIndex() {
    return this.selectType - 1;
  }
  /** 当前激活项 */
  get currentConfig() {
    return this.findConfigList[this.selectIndex];
  }
  /** 重置列表 */
  resetTransList() {
    var _this4 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      if (_this4.resetTransListLoading || _this4.currentConfig.loadingPromiseOut) {
        return;
      }
      try {
        _this4.resetTransListLoading = true;
        const loadingPromiseOutTask = _this4.findConfigList.filter(item => item.loadingPromiseOut).map(item => item.loadingPromiseOut);
        yield Promise.all([...loadingPromiseOutTask, _this4._pendingListPromise]);
        /// 刷新交易列表
        _this4.findConfigList.forEach(item => {
          item.hasMore = false;
          item.page = 1;
          item.loadingPromiseOut = undefined;
        });
        _this4._pendingListPromise = undefined;
        if (_this4.isBioforestChain) {
          _this4.firstQueryBlockHeight = (yield _this4.chainV2Service.getChainService(_this4.assetInfo.chain).getBlockInfo()).height;
          const taks = _this4.findConfigList.map((item, index) => {
            return _this4.queryTransList(false, index);
          });
          yield Promise.all(taks);
        } else {
          if (_this4.assetInfo.fingerprint) {
            _this4.assetInfo.fingerprint = undefined;
          }
          yield _this4.queryTransList(false);
        }
      } catch (err) {
        _this4.console.error('resetTransList error:', err);
      } finally {
        _this4.resetTransListLoading = false;
      }
    })();
  }
  /** 加载更多 */
  loadMoreTransList() {
    var _this5 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      return _this5.queryTransList(true);
    })();
  }
  /**
   * 查询交易列表
   * 这里只负责拉数据，解析数据在别的地方
   * */
  queryTransList(loadMore = false, index) {
    var _this6 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const configInfo = _this6.findConfigList[index !== null && index !== void 0 ? index : _this6.selectIndex];
      if (configInfo.loadingPromiseOut) {
        return;
      }
      const queryType = configInfo.type;
      if (loadMore) {
        configInfo.page++;
      }
      configInfo.loadingPromiseOut = new _bnqkl_util_web_extends_promise__WEBPACK_IMPORTED_MODULE_4__.PromiseOut();
      try {
        const apiService = _this6.chainV2Service.getChainService(_this6.assetInfo.chain);
        if (_this6._pendingListPromise === undefined) {
          _this6._pendingListPromise = apiService.getAssetTypePendingTrans(_this6.assetInfo.address, _this6.assetInfo.assetType, _this6.assetInfo.decimals);
        }
        let queryTask;
        if (_this6.isBioforestChain) {
          const bioforestChainApi = apiService;
          if (_this6.firstQueryBlockHeight === undefined) {
            _this6.firstQueryBlockHeight = (yield bioforestChainApi.getBlockInfo()).height;
          }
          queryTask = bioforestChainApi.getAssetTypeTrans({
            address: _this6.assetInfo.address,
            findType: queryType,
            assetType: _this6.assetInfo.assetType === _this6.assetInfo.symbol ? '' : _this6.assetInfo.assetType,
            page: configInfo.page,
            pageSize: configInfo.pageSize,
            height: _this6.firstQueryBlockHeight
          });
        } else if (_this6.assetInfo.chain === _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_6__.CHAIN_NAME.Tron) {
          const tronChainApi = apiService;
          queryTask = tronChainApi.getAssetTypeTrans({
            address: _this6.assetInfo.address,
            pageSize: configInfo.pageSize,
            decimals: _this6.assetInfo.decimals,
            contractaddress: _this6.assetInfo.contractAddress,
            fingerprint: _this6.assetInfo.fingerprint
          });
        } else if (_this6.assetInfo.chain === _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_6__.CHAIN_NAME.Binance || _this6.assetInfo.chain === _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_6__.CHAIN_NAME.Ethereum) {
          const binanceChainApi = apiService;
          queryTask = binanceChainApi.getAssetTypeTrans({
            address: _this6.assetInfo.address,
            page: configInfo.page,
            pageSize: configInfo.pageSize,
            decimals: _this6.assetInfo.decimals,
            contractaddress: _this6.assetInfo.contractAddress
          });
        } else if (_this6.assetInfo.chain === _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_6__.CHAIN_NAME.Bitcoin) {
          const bitcoinChainApi = apiService;
          queryTask = bitcoinChainApi.getAssetTypeTrans({
            address: _this6.assetInfo.address,
            page: configInfo.page,
            pageSize: configInfo.pageSize,
            decimals: _this6.assetInfo.decimals
          });
        } else {
          throw new Error(`not set chain:${_this6.assetInfo.chain}`);
        }
        /// 没数据的时候 延时一下，避免闪屏不好看
        configInfo.list.length === 0 && (yield (0,_bnqkl_util_web_extends_promise__WEBPACK_IMPORTED_MODULE_4__.sleep)(350));
        /** 查询到的已确认列表 */
        const {
          list,
          hasMore,
          fingerprint
        } = yield queryTask;
        /** pending列表 */
        const pendingList = (yield _this6._pendingListPromise) || [];
        /// pending目前是全部返回
        const filter_Map = new Map();
        if (configInfo.page === 1) {
          list.push(...pendingList.filter(item => {
            let filters = false;
            const transaction = item.transaction;
            if (queryType === _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_6__.FIND_TRANS_TYPE.ALL) {
              filters = true;
            } else if (queryType === _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_6__.FIND_TRANS_TYPE.INTO) {
              filters = transaction.recipientId === _this6.assetInfo.address;
            } else if (queryType === _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_6__.FIND_TRANS_TYPE.OUT) {
              filters = transaction.senderId === _this6.assetInfo.address;
            }
            return filters;
          }));
        }
        /// 只对当前列表过滤
        list.forEach(item => {
          const old = filter_Map.get(item.signature);
          if (old === undefined) {
            filter_Map.set(item.signature, item);
          } else {
            /// 如果存在，那么判断那个是上链的，更新为上链
            if (old.status !== _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_6__.TRANS_STATUS.CONFIRM && item.status === _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_6__.TRANS_STATUS.CONFIRM) {
              filter_Map.set(item.signature, item);
            }
          }
        });
        const newList = [...filter_Map.values()].sort((a, b) => {
          /**
           * a 确认  b pending
           * a pending  b pending
           * a pending  b 确认
           * a pending  b 确认
           */
          if (a.status === _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_6__.TRANS_STATUS.CONFIRM) {
            if (b.status === _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_6__.TRANS_STATUS.CONFIRM) {
              return a.timestamp > b.timestamp ? -1 : 1;
            } else {
              return 1;
            }
          } else {
            if (b.status === _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_6__.TRANS_STATUS.CONFIRM) {
              return -1;
            } else {
              return a.timestamp > b.timestamp ? -1 : 1;
            }
          }
        });
        if (configInfo.page === 1 && configInfo.list.length) {
          configInfo.list.length = 0;
        }
        /// 对pending过滤
        configInfo.list.forEach(item => {
          if (item.status !== _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_6__.TRANS_STATUS.CONFIRM) {
            /** 上面过滤出来的数据 */
            const trsInfo = filter_Map.get(item.signature);
            if (trsInfo && trsInfo.status === _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_6__.TRANS_STATUS.CONFIRM) {
              item.hidden = true;
            }
          }
        });
        /// 过滤好了，排序一下，而且pending都在最前面
        configInfo.list.push(...newList);
        _this6.assetInfo.fingerprint = fingerprint;
        /// pending目前是全部返回
        configInfo.hasMore = hasMore;
        _this6.cdRef.detectChanges();
      } finally {
        configInfo.loadingPromiseOut && configInfo.loadingPromiseOut.resolve(true);
        configInfo.loadingPromiseOut = undefined;
        /**
         * 对于生物链 不管第几页，有数据说明初始化完成
         * 对于其他链，第一页需要铺满页面，最少list.length >= size
         */
        if (_this6.isBioforestChain === false) {
          /// 先判断条目够不够
          if (configInfo.init === false && configInfo.list.length <= configInfo.pageSize && configInfo.hasMore) {
            _this6.loadMoreTransList();
          } else {
            configInfo.init = true;
          }
        } else {
          configInfo.init = true;
        }
        _this6.cdRef.detectChanges();
      }
    })();
  }
  /** 跳转到交易详情 */
  goToTrsDetails(item) {
    /**
     * @TODO 这里应该在 resolver 中来实现
     */
    return this.nav.routeTo('/mnemonic/home-token-transaction-details', {
      trsStringify: JSON.stringify(item),
      status: item.status,
      userAddress: this.assetInfo.address,
      decimals: item.decimals,
      chain: this.assetInfo.chain
    });
  }
  /** 获取交易的变动 */
  getShowTransactionAmount(item, removeZero = true) {
    let walletAddress = this.assetInfo.address;
    const unknownTrs = "Unknown";
    let assetType = this.assetInfo.assetType;
    if (item.chain === _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_6__.CHAIN_NAME.Tron) {
      let amount = '';
      if (item.type === 0) {
        amount = item.amount;
        assetType = item.assetSymbol;
      } else if (item.type === 1) {
        amount = String(item.transaction.amount);
      } else {
        amount = item.transaction.value;
        assetType = item.transaction.token_symbol;
      }
      if (isNaN(+amount)) {
        return unknownTrs;
      }
      return `${item.senderId == walletAddress ? '-' : '+'} ${_bnqkl_framework_pipes__WEBPACK_IMPORTED_MODULE_2__.AmountFixedPipe.transform(amount, item.decimals, {
        removeZero,
        useGrouping: true
      })} ${assetType}`;
    } else if (this.chainV2Service.isBioforestChainByChainName(item.chain)) {
      return (0,_bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_6__.analysisBioforestChainTransactionAssetChange)(item.transaction, item.decimals, {
        ...this.assetInfo,
        chainName: this.assetInfo.chain
      }, removeZero, true, true).detection;
    } else if (item.chain === _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_6__.CHAIN_NAME.Binance || item.chain === _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_6__.CHAIN_NAME.Ethereum) {
      let {
        senderId
      } = item;
      senderId = senderId.toLowerCase();
      walletAddress = walletAddress.toLowerCase();
      let amount = '';
      if (item.type === 0) {
        amount = item.amount;
        assetType = item.assetSymbol;
      } else if (item.type === 1) {
        amount = String(item.transaction.value);
      } else {
        amount = item.transaction.value;
        assetType = item.transaction.tokenSymbol;
      }
      if (isNaN(+amount)) {
        return unknownTrs;
      }
      return `${senderId == walletAddress ? '-' : '+'} ${_bnqkl_framework_pipes__WEBPACK_IMPORTED_MODULE_2__.AmountFixedPipe.transform(amount, item.decimals, {
        removeZero,
        useGrouping: true
      })} ${assetType}`;
    } else if (item.chain === _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_6__.CHAIN_NAME.Bitcoin) {
      const amountChanges_BI = this.getBitconTransferAmountChanges(item.transaction, walletAddress);
      return `${amountChanges_BI <= BigInt(0) ? '' : '+'} ${_bnqkl_framework_pipes__WEBPACK_IMPORTED_MODULE_2__.AmountFixedPipe.transform(String(amountChanges_BI), item.decimals, {
        removeZero,
        useGrouping: true
      })} ${assetType}`;
    }
  }
  /** 获取交易名称 */
  getTranscationTypeName(item) {
    let walletAddress = this.assetInfo.address;
    let name = "Unregistered";
    if (this.chainV2Service.isBioforestChainByChainName(item.chain)) {
      const transaction = item.transaction;
      const {
        baseType
      } = (0,_bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_6__.getBioforestChainTransactionParseType)(transaction.type);
      const {
        typeName,
        i18n: typeNameI18n
      } = (0,_bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_6__.getBioforestChainTypeNameByBaseType)(this.assetInfo.chain, baseType, (0,_bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_6__.getBioforestChainTransactionParentAssetType)(transaction, this.assetInfo.chain));
      if (typeName && typeNameI18n) {
        /// 部分类型下，需要显示地址
        switch (baseType) {
          case _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_6__.BIOFOREST_CHAIN_TRANSACTION_TYPES_BASE.DAPP_PURCHASING:
          case _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_6__.BIOFOREST_CHAIN_TRANSACTION_TYPES_BASE.GRAB_ASSET:
          case _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_6__.BIOFOREST_CHAIN_TRANSACTION_TYPES_BASE.EMIGRATE_ASSET:
          case _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_6__.BIOFOREST_CHAIN_TRANSACTION_TYPES_BASE.IMMIGRATE_ASSET:
          case _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_6__.BIOFOREST_CHAIN_TRANSACTION_TYPES_BASE.TRANSFER_ANY:
          case _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_6__.BIOFOREST_CHAIN_TRANSACTION_TYPES_BASE.BE_EXCHANGE_ANY:
          case _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_6__.BIOFOREST_CHAIN_TRANSACTION_TYPES_BASE.BE_EXCHANGE_SPECIAL_ASSET:
          case _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_6__.BIOFOREST_CHAIN_TRANSACTION_TYPES_BASE.BE_EXCHANGE_ASSET:
          case _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_6__.BIOFOREST_CHAIN_TRANSACTION_TYPES_BASE.GRAB_ANY:
          case _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_6__.BIOFOREST_CHAIN_TRANSACTION_TYPES_BASE.TRANSFER_ASSET:
            return _bnqkl_framework_pipes__WEBPACK_IMPORTED_MODULE_2__.AddressHiddenPipe.transform(transaction.senderId == walletAddress ? transaction.recipientId : transaction.senderId);
        }
        name = typeNameI18n;
      }
    } else {
      let {
        recipientId,
        senderId
      } = item;
      if (item.chain === _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_6__.CHAIN_NAME.Binance || item.chain === _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_6__.CHAIN_NAME.Ethereum) {
        recipientId && (recipientId = recipientId.toLowerCase());
        senderId = senderId.toLowerCase();
        walletAddress = walletAddress.toLowerCase();
      }
      const showAddress = _bnqkl_framework_pipes__WEBPACK_IMPORTED_MODULE_2__.AddressHiddenPipe.transform(senderId == walletAddress ? recipientId : senderId);
      showAddress && (name = showAddress);
    }
    return name;
  }
}
_class = HomeTokenDetailsPage;
_class.ɵfac = /*@__PURE__*/(() => {
  let ɵHomeTokenDetailsPage_BaseFactory;
  return function HomeTokenDetailsPage_Factory(t) {
    return (ɵHomeTokenDetailsPage_BaseFactory || (ɵHomeTokenDetailsPage_BaseFactory = _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵgetInheritedFactory"](_class)))(t || _class);
  };
})();
_class.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵdefineComponent"]({
  type: _class,
  selectors: [["w-home-token-details-page"]],
  viewQuery: function HomeTokenDetailsPage_Query(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵviewQuery"](_c0, 5);
    }
    if (rf & 2) {
      let _t;
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵloadQuery"]()) && (ctx.transactionListContentRef = _t.first);
    }
  },
  standalone: true,
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵInheritDefinitionFeature"], _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵStandaloneFeature"]],
  decls: 17,
  vars: 8,
  consts: () => {
    let i18n_1;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_TRANSFER$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_HOME_TOKEN_DETAILS_HOME_TOKEN_DETAILS_COMPONENT_TS_2 = goog.getMsg(" Transfer ");
      i18n_1 = MSG_EXTERNAL_TRANSFER$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_HOME_TOKEN_DETAILS_HOME_TOKEN_DETAILS_COMPONENT_TS_2;
    } else {
      i18n_1 = " Transfer ";
    }
    let i18n_3;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_RECEIVE$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_HOME_TOKEN_DETAILS_HOME_TOKEN_DETAILS_COMPONENT_TS_4 = goog.getMsg(" Receive ");
      i18n_3 = MSG_EXTERNAL_RECEIVE$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_HOME_TOKEN_DETAILS_HOME_TOKEN_DETAILS_COMPONENT_TS_4;
    } else {
      i18n_3 = " Receive ";
    }
    let i18n_5;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_ALL$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_HOME_TOKEN_DETAILS_HOME_TOKEN_DETAILS_COMPONENT_TS__6 = goog.getMsg(" All ");
      i18n_5 = MSG_EXTERNAL_ALL$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_HOME_TOKEN_DETAILS_HOME_TOKEN_DETAILS_COMPONENT_TS__6;
    } else {
      i18n_5 = " All ";
    }
    let i18n_7;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_IN$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_HOME_TOKEN_DETAILS_HOME_TOKEN_DETAILS_COMPONENT_TS__8 = goog.getMsg(" In ");
      i18n_7 = MSG_EXTERNAL_IN$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_HOME_TOKEN_DETAILS_HOME_TOKEN_DETAILS_COMPONENT_TS__8;
    } else {
      i18n_7 = " In ";
    }
    let i18n_9;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_OUT$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_HOME_TOKEN_DETAILS_HOME_TOKEN_DETAILS_COMPONENT_TS__10 = goog.getMsg(" Out ");
      i18n_9 = MSG_EXTERNAL_OUT$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_HOME_TOKEN_DETAILS_HOME_TOKEN_DETAILS_COMPONENT_TS__10;
    } else {
      i18n_9 = " Out ";
    }
    let i18n_11;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_FAILED$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_HOME_TOKEN_DETAILS_HOME_TOKEN_DETAILS_COMPONENT_TS__12 = goog.getMsg(" Failed ");
      i18n_11 = MSG_EXTERNAL_FAILED$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_HOME_TOKEN_DETAILS_HOME_TOKEN_DETAILS_COMPONENT_TS__12;
    } else {
      i18n_11 = " Failed ";
    }
    let i18n_15;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_LOADING$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_HOME_TOKEN_DETAILS_HOME_TOKEN_DETAILS_COMPONENT_TS___16 = goog.getMsg("Loading");
      i18n_15 = MSG_EXTERNAL_LOADING$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_HOME_TOKEN_DETAILS_HOME_TOKEN_DETAILS_COMPONENT_TS___16;
    } else {
      i18n_15 = "Loading";
    }
    let i18n_17;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_LOADING$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_HOME_TOKEN_DETAILS_HOME_TOKEN_DETAILS_COMPONENT_TS__18 = goog.getMsg("Loading");
      i18n_17 = MSG_EXTERNAL_LOADING$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_HOME_TOKEN_DETAILS_HOME_TOKEN_DETAILS_COMPONENT_TS__18;
    } else {
      i18n_17 = "Loading";
    }
    let i18n_20;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_PENDING$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_HOME_TOKEN_DETAILS_HOME_TOKEN_DETAILS_COMPONENT_TS_____21 = goog.getMsg(" Pending ");
      i18n_20 = MSG_EXTERNAL_PENDING$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_HOME_TOKEN_DETAILS_HOME_TOKEN_DETAILS_COMPONENT_TS_____21;
    } else {
      i18n_20 = " Pending ";
    }
    let i18n_22;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_TIME_OUT$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_HOME_TOKEN_DETAILS_HOME_TOKEN_DETAILS_COMPONENT_TS_____23 = goog.getMsg(" Time out ");
      i18n_22 = MSG_EXTERNAL_TIME_OUT$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_HOME_TOKEN_DETAILS_HOME_TOKEN_DETAILS_COMPONENT_TS_____23;
    } else {
      i18n_22 = " Time out ";
    }
    let i18n_24;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_FAIL$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_HOME_TOKEN_DETAILS_HOME_TOKEN_DETAILS_COMPONENT_TS_____25 = goog.getMsg(" Fail ");
      i18n_24 = MSG_EXTERNAL_FAIL$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_HOME_TOKEN_DETAILS_HOME_TOKEN_DETAILS_COMPONENT_TS_____25;
    } else {
      i18n_24 = " Fail ";
    }
    let i18n_26;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_NO_DATA$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_HOME_TOKEN_DETAILS_HOME_TOKEN_DETAILS_COMPONENT_TS__27 = goog.getMsg("No Data");
      i18n_26 = MSG_EXTERNAL_NO_DATA$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_HOME_TOKEN_DETAILS_HOME_TOKEN_DETAILS_COMPONENT_TS__27;
    } else {
      i18n_26 = "No Data";
    }
    return [[3, "headerTitle", "headerBackground", "contentBackground", "footerBackground", "footerTranslucent"], [1, "flex", "h-full", "flex-col"], ["class", "shrink-0 overflow-hidden bg-white", 4, "ngIf"], [1, "h-full", "overflow-hidden"], ["class", "h-full overflow-y-scroll px-5 pt-3 font-mono", "wPullToRefresh", "", "wInfiniteScroll", "", 3, "hasMore", "pulled$", "infinited$", 4, "ngIf", "ngIfElse"], ["initLoadingView", ""], ["footer", ""], [1, "mt-5", "flex", "justify-center", "text-center", "text-white"], ["bnRippleButton", "", 1, "from-blue-gradient-start", "to-blue-gradient-end", "h-10.5", "w-34", "mr-7", "rounded-full", "bg-gradient-to-b", 3, "click"], i18n_1, ["bnRippleButton", "", 1, "from-red-gradient-start", "to-red-gradient-end", "h-10.5", "w-34", "rounded-full", "bg-gradient-to-b", 3, "click"], i18n_3, ["transationListView", ""], ["emptyListView", ""], [1, "shrink-0", "overflow-hidden", "bg-white"], [1, "text-gray", "relative", "mx-5", "flex", "items-center", "justify-center", "text-center"], ["bnRippleButton", "", 1, "h-11", "w-1/4", 3, "click"], i18n_5, i18n_7, i18n_9, i18n_11, [1, "_subscript", 3, "ngStyle"], ["wPullToRefresh", "", "wInfiniteScroll", "", 1, "h-full", "overflow-y-scroll", "px-5", "pt-3", "font-mono", 3, "hasMore", "pulled$", "infinited$"], ["transactionListContent", ""], [1, "text-subtext"], [3, "ngTemplateOutlet", "ngTemplateOutletContext", 4, "ngIf", "ngIfElse"], [4, "ngIf"], [3, "ngTemplateOutlet", "ngTemplateOutletContext"], [1, "text-sm"], i18n_15, [1, "flex", "h-full", "w-full", "flex-col", "items-center", "justify-center"], [1, "icon-6", 3, "showLoading"], i18n_17, [4, "ngFor", "ngForOf"], ["class", "rounded-3 mb-3 flex h-16 w-full items-center justify-start bg-white p-3", "bnRippleButton", "", 3, "click", 4, "ngIf"], ["bnRippleButton", "", 1, "rounded-3", "mb-3", "flex", "h-16", "w-full", "items-center", "justify-start", "bg-white", "p-3", 3, "click"], [4, "ngIf", "ngIfElse"], ["outIcon", ""], [1, "w-full", "overflow-hidden", "text-left"], [1, "text-title", "flex", "h-5", "items-center", "justify-start", "text-base", "font-medium"], [1, "overflow-hidden", "text-ellipsis", "whitespace-nowrap", "font-bold"], [3, "ngSwitch"], [4, "ngSwitchCase"], [4, "ngSwitchDefault"], [1, "text-subtext", "flex", "h-5", "items-center", "justify-between", "font-normal"], ["class", "overflow-hidden text-ellipsis whitespace-nowrap text-xs"], [1, "text-xss", "shrink-0"], ["name", "receive-record", 1, "mr-3", "shrink-0", "text-4xl"], ["name", "pay-record", 1, "mr-3", "shrink-0", "text-4xl", 3, "ngStyle"], [1, "text-xss", "rounded-3", "text-primary", "bg-primary/10", "text-primary", "ml-2", "shrink-0", "px-2", "font-normal"], i18n_20, [1, "text-xss", "rounded-3", "bg-subtext/10", "text-subtext", "ml-2", "shrink-0", "px-2", "font-normal"], i18n_22, [1, "text-xss", "rounded-3", "bg-error/10", "text-error", "ml-2", "shrink-0", "px-2", "font-normal"], i18n_24, [1, "overflow-hidden", "text-ellipsis", "whitespace-nowrap", "text-xs"], ["name", "no-data", 1, "pb-2", "text-4xl"], [1, "text-line", "text-sm"], i18n_26];
  },
  template: function HomeTokenDetailsPage_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementStart"](0, "common-page", 0)(1, "div", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtemplate"](2, HomeTokenDetailsPage_div_2_Template, 11, 3, "div", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementStart"](3, "div", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtemplate"](4, HomeTokenDetailsPage_div_4_Template, 5, 4, "div", 4)(5, HomeTokenDetailsPage_ng_template_5_Template, 4, 1, "ng-template", null, 5, _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtemplateRefExtractor"]);
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementStart"](7, "div", 6)(8, "div", 7)(9, "button", 8);
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵlistener"]("click", function HomeTokenDetailsPage_Template_button_click_9_listener() {
        return ctx.goToTransfer();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵi18n"](10, 9);
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementStart"](11, "button", 10);
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵlistener"]("click", function HomeTokenDetailsPage_Template_button_click_11_listener() {
        return ctx.goToReceive();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵi18n"](12, 11);
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementEnd"]()()()();
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtemplate"](13, HomeTokenDetailsPage_ng_template_13_Template, 1, 1, "ng-template", null, 12, _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtemplateRefExtractor"])(15, HomeTokenDetailsPage_ng_template_15_Template, 4, 0, "ng-template", null, 13, _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtemplateRefExtractor"]);
    }
    if (rf & 2) {
      const _r3 = _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵreference"](6);
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵproperty"]("headerTitle", ctx.title)("headerBackground", "white")("contentBackground", "env")("footerBackground", "white")("footerTranslucent", false);
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵproperty"]("ngIf", ctx.isBioforestChain);
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵproperty"]("ngIf", ctx.currentConfig.init)("ngIfElse", _r3);
    }
  },
  dependencies: [_modules_page_module__WEBPACK_IMPORTED_MODULE_7__.CommonPageModule, _libs_bnf_components_ripple_button_ripple_button_directive__WEBPACK_IMPORTED_MODULE_9__.RippleButtonDirective, _libs_bnf_components_pull_to_refresh_pull_to_refresh_directive__WEBPACK_IMPORTED_MODULE_10__.PullToRefreshDirective, _libs_bnf_components_pull_to_refresh_pull_to_refresh_spinner_component__WEBPACK_IMPORTED_MODULE_11__.PullToRefreshSpinnerComponent, _libs_bnf_components_infinite_scroll_infinite_scroll_spinner_component__WEBPACK_IMPORTED_MODULE_12__.InfiniteScrollSpinnerComponent, _libs_bnf_components_infinite_scroll_infinite_scroll_directive__WEBPACK_IMPORTED_MODULE_13__.InfiniteScrollDirective, _angular_common__WEBPACK_IMPORTED_MODULE_20__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_20__.NgIf, _angular_common__WEBPACK_IMPORTED_MODULE_20__.NgTemplateOutlet, _angular_common__WEBPACK_IMPORTED_MODULE_20__.NgStyle, _angular_common__WEBPACK_IMPORTED_MODULE_20__.NgSwitch, _angular_common__WEBPACK_IMPORTED_MODULE_20__.NgSwitchCase, _angular_common__WEBPACK_IMPORTED_MODULE_20__.NgSwitchDefault, _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_14__.CommonPageComponent, _components_icon_icon_component__WEBPACK_IMPORTED_MODULE_15__.IconComponent, _libs_bnf_components_loading_wrapper_loading_wrapper_component__WEBPACK_IMPORTED_MODULE_16__.LoadingWrapperComponent, _libs_bnf_pipes_day_format_day_format_pipe__WEBPACK_IMPORTED_MODULE_17__.DayFormatPipe, _pipes_color_color_pipe__WEBPACK_IMPORTED_MODULE_18__.ColorPipe],
  styles: ["[_nghost-%COMP%]   ._subscript[_ngcontent-%COMP%] {\n  position: absolute;\n  --tw-bg-opacity: 1;\n  background-color: rgb(2 17 35 / var(--tw-bg-opacity));\n  height: 2px;\n  width: 2.5rem;\n  border-radius: 1px;\n  bottom: 0;\n  --index: 0;\n  left: calc(var(--index) * 25% + 12.5% - 1.25rem);\n  transition-duration: 350ms;\n  transition-timing-function: ease-in;\n}\n[_nghost-%COMP%]   ._bioforest_asset_logo[_ngcontent-%COMP%] {\n  width: 1em;\n  height: 1em;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL2FwcHMvd2FsbGV0L3NyYy9wYWdlcy9tbmVtb25pYy9wYWdlcy9ob21lLXRva2VuLWRldGFpbHMvaG9tZS10b2tlbi1kZXRhaWxzLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUVJO0VBQUEsa0JBQUE7RUFBQSxrQkFBQTtFQUFBLHFEQUFBO0VBQ0EsV0FBQTtFQUNBLGFBQUE7RUFDQSxrQkFBQTtFQUNBLFNBQUE7RUFDQSxVQUFBO0VBQ0EsZ0RBQUE7RUFDQSwwQkFBQTtFQUNBO0FBUkE7QUFVRjtFQUNFLFVBQUE7RUFDQSxXQUFBO0FBQUoiLCJzb3VyY2VzQ29udGVudCI6WyI6aG9zdCB7XHJcbiAgLl9zdWJzY3JpcHQge1xyXG4gICAgQGFwcGx5IGJnLXRpdGxlIGFic29sdXRlO1xyXG4gICAgaGVpZ2h0OiAycHg7XHJcbiAgICB3aWR0aDogMi41cmVtO1xyXG4gICAgYm9yZGVyLXJhZGl1czogMXB4O1xyXG4gICAgYm90dG9tOiAwO1xyXG4gICAgLS1pbmRleDogMDtcclxuICAgIGxlZnQ6IGNhbGModmFyKC0taW5kZXgpICogMjUlICsgMTIuNSUgLSAxLjI1cmVtKTtcclxuICAgIHRyYW5zaXRpb24tZHVyYXRpb246IDM1MG1zO1xyXG4gICAgdHJhbnNpdGlvbi10aW1pbmctZnVuY3Rpb246IGVhc2UtaW47XHJcbiAgfVxyXG4gIC5fYmlvZm9yZXN0X2Fzc2V0X2xvZ28ge1xyXG4gICAgd2lkdGg6IDFlbTtcclxuICAgIGhlaWdodDogMWVtO1xyXG4gIH1cclxufVxyXG4iXSwic291cmNlUm9vdCI6IiJ9 */"],
  changeDetection: 0
});
(0,tslib__WEBPACK_IMPORTED_MODULE_21__.__decorate)([HomeTokenDetailsPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_21__.__metadata)("design:type", Object), (0,tslib__WEBPACK_IMPORTED_MODULE_21__.__metadata)("design:paramtypes", [])], HomeTokenDetailsPage.prototype, "title", null);
(0,tslib__WEBPACK_IMPORTED_MODULE_21__.__decorate)([HomeTokenDetailsPage.QueryParams(), (0,tslib__WEBPACK_IMPORTED_MODULE_21__.__metadata)("design:type", Object)], HomeTokenDetailsPage.prototype, "_data", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_21__.__decorate)([HomeTokenDetailsPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_21__.__metadata)("design:type", Object)], HomeTokenDetailsPage.prototype, "assetInfo", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_21__.__decorate)([HomeTokenDetailsPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_21__.__metadata)("design:type", Object)], HomeTokenDetailsPage.prototype, "homeTransferPageReturnController", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_21__.__decorate)([HomeTokenDetailsPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_21__.__metadata)("design:type", Object)], HomeTokenDetailsPage.prototype, "isBioforestChain", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_21__.__decorate)([HomeTokenDetailsPage.OnInit(), (0,tslib__WEBPACK_IMPORTED_MODULE_21__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_21__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_21__.__metadata)("design:returntype", void 0)], HomeTokenDetailsPage.prototype, "pageInit", null);
(0,tslib__WEBPACK_IMPORTED_MODULE_21__.__decorate)([HomeTokenDetailsPage.OnReady(), (0,tslib__WEBPACK_IMPORTED_MODULE_21__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_21__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_21__.__metadata)("design:returntype", Promise)], HomeTokenDetailsPage.prototype, "getWalletInfoAndMnemonic", null);
(0,tslib__WEBPACK_IMPORTED_MODULE_21__.__decorate)([HomeTokenDetailsPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_21__.__metadata)("design:type", Object)], HomeTokenDetailsPage.prototype, "selectType", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_21__.__decorate)([HomeTokenDetailsPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_21__.__metadata)("design:type", Object)], HomeTokenDetailsPage.prototype, "resetTransListLoading", void 0);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (HomeTokenDetailsPage);

/***/ })

}]);
//# sourceMappingURL=apps_wallet_src_pages_mnemonic_pages_home-token-details_home-token-details_component_ts.js.map