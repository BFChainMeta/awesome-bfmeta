"use strict";
(self["webpackChunkwallet"] = self["webpackChunkwallet"] || []).push([["apps_wallet_src_pages_chat_chat_routes_ts"],{

/***/ 42038:
/*!***************************************************!*\
  !*** ./apps/wallet/src/pages/chat/chat.routes.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   routes: () => (/* binding */ routes)
/* harmony export */ });
const routes = [{
  path: '',
  loadComponent: () => __webpack_require__.e(/*! import() */ "apps_wallet_src_pages_chat_chat_component_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./chat.component */ 92805))
}
// {
//   path: 'chat-detail',
//   loadComponent: () => import('./page/chat-detail/chat-detail.component'),
// },
];

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (routes);

/***/ })

}]);
//# sourceMappingURL=apps_wallet_src_pages_chat_chat_routes_ts.js.map