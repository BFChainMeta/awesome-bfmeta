"use strict";
(self["webpackChunkwallet"] = self["webpackChunkwallet"] || []).push([["apps_wallet_src_pages_home_pages_home-create-or-import-wallet_home-create-or-import-wallet_co-c45fd7"],{

/***/ 95098:
/*!*****************************************************************************************************************!*\
  !*** ./apps/wallet/src/pages/home/pages/home-create-or-import-wallet/home-create-or-import-wallet.component.ts ***!
  \*****************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   HomeCreateOrImportWalletPage: () => (/* binding */ HomeCreateOrImportWalletPage),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 52542);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! tslib */ 90505);
/* harmony import */ var _bnqkl_wallet_base_services_wallet_bip39__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @bnqkl/wallet-base/services/wallet/bip39 */ 76659);
/* harmony import */ var _modules_page_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ~modules/page.module */ 77538);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 61039);
/* harmony import */ var _libs_bnf_modules_bottom_sheet_components_bottom_sheet_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../../../../libs/bnf/modules/bottom-sheet/components/bottom-sheet.component */ 94072);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/common */ 6729);
/* harmony import */ var _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../../../../../libs/bnf/modules/page/common-page/common-page.component */ 62052);
/* harmony import */ var _components_icon_icon_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../../components/icon/icon.component */ 74703);
/* harmony import */ var _pipes_color_color_pipe__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../../pipes/color/color.pipe */ 76489);

var _class;









function HomeCreateOrImportWalletPage_ng_template_33_button_3_Template(rf, ctx) {
  if (rf & 1) {
    const _r6 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](0, "button", 27);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("click", function HomeCreateOrImportWalletPage_ng_template_33_button_3_Template_button_click_0_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵrestoreView"](_r6);
      const item_r3 = restoredCtx.$implicit;
      const ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵresetView"](ctx_r5.getChange(item_r3));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](1, "div", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const item_r3 = ctx.$implicit;
    const last_r4 = ctx.last;
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("ngClass", last_r4 ? "border-0" : "border-b-[0.5px]");
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtextInterpolate1"](" ", item_r3.text, " ");
  }
}
function HomeCreateOrImportWalletPage_ng_template_33_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](0, "common-page", 23, 24)(2, "div", 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtemplate"](3, HomeCreateOrImportWalletPage_ng_template_33_button_3_Template, 3, 2, "button", 26);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("headerTitle", ctx_r0.mnemonicBottomSheetInfo.title);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("ngForOf", ctx_r0.mnemonicBottomSheetInfo.data);
  }
}
const _c16 = a0 => ({
  "--color-1": a0
});
/** 创建/导入钱包 */
class HomeCreateOrImportWalletPage extends _modules_page_module__WEBPACK_IMPORTED_MODULE_2__.CommonPageBase {
  constructor() {
    super(...arguments);
    /** 底部选择器 */
    this.mnemonicBottomSheetInfo = {
      title: '',
      data: [],
      open: false
    };
    /** 助剂词信息 */
    this.mnemonicInfo = {
      length: 12,
      language: _bnqkl_wallet_base_services_wallet_bip39__WEBPACK_IMPORTED_MODULE_1__.MNEMONIC_LANGUAGE.english,
      text: "English"
    };
  }
  /** 创建身份钱包 */
  createMainWallet() {
    var _this = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      /// 创建成功页面
      _this.nav.routeTo('/mnemonic/create-wallet', {
        mnemonicLength: _this.mnemonicInfo.length,
        mnemonicLanguage: _this.mnemonicInfo.language,
        addWallet: true,
        showBackupBtn: true,
        backUrl: 'home-create-or-import-wallet'
      });
    })();
  }
  /** 选择语言 */
  selectLanguage() {
    this.mnemonicBottomSheetInfo.title = "Select mnemonic language";
    this.mnemonicBottomSheetInfo.data = [{
      type: 'language',
      text: "English",
      value: _bnqkl_wallet_base_services_wallet_bip39__WEBPACK_IMPORTED_MODULE_1__.MNEMONIC_LANGUAGE.english
    }, {
      type: 'language',
      text: "\u4E2D\u6587\uFF08\u7B80\u4F53\uFF09",
      value: _bnqkl_wallet_base_services_wallet_bip39__WEBPACK_IMPORTED_MODULE_1__.MNEMONIC_LANGUAGE.chineseSimplified
    }, {
      type: 'language',
      text: "\u4E2D\u6587\uFF08\u7E41\u9AD4\uFF09",
      value: _bnqkl_wallet_base_services_wallet_bip39__WEBPACK_IMPORTED_MODULE_1__.MNEMONIC_LANGUAGE.chineseTraditional
    }];
    this.mnemonicBottomSheetInfo.open = true;
  }
  /** 选择长度 */
  selectLength() {
    this.mnemonicBottomSheetInfo.title = "Select number of mnemonics";
    this.mnemonicBottomSheetInfo.data = [12, 15, 18, 21, 24, 36].map(item => {
      return {
        type: 'length',
        text: "" + item + " words",
        value: item
      };
    });
    this.mnemonicBottomSheetInfo.open = true;
  }
  /** 获取变更的语言 */
  getChange(item) {
    if (item) {
      if (item.type === 'language') {
        this.mnemonicInfo.language = item.value;
        this.mnemonicInfo.text = item.text;
      } else {
        this.mnemonicInfo.length = item.value;
      }
    }
    this.mnemonicBottomSheetInfo.open = false;
    this.cdRef.detectChanges();
  }
  /** 助剂词导入 */
  importMnemonic() {
    this.nav.routeTo('mnemonic/mnemonic-recover-wallet', {
      addWallet: true,
      backUrl: 'home-create-or-import-wallet'
    });
  }
  /** 私钥导入 */
  importPrivateKey() {
    this.nav.routeTo('home-import-private-key-wallet-before');
  }
}
_class = HomeCreateOrImportWalletPage;
_class.ɵfac = /*@__PURE__*/(() => {
  let ɵHomeCreateOrImportWalletPage_BaseFactory;
  return function HomeCreateOrImportWalletPage_Factory(t) {
    return (ɵHomeCreateOrImportWalletPage_BaseFactory || (ɵHomeCreateOrImportWalletPage_BaseFactory = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵgetInheritedFactory"](_class)))(t || _class);
  };
})();
_class.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdefineComponent"]({
  type: _class,
  selectors: [["w-home-create-or-import-wallet-page"]],
  standalone: true,
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵInheritDefinitionFeature"], _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵStandaloneFeature"]],
  decls: 34,
  vars: 29,
  consts: () => {
    let i18n_0;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_CREATE_IMPORT_WALLET$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_CREATE_OR_IMPORT_WALLET_HOME_CREATE_OR_IMPORT_WALLET_COMPONENT_TS_1 = goog.getMsg("Create/Import Wallet");
      i18n_0 = MSG_EXTERNAL_CREATE_IMPORT_WALLET$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_CREATE_OR_IMPORT_WALLET_HOME_CREATE_OR_IMPORT_WALLET_COMPONENT_TS_1;
    } else {
      i18n_0 = "Create/Import Wallet";
    }
    let i18n_2;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_NEW_CREATE_WALLET$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_CREATE_OR_IMPORT_WALLET_HOME_CREATE_OR_IMPORT_WALLET_COMPONENT_TS_3 = goog.getMsg(" Create Wallet ");
      i18n_2 = MSG_EXTERNAL_NEW_CREATE_WALLET$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_CREATE_OR_IMPORT_WALLET_HOME_CREATE_OR_IMPORT_WALLET_COMPONENT_TS_3;
    } else {
      i18n_2 = " Create Wallet ";
    }
    let i18n_4;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_MNEMONIC$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_CREATE_OR_IMPORT_WALLET_HOME_CREATE_OR_IMPORT_WALLET_COMPONENT_TS_5 = goog.getMsg("Mnemonic");
      i18n_4 = MSG_EXTERNAL_MNEMONIC$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_CREATE_OR_IMPORT_WALLET_HOME_CREATE_OR_IMPORT_WALLET_COMPONENT_TS_5;
    } else {
      i18n_4 = "Mnemonic";
    }
    let i18n_6;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_CREATE$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_CREATE_OR_IMPORT_WALLET_HOME_CREATE_OR_IMPORT_WALLET_COMPONENT_TS_7 = goog.getMsg("Create");
      i18n_6 = MSG_EXTERNAL_CREATE$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_CREATE_OR_IMPORT_WALLET_HOME_CREATE_OR_IMPORT_WALLET_COMPONENT_TS_7;
    } else {
      i18n_6 = "Create";
    }
    let i18n_8;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL___length___WORDS$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_CREATE_OR_IMPORT_WALLET_HOME_CREATE_OR_IMPORT_WALLET_COMPONENT_TS_9 = goog.getMsg("{$interpolation} words", {
        "interpolation": "\uFFFD0\uFFFD"
      }, {
        original_code: {
          "interpolation": "{{ mnemonicInfo.length }}"
        }
      });
      i18n_8 = MSG_EXTERNAL___length___WORDS$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_CREATE_OR_IMPORT_WALLET_HOME_CREATE_OR_IMPORT_WALLET_COMPONENT_TS_9;
    } else {
      i18n_8 = "" + "\uFFFD0\uFFFD" + " words";
    }
    let i18n_10;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_IMPORT_WALLET$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_CREATE_OR_IMPORT_WALLET_HOME_CREATE_OR_IMPORT_WALLET_COMPONENT_TS_11 = goog.getMsg(" Import Wallet ");
      i18n_10 = MSG_EXTERNAL_IMPORT_WALLET$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_CREATE_OR_IMPORT_WALLET_HOME_CREATE_OR_IMPORT_WALLET_COMPONENT_TS_11;
    } else {
      i18n_10 = " Import Wallet ";
    }
    let i18n_12;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_MNEMONIC_IMPORT$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_CREATE_OR_IMPORT_WALLET_HOME_CREATE_OR_IMPORT_WALLET_COMPONENT_TS_13 = goog.getMsg("Mnemonic import");
      i18n_12 = MSG_EXTERNAL_MNEMONIC_IMPORT$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_CREATE_OR_IMPORT_WALLET_HOME_CREATE_OR_IMPORT_WALLET_COMPONENT_TS_13;
    } else {
      i18n_12 = "Mnemonic import";
    }
    let i18n_14;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_PRIVATE_KEY_IMPORT$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_CREATE_OR_IMPORT_WALLET_HOME_CREATE_OR_IMPORT_WALLET_COMPONENT_TS_15 = goog.getMsg("Private key import");
      i18n_14 = MSG_EXTERNAL_PRIVATE_KEY_IMPORT$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_CREATE_OR_IMPORT_WALLET_HOME_CREATE_OR_IMPORT_WALLET_COMPONENT_TS_15;
    } else {
      i18n_14 = "Private key import";
    }
    return [["headerTitle", i18n_0, 3, "titleColor", "contentSafeArea"], [1, "text-subtext", "mb-2", "flex", "h-10", "w-full", "items-end", "justify-between", "text-xs", "font-semibold"], i18n_2, [1, "border-tiny", "border-line", "rounded-3", "p-4"], [1, "mb-2", "flex", "w-full", "items-center", "justify-between", "text-xs", "font-semibold"], [1, "flex-shrink-0", "pr-2", "text-sm"], i18n_4, ["wRippleButton", "", 1, "from-purple-gradient-start", "to-purple-gradient-end", "flex", "items-center", "justify-end", "rounded-full", "bg-gradient-to-b", "px-4", "py-1", "text-white", 3, "click"], [1, "text-sm"], i18n_6, ["wRippleButton", "", "type", "button", 1, "bg-grey", "text-subtext", "rounded-3", "flex", "h-12", "w-full", "items-center", "justify-between", "pr-4", 3, "click"], [1, "w-full", "px-3"], ["name", "right", 1, "icon-5", "ml-1.5"], ["wRippleButton", "", "type", "button", 1, "bg-grey", "text-subtext", "rounded-3", "mb-2", "mt-2", "flex", "h-12", "w-full", "items-center", "justify-between", "pr-4", 3, "click"], i18n_8, [1, "text-subtext", "mb-2", "mb-3", "mt-6", "flex", "w-full", "items-end", "justify-between", "text-xs", "font-semibold"], i18n_10, ["wRippleButton", "", "type", "button", 1, "h-15", "border-tiny", "border-line", "rounded-3", "mb-3", "flex", "w-full", "items-center", "justify-between", "pr-4", 3, "click"], [1, "w-full", "px-3", "font-bold"], i18n_12, ["wRippleButton", "", "type", "button", 1, "h-15", "border-tiny", "border-line", "rounded-3", "flex", "w-full", "items-center", "justify-between", "pr-4", 3, "click"], i18n_14, [3, "isOpen", "isOpenChange"], [3, "headerTitle"], ["page", ""], [1, "box-border", "flex", "flex-col", "pb-7"], ["wRippleButton", "", "class", "h-12 w-full px-5 text-sm", 3, "click", 4, "ngFor", "ngForOf"], ["wRippleButton", "", 1, "h-12", "w-full", "px-5", "text-sm", 3, "click"], [1, "border-line", "flex", "h-full", "w-full", "items-center", "justify-center", 3, "ngClass"]];
  },
  template: function HomeCreateOrImportWalletPage_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](0, "common-page", 0)(1, "div", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵi18n"](2, 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](3, "div", 3)(4, "div", 4)(5, "div", 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵi18n"](6, 6);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](7, "button", 7);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("click", function HomeCreateOrImportWalletPage_Template_button_click_7_listener() {
        return ctx.createMainWallet();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](8, "span", 8);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵi18n"](9, 9);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]()()();
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](10, "button", 10);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("click", function HomeCreateOrImportWalletPage_Template_button_click_10_listener() {
        return ctx.selectLanguage();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](11, "div", 11);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](12);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](13, "w-icon", 12);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipe"](14, "color");
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](15, "button", 13);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("click", function HomeCreateOrImportWalletPage_Template_button_click_15_listener() {
        return ctx.selectLength();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](16, "div", 11);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵi18n"](17, 14);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](18, "w-icon", 12);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipe"](19, "color");
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](20, "div", 15);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵi18n"](21, 16);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](22, "button", 17);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("click", function HomeCreateOrImportWalletPage_Template_button_click_22_listener() {
        return ctx.importMnemonic();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](23, "div", 18);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵi18n"](24, 19);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](25, "w-icon", 12);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipe"](26, "color");
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](27, "button", 20);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("click", function HomeCreateOrImportWalletPage_Template_button_click_27_listener() {
        return ctx.importPrivateKey();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](28, "div", 18);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵi18n"](29, 21);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](30, "w-icon", 12);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipe"](31, "color");
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](32, "common-bottom-sheet", 22);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("isOpenChange", function HomeCreateOrImportWalletPage_Template_common_bottom_sheet_isOpenChange_32_listener($event) {
        return $event || (ctx.mnemonicBottomSheetInfo.open = false);
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtemplate"](33, HomeCreateOrImportWalletPage_ng_template_33_Template, 4, 2, "ng-template");
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("titleColor", "title")("contentSafeArea", true);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](12);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtextInterpolate"](ctx.mnemonicInfo.text);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpureFunction1"](21, _c16, _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipeBind1"](14, 13, "subtext")));
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](4);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵi18nExp"](ctx.mnemonicInfo.length);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵi18nApply"](17);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpureFunction1"](23, _c16, _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipeBind1"](19, 15, "subtext")));
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](7);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpureFunction1"](25, _c16, _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipeBind1"](26, 17, "subtext")));
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](5);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpureFunction1"](27, _c16, _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipeBind1"](31, 19, "subtext")));
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("isOpen", ctx.mnemonicBottomSheetInfo.open);
    }
  },
  dependencies: [_modules_page_module__WEBPACK_IMPORTED_MODULE_2__.CommonPageModule, _libs_bnf_modules_bottom_sheet_components_bottom_sheet_component__WEBPACK_IMPORTED_MODULE_3__.BottomSheetComponent, _angular_common__WEBPACK_IMPORTED_MODULE_8__.NgClass, _angular_common__WEBPACK_IMPORTED_MODULE_8__.NgForOf, _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_4__.CommonPageComponent, _components_icon_icon_component__WEBPACK_IMPORTED_MODULE_5__.IconComponent, _pipes_color_color_pipe__WEBPACK_IMPORTED_MODULE_6__.ColorPipe],
  styles: ["/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsInNvdXJjZVJvb3QiOiIifQ== */"],
  changeDetection: 0
});
(0,tslib__WEBPACK_IMPORTED_MODULE_9__.__decorate)([HomeCreateOrImportWalletPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__metadata)("design:type", Object)], HomeCreateOrImportWalletPage.prototype, "mnemonicBottomSheetInfo", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_9__.__decorate)([HomeCreateOrImportWalletPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__metadata)("design:type", Object)], HomeCreateOrImportWalletPage.prototype, "mnemonicInfo", void 0);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (HomeCreateOrImportWalletPage);

/***/ })

}]);
//# sourceMappingURL=apps_wallet_src_pages_home_pages_home-create-or-import-wallet_home-create-or-import-wallet_co-c45fd7.js.map