"use strict";
(self["webpackChunkwallet"] = self["webpackChunkwallet"] || []).push([["default-apps_wallet_src_pages_mnemonic_pages_home-select-token_home-select-token_component_ts"],{

/***/ 33299:
/*!***********************************************************************************************!*\
  !*** ./apps/wallet/src/pages/mnemonic/pages/home-select-token/home-select-token.component.ts ***!
  \***********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   HomeSelectTokenPage: () => (/* binding */ HomeSelectTokenPage),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 52542);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! tslib */ 90505);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/core */ 61039);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! rxjs */ 41720);
/* harmony import */ var _modules_page_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ~modules/page.module */ 77538);
/* harmony import */ var _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @bnqkl/wallet-base/services/wallet/chain-base */ 27187);
/* harmony import */ var _bnqkl_wallet_base_services_wallet_chain__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @bnqkl/wallet-base/services/wallet/chain */ 27434);
/* harmony import */ var _bnqkl_wallet_base_services_wallet_wallet_data_storage__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @bnqkl/wallet-base/services/wallet/wallet-data-storage */ 63024);
/* harmony import */ var _libs_bnf_components_ripple_button_ripple_button_directive__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../../../../../libs/bnf/components/ripple-button/ripple-button.directive */ 16505);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/common */ 6729);
/* harmony import */ var _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../../../../../libs/bnf/modules/page/common-page/common-page.component */ 62052);
/* harmony import */ var _components_icon_icon_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../../components/icon/icon.component */ 74703);
/* harmony import */ var _libs_bnf_pipes_number_format_number_format_pipe__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../../../../../libs/bnf/pipes/number-format/number-format.pipe */ 89873);
/* harmony import */ var _libs_bnf_pipes_amountFixed_amount_fixed_pipe__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../../../../../../libs/bnf/pipes/amountFixed/amount-fixed.pipe */ 44070);
/* harmony import */ var _pipes_chainIcon_chain_icon_pipe__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../../../pipes/chainIcon/chain-icon.pipe */ 43040);

var _class;















function HomeSelectTokenPage_ng_container_2_ng_container_3_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](1, "img", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const item_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"]().$implicit;
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵclassProp"]("rounded-full", ctx_r2.isBioforestChain);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("src", item_r1.logoUrl, _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵsanitizeUrl"]);
  }
}
const _c0 = a0 => ({
  chain: a0,
  prefix: "icon"
});
function HomeSelectTokenPage_ng_container_2_ng_template_4_ng_container_0_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](1, "w-icon", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](2, "chainIcon");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const item_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"](2).$implicit;
    const ctx_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("name", _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind2"](2, 1, item_r1.tokeyName, _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpureFunction1"](4, _c0, ctx_r6.chain)));
  }
}
function HomeSelectTokenPage_ng_container_2_ng_template_4_ng_template_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](0, "w-icon", 12);
  }
}
function HomeSelectTokenPage_ng_container_2_ng_template_4_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](0, HomeSelectTokenPage_ng_container_2_ng_template_4_ng_container_0_Template, 3, 6, "ng-container", 5)(1, HomeSelectTokenPage_ng_container_2_ng_template_4_ng_template_1_Template, 1, 0, "ng-template", null, 10, _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplateRefExtractor"]);
  }
  if (rf & 2) {
    const _r8 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵreference"](2);
    const item_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"]().$implicit;
    const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngIf", ctx_r3.isLocalLogo(item_r1.tokeyName, ctx_r3.chain))("ngIfElse", _r8);
  }
}
function HomeSelectTokenPage_ng_container_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r12 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](1, "button", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵlistener"]("click", function HomeSelectTokenPage_ng_container_2_Template_button_click_1_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵrestoreView"](_r12);
      const item_r1 = restoredCtx.$implicit;
      const ctx_r11 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵresetView"](ctx_r11.confirmSelect(item_r1));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](2, "div", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](3, HomeSelectTokenPage_ng_container_2_ng_container_3_Template, 2, 3, "ng-container", 5)(4, HomeSelectTokenPage_ng_container_2_ng_template_4_Template, 3, 2, "ng-template", null, 6, _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplateRefExtractor"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](6, "div", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](7);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](8, "div", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](9);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](10, "numberFormat");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](11, "amountFixed");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const item_r1 = ctx.$implicit;
    const _r4 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵreference"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngIf", item_r1.logoUrl)("ngIfElse", _r4);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate1"](" ", item_r1.tokeyName, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind1"](10, 4, _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind2"](11, 6, item_r1.amount ? item_r1.amount : "------", item_r1.decimals)), " ");
  }
}
/** 选择弹窗 */
class HomeSelectTokenPage extends _modules_page_module__WEBPACK_IMPORTED_MODULE_1__.CommonPageBase {
  constructor() {
    super(...arguments);
    /** 页面显示内容 */
    this.tokeyArr = [];
    /** 链 */
    this.chain = '';
    /** 输入的地址 */
    this.addressKey = '';
    /** 资产的类型 */
    this.tokenType = '';
    /** 资产的主权益 */
    this.chainSymbol = '';
    /** 钱包存储服务 */
    this.walletDataStorageV2Service = (0,_angular_core__WEBPACK_IMPORTED_MODULE_11__.inject)(_bnqkl_wallet_base_services_wallet_wallet_data_storage__WEBPACK_IMPORTED_MODULE_4__.WalletDataStorageV2Service);
    /** 链服务 */
    this.chainV2Service = (0,_angular_core__WEBPACK_IMPORTED_MODULE_11__.inject)(_bnqkl_wallet_base_services_wallet_chain__WEBPACK_IMPORTED_MODULE_3__.ChainV2Service);
    /** 页面返回值的类型 */
    this.returnValue$ = new _modules_page_module__WEBPACK_IMPORTED_MODULE_1__.PageReturnValue();
  }
  /**  是否是生物链林-链 */
  get isBioforestChain() {
    return this.chainV2Service.isBioforestChainByChainName(this.chain);
  }
  /** 获取地址资产信息 */
  getTokenType() {
    var _this = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const addressInfo = yield _this.walletDataStorageV2Service.getChainAddressInfo(_this.addressKey);
      _this.tokeyArr = addressInfo.assets.map(asset => {
        return {
          tokeyName: asset.assetType,
          amount: asset.amount,
          decimals: asset.decimals,
          activeFlag: asset.assetType === _this.tokenType,
          logoUrl: asset.logoUrl
        };
      });
      /// 订阅余额更新
      _this.chainV2Service.getChainBalanceSubject(_this.chain).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_12__.map)(data => {
        const assets = data[addressInfo.address] || {};
        _this.tokeyArr.forEach(item => {
          item.amount = assets[item.tokeyName];
        });
        return _this.tokeyArr;
      }));
    })();
  }
  /** 返回数据并退出路由 */
  doReturn() {
    throw new Error('Method not implemented.');
  }
  /** 选择好资产 */
  confirmSelect(event) {
    this.tokeyArr.forEach(item => {
      if (item.tokeyName === event.tokeyName) {
        item.activeFlag = true;
      } else {
        item.activeFlag = false;
      }
    });
    this.returnValue$.next({
      amount: event.amount,
      assetType: event.tokeyName,
      decimals: event.decimals
    });
    this.nav.back();
  }
  /** 本地是否存在图标 */
  isLocalLogo(assetType, chain) {
    return (0,_bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_2__.CHECK_LOCAL_ASSET_LOGO)(assetType, chain);
  }
}
_class = HomeSelectTokenPage;
_class.ɵfac = /*@__PURE__*/(() => {
  let ɵHomeSelectTokenPage_BaseFactory;
  return function HomeSelectTokenPage_Factory(t) {
    return (ɵHomeSelectTokenPage_BaseFactory || (ɵHomeSelectTokenPage_BaseFactory = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵgetInheritedFactory"](_class)))(t || _class);
  };
})();
_class.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdefineComponent"]({
  type: _class,
  selectors: [["w-bfm-home-select-token-page"]],
  outputs: {
    returnValue$: "returnValue$"
  },
  standalone: true,
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵInheritDefinitionFeature"], _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵStandaloneFeature"]],
  decls: 3,
  vars: 4,
  consts: [[3, "contentSafeArea", "contentBackground", "contentClass"], [1, "bg-white", "pt-3"], [4, "ngFor", "ngForOf"], ["bnRippleButton", "", 1, "h-15", "mb-3", "flex", "w-full", "items-center", "justify-between", "bg-white", "px-5", 3, "click"], [1, "flex", "items-center"], [4, "ngIf", "ngIfElse"], ["wIconViewByToken", ""], [1, "font-semibold"], [1, "font-num", "font-semibold"], [1, "_bioforest_asset_logo", "mr-1.5", "rounded-full", "text-3xl", 3, "src"], ["wIconViewBySymbol", ""], [1, "mr-1.5", "text-3xl", 3, "name"], ["name", "icon-default", 1, "mr-1.5", "text-3xl"]],
  template: function HomeSelectTokenPage_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "common-page", 0)(1, "div", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](2, HomeSelectTokenPage_ng_container_2_Template, 12, 9, "ng-container", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()();
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("contentSafeArea", true)("contentBackground", "env")("contentClass", "px-0");
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngForOf", ctx.tokeyArr);
    }
  },
  dependencies: [_modules_page_module__WEBPACK_IMPORTED_MODULE_1__.CommonPageModule, _libs_bnf_components_ripple_button_ripple_button_directive__WEBPACK_IMPORTED_MODULE_5__.RippleButtonDirective, _angular_common__WEBPACK_IMPORTED_MODULE_13__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_13__.NgIf, _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_6__.CommonPageComponent, _components_icon_icon_component__WEBPACK_IMPORTED_MODULE_7__.IconComponent, _libs_bnf_pipes_number_format_number_format_pipe__WEBPACK_IMPORTED_MODULE_8__.NumberFormatPipe, _libs_bnf_pipes_amountFixed_amount_fixed_pipe__WEBPACK_IMPORTED_MODULE_9__.AmountFixedPipe, _pipes_chainIcon_chain_icon_pipe__WEBPACK_IMPORTED_MODULE_10__.ChainIconPipe],
  styles: ["[_nghost-%COMP%]   ._bioforest_asset_logo[_ngcontent-%COMP%] {\n  width: 1em;\n  height: 1em;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL2FwcHMvd2FsbGV0L3NyYy9wYWdlcy9tbmVtb25pYy9wYWdlcy9ob21lLXNlbGVjdC10b2tlbi9ob21lLXNlbGVjdC10b2tlbi5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFDRTtFQUNFLFVBQUE7RUFDQSxXQUFBO0FBQUoiLCJzb3VyY2VzQ29udGVudCI6WyI6aG9zdCB7XHJcbiAgLl9iaW9mb3Jlc3RfYXNzZXRfbG9nbyB7XHJcbiAgICB3aWR0aDogMWVtO1xyXG4gICAgaGVpZ2h0OiAxZW07XHJcbiAgfVxyXG59XHJcbiJdLCJzb3VyY2VSb290IjoiIn0= */"],
  changeDetection: 0
});
(0,tslib__WEBPACK_IMPORTED_MODULE_14__.__decorate)([HomeSelectTokenPage.States(), (0,tslib__WEBPACK_IMPORTED_MODULE_14__.__metadata)("design:type", Array)], HomeSelectTokenPage.prototype, "tokeyArr", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_14__.__decorate)([HomeSelectTokenPage.State(), HomeSelectTokenPage.QueryParam('chain'), (0,tslib__WEBPACK_IMPORTED_MODULE_14__.__metadata)("design:type", Object)], HomeSelectTokenPage.prototype, "chain", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_14__.__decorate)([HomeSelectTokenPage.State(), HomeSelectTokenPage.QueryParam('addressKey'), (0,tslib__WEBPACK_IMPORTED_MODULE_14__.__metadata)("design:type", Object)], HomeSelectTokenPage.prototype, "addressKey", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_14__.__decorate)([HomeSelectTokenPage.State(), HomeSelectTokenPage.QueryParam('activeAssetType'), (0,tslib__WEBPACK_IMPORTED_MODULE_14__.__metadata)("design:type", Object)], HomeSelectTokenPage.prototype, "tokenType", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_14__.__decorate)([HomeSelectTokenPage.State(), HomeSelectTokenPage.QueryParam('chainSymbol'), (0,tslib__WEBPACK_IMPORTED_MODULE_14__.__metadata)("design:type", Object)], HomeSelectTokenPage.prototype, "chainSymbol", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_14__.__decorate)([HomeSelectTokenPage.OnInit(), (0,tslib__WEBPACK_IMPORTED_MODULE_14__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_14__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_14__.__metadata)("design:returntype", Promise)], HomeSelectTokenPage.prototype, "getTokenType", null);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (HomeSelectTokenPage);

/***/ })

}]);
//# sourceMappingURL=default-apps_wallet_src_pages_mnemonic_pages_home-select-token_home-select-token_component_ts.js.map