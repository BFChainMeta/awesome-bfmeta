"use strict";
(self["webpackChunkwallet"] = self["webpackChunkwallet"] || []).push([["apps_wallet_src_pages_authorize_pages_address_address_component_ts"],{

/***/ 45604:
/*!****************************************************************************!*\
  !*** ./apps/wallet/src/pages/authorize/pages/address/address.component.ts ***!
  \****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   WalletAuthorizeAddressPage: () => (/* binding */ WalletAuthorizeAddressPage),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 52542);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! tslib */ 90505);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @angular/core */ 61039);
/* harmony import */ var _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @bnqkl/wallet-base/services/wallet/chain-base */ 27187);
/* harmony import */ var _bnqkl_framework_plugins__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @bnqkl/framework/plugins */ 43990);
/* harmony import */ var _modules_page_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ~modules/page.module */ 77538);
/* harmony import */ var _services_permission_permission_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ~services/permission/permission.service */ 26502);
/* harmony import */ var _bnqkl_wallet_base_services_plaoc__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @bnqkl/wallet-base/services/plaoc */ 63878);
/* harmony import */ var _bnqkl_wallet_base_services_wallet_wallet__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @bnqkl/wallet-base/services/wallet/wallet */ 21789);
/* harmony import */ var _bnqkl_wallet_base_services_wallet_chain__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @bnqkl/wallet-base/services/wallet/chain */ 27434);
/* harmony import */ var _bnqkl_framework_helpers__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @bnqkl/framework/helpers */ 12169);
/* harmony import */ var _bnqkl_util_web_extends_promise__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @bnqkl/util-web/extends-promise */ 87778);
/* harmony import */ var _bnqkl_framework_animations__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @bnqkl/framework/animations */ 43127);
/* harmony import */ var _libs_bnf_modules_bottom_sheet_components_bottom_sheet_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../../../../../../libs/bnf/modules/bottom-sheet/components/bottom-sheet.component */ 94072);
/* harmony import */ var _libs_bnf_components_ripple_button_ripple_button_directive__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../../../../../../libs/bnf/components/ripple-button/ripple-button.directive */ 16505);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @angular/common */ 6729);
/* harmony import */ var _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../../../../../../../libs/bnf/modules/page/common-page/common-page.component */ 62052);
/* harmony import */ var _components_icon_icon_component__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../../../../components/icon/icon.component */ 74703);
/* harmony import */ var _pipes_color_color_pipe__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ../../../../pipes/color/color.pipe */ 76489);

var _class;



















function WalletAuthorizeAddressPage_img_14_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelement"](0, "img", 32);
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵproperty"]("src", ctx_r0.mainWalletHeadSculpture, _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵsanitizeUrl"]);
  }
}
function WalletAuthorizeAddressPage_img_15_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelement"](0, "img", 33);
  }
}
function WalletAuthorizeAddressPage_w_icon_16_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelement"](0, "w-icon", 34);
  }
  if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵproperty"]("name", ctx_r2.chainIcon);
  }
}
function WalletAuthorizeAddressPage_div_19_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](0, "div", 35);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelement"](1, "w-icon", 36);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
  }
}
const _forTrack16 = ($index, $item) => $item.mainWalletId;
const _c17 = a0 => ({
  "--color-1": a0
});
function WalletAuthorizeAddressPage_ng_template_40_For_2_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelement"](0, "w-icon", 43);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipe"](1, "color");
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵproperty"]("ngStyle", _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpureFunction1"](3, _c17, _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipeBind1"](1, 1, "subtext")));
  }
}
function WalletAuthorizeAddressPage_ng_template_40_For_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r14 = _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](0, "button", 38);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵlistener"]("click", function WalletAuthorizeAddressPage_ng_template_40_For_2_Template_button_click_0_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵrestoreView"](_r14);
      const wallet_r7 = restoredCtx.$implicit;
      const ctx_r13 = _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵresetView"](ctx_r13.selectWallet(wallet_r7));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](1, "div", 39)(2, "div", 40);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtemplate"](3, WalletAuthorizeAddressPage_ng_template_40_For_2_Conditional_3_Template, 2, 5, "w-icon", 41);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](4, "div", 39);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelement"](5, "img", 32);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](6, "span", 42);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtext"](7);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]()()()();
  }
  if (rf & 2) {
    const wallet_r7 = ctx.$implicit;
    const ctx_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵconditional"](3, wallet_r7.mainWalletId === ctx_r6.mainWalletId ? 3 : -1);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵproperty"]("src", wallet_r7.headSculpture, _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵsanitizeUrl"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtextInterpolate"](wallet_r7.name);
  }
}
function WalletAuthorizeAddressPage_ng_template_40_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](0, "common-page", 37);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵrepeaterCreate"](1, WalletAuthorizeAddressPage_ng_template_40_For_2_Template, 8, 3, "button", 44, _forTrack16);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵproperty"]("contentBackground", "white")("contentSafeArea", true)("contentClass", "!px-0");
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵrepeater"](ctx_r4.allMainWalletList);
  }
}
function WalletAuthorizeAddressPage_ng_template_42_button_1_w_icon_3_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelement"](0, "w-icon", 43);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipe"](1, "color");
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵproperty"]("ngStyle", _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpureFunction1"](3, _c17, _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipeBind1"](1, 1, "subtext")));
  }
}
function WalletAuthorizeAddressPage_ng_template_42_button_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r19 = _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](0, "button", 38);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵlistener"]("click", function WalletAuthorizeAddressPage_ng_template_42_button_1_Template_button_click_0_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵrestoreView"](_r19);
      const item_r16 = restoredCtx.$implicit;
      const ctx_r18 = _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵresetView"](ctx_r18.selectChain(item_r16));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](1, "div", 39)(2, "div", 40);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtemplate"](3, WalletAuthorizeAddressPage_ng_template_42_button_1_w_icon_3_Template, 2, 5, "w-icon", 47);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](4, "div", 39);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelement"](5, "w-icon", 48);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](6, "span", 42);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtext"](7);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]()()()();
  }
  if (rf & 2) {
    const item_r16 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵproperty"]("ngIf", item_r16.selected);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵproperty"]("name", item_r16.icon);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtextInterpolate"](item_r16.chain);
  }
}
function WalletAuthorizeAddressPage_ng_template_42_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](0, "common-page", 45);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtemplate"](1, WalletAuthorizeAddressPage_ng_template_42_button_1_Template, 8, 3, "button", 46);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵproperty"]("contentBackground", "white")("contentSafeArea", true)("contentClass", "!px-0");
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵproperty"]("ngForOf", ctx_r5.chainList);
  }
}
/**
 * 授权地址
 */
class WalletAuthorizeAddressPage extends _modules_page_module__WEBPACK_IMPORTED_MODULE_3__.CommonPageBase {
  constructor() {
    super(...arguments);
    /** 权限服务 */
    this._permissionService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_16__.inject)(_services_permission_permission_service__WEBPACK_IMPORTED_MODULE_4__.PermissionService);
    this.walletOpen = false;
    this.networkOpen = false;
    /**
     * 链临时数据
     */
    this.chainList = [];
    /**
     * 获取地址方式类型
     */
    this.type = _bnqkl_wallet_base_services_plaoc__WEBPACK_IMPORTED_MODULE_5__.$WALLET_AUTHORIZE_ADDRESS_TYPE.main;
    /** 需要签名的数据 */
    this._signMessage = '';
    this.WALLET_AUTHORIZE_ADDRESS_TYPE = _bnqkl_wallet_base_services_plaoc__WEBPACK_IMPORTED_MODULE_5__.$WALLET_AUTHORIZE_ADDRESS_TYPE;
    /** 类型对应的文本 */
    this.typeText = {
      [_bnqkl_wallet_base_services_plaoc__WEBPACK_IMPORTED_MODULE_5__.$WALLET_AUTHORIZE_ADDRESS_TYPE.main]: "\u9078\u64C7\u6388\u6B0A\u9322\u5305",
      [_bnqkl_wallet_base_services_plaoc__WEBPACK_IMPORTED_MODULE_5__.$WALLET_AUTHORIZE_ADDRESS_TYPE.network]: "\u9078\u64C7\u6388\u6B0A\u7DB2\u7D61",
      [_bnqkl_wallet_base_services_plaoc__WEBPACK_IMPORTED_MODULE_5__.$WALLET_AUTHORIZE_ADDRESS_TYPE.all]: "\u5DF2\u6388\u6B0A\u9322\u5305"
    };
    /** 提示文本 */
    this.tipsText = {
      [_bnqkl_wallet_base_services_plaoc__WEBPACK_IMPORTED_MODULE_5__.$WALLET_AUTHORIZE_ADDRESS_TYPE.main]: "\u5141\u8A31\u7372\u53D6\u7576\u524D\u9322\u5305\u6BCF\u500B\u7DB2\u7D61\u4E0B\u7684\u5730\u5740",
      [_bnqkl_wallet_base_services_plaoc__WEBPACK_IMPORTED_MODULE_5__.$WALLET_AUTHORIZE_ADDRESS_TYPE.network]: "\u5141\u8A31\u8A2A\u554F\u6B64\u7DB2\u7D61\u4E0B\u6240\u6709\u5730\u5740",
      [_bnqkl_wallet_base_services_plaoc__WEBPACK_IMPORTED_MODULE_5__.$WALLET_AUTHORIZE_ADDRESS_TYPE.all]: "\u5141\u8A31\u7372\u53D6\u61C9\u7528\u4E2D\u6240\u6709\u9322\u5305\u7684\u5730\u5740"
    };
    /**
     * 应用链接
     */
    this.appHome = '';
    /**
     * 应用名称
     */
    this.appName = '';
    /**
     * 应用图标
     */
    this.appLogo = '';
    /**
     * 钱包名称
     */
    this.selectText = '';
    /**
     * 钱包头像
     */
    this.mainWalletHeadSculpture = '';
    /** 钱包ID */
    this.mainWalletId = '';
    /** 所有的身份钱包 */
    this.allMainWalletList = [];
    /**
     * 句柄id
     */
    this._eventId = '';
  }
  /** 授权类型 */
  get authorizeTypeText() {
    return this.typeText[this.type];
  }
  /** 授权提示 */
  get authorizeTipsText() {
    return this.tipsText[this.type];
  }
  /** 初始化获取传参 */
  initMnemonicArr() {
    var _this = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const resolveData = _this.resolveData;
      _this.chainName = resolveData.data.chainName;
      _this._eventId = resolveData.data.eventId;
      _this.type = resolveData.data.type;
      _this._signMessage = resolveData.data.signMessage;
      _this.appName = resolveData.data.appName;
      _this.appHome = resolveData.data.appHome;
      _this.appLogo = resolveData.data.appLogo;
      if (_this.type === _bnqkl_wallet_base_services_plaoc__WEBPACK_IMPORTED_MODULE_5__.$WALLET_AUTHORIZE_ADDRESS_TYPE.main) {
        const walletV2Service = _this.injectorForceGet(_bnqkl_wallet_base_services_wallet_wallet__WEBPACK_IMPORTED_MODULE_6__.WalletV2Service);
        const activeAddressInfo = yield walletV2Service.getActivateAddressWalletInfo();
        const mainWalletChainInfo = yield walletV2Service.walletDataStorageV2Service.getMainWalletInfo(activeAddressInfo.mainWalletId);
        _this.selectText = mainWalletChainInfo.name;
        _this.mainWalletHeadSculpture = mainWalletChainInfo.headSculpture;
        _this.mainWalletId = mainWalletChainInfo.mainWalletId;
        _this.allMainWalletList = yield walletV2Service.walletDataStorageV2Service.getAllMainWalletInfo();
      } else if (_this.type === _bnqkl_wallet_base_services_plaoc__WEBPACK_IMPORTED_MODULE_5__.$WALLET_AUTHORIZE_ADDRESS_TYPE.all) {
        _this.selectText = "\u6240\u6709\u9322\u5305\u5728 " + APP_NAME + "";
      } else if (_this.type === _bnqkl_wallet_base_services_plaoc__WEBPACK_IMPORTED_MODULE_5__.$WALLET_AUTHORIZE_ADDRESS_TYPE.network) {
        _this.selectText = _this.chainName;
        const chainV2Service = _this.injectorForceGet(_bnqkl_wallet_base_services_wallet_chain__WEBPACK_IMPORTED_MODULE_7__.ChainV2Service);
        const chainInfo = chainV2Service.getChainInfo(_this.chainName);
        _this.chainIcon = `icon-${chainInfo.chain}-${chainInfo.symbol.toLowerCase()}`;
        const chain_Set = new Set();
        const list = (yield chainV2Service.walletDataStorageV2Service.getAllChainAddressInfoList()).filter(item => {
          if (chain_Set.has(item.chain)) {
            return false;
          }
          chain_Set.add(item.chain);
          return true;
        });
        _this.chainList = list.map(item => {
          return {
            icon: `icon-${item.chain}-${item.symbol.toLowerCase()}`,
            chain: item.chain,
            selected: item.chain === _this.chainName
          };
        });
      }
    })();
  }
  /** 授权 */
  authorize() {
    var _this2 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      /// 校验密码
      const pwdInfo = yield _this2._permissionService.requestPassword();
      if (pwdInfo === false || pwdInfo === null) {
        return;
      }
      try {
        const plaoc = _this2.injectorForceGet(_bnqkl_wallet_base_services_plaoc__WEBPACK_IMPORTED_MODULE_5__.PlaocService);
        const addressList = [];
        const walletV2Service = _this2.injectorForceGet(_bnqkl_wallet_base_services_wallet_wallet__WEBPACK_IMPORTED_MODULE_6__.WalletV2Service);
        const chainV2Service = _this2.injectorForceGet(_bnqkl_wallet_base_services_wallet_chain__WEBPACK_IMPORTED_MODULE_7__.ChainV2Service);
        const walletList = yield (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
          const allAddressList = yield walletV2Service.walletDataStorageV2Service.getAllChainAddressInfoList();
          if (_this2.type === _bnqkl_wallet_base_services_plaoc__WEBPACK_IMPORTED_MODULE_5__.$WALLET_AUTHORIZE_ADDRESS_TYPE.main) {
            return allAddressList.filter(item => item.mainWalletId === _this2.mainWalletId);
          }
          if (_this2.type === _bnqkl_wallet_base_services_plaoc__WEBPACK_IMPORTED_MODULE_5__.$WALLET_AUTHORIZE_ADDRESS_TYPE.network) {
            return allAddressList.filter(item => item.chain === _this2.chainName);
          }
          return allAddressList;
        })();
        for (let i = 0; i < walletList.length; i++) {
          const walletInfo = walletList[i];
          const addressInfo = yield walletV2Service.walletDataStorageV2Service.getChainAddressInfo(walletInfo.addressKey);
          let publicKey = addressInfo.publicKey || '';
          let signMessage = '';
          if ((0,_bnqkl_framework_helpers__WEBPACK_IMPORTED_MODULE_8__.$isNoEmptyString)(publicKey) === false && addressInfo.mnemonic) {
            const chainApiService = chainV2Service.getChainService(addressInfo.chain);
            if (chainV2Service.isBioforestChainByChainName(addressInfo.chain)) {
              const keyInfo = yield chainApiService.createKeypair(addressInfo.mnemonic);
              publicKey = keyInfo.publicKey.toString('hex');
            } else {
              const chainInfo = chainV2Service.getChainInfo(addressInfo.chain);
              const data = yield chainV2Service.createAddressAndPrivkeyFromMnemonic(addressInfo.chain, chainInfo.coinId, addressInfo.mnemonic, addressInfo.index || 0, addressInfo.purpose || 44);
              publicKey = data.pubkey;
            }
          }
          let magic = '';
          if (chainV2Service.isBioforestChainByChainName(addressInfo.chain)) {
            const chainNameService = chainV2Service.getChainService(addressInfo.chain);
            magic = chainNameService.config.magic;
          }
          if (_this2._signMessage) {
            const chainApiService = chainV2Service.getChainService(addressInfo.chain);
            if (chainV2Service.isBioforestChainByChainName(addressInfo.chain)) {
              /// 内链用地址密码签
              signMessage = yield chainApiService.signMessage(_this2._signMessage, addressInfo.mnemonic);
            } else {
              signMessage = yield chainApiService.signMessage(_this2._signMessage, addressInfo.privateKey);
            }
          }
          addressList.push({
            name: walletInfo.name,
            address: addressInfo.address,
            chainName: addressInfo.chain,
            publicKey,
            magic,
            signMessage
          });
        }
        plaoc.respondWith(_this2._eventId, _bnqkl_wallet_base_services_plaoc__WEBPACK_IMPORTED_MODULE_5__.$WALLET_PLAOC_PATH.getAddress, addressList);
        plaoc.removeEventId(_this2._eventId);
        yield (0,_bnqkl_util_web_extends_promise__WEBPACK_IMPORTED_MODULE_9__.sleep)(500);
        _this2.nav.back();
      } catch (err) {
        _this2.console.error(err);
        _bnqkl_framework_plugins__WEBPACK_IMPORTED_MODULE_2__.Toast.show("\u5931\u6557");
      }
    })();
  }
  /** 移除缓存 */
  removeEvent() {
    const plaoc = this.injectorForceGet(_bnqkl_wallet_base_services_plaoc__WEBPACK_IMPORTED_MODULE_5__.PlaocService);
    plaoc.removeEventId(this._eventId);
  }
  /** 选择授权 */
  selectAuthorize() {
    if (this.type === _bnqkl_wallet_base_services_plaoc__WEBPACK_IMPORTED_MODULE_5__.$WALLET_AUTHORIZE_ADDRESS_TYPE.main) {
      this.walletOpen = !this.walletOpen;
    } else if (this.type === _bnqkl_wallet_base_services_plaoc__WEBPACK_IMPORTED_MODULE_5__.$WALLET_AUTHORIZE_ADDRESS_TYPE.network) {
      this.networkOpen = !this.networkOpen;
    }
  }
  /** 选择钱包 */
  selectWallet(wallet) {
    var _this3 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this3.walletOpen = false;
      _this3.selectText = wallet.name;
      _this3.mainWalletHeadSculpture = wallet.headSculpture;
      _this3.mainWalletId = wallet.mainWalletId;
    })();
  }
  /** 选择链 */
  selectChain(item) {
    var _this4 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      if (_this4.chainName !== item.chain) {
        _this4.chainList.find(item => {
          if (item.selected) {
            item.selected = false;
            return true;
          }
          return false;
        });
        _this4.selectText = item.chain;
        _this4.chainIcon = item.icon;
        _this4.chainName = item.chain;
        item.selected = true;
      }
      _this4.networkOpen = !_this4.networkOpen;
      _this4.cdRef.detectChanges();
    })();
  }
  /** 返回 */
  back() {
    if (this.nav.canGoBack) {
      this.nav.back();
    } else {
      this.nav.setPageRoot('tabs');
    }
  }
}
_class = WalletAuthorizeAddressPage;
_class.ɵfac = /*@__PURE__*/(() => {
  let ɵWalletAuthorizeAddressPage_BaseFactory;
  return function WalletAuthorizeAddressPage_Factory(t) {
    return (ɵWalletAuthorizeAddressPage_BaseFactory || (ɵWalletAuthorizeAddressPage_BaseFactory = _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵgetInheritedFactory"](_class)))(t || _class);
  };
})();
_class.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵdefineComponent"]({
  type: _class,
  selectors: [["w-authorize-address-page"]],
  standalone: true,
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵInheritDefinitionFeature"], _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵStandaloneFeature"]],
  decls: 43,
  vars: 21,
  consts: () => {
    let i18n_0;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_REQUEST_CONNECTION$$APPS_WALLET_SRC_PAGES_AUTHORIZE_PAGES_ADDRESS_ADDRESS_COMPONENT_TS_1 = goog.getMsg("Request Connection");
      i18n_0 = MSG_EXTERNAL_REQUEST_CONNECTION$$APPS_WALLET_SRC_PAGES_AUTHORIZE_PAGES_ADDRESS_ADDRESS_COMPONENT_TS_1;
    } else {
      i18n_0 = "\u8ACB\u6C42\u93C8\u63A5";
    }
    let i18n_2;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_AFTER_AUTHORIZATION_THE_APPLICATION_WILL_BOTAIN_THE_FOLLOWING_PERMISSIONS$$APPS_WALLET_SRC_PAGES_AUTHORIZE_PAGES_ADDRESS_ADDRESS_COMPONENT_TS_3 = goog.getMsg(" After authorization, the application will obtain the following permissions ");
      i18n_2 = MSG_EXTERNAL_AFTER_AUTHORIZATION_THE_APPLICATION_WILL_BOTAIN_THE_FOLLOWING_PERMISSIONS$$APPS_WALLET_SRC_PAGES_AUTHORIZE_PAGES_ADDRESS_ADDRESS_COMPONENT_TS_3;
    } else {
      i18n_2 = "\u6388\u6B0A\u540E\uFF0C\u61C9\u7528\u5C07\u7372\u5F97\u5982\u4E0B\u6B0A\u9650";
    }
    let i18n_4;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_ALLOW_AUTHORIZED_ADDRESSES_TO_REQUEST_SIGNATURES$$APPS_WALLET_SRC_PAGES_AUTHORIZE_PAGES_ADDRESS_ADDRESS_COMPONENT_TS_5 = goog.getMsg("{$startTagSpan}{$closeTagSpan}Allow authorized addresses to request signatures ", {
        "closeTagSpan": "\uFFFD/#28\uFFFD",
        "startTagSpan": "\uFFFD#28\uFFFD"
      }, {
        original_code: {
          "closeTagSpan": "</span>",
          "startTagSpan": "<span class=\"bg-subtext mr-[6px] inline-block h-[5px] w-[5px] shrink-0 rounded-full\">"
        }
      });
      i18n_4 = MSG_EXTERNAL_ALLOW_AUTHORIZED_ADDRESSES_TO_REQUEST_SIGNATURES$$APPS_WALLET_SRC_PAGES_AUTHORIZE_PAGES_ADDRESS_ADDRESS_COMPONENT_TS_5;
    } else {
      i18n_4 = "" + "\uFFFD#28\uFFFD" + "" + "\uFFFD/#28\uFFFD" + "\u5141\u8A31\u6388\u6B0A\u5730\u5740\u8ACB\u6C42\u7C3D\u540D ";
    }
    let i18n_6;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_Hint$$APPS_WALLET_SRC_PAGES_AUTHORIZE_PAGES_ADDRESS_ADDRESS_COMPONENT_TS_7 = goog.getMsg("Hint");
      i18n_6 = MSG_EXTERNAL_Hint$$APPS_WALLET_SRC_PAGES_AUTHORIZE_PAGES_ADDRESS_ADDRESS_COMPONENT_TS_7;
    } else {
      i18n_6 = "\u63D0\u793A";
    }
    let i18n_8;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_AUTHORIZATION_DOES_NOI_SHARE_YOUR_PRIVATE_KEY_INFORMATION$$APPS_WALLET_SRC_PAGES_AUTHORIZE_PAGES_ADDRESS_ADDRESS_COMPONENT_TS_9 = goog.getMsg("{$startTagSpan}{$closeTagSpan}Authorization does not share your private key information ", {
        "closeTagSpan": "\uFFFD/#33\uFFFD",
        "startTagSpan": "\uFFFD#33\uFFFD"
      }, {
        original_code: {
          "closeTagSpan": "</span>",
          "startTagSpan": "<span class=\"bg-subtext mr-[6px] inline-block h-[5px] w-[5px] shrink-0 rounded-full\">"
        }
      });
      i18n_8 = MSG_EXTERNAL_AUTHORIZATION_DOES_NOI_SHARE_YOUR_PRIVATE_KEY_INFORMATION$$APPS_WALLET_SRC_PAGES_AUTHORIZE_PAGES_ADDRESS_ADDRESS_COMPONENT_TS_9;
    } else {
      i18n_8 = "" + "\uFFFD#33\uFFFD" + "" + "\uFFFD/#33\uFFFD" + "\u6388\u6B0A\u4E0D\u6703\u5171\u4EAB\u60A8\u7684\u79C1\u9470\u4FE1\u606F ";
    }
    let i18n_10;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_REFUSE$$APPS_WALLET_SRC_PAGES_AUTHORIZE_PAGES_ADDRESS_ADDRESS_COMPONENT_TS_11 = goog.getMsg(" Refuse ");
      i18n_10 = MSG_EXTERNAL_REFUSE$$APPS_WALLET_SRC_PAGES_AUTHORIZE_PAGES_ADDRESS_ADDRESS_COMPONENT_TS_11;
    } else {
      i18n_10 = "\u62D2\u7D55";
    }
    let i18n_12;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_AUTHORIZE$$APPS_WALLET_SRC_PAGES_AUTHORIZE_PAGES_ADDRESS_ADDRESS_COMPONENT_TS_13 = goog.getMsg(" Authorize ");
      i18n_12 = MSG_EXTERNAL_AUTHORIZE$$APPS_WALLET_SRC_PAGES_AUTHORIZE_PAGES_ADDRESS_ADDRESS_COMPONENT_TS_13;
    } else {
      i18n_12 = "\u6388\u6B0A";
    }
    let i18n_14;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_SELECT_WALLET$$APPS_WALLET_SRC_PAGES_AUTHORIZE_PAGES_ADDRESS_ADDRESS_COMPONENT_TS__15 = goog.getMsg("Select Wallet");
      i18n_14 = MSG_EXTERNAL_SELECT_WALLET$$APPS_WALLET_SRC_PAGES_AUTHORIZE_PAGES_ADDRESS_ADDRESS_COMPONENT_TS__15;
    } else {
      i18n_14 = "\u9078\u64C7\u9322\u5305";
    }
    let i18n_18;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_SELECT_NETWORK$$APPS_WALLET_SRC_PAGES_AUTHORIZE_PAGES_ADDRESS_ADDRESS_COMPONENT_TS__19 = goog.getMsg("Select Network");
      i18n_18 = MSG_EXTERNAL_SELECT_NETWORK$$APPS_WALLET_SRC_PAGES_AUTHORIZE_PAGES_ADDRESS_ADDRESS_COMPONENT_TS__19;
    } else {
      i18n_18 = "\u9078\u64C7\u7DB2\u7D61";
    }
    return [["headerTitle", i18n_0, 3, "contentBackground", "footerTranslucent", "footerBackground", "headerBackground", "headerTranslucent", "contentSafeArea", "titleColor"], [1, "flex", "min-h-full", "flex-col", "items-center", "justify-start", "text-center"], [1, "mb-8"], [1, "mx-auto", "mt-4", "h-16", "w-16"], [1, "rounded-2", "h-full", "w-full", 3, "src"], [1, "text-title", "mt-2", "text-center", "text-base", "font-bold"], [1, "text-subtext", "text-xs"], [1, "px-page-safe-area-inset", "mb-6", "w-full", "text-sm"], [1, "text-title", "mb-2", "text-start", "font-bold"], ["bnRippleButton", "", 1, "rounded-3", "bg-env", "mb-1.5", "flex", "h-12", "w-full", "items-stretch", "justify-between", "px-4", "py-2", 3, "click"], [1, "flex", "w-[92%]", "items-center", "overflow-x-clip"], ["class", "h-[2rem] w-[2rem] shrink-0 rounded-full", "alt", "", 3, "src", 4, "ngIf"], ["class", "h-[2rem] w-[2rem]", "src", "./assets/images/logo.svg", "alt", "", 4, "ngIf"], ["class", "text-3xl", 3, "name", 4, "ngIf"], [1, "text-title", "ml-2", "font-bold", "tracking-normal"], ["class", "flex items-center justify-end", 4, "ngIf"], [1, "px-page-safe-area-inset", "text-subtext", "w-full", "text-start"], [1, "text-title", "mb-2", "font-bold"], i18n_2, [1, "mb-2", "flex", "items-center", "justify-start", "text-xs"], [1, "bg-subtext", "mr-[6px]", "inline-block", "h-[5px]", "w-[5px]", "shrink-0", "rounded-full"], [1, "flex", "items-center", "justify-start", "text-xs"], i18n_4, [1, "text-title", "mb-2", "mt-6", "font-bold"], i18n_6, i18n_8, ["footer", "", 1, "my-3", "flex", "w-full", "items-center", "justify-between"], ["bnRippleButton", "", 1, "border-tiny", "h-10.5", "text-title", "border-primary", "w-[46.86%]", "rounded-full", "text-center", 3, "click"], i18n_10, ["bnRippleButton", "", 1, "from-purple-gradient-start", "to-purple-gradient-end", "h-10.5", "w-[46.86%]", "rounded-full", "bg-gradient-to-b", "text-center", "text-white", 3, "click"], i18n_12, [3, "isOpen", "panelClass", "isOpenChange"], ["alt", "", 1, "h-[2rem]", "w-[2rem]", "shrink-0", "rounded-full", 3, "src"], ["src", "./assets/images/logo.svg", "alt", "", 1, "h-[2rem]", "w-[2rem]"], [1, "text-3xl", 3, "name"], [1, "flex", "items-center", "justify-end"], ["name", "right", 1, "icon-4", "text-subtext", "ml-1.5"], ["headerTitle", i18n_14, 3, "contentBackground", "contentSafeArea", "contentClass"], ["bnRippleButton", "", 1, "h-16", "w-full", "overflow-x-hidden", "px-5", 3, "click"], [1, "flex", "h-full", "items-center", "justify-start"], [1, "border-tiny", "border-subtext", "mr-3", "flex", "h-[1rem]", "w-[1rem]", "items-center", "justify-center", "rounded-[2px]"], ["name", "language-selected-1", "class", "shrink-0 text-[12px]", 3, "ngStyle"], [1, "text-title", "font-bold", "tracking-normal"], ["name", "language-selected-1", 1, "shrink-0", "text-[12px]", 3, "ngStyle"], ["bnRippleButton", "", "class", "h-16 w-full overflow-x-hidden px-5"], ["headerTitle", i18n_18, 3, "contentBackground", "contentSafeArea", "contentClass"], ["bnRippleButton", "", "class", "h-16 w-full overflow-x-hidden px-5", 3, "click", 4, "ngFor", "ngForOf"], ["name", "language-selected-1", "class", "shrink-0 text-[12px]", 3, "ngStyle", 4, "ngIf"], [1, "mr-3", "h-full", "shrink-0", "text-[2rem]", 3, "name"]];
  },
  template: function WalletAuthorizeAddressPage_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](0, "common-page", 0)(1, "div", 1)(2, "div", 2)(3, "div", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelement"](4, "img", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](5, "div", 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtext"](6);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](7, "div", 6);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtext"](8);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](9, "div", 7)(10, "div", 8);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtext"](11);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](12, "button", 9);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵlistener"]("click", function WalletAuthorizeAddressPage_Template_button_click_12_listener() {
        return ctx.selectAuthorize();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](13, "div", 10);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtemplate"](14, WalletAuthorizeAddressPage_img_14_Template, 1, 1, "img", 11)(15, WalletAuthorizeAddressPage_img_15_Template, 1, 0, "img", 12)(16, WalletAuthorizeAddressPage_w_icon_16_Template, 1, 1, "w-icon", 13);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](17, "span", 14);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtext"](18);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtemplate"](19, WalletAuthorizeAddressPage_div_19_Template, 2, 0, "div", 15);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](20, "div", 16)(21, "div", 17);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵi18n"](22, 18);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](23, "div", 19);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelement"](24, "span", 20);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtext"](25);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](26, "div", 21);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵi18nStart"](27, 22);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelement"](28, "span", 20);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵi18nEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](29, "div", 23);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵi18n"](30, 24);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](31, "div", 21);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵi18nStart"](32, 25);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelement"](33, "span", 20);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵi18nEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]()()();
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](34, "div", 26)(35, "button", 27);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵlistener"]("click", function WalletAuthorizeAddressPage_Template_button_click_35_listener() {
        return ctx.back();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵi18n"](36, 28);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](37, "button", 29);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵlistener"]("click", function WalletAuthorizeAddressPage_Template_button_click_37_listener() {
        return ctx.authorize();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵi18n"](38, 30);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]()()();
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](39, "common-bottom-sheet", 31);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵlistener"]("isOpenChange", function WalletAuthorizeAddressPage_Template_common_bottom_sheet_isOpenChange_39_listener($event) {
        return ctx.walletOpen = $event;
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtemplate"](40, WalletAuthorizeAddressPage_ng_template_40_Template, 3, 3, "ng-template");
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](41, "common-bottom-sheet", 31);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵlistener"]("isOpenChange", function WalletAuthorizeAddressPage_Template_common_bottom_sheet_isOpenChange_41_listener($event) {
        return ctx.networkOpen = $event;
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtemplate"](42, WalletAuthorizeAddressPage_ng_template_42_Template, 2, 4, "ng-template");
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵproperty"]("contentBackground", "white")("footerTranslucent", false)("footerBackground", "white")("headerBackground", "transparent")("headerTranslucent", false)("contentSafeArea", true)("titleColor", "title");
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](4);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵproperty"]("src", ctx.appLogo, _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵsanitizeUrl"]);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtextInterpolate"](ctx.appName);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtextInterpolate"](ctx.appHome);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtextInterpolate"](ctx.authorizeTypeText);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵproperty"]("ngIf", ctx.type === ctx.WALLET_AUTHORIZE_ADDRESS_TYPE.main);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵproperty"]("ngIf", ctx.type === ctx.WALLET_AUTHORIZE_ADDRESS_TYPE.all);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵproperty"]("ngIf", ctx.type === ctx.WALLET_AUTHORIZE_ADDRESS_TYPE.network);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtextInterpolate"](ctx.selectText);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵproperty"]("ngIf", ctx.type !== ctx.WALLET_AUTHORIZE_ADDRESS_TYPE.all);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](6);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtextInterpolate1"]("", ctx.authorizeTipsText, " ");
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](14);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵproperty"]("isOpen", ctx.walletOpen)("panelClass", "h-5/6");
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵproperty"]("isOpen", ctx.networkOpen)("panelClass", "h-5/6");
    }
  },
  dependencies: [_modules_page_module__WEBPACK_IMPORTED_MODULE_3__.CommonPageModule, _libs_bnf_modules_bottom_sheet_components_bottom_sheet_component__WEBPACK_IMPORTED_MODULE_11__.BottomSheetComponent, _libs_bnf_components_ripple_button_ripple_button_directive__WEBPACK_IMPORTED_MODULE_12__.RippleButtonDirective, _angular_common__WEBPACK_IMPORTED_MODULE_17__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_17__.NgIf, _angular_common__WEBPACK_IMPORTED_MODULE_17__.NgStyle, _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_13__.CommonPageComponent, _components_icon_icon_component__WEBPACK_IMPORTED_MODULE_14__.IconComponent, _pipes_color_color_pipe__WEBPACK_IMPORTED_MODULE_15__.ColorPipe],
  styles: ["[_nghost-%COMP%]   ._bg[_ngcontent-%COMP%] {\n  position: absolute;\n  left: 0rem;\n  top: 0rem;\n  height: 18rem;\n  width: auto;\n  --tw-bg-opacity: 1;\n  background-color: rgb(146 103 254 / var(--tw-bg-opacity));\n  object-fit: cover;\n  z-index: -1\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL2FwcHMvd2FsbGV0L3NyYy9wYWdlcy9hdXRob3JpemUvcGFnZXMvYWRkcmVzcy9hZGRyZXNzLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUVJO0VBQUEsa0JBQUE7RUFBQSxVQUFBO0VBQUEsU0FBQTtFQUFBLGFBQUE7RUFBQSxXQUFBO0VBQUEsa0JBQUE7RUFBQSx5REFBQTtFQUFBLGlCQUFBO0VBQ0E7QUFEQSIsInNvdXJjZXNDb250ZW50IjpbIjpob3N0IHtcclxuICAuX2JnIHtcclxuICAgIEBhcHBseSBiZy1wcmltYXJ5IGFic29sdXRlIGxlZnQtMCB0b3AtMCBoLTcyIHctYXV0byBvYmplY3QtY292ZXI7XHJcbiAgICB6LWluZGV4OiAtMTtcclxuICB9XHJcbn1cclxuIl0sInNvdXJjZVJvb3QiOiIifQ== */"],
  data: {
    animation: [_bnqkl_framework_animations__WEBPACK_IMPORTED_MODULE_10__.listFadeInRightTrigger]
  },
  changeDetection: 0
});
(0,tslib__WEBPACK_IMPORTED_MODULE_18__.__decorate)([WalletAuthorizeAddressPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_18__.__metadata)("design:type", Object)], WalletAuthorizeAddressPage.prototype, "walletOpen", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_18__.__decorate)([WalletAuthorizeAddressPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_18__.__metadata)("design:type", Object)], WalletAuthorizeAddressPage.prototype, "networkOpen", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_18__.__decorate)([WalletAuthorizeAddressPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_18__.__metadata)("design:type", Array)], WalletAuthorizeAddressPage.prototype, "chainList", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_18__.__decorate)([WalletAuthorizeAddressPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_18__.__metadata)("design:type", String)], WalletAuthorizeAddressPage.prototype, "chainName", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_18__.__decorate)([WalletAuthorizeAddressPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_18__.__metadata)("design:type", String)], WalletAuthorizeAddressPage.prototype, "chainIcon", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_18__.__decorate)([WalletAuthorizeAddressPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_18__.__metadata)("design:type", Object)], WalletAuthorizeAddressPage.prototype, "type", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_18__.__decorate)([WalletAuthorizeAddressPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_18__.__metadata)("design:type", Object)], WalletAuthorizeAddressPage.prototype, "appHome", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_18__.__decorate)([WalletAuthorizeAddressPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_18__.__metadata)("design:type", Object)], WalletAuthorizeAddressPage.prototype, "appName", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_18__.__decorate)([WalletAuthorizeAddressPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_18__.__metadata)("design:type", Object)], WalletAuthorizeAddressPage.prototype, "appLogo", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_18__.__decorate)([WalletAuthorizeAddressPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_18__.__metadata)("design:type", Object)], WalletAuthorizeAddressPage.prototype, "selectText", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_18__.__decorate)([WalletAuthorizeAddressPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_18__.__metadata)("design:type", Object)], WalletAuthorizeAddressPage.prototype, "mainWalletHeadSculpture", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_18__.__decorate)([WalletAuthorizeAddressPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_18__.__metadata)("design:type", Object)], WalletAuthorizeAddressPage.prototype, "mainWalletId", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_18__.__decorate)([WalletAuthorizeAddressPage.States(), (0,tslib__WEBPACK_IMPORTED_MODULE_18__.__metadata)("design:type", Object)], WalletAuthorizeAddressPage.prototype, "allMainWalletList", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_18__.__decorate)([WalletAuthorizeAddressPage.OnInit(), (0,tslib__WEBPACK_IMPORTED_MODULE_18__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_18__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_18__.__metadata)("design:returntype", Promise)], WalletAuthorizeAddressPage.prototype, "initMnemonicArr", null);
(0,tslib__WEBPACK_IMPORTED_MODULE_18__.__decorate)([WalletAuthorizeAddressPage.OnDestroy(), (0,tslib__WEBPACK_IMPORTED_MODULE_18__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_18__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_18__.__metadata)("design:returntype", void 0)], WalletAuthorizeAddressPage.prototype, "removeEvent", null);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (WalletAuthorizeAddressPage);

/***/ })

}]);
//# sourceMappingURL=apps_wallet_src_pages_authorize_pages_address_address_component_ts.js.map