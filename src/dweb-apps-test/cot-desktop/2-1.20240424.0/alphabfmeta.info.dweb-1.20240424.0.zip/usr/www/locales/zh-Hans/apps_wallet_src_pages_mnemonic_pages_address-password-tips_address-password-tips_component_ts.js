"use strict";
(self["webpackChunkwallet"] = self["webpackChunkwallet"] || []).push([["apps_wallet_src_pages_mnemonic_pages_address-password-tips_address-password-tips_component_ts"],{

/***/ 29312:
/*!*******************************************************************************************************!*\
  !*** ./apps/wallet/src/pages/mnemonic/pages/address-password-tips/address-password-tips.component.ts ***!
  \*******************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AddressPasswordTipsPage: () => (/* binding */ AddressPasswordTipsPage),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 52542);
/* harmony import */ var _modules_page_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ~modules/page.module */ 77538);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 61039);
/* harmony import */ var _libs_bnf_components_ripple_button_ripple_button_directive__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../../../libs/bnf/components/ripple-button/ripple-button.directive */ 16505);
/* harmony import */ var _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../../../../libs/bnf/modules/page/common-page/common-page.component */ 62052);

var _class;




/**
 * 备份助记词提示页面
 * @FIXME
 */
/** 助记词备份提示页 */
class AddressPasswordTipsPage extends _modules_page_module__WEBPACK_IMPORTED_MODULE_1__.CommonPageBase {
  /** 进入都创建助记词页面 */
  goToBackup() {
    var _this = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      // 基本参数传递到
      return _this.nav.routeTo('/mnemonic/address-password-backup', _this.nav.getQueryParams(), true);
    })();
  }
}
_class = AddressPasswordTipsPage;
_class.ɵfac = /*@__PURE__*/(() => {
  let ɵAddressPasswordTipsPage_BaseFactory;
  return function AddressPasswordTipsPage_Factory(t) {
    return (ɵAddressPasswordTipsPage_BaseFactory || (ɵAddressPasswordTipsPage_BaseFactory = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵgetInheritedFactory"](_class)))(t || _class);
  };
})();
_class.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineComponent"]({
  type: _class,
  selectors: [["w-address-password-tips-page"]],
  standalone: true,
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵInheritDefinitionFeature"], _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵStandaloneFeature"]],
  decls: 19,
  vars: 1,
  consts: () => {
    let i18n_0;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_BACKUP_ADDRESS_PASSWORD$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_ADDRESS_PASSWORD_TIPS_ADDRESS_PASSWORD_TIPS_COMPONENT_TS_1 = goog.getMsg("Backup Address Password");
      i18n_0 = MSG_EXTERNAL_BACKUP_ADDRESS_PASSWORD$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_ADDRESS_PASSWORD_TIPS_ADDRESS_PASSWORD_TIPS_COMPONENT_TS_1;
    } else {
      i18n_0 = "\u5907\u4EFD\u5730\u5740\u5BC6\u7801";
    }
    let i18n_2;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL__OBTAINING_THE_ADDRESS_PASSOWRD_IS_EQUIVALENT_TO_OWNING_THE_WALLET_ASSET$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_ADDRESS_PASSWORD_TIPS_ADDRESS_PASSWORD_TIPS_COMPONENT_TS_3 = goog.getMsg(" Obtaining the address password is equivalent to owning the wallet asset ");
      i18n_2 = MSG_EXTERNAL__OBTAINING_THE_ADDRESS_PASSOWRD_IS_EQUIVALENT_TO_OWNING_THE_WALLET_ASSET$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_ADDRESS_PASSWORD_TIPS_ADDRESS_PASSWORD_TIPS_COMPONENT_TS_3;
    } else {
      i18n_2 = "\u83B7\u5F97\u5730\u5740\u5BC6\u7801\u7B49\u540C\u4E8E\u62E5\u6709\u94B1\u5305\u8D44\u4EA7\u6240\u6709\u6743";
    }
    let i18n_4;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_IMPORTANT_HINT$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_ADDRESS_PASSWORD_TIPS_ADDRESS_PASSWORD_TIPS_COMPONENT_TS_5 = goog.getMsg("Important Hint !");
      i18n_4 = MSG_EXTERNAL_IMPORTANT_HINT$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_ADDRESS_PASSWORD_TIPS_ADDRESS_PASSWORD_TIPS_COMPONENT_TS_5;
    } else {
      i18n_4 = "\u91CD\u8981\u63D0\u793A\uFF01";
    }
    let i18n_6;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_BE_SURE_TO_KEEP_THE_ADDRESS_PASSWORD_IN_A_SAFE_PLACE$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_ADDRESS_PASSWORD_TIPS_ADDRESS_PASSWORD_TIPS_COMPONENT_TS_7 = goog.getMsg(" Be sure to keep the address password in a safe place. ");
      i18n_6 = MSG_EXTERNAL_BE_SURE_TO_KEEP_THE_ADDRESS_PASSWORD_IN_A_SAFE_PLACE$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_ADDRESS_PASSWORD_TIPS_ADDRESS_PASSWORD_TIPS_COMPONENT_TS_7;
    } else {
      i18n_6 = "\u8BF7\u52A1\u5FC5\u5C06\u5730\u5740\u5BC6\u7801\u4FDD\u5B58\u81F3\u5B89\u5168\u7684\u5730\u65B9\u3002";
    }
    let i18n_8;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_IF_THE_ADDRESS_PASSWORD_IS_LOST_IT_CANNOT_BE_RETRIEVED$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_ADDRESS_PASSWORD_TIPS_ADDRESS_PASSWORD_TIPS_COMPONENT_TS_9 = goog.getMsg(" If the address password is lost, it cannot be retrieved. ");
      i18n_8 = MSG_EXTERNAL_IF_THE_ADDRESS_PASSWORD_IS_LOST_IT_CANNOT_BE_RETRIEVED$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_ADDRESS_PASSWORD_TIPS_ADDRESS_PASSWORD_TIPS_COMPONENT_TS_9;
    } else {
      i18n_8 = "\u5730\u5740\u5BC6\u7801\u4E22\u5931\u5C06\u65E0\u6CD5\u627E\u56DE\u3002";
    }
    let i18n_10;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_PAGE_FOOTER$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_ADDRESS_PASSWORD_TIPS_ADDRESS_PASSWORD_TIPS_COMPONENT_TS_11 = goog.getMsg("Page footer");
      i18n_10 = MSG_EXTERNAL_PAGE_FOOTER$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_ADDRESS_PASSWORD_TIPS_ADDRESS_PASSWORD_TIPS_COMPONENT_TS_11;
    } else {
      i18n_10 = "\u9875\u811A";
    }
    let i18n_12;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_NEXT$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_ADDRESS_PASSWORD_TIPS_ADDRESS_PASSWORD_TIPS_COMPONENT_TS_13 = goog.getMsg(" Next ");
      i18n_12 = MSG_EXTERNAL_NEXT$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_ADDRESS_PASSWORD_TIPS_ADDRESS_PASSWORD_TIPS_COMPONENT_TS_13;
    } else {
      i18n_12 = "\u4E0B\u4E00\u6B65";
    }
    return [[3, "contentSafeArea"], [1, "w-45", "mx-auto", "pt-6"], ["src", "./assets/images/icon_address.svg"], [1, "text-center"], [1, "mb-1.5", "mt-3", "text-base", "font-semibold"], i18n_0, [1, "text-text", "text-sm"], i18n_2, [1, "mt-6", "rounded", "bg-[#fff0ee]", "px-5", "py-4"], [1, "text-error", "mb-1.5", "font-semibold"], i18n_4, [1, "text-error", "text-xs"], i18n_6, [1, "mt-1"], i18n_8, ["footer", "", "aria-label", i18n_10], ["bnRippleButton", "", 1, "from-purple-gradient-start", "to-purple-gradient-end", "h-10.5", "w-full", "rounded-full", "bg-gradient-to-b", "text-center", "text-white", 3, "click"], i18n_12];
  },
  template: function AddressPasswordTipsPage_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "common-page", 0)(1, "div", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](2, "img", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](3, "div", 3)(4, "div", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵi18n"](5, 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](6, "div", 6);
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵi18n"](7, 7);
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](8, "div", 8)(9, "div", 9);
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵi18n"](10, 10);
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](11, "div", 11);
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementContainerStart"](12);
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵi18n"](13, 12);
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementContainerEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](14, "div", 13);
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵi18n"](15, 14);
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()()();
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](16, "div", 15)(17, "button", 16);
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function AddressPasswordTipsPage_Template_button_click_17_listener() {
        return ctx.goToBackup();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵi18n"](18, 17);
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()();
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("contentSafeArea", true);
    }
  },
  dependencies: [_modules_page_module__WEBPACK_IMPORTED_MODULE_1__.CommonPageModule, _libs_bnf_components_ripple_button_ripple_button_directive__WEBPACK_IMPORTED_MODULE_2__.RippleButtonDirective, _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_3__.CommonPageComponent],
  styles: ["/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsInNvdXJjZVJvb3QiOiIifQ== */"],
  changeDetection: 0
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (AddressPasswordTipsPage);

/***/ })

}]);
//# sourceMappingURL=apps_wallet_src_pages_mnemonic_pages_address-password-tips_address-password-tips_component_ts.js.map