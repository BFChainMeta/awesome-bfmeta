"use strict";
(self["webpackChunkwallet"] = self["webpackChunkwallet"] || []).push([["apps_wallet_src_pages_home_pages_home-manage-wallets_home-manage-wallets_component_ts"],{

/***/ 19136:
/*!***********************************************************************************************!*\
  !*** ./apps/wallet/src/pages/home/pages/home-manage-wallets/home-manage-wallets.component.ts ***!
  \***********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   HomeManageWalletsPage: () => (/* binding */ HomeManageWalletsPage),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 52542);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! tslib */ 90505);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/core */ 61039);
/* harmony import */ var _bnqkl_wallet_base_services_wallet_wallet_data_storage__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @bnqkl/wallet-base/services/wallet/wallet-data-storage */ 63024);
/* harmony import */ var _pages_home_components_wallet_list_wallet_list_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ~pages/home/components/wallet-list/wallet-list.component */ 79345);
/* harmony import */ var _bnqkl_framework_controllers__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @bnqkl/framework/controllers */ 47919);
/* harmony import */ var _bnqkl_framework_plugins_toast__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @bnqkl/framework/plugins/toast */ 18030);
/* harmony import */ var _modules_page_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ~modules/page.module */ 77538);
/* harmony import */ var _pages_mnemonic_pages_manage_manage_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ~pages/mnemonic/pages/manage/manage.component */ 54414);
/* harmony import */ var _pages_mnemonic_pages_mnemonic_confirm_backup_mnemonic_confirm_backup_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ~pages/mnemonic/pages/mnemonic-confirm-backup/mnemonic-confirm-backup.component */ 91879);
/* harmony import */ var _home_add_wallets_home_add_wallets_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../home-add-wallets/home-add-wallets.component */ 61007);
/* harmony import */ var _home_import_wallet_home_import_wallet_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../home-import-wallet/home-import-wallet.component */ 72710);
/* harmony import */ var _libs_bnf_components_ripple_button_ripple_button_directive__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../../../../../../libs/bnf/components/ripple-button/ripple-button.directive */ 16505);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/router */ 56776);
/* harmony import */ var _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../../../../../../libs/bnf/modules/page/common-page/common-page.component */ 62052);
/* harmony import */ var _components_icon_icon_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../../../components/icon/icon.component */ 74703);

var _class;
















const _c4 = () => ["/home-add-wallets"];
/**
 * 管理钱包的页面
 */
class HomeManageWalletsPage extends _modules_page_module__WEBPACK_IMPORTED_MODULE_5__.CommonPageBase {
  constructor() {
    super(...arguments);
    /** 添加钱包页面返回 */
    this.toPageReturnController = new _bnqkl_framework_controllers__WEBPACK_IMPORTED_MODULE_3__.PageReturnController(this, _home_add_wallets_home_add_wallets_component__WEBPACK_IMPORTED_MODULE_8__.HomeAddWalletsPage);
    /** 创建钱包页面返回 */
    this.mnemonicConfirmBackupPageReturnController = new _bnqkl_framework_controllers__WEBPACK_IMPORTED_MODULE_3__.PageReturnController(this, _pages_mnemonic_pages_mnemonic_confirm_backup_mnemonic_confirm_backup_component__WEBPACK_IMPORTED_MODULE_7__.MnemonicConfirmBackupPage);
    /** 导入钱包页面返回  */
    this.homeImportWalletPageReturnController = new _bnqkl_framework_controllers__WEBPACK_IMPORTED_MODULE_3__.PageReturnController(this, _home_import_wallet_home_import_wallet_component__WEBPACK_IMPORTED_MODULE_9__.HomeImportWalletPage);
    /** Manage页面返回 */
    this.managePageReturnController = new _bnqkl_framework_controllers__WEBPACK_IMPORTED_MODULE_3__.PageReturnController(this, _pages_mnemonic_pages_manage_manage_component__WEBPACK_IMPORTED_MODULE_6__.ManagePage);
    this.walletDataStorageService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_13__.inject)(_bnqkl_wallet_base_services_wallet_wallet_data_storage__WEBPACK_IMPORTED_MODULE_1__.WalletDataStorageService);
  }
  /** 初始化返回值监听 */
  watchPageReturn() {}
  /** 点击钱包卡片 */
  onClickWalletItem() {
    /// event: $ClickWalletItemEvent
  }
  /** 去管理身份钱包页 */
  goToManage(item) {
    var _this = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      try {
        /**
         * @TODO 这里应该在 resolver 中来实现
         */
        const mainWalleter = yield _this.walletDataStorageService.getWalleterInfo();
        if (mainWalleter === undefined) {
          throw new Error('not find walleter ');
        }
        const addressInfo = yield _this.walletDataStorageService.getChainAddressInfo(item.addressKey);
        _this.nav.routeTo('/mnemonic/manage', {
          pageType: 'identityWallet',
          name: mainWalleter === null || mainWalleter === void 0 ? void 0 : mainWalleter.name,
          walletAddress: item === null || item === void 0 ? void 0 : item.address,
          walletName: item === null || item === void 0 ? void 0 : item.name,
          chain: item.chain,
          privateKey: addressInfo.privateKey,
          addressKey: addressInfo.addressKey
        });
      } catch (error) {
        _bnqkl_framework_plugins_toast__WEBPACK_IMPORTED_MODULE_4__.Toast.show(error instanceof Error ? error.message : String(error));
      }
    })();
  }
  /** 去非管理身份钱包页 */
  goToNoIdentityWallets(item) {
    var _this2 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      try {
        const noMainWalleter = yield _this2.walletDataStorageService.getWalleterInfo();
        if (noMainWalleter === undefined) {
          throw new Error('not find walleter ');
        }
        const addressInfo = yield _this2.walletDataStorageService.getChainAddressInfo(item.addressKey);
        _this2.nav.routeTo('/mnemonic/manage', {
          pageType: 'noIdentityWallet',
          name: noMainWalleter === null || noMainWalleter === void 0 ? void 0 : noMainWalleter.name,
          walletAddress: item === null || item === void 0 ? void 0 : item.address,
          walletName: item === null || item === void 0 ? void 0 : item.name,
          notMainWalletKey: item.notMainWalletKey,
          chain: item.chain,
          importType: item.importType,
          privateKey: addressInfo.privateKey,
          addressKey: addressInfo.addressKey
        });
      } catch (error) {
        _bnqkl_framework_plugins_toast__WEBPACK_IMPORTED_MODULE_4__.Toast.show(error instanceof Error ? error.message : String(error));
      }
    })();
  }
}
_class = HomeManageWalletsPage;
_class.ɵfac = /*@__PURE__*/(() => {
  let ɵHomeManageWalletsPage_BaseFactory;
  return function HomeManageWalletsPage_Factory(t) {
    return (ɵHomeManageWalletsPage_BaseFactory || (ɵHomeManageWalletsPage_BaseFactory = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵgetInheritedFactory"](_class)))(t || _class);
  };
})();
_class.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdefineComponent"]({
  type: _class,
  selectors: [["w-home-manage-wallets-page"]],
  viewQuery: function HomeManageWalletsPage_Query(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵviewQuery"](_pages_home_components_wallet_list_wallet_list_component__WEBPACK_IMPORTED_MODULE_2__.WalletListComponent, 7);
    }
    if (rf & 2) {
      let _t;
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵloadQuery"]()) && (ctx.walletList = _t.first);
    }
  },
  standalone: true,
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵInheritDefinitionFeature"], _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵStandaloneFeature"]],
  decls: 8,
  vars: 14,
  consts: () => {
    let i18n_0;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_MANAGE$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_MANAGE_WALLETS_HOME_MANAGE_WALLETS_COMPONENT_TS_1 = goog.getMsg(" Manage ");
      i18n_0 = MSG_EXTERNAL_MANAGE$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_MANAGE_WALLETS_HOME_MANAGE_WALLETS_COMPONENT_TS_1;
    } else {
      i18n_0 = "\u7BA1\u7406";
    }
    let i18n_2;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_ADD_WALLET$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_MANAGE_WALLETS_HOME_MANAGE_WALLETS_COMPONENT_TS_3 = goog.getMsg("Add Wallet");
      i18n_2 = MSG_EXTERNAL_ADD_WALLET$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_MANAGE_WALLETS_HOME_MANAGE_WALLETS_COMPONENT_TS_3;
    } else {
      i18n_2 = "\u6DFB\u52A0\u9322\u5305";
    }
    return [[3, "contentBackground", "contentClass", "contentSafeArea", "footerSpacerTheme", "footerClass"], [1, "h-full", 3, "paddingTop", "paddingBottom", "paddingLeft", "paddingRight", "mainWalletList"], ["titleEnd", "", "bnRippleButton", "", 1, "text-primary-2", "rounded-lg", "px-2", "py-1", "text-sm", 3, "routerLink"], i18n_0, ["footer", "", "bnRippleButton", "", 1, "pb-page-safe-area-inset", "absolute", "left-0", "top-0", "flex", "h-full", "w-full", "items-center", "justify-center", "bg-white/80", 3, "rippleColor", "routerLink"], ["name", "add", 1, "text-base"], [1, "ml-2", "text-sm"], i18n_2];
  },
  template: function HomeManageWalletsPage_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "common-page", 0)(1, "w-home-wallet-list", 1)(2, "button", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵi18n"](3, 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](4, "button", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](5, "w-icon", 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](6, "div", 6);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵi18n"](7, 7);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()()();
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("contentBackground", "white")("contentClass", "!p-0")("contentSafeArea", true)("footerSpacerTheme", "strict")("footerClass", "text-title border-solid border-line rounded-t-large border-t-tiny overflow-hidden relative pt-12.5");
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("paddingTop", "var(--page-content-padding-top, 0px)")("paddingBottom", "var(--page-content-padding-bottom, 0px)")("paddingLeft", "var(--page-safe-area-inset-left, 0px)")("paddingRight", "var(--page-safe-area-inset-right, 0px)")("mainWalletList", ctx.resolveData.mainWalletList);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("routerLink", "/mnemonic/manage-identity-wallet");
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("rippleColor", "rgba(255,255,255,0.1)")("routerLink", _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpureFunction0"](13, _c4));
    }
  },
  dependencies: [_modules_page_module__WEBPACK_IMPORTED_MODULE_5__.CommonPageModule, _libs_bnf_components_ripple_button_ripple_button_directive__WEBPACK_IMPORTED_MODULE_10__.RippleButtonDirective, _angular_router__WEBPACK_IMPORTED_MODULE_14__.RouterLink, _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_11__.CommonPageComponent, _components_icon_icon_component__WEBPACK_IMPORTED_MODULE_12__.IconComponent, _pages_home_components_wallet_list_wallet_list_component__WEBPACK_IMPORTED_MODULE_2__.WalletListComponent],
  styles: ["/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsInNvdXJjZVJvb3QiOiIifQ== */"],
  changeDetection: 0
});
(0,tslib__WEBPACK_IMPORTED_MODULE_15__.__decorate)([HomeManageWalletsPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_15__.__metadata)("design:type", Object)], HomeManageWalletsPage.prototype, "toPageReturnController", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_15__.__decorate)([HomeManageWalletsPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_15__.__metadata)("design:type", Object)], HomeManageWalletsPage.prototype, "mnemonicConfirmBackupPageReturnController", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_15__.__decorate)([HomeManageWalletsPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_15__.__metadata)("design:type", Object)], HomeManageWalletsPage.prototype, "homeImportWalletPageReturnController", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_15__.__decorate)([HomeManageWalletsPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_15__.__metadata)("design:type", Object)], HomeManageWalletsPage.prototype, "managePageReturnController", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_15__.__decorate)([HomeManageWalletsPage.OnInit(), (0,tslib__WEBPACK_IMPORTED_MODULE_15__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_15__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_15__.__metadata)("design:returntype", void 0)], HomeManageWalletsPage.prototype, "watchPageReturn", null);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (HomeManageWalletsPage);

/***/ })

}]);
//# sourceMappingURL=apps_wallet_src_pages_home_pages_home-manage-wallets_home-manage-wallets_component_ts.js.map