"use strict";
(self["webpackChunkwallet"] = self["webpackChunkwallet"] || []).push([["default-apps_wallet_src_pages_mnemonic_pages_home-transfer_home-transfer_component_ts"],{

/***/ 7406:
/*!***************************************************************************************!*\
  !*** ./apps/wallet/src/pages/mnemonic/pages/home-transfer/home-transfer.component.ts ***!
  \***************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   HomeTransferPage: () => (/* binding */ HomeTransferPage),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 52542);
/* harmony import */ var D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncIterator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/esm/asyncIterator.js */ 9243);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_45__ = __webpack_require__(/*! tslib */ 90505);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_39__ = __webpack_require__(/*! @angular/core */ 61039);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_40__ = __webpack_require__(/*! @angular/forms */ 7820);
/* harmony import */ var _bnqkl_framework_controllers__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @bnqkl/framework/controllers */ 47919);
/* harmony import */ var _bnqkl_framework_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @bnqkl/framework/core */ 63563);
/* harmony import */ var _bnqkl_framework_helpers__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @bnqkl/framework/helpers */ 12169);
/* harmony import */ var _bnqkl_framework_pipes__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @bnqkl/framework/pipes */ 80909);
/* harmony import */ var _bnqkl_framework_plugins_barcode_scanner__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @bnqkl/framework/plugins/barcode-scanner */ 5005);
/* harmony import */ var _bnqkl_framework_plugins_network__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @bnqkl/framework/plugins/network */ 510);
/* harmony import */ var _bnqkl_framework_plugins_toast__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @bnqkl/framework/plugins/toast */ 18030);
/* harmony import */ var _bnqkl_util_web_extends_promise__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @bnqkl/util-web/extends-promise */ 87778);
/* harmony import */ var _bnqkl_wallet_base_services_wallet_binance__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @bnqkl/wallet-base/services/wallet/binance */ 45343);
/* harmony import */ var _bnqkl_wallet_base_services_wallet_chain__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @bnqkl/wallet-base/services/wallet/chain */ 27434);
/* harmony import */ var _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @bnqkl/wallet-base/services/wallet/chain-base */ 27187);
/* harmony import */ var _bnqkl_wallet_base_services_wallet_ethereum__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @bnqkl/wallet-base/services/wallet/ethereum */ 70641);
/* harmony import */ var _bnqkl_wallet_base_services_wallet_tron__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @bnqkl/wallet-base/services/wallet/tron */ 50274);
/* harmony import */ var _bnqkl_wallet_base_services_wallet_wallet_data_storage__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @bnqkl/wallet-base/services/wallet/wallet-data-storage */ 63024);
/* harmony import */ var _bnqkl_wallet_base_services_wallet_wallet_fetch__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @bnqkl/wallet-base/services/wallet/wallet-fetch */ 44408);
/* harmony import */ var _bnqkl_wallet_base_tools__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @bnqkl/wallet-base/tools */ 38881);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_41__ = __webpack_require__(/*! rxjs */ 14115);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_42__ = __webpack_require__(/*! rxjs */ 19177);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_43__ = __webpack_require__(/*! rxjs */ 41720);
/* harmony import */ var _environments_index__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ~environments/index */ 40014);
/* harmony import */ var _modules_page_module__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ~modules/page.module */ 77538);
/* harmony import */ var _pages_home_pages_home_payment_details_home_payment_details_component__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ~pages/home/pages/home-payment-details/home-payment-details.component */ 38093);
/* harmony import */ var _pages_scanner_scanner_component__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! ~pages/scanner/scanner.component */ 41405);
/* harmony import */ var _mime_pages_address_book_address_book_component__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! ../../../mime/pages/address-book/address-book.component */ 35866);
/* harmony import */ var _home_select_token_home_select_token_component__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! ../home-select-token/home-select-token.component */ 33299);
/* harmony import */ var _helpers_utils__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! ~helpers/utils */ 6596);
/* harmony import */ var _libs_bnf_modules_bottom_sheet_components_bottom_sheet_component__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! ../../../../../../../libs/bnf/modules/bottom-sheet/components/bottom-sheet.component */ 94072);
/* harmony import */ var _libs_bnf_components_ripple_button_ripple_button_directive__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! ../../../../../../../libs/bnf/components/ripple-button/ripple-button.directive */ 16505);
/* harmony import */ var _libs_bnf_directives_form_errors_directive__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! ../../../../../../../libs/bnf/directives/form-errors.directive */ 29541);
/* harmony import */ var _libs_bnf_directives_auto_complete_off_directive__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! ../../../../../../../libs/bnf/directives/auto-complete-off.directive */ 66722);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_44__ = __webpack_require__(/*! @angular/common */ 6729);
/* harmony import */ var _libs_bnf_modules_dialog_components_common_card_common_card_component__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! ../../../../../../../libs/bnf/modules/dialog/components/common-card/common-card.component */ 92686);
/* harmony import */ var _libs_bnf_modules_dialog_components_card_footer_confirm_confirm_footer_component__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(/*! ../../../../../../../libs/bnf/modules/dialog/components/card-footer-confirm/confirm-footer.component */ 42489);
/* harmony import */ var _libs_bnf_modules_dialog_components_template_dialog_opener_template_dialog_opener_component__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(/*! ../../../../../../../libs/bnf/modules/dialog/components/template-dialog-opener/template-dialog-opener.component */ 57628);
/* harmony import */ var _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_32__ = __webpack_require__(/*! ../../../../../../../libs/bnf/modules/page/common-page/common-page.component */ 62052);
/* harmony import */ var _components_icon_icon_component__WEBPACK_IMPORTED_MODULE_33__ = __webpack_require__(/*! ../../../../components/icon/icon.component */ 74703);
/* harmony import */ var _components_form_validation_top_tips_form_validation_top_tips_component__WEBPACK_IMPORTED_MODULE_34__ = __webpack_require__(/*! ../../../../components/form-validation-top-tips/form-validation-top-tips.component */ 34113);
/* harmony import */ var _libs_bnf_components_loading_wrapper_loading_wrapper_component__WEBPACK_IMPORTED_MODULE_35__ = __webpack_require__(/*! ../../../../../../../libs/bnf/components/loading-wrapper/loading-wrapper.component */ 51263);
/* harmony import */ var _libs_bnf_pipes_errors_errors_pipe__WEBPACK_IMPORTED_MODULE_36__ = __webpack_require__(/*! ../../../../../../../libs/bnf/pipes/errors/errors.pipe */ 68362);
/* harmony import */ var _libs_bnf_pipes_number_format_number_format_pipe__WEBPACK_IMPORTED_MODULE_37__ = __webpack_require__(/*! ../../../../../../../libs/bnf/pipes/number-format/number-format.pipe */ 89873);
/* harmony import */ var _libs_bnf_pipes_amountFixed_amount_fixed_pipe__WEBPACK_IMPORTED_MODULE_38__ = __webpack_require__(/*! ../../../../../../../libs/bnf/pipes/amountFixed/amount-fixed.pipe */ 44070);


var _class;












































const _c0 = ["bioforestChainFeeInput"];
function HomeTransferPage_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r12 = _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵelementStart"](0, "button", 35);
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵlistener"]("click", function HomeTransferPage_Conditional_2_Template_button_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵrestoreView"](_r12);
      const ctx_r11 = _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵresetView"](ctx_r11.routeToScanner());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵelement"](1, "w-icon", 36);
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵproperty"]("mode", "icon");
  }
}
function HomeTransferPage_div_11_div_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵelementStart"](0, "div", 39);
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵi18n"](1, 40);
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵelementEnd"]();
  }
}
function HomeTransferPage_div_11_div_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵelementStart"](0, "div", 39);
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const errors_r13 = _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵnextContext"]().ngIf;
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵtextInterpolate1"](" ", errors_r13["address"], " ");
  }
}
function HomeTransferPage_div_11_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵelementStart"](0, "div", 37);
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵtemplate"](1, HomeTransferPage_div_11_div_1_Template, 2, 0, "div", 38)(2, HomeTransferPage_div_11_div_2_Template, 2, 1, "div", 38);
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const errors_r13 = ctx.ngIf;
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵproperty"]("ngIf", errors_r13["required"] || errors_r13["trimRequired"] || errors_r13["whitespace"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵproperty"]("ngIf", errors_r13["address"]);
  }
}
function HomeTransferPage_div_34_div_1_span_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵi18n"](1, 42);
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵelementEnd"]();
  }
}
function HomeTransferPage_div_34_div_1_span_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵi18n"](1, 43);
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵelementEnd"]();
  }
}
function HomeTransferPage_div_34_div_1_span_3_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const errors_r17 = _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵnextContext"](2).ngIf;
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵtextInterpolate1"](" ", errors_r17["amount"], " ");
  }
}
function HomeTransferPage_div_34_div_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵtemplate"](1, HomeTransferPage_div_34_div_1_span_1_Template, 2, 0, "span", 25)(2, HomeTransferPage_div_34_div_1_span_2_Template, 2, 0, "span", 25)(3, HomeTransferPage_div_34_div_1_span_3_Template, 2, 1, "span", 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const errors_r17 = _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵnextContext"]().ngIf;
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵproperty"]("ngIf", errors_r17["required"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵproperty"]("ngIf", errors_r17["pattern"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵproperty"]("ngIf", errors_r17["amount"]);
  }
}
function HomeTransferPage_div_34_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵelementStart"](0, "div", 41);
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵtemplate"](1, HomeTransferPage_div_34_div_1_Template, 4, 3, "div", 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const errors_r17 = ctx.ngIf;
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵproperty"]("ngIf", errors_r17);
  }
}
function HomeTransferPage_ng_container_40_ng_template_7_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵi18n"](1, 50);
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const error_r25 = ctx.$error;
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵi18nExp"](error_r25.requiredLength);
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵi18nApply"](1);
  }
}
const _c27 = a0 => ({
  "text-error": a0
});
function HomeTransferPage_ng_container_40_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵelementStart"](1, "fieldset")(2, "legend", 6)(3, "div", 44);
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵi18n"](4, 45);
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵpipe"](5, "errors");
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵelementStart"](6, "div", 46);
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵtemplate"](7, HomeTransferPage_ng_container_40_ng_template_7_Template, 2, 1, "ng-template", 47);
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵelementStart"](8, "div", 48);
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵelement"](9, "input", 49);
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵpureFunction1"](4, _c27, _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵpipeBind1"](5, 2, ctx_r3.memo)));
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵproperty"]("wSwitchErrors", ctx_r3.memo);
  }
}
function HomeTransferPage_Conditional_43_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵelementStart"](0, "div", 51)(1, "span", 52)(2, "div", 53);
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵpipe"](4, "amountFixed");
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵelementStart"](5, "div", 54);
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵtext"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵtextInterpolate1"](" ", +ctx_r4.bitcoinUseFee > 0 ? _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵpipeBind2"](4, 2, ctx_r4.bitcoinUseFee, ctx_r4.decimals) : "----", " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵtextInterpolate"](ctx_r4.chainSymbol);
  }
}
function HomeTransferPage_div_44_Template(rf, ctx) {
  if (rf & 1) {
    const _r27 = _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵelementStart"](0, "div", 51)(1, "span", 52);
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵelementContainerStart"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵi18n"](3, 55);
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵelementContainerEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵelementStart"](4, "span", 56);
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵlistener"]("click", function HomeTransferPage_div_44_Template_span_click_4_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵrestoreView"](_r27);
      const ctx_r26 = _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵresetView"](ctx_r26.showTronFeeTips());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵtext"](5, " ? ");
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵelementEnd"]()()();
  }
}
const _c30 = (a0, a1) => ({
  activeBorderStyle: a0,
  borderStyle: a1
});
const _c31 = () => ({
  removeZero: true
});
function HomeTransferPage_ng_container_46_ng_container_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r31 = _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵelementStart"](1, "div", 59);
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵlistener"]("click", function HomeTransferPage_ng_container_46_ng_container_2_Template_div_click_1_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵrestoreView"](_r31);
      const item_r29 = restoredCtx.$implicit;
      const ctx_r30 = _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵresetView"](ctx_r30.onEthFeeClick(item_r29));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵelementStart"](2, "div", 60);
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵelementStart"](4, "div", 61);
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵtext"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵelementStart"](6, "div", 62);
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵtext"](7);
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵpipe"](8, "amountFixed");
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const item_r29 = ctx.$implicit;
    const ctx_r28 = _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵpureFunction2"](9, _c30, item_r29.activeFlag, !item_r29.activeFlag));
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵtextInterpolate1"](" ", item_r29.title, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵtextInterpolate1"](" ", item_r29.time, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵtextInterpolate2"](" ", "(\u2248" + _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵpipeBind3"](8, 5, item_r29.fee, ctx_r28.chainSymbolDecimals, _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵpureFunction0"](12, _c31)) + ") ", " ", ctx_r28.chainSymbol, " ");
  }
}
function HomeTransferPage_ng_container_46_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵelementStart"](1, "div", 57);
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵtemplate"](2, HomeTransferPage_ng_container_46_ng_container_2_Template, 9, 13, "ng-container", 58);
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const ctx_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵproperty"]("ngForOf", ctx_r6.bscFeeArr);
  }
}
function HomeTransferPage_fieldset_47_Template(rf, ctx) {
  if (rf & 1) {
    const _r33 = _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵelementStart"](0, "fieldset")(1, "button", 63);
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵlistener"]("click", function HomeTransferPage_fieldset_47_Template_button_click_1_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵrestoreView"](_r33);
      const ctx_r32 = _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵresetView"](ctx_r32.startChangeBioforestChainFee());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵelementStart"](2, "div", 53);
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵpipe"](4, "amountFixed");
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵelementStart"](5, "div", 54);
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵtext"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const ctx_r7 = _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵpipeBind2"](4, 2, ctx_r7.bioforestUseFee, ctx_r7.decimals), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵtextInterpolate"](ctx_r7.chainSymbol);
  }
}
function HomeTransferPage_common_bottom_sheet_53_ng_template_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r37 = _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵelementStart"](0, "w-home-payment-details-page", 65);
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵlistener"]("returnValue$", function HomeTransferPage_common_bottom_sheet_53_ng_template_1_Template_w_home_payment_details_page_returnValue__0_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵrestoreView"](_r37);
      const ctx_r36 = _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵresetView"](ctx_r36.paymenDetailOutput$.next($event));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const data_r34 = _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵnextContext"]().ngIf;
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵproperty"]("dataInfo", data_r34);
  }
}
function HomeTransferPage_common_bottom_sheet_53_Template(rf, ctx) {
  if (rf & 1) {
    const _r40 = _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵelementStart"](0, "common-bottom-sheet", 64);
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵlistener"]("isOpenChange", function HomeTransferPage_common_bottom_sheet_53_Template_common_bottom_sheet_isOpenChange_0_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵrestoreView"](_r40);
      const ctx_r39 = _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵresetView"]($event || (ctx_r39.paymentDetailInput = undefined));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵtemplate"](1, HomeTransferPage_common_bottom_sheet_53_ng_template_1_Template, 1, 1, "ng-template");
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵproperty"]("disableClose", true)("isOpen", true)("panelClass", "payment-details-sheet-panel");
  }
}
function HomeTransferPage_ng_template_55_Template(rf, ctx) {
  if (rf & 1) {
    const _r43 = _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵelementStart"](0, "common-card", 66, 67)(2, "div", 68)(3, "ol")(4, "li")(5, "p");
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵi18n"](6, 69);
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵelementStart"](7, "li")(8, "p");
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵi18n"](9, 70);
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵelementEnd"]()()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵelementStart"](10, "button", 71);
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵlistener"]("click", function HomeTransferPage_ng_template_55_Template_button_click_10_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵrestoreView"](_r43);
      const _r41 = _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵreference"](1);
      return _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵresetView"](_r41.finally());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵi18n"](11, 72);
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵelementEnd"]()();
  }
}
function HomeTransferPage_ng_template_57_ng_template_7_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵi18n"](1, 82);
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵelementContainerEnd"]();
  }
}
function HomeTransferPage_ng_template_57_Template(rf, ctx) {
  if (rf & 1) {
    const _r49 = _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵelementStart"](0, "common-card", 73, 74);
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵlistener"]("returnValue$", function HomeTransferPage_ng_template_57_Template_common_card_returnValue__0_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵrestoreView"](_r49);
      const ctx_r48 = _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵresetView"](ctx_r48.confirmChangeBioforestChainFee($event));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵelementStart"](2, "div", 75);
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵelement"](3, "input", 76, 77);
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵpipe"](5, "amountFixed");
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵelementStart"](6, "div", 46);
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵtemplate"](7, HomeTransferPage_ng_template_57_ng_template_7_Template, 2, 0, "ng-template", 78);
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵelementStart"](8, "blockquote", 79);
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵi18n"](9, 80);
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵpipe"](10, "amountFixed");
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵelement"](11, "common-confirm-footer", 81);
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r10 = _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵproperty"]("defaultValue", _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵpipeBind2"](5, 4, ctx_r10.bioforestChainFee.value, ctx_r10.decimals))("formControl", ctx_r10.bioforestChainFee);
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵproperty"]("wSwitchErrors", ctx_r10.bioforestChainFee);
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵi18nExp"](_angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵpipeBind2"](10, 7, ctx_r10.bioforestDefaultFee, ctx_r10.decimals));
    _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵi18nApply"](9);
  }
}
/**
 *  转账页面
 */
class HomeTransferPage extends _modules_page_module__WEBPACK_IMPORTED_MODULE_19__.CommonPageBase {
  constructor() {
    var _this;
    /** 页面返回值的类型 */
    super(...arguments);
    _this = this;
    this.returnValue$ = new _bnqkl_framework_core__WEBPACK_IMPORTED_MODULE_3__.PageReturnValue();
    /** 页面试图 */
    this._viewContainerRef = (0,_angular_core__WEBPACK_IMPORTED_MODULE_39__.inject)(_angular_core__WEBPACK_IMPORTED_MODULE_39__.ViewContainerRef);
    /** 缓存tron地址激活状态 */
    this._saveTronAddressNotActive = false;
    /** 监听页面视图dom的属性值变更 */
    this._attrListener = new MutationObserver(() => {
      const hidden = !!this.homeTransferPageDom.getAttribute('aria-hidden');
      if (hidden) {
        /// 隐藏的说明去了别的页面
        this._saveTronAddressNotActive = this.tronAddressNotActive;
        this.tronAddressNotActive = false;
      } else {
        /// 返回页面了
        this.tronAddressNotActive = this._saveTronAddressNotActive;
      }
    });
    /** 是否是移动端 */
    this.isMobile = (0,_helpers_utils__WEBPACK_IMPORTED_MODULE_24__.isMobile)();
    /** 表单验证服务 */
    this.validators = new _bnqkl_framework_controllers__WEBPACK_IMPORTED_MODULE_2__.FormValidatorsController(this);
    /** 收款地址 */
    this.address = new _angular_forms__WEBPACK_IMPORTED_MODULE_40__.FormControl('', {
      nonNullable: true,
      validators: [() => {
        // 初始化状态
        this.tronAddressNotActive = false;
        return null;
      }, _angular_forms__WEBPACK_IMPORTED_MODULE_40__.Validators.required, this.validators.whitespace, this.validators.trimRequired],
      asyncValidators: [( /*#__PURE__*/function () {
        var _ref = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (control) {
          /// 有其它错误了
          if (control.errors) {
            return null;
          }
          try {
            var _this$activeWallet;
            const address = control.value;
            if (control.value === ((_this$activeWallet = _this.activeWallet) === null || _this$activeWallet === void 0 ? void 0 : _this$activeWallet.address)) {
              throw new Error("Receive cannot be the same");
            }
            /// 检查地址格式
            if ((yield _this.chainApiService.isAddress(address)) === false) {
              // 地址格式错误
              throw new Error("Incorrect Wallet Address");
            }
            /// 判断波场未激活提示，这个跟转账逻辑无关联，所以不用await 触发就行
            _this._checkTronAddressNotActive(address);
          } catch (err) {
            return {
              address: err instanceof Error ? err.message : String(err)
            };
          }
          if (_this.isBitcoinChain) {
            _this.amount.updateValueAndValidity();
          }
          return null;
        });
        return function (_x) {
          return _ref.apply(this, arguments);
        };
      }())]
    });
    /** 转账数量 */
    this.amount = new _angular_forms__WEBPACK_IMPORTED_MODULE_40__.FormControl('', {
      nonNullable: true,
      validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_40__.Validators.required, this.validators.whitespace, control => {
        /// 矫正输入
        const inputValue = String(control.value);
        const value = (0,_bnqkl_wallet_base_tools__WEBPACK_IMPORTED_MODULE_17__.getValueByDecimalsRange)(inputValue, this.decimals);
        if (value !== inputValue) {
          control.setValue(value);
        }
        return null;
      }],
      asyncValidators: [( /*#__PURE__*/function () {
        var _ref2 = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (control) {
          if (control.errors) {
            return null;
          }
          try {
            if (+control.value === 0) {
              throw new Error("Enter a valid number");
            } else {
              yield _this._checkAmount(control.value);
            }
          } catch (err) {
            return {
              amount: err instanceof Error ? err.message : String(err)
            };
          }
          return null;
        });
        return function (_x2) {
          return _ref2.apply(this, arguments);
        };
      }()), ( /*#__PURE__*/function () {
        var _ref3 = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (control) {
          if (_this.isBitcoinChain && (_this.address.valid || _this.address.value) && isNaN(control.value) === false) {
            const bitcoinService = _this.chainApiService;
            const amount = _this.chainV2Service.getPrecisionInteger(control.value, _this.decimals);
            if (BigInt(amount) > BigInt(0)) {
              if (_this.utxos.length <= 0) {
                yield _this.checkBitcoinUtxos();
              }
              const addressInfo = yield _this.walletDataStorageV2Service.getChainAddressInfo(_this.activeWallet.addressKey);
              const res = yield bitcoinService.createTransaction({
                privateKey: addressInfo.privateKey,
                utxos: _this.utxos,
                assetType: _this.assetType,
                sendAddress: addressInfo.address,
                receiveAddress: _this.address.value,
                amount
              });
              _this.bitcoinUseFee = res.fee;
            }
          }
          return null;
        });
        return function (_x3) {
          return _ref3.apply(this, arguments);
        };
      }())]
    });
    /** 附言 */
    this.memo = new _angular_forms__WEBPACK_IMPORTED_MODULE_40__.FormControl('', {
      nonNullable: true,
      validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_40__.Validators.maxLength(24)]
    });
    /** 钱包支持的链 */
    this.CHAIN_NAME = _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_12__.CHAIN_NAME;
    /** 代币类型,控制要展示的页面格式 */
    this.assetType = '';
    /** 代币精确度 */
    this.decimals = 0;
    /** 最小手续费,默认1.5Gwei */
    this._maxPriorityFeePerGas = '1500000000';
    /** bsc链所选手续费 */
    this._bscGasInfo = {
      hasInit: false,
      selectFee: '0',
      gas: 0,
      gasPrice: 0,
      multiples: [10, 15]
    };
    /** 钱包币种余额 */
    this.assetBalance = '0';
    /** 地址的资产信息 */
    this.currentAddressAssets = {};
    /** 链的主权益 */
    this.chainSymbol = '';
    /** 链的主权益精确度 */
    this.chainSymbolDecimals = 0;
    /** BSC矿工费模块（eth binance） */
    this.bscFeeArr = [{
      title: "Fastest",
      time: "Probably within 15 seconds",
      fee: '---',
      activeFlag: false,
      multiples: [10, 20] // 2
    }, {
      title: "Standard",
      time: "Could be within 30 seconds",
      fee: '---',
      activeFlag: true,
      multiples: [10, 15] // 1.5
    }, {
      title: "Slowest",
      time: "Estimated 1 minute",
      fee: '---',
      activeFlag: false,
      multiples: [10, 10] // 1
    }];
    /** 生物链林--链默认手续费 */
    this.bioforestDefaultFee = '0';
    /** 生物链林--输入的手续费 */
    this.bioforestChainFee = new _angular_forms__WEBPACK_IMPORTED_MODULE_40__.FormControl('0', {
      nonNullable: true,
      validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_40__.Validators.required, this.validators.whitespace, control => {
        /// 这个校验器用于输入矫正
        if (this.decimals > 0) {
          var _this$_bioforestChain, _this$_bioforestChain2;
          const decimals = this.decimals;
          /// 使用this._bioforestChainFeeInput?.value 可以得到0.0000000，而用control.value得到 0
          const inputValue = (_this$_bioforestChain = (_this$_bioforestChain2 = this._bioforestChainFeeInput) === null || _this$_bioforestChain2 === void 0 ? void 0 : _this$_bioforestChain2.value) !== null && _this$_bioforestChain !== void 0 ? _this$_bioforestChain : control.value;
          const newValue = (0,_bnqkl_wallet_base_tools__WEBPACK_IMPORTED_MODULE_17__.getValueByDecimalsRange)(inputValue, decimals);
          if (newValue !== String(inputValue)) {
            control.setValue(newValue);
            this.cdRef.detectChanges();
          }
        }
        return null;
      }],
      asyncValidators: [( /*#__PURE__*/function () {
        var _ref4 = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (control) {
          if (_this.chainV2Service) {
            var _this$_bioforestChain3, _this$_bioforestChain4;
            const inputValue = (_this$_bioforestChain3 = (_this$_bioforestChain4 = _this._bioforestChainFeeInput) === null || _this$_bioforestChain4 === void 0 ? void 0 : _this$_bioforestChain4.value) !== null && _this$_bioforestChain3 !== void 0 ? _this$_bioforestChain3 : control.value;
            const value = yield _this.chainApiService.toUnit(inputValue);
            if (BigInt(_this.bioforestDefaultFee) > BigInt(value)) {
              return {
                lessThenDefaultFee: _this.bioforestDefaultFee
              };
            }
          }
          return null;
        });
        return function (_x4) {
          return _ref4.apply(this, arguments);
        };
      }())]
    });
    /** 生物链林--使用的手续费 */
    this._bioforestUseFee = this.bioforestChainFee.value;
    /** 修改生物链林手续费 对话框 控制器 */
    this.dialog_changeBioforestChainFee = {
      is_open: false
    };
    /** 要提交的表单与复合验证 */
    this.form = new _angular_forms__WEBPACK_IMPORTED_MODULE_40__.FormGroup({
      address: this.address,
      amount: this.amount,
      memo: this.memo
    }, {
      validators: [],
      asyncValidators: []
    });
    /** TRON链的地址是否激活
     * @FIXME 现在只是针对TRX 别的链的话看情况一起整合
     */
    this.tronAddressNotActive = false;
    this.tronAddressNotActiveTips = "The address is not active, 1.1 TRX will be consumed to activate the address";
    /** 钱包链服务 */
    this.chainV2Service = (0,_angular_core__WEBPACK_IMPORTED_MODULE_39__.inject)(_bnqkl_wallet_base_services_wallet_chain__WEBPACK_IMPORTED_MODULE_11__.ChainV2Service);
    /** 存储服务 */
    this.walletDataStorageV2Service = (0,_angular_core__WEBPACK_IMPORTED_MODULE_39__.inject)(_bnqkl_wallet_base_services_wallet_wallet_data_storage__WEBPACK_IMPORTED_MODULE_15__.WalletDataStorageV2Service);
    /** 波场服务 */
    this._tronService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_39__.inject)(_bnqkl_wallet_base_services_wallet_tron__WEBPACK_IMPORTED_MODULE_14__.TronService);
    /**
     * 跳转到选择币种界面
     */
    this.homeSelectTokenPageReturnController = new _bnqkl_framework_controllers__WEBPACK_IMPORTED_MODULE_2__.PageReturnController(this, _home_select_token_home_select_token_component__WEBPACK_IMPORTED_MODULE_23__.HomeSelectTokenPage);
    /** 当前正在处理的交易信息，通过多个步骤逐步完善该对象 */
    this._state = {};
    /** 转账数据的提交 */
    this.onSubmit = (0,_bnqkl_framework_helpers__WEBPACK_IMPORTED_MODULE_4__.$singleton)( /*#__PURE__*/(0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      if (_this.isBitcoinChain && _this.utxos.length <= 0) {
        _bnqkl_framework_plugins_toast__WEBPACK_IMPORTED_MODULE_8__.Toast.show("No possible utxo obtained");
        return;
      }
      /// 判断网络状态
      const online = _bnqkl_framework_plugins_network__WEBPACK_IMPORTED_MODULE_7__.Network.getOnlineStatus$().value;
      if (online === false) {
        _bnqkl_framework_plugins_toast__WEBPACK_IMPORTED_MODULE_8__.Toast.show("Network not connected");
        return;
      }
      const chain = _this.chain;
      const isBioforestChain = _this.isBioforestChain;
      try {
        /// 判断生物链林地址是否被冻结
        if (isBioforestChain) {
          const {
            isFreezed
          } = yield _this.walletDataStorageV2Service.getChainAddressInfo(_this.activeWallet.addressKey);
          if (isFreezed) {
            _bnqkl_framework_plugins_toast__WEBPACK_IMPORTED_MODULE_8__.Toast.show("The frozen address cannot be transferred");
            return;
          }
        }
        const addressInfo = yield _this.walletDataStorageV2Service.getChainAddressInfo(_this.activeWallet.addressKey);
        /// 判断是否短时间内发起过相同的交易
        try {
          const pendingList = yield _this.chainApiService.getAssetTypePendingTrans(addressInfo.address, _this.assetType, _this.decimals);
          const pendingTrs = pendingList.find(item => {
            let pendIngRecipientId = item.recipientId || '';
            let recipientId = _this.address.value;
            if (item.chain === _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_12__.CHAIN_NAME.Binance || item.chain === _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_12__.CHAIN_NAME.Ethereum) {
              pendIngRecipientId = pendIngRecipientId.toLowerCase();
              recipientId = recipientId.toLowerCase();
            }
            if (pendIngRecipientId !== recipientId) {
              return false;
            }
            if (_this.chainV2Service.isBioforestChainByChainName(item.chain)) {
              if (item.transaction.storageValue && item.transaction.storageValue === _this.assetType) {
                return item.transaction.asset.transferAsset.amount === _this.chainV2Service.getPrecisionInteger(_this.amount.value, _this.decimals);
              }
            }
            if ('type' in item && item.type === 0 && item.assetSymbol === _this.assetType) {
              return item.amount === _this.amount.value;
            }
            return false;
          });
          /// 10分钟内才进行
          if (pendingTrs && Number(pendingTrs.timestamp) + 1000 * 60 * 10 > Date.now()) {
            /// 有交易还得查下是否上链
            // const hasInBlock = await this.chainApiService.hasTransactionInBlockById(pendingTrs.signature);
            const confirmed = yield _this.confirm({
              headerTitle: "Hint",
              bodyMessage: "There is an identical transfer that has not arrived, can you wait for the confirmation of the transfer, or continue with a new transfer?",
              confirmText: "New Transfer",
              cancelText: "Cancel"
            });
            if (confirmed === false) {
              return;
            }
          }
        } catch (error) {
          _this.console.error('home-transfer submit get pending list:', error);
        }
        let amount = _this.amount.value;
        /// 判断手续费，tron已经在amount校验器判断这边只需判断eth跟binance
        if (chain === _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_12__.CHAIN_NAME.Binance || chain === _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_12__.CHAIN_NAME.Ethereum) {
          const item = _this.bscFeeArr.find(item => item.activeFlag);
          if (item === undefined) {
            // 没选择手续费 直接退出
            return;
          }
          if (BigInt(_this.currentAddressSymbolBalance) <= BigInt(item.fee)) {
            throw new Error("" + _this.chainSymbol + " is not enough to cover fees");
          }
          /// 更新gas信息确保最新
          yield _this.updateBscFeeArrInfo();
        } else if (isBioforestChain) {
          /// 不是主币种转账 只需判断主币种跟余额
          if (_this.assetType === _this.chainSymbol) {
            if (BigInt(_this.assetBalance) < BigInt(_this.bioforestUseFee)) {
              throw new Error("insufficient funds");
            }
          } else {
            if (BigInt(_this.currentAddressSymbolBalance) < BigInt(_this.bioforestUseFee)) {
              throw new Error("" + _this.chainSymbol + " is not enough to cover fees");
            }
          }
        } else if (chain === _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_12__.CHAIN_NAME.Bitcoin) {
          if (BigInt(_this.assetBalance) < BigInt(_this.bitcoinUseFee)) {
            throw new Error("insufficient funds");
          }
          const amountUnit = yield _this.chainApiService.toUnit(amount);
          if (BigInt(_this.assetBalance) !== BigInt(amountUnit) && BigInt(_this.assetBalance) < BigInt(_this.bitcoinUseFee) + BigInt(amountUnit)) {
            throw new Error("insufficient funds");
          }
        }
        if (chain === _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_12__.CHAIN_NAME.Tron && _this.tronAddressNotActive && _this.assetType === _this.chainSymbol) {
          // 余额 - 转出 需要大于1.1
          const diff_BI = BigInt(_this.currentAddressSymbolBalance) - BigInt(_this.assetType === _this.chainSymbol ? yield _this.chainApiService.toUnit(amount) : '0');
          if (diff_BI < BigInt(_this.chainV2Service.getPrecisionInteger('1.1', _this.decimals))) {
            amount = String(yield _this.chainApiService.fromUnit(_this.chainV2Service.getPrecisionInteger(amount, _this.decimals, _this.chainV2Service.getPrecisionInteger('-1.1', _this.decimals))));
          }
        }
        _this._state.addresInfo = addressInfo;
        const {
          address: sendAddress
        } = addressInfo;
        if (_this.isBitcoinChain) {
          var _iteratorAbruptCompletion = false;
          var _didIteratorError = false;
          var _iteratorError;
          try {
            for (var _iterator = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncIterator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(_this.utxos), _step; _iteratorAbruptCompletion = !(_step = yield _iterator.next()).done; _iteratorAbruptCompletion = false) {
              const item = _step.value;
              {
                if ((0,_bnqkl_framework_helpers__WEBPACK_IMPORTED_MODULE_4__.$isNoEmptyString)(item.txHex) === false) {
                  const tx = yield _this.chainApiService.getTxInfo(item.txid);
                  item.txHex = tx.hex;
                }
              }
            }
          } catch (err) {
            _didIteratorError = true;
            _iteratorError = err;
          } finally {
            try {
              if (_iteratorAbruptCompletion && _iterator.return != null) {
                yield _iterator.return();
              }
            } finally {
              if (_didIteratorError) {
                throw _iteratorError;
              }
            }
          }
        }
        let transactionInfo = yield _this.chainApiService.createTransaction({
          mainSecret: addressInfo.mnemonic,
          fee: _this.bioforestUseFee,
          privateKey: addressInfo.privateKey,
          sendAddress,
          receiveAddress: _this.address.value,
          assetType: _this.assetType,
          utxos: _this.utxos,
          /// 转余额精度不在createTransaction做，传入就是最小单位
          amount: _this.chainV2Service.getPrecisionInteger(amount, _this.decimals),
          maxPriorityFeePerGas: _this._maxPriorityFeePerGas,
          chainSymbol: _this.chainSymbol,
          gasLimit: _this._bscGasInfo.gas,
          gasPrice: (BigInt(_this._bscGasInfo.gasPrice) / BigInt(_this._bscGasInfo.multiples[0]) * BigInt(_this._bscGasInfo.multiples[1])).toString(),
          remark: _this.memo.value.trim() ? {
            postscript: _this.memo.value.trim()
          } : undefined,
          contractAddress: yield _this.chainV2Service.getContractAddressByAddressKey(_this.activeWallet.addressKey, _this.assetType)
        });
        _this._state.transactionInfo = transactionInfo;
        // 校验余额与精度
        const {
          gasLimit
        } = transactionInfo;
        let {
          fee,
          amount: unitAmount
        } = transactionInfo;
        /// 这边对eth跟binance进行数值判断,binance 返回 不带 maxFeePerGas
        let checkBsc = false;
        if (gasLimit) {
          checkBsc = yield _this._checkBscBalanceAndAccuracy(unitAmount);
          fee = _this._bscGasInfo.selectFee;
        }
        if (checkBsc || isBioforestChain || _this.chain === _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_12__.CHAIN_NAME.Tron) {
          /// 校验通过了，现在只需要判断 转出数量 == 余额的话 重新生成扣除手续费的交易体
          /** 由于输入框的是有精度最大限制，这边需要转化下余额 */
          const assetBalance = _this.chainV2Service.getPrecisionInteger(_bnqkl_framework_pipes__WEBPACK_IMPORTED_MODULE_5__.AmountFixedPipe.transform(_this.assetBalance, _this.decimals), _this.decimals);
          if (_this.assetType === _this.chainSymbol && unitAmount === assetBalance) {
            if (_this.chain === _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_12__.CHAIN_NAME.Tron) {
              /// tron是预估的，只能扩大下倍数了
              fee = (BigInt(fee) * 2n).toString();
            }
            /// 主币种，使用toUnit就行
            const oldAmount = yield _this.chainApiService.toUnit(amount);
            const newAmount = (BigInt(oldAmount) - BigInt(fee)).toString();
            unitAmount = newAmount;
            /// 转出全部，需扣除手续费 重新生成交易体
            transactionInfo = yield _this.chainApiService.createTransaction({
              mainSecret: addressInfo.mnemonic,
              fee: _this.bioforestUseFee,
              privateKey: addressInfo.privateKey,
              sendAddress,
              receiveAddress: _this.address.value,
              assetType: _this.assetType,
              amount: newAmount,
              gasLimit: _this._bscGasInfo.gas,
              gasPrice: (BigInt(_this._bscGasInfo.gasPrice) / BigInt(_this._bscGasInfo.multiples[0]) * BigInt(_this._bscGasInfo.multiples[1])).toString(),
              maxPriorityFeePerGas: _this._maxPriorityFeePerGas,
              remark: _this.memo.value.trim() ? {
                postscript: _this.memo.value.trim()
              } : undefined,
              contractAddress: yield _this.chainV2Service.getContractAddressByAddressKey(_this.activeWallet.addressKey, _this.assetType)
            });
          }
        }
        if (_this.isBitcoinChain) {
          const assetBalance = _this.chainV2Service.getPrecisionInteger(_bnqkl_framework_pipes__WEBPACK_IMPORTED_MODULE_5__.AmountFixedPipe.transform(_this.assetBalance, _this.decimals), _this.decimals);
          if (unitAmount === assetBalance) {
            /// 主币种，使用toUnit就行
            const oldAmount = yield _this.chainApiService.toUnit(amount);
            const newAmount = (BigInt(oldAmount) - BigInt(fee)).toString();
            unitAmount = newAmount;
          }
        }
        if (chain === _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_12__.CHAIN_NAME.Tron && _this.tronAddressNotActive) {
          fee = _this.chainV2Service.getPrecisionInteger('1.1', _this.decimals, fee);
        }
        /// 交易广播
        {
          var _yield$_this$chainApi;
          // const amount = await this.chainApiService.fromUnit(unitAmount).toString();
          // const unitAmount = await this.chainApiService.toUnit(amount) as string;
          transactionInfo.fee = fee;
          _this._state.addresInfo = addressInfo;
          _this._state.transactionInfo = transactionInfo;
          const {
            addressKey,
            symbol: coinSymbol
          } = _this.activeWallet;
          const password = _this.walletDataStorageV2Service.walletAppSettings.password;
          if (password === undefined) {
            throw new Error('walleter info defect');
          }
          const chain = _this.chain;
          const isBioforestChain = _this.isBioforestChain;
          _this.paymentDetailInput = {
            status: _pages_home_pages_home_payment_details_home_payment_details_component__WEBPACK_IMPORTED_MODULE_20__.PAYMENT_DETAILS_PAGE_STATUS.Details,
            receiveAddress: _this.address.value,
            senderAddress: addressInfo.address,
            assetType: _this.assetType,
            chain: chain,
            /** 显示值使用输入的值 */
            amount: unitAmount,
            fee: transactionInfo.fee,
            addressKey: addressKey,
            decimals: _this.decimals,
            password: password,
            symbol: coinSymbol,
            mnemonic: addressInfo.mnemonic,
            bioforestPasswordPublicKey: isBioforestChain ? yield (_yield$_this$chainApi = yield _this.chainApiService.getAddressInfo(addressInfo.address)) === null || _yield$_this$chainApi === void 0 ? void 0 : _yield$_this$chainApi.secondPublicKey : undefined
          };
        }
        /// 等待提交
        {
          const data = yield (0,rxjs__WEBPACK_IMPORTED_MODULE_41__.firstValueFrom)(_this.paymenDetailOutput$);
          if (data === false) {
            return;
          }
          try {
            if (_this.chain === _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_12__.CHAIN_NAME.Tron) {
              const _signTransaction = yield _this._tronBeforeBroadcast(addressInfo, unitAmount, transactionInfo.transaction, transactionInfo.fee);
              if (_signTransaction === undefined) {
                return;
              }
              transactionInfo.transaction = _signTransaction;
            }
            const broadcastOptions = transactionInfo.transaction;
            // 生物链林的链需要额外参数
            if (isBioforestChain) {
              const paysecretInfo = data.find(dataItem => chain === dataItem.chain);
              if (paysecretInfo === undefined) {
                /// 不应该出现这个情况
                _this.console.error(`Not find ${chain} paysecretInfo`, data);
                throw new Error(`Not find ${chain} paysecretInfo`);
              }
              if (typeof data !== 'boolean' && paysecretInfo.status !== _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_12__.PAYSECERT_CHECK_RESULT.FAIL) {
                transactionInfo = yield _this.chainApiService.createTransaction({
                  usePaySecretV1: paysecretInfo.status === _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_12__.PAYSECERT_CHECK_RESULT.OLD_SUCCESS,
                  paySecret: paysecretInfo.paysecret,
                  mainSecret: addressInfo.mnemonic,
                  fee: transactionInfo.fee,
                  privateKey: addressInfo.privateKey,
                  sendAddress: addressInfo.address,
                  receiveAddress: _this.address.value,
                  assetType: _this.assetType,
                  amount: transactionInfo.amount,
                  chainSymbol: _this.chainSymbol,
                  remark: _this.memo.value.trim() ? {
                    postscript: _this.memo.value.trim()
                  } : undefined,
                  contractAddress: yield _this.chainV2Service.getContractAddressByAddressKey(_this.activeWallet.addressKey, _this.assetType)
                });
              }
              yield _this.chainApiService.broadcast(transactionInfo.transaction);
            } else {
              yield _this.chainApiService.broadcast(broadcastOptions, {
                transType: _this.chainSymbol === _this.assetType ? _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_12__.TRANS_TYPE.COMMON : _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_12__.TRANS_TYPE.CONTRACT,
                from: addressInfo.address,
                to: _this.address.value,
                amount: unitAmount,
                fee: transactionInfo.fee || '',
                assetSymbol: _this.assetType
              });
            }
          } catch (err) {
            if (err instanceof _bnqkl_wallet_base_services_wallet_wallet_fetch__WEBPACK_IMPORTED_MODULE_16__.WalletLocalError) {
              _this._bioforestUseFee = String(err.minFee);
              _this.bioforestChainFee.setValue(String(err.minFee));
            }
            _bnqkl_framework_plugins_toast__WEBPACK_IMPORTED_MODULE_8__.Toast.show(err instanceof Error ? err.message : String(err));
            throw err;
          }
          // 清空表单
          _this.amount.setValue('');
          _this.address.setValue('');
          _this.form.reset();
          if (chain === _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_12__.CHAIN_NAME.Tron) {
            _this.tronAddressNotActive = false;
          }
          _bnqkl_framework_plugins_toast__WEBPACK_IMPORTED_MODULE_8__.Toast.show("Transaction sent successfully");
          const resData = {
            assetType: _this.assetType,
            decimals: _this.decimals,
            addressKey: _this.activeWallet.addressKey,
            chain: chain,
            fromTransaction: true
          };
          _this.returnValue$.next(resData);
          // 跳转到币种详情
          return _this.nav.routeBack('/mnemonic/home-token-details', resData, true);
        }
      } catch (err) {
        _bnqkl_framework_plugins_toast__WEBPACK_IMPORTED_MODULE_8__.Toast.show(err instanceof Error ? err.message : String(err));
        throw err;
      } finally {
        (chain === _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_12__.CHAIN_NAME.Binance || chain === _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_12__.CHAIN_NAME.Ethereum) && _this.updateBscFeeArrInfo();
      }
    }));
    /** 支付面板的输出 */
    this.paymenDetailOutput$ = new rxjs__WEBPACK_IMPORTED_MODULE_42__.Subject();
    /**
     * 波场手续费提示 对话框 控制器
     */
    this.dialog_tronFeeTips = {
      is_open: false
    };
    this.bitcoinUseFee = '0';
    /**
     * 扫码后触发弹窗
     */
    this.scannerPageReturnController = new _bnqkl_framework_controllers__WEBPACK_IMPORTED_MODULE_2__.PageReturnController(this, _pages_scanner_scanner_component__WEBPACK_IMPORTED_MODULE_21__.ScannerPage, true);
    /**
     * 跳转到选择币种界面
     */
    this.addressBookPageReturnController = new _bnqkl_framework_controllers__WEBPACK_IMPORTED_MODULE_2__.PageReturnController(this, _mime_pages_address_book_address_book_component__WEBPACK_IMPORTED_MODULE_22__.AddressBookPage);
    this.utxos = [];
  }
  /** 输入框链提示语 */
  get enterAddressPlaceholder() {
    return "Enter the address of " + this.chain + "";
  }
  /** 页面视图DOM */
  get homeTransferPageDom() {
    return this._viewContainerRef.element.nativeElement;
  }
  /** 绑定观察 */
  addObserverDom() {
    this._attrListener.observe(this.homeTransferPageDom, {
      attributes: true,
      attributeFilter: ['aria-hidden']
    });
  }
  /** 终止观察 */
  disconnectObserverDom() {
    this._attrListener.disconnect();
  }
  /** 获取地址主代币余额 */
  get currentAddressSymbolBalance() {
    return this.currentAddressAssets[this.chainSymbol] || '0';
  }
  /** 生物链林 手续费输入框DOM */
  get _bioforestChainFeeInput() {
    var _this$_bioforestChain5;
    return (_this$_bioforestChain5 = this._bioforestChainFeeInputRef) === null || _this$_bioforestChain5 === void 0 ? void 0 : _this$_bioforestChain5.nativeElement;
  }
  get bioforestUseFee() {
    return this._bioforestUseFee;
  }
  /** 开始修改生物链林手续费 */
  startChangeBioforestChainFee() {
    var _this2 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this2.bioforestChainFee.setValue(String(yield _this2.chainApiService.fromUnit(_this2.bioforestUseFee)));
      _this2.dialog_changeBioforestChainFee.is_open = true;
    })();
  }
  /** 确认修改生物链林手续费 */
  confirmChangeBioforestChainFee(confirm) {
    var _this3 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      if (confirm) {
        var _this3$_bioforestChai, _this3$_bioforestChai2;
        _this3._bioforestUseFee = String(yield _this3.chainApiService.toUnit(String((_this3$_bioforestChai = (_this3$_bioforestChai2 = _this3._bioforestChainFeeInput) === null || _this3$_bioforestChai2 === void 0 ? void 0 : _this3$_bioforestChai2.value) !== null && _this3$_bioforestChai !== void 0 ? _this3$_bioforestChai : _this3.bioforestChainFee.value)));
      }
    })();
  }
  /**
   * 检查地址
   */
  _checkTronAddressNotActive(address) {
    var _this4 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      /// TRON -> 1.检查地址是否激活  2.检查是否正确格式
      if (_this4.chain == _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_12__.CHAIN_NAME.Tron) {
        const tronService = _this4.injectorForceGet(_bnqkl_wallet_base_services_wallet_tron__WEBPACK_IMPORTED_MODULE_14__.TronService);
        if ((yield tronService.isAddressActive(address)) === false) {
          /// 确保是当前输入地址
          if (address === _this4.address.value) {
            // 地址未激活
            _this4.tronAddressNotActive = true;
            _this4.cdRef.detectChanges();
          }
        }
        return null;
      }
    })();
  }
  /**
   * 余额的校验
   * 这里只能校验输入的数量跟余额判断,以及一些确定性扣费：TRON的激活地址
   * 如果需要判断手续费，需要到对应链的提交函数进行
   */
  _checkAmount(amount) {
    var _this5 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const realAmount = _this5.chainV2Service.getPrecisionInteger(amount, _this5.decimals);
      /** 本次转移的数量 */
      const realAmount_BI = BigInt(_this5.chainV2Service.getMaxDecimalsRangeAmount(realAmount, _this5.decimals));
      /** 地址所拥有的数量 */
      const assetBalance_BI = BigInt(_this5.chainV2Service.getMaxDecimalsRangeAmount(_this5.assetBalance, _this5.decimals));
      /// 通用判断, 转移数量不可以 大于 余额
      if (realAmount_BI > assetBalance_BI) {
        throw new Error("Transfer quantity cannot be greater than balance");
      }
      /// 不同链有不同的判断规则
      if (_this5.chain === _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_12__.CHAIN_NAME.Tron) {
        // 波场地址未激活情况下，需要额外付出1.1TRX
        if (_this5.tronAddressNotActive && _this5.chainSymbol === _this5.assetType) {
          if (assetBalance_BI < BigInt(_this5.chainV2Service.getPrecisionInteger('1.1', _this5.decimals))) {
            // 地址未激活，扣除1.1TRX后无法满足本次转账
            throw new Error("The address is not activated, and the TRX balance does not meet the transfer fee");
          }
        }
      }
      return true;
    })();
  }
  /** 链的接口服务 */
  get chainApiService() {
    return this.chainV2Service.getChainService(this.activeWallet.chain);
  }
  /** 获取初始化参数 */
  initChainInfo() {
    var _this6 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const data = _this6._data;
      const lastWalletActivate = _this6.walletDataStorageV2Service.getLastWalletActivate();
      if (lastWalletActivate === undefined) {
        _this6.nav.back();
        throw new Error('not find mainWalleter.');
      }
      _this6.activeWallet = lastWalletActivate;
      const addressInfo = yield _this6.walletDataStorageV2Service.getChainAddressInfo(_this6.activeWallet.addressKey);
      _this6.console.log(_this6.activeWallet, '当前激活钱包信息', addressInfo);
      /// 选择资产类型
      const assetInfo = addressInfo.assets.find(item => item.assetType === data.assetType) || addressInfo.assets[0];
      _this6.chain = _this6.activeWallet.chain;
      _this6.assetType = assetInfo.assetType;
      _this6.assetBalance = assetInfo.amount || '0';
      _this6.decimals = assetInfo.decimals;
      const chain = _this6.chain;
      if (data.QR_address) {
        _this6.address.setValue(data.QR_address);
        _this6.address.markAsDirty();
        _this6.address.updateValueAndValidity();
      }
      if (_this6.isBioforestChain) {
        _this6._bioforestUseFee = _this6.bioforestDefaultFee = yield _this6.chainApiService.getTransferTransactionMinFee();
        _this6.bioforestChainFee.setValue(String(yield _this6.chainApiService.fromUnit(_this6.bioforestDefaultFee)));
      }
      _this6.updateAssetTypeBalance$();
      const chainInfo = _this6.chainV2Service.getChainInfo(chain);
      _this6.chainSymbol = chainInfo.symbol;
      _this6.chainSymbolDecimals = chainInfo.decimals;
      _this6.updateBscFeeArrInfo();
      _this6.checkBitcoinUtxos();
    })();
  }
  updateBscFeeArrInfo() {
    var _this7 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const chain = _this7.chain;
      /// 看下是否为BSC链，需要获取对应gas信息
      if (chain === _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_12__.CHAIN_NAME.Binance) {
        const binanceService = _this7.injectorForceGet(_bnqkl_wallet_base_services_wallet_binance__WEBPACK_IMPORTED_MODULE_10__.BinanceService);
        // 如果已经初始化一次，就不需要重新初始化赋值
        if (_this7.bscFeeArr.some(feeOption => feeOption.fee === '---')) {
          /// 先设置默认gas跟gasPrice, 网络请求有延迟
          const gas = _this7._bscGasInfo.hasInit ? _this7._bscGasInfo.gas : _this7._bscGasInfo.gas = _this7.assetType === _this7.chainSymbol ? 21000 : 210000;
          const gasPrice = _this7._bscGasInfo.hasInit ? _this7._bscGasInfo.gasPrice : _this7._bscGasInfo.gasPrice = _environments_index__WEBPACK_IMPORTED_MODULE_18__.environment.binanceGasPrice;
          _this7.bscFeeArr.forEach(item => {
            item.fee = (BigInt(gas) * BigInt(gasPrice) / BigInt(item.multiples[0]) * BigInt(item.multiples[1])).toString();
          });
          _this7.cdRef.detectChanges();
        }
        const gasInfo = yield binanceService.getGasInfo();
        const newGasPrice = _this7._bscGasInfo.gasPrice = yield binanceService.getGasPrice();
        const newGas = _this7._bscGasInfo.gas = _this7.assetType === _this7.chainSymbol ? gasInfo.generalGas : gasInfo.contractGas;
        _this7.bscFeeArr.forEach(item => {
          item.fee = (BigInt(newGas) * BigInt(newGasPrice) / BigInt(item.multiples[0]) * BigInt(item.multiples[1])).toString();
        });
      } else if (chain === _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_12__.CHAIN_NAME.Ethereum) {
        const ethereumService = _this7.injectorForceGet(_bnqkl_wallet_base_services_wallet_ethereum__WEBPACK_IMPORTED_MODULE_13__.EthereumService);
        const maxPriorityFeePerGas = '1500000000';
        // 如果已经初始化一次，就不需要重新初始化赋值
        if (_this7.bscFeeArr.some(feeOption => feeOption.fee === '---')) {
          /// 先设置默认gas跟gasPrice, 网络请求有延迟
          const gasLimit = _this7.assetType === _this7.chainSymbol ? '21000' : '210000';
          const gasPrice = _environments_index__WEBPACK_IMPORTED_MODULE_18__.environment.binanceGasPrice;
          _this7.bscFeeArr.forEach(item => {
            item.fee = ((BigInt(gasPrice) * BigInt(3) / BigInt(2) + BigInt(maxPriorityFeePerGas) / BigInt(item.multiples[0]) * BigInt(item.multiples[1])) * BigInt(gasLimit)).toString();
            if (item.activeFlag) {
              _this7._bscGasInfo.selectFee = item.fee;
            }
          });
          _this7.cdRef.detectChanges();
        }
        const gasInfo = yield ethereumService.getGasInfo();
        const newGasPrice = yield ethereumService.getGasPrice();
        /// 合約 還是 主幣 的手續費
        const newGasLimit = _this7.assetType === _this7.chainSymbol ? gasInfo.generalGas : gasInfo.contractGas;
        _this7.bscFeeArr.forEach(item => {
          item.fee = ((BigInt(newGasPrice) * BigInt(2) + BigInt(maxPriorityFeePerGas) / BigInt(item.multiples[0]) * BigInt(item.multiples[1])) * BigInt(newGasLimit)).toString();
        });
      }
      _this7.bscFeeArr.find(item => {
        if (item.activeFlag) {
          _this7._bscGasInfo.selectFee = item.fee;
          _this7._bscGasInfo.multiples = item.multiples;
        }
        return item.activeFlag;
      });
      _this7._bscGasInfo.hasInit = true;
      _this7.cdRef.detectChanges();
    })();
  }
  /** 监听余额的变动 */
  updateAssetTypeBalance$() {
    this.assetTypeBalance$ = this.chainV2Service.getChainBalanceSubject(this.chain).asObservable().pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_43__.map)(data => {
      const assets = data[this.activeWallet.address] || {};
      this.currentAddressAssets = assets;
      const newBalance = assets[this.assetType] || '0';
      if (this.assetBalance !== newBalance) {
        this.assetBalance = newBalance;
        this.checkBitcoinUtxos();
      }
      return this.assetBalance;
    }));
    this.cdRef.detectChanges();
  }
  /** 选择ETH矿工费时的点击事件 */
  onEthFeeClick(event) {
    this.bscFeeArr.forEach(item => {
      if (item.title === event.title) {
        this._maxPriorityFeePerGas = (BigInt(1000000000) / BigInt(item.multiples[0]) * BigInt(item.multiples[1])).toString();
        this._bscGasInfo.selectFee = item.fee;
        this._bscGasInfo.multiples = item.multiples;
        item.activeFlag = true;
      } else {
        item.activeFlag = false;
      }
    });
  }
  /** 点击all时填入全部资产 */
  fullAssets() {
    var _this8 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this8.amount.setValue(_bnqkl_framework_pipes__WEBPACK_IMPORTED_MODULE_5__.AmountFixedPipe.transform(_this8.assetBalance, _this8.decimals));
    })();
  }
  /** 跳转到资产选择页 */
  goSelectAsset() {
    this.nav.routeTo('/mnemonic/home-select-token', {
      addressKey: this.activeWallet.addressKey,
      activeAssetType: this.assetType,
      chain: this.chain,
      chainSymbol: this.chainSymbol
    });
  }
  /**
   * 接收选择到的币种 & 接收选择的地址
   */
  watchToPageReturn() {
    this.homeSelectTokenPageReturnController.pageReturn$.subscribe(data => {
      this.assetType = data.assetType;
      this.assetBalance = data.amount || '';
      this.decimals = data.decimals;
      this.amount.setValue('');
      this.updateAssetTypeBalance$();
      this.updateBscFeeArrInfo();
    });
    this.addressBookPageReturnController.pageReturn$.subscribe(data => {
      this.address.setValue(data.selectAddress);
      this.address.markAsDirty();
      this.address.updateValueAndValidity();
    });
  }
  /** 校验bsc余额与精度 */
  _checkBscBalanceAndAccuracy(amount) {
    var _this9 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      // 判断余额够不够
      let isInsufficient_BI = BigInt(_this9.currentAddressSymbolBalance) - BigInt(_this9._bscGasInfo.selectFee);
      // 是否满足转出数量, 由于最大显示的精度是8，所以这边转2次确保显示值跟输入值是一致的
      const chainSymbolBalance = _this9.chainV2Service.getPrecisionInteger(_bnqkl_framework_pipes__WEBPACK_IMPORTED_MODULE_5__.AmountFixedPipe.transform(_this9.assetBalance, _this9.decimals), _this9.decimals);
      const hasAll = chainSymbolBalance === amount;
      if (hasAll === false) {
        isInsufficient_BI = isInsufficient_BI - BigInt(_this9.assetType !== _this9.chainSymbol ? '0' : amount);
      }
      if (isInsufficient_BI < 0) {
        throw new Error("insufficient funds");
      }
      /// 转化最大精度范围内的值
      const isInsufficient_maxDecimalsRang = _this9.chainV2Service.getMaxDecimalsRangeAmount(isInsufficient_BI.toString(), _this9.decimals);
      if (BigInt(isInsufficient_maxDecimalsRang) < BigInt(0)) {
        throw new Error("insufficient funds");
      }
      return true;
    })();
  }
  /** 波场校验余额与手续费 */
  _tronBeforeBroadcast(addresInfo, amount, signTransaction, fee) {
    var _this10 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      /// 判断TRX余额是否可以支持手续费
      const chainSymbolBalance_BI = BigInt(_this10.currentAddressSymbolBalance);
      /**
       * tron手续费判断
       * 1、如果是合约的，需要消耗能量1~10TRX或者更多都有可能，目前写需要至少10TRX在地址
       * 2、如果是转账TRX，
       *    1） 判断剩余带宽是否满足所需带宽
       *    2） 带宽不够，需要部分从所在amount扣除
       *    3） 没有带宽，全部从amount扣除
       */
      let showLessFeeTips = false;
      const fee_BI = BigInt(fee);
      /// 合约
      if (_this10.assetType !== _this10.chainSymbol) {
        if (fee_BI > chainSymbolBalance_BI) {
          showLessFeeTips = true;
        }
      } else if (_this10.tronAddressNotActive === false) {
        /// 主权益
        const tronService = _this10.injectorForceGet(_bnqkl_wallet_base_services_wallet_tron__WEBPACK_IMPORTED_MODULE_14__.TronService);
        /// 地址可用带宽转TRX
        const addressBandwidthToSun_BI = BigInt(yield tronService.getAddressBandwidth(addresInfo.address, true));
        if (addressBandwidthToSun_BI < fee_BI) {
          /// 带宽不足,需要使用trx进行扣除
          const surplus = chainSymbolBalance_BI - (fee_BI - addressBandwidthToSun_BI) - BigInt(amount);
          if (surplus < BigInt(0)) {
            showLessFeeTips = true;
          }
        }
      }
      /// 手续费过低提示弹窗
      if (showLessFeeTips) {
        const confirmed = yield _this10.confirm({
          bodyMessage: "At present, there is less TRX, and continued transfers may fail due to insufficient handling fees."
        });
        if (false === confirmed) {
          return;
        }
      }
      const opts = {
        sendAddress: addresInfo.address,
        receiveAddress: _this10.address.value,
        amount: amount
      };
      /// 判断交易是否过期
      const expiration = yield _this10.chainV2Service.checkTransactionExpiration(signTransaction, _this10.chain);
      if (expiration) {
        _this10.console.warn('This transfer has expired, please operate again');
        const trs = yield _this10.assetType !== _this10.chainSymbol ? _this10._tronService.createTRC20Transaction(opts, yield _this10.chainV2Service.getContractAddressByAddressKey(addresInfo.addressKey, _this10.assetType)) : _this10._tronService.createTrxTransaction(opts);
        signTransaction = yield _this10._tronService.sign(trs, addresInfo.privateKey);
      }
      return signTransaction;
    })();
  }
  /**
   * 波场手续费提示
   */
  showTronFeeTips() {
    this.dialog_tronFeeTips.is_open = true;
  }
  /**  是否是生物链林-链 */
  get isBioforestChain() {
    return this.chainV2Service.isBioforestChainByChainName(this.chain);
  }
  get isBitcoinChain() {
    return this.chain === _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_12__.CHAIN_NAME.Bitcoin;
  }
  /** 初始化页面监听 */
  watchPageReturn() {
    var _this11 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this11.scannerPageReturnController.pageReturn$.subscribe( /*#__PURE__*/function () {
        var _ref6 = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (data) {
          yield (0,_bnqkl_util_web_extends_promise__WEBPACK_IMPORTED_MODULE_9__.sleep)(350);
          const isString = typeof data === 'string';
          if (isString || data.protocal === _pages_scanner_scanner_component__WEBPACK_IMPORTED_MODULE_21__.QRCODE_PROTOCAL_TYPE.ADDRESS) {
            const address = isString ? data : data['address'];
            _this11.console.log('scan qrCore:', address);
            const isAddress = yield _this11.chainV2Service.getChainService(_this11.chain).isAddress(address);
            if (isAddress) {
              if (address === _this11.activeWallet.address) {
                _bnqkl_framework_plugins_toast__WEBPACK_IMPORTED_MODULE_8__.Toast.show("Receive cannot be the same");
                return;
              }
              _this11.address.setValue(address);
              _this11.cdRef.detectChanges();
              return;
            } else {
              _bnqkl_framework_plugins_toast__WEBPACK_IMPORTED_MODULE_8__.Toast.show("Scan results do not match address rules");
              return;
            }
          }
        });
        return function (_x5) {
          return _ref6.apply(this, arguments);
        };
      }());
    })();
  }
  /**
   * 跳转到扫一扫页面
   */
  routeToScanner() {
    // 暂时只提供QR_CODE
    this.nav.routeTo('scanner', {
      scanType: _bnqkl_framework_plugins_barcode_scanner__WEBPACK_IMPORTED_MODULE_6__.SUPPORTED_FORMAT.QR_CODE,
      cameraDirection: _bnqkl_framework_plugins_barcode_scanner__WEBPACK_IMPORTED_MODULE_6__.CAMERA_DIRECTION.BACK
    });
  }
  /** 跳转到地址选择页 */
  goSelectAddress() {
    this.nav.routeTo('mime/address-book', {
      chain: this.chain,
      symbol: this.chainSymbol
    });
  }
  /** 刷新utox */
  checkBitcoinUtxos() {
    var _this12 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      if (_this12.isBitcoinChain) {
        const bitcoinService = _this12.chainApiService;
        _this12.utxos = yield bitcoinService.getUtxos(_this12.activeWallet.address);
        var _iteratorAbruptCompletion2 = false;
        var _didIteratorError2 = false;
        var _iteratorError2;
        try {
          for (var _iterator2 = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncIterator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(_this12.utxos), _step2; _iteratorAbruptCompletion2 = !(_step2 = yield _iterator2.next()).done; _iteratorAbruptCompletion2 = false) {
            const item = _step2.value;
            {
              if ((0,_bnqkl_framework_helpers__WEBPACK_IMPORTED_MODULE_4__.$isNoEmptyString)(item.txHex) === false) {
                const tx = yield _this12.chainApiService.getTxInfo(item.txid);
                item.txHex = tx.hex;
              }
            }
          }
        } catch (err) {
          _didIteratorError2 = true;
          _iteratorError2 = err;
        } finally {
          try {
            if (_iteratorAbruptCompletion2 && _iterator2.return != null) {
              yield _iterator2.return();
            }
          } finally {
            if (_didIteratorError2) {
              throw _iteratorError2;
            }
          }
        }
      }
    })();
  }
}
_class = HomeTransferPage;
_class.ɵfac = /*@__PURE__*/(() => {
  let ɵHomeTransferPage_BaseFactory;
  return function HomeTransferPage_Factory(t) {
    return (ɵHomeTransferPage_BaseFactory || (ɵHomeTransferPage_BaseFactory = _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵgetInheritedFactory"](_class)))(t || _class);
  };
})();
_class.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵdefineComponent"]({
  type: _class,
  selectors: [["w-home-transfer-page"]],
  viewQuery: function HomeTransferPage_Query(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵviewQuery"](_c0, 5);
    }
    if (rf & 2) {
      let _t;
      _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵloadQuery"]()) && (ctx._bioforestChainFeeInputRef = _t.first);
    }
  },
  outputs: {
    returnValue$: "returnValue$"
  },
  standalone: true,
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵInheritDefinitionFeature"], _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵStandaloneFeature"]],
  decls: 58,
  vars: 51,
  consts: () => {
    let i18n_1;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_RECEIVER$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_HOME_TRANSFER_HOME_TRANSFER_COMPONENT_TS_2 = goog.getMsg(" Receiver ");
      i18n_1 = MSG_EXTERNAL_RECEIVER$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_HOME_TRANSFER_HOME_TRANSFER_COMPONENT_TS_2;
    } else {
      i18n_1 = " Receiver ";
    }
    let i18n_3;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_ASSETS$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_HOME_TRANSFER_HOME_TRANSFER_COMPONENT_TS_4 = goog.getMsg("Assets");
      i18n_3 = MSG_EXTERNAL_ASSETS$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_HOME_TRANSFER_HOME_TRANSFER_COMPONENT_TS_4;
    } else {
      i18n_3 = "Assets";
    }
    let i18n_5;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_TRANSFER_AMOUNT$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_HOME_TRANSFER_HOME_TRANSFER_COMPONENT_TS_6 = goog.getMsg(" Transfer Amount ");
      i18n_5 = MSG_EXTERNAL_TRANSFER_AMOUNT$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_HOME_TRANSFER_HOME_TRANSFER_COMPONENT_TS_6;
    } else {
      i18n_5 = " Transfer Amount ";
    }
    let i18n_7;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_ENTER_AMOUNT$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_HOME_TRANSFER_HOME_TRANSFER_COMPONENT_TS_8 = goog.getMsg("Enter Amount");
      i18n_7 = MSG_EXTERNAL_ENTER_AMOUNT$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_HOME_TRANSFER_HOME_TRANSFER_COMPONENT_TS_8;
    } else {
      i18n_7 = "Enter Amount";
    }
    let i18n_9;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_ALL$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_HOME_TRANSFER_HOME_TRANSFER_COMPONENT_TS_10 = goog.getMsg(" All ");
      i18n_9 = MSG_EXTERNAL_ALL$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_HOME_TRANSFER_HOME_TRANSFER_COMPONENT_TS_10;
    } else {
      i18n_9 = " All ";
    }
    let i18n_11;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_MINER_FEE$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_HOME_TRANSFER_HOME_TRANSFER_COMPONENT_TS_12 = goog.getMsg("Miner Fee");
      i18n_11 = MSG_EXTERNAL_MINER_FEE$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_HOME_TRANSFER_HOME_TRANSFER_COMPONENT_TS_12;
    } else {
      i18n_11 = "Miner Fee";
    }
    let i18n_13;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_CONFIRM$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_HOME_TRANSFER_HOME_TRANSFER_COMPONENT_TS_14 = goog.getMsg("Confirm");
      i18n_13 = MSG_EXTERNAL_CONFIRM$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_HOME_TRANSFER_HOME_TRANSFER_COMPONENT_TS_14;
    } else {
      i18n_13 = "Confirm";
    }
    let i18n_15;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_INCORRECT_WALLET_ADDRESS$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_HOME_TRANSFER_HOME_TRANSFER_COMPONENT_TS___16 = goog.getMsg(" Incorrect Wallet Address ");
      i18n_15 = MSG_EXTERNAL_INCORRECT_WALLET_ADDRESS$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_HOME_TRANSFER_HOME_TRANSFER_COMPONENT_TS___16;
    } else {
      i18n_15 = " Incorrect Wallet Address ";
    }
    let i18n_17;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_ENTER_AMOUNT$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_HOME_TRANSFER_HOME_TRANSFER_COMPONENT_TS____18 = goog.getMsg("Enter Amount");
      i18n_17 = MSG_EXTERNAL_ENTER_AMOUNT$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_HOME_TRANSFER_HOME_TRANSFER_COMPONENT_TS____18;
    } else {
      i18n_17 = "Enter Amount";
    }
    let i18n_19;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_ENTER_THE_CORRECT_FORMAT$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_HOME_TRANSFER_HOME_TRANSFER_COMPONENT_TS____20 = goog.getMsg("Enter the correct format");
      i18n_19 = MSG_EXTERNAL_ENTER_THE_CORRECT_FORMAT$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_HOME_TRANSFER_HOME_TRANSFER_COMPONENT_TS____20;
    } else {
      i18n_19 = "Enter the correct format";
    }
    let i18n_21;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_MEMO$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_HOME_TRANSFER_HOME_TRANSFER_COMPONENT_TS__22 = goog.getMsg(" Memo ");
      i18n_21 = MSG_EXTERNAL_MEMO$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_HOME_TRANSFER_HOME_TRANSFER_COMPONENT_TS__22;
    } else {
      i18n_21 = " Memo ";
    }
    let i18n_23;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_FILLABLE_MEMO$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_HOME_TRANSFER_HOME_TRANSFER_COMPONENT_TS__24 = goog.getMsg("Fillable Memo");
      i18n_23 = MSG_EXTERNAL_FILLABLE_MEMO$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_HOME_TRANSFER_HOME_TRANSFER_COMPONENT_TS__24;
    } else {
      i18n_23 = "Fillable Memo";
    }
    let i18n_25;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_THE_MAXIMUM_LENGTH_OF_THE_MEMO_IS_MAX__length_$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_HOME_TRANSFER_HOME_TRANSFER_COMPONENT_TS___26 = goog.getMsg(" The maximum length of the memo is {$interpolation} ", {
        "interpolation": "\uFFFD0\uFFFD"
      }, {
        original_code: {
          "interpolation": "{{ error.requiredLength }}"
        }
      });
      i18n_25 = MSG_EXTERNAL_THE_MAXIMUM_LENGTH_OF_THE_MEMO_IS_MAX__length_$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_HOME_TRANSFER_HOME_TRANSFER_COMPONENT_TS___26;
    } else {
      i18n_25 = " The maximum length of the memo is " + "\uFFFD0\uFFFD" + " ";
    }
    let i18n_28;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_ESTIMATED_FEE$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_HOME_TRANSFER_HOME_TRANSFER_COMPONENT_TS__29 = goog.getMsg("Estimated Fee");
      i18n_28 = MSG_EXTERNAL_ESTIMATED_FEE$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_HOME_TRANSFER_HOME_TRANSFER_COMPONENT_TS__29;
    } else {
      i18n_28 = "Estimated Fee";
    }
    let i18n_32;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_ABOUT_FEE$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_HOME_TRANSFER_HOME_TRANSFER_COMPONENT_TS__33 = goog.getMsg("About Fee");
      i18n_32 = MSG_EXTERNAL_ABOUT_FEE$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_HOME_TRANSFER_HOME_TRANSFER_COMPONENT_TS__33;
    } else {
      i18n_32 = "About Fee";
    }
    let i18n_34;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_TRON_NETWORK_FEE_LONG_TIPS_1$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_HOME_TRANSFER_HOME_TRANSFER_COMPONENT_TS__35 = goog.getMsg(" The network fee will vary according to networksituation, once the transaction is confirmed, the fee cannot be refunded regardless of whether the transaction is successful or not. ");
      i18n_34 = MSG_EXTERNAL_TRON_NETWORK_FEE_LONG_TIPS_1$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_HOME_TRANSFER_HOME_TRANSFER_COMPONENT_TS__35;
    } else {
      i18n_34 = " The network fee will vary according to networksituation, once the transaction is confirmed, the fee cannot be refunded regardless of whether the transaction is successful or not. ";
    }
    let i18n_36;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_TRON_NETWORK_FEE_LONG_TIPS_2$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_HOME_TRANSFER_HOME_TRANSFER_COMPONENT_TS__37 = goog.getMsg(" The network fee is charged by the TRON network, and COT does not charge any fees ! ");
      i18n_36 = MSG_EXTERNAL_TRON_NETWORK_FEE_LONG_TIPS_2$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_HOME_TRANSFER_HOME_TRANSFER_COMPONENT_TS__37;
    } else {
      i18n_36 = " The network fee is charged by the TRON network, and COT does not charge any fees ! ";
    }
    let i18n_38;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_I_GOT_IT$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_HOME_TRANSFER_HOME_TRANSFER_COMPONENT_TS__39 = goog.getMsg(" I got it ! ");
      i18n_38 = MSG_EXTERNAL_I_GOT_IT$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_HOME_TRANSFER_HOME_TRANSFER_COMPONENT_TS__39;
    } else {
      i18n_38 = " I got it ! ";
    }
    let i18n_40;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_MINER_FEE$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_HOME_TRANSFER_HOME_TRANSFER_COMPONENT_TS__41 = goog.getMsg("Miner Fee");
      i18n_40 = MSG_EXTERNAL_MINER_FEE$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_HOME_TRANSFER_HOME_TRANSFER_COMPONENT_TS__41;
    } else {
      i18n_40 = "Miner Fee";
    }
    let i18n_42;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_THE_RECOMMENDED_MINER_FEE__fee_$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_HOME_TRANSFER_HOME_TRANSFER_COMPONENT_TS__43 = goog.getMsg(" The recommended miner fee is: {$interpolation} ", {
        "interpolation": "\uFFFD0\uFFFD"
      }, {
        original_code: {
          "interpolation": "{{ bioforestDefaultFee | amountFixed : decimals }}"
        }
      });
      i18n_42 = MSG_EXTERNAL_THE_RECOMMENDED_MINER_FEE__fee_$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_HOME_TRANSFER_HOME_TRANSFER_COMPONENT_TS__43;
    } else {
      i18n_42 = " The recommended miner fee is: " + "\uFFFD0\uFFFD" + " ";
    }
    let i18n_44;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_BIOFOREST_CHAIN_FEE_TO_LOW$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_HOME_TRANSFER_HOME_TRANSFER_COMPONENT_TS___45 = goog.getMsg(" If the miner fee is too low, it will affect the transaction on-chain. ");
      i18n_44 = MSG_EXTERNAL_BIOFOREST_CHAIN_FEE_TO_LOW$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_HOME_TRANSFER_HOME_TRANSFER_COMPONENT_TS___45;
    } else {
      i18n_44 = " If the miner fee is too low, it will affect the transaction on-chain. ";
    }
    return [[3, "open", "tips"], [3, "titleColor", "headerBackground", "headerOpacity", "headerTranslucent", "headerButtonColor", "contentHeaderArea", "contentSafeArea", "contentClass", "pageBackground", "contentBackground"], ["endMenu", "", "bnRippleButton", "", 3, "mode"], [1, "_bg"], [1, "rounded-t-large", "mt-4", "bg-white", "px-5"], [1, "pb-5", 3, "formGroup", "ngSubmit"], [1, "flex", "h-10", "w-full", "items-end", "justify-between", "text-xs", "font-semibold"], [1, "flex-shrink-0", "pr-2", "text-xs", 3, "ngClass"], i18n_1, ["class", "text-red mr-1 flex-grow text-right", 4, "ngIf"], ["name", "address-book", 1, "icon-5", "pl-1", 3, "click"], [1, "bg-env", "mt-1.5", "flex", "h-10", "rounded-lg"], ["formControlName", "address", "type", "text", 1, "text-subtext", "w-full", "px-2", 3, "placeholder"], i18n_3, ["bnRippleButton", "", 1, "bg-env", "mt-1.5", "flex", "h-10", "w-full", "items-center", "justify-between", "rounded-lg", "p-3", 3, "click"], [1, "text-subtext", "text-sm"], [1, "font-num", "text-subtext", "flex", "items-center", "text-xs", "font-medium", "tracking-normal"], [1, "pr-0.5"], [1, "icon-4", 3, "name"], i18n_5, ["class", "text-error text-xss text-right font-normal", 4, "ngIf"], [1, "bg-env", "mb-1.5", "mt-1.5", "flex", "h-10", "rounded-lg", "px-3"], ["formControlName", "amount", "type", "string", "placeholder", i18n_7, 1, "font-num", "text-subtext", "w-full"], ["bnRippleButton", "", 1, "text-primary", "text-primary-2", "flex", "shrink-0", "items-center", "self-center", "rounded-lg", "px-2", "py-1", "text-sm", 3, "click"], i18n_9, [4, "ngIf"], i18n_11, ["class", "bg-env mt-1.5 flex items-center justify-between rounded-lg p-3"], ["class", "bg-env mt-1.5 flex items-center justify-between rounded-lg p-3", 4, "ngIf"], ["footer", "", 1, "w-full", 3, "formGroup", "ngSubmit"], ["bnRippleButton", "", "type", "submit", 1, "from-purple-gradient-start", "to-purple-gradient-end", "h-10.5", "w-full", "rounded-full", "bg-gradient-to-b", "text-center", "text-white", 3, "disabled"], [3, "loadingTheme", "waitFor"], i18n_13, [3, "disableClose", "isOpen", "panelClass", "isOpenChange", 4, "ngIf"], [3, "isOpen", "isOpenChange"], ["endMenu", "", "bnRippleButton", "", 3, "mode", "click"], ["name", "scan", 1, "icon-5"], [1, "text-red", "mr-1", "flex-grow", "text-right"], ["class", "text-error text-xss font-normal leading-4", 4, "ngIf"], [1, "text-error", "text-xss", "font-normal", "leading-4"], i18n_15, [1, "text-error", "text-xss", "text-right", "font-normal"], i18n_17, i18n_19, [1, "flex-shrink-0", "pr-2", 3, "ngClass"], i18n_21, [1, "text-error", "text-xss", "text-right", 3, "wSwitchErrors"], ["wCaseKey", "maxlength"], [1, "bg-env", "mt-2", "flex", "h-10", "rounded-lg", "px-3"], ["formControlName", "memo", "type", "text", "placeholder", i18n_23, 1, "text-subtext", "w-full", "border-none", "bg-transparent", "text-sm", "outline-none"], i18n_25, [1, "bg-env", "mt-1.5", "flex", "items-center", "justify-between", "rounded-lg", "p-3"], [1, "text-text", "flex", "justify-start", "text-sm", "font-normal", "tracking-normal"], [1, "grow-0", "overflow-hidden", "text-ellipsis"], [1, "ml-1"], i18n_28, [1, "rounded-50", "bg-line", "h-5.5", "w-5.5", "ml-2", "flex", "items-center", "justify-center", "text-center", "font-semibold", "text-white", 3, "click"], [1, "mt-1.5", "flex", "justify-between"], [4, "ngFor", "ngForOf"], [1, "fee-select-item", "w-1/3", "rounded-lg", "px-2", "py-3", "text-center", 3, "ngClass", "click"], [1, "text-title", "text-sm", "font-bold", "tracking-normal"], [1, "text-subtext", "text-xss", "font-normal", "tracking-normal"], [1, "text-subtext", "text-xsss", "font-normal", "tracking-normal"], ["bnRippleButton", "", 1, "bg-env", "mb-24px", "mt-2", "flex", "h-10", "w-full", "rounded-lg", "px-3", "font-mono", "leading-10", 3, "click"], [3, "disableClose", "isOpen", "panelClass", "isOpenChange"], [3, "dataInfo", "returnValue$"], ["headerTitle", i18n_32], ["card", ""], [1, "text-text", "prose", "text-sm"], i18n_34, i18n_36, ["footer", "", "bnRippleButton", "", 1, "border-tiny", "border-line", 3, "click"], i18n_38, ["headerTitle", i18n_40, 3, "returnValue$"], ["card", "card"], [1, "bg-env", "flex", "items-center", "rounded-lg", "p-2.5"], ["type", "number", 1, "font-num", "flex-grow", "bg-transparent", "text-sm", 3, "defaultValue", "formControl"], ["bioforestChainFeeInput", ""], ["wCaseKey", "lessThenDefaultFee"], [1, "text-subtext", "py-2", "text-right", "text-xs"], i18n_42, ["footer", ""], i18n_44];
  },
  template: function HomeTransferPage_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵelement"](0, "w-form-validation-top-tips", 0);
      _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵelementStart"](1, "common-page", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵtemplate"](2, HomeTransferPage_Conditional_2_Template, 2, 1, "button", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵelement"](3, "div", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵelementStart"](4, "div", 4)(5, "form", 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵlistener"]("ngSubmit", function HomeTransferPage_Template_form_ngSubmit_5_listener() {
        return ctx.onSubmit();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵelementStart"](6, "fieldset")(7, "legend", 6)(8, "div", 7);
      _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵi18n"](9, 8);
      _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵpipe"](10, "errors");
      _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵtemplate"](11, HomeTransferPage_div_11_Template, 3, 2, "div", 9);
      _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵpipe"](12, "errors");
      _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵelementStart"](13, "w-icon", 10);
      _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵlistener"]("click", function HomeTransferPage_Template_w_icon_click_13_listener() {
        return ctx.goSelectAddress();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵelementStart"](14, "div", 11);
      _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵelement"](15, "input", 12);
      _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵelementStart"](16, "fieldset")(17, "legend", 6);
      _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵi18n"](18, 13);
      _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵelementStart"](19, "button", 14);
      _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵlistener"]("click", function HomeTransferPage_Template_button_click_19_listener() {
        return ctx.goSelectAsset();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵelementStart"](20, "span", 15);
      _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵtext"](21);
      _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵelementStart"](22, "span", 16)(23, "span", 17);
      _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵtext"](24);
      _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵpipe"](25, "numberFormat");
      _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵpipe"](26, "amountFixed");
      _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵpipe"](27, "async");
      _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵelement"](28, "w-icon", 18);
      _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵelementEnd"]()()();
      _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵelementStart"](29, "fieldset")(30, "legend", 6)(31, "div", 7);
      _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵi18n"](32, 19);
      _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵpipe"](33, "errors");
      _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵtemplate"](34, HomeTransferPage_div_34_Template, 2, 1, "div", 20);
      _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵpipe"](35, "errors");
      _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵelementStart"](36, "div", 21);
      _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵelement"](37, "input", 22);
      _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵelementStart"](38, "button", 23);
      _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵlistener"]("click", function HomeTransferPage_Template_button_click_38_listener() {
        return ctx.fullAssets();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵi18n"](39, 24);
      _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵtemplate"](40, HomeTransferPage_ng_container_40_Template, 10, 6, "ng-container", 25);
      _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵelementStart"](41, "div", 6);
      _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵi18n"](42, 26);
      _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵtemplate"](43, HomeTransferPage_Conditional_43_Template, 7, 5, "div", 27)(44, HomeTransferPage_div_44_Template, 6, 0, "div", 28);
      _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵelementStart"](45, "fieldset");
      _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵtemplate"](46, HomeTransferPage_ng_container_46_Template, 3, 1, "ng-container", 25);
      _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵtemplate"](47, HomeTransferPage_fieldset_47_Template, 7, 5, "fieldset", 25);
      _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵelementStart"](48, "form", 29);
      _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵlistener"]("ngSubmit", function HomeTransferPage_Template_form_ngSubmit_48_listener() {
        return ctx.onSubmit();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵelementStart"](49, "button", 30)(50, "bn-loading-wrapper", 31)(51, "span");
      _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵi18n"](52, 32);
      _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵelementEnd"]()()()()();
      _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵtemplate"](53, HomeTransferPage_common_bottom_sheet_53_Template, 2, 3, "common-bottom-sheet", 33);
      _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵelementStart"](54, "common-template-dialog-opener", 34);
      _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵlistener"]("isOpenChange", function HomeTransferPage_Template_common_template_dialog_opener_isOpenChange_54_listener($event) {
        return ctx.dialog_tronFeeTips.is_open = $event;
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵtemplate"](55, HomeTransferPage_ng_template_55_Template, 12, 0, "ng-template");
      _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵelementStart"](56, "common-template-dialog-opener", 34);
      _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵlistener"]("isOpenChange", function HomeTransferPage_Template_common_template_dialog_opener_isOpenChange_56_listener($event) {
        return ctx.dialog_changeBioforestChainFee.is_open = $event;
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵtemplate"](57, HomeTransferPage_ng_template_57_Template, 12, 10, "ng-template");
      _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵelementEnd"]();
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵproperty"]("open", ctx.tronAddressNotActive)("tips", ctx.tronAddressNotActiveTips);
      _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵproperty"]("titleColor", "white")("headerBackground", "transparent")("headerOpacity", 100)("headerTranslucent", false)("headerButtonColor", "light")("contentHeaderArea", false)("contentSafeArea", true)("contentClass", "px-0")("pageBackground", "white")("contentBackground", "white");
      _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵconditional"](2, ctx.isMobile ? 2 : -1);
      _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵproperty"]("formGroup", ctx.form);
      _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵpipeBind1"](10, 36, ctx.address) ? "text-error" : "text-title");
      _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵproperty"]("ngIf", _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵpipeBind1"](12, 38, ctx.address));
      _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵadvance"](4);
      _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵproperty"]("placeholder", ctx.enterAddressPlaceholder);
      _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵadvance"](6);
      _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵtextInterpolate1"](" ", ctx.assetType, " ");
      _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵpipeBind1"](25, 40, _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵpipeBind2"](26, 42, _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵpipeBind1"](27, 45, ctx.assetTypeBalance$), ctx.decimals)), " ");
      _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵadvance"](4);
      _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵproperty"]("name", "right");
      _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵpipeBind1"](33, 47, ctx.amount) ? "text-error" : "text-title");
      _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵproperty"]("ngIf", _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵpipeBind1"](35, 49, ctx.amount));
      _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵadvance"](6);
      _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵproperty"]("ngIf", ctx.isBioforestChain);
      _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵconditional"](43, ctx.isBitcoinChain ? 43 : -1);
      _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵproperty"]("ngIf", ctx.chain === "Tron");
      _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵproperty"]("ngIf", ctx.chain === ctx.CHAIN_NAME.Ethereum || ctx.chain === ctx.CHAIN_NAME.Binance);
      _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵproperty"]("ngIf", ctx.isBioforestChain);
      _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵproperty"]("formGroup", ctx.form);
      _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵclassProp"]("opacity-30", !ctx.form.valid);
      _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵproperty"]("disabled", !ctx.form.valid);
      _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵproperty"]("loadingTheme", "ellipsis")("waitFor", ctx.onSubmit.running);
      _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵproperty"]("ngIf", ctx.paymentDetailInput);
      _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵproperty"]("isOpen", ctx.dialog_tronFeeTips.is_open);
      _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_39__["ɵɵproperty"]("isOpen", ctx.dialog_changeBioforestChainFee.is_open);
    }
  },
  dependencies: [_modules_page_module__WEBPACK_IMPORTED_MODULE_19__.CommonPageModule, _libs_bnf_modules_bottom_sheet_components_bottom_sheet_component__WEBPACK_IMPORTED_MODULE_25__.BottomSheetComponent, _libs_bnf_components_ripple_button_ripple_button_directive__WEBPACK_IMPORTED_MODULE_26__.RippleButtonDirective, _libs_bnf_directives_form_errors_directive__WEBPACK_IMPORTED_MODULE_27__.SwitchErrorsDirective, _libs_bnf_directives_form_errors_directive__WEBPACK_IMPORTED_MODULE_27__.SwitchCaseDirective, _libs_bnf_directives_auto_complete_off_directive__WEBPACK_IMPORTED_MODULE_28__.AutoCompleteOffDirective, _angular_common__WEBPACK_IMPORTED_MODULE_44__.NgClass, _angular_common__WEBPACK_IMPORTED_MODULE_44__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_44__.NgIf, _angular_forms__WEBPACK_IMPORTED_MODULE_40__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_40__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_40__.NumberValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_40__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_40__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_40__.FormControlDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_40__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_40__.FormControlName, _libs_bnf_modules_dialog_components_common_card_common_card_component__WEBPACK_IMPORTED_MODULE_29__.CommonCardComponent, _libs_bnf_modules_dialog_components_card_footer_confirm_confirm_footer_component__WEBPACK_IMPORTED_MODULE_30__.ConfirmFooterComponent, _libs_bnf_modules_dialog_components_template_dialog_opener_template_dialog_opener_component__WEBPACK_IMPORTED_MODULE_31__.TemplateDialogOpenerComponent, _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_32__.CommonPageComponent, _components_icon_icon_component__WEBPACK_IMPORTED_MODULE_33__.IconComponent, _components_form_validation_top_tips_form_validation_top_tips_component__WEBPACK_IMPORTED_MODULE_34__.FormValidationTopTipsComponent, _libs_bnf_components_loading_wrapper_loading_wrapper_component__WEBPACK_IMPORTED_MODULE_35__.LoadingWrapperComponent, _libs_bnf_pipes_errors_errors_pipe__WEBPACK_IMPORTED_MODULE_36__.ErrorsPipe, _libs_bnf_pipes_number_format_number_format_pipe__WEBPACK_IMPORTED_MODULE_37__.NumberFormatPipe, _angular_common__WEBPACK_IMPORTED_MODULE_44__.AsyncPipe, _libs_bnf_pipes_amountFixed_amount_fixed_pipe__WEBPACK_IMPORTED_MODULE_38__.AmountFixedPipe, _pages_home_pages_home_payment_details_home_payment_details_component__WEBPACK_IMPORTED_MODULE_20__.PaymentDetailsPage],
  styles: ["[_nghost-%COMP%]   .activeBorderStyle[_ngcontent-%COMP%] {\n  border: 0.5px solid #5c14c4;\n  border-radius: 8px;\n}\n[_nghost-%COMP%]   .borderStyle[_ngcontent-%COMP%] {\n  border: 0.5px solid #eff5ff;\n  border-radius: 8px;\n}\n[_nghost-%COMP%]   .fee-select-item[_ngcontent-%COMP%]:nth-child(2) {\n  margin-left: 0.75rem;\n  margin-right: 0.75rem;\n}\n[_nghost-%COMP%]   ._bg[_ngcontent-%COMP%] {\n  position: absolute;\n  left: 0rem;\n  top: 0rem;\n  height: 18rem;\n  width: 100%;\n  --tw-bg-opacity: 1;\n  background-color: rgb(0 0 0 / var(--tw-bg-opacity));\n  object-fit: cover;\n  z-index: -1;\n}\n\n  .payment-details-sheet-panel .mat-bottom-sheet-container {\n  min-height: 355px;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL2FwcHMvd2FsbGV0L3NyYy9wYWdlcy9tbmVtb25pYy9wYWdlcy9ob21lLXRyYW5zZmVyL2hvbWUtdHJhbnNmZXIuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQ0U7RUFDRSwyQkFBQTtFQUNBLGtCQUFBO0FBQUo7QUFFRTtFQUNFLDJCQUFBO0VBQ0Esa0JBQUE7QUFBSjtBQUdJO0VBQUEsb0JBQUE7RUFBQTtBQUFBO0FBR0E7RUFBQSxrQkFBQTtFQUFBLFVBQUE7RUFBQSxTQUFBO0VBQUEsYUFBQTtFQUFBLFdBQUE7RUFBQSxrQkFBQTtFQUFBLG1EQUFBO0VBQUEsaUJBQUE7RUFFQTtBQUZBOztBQU1GO0VBQ0UsaUJBQUE7QUFGSiIsInNvdXJjZXNDb250ZW50IjpbIjpob3N0IHtcclxuICAuYWN0aXZlQm9yZGVyU3R5bGUge1xyXG4gICAgYm9yZGVyOiAwLjVweCBzb2xpZCAjNWMxNGM0O1xyXG4gICAgYm9yZGVyLXJhZGl1czogOHB4O1xyXG4gIH1cclxuICAuYm9yZGVyU3R5bGUge1xyXG4gICAgYm9yZGVyOiAwLjVweCBzb2xpZCAjZWZmNWZmO1xyXG4gICAgYm9yZGVyLXJhZGl1czogOHB4O1xyXG4gIH1cclxuICAuZmVlLXNlbGVjdC1pdGVtOm50aC1jaGlsZCgyKSB7XHJcbiAgICBAYXBwbHkgbXgtMztcclxuICB9XHJcbiAgLl9iZyB7XHJcbiAgICBAYXBwbHkgYWJzb2x1dGUgbGVmdC0wIHRvcC0wIGgtNzIgdy1mdWxsIGJnLWJsYWNrIG9iamVjdC1jb3ZlcjtcclxuXHJcbiAgICB6LWluZGV4OiAtMTtcclxuICB9XHJcbn1cclxuOjpuZy1kZWVwIC5wYXltZW50LWRldGFpbHMtc2hlZXQtcGFuZWwge1xyXG4gIC5tYXQtYm90dG9tLXNoZWV0LWNvbnRhaW5lciB7XHJcbiAgICBtaW4taGVpZ2h0OiAzNTVweDtcclxuICB9XHJcbn1cclxuIl0sInNvdXJjZVJvb3QiOiIifQ== */"],
  changeDetection: 0
});
(0,tslib__WEBPACK_IMPORTED_MODULE_45__.__decorate)([HomeTransferPage.OnInit(), (0,tslib__WEBPACK_IMPORTED_MODULE_45__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_45__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_45__.__metadata)("design:returntype", void 0)], HomeTransferPage.prototype, "addObserverDom", null);
(0,tslib__WEBPACK_IMPORTED_MODULE_45__.__decorate)([HomeTransferPage.OnDestroy(), (0,tslib__WEBPACK_IMPORTED_MODULE_45__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_45__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_45__.__metadata)("design:returntype", void 0)], HomeTransferPage.prototype, "disconnectObserverDom", null);
(0,tslib__WEBPACK_IMPORTED_MODULE_45__.__decorate)([HomeTransferPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_45__.__metadata)("design:type", Object)], HomeTransferPage.prototype, "address", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_45__.__decorate)([HomeTransferPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_45__.__metadata)("design:type", Object)], HomeTransferPage.prototype, "amount", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_45__.__decorate)([HomeTransferPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_45__.__metadata)("design:type", Object)], HomeTransferPage.prototype, "memo", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_45__.__decorate)([HomeTransferPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_45__.__metadata)("design:type", String)], HomeTransferPage.prototype, "chain", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_45__.__decorate)([HomeTransferPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_45__.__metadata)("design:type", Object)], HomeTransferPage.prototype, "assetType", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_45__.__decorate)([HomeTransferPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_45__.__metadata)("design:type", Object)], HomeTransferPage.prototype, "decimals", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_45__.__decorate)([HomeTransferPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_45__.__metadata)("design:type", Object)], HomeTransferPage.prototype, "_maxPriorityFeePerGas", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_45__.__decorate)([HomeTransferPage.State({
  depth: 1
}), (0,tslib__WEBPACK_IMPORTED_MODULE_45__.__metadata)("design:type", Object)], HomeTransferPage.prototype, "_bscGasInfo", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_45__.__decorate)([HomeTransferPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_45__.__metadata)("design:type", Object)], HomeTransferPage.prototype, "assetBalance", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_45__.__decorate)([HomeTransferPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_45__.__metadata)("design:type", Object)], HomeTransferPage.prototype, "chainSymbol", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_45__.__decorate)([HomeTransferPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_45__.__metadata)("design:type", Object)], HomeTransferPage.prototype, "chainSymbolDecimals", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_45__.__decorate)([HomeTransferPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_45__.__metadata)("design:type", Array)], HomeTransferPage.prototype, "bscFeeArr", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_45__.__decorate)([HomeTransferPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_45__.__metadata)("design:type", Object)], HomeTransferPage.prototype, "bioforestDefaultFee", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_45__.__decorate)([HomeTransferPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_45__.__metadata)("design:type", Object)], HomeTransferPage.prototype, "bioforestChainFee", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_45__.__decorate)([HomeTransferPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_45__.__metadata)("design:type", Object)], HomeTransferPage.prototype, "_bioforestUseFee", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_45__.__decorate)([HomeTransferPage.State({
  depth: 1
}), (0,tslib__WEBPACK_IMPORTED_MODULE_45__.__metadata)("design:type", Object)], HomeTransferPage.prototype, "dialog_changeBioforestChainFee", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_45__.__decorate)([HomeTransferPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_45__.__metadata)("design:type", Object)], HomeTransferPage.prototype, "form", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_45__.__decorate)([HomeTransferPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_45__.__metadata)("design:type", Object)], HomeTransferPage.prototype, "tronAddressNotActive", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_45__.__decorate)([HomeTransferPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_45__.__metadata)("design:type", Object)], HomeTransferPage.prototype, "tronAddressNotActiveTips", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_45__.__decorate)([HomeTransferPage.QueryParams(), (0,tslib__WEBPACK_IMPORTED_MODULE_45__.__metadata)("design:type", Object)], HomeTransferPage.prototype, "_data", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_45__.__decorate)([HomeTransferPage.OnInit(), (0,tslib__WEBPACK_IMPORTED_MODULE_45__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_45__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_45__.__metadata)("design:returntype", Promise)], HomeTransferPage.prototype, "initChainInfo", null);
(0,tslib__WEBPACK_IMPORTED_MODULE_45__.__decorate)([HomeTransferPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_45__.__metadata)("design:type", Object)], HomeTransferPage.prototype, "homeSelectTokenPageReturnController", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_45__.__decorate)([HomeTransferPage.OnInit(), (0,tslib__WEBPACK_IMPORTED_MODULE_45__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_45__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_45__.__metadata)("design:returntype", void 0)], HomeTransferPage.prototype, "watchToPageReturn", null);
(0,tslib__WEBPACK_IMPORTED_MODULE_45__.__decorate)([HomeTransferPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_45__.__metadata)("design:type", Object)], HomeTransferPage.prototype, "paymentDetailInput", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_45__.__decorate)([HomeTransferPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_45__.__metadata)("design:type", Object)], HomeTransferPage.prototype, "paymenDetailOutput$", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_45__.__decorate)([HomeTransferPage.State({
  depth: 1
}), (0,tslib__WEBPACK_IMPORTED_MODULE_45__.__metadata)("design:type", Object)], HomeTransferPage.prototype, "dialog_tronFeeTips", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_45__.__decorate)([HomeTransferPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_45__.__metadata)("design:type", Object)], HomeTransferPage.prototype, "bitcoinUseFee", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_45__.__decorate)([HomeTransferPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_45__.__metadata)("design:type", Object)], HomeTransferPage.prototype, "scannerPageReturnController", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_45__.__decorate)([HomeTransferPage.OnInit(), (0,tslib__WEBPACK_IMPORTED_MODULE_45__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_45__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_45__.__metadata)("design:returntype", Promise)], HomeTransferPage.prototype, "watchPageReturn", null);
(0,tslib__WEBPACK_IMPORTED_MODULE_45__.__decorate)([HomeTransferPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_45__.__metadata)("design:type", Object)], HomeTransferPage.prototype, "addressBookPageReturnController", void 0);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (HomeTransferPage);

/***/ })

}]);
//# sourceMappingURL=default-apps_wallet_src_pages_mnemonic_pages_home-transfer_home-transfer_component_ts.js.map