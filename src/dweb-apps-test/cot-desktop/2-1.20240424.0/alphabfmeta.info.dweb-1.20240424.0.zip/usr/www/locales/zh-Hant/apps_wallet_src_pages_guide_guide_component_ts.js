"use strict";
(self["webpackChunkwallet"] = self["webpackChunkwallet"] || []).push([["apps_wallet_src_pages_guide_guide_component_ts"],{

/***/ 7951:
/*!********************************************************!*\
  !*** ./apps/wallet/src/pages/guide/guide.component.ts ***!
  \********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   GuidePage: () => (/* binding */ GuidePage),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! tslib */ 90505);
/* harmony import */ var _bnqkl_framework_plugins__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @bnqkl/framework/plugins */ 43990);
/* harmony import */ var _modules_page_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ~modules/page.module */ 77538);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 61039);
/* harmony import */ var _libs_bnf_directives_tab_directive__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../libs/bnf/directives/tab.directive */ 384);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 6729);
/* harmony import */ var _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../../libs/bnf/modules/page/common-page/common-page.component */ 62052);
var _class;







const _forTrack0 = ($index, $item) => $item.index;
function GuidePage_For_4_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](1, "img", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](2, "div", 8)(3, "div", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](4, "div", 10)(5, "div", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const item_r2 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("src", item_r2.image, _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵsanitizeUrl"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("innerHtml", item_r2.text_1, _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵsanitizeHtml"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("innerHtml", item_r2.text_2, _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵsanitizeHtml"]);
  }
}
const _c1 = (a0, a1) => ({
  "!w-[16px] bg-white": a0,
  "bg-white/50": a1
});
function GuidePage_For_7_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](0, "div", 12);
  }
  if (rf & 2) {
    const i_r8 = ctx.$index;
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpureFunction2"](1, _c1, i_r8 === ctx_r1.currActivityIndex, i_r8 !== ctx_r1.currActivityIndex));
  }
}
/**
 * 引导页
 */
class GuidePage extends _modules_page_module__WEBPACK_IMPORTED_MODULE_1__.CommonPageBase {
  constructor() {
    super(...arguments);
    /** 列表 */
    this.activitySlides = [{
      index: 0,
      text_1: "\u8F15\u9B06\u8F49\u8CEC",
      text_2: "\u96A8\u6642\u96A8\u5730 <br /> \u7BA1\u7406\u60A8\u7684\u6578\u5B57\u8CC7\u7522",
      image: './assets/images/guide-transfer.svg'
    }, {
      index: 1,
      text_1: "\u591A\u93C8\u652F\u6301",
      text_2: "\u652F\u6301\u591A\u7A2E\u5340\u584A\u93C8 <br /> \u64C1\u6709\u7121\u9650\u53EF\u80FD",
      image: './assets/images/guide-chain.svg'
    }, {
      index: 2,
      text_1: "\u5168\u9762\u52A0\u5BC6",
      text_2: "\u5148\u9032\u7684\u52A0\u5BC6\u6280\u8853 <br /> \u6578\u5B57\u8CA1\u5BCC\u66F4\u5B89\u5168",
      image: './assets/images/guide-encryption.svg'
    }];
    this.enter = {
      text: "\u9EDE\u64CA\u9032\u5165",
      handle: () => {
        localStorage.setItem('🙋‍♂️show_guide', '1');
        this.nav.setPageRoot('wallet-sign-in');
      }
    };
    /** 记录初始 */
    this.touchEventStartX = 0;
    /** 当前激活项 */
    this.currActivityIndex = 0;
  }
  hideSplashScreen() {
    _bnqkl_framework_plugins__WEBPACK_IMPORTED_MODULE_0__.SplashScreen.hide();
  }
  /** 当前激活的活动 */
  selectPointActivity(index) {
    this.currActivityIndex = index;
  }
}
_class = GuidePage;
_class.ɵfac = /*@__PURE__*/(() => {
  let ɵGuidePage_BaseFactory;
  return function GuidePage_Factory(t) {
    return (ɵGuidePage_BaseFactory || (ɵGuidePage_BaseFactory = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵgetInheritedFactory"](_class)))(t || _class);
  };
})();
_class.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineComponent"]({
  type: _class,
  selectors: [["w-guide-page"]],
  standalone: true,
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵInheritDefinitionFeature"], _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵStandaloneFeature"]],
  decls: 11,
  vars: 5,
  consts: [[3, "hideHeader", "footerTranslucent", "footerSafeArea", "footerBackground"], [1, "relative", "h-full"], ["wTabGroup", "", 1, "no-scrollbar", "relative", "z-[1]", "grid", "h-full", "w-full", "flex-grow", "grid-flow-col", "overflow-y-hidden", "overflow-x-scroll", 3, "selectedIndexChange$"], [1, "_slide-pager", "absolute", "bottom-4", "left-0", "z-10", "flex", "w-full", "items-center", "justify-center"], ["footer", "", 1, "px-[8%]", "py-3"], [1, "from-red-gradient-start", "to-red-gradient-end", "h-10.5", "flex", "w-full", "flex-col", "items-center", "justify-center", "rounded-full", "bg-gradient-to-b", "text-white", 3, "click"], ["wTab", "", 1, "_slide-item", "w-cqw-100", "relative", "mt-[6%]", "flex", "h-[89%]", "flex-col", "items-center", "justify-start", "overflow-hidden"], [1, "mb-7", "mt-8", "w-[72%]", 3, "src"], [1, "_promotion-view", "w-full"], [1, "_text-box", "px-[8%]", "text-left", "text-white"], [1, "mb-5", "text-4xl", "font-bold", 3, "innerHtml"], [1, "text-lg", 3, "innerHtml"], [1, "ml-2", "h-[8px]", "w-[8px]", "rounded-full", "first:ml-0", 3, "ngClass"], ["class", "_slide-item w-cqw-100 relative mt-[6%] flex h-[89%] flex-col items-center justify-start overflow-hidden", "wTab", ""], ["class", "ml-2 h-[8px] w-[8px] rounded-full first:ml-0", 3, "ngClass"]],
  template: function GuidePage_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "common-page", 0)(1, "div", 1)(2, "div", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("selectedIndexChange$", function GuidePage_Template_div_selectedIndexChange__2_listener($event) {
        return ctx.selectPointActivity($event);
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrepeaterCreate"](3, GuidePage_For_4_Template, 6, 3, "div", 13, _forTrack0);
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](5, "div", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrepeaterCreate"](6, GuidePage_For_7_Template, 1, 4, "div", 14, _forTrack0);
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](8, "div", 4)(9, "button", 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function GuidePage_Template_button_click_9_listener() {
        return ctx.enter.handle();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](10);
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()();
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("hideHeader", true)("footerTranslucent", false)("footerSafeArea", false)("footerBackground", "transparent");
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrepeater"](ctx.activitySlides);
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrepeater"](ctx.activitySlides);
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](4);
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate1"](" ", ctx.enter.text, " ");
    }
  },
  dependencies: [_modules_page_module__WEBPACK_IMPORTED_MODULE_1__.CommonPageModule, _libs_bnf_directives_tab_directive__WEBPACK_IMPORTED_MODULE_2__.TabGroupDirective, _libs_bnf_directives_tab_directive__WEBPACK_IMPORTED_MODULE_2__.TabDirective, _angular_common__WEBPACK_IMPORTED_MODULE_5__.NgClass, _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_3__.CommonPageComponent],
  styles: ["[_nghost-%COMP%]     common-page > section {\n    background-image: linear-gradient(to bottom, var(--tw-gradient-stops));\n    --tw-gradient-from: #a694f8 var(--tw-gradient-from-position);\n    --tw-gradient-to: rgb(166 148 248 / 0) var(--tw-gradient-to-position);\n    --tw-gradient-stops: var(--tw-gradient-from), var(--tw-gradient-to);\n    --tw-gradient-to: #8970ff var(--tw-gradient-to-position)\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL2FwcHMvd2FsbGV0L3NyYy9wYWdlcy9ndWlkZS9ndWlkZS5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFHTTtJQUFBLHNFQUFBO0lBQUEsNERBQUE7SUFBQSxxRUFBQTtJQUFBLG1FQUFBO0lBQUE7QUFBQSIsInNvdXJjZXNDb250ZW50IjpbIjpob3N0IHtcclxuICA6Om5nLWRlZXAge1xyXG4gICAgY29tbW9uLXBhZ2UgPiBzZWN0aW9uIHtcclxuICAgICAgQGFwcGx5IGZyb20tcHVycGxlLWdyYWRpZW50LXN0YXJ0IHRvLXB1cnBsZS1ncmFkaWVudC1lbmQgYmctZ3JhZGllbnQtdG8tYjtcclxuICAgIH1cclxuICB9XHJcbn1cclxuIl0sInNvdXJjZVJvb3QiOiIifQ== */"],
  changeDetection: 0
});
(0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([GuidePage.OnInit(), (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__metadata)("design:returntype", void 0)], GuidePage.prototype, "hideSplashScreen", null);
(0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([GuidePage.States(), (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__metadata)("design:type", Object)], GuidePage.prototype, "currActivityIndex", void 0);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (GuidePage);

/***/ })

}]);
//# sourceMappingURL=apps_wallet_src_pages_guide_guide_component_ts.js.map