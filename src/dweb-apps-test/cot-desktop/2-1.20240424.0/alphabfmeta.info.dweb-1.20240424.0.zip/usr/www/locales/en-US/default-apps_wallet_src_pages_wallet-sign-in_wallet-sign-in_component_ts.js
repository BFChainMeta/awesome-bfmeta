"use strict";
(self["webpackChunkwallet"] = self["webpackChunkwallet"] || []).push([["default-apps_wallet_src_pages_wallet-sign-in_wallet-sign-in_component_ts"],{

/***/ 38905:
/*!**************************************************************************!*\
  !*** ./apps/wallet/src/pages/wallet-sign-in/wallet-sign-in.component.ts ***!
  \**************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   WalletSignInPage: () => (/* binding */ WalletSignInPage),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 52542);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! tslib */ 90505);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @angular/core */ 61039);
/* harmony import */ var _bnqkl_framework_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @bnqkl/framework/core */ 63563);
/* harmony import */ var _bnqkl_framework_plugins_biometric__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @bnqkl/framework/plugins/biometric */ 52583);
/* harmony import */ var _bnqkl_framework_plugins_splash_screen__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @bnqkl/framework/plugins/splash-screen */ 71739);
/* harmony import */ var _bnqkl_framework_plugins_toast__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @bnqkl/framework/plugins/toast */ 18030);
/* harmony import */ var _components_input_hidden_icon_swap_input_hidden_icon_swap_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ~components/input-hidden-icon-swap/input-hidden-icon-swap.component */ 68027);
/* harmony import */ var _modules_page_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ~modules/page.module */ 77538);
/* harmony import */ var _pages_mime_pages_verify_fingerprint_verify_fingerprint_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ~pages/mime/pages/verify-fingerprint/verify-fingerprint.component */ 5780);
/* harmony import */ var _bnqkl_wallet_base_services_wallet_wallet__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @bnqkl/wallet-base/services/wallet/wallet */ 21789);
/* harmony import */ var _bnqkl_wallet_base_services_wallet__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @bnqkl/wallet-base/services/wallet */ 20609);
/* harmony import */ var _components_version_upgrade_version_upgrade_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ~components/version-upgrade/version-upgrade.service */ 8701);
/* harmony import */ var _libs_bnf_components_ripple_button_ripple_button_directive__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../../../../libs/bnf/components/ripple-button/ripple-button.directive */ 16505);
/* harmony import */ var _libs_bnf_directives_auto_complete_off_directive__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../../../../libs/bnf/directives/auto-complete-off.directive */ 66722);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @angular/common */ 6729);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @angular/forms */ 7820);
/* harmony import */ var _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../../../../../libs/bnf/modules/page/common-page/common-page.component */ 62052);
/* harmony import */ var _components_icon_icon_component__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../../components/icon/icon.component */ 74703);

var _class;



















function WalletSignInPage_div_7_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](0, "div", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtextInterpolate1"](" ", ctx_r0.passwordTips, " ");
  }
}
function WalletSignInPage_ng_container_14_Template(rf, ctx) {
  if (rf & 1) {
    const _r5 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](1, "button", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("click", function WalletSignInPage_ng_container_14_Template_button_click_1_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵrestoreView"](_r5);
      const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵresetView"](ctx_r4.checkFingerprint());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelement"](2, "w-icon", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](3, "button", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("click", function WalletSignInPage_ng_container_14_Template_button_click_3_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵrestoreView"](_r5);
      const ctx_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵresetView"](ctx_r6.switchType());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵi18n"](4, 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementContainerEnd"]();
  }
}
function WalletSignInPage_ng_template_15_button_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r9 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](0, "button", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("click", function WalletSignInPage_ng_template_15_button_2_Template_button_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵrestoreView"](_r9);
      const ctx_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵresetView"](ctx_r8.switchType());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵi18n"](1, 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
  }
}
function WalletSignInPage_ng_template_15_Template(rf, ctx) {
  if (rf & 1) {
    const _r11 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](0, "button", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("click", function WalletSignInPage_ng_template_15_Template_button_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵrestoreView"](_r11);
      const ctx_r10 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵresetView"](ctx_r10.submit());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵi18n"](1, 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](2, WalletSignInPage_ng_template_15_button_2_Template, 2, 0, "button", 23);
  }
  if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("disabled", !ctx_r2.inputPassword);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngIf", ctx_r2.showFingerprint);
  }
}
const _c12 = a0 => ({
  "pointer-events-none": a0
});
/** 身份钱包存在的登录页面 */
class WalletSignInPage extends _modules_page_module__WEBPACK_IMPORTED_MODULE_6__.CommonPageBase {
  constructor() {
    super(...arguments);
    /** 页面返回值的类型 */
    this.returnValue$ = new _bnqkl_framework_core__WEBPACK_IMPORTED_MODULE_1__.PageReturnValue();
    /** 存储服务 */
    this.walletDataStorageV2Service = (0,_angular_core__WEBPACK_IMPORTED_MODULE_15__.inject)(_bnqkl_wallet_base_services_wallet__WEBPACK_IMPORTED_MODULE_9__.WalletDataStorageV2Service);
    /** 只校验密码 */
    this.onlyPwd = false;
    /** 后台验证 */
    this.backgroundVerification = false;
    /** 密码是否可见 */
    this.showPwd = false;
    /** 钱包名称 */
    this.walletName = '';
    /** 密码提示 */
    this.passwordTips = '';
    /** 身份钱包设置的密码 */
    this._mainWalletPassword = '';
    /** 用户输入的密码 */
    this.inputPassword = '';
    /** 密码错误提示 */
    this.showPasswordErrorTips = false;
    /** 指纹验证 */
    this.showFingerprint = false;
    /** 密码登录类型 */
    this.pwdType = true;
    /** 指纹被禁用 */
    this.fingerprintProhibited = false;
    /** 返回按钮服务 */
    this._backButtonPriority = (0,_angular_core__WEBPACK_IMPORTED_MODULE_15__.inject)(_bnqkl_framework_core__WEBPACK_IMPORTED_MODULE_1__.CommonBackButtonPriority).registryInCompPrevent(this);
    /** 是否可以使用 */
    this.canUse = false;
  }
  /** 隐藏欢迎屏 */
  hideSplashScreen() {
    _bnqkl_framework_plugins_splash_screen__WEBPACK_IMPORTED_MODULE_3__.SplashScreen.hide();
  }
  /** 获取身份钱包设置的密码 */
  getMainPasswordInfo() {
    var _this = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this._mainWalletPassword = _this.walletDataStorageV2Service.walletAppSettings.password;
      /// 必须是没有更新任务情况下才可以关闭
      const versionUpgradeService = _this.injectorForceGet(_components_version_upgrade_version_upgrade_service__WEBPACK_IMPORTED_MODULE_10__.VersionUpgradeService);
      yield versionUpgradeService.needUpgradeApp.waitClose.promise;
      _this.canUse = true;
      if (_this.walletDataStorageV2Service.walletAppSettings.fingerprintLock) {
        try {
          /// 判断是否开启
          const info = yield _bnqkl_framework_plugins_biometric__WEBPACK_IMPORTED_MODULE_2__.NativeBiometric.isAvailable();
          _this.console.log(info);
          if (info.isAvailable === false) {
            /// 开启了，但是系统取消了，需要使用密码关闭
            _bnqkl_framework_plugins_toast__WEBPACK_IMPORTED_MODULE_4__.Toast.show("Fingerprint verification cannot be started, please use password verification");
            _this.showFingerprint = false;
          } else {
            _this.showFingerprint = true;
            /// 判断是否被系统禁用
            _this.fingerprintProhibited = !!sessionStorage.getItem(_pages_mime_pages_verify_fingerprint_verify_fingerprint_component__WEBPACK_IMPORTED_MODULE_7__.FINGERPRINT_PROHIBITION_OF_USE);
            if (_this.fingerprintProhibited === false) {
              _this.pwdType = false;
              _this.checkFingerprint(true);
            }
          }
        } catch (err) {
          /// 用不了的情况下，提示用密码
          _this.console.error('NativeBiometric.isAvailable:', err);
          /// 开启了，但是系统取消了，需要使用密码关闭
          _bnqkl_framework_plugins_toast__WEBPACK_IMPORTED_MODULE_4__.Toast.show("Fingerprint verification cannot be started, please use password verification");
          _this.showFingerprint = false;
        }
      } else {
        _this.showFingerprint = false;
      }
      if (_this.onlyPwd && (_this.onlyPwd === true || _this.onlyPwd === 'true')) {
        _this.showFingerprint = false;
      }
      _this.passwordTips = _this.walletDataStorageV2Service.walletAppSettings.passwordTips || '';
    })();
  }
  /** 校验密码 */
  submit(skipPwd = false) {
    var _this2 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      if (skipPwd || _this2.inputPassword == _this2._mainWalletPassword) {
        _this2.showPasswordErrorTips = false;
        /// 该参数返回是为了关闭/开启指纹功能，如果有别的页面需要这个，需要自己补充判断
        if (_this2.onlyPwd && (_this2.onlyPwd === true || _this2.onlyPwd === 'true')) {
          _this2.returnValue$.next(true);
        }
        if (_this2.onlyPwd && (_this2.onlyPwd === true || _this2.onlyPwd === 'true') || _this2.backgroundVerification && (_this2.backgroundVerification === true || _this2.backgroundVerification === 'true')) {
          return _this2.nav.back();
        }
        yield _this2.injectorForceGet(_bnqkl_wallet_base_services_wallet_wallet__WEBPACK_IMPORTED_MODULE_8__.WalletV2Service).upDateActivateAddressWallet();
        sessionStorage.removeItem(_pages_mime_pages_verify_fingerprint_verify_fingerprint_component__WEBPACK_IMPORTED_MODULE_7__.FINGERPRINT_INTERVAL_SESSION_KEY);
        /** 判断成功跳转到主页 */
        const navigatorService = _this2.injectorForceGet(_bnqkl_framework_core__WEBPACK_IMPORTED_MODULE_1__.NavigatorService);
        return navigatorService.setPageRoot('tabs');
      }
      _bnqkl_framework_plugins_toast__WEBPACK_IMPORTED_MODULE_4__.Toast.show(" Password inout error");
      return;
    })();
  }
  /** 切换模式 */
  switchType() {
    if (this.fingerprintProhibited) {
      _bnqkl_framework_plugins_toast__WEBPACK_IMPORTED_MODULE_4__.Toast.show("System fingerprinting has been disabled");
      return;
    }
    if (this.showFingerprint !== true) {
      return;
    }
    if (this.pwdType) {
      this.showPasswordErrorTips = false;
      this.inputPassword = '';
    }
    if (this.pwdType === true) {
      const hasFingerprint = this.checkFingerprintTimestamp();
      if (hasFingerprint === false) {
        return;
      }
    }
    this.pwdType = !this.pwdType;
    this.pwdType === false && this.checkFingerprint(true);
  }
  checkFingerprintTimestamp(skip = false) {
    const fingerprintTimestamp = Number(sessionStorage.getItem(_pages_mime_pages_verify_fingerprint_verify_fingerprint_component__WEBPACK_IMPORTED_MODULE_7__.FINGERPRINT_INTERVAL_SESSION_KEY) || 0);
    if (skip === false && fingerprintTimestamp > 0) {
      const interval = Date.now() - fingerprintTimestamp;
      if (interval < 30 * 1000) {
        const waiting = 30 - Math.floor(interval / 1000);
        _bnqkl_framework_plugins_toast__WEBPACK_IMPORTED_MODULE_4__.Toast.show("Please try again in " + waiting + " seconds");
        return false;
      }
    }
    return true;
  }
  /** 校验指纹 */
  checkFingerprint(skip = false) {
    var _this3 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      /// 判断下间隔
      const hasFingerprint = _this3.checkFingerprintTimestamp(skip);
      if (hasFingerprint === false) {
        return;
      }
      const {
        success,
        code
      } = yield _bnqkl_framework_plugins_biometric__WEBPACK_IMPORTED_MODULE_2__.NativeBiometric.verifyIdentity({
        maxAttempts: 5,
        title: "Verify Fingerprint",
        negativeButtonText: "Cancel"
      });
      if (success) {
        return _this3.submit(true);
      } else if (code != undefined) {
        if (code === 0) {
          const confirmed = yield _this3.confirm({
            bodyMessage: "Fingerprint verification failed",
            confirmText: "Try again",
            cancelText: "Login with password",
            footerTheme: 'blank'
          });
          if (confirmed) {
            _this3.checkFingerprint();
          } else {
            _this3.switchType();
          }
        } else if (code === 7) {
          sessionStorage.setItem(_pages_mime_pages_verify_fingerprint_verify_fingerprint_component__WEBPACK_IMPORTED_MODULE_7__.FINGERPRINT_INTERVAL_SESSION_KEY, String(Date.now()));
          const waiting = 30;
          _bnqkl_framework_plugins_toast__WEBPACK_IMPORTED_MODULE_4__.Toast.show("Please try again in " + waiting + " seconds");
          _this3.switchType();
          return;
        } else if (code === 9) {
          localStorage.setItem(_pages_mime_pages_verify_fingerprint_verify_fingerprint_component__WEBPACK_IMPORTED_MODULE_7__.FINGERPRINT_PROHIBITION_OF_USE, '1');
          yield _this3.alert({
            bodyMessage: "Fingerprint verification cannot be started, please use password verification"
          });
          _this3.switchType();
          return;
        }
      }
    })();
  }
}
_class = WalletSignInPage;
_class.ɵfac = /*@__PURE__*/(() => {
  let ɵWalletSignInPage_BaseFactory;
  return function WalletSignInPage_Factory(t) {
    return (ɵWalletSignInPage_BaseFactory || (ɵWalletSignInPage_BaseFactory = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵgetInheritedFactory"](_class)))(t || _class);
  };
})();
_class.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵdefineComponent"]({
  type: _class,
  selectors: [["w-wallet-sign-in-page"]],
  outputs: {
    returnValue$: "returnValue$"
  },
  standalone: true,
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵInheritDefinitionFeature"], _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵStandaloneFeature"]],
  decls: 17,
  vars: 19,
  consts: () => {
    let i18n_0;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_APP_SHORT_NAME$$APPS_WALLET_SRC_PAGES_WALLET_SIGN_IN_WALLET_SIGN_IN_COMPONENT_TS_1 = goog.getMsg("COT");
      i18n_0 = MSG_EXTERNAL_APP_SHORT_NAME$$APPS_WALLET_SRC_PAGES_WALLET_SIGN_IN_WALLET_SIGN_IN_COMPONENT_TS_1;
    } else {
      i18n_0 = "COT";
    }
    let i18n_2;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_ENTER_THE_IDENTITY_WALLET_PASSWORD$$APPS_WALLET_SRC_PAGES_WALLET_SIGN_IN_WALLET_SIGN_IN_COMPONENT_TS_3 = goog.getMsg("Enter the wallet password");
      i18n_2 = MSG_EXTERNAL_ENTER_THE_IDENTITY_WALLET_PASSWORD$$APPS_WALLET_SRC_PAGES_WALLET_SIGN_IN_WALLET_SIGN_IN_COMPONENT_TS_3;
    } else {
      i18n_2 = "Enter the wallet password";
    }
    let i18n_4;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_PASSWORD_INOUT_ERROR$$APPS_WALLET_SRC_PAGES_WALLET_SIGN_IN_WALLET_SIGN_IN_COMPONENT_TS_5 = goog.getMsg(" Password inout error. ");
      i18n_4 = MSG_EXTERNAL_PASSWORD_INOUT_ERROR$$APPS_WALLET_SRC_PAGES_WALLET_SIGN_IN_WALLET_SIGN_IN_COMPONENT_TS_5;
    } else {
      i18n_4 = " Password inout error. ";
    }
    let i18n_6;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_LOGIN_WITH_IDENTITY_WALLET_PASSWORD$$APPS_WALLET_SRC_PAGES_WALLET_SIGN_IN_WALLET_SIGN_IN_COMPONENT_TS__7 = goog.getMsg(" Login with wallet password ");
      i18n_6 = MSG_EXTERNAL_LOGIN_WITH_IDENTITY_WALLET_PASSWORD$$APPS_WALLET_SRC_PAGES_WALLET_SIGN_IN_WALLET_SIGN_IN_COMPONENT_TS__7;
    } else {
      i18n_6 = " Login with wallet password ";
    }
    let i18n_8;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_CONFIRM$$APPS_WALLET_SRC_PAGES_WALLET_SIGN_IN_WALLET_SIGN_IN_COMPONENT_TS__9 = goog.getMsg(" Confirm ");
      i18n_8 = MSG_EXTERNAL_CONFIRM$$APPS_WALLET_SRC_PAGES_WALLET_SIGN_IN_WALLET_SIGN_IN_COMPONENT_TS__9;
    } else {
      i18n_8 = " Confirm ";
    }
    let i18n_10;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_LOGIN_WITH_FINGERPRINT_VERIFICATION$$APPS_WALLET_SRC_PAGES_WALLET_SIGN_IN_WALLET_SIGN_IN_COMPONENT_TS___11 = goog.getMsg(" Login with Fingerprint Verification ");
      i18n_10 = MSG_EXTERNAL_LOGIN_WITH_FINGERPRINT_VERIFICATION$$APPS_WALLET_SRC_PAGES_WALLET_SIGN_IN_WALLET_SIGN_IN_COMPONENT_TS___11;
    } else {
      i18n_10 = " Login with Fingerprint Verification ";
    }
    return [[3, "contentBackground", "footerTranslucent", "headerBackground", "headerTranslucent", "hideHeaderTitle", "headerButtonColor", "backButtonDisable", "ngClass"], [1, "flex", "min-h-full", "flex-col", "items-center", "justify-center", "text-center"], [1, "flex", "h-full", "flex-col", "items-center", "justify-center"], ["src", "./assets/images/logo.png", 1, "h-27", "w-27", "mx-auto"], [1, "mb-7", "mt-2", "text-center", "text-2xl", "font-semibold", "text-white"], i18n_0, [1, "mb-16", "w-full", "px-5", 3, "ngClass"], ["class", "mb-3 text-sm text-white", 4, "ngIf"], [1, "bg-env/10", "flex", "h-12", "items-stretch", "rounded-lg", "pr-4"], ["placeholder", i18n_2, 1, "w-full", "px-3", "text-white", "placeholder:text-white/60", 3, "ngModel", "type", "ngModelChange"], [1, "text-2xl", "text-white/60", 3, "show", "showChange"], [1, "text-error", "mt-1", "text-xs"], i18n_4, ["footer", "", 1, "grid", "place-items-center", "gap-6"], [4, "ngIf", "ngIfElse"], ["pwdLogin", ""], [1, "mb-3", "text-sm", "text-white"], ["bnRippleButton", "", "type", "button", 3, "click"], ["name", "al-touch-id", 1, "icon-10.5", "text-white"], ["bnRippleButton", "", 1, "text-white", 3, "click"], i18n_6, ["bnRippleButton", "", "type", "button", 1, "h-10.5", "text-primary-2", "w-full", "rounded-full", "bg-white", "text-center", 3, "disabled", "click"], i18n_8, ["bnRippleButton", "", "class", "text-white", 3, "click", 4, "ngIf"], i18n_10];
  },
  template: function WalletSignInPage_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](0, "common-page", 0)(1, "div", 1)(2, "div", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelement"](3, "img", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](4, "div", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵi18n"](5, 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](6, "div", 6);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](7, WalletSignInPage_div_7_Template, 2, 1, "div", 7);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](8, "div", 8)(9, "input", 9);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("ngModelChange", function WalletSignInPage_Template_input_ngModelChange_9_listener($event) {
        return ctx.inputPassword = $event;
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](10, "w-input-hidden-icon-swap", 10);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("showChange", function WalletSignInPage_Template_w_input_hidden_icon_swap_showChange_10_listener($event) {
        return ctx.showPwd = $event;
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](11, "div", 11);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵi18n"](12, 12);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]()()();
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](13, "div", 13);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](14, WalletSignInPage_ng_container_14_Template, 5, 0, "ng-container", 14)(15, WalletSignInPage_ng_template_15_Template, 3, 2, "ng-template", null, 15, _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplateRefExtractor"]);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]()();
    }
    if (rf & 2) {
      const _r3 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵreference"](16);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("contentBackground", "primary")("footerTranslucent", false)("headerBackground", "primary")("headerTranslucent", false)("hideHeaderTitle", true)("headerButtonColor", "light")("backButtonDisable", !ctx.onlyPwd)("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpureFunction1"](17, _c12, !ctx.canUse));
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](6);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngClass", !ctx.pwdType ? "pointer-events-none opacity-0" : "");
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngIf", !!ctx.passwordTips);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngModel", ctx.inputPassword)("type", ctx.showPwd ? "text" : "password");
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("show", ctx.showPwd);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵclassProp"]("opacity-0", !ctx.showPasswordErrorTips);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngIf", ctx.pwdType === false)("ngIfElse", _r3);
    }
  },
  dependencies: [_modules_page_module__WEBPACK_IMPORTED_MODULE_6__.CommonPageModule, _libs_bnf_components_ripple_button_ripple_button_directive__WEBPACK_IMPORTED_MODULE_11__.RippleButtonDirective, _libs_bnf_directives_auto_complete_off_directive__WEBPACK_IMPORTED_MODULE_12__.AutoCompleteOffDirective, _angular_common__WEBPACK_IMPORTED_MODULE_16__.NgClass, _angular_common__WEBPACK_IMPORTED_MODULE_16__.NgIf, _angular_forms__WEBPACK_IMPORTED_MODULE_17__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_17__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_17__.NgModel, _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_13__.CommonPageComponent, _components_icon_icon_component__WEBPACK_IMPORTED_MODULE_14__.IconComponent, _components_input_hidden_icon_swap_input_hidden_icon_swap_component__WEBPACK_IMPORTED_MODULE_5__["default"]],
  styles: ["/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsInNvdXJjZVJvb3QiOiIifQ== */"],
  changeDetection: 0
});
(0,tslib__WEBPACK_IMPORTED_MODULE_18__.__decorate)([WalletSignInPage.State(), WalletSignInPage.QueryParam('onlyPwd'), (0,tslib__WEBPACK_IMPORTED_MODULE_18__.__metadata)("design:type", Object)], WalletSignInPage.prototype, "onlyPwd", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_18__.__decorate)([WalletSignInPage.State(), WalletSignInPage.QueryParam('backgroundVerification'), (0,tslib__WEBPACK_IMPORTED_MODULE_18__.__metadata)("design:type", Object)], WalletSignInPage.prototype, "backgroundVerification", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_18__.__decorate)([WalletSignInPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_18__.__metadata)("design:type", Object)], WalletSignInPage.prototype, "showPwd", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_18__.__decorate)([WalletSignInPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_18__.__metadata)("design:type", Object)], WalletSignInPage.prototype, "walletName", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_18__.__decorate)([WalletSignInPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_18__.__metadata)("design:type", Object)], WalletSignInPage.prototype, "passwordTips", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_18__.__decorate)([WalletSignInPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_18__.__metadata)("design:type", Object)], WalletSignInPage.prototype, "inputPassword", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_18__.__decorate)([WalletSignInPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_18__.__metadata)("design:type", Object)], WalletSignInPage.prototype, "showPasswordErrorTips", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_18__.__decorate)([WalletSignInPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_18__.__metadata)("design:type", Object)], WalletSignInPage.prototype, "showFingerprint", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_18__.__decorate)([WalletSignInPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_18__.__metadata)("design:type", Object)], WalletSignInPage.prototype, "pwdType", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_18__.__decorate)([WalletSignInPage.OnInit(), (0,tslib__WEBPACK_IMPORTED_MODULE_18__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_18__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_18__.__metadata)("design:returntype", void 0)], WalletSignInPage.prototype, "hideSplashScreen", null);
(0,tslib__WEBPACK_IMPORTED_MODULE_18__.__decorate)([WalletSignInPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_18__.__metadata)("design:type", Object)], WalletSignInPage.prototype, "canUse", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_18__.__decorate)([WalletSignInPage.OnInit(), (0,tslib__WEBPACK_IMPORTED_MODULE_18__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_18__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_18__.__metadata)("design:returntype", Promise)], WalletSignInPage.prototype, "getMainPasswordInfo", null);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (WalletSignInPage);

/***/ })

}]);
//# sourceMappingURL=default-apps_wallet_src_pages_wallet-sign-in_wallet-sign-in_component_ts.js.map