"use strict";
(self["webpackChunkwallet"] = self["webpackChunkwallet"] || []).push([["apps_wallet_src_pages_mnemonic_pages_mnemonic-create-wallet_mnemonic-create-wallet_component_ts"],{

/***/ 49674:
/*!*********************************************************************************************************!*\
  !*** ./apps/wallet/src/pages/mnemonic/pages/mnemonic-create-wallet/mnemonic-create-wallet.component.ts ***!
  \*********************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   MnemonicCreateWalletPage: () => (/* binding */ MnemonicCreateWalletPage),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! tslib */ 90505);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/core */ 61039);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/forms */ 7820);
/* harmony import */ var _bnqkl_framework_controllers__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @bnqkl/framework/controllers */ 47919);
/* harmony import */ var _bnqkl_framework_plugins_keyboard__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @bnqkl/framework/plugins/keyboard */ 87717);
/* harmony import */ var _components_input_hidden_icon_swap_input_hidden_icon_swap_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ~components/input-hidden-icon-swap/input-hidden-icon-swap.component */ 68027);
/* harmony import */ var _modules_page_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ~modules/page.module */ 77538);
/* harmony import */ var _bnqkl_wallet_base_services_wallet_bip39__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @bnqkl/wallet-base/services/wallet/bip39 */ 76659);
/* harmony import */ var _libs_bnf_modules_bottom_sheet_components_bottom_sheet_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../../../../../libs/bnf/modules/bottom-sheet/components/bottom-sheet.component */ 94072);
/* harmony import */ var _libs_bnf_components_ripple_button_ripple_button_directive__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../../../../../libs/bnf/components/ripple-button/ripple-button.directive */ 16505);
/* harmony import */ var _libs_bnf_directives_form_errors_directive__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../../../../../libs/bnf/directives/form-errors.directive */ 29541);
/* harmony import */ var _libs_bnf_directives_auto_complete_off_directive__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../../../../../libs/bnf/directives/auto-complete-off.directive */ 66722);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @angular/common */ 6729);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @angular/router */ 56776);
/* harmony import */ var _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../../../../../../libs/bnf/modules/page/common-page/common-page.component */ 62052);
/* harmony import */ var _components_icon_icon_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../../../components/icon/icon.component */ 74703);
/* harmony import */ var _libs_bnf_pipes_errors_errors_pipe__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../../../../../../libs/bnf/pipes/errors/errors.pipe */ 68362);
/* harmony import */ var _pipes_color_color_pipe__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../../../pipes/color/color.pipe */ 76489);
var _class;




















function MnemonicCreateWalletPage_ng_template_8_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵi18n"](1, 44);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementContainerEnd"]();
  }
}
function MnemonicCreateWalletPage_ng_template_9_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵi18n"](1, 45);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const error_r14 = ctx.$error;
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵi18nExp"](error_r14.requiredLength);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵi18nApply"](1);
  }
}
function MnemonicCreateWalletPage_ng_template_19_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵi18n"](1, 46);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementContainerEnd"]();
  }
}
function MnemonicCreateWalletPage_ng_template_20_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵi18n"](1, 47);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const error_r16 = ctx.$error;
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵi18nExp"](error_r16.requiredLength);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵi18nApply"](1);
  }
}
function MnemonicCreateWalletPage_ng_template_21_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵi18n"](1, 48);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const error_r17 = ctx.$error;
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵi18nExp"](error_r17.requiredLength);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵi18nApply"](1);
  }
}
function MnemonicCreateWalletPage_ng_template_22_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵi18n"](1, 49);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementContainerEnd"]();
  }
}
function MnemonicCreateWalletPage_ng_template_23_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵi18n"](1, 50);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementContainerEnd"]();
  }
}
function MnemonicCreateWalletPage_ng_template_24_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵi18n"](1, 51);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementContainerEnd"]();
  }
}
function MnemonicCreateWalletPage_ng_template_25_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](0);
  }
  if (rf & 2) {
    const errors_r19 = ctx.$errors;
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtextInterpolate1"](" ", errors_r19, " ");
  }
}
function MnemonicCreateWalletPage_div_30_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div", 52);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](1, "w-icon", 53);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](2, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵi18n"](3, 54);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
  }
}
function MnemonicCreateWalletPage_div_40_div_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵi18n"](1, 56);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const errors_r20 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"]().ngIf;
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵi18nExp"](errors_r20 == null ? null : errors_r20["maxlength"] == null ? null : errors_r20["maxlength"].requiredLength);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵi18nApply"](1);
  }
}
function MnemonicCreateWalletPage_div_40_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div", 55);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](1, MnemonicCreateWalletPage_div_40_div_1_Template, 2, 1, "div", 39);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r10 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", ctx_r10.tip.errors == null ? null : ctx_r10.tip.errors["maxlength"]);
  }
}
function MnemonicCreateWalletPage_span_63_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵi18nStart"](0, 38, 1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](1, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵi18nEnd"]();
  }
}
function MnemonicCreateWalletPage_span_65_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵi18nStart"](0, 38, 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](1, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵi18nEnd"]();
  }
}
function MnemonicCreateWalletPage_ng_template_69_button_3_Template(rf, ctx) {
  if (rf & 1) {
    const _r28 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "button", 61);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("click", function MnemonicCreateWalletPage_ng_template_69_button_3_Template_button_click_0_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r28);
      const item_r25 = restoredCtx.$implicit;
      const ctx_r27 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵresetView"](ctx_r27.getChange(item_r25));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](1, "div", 62);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const item_r25 = ctx.$implicit;
    const last_r26 = ctx.last;
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngClass", last_r26 ? "border-0" : "border-b-[0.5px]");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtextInterpolate1"](" ", item_r25.text, " ");
  }
}
function MnemonicCreateWalletPage_ng_template_69_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "common-page", 57, 58)(2, "div", 59);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](3, MnemonicCreateWalletPage_ng_template_69_button_3_Template, 3, 2, "button", 60);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r13 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("headerTitle", ctx_r13.mnemonicBottomSheetInfo.title);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngForOf", ctx_r13.mnemonicBottomSheetInfo.data);
  }
}
const _c44 = a0 => ({
  "text-error": a0
});
const _c45 = (a0, a1) => ({
  pwd: a0,
  cpwd: a1
});
const _c46 = a0 => ({
  "--color-1": a0
});
const _c47 = () => ["/mnemonic/user-agreement"];
/**
 * 创建钱包页面
 */
class MnemonicCreateWalletPage extends _modules_page_module__WEBPACK_IMPORTED_MODULE_3__.CommonPageBase {
  constructor() {
    super(...arguments);
    /** 键盘是否弹出 */
    this.keyboardShow = false;
    /** 键盘状态监听 */
    this.getKeyboardInfo = _bnqkl_framework_plugins_keyboard__WEBPACK_IMPORTED_MODULE_1__.Keyboard.getKeyboardInfo$().subscribe(data => {
      this.keyboardShow = data.height > 0;
    });
    /** 表单验证服务 */
    this.validators = new _bnqkl_framework_controllers__WEBPACK_IMPORTED_MODULE_0__.FormValidatorsController(this);
    /** 是否为汉语 */
    this.isZh = this.injectorGet(_angular_core__WEBPACK_IMPORTED_MODULE_13__.LOCALE_ID) === 'zh-Hant' || this.injectorGet(_angular_core__WEBPACK_IMPORTED_MODULE_13__.LOCALE_ID) === 'zh-Hans';
    /** 是否显示密码 */
    this.showPwd = false;
    /** 是否显示确认密码 */
    this.showCPwd = false;
    /** 是否显示密码的顶部提示 */
    this.showPwdTip = false;
    /** 钱包名称 */
    this.name = new _angular_forms__WEBPACK_IMPORTED_MODULE_14__.FormControl('', {
      nonNullable: true,
      validators: [this.validators.trimRequired, _angular_forms__WEBPACK_IMPORTED_MODULE_14__.Validators.maxLength(12)]
    });
    /** 密码 */
    this.pwd = new _angular_forms__WEBPACK_IMPORTED_MODULE_14__.FormControl('', {
      nonNullable: true,
      validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_14__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_14__.Validators.minLength(8), _angular_forms__WEBPACK_IMPORTED_MODULE_14__.Validators.maxLength(30), this.validators.whitespace]
    });
    /** 确认密码 */
    this.cpwd = new _angular_forms__WEBPACK_IMPORTED_MODULE_14__.FormControl('', {
      nonNullable: true,
      validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_14__.Validators.required, this.validators.equals(this.pwd)]
    });
    /** 是否勾选用户协议 */
    this.checked = new _angular_forms__WEBPACK_IMPORTED_MODULE_14__.FormControl(false, [_angular_forms__WEBPACK_IMPORTED_MODULE_14__.Validators.requiredTrue]);
    /** 密码提示 */
    this.tip = new _angular_forms__WEBPACK_IMPORTED_MODULE_14__.FormControl('', {
      nonNullable: true,
      validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_14__.Validators.maxLength(50)]
    });
    /** 要提交的表单与复合验证 */
    this.form = new _angular_forms__WEBPACK_IMPORTED_MODULE_14__.FormGroup({
      name: this.name,
      pwd: this.pwd,
      cpwd: this.cpwd,
      tip: this.tip,
      checked: this.checked
    }, {
      validators: [],
      asyncValidators: []
    });
    /** 底部选择器 */
    this.mnemonicBottomSheetInfo = {
      title: '',
      data: [],
      open: false
    };
    /** 助剂词信息 */
    this.mnemonicInfo = {
      length: 12,
      language: _bnqkl_wallet_base_services_wallet_bip39__WEBPACK_IMPORTED_MODULE_4__.MNEMONIC_LANGUAGE.english,
      text: "English"
    };
  }
  /** 选择语言 */
  selectLanguage() {
    this.mnemonicBottomSheetInfo.title = "\u9009\u62E9\u52A9\u8BB0\u8BCD\u8BED\u8A00";
    this.mnemonicBottomSheetInfo.data = [{
      type: 'language',
      text: "English",
      value: _bnqkl_wallet_base_services_wallet_bip39__WEBPACK_IMPORTED_MODULE_4__.MNEMONIC_LANGUAGE.english
    }, {
      type: 'language',
      text: "\u4E2D\u6587\uFF08\u7B80\u4F53\uFF09",
      value: _bnqkl_wallet_base_services_wallet_bip39__WEBPACK_IMPORTED_MODULE_4__.MNEMONIC_LANGUAGE.chineseSimplified
    }, {
      type: 'language',
      text: "\u4E2D\u6587\uFF08\u7E41\u9AD4\uFF09",
      value: _bnqkl_wallet_base_services_wallet_bip39__WEBPACK_IMPORTED_MODULE_4__.MNEMONIC_LANGUAGE.chineseTraditional
    }];
    this.mnemonicBottomSheetInfo.open = true;
  }
  /** 选择长度 */
  selectLength() {
    this.mnemonicBottomSheetInfo.title = "\u9009\u62E9\u52A9\u8BB0\u8BCD\u6570\u91CF";
    this.mnemonicBottomSheetInfo.data = [12, 15, 18, 21, 24, 36].map(item => {
      return {
        type: 'length',
        text: `${item} ${"\u4E2A\u5B57"}`,
        value: item
      };
    });
    this.mnemonicBottomSheetInfo.open = true;
  }
  getChange(item) {
    if (item) {
      if (item.type === 'language') {
        this.mnemonicInfo.language = item.value;
        this.mnemonicInfo.text = item.text;
      } else {
        this.mnemonicInfo.length = item.value;
      }
    }
    this.mnemonicBottomSheetInfo.open = false;
    this.cdRef.detectChanges();
  }
  /** 提交事件 */
  onSubmit() {
    // 基本参数传递到
    this.nav.routeTo('/mnemonic/mnemonic-backup-tips', Object.assign(this.form.value, {
      skipBackup: true,
      ...this.mnemonicInfo
    }));
  }
}
_class = MnemonicCreateWalletPage;
_class.ɵfac = /*@__PURE__*/(() => {
  let ɵMnemonicCreateWalletPage_BaseFactory;
  return function MnemonicCreateWalletPage_Factory(t) {
    return (ɵMnemonicCreateWalletPage_BaseFactory || (ɵMnemonicCreateWalletPage_BaseFactory = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵgetInheritedFactory"](_class)))(t || _class);
  };
})();
_class.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdefineComponent"]({
  type: _class,
  selectors: [["w-mnemonic-create-wallet-page"]],
  standalone: true,
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵInheritDefinitionFeature"], _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵStandaloneFeature"]],
  decls: 70,
  vars: 76,
  consts: () => {
    let i18n_0;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_CREATE_WALLET$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_MNEMONIC_CREATE_WALLET_MNEMONIC_CREATE_WALLET_COMPONENT_TS_1 = goog.getMsg("Create Wallet");
      i18n_0 = MSG_EXTERNAL_CREATE_WALLET$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_MNEMONIC_CREATE_WALLET_MNEMONIC_CREATE_WALLET_COMPONENT_TS_1;
    } else {
      i18n_0 = "\u521B\u5EFA\u94B1\u5305";
    }
    let i18n_2;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_WALLET_NAME$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_MNEMONIC_CREATE_WALLET_MNEMONIC_CREATE_WALLET_COMPONENT_TS_3 = goog.getMsg(" Wallet Name ");
      i18n_2 = MSG_EXTERNAL_WALLET_NAME$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_MNEMONIC_CREATE_WALLET_MNEMONIC_CREATE_WALLET_COMPONENT_TS_3;
    } else {
      i18n_2 = "\u94B1\u5305\u540D\u79F0";
    }
    let i18n_4;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_ENTER_CHARACTERS$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_MNEMONIC_CREATE_WALLET_MNEMONIC_CREATE_WALLET_COMPONENT_TS_5 = goog.getMsg("Enter 1-12 characters");
      i18n_4 = MSG_EXTERNAL_ENTER_CHARACTERS$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_MNEMONIC_CREATE_WALLET_MNEMONIC_CREATE_WALLET_COMPONENT_TS_5;
    } else {
      i18n_4 = "\u8F93\u51651~12\u4E2A\u5B57\u7B26";
    }
    let i18n_6;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_WALLET_PASSWORD$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_MNEMONIC_CREATE_WALLET_MNEMONIC_CREATE_WALLET_COMPONENT_TS_7 = goog.getMsg(" Wallet Password ");
      i18n_6 = MSG_EXTERNAL_WALLET_PASSWORD$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_MNEMONIC_CREATE_WALLET_MNEMONIC_CREATE_WALLET_COMPONENT_TS_7;
    } else {
      i18n_6 = "\u94B1\u5305\u5BC6\u7801";
    }
    let i18n_8;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_PASSWORD_IS_NOT_LESS_THAN_DIGITS$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_MNEMONIC_CREATE_WALLET_MNEMONIC_CREATE_WALLET_COMPONENT_TS_9 = goog.getMsg("Password is not less than 8 digits");
      i18n_8 = MSG_EXTERNAL_PASSWORD_IS_NOT_LESS_THAN_DIGITS$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_MNEMONIC_CREATE_WALLET_MNEMONIC_CREATE_WALLET_COMPONENT_TS_9;
    } else {
      i18n_8 = "\u5BC6\u7801\u81F3\u5C118\u4E2A\u5B57\u7B26";
    }
    let i18n_10;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_REPEAT_PASSWORD$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_MNEMONIC_CREATE_WALLET_MNEMONIC_CREATE_WALLET_COMPONENT_TS_11 = goog.getMsg("Repeat Password ");
      i18n_10 = MSG_EXTERNAL_REPEAT_PASSWORD$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_MNEMONIC_CREATE_WALLET_MNEMONIC_CREATE_WALLET_COMPONENT_TS_11;
    } else {
      i18n_10 = "\u786E\u8BA4\u5BC6\u7801";
    }
    let i18n_12;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_PASSWORD_HINT_OPTIONAL$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_MNEMONIC_CREATE_WALLET_MNEMONIC_CREATE_WALLET_COMPONENT_TS_13 = goog.getMsg(" Password Hint (optional) ");
      i18n_12 = MSG_EXTERNAL_PASSWORD_HINT_OPTIONAL$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_MNEMONIC_CREATE_WALLET_MNEMONIC_CREATE_WALLET_COMPONENT_TS_13;
    } else {
      i18n_12 = "\u5BC6\u7801\u63D0\u793A\uFF08\u53EF\u9009\uFF09";
    }
    let i18n_14;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_ENTER_PASSWORD_PROMPT_INFORMATION$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_MNEMONIC_CREATE_WALLET_MNEMONIC_CREATE_WALLET_COMPONENT_TS_15 = goog.getMsg("Enter password prompt information ");
      i18n_14 = MSG_EXTERNAL_ENTER_PASSWORD_PROMPT_INFORMATION$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_MNEMONIC_CREATE_WALLET_MNEMONIC_CREATE_WALLET_COMPONENT_TS_15;
    } else {
      i18n_14 = "\u8F93\u5165\u5BC6\u7801\u63D0\u793A\u4FE1\u606F";
    }
    let i18n_16;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_MNEMONIC$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_MNEMONIC_CREATE_WALLET_MNEMONIC_CREATE_WALLET_COMPONENT_TS_17 = goog.getMsg("Mnemonic");
      i18n_16 = MSG_EXTERNAL_MNEMONIC$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_MNEMONIC_CREATE_WALLET_MNEMONIC_CREATE_WALLET_COMPONENT_TS_17;
    } else {
      i18n_16 = "\u52A9\u8BB0\u8BCD";
    }
    let i18n_18;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL___length___WORDS$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_MNEMONIC_CREATE_WALLET_MNEMONIC_CREATE_WALLET_COMPONENT_TS_19 = goog.getMsg("{$interpolation} words", {
        "interpolation": "\uFFFD0\uFFFD"
      }, {
        original_code: {
          "interpolation": "{{ mnemonicInfo.length }}"
        }
      });
      i18n_18 = MSG_EXTERNAL___length___WORDS$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_MNEMONIC_CREATE_WALLET_MNEMONIC_CREATE_WALLET_COMPONENT_TS_19;
    } else {
      i18n_18 = "" + "\uFFFD0\uFFFD" + " \u4E2A\u5B57";
    }
    let i18n_21;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_CREATE_WALLET$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_MNEMONIC_CREATE_WALLET_MNEMONIC_CREATE_WALLET_COMPONENT_TS_22 = goog.getMsg(" Create Wallet ");
      i18n_21 = MSG_EXTERNAL_CREATE_WALLET$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_MNEMONIC_CREATE_WALLET_MNEMONIC_CREATE_WALLET_COMPONENT_TS_22;
    } else {
      i18n_21 = "\u521B\u5EFA\u94B1\u5305";
    }
    let i18n_23;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_PLEASE_ENTER_WALLET_NAME$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_MNEMONIC_CREATE_WALLET_MNEMONIC_CREATE_WALLET_COMPONENT_TS__24 = goog.getMsg("Please enter wallet name");
      i18n_23 = MSG_EXTERNAL_PLEASE_ENTER_WALLET_NAME$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_MNEMONIC_CREATE_WALLET_MNEMONIC_CREATE_WALLET_COMPONENT_TS__24;
    } else {
      i18n_23 = "\u8BF7\u8F93\u5165\u94B1\u5305\u540D\u79F0";
    }
    let i18n_25;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_THE_MAXIMUM_LENGTH_OF_THE_NAME_IS_REQUIRED_LENGTH$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_MNEMONIC_CREATE_WALLET_MNEMONIC_CREATE_WALLET_COMPONENT_TS__26 = goog.getMsg(" The maximum length of the name is {$interpolation} ", {
        "interpolation": "\uFFFD0\uFFFD"
      }, {
        original_code: {
          "interpolation": "{{ error.requiredLength }}"
        }
      });
      i18n_25 = MSG_EXTERNAL_THE_MAXIMUM_LENGTH_OF_THE_NAME_IS_REQUIRED_LENGTH$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_MNEMONIC_CREATE_WALLET_MNEMONIC_CREATE_WALLET_COMPONENT_TS__26;
    } else {
      i18n_25 = "\u540D\u5B57\u8BF7\u52FF\u8D85\u8FC7 " + "\uFFFD0\uFFFD" + " \u4E2A\u5B57\u7B26 ";
    }
    let i18n_27;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_PLEASE_INPUT_THE_PASSWORD$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_MNEMONIC_CREATE_WALLET_MNEMONIC_CREATE_WALLET_COMPONENT_TS__28 = goog.getMsg("Please input the password");
      i18n_27 = MSG_EXTERNAL_PLEASE_INPUT_THE_PASSWORD$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_MNEMONIC_CREATE_WALLET_MNEMONIC_CREATE_WALLET_COMPONENT_TS__28;
    } else {
      i18n_27 = "\u8BF7\u8F93\u5165\u5BC6\u7801";
    }
    let i18n_29;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_THE_PASSWORD_IS_AT_LEAST_CHARACTERS_LONG$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_MNEMONIC_CREATE_WALLET_MNEMONIC_CREATE_WALLET_COMPONENT_TS__30 = goog.getMsg(" The password is at least {$interpolation} characters long ", {
        "interpolation": "\uFFFD0\uFFFD"
      }, {
        original_code: {
          "interpolation": "{{ error.requiredLength }}"
        }
      });
      i18n_29 = MSG_EXTERNAL_THE_PASSWORD_IS_AT_LEAST_CHARACTERS_LONG$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_MNEMONIC_CREATE_WALLET_MNEMONIC_CREATE_WALLET_COMPONENT_TS__30;
    } else {
      i18n_29 = "\u5BC6\u7801\u8BF7\u52FF\u5C11\u4E8E " + "\uFFFD0\uFFFD" + " \u4E2A\u5B57\u7B26 ";
    }
    let i18n_31;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_THE_MAXIMUM_LENGTH_OF_THE_PASSWORD_IS$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_MNEMONIC_CREATE_WALLET_MNEMONIC_CREATE_WALLET_COMPONENT_TS__32 = goog.getMsg(" The maximum length of the password is {$interpolation} ", {
        "interpolation": "\uFFFD0\uFFFD"
      }, {
        original_code: {
          "interpolation": "{{ error.requiredLength }}"
        }
      });
      i18n_31 = MSG_EXTERNAL_THE_MAXIMUM_LENGTH_OF_THE_PASSWORD_IS$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_MNEMONIC_CREATE_WALLET_MNEMONIC_CREATE_WALLET_COMPONENT_TS__32;
    } else {
      i18n_31 = "\u5BC6\u7801\u8BF7\u52FF\u8D85\u8FC7 " + "\uFFFD0\uFFFD" + " \u4E2A\u5B57\u7B26 ";
    }
    let i18n_33;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_THE_PASSWORD_CANNOT_CONTAINER_SPACES$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_MNEMONIC_CREATE_WALLET_MNEMONIC_CREATE_WALLET_COMPONENT_TS__34 = goog.getMsg(" The password cannot container spaces ! ");
      i18n_33 = MSG_EXTERNAL_THE_PASSWORD_CANNOT_CONTAINER_SPACES$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_MNEMONIC_CREATE_WALLET_MNEMONIC_CREATE_WALLET_COMPONENT_TS__34;
    } else {
      i18n_33 = "\u5BC6\u7801\u4E2D\u8BF7\u52FF\u5305\u542B\u7A7A\u683C\uFF01";
    }
    let i18n_35;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_PLEASE_INPUT_THE_PASSWORD_AGAIN$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_MNEMONIC_CREATE_WALLET_MNEMONIC_CREATE_WALLET_COMPONENT_TS__36 = goog.getMsg("Please input the password again");
      i18n_35 = MSG_EXTERNAL_PLEASE_INPUT_THE_PASSWORD_AGAIN$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_MNEMONIC_CREATE_WALLET_MNEMONIC_CREATE_WALLET_COMPONENT_TS__36;
    } else {
      i18n_35 = "\u8BF7\u518D\u6B21\u8F93\u5165\u5BC6\u7801";
    }
    let i18n_37;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_TWO_INPUTSDO_NOT_MATCH$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_MNEMONIC_CREATE_WALLET_MNEMONIC_CREATE_WALLET_COMPONENT_TS__38 = goog.getMsg("Two inputs don't match!");
      i18n_37 = MSG_EXTERNAL_TWO_INPUTSDO_NOT_MATCH$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_MNEMONIC_CREATE_WALLET_MNEMONIC_CREATE_WALLET_COMPONENT_TS__38;
    } else {
      i18n_37 = "\u4E24\u6B21\u8F93\u5165\u4E0D\u4E00\u81F4\uFF01";
    }
    let i18n_39;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_THIS_PASSWORD_IS_ONLY_USED_FOR_THE_SECURITY_PROTECTION_OF_THE_WALLET_COT_WILL_NOT_SAVE_YOUR_PASSWORD_NOR_WILL_IT_BE_ABLE_TO_HELP_YOU_RETRIEVE_IT_PLEASE_REMEMBER_AND_KEEP_YOUR_PASSWORD$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_MNEMONIC_CREATE_WALLET_MNEMONIC_CREATE_WALLET_COMPONENT_TS__40 = goog.getMsg(" This password is only used for the security protection of the wallet. COT will not save your password, nor will it be able to help you retrieve it. Please remember and keep your password! ");
      i18n_39 = MSG_EXTERNAL_THIS_PASSWORD_IS_ONLY_USED_FOR_THE_SECURITY_PROTECTION_OF_THE_WALLET_COT_WILL_NOT_SAVE_YOUR_PASSWORD_NOR_WILL_IT_BE_ABLE_TO_HELP_YOU_RETRIEVE_IT_PLEASE_REMEMBER_AND_KEEP_YOUR_PASSWORD$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_MNEMONIC_CREATE_WALLET_MNEMONIC_CREATE_WALLET_COMPONENT_TS__40;
    } else {
      i18n_39 = "\u8BE5\u5BC6\u7801\u4EC5\u4F5C\u94B1\u5305\u5B89\u5168\u7684\u4FDD\u62A4\u4F5C\u7528\uFF0CCOT\u4E0D\u4F1A\u4FDD\u5B58\u60A8\u7684\u5BC6\u7801\uFF0C\u4E5F\u65E0\u6CD5\u5E2E\u60A8\u627E\u56DE\u5BC6\u7801\uFF0C\u8BF7\u52A1\u5FC5\u8BB0\u5F97\u5E76\u4FDD\u7BA1\u597D\u5BC6\u7801\uFF01";
    }
    let i18n_41;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_THE_MAXIMUM_LENGTH_OF_THE_HINT_IS$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_MNEMONIC_CREATE_WALLET_MNEMONIC_CREATE_WALLET_COMPONENT_TS___42 = goog.getMsg(" The maximum length of the hint is {$interpolation} ", {
        "interpolation": "\uFFFD0\uFFFD"
      }, {
        original_code: {
          "interpolation": "{{errors?.['maxlength']?.requiredLength}}"
        }
      });
      i18n_41 = MSG_EXTERNAL_THE_MAXIMUM_LENGTH_OF_THE_HINT_IS$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_MNEMONIC_CREATE_WALLET_MNEMONIC_CREATE_WALLET_COMPONENT_TS___42;
    } else {
      i18n_41 = "\u63D0\u793A\u4FE1\u606F\u8BF7\u52FF\u8D85\u8FC7 " + "\uFFFD0\uFFFD" + " \u4E2A\u5B57\u7B26 ";
    }
    let i18n_20;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_I_HAVE_READ_AND_AGREED_TO_THE_USER_AGREEMENT$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_MNEMONIC_CREATE_WALLET_MNEMONIC_CREATE_WALLET_COMPONENT_TS__43 = goog.getMsg(" I have read and agreed to {$startTagSpan}\u300A{$closeTagSpan}{$startTagSpan_1}User Agreement{$closeTagSpan}{$startTagSpan}\u300B{$closeTagSpan}", {
        "closeTagSpan": "[\uFFFD/#1:1\uFFFD\uFFFD/*63:1\uFFFD|\uFFFD/#64\uFFFD|\uFFFD/#1:2\uFFFD\uFFFD/*65:2\uFFFD]",
        "startTagSpan": "[\uFFFD*63:1\uFFFD\uFFFD#1:1\uFFFD|\uFFFD*65:2\uFFFD\uFFFD#1:2\uFFFD]",
        "startTagSpan_1": "\uFFFD#64\uFFFD"
      }, {
        original_code: {
          "closeTagSpan": "</span>",
          "startTagSpan": "<span *ngIf=\"isZh\">",
          "startTagSpan_1": "<span class=\"text-white\" [routerLink]=\"['/mnemonic/user-agreement']\">"
        }
      });
      i18n_20 = MSG_EXTERNAL_I_HAVE_READ_AND_AGREED_TO_THE_USER_AGREEMENT$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_MNEMONIC_CREATE_WALLET_MNEMONIC_CREATE_WALLET_COMPONENT_TS__43;
    } else {
      i18n_20 = "\u6211\u5DF2\u9605\u8BFB\u5E76\u540C\u610F " + "[\uFFFD*63:1\uFFFD\uFFFD#1:1\uFFFD|\uFFFD*65:2\uFFFD\uFFFD#1:2\uFFFD]" + "\u300A" + "[\uFFFD/#1:1\uFFFD\uFFFD/*63:1\uFFFD|\uFFFD/#64\uFFFD|\uFFFD/#1:2\uFFFD\uFFFD/*65:2\uFFFD]" + "" + "\uFFFD#64\uFFFD" + "\u7528\u6237\u534F\u8BAE" + "[\uFFFD/#1:1\uFFFD\uFFFD/*63:1\uFFFD|\uFFFD/#64\uFFFD|\uFFFD/#1:2\uFFFD\uFFFD/*65:2\uFFFD]" + "" + "[\uFFFD*63:1\uFFFD\uFFFD#1:1\uFFFD|\uFFFD*65:2\uFFFD\uFFFD#1:2\uFFFD]" + "\u300B" + "[\uFFFD/#1:1\uFFFD\uFFFD/*63:1\uFFFD|\uFFFD/#64\uFFFD|\uFFFD/#1:2\uFFFD\uFFFD/*65:2\uFFFD]" + "";
    }
    i18n_20 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵi18nPostprocess"](i18n_20);
    return [["headerTitle", i18n_0, 3, "contentBackground", "headerBackground", "headerTranslucent", "footerTranslucent", "footerBackground", "footerOpacity", "titleColor", "titleTheme", "contentSafeArea", "headerButtonColor"], [1, "text-white", 3, "formGroup", "ngSubmit"], [1, "mb-2", "flex", "h-10", "w-full", "items-end", "justify-between", "text-xs", "font-semibold"], [1, "flex-shrink-0", "pr-2", "text-sm", 3, "ngClass"], i18n_2, [1, "text-error", "text-xss", "text-right", 3, "wSwitchErrors"], ["wCaseKey", "trimRequired"], ["wCaseKey", "maxlength"], [1, "bg-env/10", "flex", "h-12", "rounded-lg"], ["formControlName", "name", "type", "text", "placeholder", i18n_4, 1, "w-full", "px-3"], i18n_6, ["scope", "pwd", "wCaseKey", "required"], ["scope", "pwd", "wCaseKey", "minlength"], ["scope", "pwd", "wCaseKey", "maxlength"], ["scope", "pwd", "wCaseKey", "whitespace"], ["scope", "cpwd", "wCaseKey", "required"], ["scope", "cpwd", "wCaseKey", "equals"], [3, "wCaseDefault"], [1, "bg-env/10", "flex", "h-12", "items-stretch", "rounded-lg", "pr-4"], ["formControlName", "pwd", "placeholder", i18n_8, 1, "w-full", "px-3", 3, "type", "focus", "blur"], [1, "text-subtext", "text-xl", 3, "show", "showChange"], ["class", "text-error my-2 text-xs", 4, "ngIf"], [1, "bg-env/10", "mt-2", "flex", "h-12", "items-stretch", "rounded-lg", "pr-4"], ["formControlName", "cpwd", "placeholder", i18n_10, 1, "w-full", "px-3", 3, "type"], i18n_12, ["class", "text-error text-xss text-right", 4, "ngIf"], ["formControlName", "tip", "type", "text", "placeholder", i18n_14, 1, "w-full", "px-3"], [1, "flex-shrink-0", "pr-2", "text-sm"], i18n_16, ["wRippleButton", "", "type", "button", 1, "bg-env/10", "flex", "h-12", "w-full", "items-center", "justify-between", "rounded-lg", "pr-4", 3, "click"], [1, "w-full", "px-3"], ["name", "right", 1, "icon-5", "ml-1.5"], ["wRippleButton", "", "type", "button", 1, "bg-env/10", "mb-2", "mt-2", "flex", "h-12", "w-full", "items-center", "justify-between", "rounded-lg", "pr-4", 3, "click"], i18n_18, ["footer", "", 1, "grid", "place-items-center", "gap-2", 3, "formGroup", "ngSubmit"], [1, "flex", "items-center", "justify-start"], ["type", "checkbox", "id", "agree", "formControlName", "checked", 1, "cot-checkbox", "cot-checkbox-info", "cot-checkbox-xs", "bg-env/10", "m-2"], [1, "text-xss", "pl-1", "text-white"], i18n_20, [4, "ngIf"], [1, "text-white", 3, "routerLink"], ["bnRippleButton", "", "type", "submit", 1, "h-10.5", "text-primary-2", "w-full", "rounded-full", "bg-white", "text-center", "text-sm", 3, "disabled"], i18n_21, [3, "isOpen", "isOpenChange"], i18n_23, i18n_25, i18n_27, i18n_29, i18n_31, i18n_33, i18n_35, i18n_37, [1, "text-error", "my-2", "text-xs"], ["name", "warn-grey", 1, "icon-5"], i18n_39, [1, "text-error", "text-xss", "text-right"], i18n_41, [3, "headerTitle"], ["page", ""], [1, "box-border", "flex", "flex-col"], ["wRippleButton", "", "class", "h-12 w-full px-5 text-sm", 3, "click", 4, "ngFor", "ngForOf"], ["wRippleButton", "", 1, "h-12", "w-full", "px-5", "text-sm", 3, "click"], [1, "border-line", "flex", "h-full", "w-full", "items-center", "justify-center", 3, "ngClass"]];
  },
  template: function MnemonicCreateWalletPage_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "common-page", 0)(1, "form", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("ngSubmit", function MnemonicCreateWalletPage_Template_form_ngSubmit_1_listener() {
        return ctx.onSubmit();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](2, "fieldset")(3, "legend", 2)(4, "div", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵi18n"](5, 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipe"](6, "errors");
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](7, "div", 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](8, MnemonicCreateWalletPage_ng_template_8_Template, 2, 0, "ng-template", 6)(9, MnemonicCreateWalletPage_ng_template_9_Template, 2, 1, "ng-template", 7);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](10, "div", 8);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](11, "input", 9);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](12, "fieldset")(13, "legend", 2)(14, "div", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵi18n"](15, 10);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipe"](16, "errors");
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipe"](17, "errors");
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](18, "div", 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](19, MnemonicCreateWalletPage_ng_template_19_Template, 2, 0, "ng-template", 11)(20, MnemonicCreateWalletPage_ng_template_20_Template, 2, 1, "ng-template", 12)(21, MnemonicCreateWalletPage_ng_template_21_Template, 2, 1, "ng-template", 13)(22, MnemonicCreateWalletPage_ng_template_22_Template, 2, 0, "ng-template", 14)(23, MnemonicCreateWalletPage_ng_template_23_Template, 2, 0, "ng-template", 15)(24, MnemonicCreateWalletPage_ng_template_24_Template, 2, 0, "ng-template", 16)(25, MnemonicCreateWalletPage_ng_template_25_Template, 1, 1, "ng-template", 17);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](26, "div", 18)(27, "input", 19);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("focus", function MnemonicCreateWalletPage_Template_input_focus_27_listener() {
        return ctx.showPwdTip = true;
      })("blur", function MnemonicCreateWalletPage_Template_input_blur_27_listener() {
        return ctx.showPwdTip = false;
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](28, "w-input-hidden-icon-swap", 20);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("showChange", function MnemonicCreateWalletPage_Template_w_input_hidden_icon_swap_showChange_28_listener($event) {
        return ctx.showPwd = $event;
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipe"](29, "color");
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](30, MnemonicCreateWalletPage_div_30_Template, 4, 0, "div", 21);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](31, "div", 22);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](32, "input", 23);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](33, "w-input-hidden-icon-swap", 20);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("showChange", function MnemonicCreateWalletPage_Template_w_input_hidden_icon_swap_showChange_33_listener($event) {
        return ctx.showCPwd = $event;
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipe"](34, "color");
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()()();
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](35, "fieldset")(36, "legend", 2)(37, "div", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵi18n"](38, 24);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipe"](39, "errors");
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](40, MnemonicCreateWalletPage_div_40_Template, 2, 1, "div", 25);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipe"](41, "errors");
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](42, "div", 8);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](43, "input", 26);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](44, "fieldset")(45, "legend", 2)(46, "div", 27);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵi18n"](47, 28);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](48, "button", 29);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("click", function MnemonicCreateWalletPage_Template_button_click_48_listener() {
        return ctx.selectLanguage();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](49, "div", 30);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](50);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](51, "w-icon", 31);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipe"](52, "color");
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](53, "button", 32);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("click", function MnemonicCreateWalletPage_Template_button_click_53_listener() {
        return ctx.selectLength();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](54, "div", 30);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵi18n"](55, 33);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](56, "w-icon", 31);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipe"](57, "color");
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()()();
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](58, "form", 34);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("ngSubmit", function MnemonicCreateWalletPage_Template_form_ngSubmit_58_listener() {
        return ctx.onSubmit();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](59, "div", 35);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](60, "input", 36);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](61, "span", 37);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵi18nStart"](62, 38);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](63, MnemonicCreateWalletPage_span_63_Template, 2, 0, "span", 39);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](64, "span", 40);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](65, MnemonicCreateWalletPage_span_65_Template, 2, 0, "span", 39);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵi18nEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](66, "button", 41);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵi18n"](67, 42);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()()();
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](68, "common-bottom-sheet", 43);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("isOpenChange", function MnemonicCreateWalletPage_Template_common_bottom_sheet_isOpenChange_68_listener($event) {
        return $event || (ctx.mnemonicBottomSheetInfo.open = false);
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](69, MnemonicCreateWalletPage_ng_template_69_Template, 4, 2, "ng-template");
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("contentBackground", "primary")("headerBackground", "transparent")("headerTranslucent", false)("footerTranslucent", false)("footerBackground", "primary")("footerOpacity", 0.8)("titleColor", "white")("titleTheme", ctx.keyboardShow ? "center-aligned" : "large")("contentSafeArea", true)("headerButtonColor", "light");
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("formGroup", ctx.form);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpureFunction1"](58, _c44, _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipeBind1"](6, 40, ctx.name)));
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("wSwitchErrors", ctx.name);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](7);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpureFunction1"](60, _c44, _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipeBind1"](16, 42, ctx.pwd) || _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipeBind1"](17, 44, ctx.cpwd)));
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](4);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("wSwitchErrors", _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpureFunction2"](62, _c45, ctx.pwd, ctx.cpwd));
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](9);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("type", ctx.showPwd ? "text" : "password");
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpureFunction1"](65, _c46, _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipeBind1"](29, 46, "subtext")));
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("show", ctx.showPwd);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", ctx.showPwdTip);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("type", ctx.showCPwd ? "text" : "password");
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpureFunction1"](67, _c46, _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipeBind1"](34, 48, "subtext")));
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("show", ctx.showCPwd);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](4);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpureFunction1"](69, _c44, _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipeBind1"](39, 50, ctx.tip)));
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipeBind1"](41, 52, ctx.tip));
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](10);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtextInterpolate"](ctx.mnemonicInfo.text);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpureFunction1"](71, _c46, _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipeBind1"](52, 54, "subtext")));
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](4);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵi18nExp"](ctx.mnemonicInfo.length);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵi18nApply"](55);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpureFunction1"](73, _c46, _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipeBind1"](57, 56, "subtext")));
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("formGroup", ctx.form);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](5);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", ctx.isZh);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("routerLink", _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpureFunction0"](75, _c47));
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", ctx.isZh);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵclassProp"]("opacity-30", !ctx.form.valid);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("disabled", !ctx.form.valid);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("isOpen", ctx.mnemonicBottomSheetInfo.open);
    }
  },
  dependencies: [_modules_page_module__WEBPACK_IMPORTED_MODULE_3__.CommonPageModule, _libs_bnf_modules_bottom_sheet_components_bottom_sheet_component__WEBPACK_IMPORTED_MODULE_5__.BottomSheetComponent, _libs_bnf_components_ripple_button_ripple_button_directive__WEBPACK_IMPORTED_MODULE_6__.RippleButtonDirective, _libs_bnf_directives_form_errors_directive__WEBPACK_IMPORTED_MODULE_7__.SwitchErrorsDirective, _libs_bnf_directives_form_errors_directive__WEBPACK_IMPORTED_MODULE_7__.SwitchCaseDirective, _libs_bnf_directives_form_errors_directive__WEBPACK_IMPORTED_MODULE_7__.SwitchDefaultDirective, _libs_bnf_directives_auto_complete_off_directive__WEBPACK_IMPORTED_MODULE_8__.AutoCompleteOffDirective, _angular_common__WEBPACK_IMPORTED_MODULE_15__.NgClass, _angular_common__WEBPACK_IMPORTED_MODULE_15__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_15__.NgIf, _angular_forms__WEBPACK_IMPORTED_MODULE_14__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_14__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_14__.CheckboxControlValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_14__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_14__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_14__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_14__.FormControlName, _angular_router__WEBPACK_IMPORTED_MODULE_16__.RouterLink, _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_9__.CommonPageComponent, _components_icon_icon_component__WEBPACK_IMPORTED_MODULE_10__.IconComponent, _libs_bnf_pipes_errors_errors_pipe__WEBPACK_IMPORTED_MODULE_11__.ErrorsPipe, _pipes_color_color_pipe__WEBPACK_IMPORTED_MODULE_12__.ColorPipe, _components_input_hidden_icon_swap_input_hidden_icon_swap_component__WEBPACK_IMPORTED_MODULE_2__["default"]],
  styles: ["[_nghost-%COMP%]   ._bg[_ngcontent-%COMP%] {\n  position: absolute;\n  left: 0rem;\n  top: 0rem;\n  height: 18rem;\n  width: auto;\n  --tw-bg-opacity: 1;\n  background-color: rgb(146 103 254 / var(--tw-bg-opacity));\n  object-fit: cover;\n  z-index: -1\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL2FwcHMvd2FsbGV0L3NyYy9wYWdlcy9tbmVtb25pYy9wYWdlcy9tbmVtb25pYy1jcmVhdGUtd2FsbGV0L21uZW1vbmljLWNyZWF0ZS13YWxsZXQuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBRUk7RUFBQSxrQkFBQTtFQUFBLFVBQUE7RUFBQSxTQUFBO0VBQUEsYUFBQTtFQUFBLFdBQUE7RUFBQSxrQkFBQTtFQUFBLHlEQUFBO0VBQUEsaUJBQUE7RUFDQTtBQURBIiwic291cmNlc0NvbnRlbnQiOlsiOmhvc3Qge1xyXG4gIC5fYmcge1xyXG4gICAgQGFwcGx5IGJnLXByaW1hcnkgYWJzb2x1dGUgbGVmdC0wIHRvcC0wIGgtNzIgdy1hdXRvIG9iamVjdC1jb3ZlcjtcclxuICAgIHotaW5kZXg6IC0xO1xyXG4gIH1cclxufVxyXG4iXSwic291cmNlUm9vdCI6IiJ9 */"],
  changeDetection: 0
});
(0,tslib__WEBPACK_IMPORTED_MODULE_17__.__decorate)([MnemonicCreateWalletPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_17__.__metadata)("design:type", Object)], MnemonicCreateWalletPage.prototype, "keyboardShow", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_17__.__decorate)([MnemonicCreateWalletPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_17__.__metadata)("design:type", Object)], MnemonicCreateWalletPage.prototype, "getKeyboardInfo", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_17__.__decorate)([MnemonicCreateWalletPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_17__.__metadata)("design:type", Object)], MnemonicCreateWalletPage.prototype, "isZh", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_17__.__decorate)([MnemonicCreateWalletPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_17__.__metadata)("design:type", Object)], MnemonicCreateWalletPage.prototype, "showPwd", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_17__.__decorate)([MnemonicCreateWalletPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_17__.__metadata)("design:type", Object)], MnemonicCreateWalletPage.prototype, "showCPwd", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_17__.__decorate)([MnemonicCreateWalletPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_17__.__metadata)("design:type", Object)], MnemonicCreateWalletPage.prototype, "showPwdTip", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_17__.__decorate)([MnemonicCreateWalletPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_17__.__metadata)("design:type", Object)], MnemonicCreateWalletPage.prototype, "name", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_17__.__decorate)([MnemonicCreateWalletPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_17__.__metadata)("design:type", Object)], MnemonicCreateWalletPage.prototype, "pwd", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_17__.__decorate)([MnemonicCreateWalletPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_17__.__metadata)("design:type", Object)], MnemonicCreateWalletPage.prototype, "cpwd", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_17__.__decorate)([MnemonicCreateWalletPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_17__.__metadata)("design:type", Object)], MnemonicCreateWalletPage.prototype, "checked", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_17__.__decorate)([MnemonicCreateWalletPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_17__.__metadata)("design:type", Object)], MnemonicCreateWalletPage.prototype, "tip", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_17__.__decorate)([MnemonicCreateWalletPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_17__.__metadata)("design:type", Object)], MnemonicCreateWalletPage.prototype, "form", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_17__.__decorate)([MnemonicCreateWalletPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_17__.__metadata)("design:type", Object)], MnemonicCreateWalletPage.prototype, "mnemonicBottomSheetInfo", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_17__.__decorate)([MnemonicCreateWalletPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_17__.__metadata)("design:type", Object)], MnemonicCreateWalletPage.prototype, "mnemonicInfo", void 0);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MnemonicCreateWalletPage);

/***/ }),

/***/ 11606:
/*!************************************************************!*\
  !*** ./libs/bnf/controllers/form-validators.controller.ts ***!
  \************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   FormValidatorsController: () => (/* binding */ FormValidatorsController)
/* harmony export */ });
/* harmony import */ var _bnqkl_framework_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @bnqkl/framework/core */ 63563);
/* harmony import */ var _bnqkl_util_web_extends_map__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @bnqkl/util-web/extends-map */ 37689);


/**
 * 页面表单扩展验证器
 *
 * > 因为涉及到FromControl的生命周期管理，所以这里需要使用Controller模式来获取组件/页面的生命周期
 *
 * 为了确保类型安全, 请遵循以下规则去定义验证器:
 * 1. 尽可能直接提供 $ValidatorFn,比如 `trimRequired(control: AbstractControl): $ValidationErrors | null {...}`
 * 2. 如果不能直接提供 $ValidatorFn, 那么作为工厂模式,必然要有参数传入,比如 `equals(leaderCtrl: AbstractControl): $ValidatorFn {...}`
 */
class FormValidatorsController {
  /**
   * 通过订阅原页面的生命周期，来对订阅的字段进行监听解除
   */
  constructor(comp) {
    /**
     * 判断两个数据字段相等的时，left===right 中 left的数据订阅
     */
    this._equalsLeaderMap = _bnqkl_util_web_extends_map__WEBPACK_IMPORTED_MODULE_1__.EasyMap.from({
      creater(ctrl) {
        const sub = {
          sub$: ctrl.valueChanges.subscribe(() => {
            for (const ctrl of sub.destControls) {
              ctrl.updateValueAndValidity();
            }
          }),
          destControls: new Set()
        };
        return sub;
      }
    });
    (0,_bnqkl_framework_core__WEBPACK_IMPORTED_MODULE_0__.addLifecycleMethods)(comp, 'ngOnDestroy', {
      origin: 'form-validator',
      method: () => {
        for (const {
          sub$
        } of this._equalsLeaderMap.values()) {
          sub$.unsubscribe();
        }
        this._equalsLeaderMap.clear();
      },
      order: Number.MAX_SAFE_INTEGER /* 最后才做这些事情 */
    });
  }
  /** 两个字段对比 相等就过 不相等返回 {equals:true} */
  equals(leaderCtrl) {
    const leader = this._equalsLeaderMap.forceGet(leaderCtrl);
    // pwdCtrl.val
    return follerCtrl => {
      leader.destControls.add(follerCtrl);
      if (leaderCtrl.value === follerCtrl.value) {
        return null;
      }
      return {
        equals: true
      };
    };
  }
  /** 是否包含空格 */
  whitespace(control) {
    const value = control.value;
    if (typeof value === 'string' && /\s/.test(value)) {
      return {
        whitespace: true
      };
    }
    return null;
  }
  /** required 变体, 左右两边不能包含空格 */
  trimRequired(control) {
    const value = control.value;
    if (typeof value === 'string' && value.trim().length === 0 || value == undefined) {
      return {
        trimRequired: true
      };
    }
    return null;
  }
}

/***/ }),

/***/ 47919:
/*!***************************************!*\
  !*** ./libs/bnf/controllers/index.ts ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   FormValidatorsController: () => (/* reexport safe */ _form_validators_controller__WEBPACK_IMPORTED_MODULE_0__.FormValidatorsController),
/* harmony export */   PageReturnController: () => (/* reexport safe */ _page_return_controller__WEBPACK_IMPORTED_MODULE_1__.PageReturnController)
/* harmony export */ });
/* harmony import */ var _form_validators_controller__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./form-validators.controller */ 11606);
/* harmony import */ var _page_return_controller__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./page-return.controller */ 62893);



/***/ }),

/***/ 62893:
/*!********************************************************!*\
  !*** ./libs/bnf/controllers/page-return.controller.ts ***!
  \********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   PageReturnController: () => (/* binding */ PageReturnController)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 54106);
/* harmony import */ var _bnqkl_util_web_decorator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @bnqkl/util-web/decorator */ 18112);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs */ 19177);



/**
 * 页面数据返回值的订阅功能
 * > Controller 必须在构造函数期间执行
 */
class PageReturnController {
  /** 继承日志 */
  get console() {
    return this.fromPage.console;
  }
  /**
   * 传入源页面与目标页面的构造函数，并通过订阅原页面的生命周期，来初始化对路由的订阅
   * 这里依赖 ion-router-outlet 来获取跳转过去的页面
   * 注：该监听返回是全触发（只要页面没被销毁掉不管页面是否处于激活状态）
   * @param specific 用于指定fromPage触发（需要手动指定），业务需要
   */
  constructor(fromPage, toPageCtor, specific = false) {
    this.fromPage = fromPage;
    /** 当前定阅过的页面 */
    this._toPages = new WeakSet();
    /**
     * 订阅到的返回内容，
     * 类型由对应页面的 returnValue$ 的定义决定
     */
    this.pageReturn$ = new rxjs__WEBPACK_IMPORTED_MODULE_1__.Subject();
    const {
      nav
    } = fromPage;
    fromPage.takeUntilDestroy(nav.pageActiveState$).subscribe(event => {
      /// 只监听新激活的页面
      if (event.type !== 'activate') {
        return;
      }
      const toPage = event.target;
      if (toPage instanceof toPageCtor &&
      // 去重
      this._toPages.has(toPage) === false) {
        if (toPage.returnValue$ === undefined) {
          return;
        }
        this._toPages.add(toPage);
        if (specific) {
          var _toPage$specificRetur;
          (_toPage$specificRetur = toPage.specificReturnPages) === null || _toPage$specificRetur === void 0 || _toPage$specificRetur.add(fromPage);
        }
        fromPage.takeUntilDestroy(toPage.returnValue$).subscribe({
          next: data => {
            /// 这里不用判断specific
            if (toPage.specificReturnPages && toPage.specificReturnPages.size) {
              /// 如果有写入，那么就只需要触发相对应页面就行
              toPage.specificReturnPages.has(fromPage) && this.pageReturn$.next(data);
              return;
            }
            this.pageReturn$.next(data);
          },
          complete: () => {
            var _toPage$specificRetur2;
            // 释放内存引用
            (_toPage$specificRetur2 = toPage.specificReturnPages) === null || _toPage$specificRetur2 === void 0 || _toPage$specificRetur2.delete(fromPage);
            return this._toPages.delete(toPage);
          }
        });
      }
    });
  }
}
(0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([_bnqkl_util_web_decorator__WEBPACK_IMPORTED_MODULE_0__.cacheGetter, (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__metadata)("design:type", Object), (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__metadata)("design:paramtypes", [])], PageReturnController.prototype, "console", null);

/***/ })

}]);
//# sourceMappingURL=apps_wallet_src_pages_mnemonic_pages_mnemonic-create-wallet_mnemonic-create-wallet_component_ts.js.map