"use strict";
(self["webpackChunkwallet"] = self["webpackChunkwallet"] || []).push([["default-apps_wallet_src_pages_mnemonic_pages_mnemonic-confirm-backup_mnemonic-confirm-backup_-f6fc5f"],{

/***/ 91879:
/*!***********************************************************************************************************!*\
  !*** ./apps/wallet/src/pages/mnemonic/pages/mnemonic-confirm-backup/mnemonic-confirm-backup.component.ts ***!
  \***********************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   MnemonicConfirmBackupPage: () => (/* binding */ MnemonicConfirmBackupPage),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 52542);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! tslib */ 90505);
/* harmony import */ var _bnqkl_framework_helpers__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @bnqkl/framework/helpers */ 12169);
/* harmony import */ var _environments_index__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ~environments/index */ 40014);
/* harmony import */ var _modules_page_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ~modules/page.module */ 77538);
/* harmony import */ var _bnqkl_wallet_base_services_wallet_wallet_data_storage__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @bnqkl/wallet-base/services/wallet/wallet-data-storage */ 63024);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/core */ 61039);
/* harmony import */ var _libs_bnf_components_ripple_button_ripple_button_directive__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../../../../../libs/bnf/components/ripple-button/ripple-button.directive */ 16505);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/common */ 6729);
/* harmony import */ var _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../../../../../libs/bnf/modules/page/common-page/common-page.component */ 62052);
/* harmony import */ var _components_icon_icon_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../../components/icon/icon.component */ 74703);
/* harmony import */ var _libs_bnf_components_loading_wrapper_loading_wrapper_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../../../../../libs/bnf/components/loading-wrapper/loading-wrapper.component */ 51263);

var _class;











function MnemonicConfirmBackupPage_ng_container_7_w_icon_6_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](0, "w-icon", 17);
  }
}
const _c4 = (a0, a1) => ({
  "bg-white": a0,
  "bg-line border-subtext border-tiny": a1
});
function MnemonicConfirmBackupPage_ng_container_7_Template(rf, ctx) {
  if (rf & 1) {
    const _r8 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](1, "button", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵlistener"]("click", function MnemonicConfirmBackupPage_ng_container_7_Template_button_click_1_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵrestoreView"](_r8);
      const item_r4 = restoredCtx.$implicit;
      const i_r5 = restoredCtx.index;
      const ctx_r7 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵresetView"](ctx_r7.btnClick1(item_r4, i_r5));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](2, "span", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](4, "div", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtext"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtemplate"](6, MnemonicConfirmBackupPage_ng_container_7_w_icon_6_Template, 1, 0, "w-icon", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const item_r4 = ctx.$implicit;
    const i_r5 = ctx.index;
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpureFunction2"](5, _c4, item_r4.flag, !item_r4.data));
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("ngClass", item_r4.errFlag ? "text-error" : "text-title");
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtextInterpolate1"](" ", item_r4.data, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtextInterpolate1"](" ", i_r5 + 1, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("ngIf", item_r4.errFlag);
  }
}
function MnemonicConfirmBackupPage_ng_container_9_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](1, "div", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵi18n"](2, 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementContainerEnd"]();
  }
}
function MnemonicConfirmBackupPage_ng_container_10_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](1, "div", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵi18n"](2, 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementContainerEnd"]();
  }
}
const _c9 = a0 => ({
  "!border-subtext !text-subtext": a0
});
function MnemonicConfirmBackupPage_ng_container_12_Template(rf, ctx) {
  if (rf & 1) {
    const _r12 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](1, "button", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵlistener"]("click", function MnemonicConfirmBackupPage_ng_container_12_Template_button_click_1_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵrestoreView"](_r12);
      const item_r9 = restoredCtx.$implicit;
      const i_r10 = restoredCtx.index;
      const ctx_r11 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵresetView"](ctx_r11.randomClick(item_r9, i_r10));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const item_r9 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("disabled", item_r9.flag)("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpureFunction1"](3, _c9, item_r9.flag));
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtextInterpolate1"](" ", item_r9.data, " ");
  }
}
/**
 * 确认助记词页面
 */
class MnemonicConfirmBackupPage extends _modules_page_module__WEBPACK_IMPORTED_MODULE_3__.CommonPageBase {
  constructor() {
    var _this;
    /** 助记词 */
    super(...arguments);
    _this = this;
    this.exhibitionnemonicArr = [];
    /** 确认助记词 */
    this.configMnemonicArr = [];
    /** 打乱已经格式化后的助记词数组 */
    this._configMnemonicArr = [{
      data: '',
      flag: false,
      errFlag: false,
      tag: ''
    }];
    /** 通过标记 */
    this.allFlag = true;
    /** 按钮标记 */
    this.btnFlag = true;
    /** 页面返回值的类型 */
    this.returnValue$ = new _modules_page_module__WEBPACK_IMPORTED_MODULE_3__.PageReturnValue();
    /** 创建钱包 */
    this.finish = (0,_bnqkl_framework_helpers__WEBPACK_IMPORTED_MODULE_1__.$singleton)( /*#__PURE__*/(0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const data = _this._data;
      if (typeof _this._data.backup === 'string' ? _this._data.backup === 'true' : _this._data.backup) {
        /// 备份助剂词模式，更新数据
        const walletDataStorageV2Service = _this.injectorForceGet(_bnqkl_wallet_base_services_wallet_wallet_data_storage__WEBPACK_IMPORTED_MODULE_4__.WalletDataStorageV2Service);
        const mainWalletV2 = yield walletDataStorageV2Service.getMainWalletInfo(_this._data.mainWalletId);
        mainWalletV2.skipBackup = false;
        yield walletDataStorageV2Service.saveMainWalletInfo(mainWalletV2);
      }
      _this.returnValue$.next({
        mainWalletId: _this._data.mainWalletId
      });
      if ((0,_bnqkl_framework_helpers__WEBPACK_IMPORTED_MODULE_1__.$isNoEmptyString)(data.backUrl)) {
        return _this.nav.routeBack(data.backUrl);
      }
      return _this.nav.setPageRoot('tabs');
    }));
  }
  /** 初始化获取传参 */
  getWalletInfoAndMnemonic() {
    var _this2 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const mnemonicLength = _this2.configMnemonicArr.length;
      const randomList = [];
      /// 随机挑4个
      while (randomList.length < 4) {
        const randomNum = Math.floor(Math.random() * mnemonicLength);
        if (randomList.includes(randomNum) === false) {
          randomList.push(randomNum);
        }
      }
      /// 初始化 exhibitionnemonicArr
      _this2.exhibitionnemonicArr = _this2.configMnemonicArr.map((item, index) => {
        if (randomList.includes(index) === false) {
          return {
            data: item,
            flag: true,
            errFlag: false,
            tag: `${index}`
          };
        }
        return {
          data: '',
          flag: false,
          errFlag: false,
          tag: ''
        };
      });
      _this2._configMnemonicArr = _this2.disorder(_this2.configMnemonicArr.map((item, index) => {
        return {
          data: item,
          flag: false,
          errFlag: false,
          tag: `${index}`
        };
      }).filter((item, index) => randomList.includes(index)));
      _this2.cdRef.detectChanges();
    })();
  }
  /** 尝试自动补全助记词 */
  autoComplete() {
    var _this3 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      if (_environments_index__WEBPACK_IMPORTED_MODULE_2__.environment.test) {
        const confirmed = yield _this3.confirm({
          headerTitle: '非正式版',
          bodyMessage: '是否需要自动补全助记词？'
        });
        if (confirmed) {
          _this3.exhibitionnemonicArr.forEach((item, index) => {
            item.data = _this3.configMnemonicArr[index];
            item.flag = true;
            item.tag = String(index);
          });
          _this3._configMnemonicArr.forEach(item => item.flag = true);
          _this3.btnFlag = false;
        }
      }
    })();
  }
  // 点击随机助记词时的事件
  randomClick(event, index) {
    if (event.flag === false && this.allFlag) {
      this._configMnemonicArr[index].flag = true;
      const curNeedInputIndex = this.exhibitionnemonicArr.findIndex(item => !item.data);
      this.exhibitionnemonicArr[curNeedInputIndex] = event;
      this.cdRef.detectChanges();
      if (event.data !== this.configMnemonicArr[curNeedInputIndex]) {
        this.exhibitionnemonicArr[curNeedInputIndex]['errFlag'] = true;
        this.allFlag = false;
      }
      const allRight = !this.exhibitionnemonicArr.find(item => item.errFlag || !item.data);
      if (allRight) {
        this.btnFlag = false;
      }
    }
  }
  /** 打乱顺序 */
  disorder(arr) {
    const res = [...arr];
    for (let i = arr.length - 1; i > 0; i--) {
      const randomIndex = Math.floor(Math.random() * (i + 1));
      const randomItem = res[randomIndex];
      res[randomIndex] = res[i];
      res[i] = randomItem;
    }
    return res;
  }
  // 点击确认框里的助记词时的事件
  btnClick1(event, index) {
    if (event.errFlag) {
      this.exhibitionnemonicArr[index] = {
        data: '',
        flag: false,
        errFlag: false,
        tag: ''
      };
      this.allFlag = true;
      this._configMnemonicArr.forEach(item => {
        if (item.tag === event.tag) {
          item.flag = false;
          item.errFlag = false;
        }
      });
    }
  }
  /** 下一步按钮显示文本 */
  get nextBtcText() {
    return (0,_bnqkl_framework_helpers__WEBPACK_IMPORTED_MODULE_1__.$isNoEmptyString)(this._data.backUrl) ? "\u5B8C\u6210" : "\u9032\u5165\u9322\u5305";
  }
}
_class = MnemonicConfirmBackupPage;
_class.ɵfac = /*@__PURE__*/(() => {
  let ɵMnemonicConfirmBackupPage_BaseFactory;
  return function MnemonicConfirmBackupPage_Factory(t) {
    return (ɵMnemonicConfirmBackupPage_BaseFactory || (ɵMnemonicConfirmBackupPage_BaseFactory = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵgetInheritedFactory"](_class)))(t || _class);
  };
})();
_class.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdefineComponent"]({
  type: _class,
  selectors: [["w-mnemonic-confirm-backup-page"]],
  outputs: {
    returnValue$: "returnValue$"
  },
  standalone: true,
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵInheritDefinitionFeature"], _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵStandaloneFeature"]],
  decls: 16,
  vars: 16,
  consts: () => {
    let i18n_0;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_CONFIRM_MNEMONIC$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_MNEMONIC_CONFIRM_BACKUP_MNEMONIC_CONFIRM_BACKUP_COMPONENT_TS_1 = goog.getMsg("Confirm Mnemonic");
      i18n_0 = MSG_EXTERNAL_CONFIRM_MNEMONIC$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_MNEMONIC_CONFIRM_BACKUP_MNEMONIC_CONFIRM_BACKUP_COMPONENT_TS_1;
    } else {
      i18n_0 = "\u78BA\u8A8D\u52A9\u8A18\u8A5E";
    }
    let i18n_2;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_CLICK_ON_THE_WORDS_TO_ARRANGE_THEM_IN_MNEMONIC_ORDER$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_MNEMONIC_CONFIRM_BACKUP_MNEMONIC_CONFIRM_BACKUP_COMPONENT_TS_3 = goog.getMsg(" Click on the words to arrange them in mnemonic order. ");
      i18n_2 = MSG_EXTERNAL_CLICK_ON_THE_WORDS_TO_ARRANGE_THEM_IN_MNEMONIC_ORDER$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_MNEMONIC_CONFIRM_BACKUP_MNEMONIC_CONFIRM_BACKUP_COMPONENT_TS_3;
    } else {
      i18n_2 = "\u9EDE\u64CA\u55AE\u8A5E\uFF0C\u6309\u52A9\u8A18\u8A5E\u9806\u5E8F\u6392\u5217\u3002";
    }
    let i18n_5;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_INCORRECT_ORDER_PLEASE_TRY_AGAIN$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_MNEMONIC_CONFIRM_BACKUP_MNEMONIC_CONFIRM_BACKUP_COMPONENT_TS__6 = goog.getMsg(" Incorrect order, please try again! ");
      i18n_5 = MSG_EXTERNAL_INCORRECT_ORDER_PLEASE_TRY_AGAIN$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_MNEMONIC_CONFIRM_BACKUP_MNEMONIC_CONFIRM_BACKUP_COMPONENT_TS__6;
    } else {
      i18n_5 = "\u9806\u5E8F\u4E0D\u6B63\u78BA\uFF0C\u8ACB\u91CD\u8A66\uFF01";
    }
    let i18n_7;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_WELL_DONE$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_MNEMONIC_CONFIRM_BACKUP_MNEMONIC_CONFIRM_BACKUP_COMPONENT_TS__8 = goog.getMsg("Well done!");
      i18n_7 = MSG_EXTERNAL_WELL_DONE$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_MNEMONIC_CONFIRM_BACKUP_MNEMONIC_CONFIRM_BACKUP_COMPONENT_TS__8;
    } else {
      i18n_7 = "\u5E79\u5F97\u6F02\u4EAE\uFF01";
    }
    return [[3, "contentSafeArea", "contentBackground", "headerBackground", "headerTranslucent", "footerTranslucent", "footerOpacity"], [1, "text-title", "pt-2"], [1, "text-base", "font-semibold"], i18n_0, [1, "text-subtext", "mb-2", "text-xs"], i18n_2, [1, "bg-grey", "min-h-56", "grid", "grid-cols-3", "grid-rows-4", "gap-1.5", "rounded-lg", "p-1.5"], [4, "ngFor", "ngForOf"], [1, "h-12", "text-2xl", "font-normal", "tracking-normal"], [4, "ngIf"], [1, "grid", "grid-cols-4", "grid-rows-3", "items-center", "justify-between", "gap-2.5", "rounded-lg", "pb-3"], ["footer", "", "bnRippleButton", "", 1, "h-10.5", "from-purple-gradient-start", "to-purple-gradient-end", "mb-4", "w-full", "rounded-full", "bg-gradient-to-b", "text-center", "text-sm", "text-white", 3, "disabled", "click"], [3, "loadingTheme", "waitFor"], [1, "grid-areas-[text]", "relative", "grid", "h-12", "place-items-center", "rounded-sm", "p-1", 3, "ngClass", "click"], [1, "grid-in-[text]", "text-base", "font-semibold", 3, "ngClass"], [1, "text-subtext", "text-xss", "absolute", "bottom-0", "right-1"], ["class", "bg-error icon-2.5 grid-in-[text] self-start justify-self-end rounded-full p-px text-white", "name", "fail", 4, "ngIf"], ["name", "fail", 1, "bg-error", "icon-2.5", "grid-in-[text]", "self-start", "justify-self-end", "rounded-full", "p-px", "text-white"], [1, "text-red", "text-error", "pt-3", "text-center", "text-sm"], i18n_5, [1, "text-primary", "pt-3", "text-center", "text-sm"], i18n_7, ["bnRippleButton", "", 1, "h-10.5", "border-tiny", "border-primary", "text-primary", "flex", "items-center", "justify-center", "rounded-sm", "text-xs", "font-semibold", 3, "disabled", "ngClass", "click"]];
  },
  template: function MnemonicConfirmBackupPage_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](0, "common-page", 0)(1, "div", 1)(2, "div", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵi18n"](3, 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](4, "div", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵi18n"](5, 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](6, "div", 6);
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtemplate"](7, MnemonicConfirmBackupPage_ng_container_7_Template, 7, 8, "ng-container", 7);
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](8, "div", 8);
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtemplate"](9, MnemonicConfirmBackupPage_ng_container_9_Template, 3, 0, "ng-container", 9)(10, MnemonicConfirmBackupPage_ng_container_10_Template, 3, 0, "ng-container", 9);
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](11, "div", 10);
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtemplate"](12, MnemonicConfirmBackupPage_ng_container_12_Template, 3, 5, "ng-container", 7);
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](13, "button", 11);
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵlistener"]("click", function MnemonicConfirmBackupPage_Template_button_click_13_listener() {
        return ctx.finish();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](14, "bn-loading-wrapper", 12);
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtext"](15);
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]()()();
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("contentSafeArea", true)("contentBackground", "white")("headerBackground", "transparent")("headerTranslucent", false)("footerTranslucent", false)("footerOpacity", 0.8);
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](7);
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("ngForOf", ctx.exhibitionnemonicArr);
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("ngIf", !ctx.allFlag);
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("ngIf", !ctx.btnFlag);
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("ngForOf", ctx._configMnemonicArr);
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵclassProp"]("opacity-30", ctx.btnFlag);
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("disabled", ctx.btnFlag || ctx.finish.running);
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("loadingTheme", "ellipsis")("waitFor", ctx.finish.running);
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtextInterpolate"](ctx.nextBtcText);
    }
  },
  dependencies: [_modules_page_module__WEBPACK_IMPORTED_MODULE_3__.CommonPageModule, _libs_bnf_components_ripple_button_ripple_button_directive__WEBPACK_IMPORTED_MODULE_5__.RippleButtonDirective, _angular_common__WEBPACK_IMPORTED_MODULE_10__.NgClass, _angular_common__WEBPACK_IMPORTED_MODULE_10__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_10__.NgIf, _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_6__.CommonPageComponent, _components_icon_icon_component__WEBPACK_IMPORTED_MODULE_7__.IconComponent, _libs_bnf_components_loading_wrapper_loading_wrapper_component__WEBPACK_IMPORTED_MODULE_8__.LoadingWrapperComponent],
  styles: ["[_nghost-%COMP%]   ._wait-mne-box[_ngcontent-%COMP%] {\n  width: 20.3325vw;\n  height: 11.2vw;\n  box-shadow: 0px 0px 0px 0.5px #dfe4f6;\n}\n[_nghost-%COMP%]   ._select-mne-box[_ngcontent-%COMP%] {\n  width: 27.6466666667vw;\n  height: 12.8vw;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL2FwcHMvd2FsbGV0L3NyYy9wYWdlcy9tbmVtb25pYy9wYWdlcy9tbmVtb25pYy1jb25maXJtLWJhY2t1cC9tbmVtb25pYy1jb25maXJtLWJhY2t1cC5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFDRTtFQUNFLGdCQUFBO0VBQ0EsY0FBQTtFQUNBLHFDQUFBO0FBQUo7QUFFRTtFQUNFLHNCQUFBO0VBQ0EsY0FBQTtBQUFKIiwic291cmNlc0NvbnRlbnQiOlsiOmhvc3Qge1xyXG4gIC5fd2FpdC1tbmUtYm94IHtcclxuICAgIHdpZHRoOiBjYWxjKCgxMDB2dyAtIDE4LjY3dncpIC8gNCk7XHJcbiAgICBoZWlnaHQ6IDExLjJ2dztcclxuICAgIGJveC1zaGFkb3c6IDBweCAwcHggMHB4IDAuNXB4ICNkZmU0ZjY7XHJcbiAgfVxyXG4gIC5fc2VsZWN0LW1uZS1ib3gge1xyXG4gICAgd2lkdGg6IGNhbGMoKDEwMHZ3IC0gMTcuMDZ2dykgLyAzKTtcclxuICAgIGhlaWdodDogMTIuOHZ3O1xyXG4gIH1cclxufVxyXG4iXSwic291cmNlUm9vdCI6IiJ9 */"],
  changeDetection: 0
});
(0,tslib__WEBPACK_IMPORTED_MODULE_11__.__decorate)([MnemonicConfirmBackupPage.State({
  depth: Infinity
}), (0,tslib__WEBPACK_IMPORTED_MODULE_11__.__metadata)("design:type", Array)], MnemonicConfirmBackupPage.prototype, "exhibitionnemonicArr", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_11__.__decorate)([MnemonicConfirmBackupPage.State(), MnemonicConfirmBackupPage.QueryParam('mnemonicArr'), (0,tslib__WEBPACK_IMPORTED_MODULE_11__.__metadata)("design:type", Array)], MnemonicConfirmBackupPage.prototype, "configMnemonicArr", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_11__.__decorate)([MnemonicConfirmBackupPage.States(), (0,tslib__WEBPACK_IMPORTED_MODULE_11__.__metadata)("design:type", Array)], MnemonicConfirmBackupPage.prototype, "_configMnemonicArr", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_11__.__decorate)([MnemonicConfirmBackupPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_11__.__metadata)("design:type", Object)], MnemonicConfirmBackupPage.prototype, "allFlag", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_11__.__decorate)([MnemonicConfirmBackupPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_11__.__metadata)("design:type", Object)], MnemonicConfirmBackupPage.prototype, "btnFlag", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_11__.__decorate)([MnemonicConfirmBackupPage.OnInit(), (0,tslib__WEBPACK_IMPORTED_MODULE_11__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_11__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_11__.__metadata)("design:returntype", Promise)], MnemonicConfirmBackupPage.prototype, "getWalletInfoAndMnemonic", null);
(0,tslib__WEBPACK_IMPORTED_MODULE_11__.__decorate)([MnemonicConfirmBackupPage.OnReady(), (0,tslib__WEBPACK_IMPORTED_MODULE_11__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_11__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_11__.__metadata)("design:returntype", Promise)], MnemonicConfirmBackupPage.prototype, "autoComplete", null);
(0,tslib__WEBPACK_IMPORTED_MODULE_11__.__decorate)([MnemonicConfirmBackupPage.QueryParams(), (0,tslib__WEBPACK_IMPORTED_MODULE_11__.__metadata)("design:type", Object)], MnemonicConfirmBackupPage.prototype, "_data", void 0);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MnemonicConfirmBackupPage);

/***/ })

}]);
//# sourceMappingURL=default-apps_wallet_src_pages_mnemonic_pages_mnemonic-confirm-backup_mnemonic-confirm-backup_-f6fc5f.js.map