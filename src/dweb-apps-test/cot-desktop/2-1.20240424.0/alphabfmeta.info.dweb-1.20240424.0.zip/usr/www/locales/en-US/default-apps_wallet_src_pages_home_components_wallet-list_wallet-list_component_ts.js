"use strict";
(self["webpackChunkwallet"] = self["webpackChunkwallet"] || []).push([["default-apps_wallet_src_pages_home_components_wallet-list_wallet-list_component_ts"],{

/***/ 79345:
/*!************************************************************************************!*\
  !*** ./apps/wallet/src/pages/home/components/wallet-list/wallet-list.component.ts ***!
  \************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   WalletListComponent: () => (/* binding */ WalletListComponent),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 52542);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! tslib */ 90505);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @angular/core */ 61039);
/* harmony import */ var _bnqkl_framework_animations__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @bnqkl/framework/animations */ 43127);
/* harmony import */ var _modules_comp_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ~modules/comp.module */ 65773);
/* harmony import */ var _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @bnqkl/wallet-base/services/wallet/chain-base */ 27187);
/* harmony import */ var _bnqkl_wallet_base_services_wallet_wallet_data_storage__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @bnqkl/wallet-base/services/wallet/wallet-data-storage */ 63024);
/* harmony import */ var _bnqkl_framework_helpers__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @bnqkl/framework/helpers */ 12169);
/* harmony import */ var _bnqkl_util_web_extends_map__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @bnqkl/util-web/extends-map */ 37689);
/* harmony import */ var _bnqkl_util_web_extends_promise__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @bnqkl/util-web/extends-promise */ 87778);
/* harmony import */ var _wallet_list_resolver__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./wallet-list.resolver */ 9104);
/* harmony import */ var _bnqkl_wallet_base_services_wallet__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @bnqkl/wallet-base/services/wallet */ 20609);
/* harmony import */ var _libs_bnf_directives_var_directive__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../../../../../../libs/bnf/directives/var.directive */ 16648);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @angular/common */ 6729);
/* harmony import */ var _components_icon_icon_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../../../components/icon/icon.component */ 74703);
/* harmony import */ var _pipes_color_color_pipe__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../../../pipes/color/color.pipe */ 76489);
/* harmony import */ var _libs_bnf_pipes_address_hidden_address_hidden_pipe__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../../../../../../../libs/bnf/pipes/address-hidden/address-hidden.pipe */ 35222);
/* harmony import */ var _pipes_chainIcon_chain_icon_pipe__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../../../../pipes/chainIcon/chain-icon.pipe */ 43040);

var _class;


















function WalletListComponent_li_1_div_5_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](0, "div", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelement"](1, "div", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("@fadeInLeft", undefined);
  }
}
const _c0 = a0 => ({
  "border-primary border-[2px]": a0
});
function WalletListComponent_li_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r5 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](0, "li", 3)(1, "button", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("click", function WalletListComponent_li_1_Template_button_click_1_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵrestoreView"](_r5);
      const item_r2 = restoredCtx.$implicit;
      const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵresetView"](ctx_r4.selectMainWallet(item_r2));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelement"](2, "img", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](3, "div", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](5, WalletListComponent_li_1_div_5_Template, 2, 1, "div", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const item_r2 = ctx.$implicit;
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("src", item_r2.headSculpture, _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵsanitizeUrl"])("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpureFunction1"](5, _c0, ctx_r0.isSelectedMainWallet(item_r2)));
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngClass", ctx_r0.isSelectedMainWallet(item_r2) ? "text-primary" : "text-title");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtextInterpolate1"](" ", item_r2.name, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngIf", ctx_r0.isSelectedMainWallet(item_r2));
  }
}
function WalletListComponent_Conditional_2_ng_container_9_li_1_Conditional_6_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelement"](0, "w-icon", 20);
  }
}
const _c1 = (a0, a1) => [a0, a1];
const _c2 = a1 => ({
  prefix: "icon",
  chain: a1
});
function WalletListComponent_Conditional_2_ng_container_9_li_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r14 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](0, "li", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("click", function WalletListComponent_Conditional_2_ng_container_9_li_1_Template_li_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵrestoreView"](_r14);
      const item_r7 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"]().$implicit;
      const ctx_r12 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵresetView"](ctx_r12.selectMainWalletChainAddress(item_r7));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](1, "div", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelement"](2, "w-icon", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipe"](3, "chainIcon");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](4, "div", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](6, WalletListComponent_Conditional_2_ng_container_9_li_1_Conditional_6_Template, 1, 0, "w-icon", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const isDisabled_r10 = ctx.wVar;
    const item_r7 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"]().$implicit;
    const ctx_r9 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpureFunction2"](7, _c1, isDisabled_r10 ? "pointer-events-none grayscale" : "", ctx_r9.isSelectedWallet(item_r7) ? "bg-line border-tiny border-primary" : "bg-grey border-tiny border-transparent"));
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("name", _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipeBind2"](3, 4, item_r7.symbol, _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpureFunction1"](10, _c2, item_r7.chainName)));
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtextInterpolate"](item_r7.chainName);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵconditional"](6, ctx_r9.isSelectedWallet(item_r7) ? 6 : -1);
  }
}
function WalletListComponent_Conditional_2_ng_container_9_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](1, WalletListComponent_Conditional_2_ng_container_9_li_1_Template, 7, 12, "li", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const item_r7 = ctx.$implicit;
    const ctx_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("wVar", ctx_r6.isDisabledAddress(item_r7));
  }
}
const _c3 = a0 => ({
  "--color-1": a0
});
function WalletListComponent_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](0, "div", 10)(1, "h4", 11)(2, "div", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelement"](3, "w-icon", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipe"](4, "color");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipe"](6, "addressHidden");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵprojection"](7);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](8, "ul");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](9, WalletListComponent_Conditional_2_ng_container_9_Template, 2, 1, "ng-container", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("@listFadeInRight", ctx_r1.listFadeInRightState);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpureFunction1"](10, _c3, _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipeBind1"](4, 6, "text-title")));
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipeBind1"](6, 8, ctx_r1.showActiveChainAddress), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngForOf", ctx_r1.showMainWalletChainAddressList)("ngForTrackBy", ctx_r1.trackByKey("addressKey"));
  }
}
const _c4 = [[["", "titleEnd", ""]]];
const _c5 = ["[titleEnd]"];
/**
 * 列表计算缓存器
 * 因为要根据不同的条件对列表进行过筛，所以这里提供了一套基于元数据与条件信息的缓存
 */
const chainListFilter = (0,_bnqkl_framework_helpers__WEBPACK_IMPORTED_MODULE_5__.$memoize)((chainList, chain) => chainList.filter(item => item.chain === chain), (chainList, chain) => (0,_bnqkl_framework_helpers__WEBPACK_IMPORTED_MODULE_5__.$tuple)([chainList.valueOf(), chain]));
chainListFilter.cache = new WeakMap();
/**
 * 钱包列表展示组件
 * 由左右两部分组成，左边时币种，右边时该币种对应的地址列表
 */
class WalletListComponent extends _modules_comp_module__WEBPACK_IMPORTED_MODULE_2__.CommonCompBase {
  constructor() {
    super(...arguments);
    /** 因为是双列布局，所以需要通过独立的 padding-top 配置来为两列同时配置 padding-top */
    this.paddingTop = 0;
    /** 因为是双列布局，所以需要通过独立的 padding-bottom 配置来为两列同时配置 padding-bottom */
    this.paddingBottom = 0;
    /** 因为是双列布局，所以需要通过独立的 padding-bottom 配置来为两列同时配置 padding-left */
    this.paddingLeft = 0;
    /** 因为是双列布局，所以需要通过独立的 padding-bottom 配置来为两列同时配置 padding-right */
    this.paddingRight = 0;
    /** 是否以可选中的模式出现 */
    this.selectable = false;
    /** 不可选择的地址组, 针对不可自己转自己，只区分地址就行 */
    this.disabledAddressList = [];
    /** 内建的身份钱包列表  */
    this.builtinMainWalletList = [];
    /** 链名 */
    this.CHAIN_NAME = _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_3__.CHAIN_NAME;
    /** 选中事件 */
    this.clickWalletItem = new _angular_core__WEBPACK_IMPORTED_MODULE_15__.EventEmitter();
  }
  /** 判断是否为不可选择地址 */
  isDisabledAddress(item) {
    return this.disabledAddressList.includes(item.address);
  }
  /** 判断指定钱包是否选中 */
  isSelectedWallet(item) {
    var _this$selectedWallet, _this$selectedWallet2;
    return ((_this$selectedWallet = this.selectedWallet) === null || _this$selectedWallet === void 0 ? void 0 : _this$selectedWallet.chain) === item.chainName && ((_this$selectedWallet2 = this.selectedWallet) === null || _this$selectedWallet2 === void 0 ? void 0 : _this$selectedWallet2.address) === item.address;
  }
  /** 要展示的钱包列表 */
  get showMainWalletList() {
    var _this$mainWalletList;
    const list = (_this$mainWalletList = this.mainWalletList) !== null && _this$mainWalletList !== void 0 ? _this$mainWalletList : this.builtinMainWalletList;
    return list;
  }
  get showMainWalletChainAddressList() {
    var _this$activeMainWalle;
    return ((_this$activeMainWalle = this.activeMainWallet) === null || _this$activeMainWalle === void 0 ? void 0 : _this$activeMainWalle.addressKeyList) || [];
  }
  /** 获取身份钱包 */
  initMainWalletList() {
    var _this = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this.builtinMainWalletList = yield _this.getResolver(_wallet_list_resolver__WEBPACK_IMPORTED_MODULE_8__.AllMainWalletListResolverForCom);
    })();
  }
  // #endregion
  // #region
  /** 获取选中的钱包 */
  getSelectedWallet() {
    var _this2 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this2.selectedWallet = yield _this2.getResolver(_wallet_list_resolver__WEBPACK_IMPORTED_MODULE_8__.SelectedWalletResolverForCom);
    })();
  }
  // #endregion
  // #region
  /** 特殊标识, 代表全部 */

  // #endregion
  /** 初始化数据 */
  initWalletData() {
    var _this3 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const tasks = new _bnqkl_util_web_extends_promise__WEBPACK_IMPORTED_MODULE_7__.TaskList();
      if (_this3.mainWalletList == undefined) {
        _this3.console.log('no mainWalletList, get default');
        tasks.next = _this3.initMainWalletList();
      }
      /// 哪个需要选中由钱包使用者的数据里面做判断
      if (_this3.selectedWallet == undefined && _this3.selectable) {
        tasks.next = _this3.getSelectedWallet();
      }
      yield tasks.toPromise();
      if (_this3.showMainWalletList.length) {
        const walletV2Service = _this3.injectorForceGet(_bnqkl_wallet_base_services_wallet__WEBPACK_IMPORTED_MODULE_9__.WalletV2Service);
        const walletDataStorageV2Service = _this3.injectorForceGet(_bnqkl_wallet_base_services_wallet_wallet_data_storage__WEBPACK_IMPORTED_MODULE_4__.WalletDataStorageV2Service);
        const last = yield walletV2Service.getActivateAddressWalletInfo();
        const lastWallet = yield walletDataStorageV2Service.getMainWalletInfo(last.mainWalletId);
        const hasFind = _this3.showMainWalletList.find(item => item.mainWalletId === lastWallet.mainWalletId);
        const defaultMainWallet = hasFind || _this3.showMainWalletList[0];
        _this3.activeMainWallet = defaultMainWallet;
        _this3.showActiveChainAddress = defaultMainWallet.addressKeyList[0].address;
      }
    })();
  }
  /** 选中权益 */
  selectMainWallet(wallet) {
    this.activeMainWallet = wallet;
    this.showActiveChainAddress = wallet.addressKeyList[0].address;
    return this.showActiveChainAddress = wallet.addressKeyList[0].address;
  }
  /** 是否是选中的身份钱包 */
  isSelectedMainWallet(wallet) {
    var _this$activeMainWalle2;
    return wallet.mainWalletId === ((_this$activeMainWalle2 = this.activeMainWallet) === null || _this$activeMainWalle2 === void 0 ? void 0 : _this$activeMainWalle2.mainWalletId);
  }
  /** 选择身份钱包 */
  selectMainWalletChainAddress(item) {
    var _this4 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const walletDataStorageV2Service = _this4.injectorForceGet(_bnqkl_wallet_base_services_wallet_wallet_data_storage__WEBPACK_IMPORTED_MODULE_4__.WalletDataStorageV2Service);
      const addressInfo = _this4.selectedWallet = yield walletDataStorageV2Service.getChainAddressInfo(item.addressKey);
      yield (0,_bnqkl_util_web_extends_promise__WEBPACK_IMPORTED_MODULE_7__.sleep)(180);
      _this4.clickWalletItem.emit(addressInfo);
    })();
  }
  /** 动画的状态机 */
  get listFadeInRightState() {
    return ':' + this.showMainWalletList.length;
  }
}
_class = WalletListComponent;
_class._allChain = {
  chain: '*',
  activeIcon: 'wallet-all-s',
  unactiveIcon: 'wallet-all-n'
};
/** 返回一个混入 all-chain 的 support-chain 列表 */
_class._chainListWithAll = _bnqkl_util_web_extends_map__WEBPACK_IMPORTED_MODULE_6__.EasyWeakMap.from({
  creater(list) {
    return [
    /// 加入全部链的支持
    _class._allChain, ...list];
  }
});
_class.ɵfac = /*@__PURE__*/(() => {
  let ɵWalletListComponent_BaseFactory;
  return function WalletListComponent_Factory(t) {
    return (ɵWalletListComponent_BaseFactory || (ɵWalletListComponent_BaseFactory = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵgetInheritedFactory"](_class)))(t || _class);
  };
})();
_class.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵdefineComponent"]({
  type: _class,
  selectors: [["w-home-wallet-list"]],
  hostVars: 8,
  hostBindings: function WalletListComponent_HostBindings(rf, ctx) {
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵstyleProp"]("--wallet-list-padding-top", ctx.paddingTop)("--wallet-list-padding-bottom", ctx.paddingBottom)("--wallet-list-padding-left", ctx.paddingLeft)("--wallet-list-padding-right", ctx.paddingRight);
    }
  },
  inputs: {
    paddingTop: "paddingTop",
    paddingBottom: "paddingBottom",
    paddingLeft: "paddingLeft",
    paddingRight: "paddingRight",
    selectable: "selectable",
    disabledAddressList: "disabledAddressList",
    selectedWallet: "selectedWallet",
    mainWalletList: "mainWalletList"
  },
  outputs: {
    clickWalletItem: "clickWalletItem"
  },
  standalone: true,
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵInheritDefinitionFeature"], _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵStandaloneFeature"]],
  ngContentSelectors: _c5,
  decls: 3,
  vars: 3,
  consts: [[1, "grid", "h-min", "grid-flow-row", "gap-4", "overflow-y-auto", "overflow-x-hidden", "pb-[var(--wallet-list-padding-bottom)]", "pl-[var(--wallet-list-padding-left)]", "pt-[var(--wallet-list-padding-top)]"], ["class", "flex items-center", 4, "ngFor", "ngForOf", "ngForTrackBy"], ["class", "ml-2 h-full flex-grow overflow-y-auto overflow-x-hidden pb-[var(--wallet-list-padding-bottom)] pr-[var(--wallet-list-padding-right)] pt-[var(--wallet-list-padding-top)]"], [1, "flex", "items-center"], [1, "grid-areas-[icon]", "w-13", "grid", 3, "click"], ["alt", "", "srcset", "", 1, "mb-1", "h-[32px]", "w-[32px]", "place-self-center", "rounded-full", 3, "src", "ngClass"], [1, "text-xss", "w-full", "overflow-hidden", "text-ellipsis", "whitespace-nowrap", "text-center", 3, "ngClass"], ["class", "self-start pl-3.5", 4, "ngIf"], [1, "self-start", "pl-3.5"], [1, "bg-primary", "h-[32px]", "w-0.5", "rounded-lg"], [1, "ml-2", "h-full", "flex-grow", "overflow-y-auto", "overflow-x-hidden", "pb-[var(--wallet-list-padding-bottom)]", "pr-[var(--wallet-list-padding-right)]", "pt-[var(--wallet-list-padding-top)]"], [1, "flex", "h-10", "items-center", "justify-between", "text-sm", "font-semibold"], [1, "flex", "items-center", "justify-start"], ["name", "address", 1, "icon-5"], [4, "ngFor", "ngForOf", "ngForTrackBy"], ["class", "text-title mb-2 flex items-center justify-between rounded-lg px-3 py-3", 3, "ngClass", "click", 4, "wVar"], [1, "text-title", "mb-2", "flex", "items-center", "justify-between", "rounded-lg", "px-3", "py-3", 3, "ngClass", "click"], [1, "mr-2", "justify-self-start", "text-3xl", 3, "name"], [1, "text-xs", "font-bold"], ["name", "language-selected-1", "class", "border-tiny border-subtext mr-2 mt-[2px] rounded-[4px] p-[2px]"], ["name", "language-selected-1", 1, "border-tiny", "border-subtext", "mr-2", "mt-[2px]", "rounded-[4px]", "p-[2px]"]],
  template: function WalletListComponent_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵprojectionDef"](_c4);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](0, "ul", 0);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](1, WalletListComponent_li_1_Template, 6, 7, "li", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](2, WalletListComponent_Conditional_2_Template, 10, 12, "div", 2);
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngForOf", ctx.showMainWalletList)("ngForTrackBy", ctx.trackByKey("mainWalletId"));
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵconditional"](2, !!ctx.showMainWalletChainAddressList.length ? 2 : -1);
    }
  },
  dependencies: [_modules_comp_module__WEBPACK_IMPORTED_MODULE_2__.CommonCompModule, _libs_bnf_directives_var_directive__WEBPACK_IMPORTED_MODULE_10__.VarDirective, _angular_common__WEBPACK_IMPORTED_MODULE_16__.NgClass, _angular_common__WEBPACK_IMPORTED_MODULE_16__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_16__.NgIf, _components_icon_icon_component__WEBPACK_IMPORTED_MODULE_11__.IconComponent, _pipes_color_color_pipe__WEBPACK_IMPORTED_MODULE_12__.ColorPipe, _libs_bnf_pipes_address_hidden_address_hidden_pipe__WEBPACK_IMPORTED_MODULE_13__.AddressHiddenPipe, _pipes_chainIcon_chain_icon_pipe__WEBPACK_IMPORTED_MODULE_14__.ChainIconPipe],
  styles: ["[_nghost-%COMP%] {\n    display: flex;\n    flex-direction: row\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL2FwcHMvd2FsbGV0L3NyYy9wYWdlcy9ob21lL2NvbXBvbmVudHMvd2FsbGV0LWxpc3Qvd2FsbGV0LWxpc3QuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQ0U7SUFBQSxhQUFBO0lBQUE7QUFBQSIsInNvdXJjZXNDb250ZW50IjpbIjpob3N0IHtcclxuICBAYXBwbHkgZmxleCBmbGV4LXJvdztcclxufVxyXG4iXSwic291cmNlUm9vdCI6IiJ9 */"],
  data: {
    animation: [_bnqkl_framework_animations__WEBPACK_IMPORTED_MODULE_1__.listFadeRightTrigger, _bnqkl_framework_animations__WEBPACK_IMPORTED_MODULE_1__.listFadeInRightTrigger, _bnqkl_framework_animations__WEBPACK_IMPORTED_MODULE_1__.listFadeOutLeftTrigger, _bnqkl_framework_animations__WEBPACK_IMPORTED_MODULE_1__.fadeInLeftTrigger]
  },
  changeDetection: 0
});
(0,tslib__WEBPACK_IMPORTED_MODULE_17__.__decorate)([WalletListComponent.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_17__.__metadata)("design:type", Object)], WalletListComponent.prototype, "selectedWallet", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_17__.__decorate)([WalletListComponent.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_17__.__metadata)("design:type", Object)], WalletListComponent.prototype, "activeMainWallet", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_17__.__decorate)([WalletListComponent.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_17__.__metadata)("design:type", String)], WalletListComponent.prototype, "showActiveChainAddress", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_17__.__decorate)([WalletListComponent.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_17__.__metadata)("design:type", Array)], WalletListComponent.prototype, "builtinMainWalletList", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_17__.__decorate)([WalletListComponent.OnInit(), (0,tslib__WEBPACK_IMPORTED_MODULE_17__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_17__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_17__.__metadata)("design:returntype", Promise)], WalletListComponent.prototype, "initWalletData", null);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (WalletListComponent);

/***/ })

}]);
//# sourceMappingURL=default-apps_wallet_src_pages_home_components_wallet-list_wallet-list_component_ts.js.map