"use strict";
(self["webpackChunkwallet"] = self["webpackChunkwallet"] || []).push([["apps_wallet_src_pages_home_pages_home-import-private-key-wallet_home-import-private-key-walle-cb1ddf"],{

/***/ 93170:
/*!*********************************************************************************************************************!*\
  !*** ./apps/wallet/src/pages/home/pages/home-import-private-key-wallet/home-import-private-key-wallet.component.ts ***!
  \*********************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   HomeImportPrivateKeyWalletPage: () => (/* binding */ HomeImportPrivateKeyWalletPage),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 52542);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! tslib */ 90505);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/core */ 61039);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/forms */ 7820);
/* harmony import */ var _bnqkl_framework_animations__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @bnqkl/framework/animations */ 43127);
/* harmony import */ var _bnqkl_framework_controllers__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @bnqkl/framework/controllers */ 47919);
/* harmony import */ var _bnqkl_framework_helpers__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @bnqkl/framework/helpers */ 12169);
/* harmony import */ var _bnqkl_framework_plugins__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @bnqkl/framework/plugins */ 43990);
/* harmony import */ var _bnqkl_wallet_base_services_wallet__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @bnqkl/wallet-base/services/wallet */ 20609);
/* harmony import */ var _modules_page_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ~modules/page.module */ 77538);
/* harmony import */ var _libs_bnf_components_ripple_button_ripple_button_directive__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../../../../../libs/bnf/components/ripple-button/ripple-button.directive */ 16505);
/* harmony import */ var _libs_bnf_directives_form_errors_directive__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../../../../../libs/bnf/directives/form-errors.directive */ 29541);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @angular/common */ 6729);
/* harmony import */ var _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../../../../../../libs/bnf/modules/page/common-page/common-page.component */ 62052);
/* harmony import */ var _components_icon_icon_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../../../components/icon/icon.component */ 74703);
/* harmony import */ var _libs_bnf_pipes_errors_errors_pipe__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../../../../../../libs/bnf/pipes/errors/errors.pipe */ 68362);
/* harmony import */ var _pipes_color_color_pipe__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../../../pipes/color/color.pipe */ 76489);

var _class;


















const _c10 = a0 => ({
  "--color-1": a0
});
function HomeImportPrivateKeyWalletPage_ng_template_10_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](1, "w-icon", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipe"](2, "color");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](3, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵi18n"](4, 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpureFunction1"](5, _c10, _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipeBind1"](2, 3, "error")));
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵi18nExp"](ctx_r0.data.chainName);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵi18nApply"](4);
  }
}
function HomeImportPrivateKeyWalletPage_div_12_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div", 16)(1, "div", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵi18n"](2, 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵi18nExp"](ctx_r1.chainName);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵi18nApply"](2);
  }
}
const _c13 = a0 => ({
  "text-error": a0
});
class HomeImportPrivateKeyWalletPage extends _modules_page_module__WEBPACK_IMPORTED_MODULE_6__.CommonPageBase {
  constructor() {
    var _this;
    /** 传进来的返回路由 */
    super(...arguments);
    _this = this;
    this.backUrl = '';
    /** 传进来的路径 */
    this.path = 44;
    this.chainV2Service = (0,_angular_core__WEBPACK_IMPORTED_MODULE_13__.inject)(_bnqkl_wallet_base_services_wallet__WEBPACK_IMPORTED_MODULE_5__.ChainV2Service);
    /** 表单验证服务 */
    this.validators = new _bnqkl_framework_controllers__WEBPACK_IMPORTED_MODULE_2__.FormValidatorsController(this);
    this.showTips = false;
    this.chainName = '';
    /** 密码 */
    this.privateKey = new _angular_forms__WEBPACK_IMPORTED_MODULE_14__.FormControl('', {
      nonNullable: true,
      validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_14__.Validators.required, this.validators.whitespace],
      asyncValidators: [(
      /*#__PURE__*/
      /** 判断助记词是否正确 */
      function () {
        var _ref = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (control) {
          /// 有其它错误了
          if (control.errors) {
            return null;
          }
          try {
            const chainService = _this.chainV2Service.getChainService(_this.data.chainName);
            const address = yield chainService.getAddressByPrivateKey(control.value.trim(), _this.path || 44);
            if ((0,_bnqkl_framework_helpers__WEBPACK_IMPORTED_MODULE_3__.$isNoEmptyString)(address) == false) {
              return {
                notcomply: true
              };
            }
          } catch (err) {
            return {
              notcomply: true
            };
          }
          return null;
        });
        return function (_x) {
          return _ref.apply(this, arguments);
        };
      }())]
    });
    /** 要提交的表单与复合验证 */
    this.form = new _angular_forms__WEBPACK_IMPORTED_MODULE_14__.FormGroup({
      privateKey: this.privateKey
    }, {
      validators: [],
      asyncValidators: []
    });
  }
  init() {
    this.showTips = this.data.chainName === _bnqkl_wallet_base_services_wallet__WEBPACK_IMPORTED_MODULE_5__.CHAIN_NAME.Ethereum || this.data.chainName === _bnqkl_wallet_base_services_wallet__WEBPACK_IMPORTED_MODULE_5__.CHAIN_NAME.Binance;
    this.chainName = this.data.chainName === _bnqkl_wallet_base_services_wallet__WEBPACK_IMPORTED_MODULE_5__.CHAIN_NAME.Ethereum ? _bnqkl_wallet_base_services_wallet__WEBPACK_IMPORTED_MODULE_5__.CHAIN_NAME.Binance : _bnqkl_wallet_base_services_wallet__WEBPACK_IMPORTED_MODULE_5__.CHAIN_NAME.Ethereum;
  }
  /** 提交事件 */
  onSubmit() {
    var _this2 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      try {
        /** 判断是否已经导入过了 */
        const walletDataStorageV2Service = _this2.injectorForceGet(_bnqkl_wallet_base_services_wallet__WEBPACK_IMPORTED_MODULE_5__.WalletDataStorageV2Service);
        const chainService = _this2.chainV2Service.getChainService(_this2.data.chainName);
        const address = yield chainService.getAddressByPrivateKey(_this2.privateKey.value.trim(), _this2.path || 44);
        const allAddressInfo = yield walletDataStorageV2Service.getAllChainAddressInfoList();
        let hasFind = false;
        for (let i = 0; i < allAddressInfo.length; i++) {
          const item = allAddressInfo[i];
          hasFind = yield _this2.chainV2Service.isAddressEqual(_this2.data.chainName, item.address, address);
          if (hasFind) {
            break;
          }
        }
        if (hasFind) {
          _bnqkl_framework_plugins__WEBPACK_IMPORTED_MODULE_4__.Toast.show("\u8A72\u5730\u5740\u5DF2\u5B58\u5728");
          return;
        }
      } catch (err) {
        /// 不管 避免中断
      }
      /// 创建成功页面
      _this2.nav.routeTo('/mnemonic/create-wallet', {
        mnemonic: _this2.privateKey.value.trim(),
        chainName: _this2.data.chainName,
        importType: _bnqkl_wallet_base_services_wallet__WEBPACK_IMPORTED_MODULE_5__.WALLET_IMPORT_TYPE.privateKey,
        path: _this2.path || 44,
        addWallet: true,
        showBackupBtn: false,
        backUrl: 'home-create-or-import-wallet'
      });
    })();
  }
}
_class = HomeImportPrivateKeyWalletPage;
_class.ɵfac = /*@__PURE__*/(() => {
  let ɵHomeImportPrivateKeyWalletPage_BaseFactory;
  return function HomeImportPrivateKeyWalletPage_Factory(t) {
    return (ɵHomeImportPrivateKeyWalletPage_BaseFactory || (ɵHomeImportPrivateKeyWalletPage_BaseFactory = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵgetInheritedFactory"](_class)))(t || _class);
  };
})();
_class.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdefineComponent"]({
  type: _class,
  selectors: [["w-home-import-private-key-wallet-page"]],
  inputs: {
    data: "data",
    backUrl: "backUrl",
    path: ["path", "path", value => {
      // eslint-disable-next-line @angular-eslint/no-input-rename
      if (value === undefined || value === 'undefined') {
        // eslint-disable-next-line @angular-eslint/no-input-rename
        return 44;
      }
      // eslint-disable-next-line @angular-eslint/no-input-rename
      const v = isNaN(+value) ? 44 : +value;
      // eslint-disable-next-line @angular-eslint/no-input-rename
      return [44, 86, 84, 49].includes(v) ? v : 44;
    }]
  },
  standalone: true,
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵInputTransformsFeature"], _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵInheritDefinitionFeature"], _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵStandaloneFeature"]],
  decls: 15,
  vars: 17,
  consts: () => {
    let i18n_0;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_IMPORT_WALLET$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_IMPORT_PRIVATE_KEY_WALLET_HOME_IMPORT_PRIVATE_KEY_WALLET_COMPONENT_TS_1 = goog.getMsg("Import Wallet");
      i18n_0 = MSG_EXTERNAL_IMPORT_WALLET$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_IMPORT_PRIVATE_KEY_WALLET_HOME_IMPORT_PRIVATE_KEY_WALLET_COMPONENT_TS_1;
    } else {
      i18n_0 = "\u5C0E\u5165\u9322\u5305";
    }
    let i18n_2;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_PRIVATE_KEY___CHAINNAME__$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_IMPORT_PRIVATE_KEY_WALLET_HOME_IMPORT_PRIVATE_KEY_WALLET_COMPONENT_TS_3 = goog.getMsg(" Private Key ({$interpolation}) ", {
        "interpolation": "\uFFFD0\uFFFD"
      }, {
        original_code: {
          "interpolation": "{{ data.chainName }}"
        }
      });
      i18n_2 = MSG_EXTERNAL_PRIVATE_KEY___CHAINNAME__$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_IMPORT_PRIVATE_KEY_WALLET_HOME_IMPORT_PRIVATE_KEY_WALLET_COMPONENT_TS_3;
    } else {
      i18n_2 = "\u79C1\u9470\uFF08" + "\uFFFD0\uFFFD" + "\uFF09 ";
    }
    let i18n_4;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_ENTER_PRIVATE_KEY$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_IMPORT_PRIVATE_KEY_WALLET_HOME_IMPORT_PRIVATE_KEY_WALLET_COMPONENT_TS_5 = goog.getMsg("Enter private key");
      i18n_4 = MSG_EXTERNAL_ENTER_PRIVATE_KEY$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_IMPORT_PRIVATE_KEY_WALLET_HOME_IMPORT_PRIVATE_KEY_WALLET_COMPONENT_TS_5;
    } else {
      i18n_4 = "\u8F38\u5165\u79C1\u9470";
    }
    let i18n_6;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_CREATE_WALLET$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_IMPORT_PRIVATE_KEY_WALLET_HOME_IMPORT_PRIVATE_KEY_WALLET_COMPONENT_TS_7 = goog.getMsg(" Create Wallet ");
      i18n_6 = MSG_EXTERNAL_CREATE_WALLET$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_IMPORT_PRIVATE_KEY_WALLET_HOME_IMPORT_PRIVATE_KEY_WALLET_COMPONENT_TS_7;
    } else {
      i18n_6 = "\u5275\u5EFA\u9322\u5305";
    }
    let i18n_8;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_THE_ENTERED_PRIVATE_KEY_DOES_NOT_COMPLY_WITH__CHAINNAME__PRIVATE_KEY_RULES$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_IMPORT_PRIVATE_KEY_WALLET_HOME_IMPORT_PRIVATE_KEY_WALLET_COMPONENT_TS__9 = goog.getMsg(" The entered private key does not comply with {$interpolation} private key rules ", {
        "interpolation": "\uFFFD0\uFFFD"
      }, {
        original_code: {
          "interpolation": "{{ data.chainName }}"
        }
      });
      i18n_8 = MSG_EXTERNAL_THE_ENTERED_PRIVATE_KEY_DOES_NOT_COMPLY_WITH__CHAINNAME__PRIVATE_KEY_RULES$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_IMPORT_PRIVATE_KEY_WALLET_HOME_IMPORT_PRIVATE_KEY_WALLET_COMPONENT_TS__9;
    } else {
      i18n_8 = "\u8F38\u5165\u7684\u79C1\u9470\u4E0D\u7B26\u5408 " + "\uFFFD0\uFFFD" + " \u7684\u79C1\u9470\u898F\u5247 ";
    }
    let i18n_11;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_WILL_SYNCHRONIZE_IMPORT_INTO_THE__CHAINNAME__CHAIN_WITH_THE_SAME_PRIVATE_KEY$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_IMPORT_PRIVATE_KEY_WALLET_HOME_IMPORT_PRIVATE_KEY_WALLET_COMPONENT_TS__12 = goog.getMsg(" Will synchronize import into the {$interpolation} chain with the same private key ", {
        "interpolation": "\uFFFD0\uFFFD"
      }, {
        original_code: {
          "interpolation": "{{ chainName }}"
        }
      });
      i18n_11 = MSG_EXTERNAL_WILL_SYNCHRONIZE_IMPORT_INTO_THE__CHAINNAME__CHAIN_WITH_THE_SAME_PRIVATE_KEY$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_IMPORT_PRIVATE_KEY_WALLET_HOME_IMPORT_PRIVATE_KEY_WALLET_COMPONENT_TS__12;
    } else {
      i18n_11 = "\u5C07\u540C\u6B65\u5C0E\u5165 " + "\uFFFD0\uFFFD" + " \u93C8 ";
    }
    return [["headerTitle", i18n_0, 3, "titleColor", "contentBackground", "headerBackground", "headerTranslucent", "contentSafeArea"], [1, "text-title", 3, "formGroup", "ngSubmit"], [1, "mb-2", "flex", "h-10", "w-full", "items-end", "justify-between", "text-xs", "font-semibold"], [1, "flex-shrink-0", "pr-2", "text-sm", 3, "ngClass"], i18n_2, [1, "flex", "rounded-lg", "bg-white", "py-2"], ["rows", "6", "formControlName", "privateKey", "type", "text", "placeholder", i18n_4, 1, "w-full", "px-2"], [3, "wSwitchErrors"], ["wCaseKey", "notcomply"], ["footer", ""], ["class", "mb-6 flex items-center justify-center p-3", 4, "ngIf"], ["bnRippleButton", "", 1, "h-10.5", "from-purple-gradient-start", "to-purple-gradient-end", "w-full", "rounded-full", "bg-gradient-to-b", "text-center", "text-sm", "text-white", 3, "disabled", "click"], i18n_6, [1, "text-error", "my-2", "text-xs"], ["name", "warn-grey", 1, "icon-5"], i18n_8, [1, "mb-6", "flex", "items-center", "justify-center", "p-3"], [1, "text-title", "rounded-6", "inline-block", "bg-white", "px-5", "py-4", "text-center", "shadow-[0_5px_5px_0px_rgba(29,24,228,0.08)]"], i18n_11];
  },
  template: function HomeImportPrivateKeyWalletPage_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "common-page", 0)(1, "form", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("ngSubmit", function HomeImportPrivateKeyWalletPage_Template_form_ngSubmit_1_listener() {
        return ctx.onSubmit();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](2, "fieldset")(3, "legend", 2)(4, "div", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵi18n"](5, 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipe"](6, "errors");
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](7, "div", 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](8, "textarea", 6);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](9, "div", 7);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](10, HomeImportPrivateKeyWalletPage_ng_template_10_Template, 5, 7, "ng-template", 8);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()()();
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](11, "div", 9);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](12, HomeImportPrivateKeyWalletPage_div_12_Template, 3, 1, "div", 10);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](13, "button", 11);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("click", function HomeImportPrivateKeyWalletPage_Template_button_click_13_listener() {
        return ctx.onSubmit();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵi18n"](14, 12);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()()();
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("titleColor", "title")("contentBackground", "grey")("headerBackground", "grey")("headerTranslucent", false)("contentSafeArea", true);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("formGroup", ctx.form);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpureFunction1"](15, _c13, _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipeBind1"](6, 13, ctx.privateKey)));
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵi18nExp"](ctx.data.chainName);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵi18nApply"](5);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("wSwitchErrors", ctx.privateKey);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", ctx.showTips);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵclassProp"]("opacity-30", !ctx.form.valid);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("disabled", !ctx.form.valid);
    }
  },
  dependencies: [_modules_page_module__WEBPACK_IMPORTED_MODULE_6__.CommonPageModule, _libs_bnf_components_ripple_button_ripple_button_directive__WEBPACK_IMPORTED_MODULE_7__.RippleButtonDirective, _libs_bnf_directives_form_errors_directive__WEBPACK_IMPORTED_MODULE_8__.SwitchErrorsDirective, _libs_bnf_directives_form_errors_directive__WEBPACK_IMPORTED_MODULE_8__.SwitchCaseDirective, _angular_common__WEBPACK_IMPORTED_MODULE_15__.NgClass, _angular_common__WEBPACK_IMPORTED_MODULE_15__.NgIf, _angular_forms__WEBPACK_IMPORTED_MODULE_14__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_14__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_14__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_14__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_14__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_14__.FormControlName, _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_9__.CommonPageComponent, _components_icon_icon_component__WEBPACK_IMPORTED_MODULE_10__.IconComponent, _libs_bnf_pipes_errors_errors_pipe__WEBPACK_IMPORTED_MODULE_11__.ErrorsPipe, _pipes_color_color_pipe__WEBPACK_IMPORTED_MODULE_12__.ColorPipe],
  styles: ["/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsInNvdXJjZVJvb3QiOiIifQ== */"],
  data: {
    animation: [_bnqkl_framework_animations__WEBPACK_IMPORTED_MODULE_1__.fadeInUpTrigger]
  },
  changeDetection: 0
});
(0,tslib__WEBPACK_IMPORTED_MODULE_16__.__decorate)([HomeImportPrivateKeyWalletPage.QueryParams(), (0,tslib__WEBPACK_IMPORTED_MODULE_16__.__metadata)("design:type", Object)], HomeImportPrivateKeyWalletPage.prototype, "data", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_16__.__decorate)([HomeImportPrivateKeyWalletPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_16__.__metadata)("design:type", Object)], HomeImportPrivateKeyWalletPage.prototype, "showTips", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_16__.__decorate)([HomeImportPrivateKeyWalletPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_16__.__metadata)("design:type", Object)], HomeImportPrivateKeyWalletPage.prototype, "chainName", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_16__.__decorate)([HomeImportPrivateKeyWalletPage.OnInit(), (0,tslib__WEBPACK_IMPORTED_MODULE_16__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_16__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_16__.__metadata)("design:returntype", void 0)], HomeImportPrivateKeyWalletPage.prototype, "init", null);
(0,tslib__WEBPACK_IMPORTED_MODULE_16__.__decorate)([HomeImportPrivateKeyWalletPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_16__.__metadata)("design:type", Object)], HomeImportPrivateKeyWalletPage.prototype, "privateKey", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_16__.__decorate)([HomeImportPrivateKeyWalletPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_16__.__metadata)("design:type", Object)], HomeImportPrivateKeyWalletPage.prototype, "form", void 0);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (HomeImportPrivateKeyWalletPage);

/***/ }),

/***/ 11606:
/*!************************************************************!*\
  !*** ./libs/bnf/controllers/form-validators.controller.ts ***!
  \************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   FormValidatorsController: () => (/* binding */ FormValidatorsController)
/* harmony export */ });
/* harmony import */ var _bnqkl_framework_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @bnqkl/framework/core */ 63563);
/* harmony import */ var _bnqkl_util_web_extends_map__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @bnqkl/util-web/extends-map */ 37689);


/**
 * 页面表单扩展验证器
 *
 * > 因为涉及到FromControl的生命周期管理，所以这里需要使用Controller模式来获取组件/页面的生命周期
 *
 * 为了确保类型安全, 请遵循以下规则去定义验证器:
 * 1. 尽可能直接提供 $ValidatorFn,比如 `trimRequired(control: AbstractControl): $ValidationErrors | null {...}`
 * 2. 如果不能直接提供 $ValidatorFn, 那么作为工厂模式,必然要有参数传入,比如 `equals(leaderCtrl: AbstractControl): $ValidatorFn {...}`
 */
class FormValidatorsController {
  /**
   * 通过订阅原页面的生命周期，来对订阅的字段进行监听解除
   */
  constructor(comp) {
    /**
     * 判断两个数据字段相等的时，left===right 中 left的数据订阅
     */
    this._equalsLeaderMap = _bnqkl_util_web_extends_map__WEBPACK_IMPORTED_MODULE_1__.EasyMap.from({
      creater(ctrl) {
        const sub = {
          sub$: ctrl.valueChanges.subscribe(() => {
            for (const ctrl of sub.destControls) {
              ctrl.updateValueAndValidity();
            }
          }),
          destControls: new Set()
        };
        return sub;
      }
    });
    (0,_bnqkl_framework_core__WEBPACK_IMPORTED_MODULE_0__.addLifecycleMethods)(comp, 'ngOnDestroy', {
      origin: 'form-validator',
      method: () => {
        for (const {
          sub$
        } of this._equalsLeaderMap.values()) {
          sub$.unsubscribe();
        }
        this._equalsLeaderMap.clear();
      },
      order: Number.MAX_SAFE_INTEGER /* 最后才做这些事情 */
    });
  }
  /** 两个字段对比 相等就过 不相等返回 {equals:true} */
  equals(leaderCtrl) {
    const leader = this._equalsLeaderMap.forceGet(leaderCtrl);
    // pwdCtrl.val
    return follerCtrl => {
      leader.destControls.add(follerCtrl);
      if (leaderCtrl.value === follerCtrl.value) {
        return null;
      }
      return {
        equals: true
      };
    };
  }
  /** 是否包含空格 */
  whitespace(control) {
    const value = control.value;
    if (typeof value === 'string' && /\s/.test(value)) {
      return {
        whitespace: true
      };
    }
    return null;
  }
  /** required 变体, 左右两边不能包含空格 */
  trimRequired(control) {
    const value = control.value;
    if (typeof value === 'string' && value.trim().length === 0 || value == undefined) {
      return {
        trimRequired: true
      };
    }
    return null;
  }
}

/***/ }),

/***/ 47919:
/*!***************************************!*\
  !*** ./libs/bnf/controllers/index.ts ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   FormValidatorsController: () => (/* reexport safe */ _form_validators_controller__WEBPACK_IMPORTED_MODULE_0__.FormValidatorsController),
/* harmony export */   PageReturnController: () => (/* reexport safe */ _page_return_controller__WEBPACK_IMPORTED_MODULE_1__.PageReturnController)
/* harmony export */ });
/* harmony import */ var _form_validators_controller__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./form-validators.controller */ 11606);
/* harmony import */ var _page_return_controller__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./page-return.controller */ 62893);



/***/ }),

/***/ 62893:
/*!********************************************************!*\
  !*** ./libs/bnf/controllers/page-return.controller.ts ***!
  \********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   PageReturnController: () => (/* binding */ PageReturnController)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 54106);
/* harmony import */ var _bnqkl_util_web_decorator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @bnqkl/util-web/decorator */ 18112);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs */ 19177);



/**
 * 页面数据返回值的订阅功能
 * > Controller 必须在构造函数期间执行
 */
class PageReturnController {
  /** 继承日志 */
  get console() {
    return this.fromPage.console;
  }
  /**
   * 传入源页面与目标页面的构造函数，并通过订阅原页面的生命周期，来初始化对路由的订阅
   * 这里依赖 ion-router-outlet 来获取跳转过去的页面
   * 注：该监听返回是全触发（只要页面没被销毁掉不管页面是否处于激活状态）
   * @param specific 用于指定fromPage触发（需要手动指定），业务需要
   */
  constructor(fromPage, toPageCtor, specific = false) {
    this.fromPage = fromPage;
    /** 当前定阅过的页面 */
    this._toPages = new WeakSet();
    /**
     * 订阅到的返回内容，
     * 类型由对应页面的 returnValue$ 的定义决定
     */
    this.pageReturn$ = new rxjs__WEBPACK_IMPORTED_MODULE_1__.Subject();
    const {
      nav
    } = fromPage;
    fromPage.takeUntilDestroy(nav.pageActiveState$).subscribe(event => {
      /// 只监听新激活的页面
      if (event.type !== 'activate') {
        return;
      }
      const toPage = event.target;
      if (toPage instanceof toPageCtor &&
      // 去重
      this._toPages.has(toPage) === false) {
        if (toPage.returnValue$ === undefined) {
          return;
        }
        this._toPages.add(toPage);
        if (specific) {
          var _toPage$specificRetur;
          (_toPage$specificRetur = toPage.specificReturnPages) === null || _toPage$specificRetur === void 0 || _toPage$specificRetur.add(fromPage);
        }
        fromPage.takeUntilDestroy(toPage.returnValue$).subscribe({
          next: data => {
            /// 这里不用判断specific
            if (toPage.specificReturnPages && toPage.specificReturnPages.size) {
              /// 如果有写入，那么就只需要触发相对应页面就行
              toPage.specificReturnPages.has(fromPage) && this.pageReturn$.next(data);
              return;
            }
            this.pageReturn$.next(data);
          },
          complete: () => {
            var _toPage$specificRetur2;
            // 释放内存引用
            (_toPage$specificRetur2 = toPage.specificReturnPages) === null || _toPage$specificRetur2 === void 0 || _toPage$specificRetur2.delete(fromPage);
            return this._toPages.delete(toPage);
          }
        });
      }
    });
  }
}
(0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([_bnqkl_util_web_decorator__WEBPACK_IMPORTED_MODULE_0__.cacheGetter, (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__metadata)("design:type", Object), (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__metadata)("design:paramtypes", [])], PageReturnController.prototype, "console", null);

/***/ })

}]);
//# sourceMappingURL=apps_wallet_src_pages_home_pages_home-import-private-key-wallet_home-import-private-key-walle-cb1ddf.js.map