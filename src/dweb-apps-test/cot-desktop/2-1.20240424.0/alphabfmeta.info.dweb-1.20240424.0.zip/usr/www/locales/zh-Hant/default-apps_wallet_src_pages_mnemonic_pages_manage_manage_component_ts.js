"use strict";
(self["webpackChunkwallet"] = self["webpackChunkwallet"] || []).push([["default-apps_wallet_src_pages_mnemonic_pages_manage_manage_component_ts"],{

/***/ 54414:
/*!*************************************************************************!*\
  !*** ./apps/wallet/src/pages/mnemonic/pages/manage/manage.component.ts ***!
  \*************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ManagePage: () => (/* binding */ ManagePage),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 52542);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! tslib */ 90505);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! @angular/core */ 61039);
/* harmony import */ var _bnqkl_framework_controllers__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @bnqkl/framework/controllers */ 47919);
/* harmony import */ var _bnqkl_framework_helpers__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @bnqkl/framework/helpers */ 12169);
/* harmony import */ var _bnqkl_framework_plugins_toast__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @bnqkl/framework/plugins/toast */ 18030);
/* harmony import */ var _bnqkl_util_web_extends_promise__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @bnqkl/util-web/extends-promise */ 87778);
/* harmony import */ var _modules_page_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ~modules/page.module */ 77538);
/* harmony import */ var _bnqkl_wallet_base_services_wallet_bip39__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @bnqkl/wallet-base/services/wallet/bip39 */ 76659);
/* harmony import */ var _bnqkl_wallet_base_services_wallet_chain__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @bnqkl/wallet-base/services/wallet/chain */ 27434);
/* harmony import */ var _services_permission_permission_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ~services/permission/permission.service */ 26502);
/* harmony import */ var _bnqkl_wallet_base_services_wallet_wallet_data_storage__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @bnqkl/wallet-base/services/wallet/wallet-data-storage */ 63024);
/* harmony import */ var _bnqkl_wallet_base_services_wallet_wallet__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @bnqkl/wallet-base/services/wallet/wallet */ 21789);
/* harmony import */ var _change_password_change_password_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../change-password/change-password.component */ 67948);
/* harmony import */ var _manage_identity_wallet_manage_identity_wallet_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../manage-identity-wallet/manage-identity-wallet.component */ 79033);
/* harmony import */ var _reset_password_reset_password_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../reset-password/reset-password.component */ 85652);
/* harmony import */ var _libs_bnf_components_ripple_button_ripple_button_directive__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../../../../../../../libs/bnf/components/ripple-button/ripple-button.directive */ 16505);
/* harmony import */ var _libs_bnf_directives_click_to_copy_directive__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ../../../../../../../libs/bnf/directives/click-to-copy.directive */ 46413);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! @angular/common */ 6729);
/* harmony import */ var _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ../../../../../../../libs/bnf/modules/page/common-page/common-page.component */ 62052);
/* harmony import */ var _components_icon_icon_component__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ../../../../components/icon/icon.component */ 74703);
/* harmony import */ var _pipes_color_color_pipe__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ../../../../pipes/color/color.pipe */ 76489);
/* harmony import */ var _pipes_chainIcon_chain_icon_pipe__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ../../../../pipes/chainIcon/chain-icon.pipe */ 43040);

var _class;























function ManagePage_ng_container_1_ng_container_21_button_1_span_6_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](0, "span", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵnextContext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtextInterpolate"](ctx_r6.walletName);
  }
}
function ManagePage_ng_container_1_ng_container_21_button_1_span_7_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](0, "span", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵi18n"](1, 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
  }
}
function ManagePage_ng_container_1_ng_container_21_button_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r10 = _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](0, "button", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵlistener"]("click", function ManagePage_ng_container_1_ng_container_21_button_1_Template_button_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵrestoreView"](_r10);
      const item_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵnextContext"]().$implicit;
      const ctx_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵresetView"](ctx_r8.mimeClick(item_r4.id));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](1, "div", 21)(2, "div", 7)(3, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](5, "div", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtemplate"](6, ManagePage_ng_container_1_ng_container_21_button_1_span_6_Template, 2, 1, "span", 22)(7, ManagePage_ng_container_1_ng_container_21_button_1_span_7_Template, 2, 0, "span", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelement"](8, "w-icon", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const item_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵnextContext"]().$implicit;
    const ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtextInterpolate"](item_r4.title);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵproperty"]("ngIf", item_r4.id === "walletName");
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵproperty"]("ngIf", item_r4.id === "setTransactionPassword" && !!ctx_r5.bioforestPasswordPublicKey);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵproperty"]("name", "right");
  }
}
function ManagePage_ng_container_1_ng_container_21_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtemplate"](1, ManagePage_ng_container_1_ng_container_21_button_1_Template, 9, 4, "button", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const item_r4 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵproperty"]("ngIf", !item_r4.hide);
  }
}
const _c8 = a0 => ({
  "--color-1": a0
});
const _c9 = () => ({
  prefix: "wallet",
  suffix: "s"
});
function ManagePage_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r13 = _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](1, "button", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵlistener"]("click", function ManagePage_ng_container_1_Template_button_click_1_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵrestoreView"](_r13);
      const ctx_r12 = _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵresetView"](ctx_r12.mimeClick("editName"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](2, "div", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelement"](3, "w-icon", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵpipe"](4, "color");
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](5, "span", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtext"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](7, "div", 7)(8, "span", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵi18n"](9, 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelement"](10, "w-icon", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](11, "div", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelement"](12, "w-icon", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵpipe"](13, "chainIcon");
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](14, "div")(15, "div", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵi18n"](16, 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](17, "div", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtext"](18);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](19, "button", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelement"](20, "w-icon", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]()()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtemplate"](21, ManagePage_ng_container_1_ng_container_21_Template, 2, 1, "ng-container", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵpureFunction1"](13, _c8, _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵpipeBind1"](4, 8, "subtext")));
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtextInterpolate"](ctx_r0.userNickName);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵproperty"]("name", "right");
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵproperty"]("name", _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵpipeBind2"](13, 10, ctx_r0.symbol, _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵpureFunction0"](15, _c9)));
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtextInterpolate1"](" ", ctx_r0.walletAddress, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵproperty"]("wClickToCopy", ctx_r0.walletAddress);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵproperty"]("ngForOf", ctx_r0.identityList);
  }
}
function ManagePage_ng_container_2_ng_container_18_button_1_span_6_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](0, "span", 32);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r17 = _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵnextContext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtextInterpolate"](ctx_r17.walletName);
  }
}
function ManagePage_ng_container_2_ng_container_18_button_1_span_7_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](0, "span", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵi18n"](1, 33);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
  }
}
function ManagePage_ng_container_2_ng_container_18_button_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r21 = _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](0, "button", 29);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵlistener"]("click", function ManagePage_ng_container_2_ng_container_18_button_1_Template_button_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵrestoreView"](_r21);
      const item_r15 = _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵnextContext"]().$implicit;
      const ctx_r19 = _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵresetView"](ctx_r19.mimeClick(item_r15.id));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](1, "div", 21)(2, "div", 7)(3, "span", 30);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](5, "div", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtemplate"](6, ManagePage_ng_container_2_ng_container_18_button_1_span_6_Template, 2, 1, "span", 31)(7, ManagePage_ng_container_2_ng_container_18_button_1_span_7_Template, 2, 0, "span", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelement"](8, "w-icon", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const item_r15 = _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵnextContext"]().$implicit;
    const ctx_r16 = _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtextInterpolate"](item_r15.title);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵproperty"]("ngIf", item_r15.id === "walletName");
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵproperty"]("ngIf", item_r15.id === "setTransactionPassword" && !!ctx_r16.bioforestPasswordPublicKey);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵproperty"]("name", "right");
  }
}
function ManagePage_ng_container_2_ng_container_18_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtemplate"](1, ManagePage_ng_container_2_ng_container_18_button_1_Template, 9, 4, "button", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const item_r15 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵproperty"]("ngIf", !item_r15.hide);
  }
}
function ManagePage_ng_container_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r24 = _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](1, "div", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelement"](2, "w-icon", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵpipe"](3, "chainIcon");
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](4, "div")(5, "div", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵi18n"](6, 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](7, "div", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtext"](8);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](9, "button", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelement"](10, "w-icon", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]()()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](11, "button", 26);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵlistener"]("click", function ManagePage_ng_container_2_Template_button_click_11_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵrestoreView"](_r24);
      const ctx_r23 = _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵresetView"](ctx_r23.goTomanageWallet());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](12, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵi18n"](13, 27);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](14, "div", 7)(15, "span", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtext"](16);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelement"](17, "w-icon", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtemplate"](18, ManagePage_ng_container_2_ng_container_18_Template, 2, 1, "ng-container", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵproperty"]("name", _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵpipeBind2"](3, 6, ctx_r1.symbol, _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵpureFunction0"](9, _c9)));
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtextInterpolate1"](" ", ctx_r1.walletAddress, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵproperty"]("wClickToCopy", ctx_r1.walletAddress);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](7);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtextInterpolate"](ctx_r1.walletName);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵproperty"]("name", "right");
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵproperty"]("ngForOf", ctx_r1.noIdentityList);
  }
}
function ManagePage_div_3_Template(rf, ctx) {
  if (rf & 1) {
    const _r26 = _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](0, "div", 34)(1, "button", 35);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵlistener"]("click", function ManagePage_div_3_Template_button_click_1_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵrestoreView"](_r26);
      const ctx_r25 = _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵresetView"](ctx_r25.deleteWallet());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](2, "span", 36);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵi18n"](3, 37);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]()()();
  }
}
/**
 * 助记词管理页面
 */
class ManagePage extends _modules_page_module__WEBPACK_IMPORTED_MODULE_5__.CommonPageBase {
  constructor() {
    super(...arguments);
    /** 引入钱包存储服务 */
    this.walletDataStorage = (0,_angular_core__WEBPACK_IMPORTED_MODULE_20__.inject)(_bnqkl_wallet_base_services_wallet_wallet_data_storage__WEBPACK_IMPORTED_MODULE_9__.WalletDataStorageService);
    /** 权限服务 */
    this._permissionService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_20__.inject)(_services_permission_permission_service__WEBPACK_IMPORTED_MODULE_8__.PermissionService);
    /**
     * 区分身份钱包/非身份钱包
     */
    this.pageType = 'identityWallet';
    /**
     * 是否展示删除按钮
     */
    this.btnFlag = false;
    /**
     * 传递过来的token类型
     */
    this.walletName = '';
    /**
     * 传递过来的用户昵称
     */
    this.userNickName = '';
    /**
     * 传递过来的钱包地址
     */
    this.walletAddress = '';
    /** 地址是否冻结 */
    this.isFreezed = false;
    /** 钱包链服务 */
    this.chainService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_20__.inject)(_bnqkl_wallet_base_services_wallet_chain__WEBPACK_IMPORTED_MODULE_7__.ChainService);
    /** 身份钱包的功能列表 */
    this.identityList = [{
      id: 'walletName',
      title: "\u9322\u5305\u540D\u7A31",
      hide: false
    }, {
      id: 'exportPrivateKey',
      title: "\u5C0E\u51FA\u79C1\u9470",
      hide: false
    }, {
      id: 'setTransactionPassword',
      title: "\u8A2D\u7F6E\u4EA4\u6613\u5BC6\u78BC",
      hide: true,
      bioforestChain: true
    }];
    /** 非身份钱包的功能列表 */
    this.noIdentityList = [{
      id: 'exportMnemonic',
      title: "\u5C0E\u51FA\u52A9\u8A18\u8A5E"
    }, {
      id: 'exportPrivateKey',
      title: "\u5C0E\u51FA\u79C1\u9470",
      hide: false
    }, {
      id: 'setTransactionPassword',
      title: "\u8A2D\u7F6E\u4EA4\u6613\u5BC6\u78BC",
      hide: true,
      bioforestChain: true
    }, {
      id: 'passwordHint',
      title: "\u5BC6\u78BC\u63D0\u793A",
      hide: false
    }, {
      id: 'changePassword',
      title: "\u4FEE\u6539\u5BC6\u78BC"
    }, {
      id: 'resetPassword',
      title: "\u91CD\u7F6E\u5BC6\u78BC"
    }];
    // /** 接收身份钱包管理页返回的数据 */
    this.manageIdentityWalletPageReturnController = new _bnqkl_framework_controllers__WEBPACK_IMPORTED_MODULE_1__.PageReturnController(this, _manage_identity_wallet_manage_identity_wallet_component__WEBPACK_IMPORTED_MODULE_12__.ManageIdentityWalletPage);
    // /** 密码修改成功之后触发 */
    this.changePasswordPageReturnController = new _bnqkl_framework_controllers__WEBPACK_IMPORTED_MODULE_1__.PageReturnController(this, _change_password_change_password_component__WEBPACK_IMPORTED_MODULE_11__.ChangePasswordPage);
    // /** 重置密码成功之后触发 */
    this.resetPasswordPageReturnController = new _bnqkl_framework_controllers__WEBPACK_IMPORTED_MODULE_1__.PageReturnController(this, _reset_password_reset_password_component__WEBPACK_IMPORTED_MODULE_13__.ResetPasswordPage);
    /** 代币 */
    this.symbol = '';
    /** 钱包创建的方式  */
    this.importType = '';
    /** 私钥 */
    this.privateKey = '';
    /** 地址信息 */
    this.addressKey = '';
    /** 页面返回值的类型 */
    this.returnValue$ = new _modules_page_module__WEBPACK_IMPORTED_MODULE_5__.PageReturnValue();
  }
  /**  是否是生物链林-链 */
  get isBioforestChain() {
    return this.chainService.isBioforestChainByChainName(this.chain);
  }
  /** 我的页面点击事件 */
  mimeClick(event) {
    var _this = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      if (event === 'walletName') {
        _this.goTomanageWallet();
      } else if (event === 'editName') {
        _this.nav.routeTo('/mnemonic/manage-identity-wallet', {
          chain: _this.chain,
          address: _this.walletAddress,
          walleterType: _this.pageType
        });
      } else if (event === 'exportMnemonic') {
        const pwdInfo = yield _this._permissionService.requestPassword();
        if (pwdInfo === null || pwdInfo === false) {
          return;
        }
        const {
          notMainWalletKey,
          address
        } = pwdInfo;
        if ((0,_bnqkl_framework_helpers__WEBPACK_IMPORTED_MODULE_2__.$isNoEmptyString)(notMainWalletKey)) {
          const wallet = yield _this.walletDataStorage.getNotMainWallet(notMainWalletKey, address);
          if (wallet === undefined) {
            throw new Error(`not find wallet:${address}-${notMainWalletKey}`);
          }
          let hasGoMnemonicBackup = _this.chainService.isBioforestChainByChainName(_this.chain) === false;
          if (hasGoMnemonicBackup === false) {
            /// 我们自己的链跳转到地址备份页面，但是助剂词不一定是地址密码，需要判断一下
            try {
              const bip39LibService = _this.injectorForceGet(_bnqkl_wallet_base_services_wallet_bip39__WEBPACK_IMPORTED_MODULE_6__.Bip39LibService);
              yield bip39LibService.checkMnemonic(wallet.importPhrase);
              hasGoMnemonicBackup = true;
            } catch (err) {
              hasGoMnemonicBackup = false;
            }
          }
          if (hasGoMnemonicBackup) {
            _this.nav.routeTo('/mnemonic/mnemonic-backup-tips', {
              export: true,
              backUrl: '/mnemonic/manage',
              mnemonicString: wallet.importPhrase,
              walleterType: _this.pageType
            });
          } else {
            _this.nav.routeTo('/mnemonic/address-password-tips', {
              chain: _this.chain,
              export: true,
              backUrl: '/mnemonic/manage',
              mnemonicString: wallet.importPhrase,
              walleterType: _this.pageType
            });
          }
        }
      } else if (event === 'exportPrivateKey') {
        // 需要先验证密码
        const pwdInfo = yield _this._permissionService.requestPassword();
        if (pwdInfo === null || pwdInfo === false) {
          return;
        }
        _this.nav.routeTo('/mnemonic/export-private-key-tips', {
          importPhrase: _this.privateKey
        });
      } else if (event === 'passwordHint') {
        const {
          passwordTips
        } = yield _this._getCurrentWalletPasswordInfo();
        yield _this.alert({
          headerTitle: "\u5BC6\u78BC\u63D0\u793A",
          bodyMessage: passwordTips !== null && passwordTips !== void 0 ? passwordTips : '',
          buttonText: "\u78BA\u5B9A"
        }, {
          panelClass: '_password-hint'
        });
      } else if (event === 'changePassword') {
        _this.nav.routeTo('/mnemonic/change-password', {
          chain: _this.chain,
          address: _this.walletAddress,
          notMainWalletKey: _this._notMainWalletKey
        });
      } else if (event === 'resetPassword') {
        _this.nav.routeTo('/mnemonic/reset-password', {
          chain: _this.chain,
          importType: _this.importType,
          address: _this.walletAddress,
          notMainWalletKey: _this._notMainWalletKey
        });
      } else if (event === 'setTransactionPassword') {
        if (_this.isFreezed) {
          _bnqkl_framework_plugins_toast__WEBPACK_IMPORTED_MODULE_3__.Toast.show("\u8A72\u5730\u5740\u5DF2\u51CD\u7D50\uFF0C\u7121\u6CD5\u8A2D\u7F6E\u93C8\u4E0A\u4EA4\u6613\u5BC6\u78BC");
          return;
        }
        _this.nav.routeTo('/mnemonic/set-transaction-password', {
          chain: _this.chain,
          address: _this.walletAddress,
          bioforestPasswordPublicKey: _this.bioforestPasswordPublicKey,
          addressKey: _this.addressKey
        });
      }
    })();
  }
  /** 初始化获取传参 */
  initWalletInfo() {
    var _this2 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const walletInfo = _this2._data;
      _this2.pageType = walletInfo.pageType;
      _this2.userNickName = walletInfo.name;
      _this2.walletAddress = walletInfo.walletAddress;
      _this2.walletName = walletInfo.walletName;
      _this2._notMainWalletKey = walletInfo.notMainWalletKey;
      _this2.chain = walletInfo.chain;
      _this2.symbol = _this2.chainService.getChainInfo(_this2.chain).symbol;
      _this2.importType = walletInfo.importType;
      _this2.privateKey = walletInfo.privateKey;
      _this2.addressKey = walletInfo.addressKey;
      _this2.filterMnemonicItem(walletInfo.importType);
      const {
        passwordTips
      } = yield _this2._getCurrentWalletPasswordInfo();
      if (_this2.chainService.isBioforestChainByChainName(walletInfo.chain)) {
        const k_main = _this2.identityList.find(item => item.id === 'exportPrivateKey');
        if (k_main) {
          k_main.hide = true;
        }
        const k_no = _this2.noIdentityList.find(item => item.id === 'exportPrivateKey');
        if (k_no) {
          k_no.hide = true;
        }
        const t = _this2.noIdentityList.find(item => item.id === 'exportMnemonic');
        if (t) {
          t.title = "\u5C0E\u51FA\u52A9\u8A18\u8A5E/\u5730\u5740\u5BC6\u78BC";
          _this2.cdRef.detectChanges();
        }
      }
      if ((0,_bnqkl_framework_helpers__WEBPACK_IMPORTED_MODULE_2__.$isNoEmptyString)(passwordTips) === false) {
        /// 隐藏提示
        const t = _this2.noIdentityList.find(item => item.id === 'passwordHint');
        if (t) {
          t.hide = true;
          _this2.cdRef.detectChanges();
        }
      }
      /// 筛选显示项
      _this2.identityList.forEach(item => {
        if (item.bioforestChain) {
          item.hide = !_this2.chainService.isBioforestChainByChainName(_this2.chain);
        }
      });
      _this2.noIdentityList.forEach(item => {
        if (item.bioforestChain) {
          item.hide = !_this2.chainService.isBioforestChainByChainName(_this2.chain);
        }
      });
      _this2.cdRef.detectChanges();
      /** 监听非身份钱包的创建 */
      _this2.manageIdentityWalletPageReturnController.pageReturn$.subscribe(data => {
        if (data.result) {
          _this2.userNickName = data.result;
        }
      });
      /** 修改密码页 */
      _this2.changePasswordPageReturnController.pageReturn$.subscribe(data => {
        if (data.result === 'success') {
          if ((0,_bnqkl_framework_helpers__WEBPACK_IMPORTED_MODULE_2__.$isNoEmptyString)(data.tipContent) === false) {
            /// 隐藏提示
            _this2.isPasswordHint(true);
          } else {
            _this2.isPasswordHint(false);
          }
        }
      });
      /** 重置密码页 */
      _this2.resetPasswordPageReturnController.pageReturn$.subscribe(data => {
        if (data.result === 'success') {
          if ((0,_bnqkl_framework_helpers__WEBPACK_IMPORTED_MODULE_2__.$isNoEmptyString)(data.tipContent) === false) {
            /// 隐藏提示
            _this2.isPasswordHint(true);
          } else {
            _this2.isPasswordHint(false);
          }
        }
      });
      /// 获取生物链林地址详情
      if (_this2.isBioforestChain) {
        _this2.isFreezed = !!(yield _this2.chainService.getChainAddressInfoByAddressKey(_this2.addressKey)).isFreezed;
        const {
          secondPublicKey,
          isFreezed
        } = yield _this2.chainService.getChainService(_this2.chain).getAddressInfo(_this2.walletAddress);
        _this2.bioforestPasswordPublicKey = secondPublicKey;
        _this2.isFreezed = isFreezed;
      }
    })();
  }
  /** 刷新页面，显示或者隐藏密码提示 */
  isPasswordHint(result) {
    /// 隐藏提示
    const t = this.noIdentityList.find(item => item.id === 'passwordHint');
    if (t) {
      t.hide = result;
      this.cdRef.detectChanges();
    }
  }
  /** 过滤掉Mnemonic 私钥导入的钱包不能导出助记词 */
  filterMnemonicItem(importType) {
    if (importType === 'privateKey') {
      this.noIdentityList = this.noIdentityList.filter(item => item.id !== 'exportMnemonic');
    }
  }
  /** 获取当前钱包的密码信息 */
  _getCurrentWalletPasswordInfo() {
    var _this3 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const info = yield _this3.walletDataStorage.getChainWalletInfoByChainAndAddress(_this3.chain, _this3.walletAddress);
      return info;
    })();
  }
  /** 修改钱包名称的弹窗 */
  goTomanageWallet() {
    var _this4 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const result = yield _this4.prompt({
        headerTitle: "\u4FEE\u6539\u9322\u5305\u540D\u7A31",
        value: _this4.walletName
      });
      if (result === null || result === _this4.walletName) {
        return;
      }
      const newWalletName = result.trim();
      if ((0,_bnqkl_framework_helpers__WEBPACK_IMPORTED_MODULE_2__.$isNoEmptyString)(newWalletName) === false) {
        return;
      }
      try {
        var _currentWallet;
        if (newWalletName.length > 12 || newWalletName.length === 0) {
          throw new Error("\u9322\u5305\u540D\u7A31\u9577\u5EA61~12");
        }
        let currentWallet;
        if ((0,_bnqkl_framework_helpers__WEBPACK_IMPORTED_MODULE_2__.$isNoEmptyString)(_this4._notMainWalletKey)) {
          /// 修改非身份钱包的名称
          const wallet = yield _this4.walletDataStorage.getNotMainWallet(_this4._notMainWalletKey, _this4.walletAddress);
          if (wallet === undefined || wallet.name == newWalletName) {
            return;
          }
          wallet.name = newWalletName;
          _this4.walletName = newWalletName;
          currentWallet = wallet;
          yield _this4.walletDataStorage.updateNotMainWallet(_this4._notMainWalletKey, wallet);
        } else {
          if (_this4.chain !== undefined) {
            /// 修改身份钱包的名称
            const walleter = yield _this4.walletDataStorage.getChainWallet(_this4.chain);
            if (walleter === undefined || walleter.name == newWalletName) {
              return;
            }
            walleter.name = newWalletName;
            _this4.walletName = newWalletName;
            currentWallet = walleter;
            yield _this4.walletDataStorage.saveChainWallet(_this4.chain, walleter);
          }
        }
        const walletDataStorage = _this4.injectorForceGet(_bnqkl_wallet_base_services_wallet_wallet_data_storage__WEBPACK_IMPORTED_MODULE_9__.WalletDataStorageService);
        const mainWalleter = yield walletDataStorage.getWalleterInfo();
        if (mainWalleter && mainWalleter.lastWalletActivate.addressKey === ((_currentWallet = currentWallet) === null || _currentWallet === void 0 ? void 0 : _currentWallet.addressKey)) {
          /// 修改到当前激活的钱包 需要更新
          mainWalleter.lastWalletActivate = currentWallet;
          yield walletDataStorage.saveWalleterInfo(mainWalleter);
        }
        _this4.returnValue$.next({
          changeName: true
        });
        _bnqkl_framework_plugins_toast__WEBPACK_IMPORTED_MODULE_3__.Toast.show("\u6210\u529F");
        return;
      } catch (err) {
        _this4.console.error(err);
        _bnqkl_framework_plugins_toast__WEBPACK_IMPORTED_MODULE_3__.Toast.show(err instanceof Error ? err.message : "\u5931\u6557");
      }
    })();
  }
  /** 删除钱包 */
  deleteWallet() {
    var _this5 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      /// 删除提示
      const confirmed = yield _this5.confirm({
        headerTitle: "\u63D0\u793A",
        bodyMessage: "\u78BA\u8A8D\u522A\u9664\uFF1F",
        footerTheme: 'warn'
      });
      if (confirmed === false) {
        return;
      }
      /// 校验密码
      const pwdInfo = yield _this5._permissionService.requestPassword();
      if (pwdInfo === false || pwdInfo === null) {
        return;
      }
      try {
        if ((0,_bnqkl_framework_helpers__WEBPACK_IMPORTED_MODULE_2__.$isNoEmptyString)(_this5._notMainWalletKey)) {
          const deleteItem = yield _this5.walletDataStorage.deleteNotMainWallet(_this5._notMainWalletKey, _this5.walletAddress);
          /// 判断是否删除使用中的非身份钱包，需要更新
          const mainWalleter = yield _this5.walletDataStorage.getWalleterInfo();
          if (mainWalleter !== undefined && deleteItem) {
            if (mainWalleter.lastWalletActivate.address === _this5.walletAddress) {
              /// 是同一个钱包，需要更新数据
              /// 获取对应链的身份钱包
              const chainWallet = yield _this5.walletDataStorage.getChainWallet(deleteItem.chain);
              if (chainWallet !== undefined) {
                mainWalleter.lastWalletActivate = chainWallet;
                yield _this5.walletDataStorage.saveWalleterInfo(mainWalleter);
                const walletService = _this5.injectorForceGet(_bnqkl_wallet_base_services_wallet_wallet__WEBPACK_IMPORTED_MODULE_10__.WalletService);
                yield walletService.upDateMainWalleter();
              }
            }
          }
          _this5.returnValue$.next({
            result: true
          });
          yield (0,_bnqkl_util_web_extends_promise__WEBPACK_IMPORTED_MODULE_4__.sleep)(500);
          _this5.nav.back();
          _bnqkl_framework_plugins_toast__WEBPACK_IMPORTED_MODULE_3__.Toast.show("\u6210\u529F");
        }
      } catch (err) {
        _this5.console.error(err);
        _bnqkl_framework_plugins_toast__WEBPACK_IMPORTED_MODULE_3__.Toast.show("\u5931\u6557");
      }
    })();
  }
}
_class = ManagePage;
_class.ɵfac = /*@__PURE__*/(() => {
  let ɵManagePage_BaseFactory;
  return function ManagePage_Factory(t) {
    return (ɵManagePage_BaseFactory || (ɵManagePage_BaseFactory = _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵgetInheritedFactory"](_class)))(t || _class);
  };
})();
_class.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵdefineComponent"]({
  type: _class,
  selectors: [["w-manage-page"]],
  outputs: {
    returnValue$: "returnValue$"
  },
  standalone: true,
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵInheritDefinitionFeature"], _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵStandaloneFeature"]],
  decls: 4,
  vars: 6,
  consts: () => {
    let i18n_0;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_USER_AVATOR_AND_NIKENAME$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_MANAGE_MANAGE_COMPONENT_TS__1 = goog.getMsg("User avatar and nickname");
      i18n_0 = MSG_EXTERNAL_USER_AVATOR_AND_NIKENAME$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_MANAGE_MANAGE_COMPONENT_TS__1;
    } else {
      i18n_0 = "\u7528\u6236\u982D\u50CF\u548C\u6635\u7A31";
    }
    let i18n_2;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_MANAGE_IDENTITY_WALLETS$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_MANAGE_MANAGE_COMPONENT_TS__3 = goog.getMsg("Manage Identity Wallets");
      i18n_2 = MSG_EXTERNAL_MANAGE_IDENTITY_WALLETS$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_MANAGE_MANAGE_COMPONENT_TS__3;
    } else {
      i18n_2 = "\u7BA1\u7406\u8EAB\u4EFD\u9322\u5305";
    }
    let i18n_4;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_WALLET_ADDRESS$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_MANAGE_MANAGE_COMPONENT_TS__5 = goog.getMsg("Wallet Address");
      i18n_4 = MSG_EXTERNAL_WALLET_ADDRESS$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_MANAGE_MANAGE_COMPONENT_TS__5;
    } else {
      i18n_4 = "\u9322\u5305\u5730\u5740";
    }
    let i18n_6;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_ALREADY_SET$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_MANAGE_MANAGE_COMPONENT_TS_____7 = goog.getMsg(" Already set ");
      i18n_6 = MSG_EXTERNAL_ALREADY_SET$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_MANAGE_MANAGE_COMPONENT_TS_____7;
    } else {
      i18n_6 = "\u5DF2\u8A2D\u7F6E";
    }
    let i18n_10;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_WALLET_ADDRESS$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_MANAGE_MANAGE_COMPONENT_TS__11 = goog.getMsg("Wallet Address");
      i18n_10 = MSG_EXTERNAL_WALLET_ADDRESS$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_MANAGE_MANAGE_COMPONENT_TS__11;
    } else {
      i18n_10 = "\u9322\u5305\u5730\u5740";
    }
    let i18n_12;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_WALLET_NAME$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_MANAGE_MANAGE_COMPONENT_TS__13 = goog.getMsg("Wallet Name");
      i18n_12 = MSG_EXTERNAL_WALLET_NAME$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_MANAGE_MANAGE_COMPONENT_TS__13;
    } else {
      i18n_12 = "\u9322\u5305\u540D\u7A31";
    }
    let i18n_14;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_ALREADY_SET$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_MANAGE_MANAGE_COMPONENT_TS_____15 = goog.getMsg(" Already set ");
      i18n_14 = MSG_EXTERNAL_ALREADY_SET$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_MANAGE_MANAGE_COMPONENT_TS_____15;
    } else {
      i18n_14 = "\u5DF2\u8A2D\u7F6E";
    }
    let i18n_16;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_DELETE_WALLET$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_MANAGE_MANAGE_COMPONENT_TS__17 = goog.getMsg("Delete Wallet");
      i18n_16 = MSG_EXTERNAL_DELETE_WALLET$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_MANAGE_MANAGE_COMPONENT_TS__17;
    } else {
      i18n_16 = "\u522A\u9664\u9322\u5305";
    }
    return [[3, "contentBackground", "headerBackground", "contentSafeArea"], [4, "ngIf"], ["footer", "", 4, "ngIf"], ["bnRippleButton", "", 1, "px-page-safe-area-inset", "mb-1.5", "flex", "h-20", "w-full", "items-center", "justify-between", "bg-white", 3, "click"], ["aria-label", i18n_0, 1, "flex", "items-center"], ["name", "head", 1, "text-5xl"], [1, "ml-1.5", "font-semibold", "tracking-normal"], [1, "flex", "items-center"], [1, "text-subtext", "text-xs"], i18n_2, [1, "icon-4", "text-subtext", 3, "name"], [1, "px-page-safe-area-inset", "flex", "h-14", "w-full", "items-center", "bg-white"], [1, "mr-1.5", "text-3xl", 3, "name"], [1, "text-xs", "font-semibold"], i18n_4, [1, "text-subtext", "text-xss", "flex", "items-center", "justify-between"], ["bnRippleButton", "", 1, "ml-2", 3, "wClickToCopy"], ["name", "copy", 1, "icon-4"], [4, "ngFor", "ngForOf"], ["class", "px-page-safe-area-inset mb-1.5 h-14 w-full bg-white", "bnRippleButton", "", 3, "click", 4, "ngIf"], ["bnRippleButton", "", 1, "px-page-safe-area-inset", "mb-1.5", "h-14", "w-full", "bg-white", 3, "click"], [1, "flex", "h-14", "items-center", "justify-between"], ["class", "text-subtext text-xs", 4, "ngIf"], i18n_6, [1, "text-sm", "font-semibold"], i18n_10, ["bnRippleButton", "", 1, "px-page-safe-area-inset", "mb-1.5", "flex", "h-14", "w-full", "items-center", "justify-between", "bg-white", 3, "click"], i18n_12, ["bnRippleButton", "", "class", "px-page-safe-area-inset h-14 w-full bg-white", 3, "click", 4, "ngIf"], ["bnRippleButton", "", 1, "px-page-safe-area-inset", "h-14", "w-full", "bg-white", 3, "click"], [1, "text-title"], ["class", "icon-4 mr-2", 4, "ngIf"], [1, "icon-4", "mr-2"], i18n_14, ["footer", ""], ["bnRippleButton", "", 1, "h-10.5", "w-full", "rounded-full", "bg-white", "text-center", 3, "click"], [1, "text-error"], i18n_16];
  },
  template: function ManagePage_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](0, "common-page", 0);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtemplate"](1, ManagePage_ng_container_1_Template, 22, 16, "ng-container", 1)(2, ManagePage_ng_container_2_Template, 19, 10, "ng-container", 1)(3, ManagePage_div_3_Template, 4, 0, "div", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵproperty"]("contentBackground", "env")("headerBackground", "white")("contentSafeArea", false);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵproperty"]("ngIf", ctx.pageType === "identityWallet");
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵproperty"]("ngIf", ctx.pageType === "noIdentityWallet");
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵproperty"]("ngIf", ctx.pageType === "noIdentityWallet");
    }
  },
  dependencies: [_modules_page_module__WEBPACK_IMPORTED_MODULE_5__.CommonPageModule, _libs_bnf_components_ripple_button_ripple_button_directive__WEBPACK_IMPORTED_MODULE_14__.RippleButtonDirective, _libs_bnf_directives_click_to_copy_directive__WEBPACK_IMPORTED_MODULE_15__.ClickToCopyDirective, _angular_common__WEBPACK_IMPORTED_MODULE_21__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_21__.NgIf, _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_16__.CommonPageComponent, _components_icon_icon_component__WEBPACK_IMPORTED_MODULE_17__.IconComponent, _pipes_color_color_pipe__WEBPACK_IMPORTED_MODULE_18__.ColorPipe, _pipes_chainIcon_chain_icon_pipe__WEBPACK_IMPORTED_MODULE_19__.ChainIconPipe],
  styles: ["._password-hint common-card-text-body > p {\n    border-radius: 0.5rem;\n    --tw-bg-opacity: 1;\n    background-color: rgb(243 242 255 / var(--tw-bg-opacity));\n    padding: 0.5rem\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL2FwcHMvd2FsbGV0L3NyYy9wYWdlcy9tbmVtb25pYy9wYWdlcy9tYW5hZ2UvbWFuYWdlLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUVJO0lBQUEscUJBQUE7SUFBQSxrQkFBQTtJQUFBLHlEQUFBO0lBQUE7QUFBQSIsInNvdXJjZXNDb250ZW50IjpbIjo6bmctZGVlcCAuX3Bhc3N3b3JkLWhpbnQge1xyXG4gIGNvbW1vbi1jYXJkLXRleHQtYm9keSA+IHAge1xyXG4gICAgQGFwcGx5IGJnLWVudiByb3VuZGVkLTIgcC0yO1xyXG4gIH1cclxufVxyXG4iXSwic291cmNlUm9vdCI6IiJ9 */"],
  changeDetection: 0
});
(0,tslib__WEBPACK_IMPORTED_MODULE_22__.__decorate)([ManagePage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_22__.__metadata)("design:type", Object)], ManagePage.prototype, "pageType", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_22__.__decorate)([ManagePage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_22__.__metadata)("design:type", Object)], ManagePage.prototype, "btnFlag", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_22__.__decorate)([ManagePage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_22__.__metadata)("design:type", Object)], ManagePage.prototype, "walletName", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_22__.__decorate)([ManagePage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_22__.__metadata)("design:type", Object)], ManagePage.prototype, "userNickName", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_22__.__decorate)([ManagePage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_22__.__metadata)("design:type", Object)], ManagePage.prototype, "walletAddress", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_22__.__decorate)([ManagePage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_22__.__metadata)("design:type", String)], ManagePage.prototype, "bioforestPasswordPublicKey", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_22__.__decorate)([ManagePage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_22__.__metadata)("design:type", Array)], ManagePage.prototype, "noIdentityList", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_22__.__decorate)([ManagePage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_22__.__metadata)("design:type", Object)], ManagePage.prototype, "manageIdentityWalletPageReturnController", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_22__.__decorate)([ManagePage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_22__.__metadata)("design:type", Object)], ManagePage.prototype, "changePasswordPageReturnController", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_22__.__decorate)([ManagePage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_22__.__metadata)("design:type", Object)], ManagePage.prototype, "resetPasswordPageReturnController", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_22__.__decorate)([ManagePage.QueryParams(), (0,tslib__WEBPACK_IMPORTED_MODULE_22__.__metadata)("design:type", Object)], ManagePage.prototype, "_data", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_22__.__decorate)([ManagePage.OnInit(), (0,tslib__WEBPACK_IMPORTED_MODULE_22__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_22__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_22__.__metadata)("design:returntype", Promise)], ManagePage.prototype, "initWalletInfo", null);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ManagePage);

/***/ })

}]);
//# sourceMappingURL=default-apps_wallet_src_pages_mnemonic_pages_manage_manage_component_ts.js.map