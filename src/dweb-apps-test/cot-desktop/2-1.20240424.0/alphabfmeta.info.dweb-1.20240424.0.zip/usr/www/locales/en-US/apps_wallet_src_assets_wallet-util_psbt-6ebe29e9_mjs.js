"use strict";
(self["webpackChunkwallet"] = self["webpackChunkwallet"] || []).push([["apps_wallet_src_assets_wallet-util_psbt-6ebe29e9_mjs"],{

/***/ 26003:
/*!**************************************************************!*\
  !*** ./apps/wallet/src/assets/wallet-util/psbt-6ebe29e9.mjs ***!
  \**************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Psbt: () => (/* binding */ En)
/* harmony export */ });
/* harmony import */ var _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./index-766bdb76.mjs */ 59809);
/* harmony import */ var _address_a3a74797_mjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./address-a3a74797.mjs */ 75036);
/* harmony import */ var _script_28a5953a_mjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./script-28a5953a.mjs */ 25453);
/* harmony import */ var _crypto_2c4d5428_mjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./crypto-2c4d5428.mjs */ 8319);
/* harmony import */ var _networks_0de0aba6_mjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./networks-0de0aba6.mjs */ 15108);
/* harmony import */ var _ops_47b8fd99_mjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./ops-47b8fd99.mjs */ 62510);
/* harmony import */ var _p2pk_9b07c6f0_mjs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./p2pk-9b07c6f0.mjs */ 73721);
/* harmony import */ var _index_f363275a_mjs__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./index-f363275a.mjs */ 89279);
/* harmony import */ var _sha256_e58017d9_mjs__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./sha256-e58017d9.mjs */ 6612);
/* harmony import */ var _WASMInterface_b9f2203b_mjs__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./WASMInterface-b9f2203b.mjs */ 43670);
/* harmony import */ var _typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./typeforce-9b266dd0.mjs */ 26139);
/* harmony import */ var _ripemd160_3baa091d_mjs__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./ripemd160-3baa091d.mjs */ 70972);
/* harmony import */ var _sha1_e1635d39_mjs__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./sha1-e1635d39.mjs */ 57);













const {
  typeforce: C
} = _script_28a5953a_mjs__WEBPACK_IMPORTED_MODULE_2__.a;
function x(e, t) {
  if ("number" != typeof e) throw new Error("cannot write a non-number as a number");
  if (e < 0) throw new Error("specified a negative value for writing an unsigned value");
  if (e > t) throw new Error("RangeError: value out of range");
  if (Math.floor(e) !== e) throw new Error("value has a fractional component");
}
function U(e) {
  if (e.length < 1) return e;
  let t = e.length - 1,
    n = 0;
  for (let r = 0; r < e.length / 2; r++) n = e[r], e[r] = e[t], e[t] = n, t--;
  return e;
}
function H(t) {
  const n = _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_0__.B.allocUnsafe(t.length);
  return t.copy(n), n;
}
class B {
  static withCapacity(t) {
    return new B(_index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_0__.B.alloc(t));
  }
  constructor(e, t = 0) {
    this.buffer = e, this.offset = t, C((0,_script_28a5953a_mjs__WEBPACK_IMPORTED_MODULE_2__.t)(_script_28a5953a_mjs__WEBPACK_IMPORTED_MODULE_2__.B, _script_28a5953a_mjs__WEBPACK_IMPORTED_MODULE_2__.U), [e, t]);
  }
  writeUInt8(e) {
    this.offset = this.buffer.writeUInt8(e, this.offset);
  }
  writeInt32(e) {
    this.offset = this.buffer.writeInt32LE(e, this.offset);
  }
  writeUInt32(e) {
    this.offset = this.buffer.writeUInt32LE(e, this.offset);
  }
  writeUInt64(e) {
    this.offset = function (e, t, n) {
      return x(t, 9007199254740991), e.writeInt32LE(-1 & t, n), e.writeUInt32LE(Math.floor(t / 4294967296), n + 4), n + 8;
    }(this.buffer, e, this.offset);
  }
  writeVarInt(e) {
    _address_a3a74797_mjs__WEBPACK_IMPORTED_MODULE_1__.v.encode(e, this.buffer, this.offset), this.offset += _address_a3a74797_mjs__WEBPACK_IMPORTED_MODULE_1__.v.encode.bytes;
  }
  writeSlice(e) {
    if (this.buffer.length < this.offset + e.length) throw new Error("Cannot write slice out of bounds");
    this.offset += e.copy(this.buffer, this.offset);
  }
  writeVarSlice(e) {
    this.writeVarInt(e.length), this.writeSlice(e);
  }
  writeVector(e) {
    this.writeVarInt(e.length), e.forEach(e => this.writeVarSlice(e));
  }
  end() {
    if (this.buffer.length === this.offset) return this.buffer;
    throw new Error(`buffer size ${this.buffer.length}, offset ${this.offset}`);
  }
}
class R {
  constructor(e, t = 0) {
    this.buffer = e, this.offset = t, C((0,_script_28a5953a_mjs__WEBPACK_IMPORTED_MODULE_2__.t)(_script_28a5953a_mjs__WEBPACK_IMPORTED_MODULE_2__.B, _script_28a5953a_mjs__WEBPACK_IMPORTED_MODULE_2__.U), [e, t]);
  }
  readUInt8() {
    const e = this.buffer.readUInt8(this.offset);
    return this.offset++, e;
  }
  readInt32() {
    const e = this.buffer.readInt32LE(this.offset);
    return this.offset += 4, e;
  }
  readUInt32() {
    const e = this.buffer.readUInt32LE(this.offset);
    return this.offset += 4, e;
  }
  readUInt64() {
    const e = function (e, t) {
      const n = e.readUInt32LE(t);
      let r = e.readUInt32LE(t + 4);
      return r *= 4294967296, x(r + n, 9007199254740991), r + n;
    }(this.buffer, this.offset);
    return this.offset += 8, e;
  }
  readVarInt() {
    const e = _address_a3a74797_mjs__WEBPACK_IMPORTED_MODULE_1__.v.decode(this.buffer, this.offset);
    return this.offset += _address_a3a74797_mjs__WEBPACK_IMPORTED_MODULE_1__.v.decode.bytes, e;
  }
  readSlice(e) {
    if (this.buffer.length < this.offset + e) throw new Error("Cannot read slice out of bounds");
    const t = this.buffer.slice(this.offset, this.offset + e);
    return this.offset += e, t;
  }
  readVarSlice() {
    return this.readSlice(this.readVarInt());
  }
  readVector() {
    const e = this.readVarInt(),
      t = [];
    for (let n = 0; n < e; n++) t.push(this.readVarSlice());
    return t;
  }
}
var L,
  V,
  K,
  D,
  G = {},
  F = {
    get exports() {
      return G;
    },
    set exports(e) {
      G = e;
    }
  },
  M = {},
  W = {},
  X = {},
  j = {},
  q = {},
  Y = {};
L = Y, Object.defineProperty(L, "__esModule", {
  value: !0
}), (V = L.GlobalTypes || (L.GlobalTypes = {}))[V.UNSIGNED_TX = 0] = "UNSIGNED_TX", V[V.GLOBAL_XPUB = 1] = "GLOBAL_XPUB", L.GLOBAL_TYPE_NAMES = ["unsignedTx", "globalXpub"], (K = L.InputTypes || (L.InputTypes = {}))[K.NON_WITNESS_UTXO = 0] = "NON_WITNESS_UTXO", K[K.WITNESS_UTXO = 1] = "WITNESS_UTXO", K[K.PARTIAL_SIG = 2] = "PARTIAL_SIG", K[K.SIGHASH_TYPE = 3] = "SIGHASH_TYPE", K[K.REDEEM_SCRIPT = 4] = "REDEEM_SCRIPT", K[K.WITNESS_SCRIPT = 5] = "WITNESS_SCRIPT", K[K.BIP32_DERIVATION = 6] = "BIP32_DERIVATION", K[K.FINAL_SCRIPTSIG = 7] = "FINAL_SCRIPTSIG", K[K.FINAL_SCRIPTWITNESS = 8] = "FINAL_SCRIPTWITNESS", K[K.POR_COMMITMENT = 9] = "POR_COMMITMENT", K[K.TAP_KEY_SIG = 19] = "TAP_KEY_SIG", K[K.TAP_SCRIPT_SIG = 20] = "TAP_SCRIPT_SIG", K[K.TAP_LEAF_SCRIPT = 21] = "TAP_LEAF_SCRIPT", K[K.TAP_BIP32_DERIVATION = 22] = "TAP_BIP32_DERIVATION", K[K.TAP_INTERNAL_KEY = 23] = "TAP_INTERNAL_KEY", K[K.TAP_MERKLE_ROOT = 24] = "TAP_MERKLE_ROOT", L.INPUT_TYPE_NAMES = ["nonWitnessUtxo", "witnessUtxo", "partialSig", "sighashType", "redeemScript", "witnessScript", "bip32Derivation", "finalScriptSig", "finalScriptWitness", "porCommitment", "tapKeySig", "tapScriptSig", "tapLeafScript", "tapBip32Derivation", "tapInternalKey", "tapMerkleRoot"], (D = L.OutputTypes || (L.OutputTypes = {}))[D.REDEEM_SCRIPT = 0] = "REDEEM_SCRIPT", D[D.WITNESS_SCRIPT = 1] = "WITNESS_SCRIPT", D[D.BIP32_DERIVATION = 2] = "BIP32_DERIVATION", D[D.TAP_INTERNAL_KEY = 5] = "TAP_INTERNAL_KEY", D[D.TAP_TREE = 6] = "TAP_TREE", D[D.TAP_BIP32_DERIVATION = 7] = "TAP_BIP32_DERIVATION", L.OUTPUT_TYPE_NAMES = ["redeemScript", "witnessScript", "bip32Derivation", "tapInternalKey", "tapTree", "tapBip32Derivation"];
var $ = {};
const {
  Buffer: z
} = _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_0__.b;
Object.defineProperty($, "__esModule", {
  value: !0
});
const J = Y;
$.decode = function (e) {
  if (e.key[0] !== J.GlobalTypes.GLOBAL_XPUB) throw new Error("Decode Error: could not decode globalXpub with key 0x" + e.key.toString("hex"));
  if (79 !== e.key.length || ![2, 3].includes(e.key[46])) throw new Error("Decode Error: globalXpub has invalid extended pubkey in key 0x" + e.key.toString("hex"));
  if (e.value.length / 4 % 1 != 0) throw new Error("Decode Error: Global GLOBAL_XPUB value length should be multiple of 4");
  const t = e.key.slice(1),
    n = {
      masterFingerprint: e.value.slice(0, 4),
      extendedPubkey: t,
      path: "m"
    };
  for (const t of (r = e.value.length / 4 - 1, [...Array(r).keys()])) {
    const r = e.value.readUInt32LE(4 * t + 4),
      i = !!(2147483648 & r),
      s = 2147483647 & r;
    n.path += "/" + s.toString(10) + (i ? "'" : "");
  }
  var r;
  return n;
}, $.encode = function (e) {
  const t = z.from([J.GlobalTypes.GLOBAL_XPUB]),
    n = z.concat([t, e.extendedPubkey]),
    r = e.path.split("/"),
    i = z.allocUnsafe(4 * r.length);
  e.masterFingerprint.copy(i, 0);
  let s = 4;
  return r.slice(1).forEach(e => {
    const t = "'" === e.slice(-1);
    let n = 2147483647 & parseInt(t ? e.slice(0, -1) : e, 10);
    t && (n += 2147483648), i.writeUInt32LE(n, s), s += 4;
  }), {
    key: n,
    value: i
  };
}, $.expected = "{ masterFingerprint: Buffer; extendedPubkey: Buffer; path: string; }", $.check = function (e) {
  const t = e.extendedPubkey,
    n = e.masterFingerprint,
    r = e.path;
  return z.isBuffer(t) && 78 === t.length && [2, 3].indexOf(t[45]) > -1 && z.isBuffer(n) && 4 === n.length && "string" == typeof r && !!r.match(/^m(\/\d+'?)*$/);
}, $.canAddToArray = function (e, t, n) {
  const r = t.extendedPubkey.toString("hex");
  return !n.has(r) && (n.add(r), 0 === e.filter(e => e.extendedPubkey.equals(t.extendedPubkey)).length);
};
var Q = {};
const {
  Buffer: Z
} = _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_0__.b;
Object.defineProperty(Q, "__esModule", {
  value: !0
});
const ee = Y;
Q.encode = function (e) {
  return {
    key: Z.from([ee.GlobalTypes.UNSIGNED_TX]),
    value: e.toBuffer()
  };
};
var te = {};
const {
  Buffer: ne
} = _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_0__.b;
Object.defineProperty(te, "__esModule", {
  value: !0
});
const re = Y;
te.decode = function (e) {
  if (e.key[0] !== re.InputTypes.FINAL_SCRIPTSIG) throw new Error("Decode Error: could not decode finalScriptSig with key 0x" + e.key.toString("hex"));
  return e.value;
}, te.encode = function (e) {
  return {
    key: ne.from([re.InputTypes.FINAL_SCRIPTSIG]),
    value: e
  };
}, te.expected = "Buffer", te.check = function (e) {
  return ne.isBuffer(e);
}, te.canAdd = function (e, t) {
  return !!e && !!t && void 0 === e.finalScriptSig;
};
var ie = {};
const {
  Buffer: se
} = _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_0__.b;
Object.defineProperty(ie, "__esModule", {
  value: !0
});
const oe = Y;
ie.decode = function (e) {
  if (e.key[0] !== oe.InputTypes.FINAL_SCRIPTWITNESS) throw new Error("Decode Error: could not decode finalScriptWitness with key 0x" + e.key.toString("hex"));
  return e.value;
}, ie.encode = function (e) {
  return {
    key: se.from([oe.InputTypes.FINAL_SCRIPTWITNESS]),
    value: e
  };
}, ie.expected = "Buffer", ie.check = function (e) {
  return se.isBuffer(e);
}, ie.canAdd = function (e, t) {
  return !!e && !!t && void 0 === e.finalScriptWitness;
};
var ue = {};
const {
  Buffer: ae
} = _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_0__.b;
Object.defineProperty(ue, "__esModule", {
  value: !0
});
const ce = Y;
ue.decode = function (e) {
  if (e.key[0] !== ce.InputTypes.NON_WITNESS_UTXO) throw new Error("Decode Error: could not decode nonWitnessUtxo with key 0x" + e.key.toString("hex"));
  return e.value;
}, ue.encode = function (e) {
  return {
    key: ae.from([ce.InputTypes.NON_WITNESS_UTXO]),
    value: e
  };
}, ue.expected = "Buffer", ue.check = function (e) {
  return ae.isBuffer(e);
}, ue.canAdd = function (e, t) {
  return !!e && !!t && void 0 === e.nonWitnessUtxo;
};
var pe = {};
const {
  Buffer: fe
} = _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_0__.b;
Object.defineProperty(pe, "__esModule", {
  value: !0
});
const he = Y;
pe.decode = function (e) {
  if (e.key[0] !== he.InputTypes.PARTIAL_SIG) throw new Error("Decode Error: could not decode partialSig with key 0x" + e.key.toString("hex"));
  if (34 !== e.key.length && 66 !== e.key.length || ![2, 3, 4].includes(e.key[1])) throw new Error("Decode Error: partialSig has invalid pubkey in key 0x" + e.key.toString("hex"));
  return {
    pubkey: e.key.slice(1),
    signature: e.value
  };
}, pe.encode = function (e) {
  const t = fe.from([he.InputTypes.PARTIAL_SIG]);
  return {
    key: fe.concat([t, e.pubkey]),
    value: e.signature
  };
}, pe.expected = "{ pubkey: Buffer; signature: Buffer; }", pe.check = function (e) {
  return fe.isBuffer(e.pubkey) && fe.isBuffer(e.signature) && [33, 65].includes(e.pubkey.length) && [2, 3, 4].includes(e.pubkey[0]) && function (e) {
    if (!fe.isBuffer(e) || e.length < 9) return !1;
    if (48 !== e[0]) return !1;
    if (e.length !== e[1] + 3) return !1;
    if (2 !== e[2]) return !1;
    const t = e[3];
    if (t > 33 || t < 1) return !1;
    if (2 !== e[3 + t + 1]) return !1;
    const n = e[3 + t + 2];
    return !(n > 33 || n < 1) && e.length === 3 + t + 2 + n + 2;
  }(e.signature);
}, pe.canAddToArray = function (e, t, n) {
  const r = t.pubkey.toString("hex");
  return !n.has(r) && (n.add(r), 0 === e.filter(e => e.pubkey.equals(t.pubkey)).length);
};
var le = {};
const {
  Buffer: de
} = _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_0__.b;
Object.defineProperty(le, "__esModule", {
  value: !0
});
const ye = Y;
le.decode = function (e) {
  if (e.key[0] !== ye.InputTypes.POR_COMMITMENT) throw new Error("Decode Error: could not decode porCommitment with key 0x" + e.key.toString("hex"));
  return e.value.toString("utf8");
}, le.encode = function (e) {
  return {
    key: de.from([ye.InputTypes.POR_COMMITMENT]),
    value: de.from(e, "utf8")
  };
}, le.expected = "string", le.check = function (e) {
  return "string" == typeof e;
}, le.canAdd = function (e, t) {
  return !!e && !!t && void 0 === e.porCommitment;
};
var Se = {};
const {
  Buffer: Ee
} = _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_0__.b;
Object.defineProperty(Se, "__esModule", {
  value: !0
});
const _e = Y;
Se.decode = function (e) {
  if (e.key[0] !== _e.InputTypes.SIGHASH_TYPE) throw new Error("Decode Error: could not decode sighashType with key 0x" + e.key.toString("hex"));
  return e.value.readUInt32LE(0);
}, Se.encode = function (e) {
  const t = Ee.from([_e.InputTypes.SIGHASH_TYPE]),
    n = Ee.allocUnsafe(4);
  return n.writeUInt32LE(e, 0), {
    key: t,
    value: n
  };
}, Se.expected = "number", Se.check = function (e) {
  return "number" == typeof e;
}, Se.canAdd = function (e, t) {
  return !!e && !!t && void 0 === e.sighashType;
};
var ge = {};
const {
  Buffer: we
} = _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_0__.b;
Object.defineProperty(ge, "__esModule", {
  value: !0
});
const Ie = Y;
function Te(e) {
  return we.isBuffer(e) && (64 === e.length || 65 === e.length);
}
ge.decode = function (e) {
  if (e.key[0] !== Ie.InputTypes.TAP_KEY_SIG || 1 !== e.key.length) throw new Error("Decode Error: could not decode tapKeySig with key 0x" + e.key.toString("hex"));
  if (!Te(e.value)) throw new Error("Decode Error: tapKeySig not a valid 64-65-byte BIP340 signature");
  return e.value;
}, ge.encode = function (e) {
  return {
    key: we.from([Ie.InputTypes.TAP_KEY_SIG]),
    value: e
  };
}, ge.expected = "Buffer", ge.check = Te, ge.canAdd = function (e, t) {
  return !!e && !!t && void 0 === e.tapKeySig;
};
var ke = {};
const {
  Buffer: be
} = _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_0__.b;
Object.defineProperty(ke, "__esModule", {
  value: !0
});
const Ae = Y;
ke.decode = function (e) {
  if (e.key[0] !== Ae.InputTypes.TAP_LEAF_SCRIPT) throw new Error("Decode Error: could not decode tapLeafScript with key 0x" + e.key.toString("hex"));
  if ((e.key.length - 2) % 32 != 0) throw new Error("Decode Error: tapLeafScript has invalid control block in key 0x" + e.key.toString("hex"));
  const t = e.value[e.value.length - 1];
  if ((254 & e.key[1]) !== t) throw new Error("Decode Error: tapLeafScript bad leaf version in key 0x" + e.key.toString("hex"));
  const n = e.value.slice(0, -1);
  return {
    controlBlock: e.key.slice(1),
    script: n,
    leafVersion: t
  };
}, ke.encode = function (e) {
  const t = be.from([Ae.InputTypes.TAP_LEAF_SCRIPT]),
    n = be.from([e.leafVersion]);
  return {
    key: be.concat([t, e.controlBlock]),
    value: be.concat([e.script, n])
  };
}, ke.expected = "{ controlBlock: Buffer; leafVersion: number, script: Buffer; }", ke.check = function (e) {
  return be.isBuffer(e.controlBlock) && (e.controlBlock.length - 1) % 32 == 0 && (254 & e.controlBlock[0]) === e.leafVersion && be.isBuffer(e.script);
}, ke.canAddToArray = function (e, t, n) {
  const r = t.controlBlock.toString("hex");
  return !n.has(r) && (n.add(r), 0 === e.filter(e => e.controlBlock.equals(t.controlBlock)).length);
};
var me = {};
const {
  Buffer: ve
} = _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_0__.b;
Object.defineProperty(me, "__esModule", {
  value: !0
});
const Ne = Y;
function Oe(e) {
  return ve.isBuffer(e) && 32 === e.length;
}
me.decode = function (e) {
  if (e.key[0] !== Ne.InputTypes.TAP_MERKLE_ROOT || 1 !== e.key.length) throw new Error("Decode Error: could not decode tapMerkleRoot with key 0x" + e.key.toString("hex"));
  if (!Oe(e.value)) throw new Error("Decode Error: tapMerkleRoot not a 32-byte hash");
  return e.value;
}, me.encode = function (e) {
  return {
    key: ve.from([Ne.InputTypes.TAP_MERKLE_ROOT]),
    value: e
  };
}, me.expected = "Buffer", me.check = Oe, me.canAdd = function (e, t) {
  return !!e && !!t && void 0 === e.tapMerkleRoot;
};
var Pe = {};
const {
  Buffer: Ce
} = _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_0__.b;
Object.defineProperty(Pe, "__esModule", {
  value: !0
});
const xe = Y;
Pe.decode = function (e) {
  if (e.key[0] !== xe.InputTypes.TAP_SCRIPT_SIG) throw new Error("Decode Error: could not decode tapScriptSig with key 0x" + e.key.toString("hex"));
  if (65 !== e.key.length) throw new Error("Decode Error: tapScriptSig has invalid key 0x" + e.key.toString("hex"));
  if (64 !== e.value.length && 65 !== e.value.length) throw new Error("Decode Error: tapScriptSig has invalid signature in key 0x" + e.key.toString("hex"));
  return {
    pubkey: e.key.slice(1, 33),
    leafHash: e.key.slice(33),
    signature: e.value
  };
}, Pe.encode = function (e) {
  const t = Ce.from([xe.InputTypes.TAP_SCRIPT_SIG]);
  return {
    key: Ce.concat([t, e.pubkey, e.leafHash]),
    value: e.signature
  };
}, Pe.expected = "{ pubkey: Buffer; leafHash: Buffer; signature: Buffer; }", Pe.check = function (e) {
  return Ce.isBuffer(e.pubkey) && Ce.isBuffer(e.leafHash) && Ce.isBuffer(e.signature) && 32 === e.pubkey.length && 32 === e.leafHash.length && (64 === e.signature.length || 65 === e.signature.length);
}, Pe.canAddToArray = function (e, t, n) {
  const r = t.pubkey.toString("hex") + t.leafHash.toString("hex");
  return !n.has(r) && (n.add(r), 0 === e.filter(e => e.pubkey.equals(t.pubkey) && e.leafHash.equals(t.leafHash)).length);
};
var Ue = {},
  He = {},
  Be = {};
const {
  Buffer: Re
} = _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_0__.b;
Object.defineProperty(Be, "__esModule", {
  value: !0
});
const Le = 9007199254740991;
function Ve(e) {
  if (e < 0 || e > Le || e % 1 != 0) throw new RangeError("value out of range");
}
function Ke(e) {
  return Ve(e), e < 253 ? 1 : e <= 65535 ? 3 : e <= 4294967295 ? 5 : 9;
}
Be.encode = function e(t, n, r) {
  if (Ve(t), n || (n = Re.allocUnsafe(Ke(t))), !Re.isBuffer(n)) throw new TypeError("buffer must be a Buffer instance");
  return r || (r = 0), t < 253 ? (n.writeUInt8(t, r), Object.assign(e, {
    bytes: 1
  })) : t <= 65535 ? (n.writeUInt8(253, r), n.writeUInt16LE(t, r + 1), Object.assign(e, {
    bytes: 3
  })) : t <= 4294967295 ? (n.writeUInt8(254, r), n.writeUInt32LE(t, r + 1), Object.assign(e, {
    bytes: 5
  })) : (n.writeUInt8(255, r), n.writeUInt32LE(t >>> 0, r + 1), n.writeUInt32LE(t / 4294967296 | 0, r + 5), Object.assign(e, {
    bytes: 9
  })), n;
}, Be.decode = function e(t, n) {
  if (!Re.isBuffer(t)) throw new TypeError("buffer must be a Buffer instance");
  n || (n = 0);
  const r = t.readUInt8(n);
  if (r < 253) return Object.assign(e, {
    bytes: 1
  }), r;
  if (253 === r) return Object.assign(e, {
    bytes: 3
  }), t.readUInt16LE(n + 1);
  if (254 === r) return Object.assign(e, {
    bytes: 5
  }), t.readUInt32LE(n + 1);
  {
    Object.assign(e, {
      bytes: 9
    });
    const r = t.readUInt32LE(n + 1),
      i = 4294967296 * t.readUInt32LE(n + 5) + r;
    return Ve(i), i;
  }
}, Be.encodingLength = Ke;
const {
  Buffer: De
} = _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_0__.b;
Object.defineProperty(He, "__esModule", {
  value: !0
});
const Ge = Be;
function Fe(e) {
  const t = e.key.length,
    n = e.value.length,
    r = Ge.encodingLength(t),
    i = Ge.encodingLength(n),
    s = De.allocUnsafe(r + t + i + n);
  return Ge.encode(t, s, 0), e.key.copy(s, r), Ge.encode(n, s, r + t), e.value.copy(s, r + t + i), s;
}
function Me(e, t) {
  if ("number" != typeof e) throw new Error("cannot write a non-number as a number");
  if (e < 0) throw new Error("specified a negative value for writing an unsigned value");
  if (e > t) throw new Error("RangeError: value out of range");
  if (Math.floor(e) !== e) throw new Error("value has a fractional component");
}
He.range = e => [...Array(e).keys()], He.reverseBuffer = function (e) {
  if (e.length < 1) return e;
  let t = e.length - 1,
    n = 0;
  for (let r = 0; r < e.length / 2; r++) n = e[r], e[r] = e[t], e[t] = n, t--;
  return e;
}, He.keyValsToBuffer = function (e) {
  const t = e.map(Fe);
  return t.push(De.from([0])), De.concat(t);
}, He.keyValToBuffer = Fe, He.readUInt64LE = function (e, t) {
  const n = e.readUInt32LE(t);
  let r = e.readUInt32LE(t + 4);
  return r *= 4294967296, Me(r + n, 9007199254740991), r + n;
}, He.writeUInt64LE = function (e, t, n) {
  return Me(t, 9007199254740991), e.writeInt32LE(-1 & t, n), e.writeUInt32LE(Math.floor(t / 4294967296), n + 4), n + 8;
};
const {
  Buffer: We
} = _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_0__.b;
Object.defineProperty(Ue, "__esModule", {
  value: !0
});
const Xe = Y,
  je = He,
  qe = Be;
Ue.decode = function (e) {
  if (e.key[0] !== Xe.InputTypes.WITNESS_UTXO) throw new Error("Decode Error: could not decode witnessUtxo with key 0x" + e.key.toString("hex"));
  const t = je.readUInt64LE(e.value, 0);
  let n = 8;
  const r = qe.decode(e.value, n);
  n += qe.encodingLength(r);
  const i = e.value.slice(n);
  if (i.length !== r) throw new Error("Decode Error: WITNESS_UTXO script is not proper length");
  return {
    script: i,
    value: t
  };
}, Ue.encode = function (e) {
  const {
      script: t,
      value: n
    } = e,
    r = qe.encodingLength(t.length),
    i = We.allocUnsafe(8 + r + t.length);
  return je.writeUInt64LE(i, n, 0), qe.encode(t.length, i, 8), t.copy(i, 8 + r), {
    key: We.from([Xe.InputTypes.WITNESS_UTXO]),
    value: i
  };
}, Ue.expected = "{ script: Buffer; value: number; }", Ue.check = function (e) {
  return We.isBuffer(e.script) && "number" == typeof e.value;
}, Ue.canAdd = function (e, t) {
  return !!e && !!t && void 0 === e.witnessUtxo;
};
var Ye = {};
const {
  Buffer: $e
} = _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_0__.b;
Object.defineProperty(Ye, "__esModule", {
  value: !0
});
const ze = Y,
  Je = Be;
Ye.decode = function (e) {
  if (e.key[0] !== ze.OutputTypes.TAP_TREE || 1 !== e.key.length) throw new Error("Decode Error: could not decode tapTree with key 0x" + e.key.toString("hex"));
  let t = 0;
  const n = [];
  for (; t < e.value.length;) {
    const r = e.value[t++],
      i = e.value[t++],
      s = Je.decode(e.value, t);
    t += Je.encodingLength(s), n.push({
      depth: r,
      leafVersion: i,
      script: e.value.slice(t, t + s)
    }), t += s;
  }
  return {
    leaves: n
  };
}, Ye.encode = function (e) {
  const t = $e.from([ze.OutputTypes.TAP_TREE]),
    n = [].concat(...e.leaves.map(e => [$e.of(e.depth, e.leafVersion), Je.encode(e.script.length), e.script]));
  return {
    key: t,
    value: $e.concat(n)
  };
}, Ye.expected = "{ leaves: [{ depth: number; leafVersion: number, script: Buffer; }] }", Ye.check = function (e) {
  return Array.isArray(e.leaves) && e.leaves.every(e => e.depth >= 0 && e.depth <= 128 && (254 & e.leafVersion) === e.leafVersion && $e.isBuffer(e.script));
}, Ye.canAdd = function (e, t) {
  return !!e && !!t && void 0 === e.tapTree;
};
var Qe = {};
const {
  Buffer: Ze
} = _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_0__.b;
Object.defineProperty(Qe, "__esModule", {
  value: !0
});
const et = e => 33 === e.length && [2, 3].includes(e[0]) || 65 === e.length && 4 === e[0];
Qe.makeConverter = function (e, t = et) {
  return {
    decode: function (n) {
      if (n.key[0] !== e) throw new Error("Decode Error: could not decode bip32Derivation with key 0x" + n.key.toString("hex"));
      const r = n.key.slice(1);
      if (!t(r)) throw new Error("Decode Error: bip32Derivation has invalid pubkey in key 0x" + n.key.toString("hex"));
      if (n.value.length / 4 % 1 != 0) throw new Error("Decode Error: Input BIP32_DERIVATION value length should be multiple of 4");
      const i = {
        masterFingerprint: n.value.slice(0, 4),
        pubkey: r,
        path: "m"
      };
      for (const e of (s = n.value.length / 4 - 1, [...Array(s).keys()])) {
        const t = n.value.readUInt32LE(4 * e + 4),
          r = !!(2147483648 & t),
          s = 2147483647 & t;
        i.path += "/" + s.toString(10) + (r ? "'" : "");
      }
      var s;
      return i;
    },
    encode: function (t) {
      const n = Ze.from([e]),
        r = Ze.concat([n, t.pubkey]),
        i = t.path.split("/"),
        s = Ze.allocUnsafe(4 * i.length);
      t.masterFingerprint.copy(s, 0);
      let o = 4;
      return i.slice(1).forEach(e => {
        const t = "'" === e.slice(-1);
        let n = 2147483647 & parseInt(t ? e.slice(0, -1) : e, 10);
        t && (n += 2147483648), s.writeUInt32LE(n, o), o += 4;
      }), {
        key: r,
        value: s
      };
    },
    check: function (e) {
      return Ze.isBuffer(e.pubkey) && Ze.isBuffer(e.masterFingerprint) && "string" == typeof e.path && t(e.pubkey) && 4 === e.masterFingerprint.length;
    },
    expected: "{ masterFingerprint: Buffer; pubkey: Buffer; path: string; }",
    canAddToArray: function (e, t, n) {
      const r = t.pubkey.toString("hex");
      return !n.has(r) && (n.add(r), 0 === e.filter(e => e.pubkey.equals(t.pubkey)).length);
    }
  };
};
var tt = {};
Object.defineProperty(tt, "__esModule", {
  value: !0
}), tt.makeChecker = function (e) {
  return function (t) {
    let n;
    if (e.includes(t.key[0]) && (n = t.key.slice(1), 33 !== n.length && 65 !== n.length || ![2, 3, 4].includes(n[0]))) throw new Error("Format Error: invalid pubkey in key 0x" + t.key.toString("hex"));
    return n;
  };
};
var nt = {};
const {
  Buffer: rt
} = _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_0__.b;
Object.defineProperty(nt, "__esModule", {
  value: !0
}), nt.makeConverter = function (e) {
  return {
    decode: function (t) {
      if (t.key[0] !== e) throw new Error("Decode Error: could not decode redeemScript with key 0x" + t.key.toString("hex"));
      return t.value;
    },
    encode: function (t) {
      return {
        key: rt.from([e]),
        value: t
      };
    },
    check: function (e) {
      return rt.isBuffer(e);
    },
    expected: "Buffer",
    canAdd: function (e, t) {
      return !!e && !!t && void 0 === e.redeemScript;
    }
  };
};
var it = {};
const {
  Buffer: st
} = _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_0__.b;
Object.defineProperty(it, "__esModule", {
  value: !0
});
const ot = Be,
  ut = Qe,
  at = e => 32 === e.length;
it.makeConverter = function (e) {
  const t = ut.makeConverter(e, at);
  return {
    decode: function (e) {
      const n = ot.decode(e.value),
        r = ot.encodingLength(n),
        i = t.decode({
          key: e.key,
          value: e.value.slice(r + 32 * n)
        }),
        s = new Array(n);
      for (let t = 0, i = r; t < n; t++, i += 32) s[t] = e.value.slice(i, i + 32);
      return Object.assign({}, i, {
        leafHashes: s
      });
    },
    encode: function (e) {
      const n = t.encode(e),
        r = ot.encodingLength(e.leafHashes.length),
        i = st.allocUnsafe(r);
      ot.encode(e.leafHashes.length, i);
      const s = st.concat([i, ...e.leafHashes, n.value]);
      return Object.assign({}, n, {
        value: s
      });
    },
    check: function (e) {
      return Array.isArray(e.leafHashes) && e.leafHashes.every(e => st.isBuffer(e) && 32 === e.length) && t.check(e);
    },
    expected: "{ masterFingerprint: Buffer; pubkey: Buffer; path: string; leafHashes: Buffer[]; }",
    canAddToArray: t.canAddToArray
  };
};
var ct = {};
const {
  Buffer: pt
} = _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_0__.b;
Object.defineProperty(ct, "__esModule", {
  value: !0
}), ct.makeConverter = function (e) {
  return {
    decode: function (t) {
      if (t.key[0] !== e || 1 !== t.key.length) throw new Error("Decode Error: could not decode tapInternalKey with key 0x" + t.key.toString("hex"));
      if (32 !== t.value.length) throw new Error("Decode Error: tapInternalKey not a 32-byte x-only pubkey");
      return t.value;
    },
    encode: function (t) {
      return {
        key: pt.from([e]),
        value: t
      };
    },
    check: function (e) {
      return pt.isBuffer(e) && 32 === e.length;
    },
    expected: "Buffer",
    canAdd: function (e, t) {
      return !!e && !!t && void 0 === e.tapInternalKey;
    }
  };
};
var ft = {};
const {
  Buffer: ht
} = _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_0__.b;
Object.defineProperty(ft, "__esModule", {
  value: !0
}), ft.makeConverter = function (e) {
  return {
    decode: function (t) {
      if (t.key[0] !== e) throw new Error("Decode Error: could not decode witnessScript with key 0x" + t.key.toString("hex"));
      return t.value;
    },
    encode: function (t) {
      return {
        key: ht.from([e]),
        value: t
      };
    },
    check: function (e) {
      return ht.isBuffer(e);
    },
    expected: "Buffer",
    canAdd: function (e, t) {
      return !!e && !!t && void 0 === e.witnessScript;
    }
  };
}, Object.defineProperty(q, "__esModule", {
  value: !0
});
const lt = Y,
  dt = te,
  yt = ie,
  St = ue,
  Et = pe,
  _t = le,
  gt = Se,
  wt = ge,
  It = ke,
  Tt = me,
  kt = Pe,
  bt = Ue,
  At = Ye,
  mt = Qe,
  vt = tt,
  Nt = nt,
  Ot = it,
  Pt = ct,
  Ct = ft,
  xt = {
    unsignedTx: Q,
    globalXpub: $,
    checkPubkey: vt.makeChecker([])
  };
q.globals = xt;
const Ut = {
  nonWitnessUtxo: St,
  partialSig: Et,
  sighashType: gt,
  finalScriptSig: dt,
  finalScriptWitness: yt,
  porCommitment: _t,
  witnessUtxo: bt,
  bip32Derivation: mt.makeConverter(lt.InputTypes.BIP32_DERIVATION),
  redeemScript: Nt.makeConverter(lt.InputTypes.REDEEM_SCRIPT),
  witnessScript: Ct.makeConverter(lt.InputTypes.WITNESS_SCRIPT),
  checkPubkey: vt.makeChecker([lt.InputTypes.PARTIAL_SIG, lt.InputTypes.BIP32_DERIVATION]),
  tapKeySig: wt,
  tapScriptSig: kt,
  tapLeafScript: It,
  tapBip32Derivation: Ot.makeConverter(lt.InputTypes.TAP_BIP32_DERIVATION),
  tapInternalKey: Pt.makeConverter(lt.InputTypes.TAP_INTERNAL_KEY),
  tapMerkleRoot: Tt
};
q.inputs = Ut;
const Ht = {
  bip32Derivation: mt.makeConverter(lt.OutputTypes.BIP32_DERIVATION),
  redeemScript: Nt.makeConverter(lt.OutputTypes.REDEEM_SCRIPT),
  witnessScript: Ct.makeConverter(lt.OutputTypes.WITNESS_SCRIPT),
  checkPubkey: vt.makeChecker([lt.OutputTypes.BIP32_DERIVATION]),
  tapBip32Derivation: Ot.makeConverter(lt.OutputTypes.TAP_BIP32_DERIVATION),
  tapTree: At,
  tapInternalKey: Pt.makeConverter(lt.OutputTypes.TAP_INTERNAL_KEY)
};
q.outputs = Ht;
const {
  Buffer: Bt
} = _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_0__.b;
Object.defineProperty(j, "__esModule", {
  value: !0
});
const Rt = q,
  Lt = He,
  Vt = Be,
  Kt = Y;
function Dt(e, t, n) {
  if (!t.equals(Bt.from([n]))) throw new Error(`Format Error: Invalid ${e} key: ${t.toString("hex")}`);
}
function Gt(e, {
  globalMapKeyVals: t,
  inputKeyVals: n,
  outputKeyVals: r
}) {
  const i = {
    unsignedTx: e
  };
  let s = 0;
  for (const e of t) switch (e.key[0]) {
    case Kt.GlobalTypes.UNSIGNED_TX:
      if (Dt("global", e.key, Kt.GlobalTypes.UNSIGNED_TX), s > 0) throw new Error("Format Error: GlobalMap has multiple UNSIGNED_TX");
      s++;
      break;
    case Kt.GlobalTypes.GLOBAL_XPUB:
      void 0 === i.globalXpub && (i.globalXpub = []), i.globalXpub.push(Rt.globals.globalXpub.decode(e));
      break;
    default:
      i.unknownKeyVals || (i.unknownKeyVals = []), i.unknownKeyVals.push(e);
  }
  const o = n.length,
    u = r.length,
    a = [],
    c = [];
  for (const e of Lt.range(o)) {
    const t = {};
    for (const r of n[e]) switch (Rt.inputs.checkPubkey(r), r.key[0]) {
      case Kt.InputTypes.NON_WITNESS_UTXO:
        if (Dt("input", r.key, Kt.InputTypes.NON_WITNESS_UTXO), void 0 !== t.nonWitnessUtxo) throw new Error("Format Error: Input has multiple NON_WITNESS_UTXO");
        t.nonWitnessUtxo = Rt.inputs.nonWitnessUtxo.decode(r);
        break;
      case Kt.InputTypes.WITNESS_UTXO:
        if (Dt("input", r.key, Kt.InputTypes.WITNESS_UTXO), void 0 !== t.witnessUtxo) throw new Error("Format Error: Input has multiple WITNESS_UTXO");
        t.witnessUtxo = Rt.inputs.witnessUtxo.decode(r);
        break;
      case Kt.InputTypes.PARTIAL_SIG:
        void 0 === t.partialSig && (t.partialSig = []), t.partialSig.push(Rt.inputs.partialSig.decode(r));
        break;
      case Kt.InputTypes.SIGHASH_TYPE:
        if (Dt("input", r.key, Kt.InputTypes.SIGHASH_TYPE), void 0 !== t.sighashType) throw new Error("Format Error: Input has multiple SIGHASH_TYPE");
        t.sighashType = Rt.inputs.sighashType.decode(r);
        break;
      case Kt.InputTypes.REDEEM_SCRIPT:
        if (Dt("input", r.key, Kt.InputTypes.REDEEM_SCRIPT), void 0 !== t.redeemScript) throw new Error("Format Error: Input has multiple REDEEM_SCRIPT");
        t.redeemScript = Rt.inputs.redeemScript.decode(r);
        break;
      case Kt.InputTypes.WITNESS_SCRIPT:
        if (Dt("input", r.key, Kt.InputTypes.WITNESS_SCRIPT), void 0 !== t.witnessScript) throw new Error("Format Error: Input has multiple WITNESS_SCRIPT");
        t.witnessScript = Rt.inputs.witnessScript.decode(r);
        break;
      case Kt.InputTypes.BIP32_DERIVATION:
        void 0 === t.bip32Derivation && (t.bip32Derivation = []), t.bip32Derivation.push(Rt.inputs.bip32Derivation.decode(r));
        break;
      case Kt.InputTypes.FINAL_SCRIPTSIG:
        Dt("input", r.key, Kt.InputTypes.FINAL_SCRIPTSIG), t.finalScriptSig = Rt.inputs.finalScriptSig.decode(r);
        break;
      case Kt.InputTypes.FINAL_SCRIPTWITNESS:
        Dt("input", r.key, Kt.InputTypes.FINAL_SCRIPTWITNESS), t.finalScriptWitness = Rt.inputs.finalScriptWitness.decode(r);
        break;
      case Kt.InputTypes.POR_COMMITMENT:
        Dt("input", r.key, Kt.InputTypes.POR_COMMITMENT), t.porCommitment = Rt.inputs.porCommitment.decode(r);
        break;
      case Kt.InputTypes.TAP_KEY_SIG:
        Dt("input", r.key, Kt.InputTypes.TAP_KEY_SIG), t.tapKeySig = Rt.inputs.tapKeySig.decode(r);
        break;
      case Kt.InputTypes.TAP_SCRIPT_SIG:
        void 0 === t.tapScriptSig && (t.tapScriptSig = []), t.tapScriptSig.push(Rt.inputs.tapScriptSig.decode(r));
        break;
      case Kt.InputTypes.TAP_LEAF_SCRIPT:
        void 0 === t.tapLeafScript && (t.tapLeafScript = []), t.tapLeafScript.push(Rt.inputs.tapLeafScript.decode(r));
        break;
      case Kt.InputTypes.TAP_BIP32_DERIVATION:
        void 0 === t.tapBip32Derivation && (t.tapBip32Derivation = []), t.tapBip32Derivation.push(Rt.inputs.tapBip32Derivation.decode(r));
        break;
      case Kt.InputTypes.TAP_INTERNAL_KEY:
        Dt("input", r.key, Kt.InputTypes.TAP_INTERNAL_KEY), t.tapInternalKey = Rt.inputs.tapInternalKey.decode(r);
        break;
      case Kt.InputTypes.TAP_MERKLE_ROOT:
        Dt("input", r.key, Kt.InputTypes.TAP_MERKLE_ROOT), t.tapMerkleRoot = Rt.inputs.tapMerkleRoot.decode(r);
        break;
      default:
        t.unknownKeyVals || (t.unknownKeyVals = []), t.unknownKeyVals.push(r);
    }
    a.push(t);
  }
  for (const e of Lt.range(u)) {
    const t = {};
    for (const n of r[e]) switch (Rt.outputs.checkPubkey(n), n.key[0]) {
      case Kt.OutputTypes.REDEEM_SCRIPT:
        if (Dt("output", n.key, Kt.OutputTypes.REDEEM_SCRIPT), void 0 !== t.redeemScript) throw new Error("Format Error: Output has multiple REDEEM_SCRIPT");
        t.redeemScript = Rt.outputs.redeemScript.decode(n);
        break;
      case Kt.OutputTypes.WITNESS_SCRIPT:
        if (Dt("output", n.key, Kt.OutputTypes.WITNESS_SCRIPT), void 0 !== t.witnessScript) throw new Error("Format Error: Output has multiple WITNESS_SCRIPT");
        t.witnessScript = Rt.outputs.witnessScript.decode(n);
        break;
      case Kt.OutputTypes.BIP32_DERIVATION:
        void 0 === t.bip32Derivation && (t.bip32Derivation = []), t.bip32Derivation.push(Rt.outputs.bip32Derivation.decode(n));
        break;
      case Kt.OutputTypes.TAP_INTERNAL_KEY:
        Dt("output", n.key, Kt.OutputTypes.TAP_INTERNAL_KEY), t.tapInternalKey = Rt.outputs.tapInternalKey.decode(n);
        break;
      case Kt.OutputTypes.TAP_TREE:
        Dt("output", n.key, Kt.OutputTypes.TAP_TREE), t.tapTree = Rt.outputs.tapTree.decode(n);
        break;
      case Kt.OutputTypes.TAP_BIP32_DERIVATION:
        void 0 === t.tapBip32Derivation && (t.tapBip32Derivation = []), t.tapBip32Derivation.push(Rt.outputs.tapBip32Derivation.decode(n));
        break;
      default:
        t.unknownKeyVals || (t.unknownKeyVals = []), t.unknownKeyVals.push(n);
    }
    c.push(t);
  }
  return {
    globalMap: i,
    inputs: a,
    outputs: c
  };
}
j.psbtFromBuffer = function (e, t) {
  let n = 0;
  function r() {
    const t = Vt.decode(e, n);
    n += Vt.encodingLength(t);
    const r = e.slice(n, n + t);
    return n += t, r;
  }
  function i() {
    return {
      key: r(),
      value: r()
    };
  }
  function s() {
    if (n >= e.length) throw new Error("Format Error: Unexpected End of PSBT");
    const t = 0 === e.readUInt8(n);
    return t && n++, t;
  }
  if (1886610036 !== function () {
    const t = e.readUInt32BE(n);
    return n += 4, t;
  }()) throw new Error("Format Error: Invalid Magic Number");
  if (255 !== function () {
    const t = e.readUInt8(n);
    return n += 1, t;
  }()) throw new Error("Format Error: Magic Number must be followed by 0xff separator");
  const o = [],
    u = {};
  for (; !s();) {
    const e = i(),
      t = e.key.toString("hex");
    if (u[t]) throw new Error("Format Error: Keys must be unique for global keymap: key " + t);
    u[t] = 1, o.push(e);
  }
  const a = o.filter(e => e.key[0] === Kt.GlobalTypes.UNSIGNED_TX);
  if (1 !== a.length) throw new Error("Format Error: Only one UNSIGNED_TX allowed");
  const c = t(a[0].value),
    {
      inputCount: p,
      outputCount: f
    } = c.getInputOutputCounts(),
    h = [],
    l = [];
  for (const e of Lt.range(p)) {
    const t = {},
      n = [];
    for (; !s();) {
      const r = i(),
        s = r.key.toString("hex");
      if (t[s]) throw new Error("Format Error: Keys must be unique for each input: input index " + e + " key " + s);
      t[s] = 1, n.push(r);
    }
    h.push(n);
  }
  for (const e of Lt.range(f)) {
    const t = {},
      n = [];
    for (; !s();) {
      const r = i(),
        s = r.key.toString("hex");
      if (t[s]) throw new Error("Format Error: Keys must be unique for each output: output index " + e + " key " + s);
      t[s] = 1, n.push(r);
    }
    l.push(n);
  }
  return Gt(c, {
    globalMapKeyVals: o,
    inputKeyVals: h,
    outputKeyVals: l
  });
}, j.checkKeyBuffer = Dt, j.psbtFromKeyVals = Gt;
var Ft = {};
const {
  Buffer: Mt
} = _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_0__.b;
Object.defineProperty(Ft, "__esModule", {
  value: !0
});
const Wt = q,
  Xt = He;
Ft.psbtToBuffer = function ({
  globalMap: e,
  inputs: t,
  outputs: n
}) {
  const {
      globalKeyVals: r,
      inputKeyVals: i,
      outputKeyVals: s
    } = Yt({
      globalMap: e,
      inputs: t,
      outputs: n
    }),
    o = Xt.keyValsToBuffer(r),
    u = e => 0 === e.length ? [Mt.from([0])] : e.map(Xt.keyValsToBuffer),
    a = u(i),
    c = u(s),
    p = Mt.allocUnsafe(5);
  return p.writeUIntBE(482972169471, 0, 5), Mt.concat([p, o].concat(a, c));
};
const jt = (e, t) => e.key.compare(t.key);
function qt(e, t) {
  const n = new Set(),
    r = Object.entries(e).reduce((e, [r, i]) => {
      if ("unknownKeyVals" === r) return e;
      const s = t[r];
      if (void 0 === s) return e;
      const o = (Array.isArray(i) ? i : [i]).map(s.encode);
      return o.map(e => e.key.toString("hex")).forEach(e => {
        if (n.has(e)) throw new Error("Serialize Error: Duplicate key: " + e);
        n.add(e);
      }), e.concat(o);
    }, []),
    i = e.unknownKeyVals ? e.unknownKeyVals.filter(e => !n.has(e.key.toString("hex"))) : [];
  return r.concat(i).sort(jt);
}
function Yt({
  globalMap: e,
  inputs: t,
  outputs: n
}) {
  return {
    globalKeyVals: qt(e, Wt.globals),
    inputKeyVals: t.map(e => qt(e, Wt.inputs)),
    outputKeyVals: n.map(e => qt(e, Wt.outputs))
  };
}
Ft.psbtToKeyVals = Yt, function (e) {
  function t(t) {
    for (var n in t) e.hasOwnProperty(n) || (e[n] = t[n]);
  }
  Object.defineProperty(e, "__esModule", {
    value: !0
  }), t(j), t(Ft);
}(X), Object.defineProperty(W, "__esModule", {
  value: !0
});
const $t = X;
function zt(e, t, n) {
  return r => {
    if (e.has(r)) return;
    const i = n.filter(e => e.key.toString("hex") === r)[0];
    t.push(i), e.add(r);
  };
}
function Jt(e) {
  return e.globalMap.unsignedTx;
}
function Qt(e) {
  const t = new Set();
  return e.forEach(e => {
    const n = e.key.toString("hex");
    if (t.has(n)) throw new Error("Combine: KeyValue Map keys should be unique");
    t.add(n);
  }), t;
}
W.combine = function (e) {
  const t = e[0],
    n = $t.psbtToKeyVals(t),
    r = e.slice(1);
  if (0 === r.length) throw new Error("Combine: Nothing to combine");
  const i = Jt(t);
  if (void 0 === i) throw new Error("Combine: Self missing transaction");
  const s = Qt(n.globalKeyVals),
    o = n.inputKeyVals.map(Qt),
    u = n.outputKeyVals.map(Qt);
  for (const e of r) {
    const t = Jt(e);
    if (void 0 === t || !t.toBuffer().equals(i.toBuffer())) throw new Error("Combine: One of the Psbts does not have the same transaction.");
    const r = $t.psbtToKeyVals(e);
    Qt(r.globalKeyVals).forEach(zt(s, n.globalKeyVals, r.globalKeyVals));
    r.inputKeyVals.map(Qt).forEach((e, t) => e.forEach(zt(o[t], n.inputKeyVals[t], r.inputKeyVals[t])));
    r.outputKeyVals.map(Qt).forEach((e, t) => e.forEach(zt(u[t], n.outputKeyVals[t], r.outputKeyVals[t])));
  }
  return $t.psbtFromKeyVals(i, {
    globalMapKeyVals: n.globalKeyVals,
    inputKeyVals: n.inputKeyVals,
    outputKeyVals: n.outputKeyVals
  });
};
var Zt = {};
!function (e) {
  const {
    Buffer: n
  } = _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_0__.b;
  Object.defineProperty(e, "__esModule", {
    value: !0
  });
  const r = q;
  function i(e, t) {
    const n = e[t];
    if (void 0 === n) throw new Error(`No input #${t}`);
    return n;
  }
  function s(e, t) {
    const n = e[t];
    if (void 0 === n) throw new Error(`No output #${t}`);
    return n;
  }
  function o(e, t, n, r) {
    throw new Error(`Data for ${e} key ${t} is incorrect: Expected ${n} and got ${JSON.stringify(r)}`);
  }
  function u(e) {
    return (t, n) => {
      for (const i of Object.keys(t)) {
        const s = t[i],
          {
            canAdd: u,
            canAddToArray: a,
            check: c,
            expected: p
          } = r[e + "s"][i] || {};
        if (c) if (!!a) {
          if (!Array.isArray(s) || n[i] && !Array.isArray(n[i])) throw new Error(`Key type ${i} must be an array`);
          s.every(c) || o(e, i, p, s);
          const t = n[i] || [],
            r = new Set();
          if (!s.every(e => a(t, e, r))) throw new Error("Can not add duplicate data to array");
          n[i] = t.concat(s);
        } else {
          if (c(s) || o(e, i, p, s), !u(n, s)) throw new Error(`Can not add duplicate data to ${e}`);
          n[i] = s;
        }
      }
    };
  }
  e.checkForInput = i, e.checkForOutput = s, e.checkHasKey = function (e, t, n) {
    if (e.key[0] < n) throw new Error("Use the method for your specific key instead of addUnknownKeyVal*");
    if (t && 0 !== t.filter(t => t.key.equals(e.key)).length) throw new Error(`Duplicate Key: ${e.key.toString("hex")}`);
  }, e.getEnumLength = function (e) {
    let t = 0;
    return Object.keys(e).forEach(e => {
      Number(isNaN(Number(e))) && t++;
    }), t;
  }, e.inputCheckUncleanFinalized = function (e, t) {
    let n = !1;
    if (t.nonWitnessUtxo || t.witnessUtxo) {
      const e = !!t.redeemScript,
        r = !!t.witnessScript,
        i = !e || !!t.finalScriptSig,
        s = !r || !!t.finalScriptWitness,
        o = !!t.finalScriptSig || !!t.finalScriptWitness;
      n = i && s && o;
    }
    if (!1 === n) throw new Error(`Input #${e} has too much or too little data to clean`);
  }, e.updateGlobal = u("global"), e.updateInput = u("input"), e.updateOutput = u("output"), e.addInputAttributes = function (t, n) {
    const r = i(t, t.length - 1);
    e.updateInput(n, r);
  }, e.addOutputAttributes = function (t, n) {
    const r = s(t, t.length - 1);
    e.updateOutput(n, r);
  }, e.defaultVersionSetter = function (e, t) {
    if (!n.isBuffer(t) || t.length < 4) throw new Error("Set Version: Invalid Transaction");
    return t.writeUInt32LE(e, 0), t;
  }, e.defaultLocktimeSetter = function (e, t) {
    if (!n.isBuffer(t) || t.length < 4) throw new Error("Set Locktime: Invalid Transaction");
    return t.writeUInt32LE(e, t.length - 4), t;
  };
}(Zt);
const {
  Buffer: en
} = _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_0__.b;
Object.defineProperty(M, "__esModule", {
  value: !0
});
const tn = W,
  nn = X,
  rn = Y,
  sn = Zt;
M.Psbt = class {
  constructor(e) {
    this.inputs = [], this.outputs = [], this.globalMap = {
      unsignedTx: e
    };
  }
  static fromBase64(e, t) {
    const n = en.from(e, "base64");
    return this.fromBuffer(n, t);
  }
  static fromHex(e, t) {
    const n = en.from(e, "hex");
    return this.fromBuffer(n, t);
  }
  static fromBuffer(e, t) {
    const n = nn.psbtFromBuffer(e, t),
      r = new this(n.globalMap.unsignedTx);
    return Object.assign(r, n), r;
  }
  toBase64() {
    return this.toBuffer().toString("base64");
  }
  toHex() {
    return this.toBuffer().toString("hex");
  }
  toBuffer() {
    return nn.psbtToBuffer(this);
  }
  updateGlobal(e) {
    return sn.updateGlobal(e, this.globalMap), this;
  }
  updateInput(e, t) {
    const n = sn.checkForInput(this.inputs, e);
    return sn.updateInput(t, n), this;
  }
  updateOutput(e, t) {
    const n = sn.checkForOutput(this.outputs, e);
    return sn.updateOutput(t, n), this;
  }
  addUnknownKeyValToGlobal(e) {
    return sn.checkHasKey(e, this.globalMap.unknownKeyVals, sn.getEnumLength(rn.GlobalTypes)), this.globalMap.unknownKeyVals || (this.globalMap.unknownKeyVals = []), this.globalMap.unknownKeyVals.push(e), this;
  }
  addUnknownKeyValToInput(e, t) {
    const n = sn.checkForInput(this.inputs, e);
    return sn.checkHasKey(t, n.unknownKeyVals, sn.getEnumLength(rn.InputTypes)), n.unknownKeyVals || (n.unknownKeyVals = []), n.unknownKeyVals.push(t), this;
  }
  addUnknownKeyValToOutput(e, t) {
    const n = sn.checkForOutput(this.outputs, e);
    return sn.checkHasKey(t, n.unknownKeyVals, sn.getEnumLength(rn.OutputTypes)), n.unknownKeyVals || (n.unknownKeyVals = []), n.unknownKeyVals.push(t), this;
  }
  addInput(e) {
    this.globalMap.unsignedTx.addInput(e), this.inputs.push({
      unknownKeyVals: []
    });
    const t = e.unknownKeyVals || [],
      n = this.inputs.length - 1;
    if (!Array.isArray(t)) throw new Error("unknownKeyVals must be an Array");
    return t.forEach(e => this.addUnknownKeyValToInput(n, e)), sn.addInputAttributes(this.inputs, e), this;
  }
  addOutput(e) {
    this.globalMap.unsignedTx.addOutput(e), this.outputs.push({
      unknownKeyVals: []
    });
    const t = e.unknownKeyVals || [],
      n = this.outputs.length - 1;
    if (!Array.isArray(t)) throw new Error("unknownKeyVals must be an Array");
    return t.forEach(e => this.addUnknownKeyValToInput(n, e)), sn.addOutputAttributes(this.outputs, e), this;
  }
  clearFinalizedInput(e) {
    const t = sn.checkForInput(this.inputs, e);
    sn.inputCheckUncleanFinalized(e, t);
    for (const e of Object.keys(t)) ["witnessUtxo", "nonWitnessUtxo", "finalScriptSig", "finalScriptWitness", "unknownKeyVals"].includes(e) || delete t[e];
    return this;
  }
  combine(...e) {
    const t = tn.combine([this].concat(e));
    return Object.assign(this, t), this;
  }
  getTransaction() {
    return this.globalMap.unsignedTx.toBuffer();
  }
}, F.exports = M;
const on = Be,
  {
    typeforce: un
  } = _script_28a5953a_mjs__WEBPACK_IMPORTED_MODULE_2__.a;
function an(e) {
  const t = e.length;
  return _address_a3a74797_mjs__WEBPACK_IMPORTED_MODULE_1__.v.encodingLength(t) + t;
}
const cn = _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_0__.B.allocUnsafe(0),
  pn = [],
  fn = _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_0__.B.from("0000000000000000000000000000000000000000000000000000000000000000", "hex"),
  hn = _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_0__.B.from("0000000000000000000000000000000000000000000000000000000000000001", "hex"),
  ln = _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_0__.B.from("ffffffffffffffff", "hex"),
  dn = {
    script: cn,
    valueBuffer: ln
  };
class yn {
  constructor() {
    this.version = 1, this.locktime = 0, this.ins = [], this.outs = [];
  }
  static fromBuffer(e, t) {
    const n = new R(e),
      r = new yn();
    r.version = n.readInt32();
    const i = n.readUInt8(),
      s = n.readUInt8();
    let o = !1;
    i === yn.ADVANCED_TRANSACTION_MARKER && s === yn.ADVANCED_TRANSACTION_FLAG ? o = !0 : n.offset -= 2;
    const u = n.readVarInt();
    for (let e = 0; e < u; ++e) r.ins.push({
      hash: n.readSlice(32),
      index: n.readUInt32(),
      script: n.readVarSlice(),
      sequence: n.readUInt32(),
      witness: pn
    });
    const a = n.readVarInt();
    for (let e = 0; e < a; ++e) r.outs.push({
      value: n.readUInt64(),
      script: n.readVarSlice()
    });
    if (o) {
      for (let e = 0; e < u; ++e) r.ins[e].witness = n.readVector();
      if (!r.hasWitnesses()) throw new Error("Transaction has superfluous witness data");
    }
    if (r.locktime = n.readUInt32(), t) return r;
    if (n.offset !== e.length) throw new Error("Transaction has unexpected data");
    return r;
  }
  static fromHex(t) {
    return yn.fromBuffer(_index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_0__.B.from(t, "hex"), !1);
  }
  static isCoinbaseHash(e) {
    un(_script_28a5953a_mjs__WEBPACK_IMPORTED_MODULE_2__.H, e);
    for (let t = 0; t < 32; ++t) if (0 !== e[t]) return !1;
    return !0;
  }
  isCoinbase() {
    return 1 === this.ins.length && yn.isCoinbaseHash(this.ins[0].hash);
  }
  addInput(e, t, n, r) {
    return un((0,_script_28a5953a_mjs__WEBPACK_IMPORTED_MODULE_2__.t)(_script_28a5953a_mjs__WEBPACK_IMPORTED_MODULE_2__.H, _script_28a5953a_mjs__WEBPACK_IMPORTED_MODULE_2__.U, (0,_script_28a5953a_mjs__WEBPACK_IMPORTED_MODULE_2__.m)(_script_28a5953a_mjs__WEBPACK_IMPORTED_MODULE_2__.U), (0,_script_28a5953a_mjs__WEBPACK_IMPORTED_MODULE_2__.m)(_script_28a5953a_mjs__WEBPACK_IMPORTED_MODULE_2__.B)), arguments), (0,_script_28a5953a_mjs__WEBPACK_IMPORTED_MODULE_2__.N)(n) && (n = yn.DEFAULT_SEQUENCE), this.ins.push({
      hash: e,
      index: t,
      script: r || cn,
      sequence: n,
      witness: pn
    }) - 1;
  }
  addOutput(e, t) {
    return un((0,_script_28a5953a_mjs__WEBPACK_IMPORTED_MODULE_2__.t)(_script_28a5953a_mjs__WEBPACK_IMPORTED_MODULE_2__.B, _script_28a5953a_mjs__WEBPACK_IMPORTED_MODULE_2__.S), arguments), this.outs.push({
      script: e,
      value: t
    }) - 1;
  }
  hasWitnesses() {
    return this.ins.some(e => 0 !== e.witness.length);
  }
  weight() {
    return 3 * this.byteLength(!1) + this.byteLength(!0);
  }
  virtualSize() {
    return Math.ceil(this.weight() / 4);
  }
  byteLength(e = !0) {
    const t = e && this.hasWitnesses();
    return (t ? 10 : 8) + _address_a3a74797_mjs__WEBPACK_IMPORTED_MODULE_1__.v.encodingLength(this.ins.length) + _address_a3a74797_mjs__WEBPACK_IMPORTED_MODULE_1__.v.encodingLength(this.outs.length) + this.ins.reduce((e, t) => e + 40 + an(t.script), 0) + this.outs.reduce((e, t) => e + 8 + an(t.script), 0) + (t ? this.ins.reduce((e, t) => e + function (e) {
      const t = e.length;
      return _address_a3a74797_mjs__WEBPACK_IMPORTED_MODULE_1__.v.encodingLength(t) + e.reduce((e, t) => e + an(t), 0);
    }(t.witness), 0) : 0);
  }
  clone() {
    const e = new yn();
    return e.version = this.version, e.locktime = this.locktime, e.ins = this.ins.map(e => ({
      hash: e.hash,
      index: e.index,
      script: e.script,
      sequence: e.sequence,
      witness: e.witness
    })), e.outs = this.outs.map(e => ({
      script: e.script,
      value: e.value
    })), e;
  }
  hashForSignature(t, n, r) {
    if (un((0,_script_28a5953a_mjs__WEBPACK_IMPORTED_MODULE_2__.t)(_script_28a5953a_mjs__WEBPACK_IMPORTED_MODULE_2__.U, _script_28a5953a_mjs__WEBPACK_IMPORTED_MODULE_2__.B, _script_28a5953a_mjs__WEBPACK_IMPORTED_MODULE_2__.b), arguments), t >= this.ins.length) return hn;
    const i = (0,_script_28a5953a_mjs__WEBPACK_IMPORTED_MODULE_2__.c)((0,_script_28a5953a_mjs__WEBPACK_IMPORTED_MODULE_2__.d)(n).filter(e => e !== _ops_47b8fd99_mjs__WEBPACK_IMPORTED_MODULE_5__.OPS.OP_CODESEPARATOR)),
      s = this.clone();
    if ((31 & r) === yn.SIGHASH_NONE) s.outs = [], s.ins.forEach((e, n) => {
      n !== t && (e.sequence = 0);
    });else if ((31 & r) === yn.SIGHASH_SINGLE) {
      if (t >= this.outs.length) return hn;
      s.outs.length = t + 1;
      for (let e = 0; e < t; e++) s.outs[e] = dn;
      s.ins.forEach((e, n) => {
        n !== t && (e.sequence = 0);
      });
    }
    r & yn.SIGHASH_ANYONECANPAY ? (s.ins = [s.ins[t]], s.ins[0].script = i) : (s.ins.forEach(e => {
      e.script = cn;
    }), s.ins[t].script = i);
    const o = _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_0__.B.allocUnsafe(s.byteLength(!1) + 4);
    return o.writeInt32LE(r, o.length - 4), s.__toBuffer(o, 0, !1), (0,_crypto_2c4d5428_mjs__WEBPACK_IMPORTED_MODULE_3__.hash256)(o);
  }
  hashForWitnessV1(t, n, r, i, s, o) {
    if (un((0,_script_28a5953a_mjs__WEBPACK_IMPORTED_MODULE_2__.t)(_script_28a5953a_mjs__WEBPACK_IMPORTED_MODULE_2__.U, un.arrayOf(_script_28a5953a_mjs__WEBPACK_IMPORTED_MODULE_2__.B), un.arrayOf(_script_28a5953a_mjs__WEBPACK_IMPORTED_MODULE_2__.S), _script_28a5953a_mjs__WEBPACK_IMPORTED_MODULE_2__.U), arguments), r.length !== this.ins.length || n.length !== this.ins.length) throw new Error("Must supply prevout script and value for all inputs");
    const u = i === yn.SIGHASH_DEFAULT ? yn.SIGHASH_ALL : i & yn.SIGHASH_OUTPUT_MASK,
      a = (i & yn.SIGHASH_INPUT_MASK) === yn.SIGHASH_ANYONECANPAY,
      h = u === yn.SIGHASH_NONE,
      l = u === yn.SIGHASH_SINGLE;
    let d = cn,
      y = cn,
      E = cn,
      _ = cn,
      g = cn;
    if (!a) {
      let e = B.withCapacity(36 * this.ins.length);
      this.ins.forEach(t => {
        e.writeSlice(t.hash), e.writeUInt32(t.index);
      }), d = (0,_crypto_2c4d5428_mjs__WEBPACK_IMPORTED_MODULE_3__.sha256)(e.end()), e = B.withCapacity(8 * this.ins.length), r.forEach(t => e.writeUInt64(t)), y = (0,_crypto_2c4d5428_mjs__WEBPACK_IMPORTED_MODULE_3__.sha256)(e.end()), e = B.withCapacity(n.map(an).reduce((e, t) => e + t)), n.forEach(t => e.writeVarSlice(t)), E = (0,_crypto_2c4d5428_mjs__WEBPACK_IMPORTED_MODULE_3__.sha256)(e.end()), e = B.withCapacity(4 * this.ins.length), this.ins.forEach(t => e.writeUInt32(t.sequence)), _ = (0,_crypto_2c4d5428_mjs__WEBPACK_IMPORTED_MODULE_3__.sha256)(e.end());
    }
    if (h || l) {
      if (l && t < this.outs.length) {
        const e = this.outs[t],
          n = B.withCapacity(8 + an(e.script));
        n.writeUInt64(e.value), n.writeVarSlice(e.script), g = (0,_crypto_2c4d5428_mjs__WEBPACK_IMPORTED_MODULE_3__.sha256)(n.end());
      }
    } else {
      const e = this.outs.map(e => 8 + an(e.script)).reduce((e, t) => e + t),
        t = B.withCapacity(e);
      this.outs.forEach(e => {
        t.writeUInt64(e.value), t.writeVarSlice(e.script);
      }), g = (0,_crypto_2c4d5428_mjs__WEBPACK_IMPORTED_MODULE_3__.sha256)(t.end());
    }
    const w = (s ? 2 : 0) + (o ? 1 : 0),
      I = 174 - (a ? 49 : 0) - (h ? 32 : 0) + (o ? 32 : 0) + (s ? 37 : 0),
      T = B.withCapacity(I);
    if (T.writeUInt8(i), T.writeInt32(this.version), T.writeUInt32(this.locktime), T.writeSlice(d), T.writeSlice(y), T.writeSlice(E), T.writeSlice(_), h || l || T.writeSlice(g), T.writeUInt8(w), a) {
      const e = this.ins[t];
      T.writeSlice(e.hash), T.writeUInt32(e.index), T.writeUInt64(r[t]), T.writeVarSlice(n[t]), T.writeUInt32(e.sequence);
    } else T.writeUInt32(t);
    if (o) {
      const e = B.withCapacity(an(o));
      e.writeVarSlice(o), T.writeSlice((0,_crypto_2c4d5428_mjs__WEBPACK_IMPORTED_MODULE_3__.sha256)(e.end()));
    }
    return l && T.writeSlice(g), s && (T.writeSlice(s), T.writeUInt8(0), T.writeUInt32(4294967295)), (0,_crypto_2c4d5428_mjs__WEBPACK_IMPORTED_MODULE_3__.taggedHash)("TapSighash", _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_0__.B.concat([_index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_0__.B.of(0), T.end()]));
  }
  hashForWitnessV0(t, n, r, i) {
    un((0,_script_28a5953a_mjs__WEBPACK_IMPORTED_MODULE_2__.t)(_script_28a5953a_mjs__WEBPACK_IMPORTED_MODULE_2__.U, _script_28a5953a_mjs__WEBPACK_IMPORTED_MODULE_2__.B, _script_28a5953a_mjs__WEBPACK_IMPORTED_MODULE_2__.S, _script_28a5953a_mjs__WEBPACK_IMPORTED_MODULE_2__.U), arguments);
    let s,
      o = _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_0__.B.from([]),
      u = fn,
      a = fn,
      h = fn;
    if (i & yn.SIGHASH_ANYONECANPAY || (o = _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_0__.B.allocUnsafe(36 * this.ins.length), s = new B(o, 0), this.ins.forEach(e => {
      s.writeSlice(e.hash), s.writeUInt32(e.index);
    }), a = (0,_crypto_2c4d5428_mjs__WEBPACK_IMPORTED_MODULE_3__.hash256)(o)), i & yn.SIGHASH_ANYONECANPAY || (31 & i) === yn.SIGHASH_SINGLE || (31 & i) === yn.SIGHASH_NONE || (o = _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_0__.B.allocUnsafe(4 * this.ins.length), s = new B(o, 0), this.ins.forEach(e => {
      s.writeUInt32(e.sequence);
    }), h = (0,_crypto_2c4d5428_mjs__WEBPACK_IMPORTED_MODULE_3__.hash256)(o)), (31 & i) !== yn.SIGHASH_SINGLE && (31 & i) !== yn.SIGHASH_NONE) {
      const t = this.outs.reduce((e, t) => e + 8 + an(t.script), 0);
      o = _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_0__.B.allocUnsafe(t), s = new B(o, 0), this.outs.forEach(e => {
        s.writeUInt64(e.value), s.writeVarSlice(e.script);
      }), u = (0,_crypto_2c4d5428_mjs__WEBPACK_IMPORTED_MODULE_3__.hash256)(o);
    } else if ((31 & i) === yn.SIGHASH_SINGLE && t < this.outs.length) {
      const n = this.outs[t];
      o = _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_0__.B.allocUnsafe(8 + an(n.script)), s = new B(o, 0), s.writeUInt64(n.value), s.writeVarSlice(n.script), u = (0,_crypto_2c4d5428_mjs__WEBPACK_IMPORTED_MODULE_3__.hash256)(o);
    }
    o = _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_0__.B.allocUnsafe(156 + an(n)), s = new B(o, 0);
    const l = this.ins[t];
    return s.writeInt32(this.version), s.writeSlice(a), s.writeSlice(h), s.writeSlice(l.hash), s.writeUInt32(l.index), s.writeVarSlice(n), s.writeUInt64(r), s.writeUInt32(l.sequence), s.writeSlice(u), s.writeUInt32(this.locktime), s.writeUInt32(i), (0,_crypto_2c4d5428_mjs__WEBPACK_IMPORTED_MODULE_3__.hash256)(o);
  }
  getHash(t) {
    return t && this.isCoinbase() ? _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_0__.B.alloc(32, 0) : (0,_crypto_2c4d5428_mjs__WEBPACK_IMPORTED_MODULE_3__.hash256)(this.__toBuffer(void 0, void 0, t));
  }
  getId() {
    return U(this.getHash(!1)).toString("hex");
  }
  toBuffer(e, t) {
    return this.__toBuffer(e, t, !0);
  }
  toHex() {
    return this.toBuffer(void 0, void 0).toString("hex");
  }
  setInputScript(e, t) {
    un((0,_script_28a5953a_mjs__WEBPACK_IMPORTED_MODULE_2__.t)(_script_28a5953a_mjs__WEBPACK_IMPORTED_MODULE_2__.b, _script_28a5953a_mjs__WEBPACK_IMPORTED_MODULE_2__.B), arguments), this.ins[e].script = t;
  }
  setWitness(e, t) {
    un((0,_script_28a5953a_mjs__WEBPACK_IMPORTED_MODULE_2__.t)(_script_28a5953a_mjs__WEBPACK_IMPORTED_MODULE_2__.b, [_script_28a5953a_mjs__WEBPACK_IMPORTED_MODULE_2__.B]), arguments), this.ins[e].witness = t;
  }
  __toBuffer(t, n, r = !1) {
    t || (t = _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_0__.B.allocUnsafe(this.byteLength(r)));
    const i = new B(t, n || 0);
    i.writeInt32(this.version);
    const s = r && this.hasWitnesses();
    return s && (i.writeUInt8(yn.ADVANCED_TRANSACTION_MARKER), i.writeUInt8(yn.ADVANCED_TRANSACTION_FLAG)), i.writeVarInt(this.ins.length), this.ins.forEach(e => {
      i.writeSlice(e.hash), i.writeUInt32(e.index), i.writeVarSlice(e.script), i.writeUInt32(e.sequence);
    }), i.writeVarInt(this.outs.length), this.outs.forEach(e => {
      void 0 !== e.value ? i.writeUInt64(e.value) : i.writeSlice(e.valueBuffer), i.writeVarSlice(e.script);
    }), s && this.ins.forEach(e => {
      i.writeVector(e.witness);
    }), i.writeUInt32(this.locktime), void 0 !== n ? t.slice(n, i.offset) : t;
  }
}
yn.DEFAULT_SEQUENCE = 4294967295, yn.SIGHASH_DEFAULT = 0, yn.SIGHASH_ALL = 1, yn.SIGHASH_NONE = 2, yn.SIGHASH_SINGLE = 3, yn.SIGHASH_ANYONECANPAY = 128, yn.SIGHASH_OUTPUT_MASK = 3, yn.SIGHASH_INPUT_MASK = 128, yn.ADVANCED_TRANSACTION_MARKER = 0, yn.ADVANCED_TRANSACTION_FLAG = 1;
const Sn = {
  network: _networks_0de0aba6_mjs__WEBPACK_IMPORTED_MODULE_4__.b,
  maximumFeeRate: 5e3
};
class En {
  static fromBase64(t, n = {}) {
    const r = _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_0__.B.from(t, "base64");
    return this.fromBuffer(r, n);
  }
  static fromHex(t, n = {}) {
    const r = _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_0__.B.from(t, "hex");
    return this.fromBuffer(r, n);
  }
  static fromBuffer(e, t = {}) {
    const n = G.Psbt.fromBuffer(e, _n),
      r = new En(t, n);
    var i, s;
    return i = r.__CACHE.__TX, s = r.__CACHE, i.ins.forEach(e => {
      Hn(s, e);
    }), r;
  }
  constructor(e = {}, t = new G.Psbt(new gn())) {
    this.data = t, this.opts = Object.assign({}, Sn, e), this.__CACHE = {
      __NON_WITNESS_UTXO_TX_CACHE: [],
      __NON_WITNESS_UTXO_BUF_CACHE: [],
      __TX_IN_CACHE: {},
      __TX: this.data.globalMap.unsignedTx.tx,
      __UNSAFE_SIGN_NONSEGWIT: !1
    }, 0 === this.data.inputs.length && this.setVersion(2);
    const n = (e, t, n, r) => Object.defineProperty(e, t, {
      enumerable: n,
      writable: r
    });
    n(this, "__CACHE", !1, !0), n(this, "opts", !1, !0);
  }
  get inputCount() {
    return this.data.inputs.length;
  }
  get version() {
    return this.__CACHE.__TX.version;
  }
  set version(e) {
    this.setVersion(e);
  }
  get locktime() {
    return this.__CACHE.__TX.locktime;
  }
  set locktime(e) {
    this.setLocktime(e);
  }
  get txInputs() {
    return this.__CACHE.__TX.ins.map(e => ({
      hash: H(e.hash),
      index: e.index,
      sequence: e.sequence
    }));
  }
  get txOutputs() {
    return this.__CACHE.__TX.outs.map(e => {
      let t;
      try {
        t = (0,_address_a3a74797_mjs__WEBPACK_IMPORTED_MODULE_1__.f)(e.script, this.opts.network);
      } catch (e) {}
      return {
        script: H(e.script),
        value: e.value,
        address: t
      };
    });
  }
  combine(...e) {
    return this.data.combine(...e.map(e => e.data)), this;
  }
  clone() {
    const e = En.fromBuffer(this.data.toBuffer());
    return e.opts = JSON.parse(JSON.stringify(this.opts)), e;
  }
  setMaximumFeeRate(e) {
    Cn(e), this.opts.maximumFeeRate = e;
  }
  setVersion(e) {
    Cn(e), xn(this.data.inputs, "setVersion");
    const t = this.__CACHE;
    return t.__TX.version = e, t.__EXTRACTED_TX = void 0, this;
  }
  setLocktime(e) {
    Cn(e), xn(this.data.inputs, "setLocktime");
    const t = this.__CACHE;
    return t.__TX.locktime = e, t.__EXTRACTED_TX = void 0, this;
  }
  setInputSequence(e, t) {
    Cn(t), xn(this.data.inputs, "setInputSequence");
    const n = this.__CACHE;
    if (n.__TX.ins.length <= e) throw new Error("Input index too high");
    return n.__TX.ins[e].sequence = t, n.__EXTRACTED_TX = void 0, this;
  }
  addInputs(e) {
    return e.forEach(e => this.addInput(e)), this;
  }
  addInput(e) {
    if (arguments.length > 1 || !e || void 0 === e.hash || void 0 === e.index) throw new Error("Invalid arguments for Psbt.addInput. Requires single object with at least [hash] and [index]");
    xn(this.data.inputs, "addInput"), e.witnessScript && Jn(e.witnessScript);
    const t = this.__CACHE;
    this.data.addInput(e);
    Hn(t, t.__TX.ins[t.__TX.ins.length - 1]);
    const n = this.data.inputs.length - 1,
      r = this.data.inputs[n];
    return r.nonWitnessUtxo && Xn(this.__CACHE, r, n), t.__FEE = void 0, t.__FEE_RATE = void 0, t.__EXTRACTED_TX = void 0, this;
  }
  addOutputs(e) {
    return e.forEach(e => this.addOutput(e)), this;
  }
  addOutput(e) {
    if (arguments.length > 1 || !e || void 0 === e.value || void 0 === e.address && void 0 === e.script) throw new Error("Invalid arguments for Psbt.addOutput. Requires single object with at least [script or address] and [value]");
    xn(this.data.inputs, "addOutput");
    const {
      address: t
    } = e;
    if ("string" == typeof t) {
      const {
          network: n
        } = this.opts,
        r = (0,_address_a3a74797_mjs__WEBPACK_IMPORTED_MODULE_1__.t)(t, n);
      e = Object.assign(e, {
        script: r
      });
    }
    const n = this.__CACHE;
    return this.data.addOutput(e), n.__FEE = void 0, n.__FEE_RATE = void 0, n.__EXTRACTED_TX = void 0, this;
  }
  extractTransaction(e) {
    if (!this.data.inputs.every(Tn)) throw new Error("Not finalized");
    const t = this.__CACHE;
    if (e || function (e, t, n) {
      const r = t.__FEE_RATE || e.getFeeRate(),
        i = t.__EXTRACTED_TX.virtualSize(),
        s = r * i;
      if (r >= n.maximumFeeRate) throw new Error(`Warning: You are paying around ${(s / 1e8).toFixed(8)} in fees, which is ${r} satoshi per byte for a transaction with a VSize of ${i} bytes (segwit counted as 0.25 byte per byte). Use setMaximumFeeRate method to raise your threshold, or pass true to the first arg of extractTransaction.`);
    }(this, t, this.opts), t.__EXTRACTED_TX) return t.__EXTRACTED_TX;
    const n = t.__TX.clone();
    return jn(this.data.inputs, n, t, !0), n;
  }
  getFeeRate() {
    return Vn("__FEE_RATE", "fee rate", this.data.inputs, this.__CACHE);
  }
  getFee() {
    return Vn("__FEE", "fee", this.data.inputs, this.__CACHE);
  }
  finalizeAllInputs() {
    return Zt.checkForInput(this.data.inputs, 0), er(this.data.inputs.length).forEach(e => this.finalizeInput(e)), this;
  }
  finalizeInput(e, t = Kn) {
    const n = Zt.checkForInput(this.data.inputs, e),
      {
        script: r,
        isP2SH: i,
        isP2WSH: s,
        isSegwit: o
      } = function (e, t, n) {
        const r = n.__TX,
          i = {
            script: null,
            isSegwit: !1,
            isP2SH: !1,
            isP2WSH: !1
          };
        if (i.isP2SH = !!t.redeemScript, i.isP2WSH = !!t.witnessScript, t.witnessScript) i.script = t.witnessScript;else if (t.redeemScript) i.script = t.redeemScript;else if (t.nonWitnessUtxo) {
          const s = qn(n, t, e),
            o = r.ins[e].index;
          i.script = s.outs[o].script;
        } else t.witnessUtxo && (i.script = t.witnessUtxo.script);
        (t.witnessScript || vn(i.script)) && (i.isSegwit = !0);
        return i;
      }(e, n, this.__CACHE);
    if (!r) throw new Error(`No script found for input #${e}`);
    !function (e) {
      if (!e.sighashType || !e.partialSig) return;
      const {
        partialSig: t,
        sighashType: n
      } = e;
      t.forEach(e => {
        const {
          hashType: t
        } = _script_28a5953a_mjs__WEBPACK_IMPORTED_MODULE_2__.s.decode(e.signature);
        if (n !== t) throw new Error("Signature sighash does not match input sighash type");
      });
    }(n);
    const {
      finalScriptSig: u,
      finalScriptWitness: a
    } = t(e, n, r, o, i, s);
    if (u && this.data.updateInput(e, {
      finalScriptSig: u
    }), a && this.data.updateInput(e, {
      finalScriptWitness: a
    }), !u && !a) throw new Error(`Unknown error finalizing input #${e}`);
    return this.data.clearFinalizedInput(e), this;
  }
  getInputType(t) {
    const n = Zt.checkForInput(this.data.inputs, t),
      r = zn(Yn(t, n, this.__CACHE), t, "input", n.redeemScript || function (t) {
        if (!t) return;
        const n = (0,_script_28a5953a_mjs__WEBPACK_IMPORTED_MODULE_2__.d)(t);
        if (!n) return;
        const r = n[n.length - 1];
        if (!_index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_0__.B.isBuffer(r) || $n(r) || (i = r, (0,_script_28a5953a_mjs__WEBPACK_IMPORTED_MODULE_2__.i)(i))) return;
        var i;
        if (!(0,_script_28a5953a_mjs__WEBPACK_IMPORTED_MODULE_2__.d)(r)) return;
        return r;
      }(n.finalScriptSig), n.witnessScript || function (e) {
        if (!e) return;
        const t = Mn(e),
          n = t[t.length - 1];
        if ($n(n)) return;
        if (!(0,_script_28a5953a_mjs__WEBPACK_IMPORTED_MODULE_2__.d)(n)) return;
        return n;
      }(n.finalScriptWitness));
    return ("raw" === r.type ? "" : r.type + "-") + Zn(r.meaningfulScript);
  }
  inputHasPubkey(e, t) {
    return function (e, t, n, r) {
      const i = Yn(n, t, r),
        {
          meaningfulScript: s
        } = zn(i, n, "input", t.redeemScript, t.witnessScript);
      return Qn(e, s);
    }(t, Zt.checkForInput(this.data.inputs, e), e, this.__CACHE);
  }
  inputHasHDKey(e, t) {
    const n = Zt.checkForInput(this.data.inputs, e),
      r = Pn(t);
    return !!n.bip32Derivation && n.bip32Derivation.some(r);
  }
  outputHasPubkey(e, t) {
    return function (e, t, n, r) {
      const i = r.__TX.outs[n].script,
        {
          meaningfulScript: s
        } = zn(i, n, "output", t.redeemScript, t.witnessScript);
      return Qn(e, s);
    }(t, Zt.checkForOutput(this.data.outputs, e), e, this.__CACHE);
  }
  outputHasHDKey(e, t) {
    const n = Zt.checkForOutput(this.data.outputs, e),
      r = Pn(t);
    return !!n.bip32Derivation && n.bip32Derivation.some(r);
  }
  validateSignaturesOfAllInputs(e) {
    Zt.checkForInput(this.data.inputs, 0);
    return er(this.data.inputs.length).map(t => this.validateSignaturesOfInput(t, e)).reduce((e, t) => !0 === t && e, !0);
  }
  validateSignaturesOfInput(e, t, n) {
    const r = this.data.inputs[e],
      i = (r || {}).partialSig;
    if (!r || !i || i.length < 1) throw new Error("No signatures to validate");
    if ("function" != typeof t) throw new Error("Need validator function to validate signatures");
    const s = n ? i.filter(e => e.pubkey.equals(n)) : i;
    if (s.length < 1) throw new Error("No signatures for this pubkey");
    const o = [];
    let u, a, c;
    for (const n of s) {
      const i = _script_28a5953a_mjs__WEBPACK_IMPORTED_MODULE_2__.s.decode(n.signature),
        {
          hash: s,
          script: p
        } = c !== i.hashType ? Gn(e, Object.assign({}, r, {
          sighashType: i.hashType
        }), this.__CACHE, !0) : {
          hash: u,
          script: a
        };
      c = i.hashType, u = s, a = p, Un(n.pubkey, p, "verify"), o.push(t(n.pubkey, s, i.signature));
    }
    return o.every(e => !0 === e);
  }
  signAllInputsHD(e, t = [yn.SIGHASH_ALL]) {
    if (!e || !e.publicKey || !e.fingerprint) throw new Error("Need HDSigner to sign input");
    const n = [];
    for (const r of er(this.data.inputs.length)) try {
      this.signInputHD(r, e, t), n.push(!0);
    } catch (e) {
      n.push(!1);
    }
    if (n.every(e => !1 === e)) throw new Error("No inputs were signed");
    return this;
  }
  signAllInputsHDAsync(e, t = [yn.SIGHASH_ALL]) {
    return new Promise((n, r) => {
      if (!e || !e.publicKey || !e.fingerprint) return r(new Error("Need HDSigner to sign input"));
      const i = [],
        s = [];
      for (const n of er(this.data.inputs.length)) s.push(this.signInputHDAsync(n, e, t).then(() => {
        i.push(!0);
      }, () => {
        i.push(!1);
      }));
      return Promise.all(s).then(() => {
        if (i.every(e => !1 === e)) return r(new Error("No inputs were signed"));
        n();
      });
    });
  }
  signInputHD(e, t, n = [yn.SIGHASH_ALL]) {
    if (!t || !t.publicKey || !t.fingerprint) throw new Error("Need HDSigner to sign input");
    return Fn(e, this.data.inputs, t).forEach(t => this.signInput(e, t, n)), this;
  }
  signInputHDAsync(e, t, n = [yn.SIGHASH_ALL]) {
    return new Promise((r, i) => {
      if (!t || !t.publicKey || !t.fingerprint) return i(new Error("Need HDSigner to sign input"));
      const s = Fn(e, this.data.inputs, t).map(t => this.signInputAsync(e, t, n));
      return Promise.all(s).then(() => {
        r();
      }).catch(i);
    });
  }
  signAllInputs(e, t = [yn.SIGHASH_ALL]) {
    if (!e || !e.publicKey) throw new Error("Need Signer to sign input");
    const n = [];
    for (const r of er(this.data.inputs.length)) try {
      this.signInput(r, e, t), n.push(!0);
    } catch (e) {
      n.push(!1);
    }
    if (n.every(e => !1 === e)) throw new Error("No inputs were signed");
    return this;
  }
  signAllInputsAsync(e, t = [yn.SIGHASH_ALL]) {
    return new Promise((n, r) => {
      if (!e || !e.publicKey) return r(new Error("Need Signer to sign input"));
      const i = [],
        s = [];
      for (const [n] of this.data.inputs.entries()) s.push(this.signInputAsync(n, e, t).then(() => {
        i.push(!0);
      }, () => {
        i.push(!1);
      }));
      return Promise.all(s).then(() => {
        if (i.every(e => !1 === e)) return r(new Error("No inputs were signed"));
        n();
      });
    });
  }
  signInput(t, n, r = [yn.SIGHASH_ALL]) {
    if (!n || !n.publicKey) throw new Error("Need Signer to sign input");
    const {
        hash: i,
        sighashType: s
      } = Dn(this.data.inputs, t, _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_0__.B.from(n.publicKey), this.__CACHE, r),
      o = [{
        pubkey: _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_0__.B.from(n.publicKey),
        signature: _script_28a5953a_mjs__WEBPACK_IMPORTED_MODULE_2__.s.encode(_index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_0__.B.from(n.sign(i)), s)
      }];
    return this.data.updateInput(t, {
      partialSig: o
    }), this;
  }
  signInputAsync(e, t, n = [yn.SIGHASH_ALL]) {
    return Promise.resolve().then(() => {
      if (!t || !t.publicKey) throw new Error("Need Signer to sign input");
      const {
        hash: r,
        sighashType: i
      } = Dn(this.data.inputs, e, t.publicKey, this.__CACHE, n);
      return Promise.resolve(t.sign(r)).then(n => {
        const r = [{
          pubkey: t.publicKey,
          signature: _script_28a5953a_mjs__WEBPACK_IMPORTED_MODULE_2__.s.encode(n, i)
        }];
        this.data.updateInput(e, {
          partialSig: r
        });
      });
    });
  }
  toBuffer() {
    return wn(this.__CACHE), this.data.toBuffer();
  }
  toHex() {
    return wn(this.__CACHE), this.data.toHex();
  }
  toBase64() {
    return wn(this.__CACHE), this.data.toBase64();
  }
  updateGlobal(e) {
    return this.data.updateGlobal(e), this;
  }
  updateInput(e, t) {
    return t.witnessScript && Jn(t.witnessScript), this.data.updateInput(e, t), t.nonWitnessUtxo && Xn(this.__CACHE, this.data.inputs[e], e), this;
  }
  updateOutput(e, t) {
    return this.data.updateOutput(e, t), this;
  }
  addUnknownKeyValToGlobal(e) {
    return this.data.addUnknownKeyValToGlobal(e), this;
  }
  addUnknownKeyValToInput(e, t) {
    return this.data.addUnknownKeyValToInput(e, t), this;
  }
  addUnknownKeyValToOutput(e, t) {
    return this.data.addUnknownKeyValToOutput(e, t), this;
  }
  clearFinalizedInput(e) {
    return this.data.clearFinalizedInput(e), this;
  }
}
const _n = e => new gn(e);
class gn {
  constructor(t = _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_0__.B.from([2, 0, 0, 0, 0, 0, 0, 0, 0, 0])) {
    this.tx = yn.fromBuffer(t), function (e) {
      if (!e.ins.every(e => e.script && 0 === e.script.length && e.witness && 0 === e.witness.length)) throw new Error("Format Error: Transaction ScriptSigs are not empty");
    }(this.tx), Object.defineProperty(this, "tx", {
      enumerable: !1,
      writable: !0
    });
  }
  getInputOutputCounts() {
    return {
      inputCount: this.tx.ins.length,
      outputCount: this.tx.outs.length
    };
  }
  addInput(t) {
    if (void 0 === t.hash || void 0 === t.index || !_index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_0__.B.isBuffer(t.hash) && "string" != typeof t.hash || "number" != typeof t.index) throw new Error("Error adding input.");
    const n = "string" == typeof t.hash ? U(_index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_0__.B.from(t.hash, "hex")) : t.hash;
    this.tx.addInput(n, t.index, t.sequence);
  }
  addOutput(t) {
    if (void 0 === t.script || void 0 === t.value || !_index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_0__.B.isBuffer(t.script) || "number" != typeof t.value) throw new Error("Error adding output.");
    this.tx.addOutput(t.script, t.value);
  }
  toBuffer() {
    return this.tx.toBuffer();
  }
}
function wn(e) {
  if (!1 !== e.__UNSAFE_SIGN_NONSEGWIT) throw new Error("Not BIP174 compliant, can not export");
}
function In(e, t, n) {
  if (!t) return !1;
  let r;
  if (r = n ? n.map(e => {
    const n = function (e) {
      if (65 === e.length) {
        const t = 1 & e[64],
          n = e.slice(0, 33);
        return n[0] = 2 | t, n;
      }
      return e.slice();
    }(e);
    return t.find(e => e.pubkey.equals(n));
  }).filter(e => !!e) : t, r.length > e) throw new Error("Too many signatures");
  return r.length === e;
}
function Tn(e) {
  return !!e.finalScriptSig || !!e.finalScriptWitness;
}
function kn(e) {
  return t => {
    try {
      return e({
        output: t
      }), !0;
    } catch (e) {
      return !1;
    }
  };
}
const bn = kn(_p2pk_9b07c6f0_mjs__WEBPACK_IMPORTED_MODULE_6__.p),
  An = kn(_p2pk_9b07c6f0_mjs__WEBPACK_IMPORTED_MODULE_6__.a),
  mn = kn(_address_a3a74797_mjs__WEBPACK_IMPORTED_MODULE_1__.a),
  vn = kn(_address_a3a74797_mjs__WEBPACK_IMPORTED_MODULE_1__.c),
  Nn = kn(_address_a3a74797_mjs__WEBPACK_IMPORTED_MODULE_1__.d),
  On = kn(_address_a3a74797_mjs__WEBPACK_IMPORTED_MODULE_1__.b);
function Pn(e) {
  return t => !!t.masterFingerprint.equals(e.fingerprint) && !!e.derivePath(t.path).publicKey.equals(t.pubkey);
}
function Cn(e) {
  if ("number" != typeof e || e !== Math.floor(e) || e > 4294967295 || e < 0) throw new Error("Invalid 32 bit integer");
}
function xn(t, n) {
  t.forEach(t => {
    let r = !1,
      i = [];
    if (0 === (t.partialSig || []).length) {
      if (!t.finalScriptSig && !t.finalScriptWitness) return;
      i = function (t) {
        const n = t.finalScriptSig && (0,_script_28a5953a_mjs__WEBPACK_IMPORTED_MODULE_2__.d)(t.finalScriptSig) || [],
          r = t.finalScriptWitness && (0,_script_28a5953a_mjs__WEBPACK_IMPORTED_MODULE_2__.d)(t.finalScriptWitness) || [];
        return n.concat(r).filter(t => _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_0__.B.isBuffer(t) && (0,_script_28a5953a_mjs__WEBPACK_IMPORTED_MODULE_2__.i)(t)).map(e => ({
          signature: e
        }));
      }(t);
    } else i = t.partialSig;
    if (i.forEach(e => {
      const {
          hashType: t
        } = _script_28a5953a_mjs__WEBPACK_IMPORTED_MODULE_2__.s.decode(e.signature),
        i = [];
      t & yn.SIGHASH_ANYONECANPAY && i.push("addInput");
      switch (31 & t) {
        case yn.SIGHASH_ALL:
          break;
        case yn.SIGHASH_SINGLE:
        case yn.SIGHASH_NONE:
          i.push("addOutput"), i.push("setInputSequence");
      }
      -1 === i.indexOf(n) && (r = !0);
    }), r) throw new Error("Can not modify transaction, signatures exist.");
  });
}
function Un(e, t, n) {
  if (!Qn(e, t)) throw new Error(`Can not ${n} for this input with the key ${e.toString("hex")}`);
}
function Hn(t, n) {
  const r = U(_index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_0__.B.from(n.hash)).toString("hex") + ":" + n.index;
  if (t.__TX_IN_CACHE[r]) throw new Error("Duplicate input detected.");
  t.__TX_IN_CACHE[r] = 1;
}
function Bn(e, t) {
  return (n, r, i, s) => {
    const o = e({
      redeem: {
        output: i
      }
    }).output;
    if (!r.equals(o)) throw new Error(`${t} for ${s} #${n} doesn't match the scriptPubKey in the prevout`);
  };
}
const Rn = Bn(_address_a3a74797_mjs__WEBPACK_IMPORTED_MODULE_1__.b, "Redeem script"),
  Ln = Bn(_address_a3a74797_mjs__WEBPACK_IMPORTED_MODULE_1__.d, "Witness script");
function Vn(e, t, n, r) {
  if (!n.every(Tn)) throw new Error(`PSBT must be finalized to calculate ${t}`);
  if ("__FEE_RATE" === e && r.__FEE_RATE) return r.__FEE_RATE;
  if ("__FEE" === e && r.__FEE) return r.__FEE;
  let i,
    s = !0;
  return r.__EXTRACTED_TX ? (i = r.__EXTRACTED_TX, s = !1) : i = r.__TX.clone(), jn(n, i, r, s), "__FEE_RATE" === e ? r.__FEE_RATE : "__FEE" === e ? r.__FEE : void 0;
}
function Kn(e, t, n, r, i, c) {
  const p = Zn(n);
  if (!function (e, t, n) {
    switch (n) {
      case "pubkey":
      case "pubkeyhash":
      case "witnesspubkeyhash":
        return In(1, e.partialSig);
      case "multisig":
        const n = (0,_p2pk_9b07c6f0_mjs__WEBPACK_IMPORTED_MODULE_6__.p)({
          output: t
        });
        return In(n.m, e.partialSig, n.pubkeys);
      default:
        return !1;
    }
  }(t, n, p)) throw new Error(`Can not finalize input #${e}`);
  return function (e, t, n, r, i, c) {
    let p, f;
    const h = function (e, t, n) {
        let r;
        switch (t) {
          case "multisig":
            const t = function (e, t) {
              const n = (0,_p2pk_9b07c6f0_mjs__WEBPACK_IMPORTED_MODULE_6__.p)({
                output: e
              });
              return n.pubkeys.map(e => (t.filter(t => t.pubkey.equals(e))[0] || {}).signature).filter(e => !!e);
            }(e, n);
            r = (0,_p2pk_9b07c6f0_mjs__WEBPACK_IMPORTED_MODULE_6__.p)({
              output: e,
              signatures: t
            });
            break;
          case "pubkey":
            r = (0,_p2pk_9b07c6f0_mjs__WEBPACK_IMPORTED_MODULE_6__.a)({
              output: e,
              signature: n[0].signature
            });
            break;
          case "pubkeyhash":
            r = (0,_address_a3a74797_mjs__WEBPACK_IMPORTED_MODULE_1__.a)({
              output: e,
              pubkey: n[0].pubkey,
              signature: n[0].signature
            });
            break;
          case "witnesspubkeyhash":
            r = (0,_address_a3a74797_mjs__WEBPACK_IMPORTED_MODULE_1__.c)({
              output: e,
              pubkey: n[0].pubkey,
              signature: n[0].signature
            });
        }
        return r;
      }(e, t, n),
      l = c ? (0,_address_a3a74797_mjs__WEBPACK_IMPORTED_MODULE_1__.d)({
        redeem: h
      }) : null,
      d = i ? (0,_address_a3a74797_mjs__WEBPACK_IMPORTED_MODULE_1__.b)({
        redeem: l || h
      }) : null;
    r ? (f = Wn(l ? l.witness : h.witness), d && (p = d.input)) : p = d ? d.input : h.input;
    return {
      finalScriptSig: p,
      finalScriptWitness: f
    };
  }(n, p, t.partialSig, r, i, c);
}
function Dn(e, t, n, r, i) {
  const s = Zt.checkForInput(e, t),
    {
      hash: o,
      sighashType: u,
      script: a
    } = Gn(t, s, r, !1, i);
  return Un(n, a, "sign"), {
    hash: o,
    sighashType: u
  };
}
function Gn(e, t, n, r, i) {
  const s = n.__TX,
    o = t.sighashType || yn.SIGHASH_ALL;
  if (i && i.indexOf(o) < 0) {
    const e = function (e) {
      let t = e & yn.SIGHASH_ANYONECANPAY ? "SIGHASH_ANYONECANPAY | " : "";
      switch (31 & e) {
        case yn.SIGHASH_ALL:
          t += "SIGHASH_ALL";
          break;
        case yn.SIGHASH_SINGLE:
          t += "SIGHASH_SINGLE";
          break;
        case yn.SIGHASH_NONE:
          t += "SIGHASH_NONE";
      }
      return t;
    }(o);
    throw new Error(`Sighash type is not allowed. Retry the sign method passing the sighashTypes array of whitelisted types. Sighash type: ${e}`);
  }
  let a, c;
  if (t.nonWitnessUtxo) {
    const r = qn(n, t, e),
      i = s.ins[e].hash,
      o = r.getHash();
    if (!i.equals(o)) throw new Error(`Non-witness UTXO hash for input #${e} doesn't match the hash specified in the prevout`);
    const u = s.ins[e].index;
    c = r.outs[u];
  } else {
    if (!t.witnessUtxo) throw new Error("Need a Utxo input item for signing");
    c = t.witnessUtxo;
  }
  const {
    meaningfulScript: p,
    type: f
  } = zn(c.script, e, "input", t.redeemScript, t.witnessScript);
  if (["p2sh-p2wsh", "p2wsh"].indexOf(f) >= 0) a = s.hashForWitnessV0(e, p, c.value, o);else if (vn(p)) {
    const t = (0,_address_a3a74797_mjs__WEBPACK_IMPORTED_MODULE_1__.a)({
      hash: p.slice(2)
    }).output;
    a = s.hashForWitnessV0(e, t, c.value, o);
  } else {
    if (void 0 === t.nonWitnessUtxo && !1 === n.__UNSAFE_SIGN_NONSEGWIT) throw new Error(`Input #${e} has witnessUtxo but non-segwit script: ${p.toString("hex")}`);
    r || !1 === n.__UNSAFE_SIGN_NONSEGWIT || console.warn("Warning: Signing non-segwit inputs without the full parent transaction means there is a chance that a miner could feed you incorrect information to trick you into paying large fees. This behavior is the same as Psbt's predecesor (TransactionBuilder - now removed) when signing non-segwit scripts. You are not able to export this Psbt with toBuffer|toBase64|toHex since it is not BIP174 compliant.\n*********************\nPROCEED WITH CAUTION!\n*********************"), a = s.hashForSignature(e, p, o);
  }
  return {
    script: p,
    sighashType: o,
    hash: a
  };
}
function Fn(e, t, n) {
  const r = Zt.checkForInput(t, e);
  if (!r.bip32Derivation || 0 === r.bip32Derivation.length) throw new Error("Need bip32Derivation to sign with HD");
  const i = r.bip32Derivation.map(e => e.masterFingerprint.equals(n.fingerprint) ? e : void 0).filter(e => !!e);
  if (0 === i.length) throw new Error("Need one bip32Derivation masterFingerprint to match the HDSigner fingerprint");
  return i.map(e => {
    const t = n.derivePath(e.path);
    if (!e.pubkey.equals(t.publicKey)) throw new Error("pubkey did not match bip32Derivation");
    return t;
  });
}
function Mn(e) {
  let t = 0;
  function n() {
    const n = on.decode(e, t);
    return t += on.decode.bytes, n;
  }
  function r() {
    return r = n(), t += r, e.slice(t - r, t);
    var r;
  }
  return function () {
    const e = n(),
      t = [];
    for (let n = 0; n < e; n++) t.push(r());
    return t;
  }();
}
function Wn(t) {
  let n = _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_0__.B.allocUnsafe(0);
  function r(t) {
    const r = n.length,
      i = on.encodingLength(t);
    n = _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_0__.B.concat([n, _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_0__.B.allocUnsafe(i)]), on.encode(t, n, r);
  }
  function i(t) {
    r(t.length), function (t) {
      n = _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_0__.B.concat([n, _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_0__.B.from(t)]);
    }(t);
  }
  var s;
  return r((s = t).length), s.forEach(i), n;
}
function Xn(e, t, n) {
  e.__NON_WITNESS_UTXO_BUF_CACHE[n] = t.nonWitnessUtxo;
  const r = yn.fromBuffer(t.nonWitnessUtxo);
  e.__NON_WITNESS_UTXO_TX_CACHE[n] = r;
  const i = e,
    s = n;
  delete t.nonWitnessUtxo, Object.defineProperty(t, "nonWitnessUtxo", {
    enumerable: !0,
    get() {
      const e = i.__NON_WITNESS_UTXO_BUF_CACHE[s],
        t = i.__NON_WITNESS_UTXO_TX_CACHE[s];
      if (void 0 !== e) return e;
      {
        const e = t.toBuffer();
        return i.__NON_WITNESS_UTXO_BUF_CACHE[s] = e, e;
      }
    },
    set(e) {
      i.__NON_WITNESS_UTXO_BUF_CACHE[s] = e;
    }
  });
}
function jn(e, t, n, r) {
  let i = 0;
  e.forEach((e, s) => {
    if (r && e.finalScriptSig && (t.ins[s].script = e.finalScriptSig), r && e.finalScriptWitness && (t.ins[s].witness = Mn(e.finalScriptWitness)), e.witnessUtxo) i += e.witnessUtxo.value;else if (e.nonWitnessUtxo) {
      const r = qn(n, e, s),
        o = t.ins[s].index,
        u = r.outs[o];
      i += u.value;
    }
  });
  const s = t.outs.reduce((e, t) => e + t.value, 0),
    o = i - s;
  if (o < 0) throw new Error("Outputs are spending more than Inputs");
  const u = t.virtualSize();
  n.__FEE = o, n.__EXTRACTED_TX = t, n.__FEE_RATE = Math.floor(o / u);
}
function qn(e, t, n) {
  const r = e.__NON_WITNESS_UTXO_TX_CACHE;
  return r[n] || Xn(e, t, n), r[n];
}
function Yn(e, t, n) {
  if (void 0 !== t.witnessUtxo) return t.witnessUtxo.script;
  if (void 0 !== t.nonWitnessUtxo) {
    return qn(n, t, e).outs[n.__TX.ins[e].index].script;
  }
  throw new Error("Can't find pubkey in input without Utxo data");
}
function $n(e) {
  return 33 === e.length && (0,_script_28a5953a_mjs__WEBPACK_IMPORTED_MODULE_2__.e)(e);
}
function zn(e, t, n, r, i) {
  const s = On(e),
    o = s && r && Nn(r),
    u = Nn(e);
  if (s && void 0 === r) throw new Error("scriptPubkey is P2SH but redeemScript missing");
  if ((u || o) && void 0 === i) throw new Error("scriptPubkey or redeemScript is P2WSH but witnessScript missing");
  let a;
  return o ? (a = i, Rn(t, e, r, n), Ln(t, r, i, n), Jn(a)) : u ? (a = i, Ln(t, e, i, n), Jn(a)) : s ? (a = r, Rn(t, e, r, n)) : a = e, {
    meaningfulScript: a,
    type: o ? "p2sh-p2wsh" : s ? "p2sh" : u ? "p2wsh" : "raw"
  };
}
function Jn(e) {
  if (vn(e) || On(e)) throw new Error("P2WPKH or P2SH can not be contained within P2WSH");
}
function Qn(e, t) {
  const n = (0,_crypto_2c4d5428_mjs__WEBPACK_IMPORTED_MODULE_3__.hash160)(e),
    r = (0,_script_28a5953a_mjs__WEBPACK_IMPORTED_MODULE_2__.d)(t);
  if (null === r) throw new Error("Unknown script error");
  return r.some(t => "number" != typeof t && (t.equals(e) || t.equals(n)));
}
function Zn(e) {
  return vn(e) ? "witnesspubkeyhash" : mn(e) ? "pubkeyhash" : bn(e) ? "multisig" : An(e) ? "pubkey" : "nonstandard";
}
function er(e) {
  return [...Array(e).keys()];
}


/***/ })

}]);
//# sourceMappingURL=apps_wallet_src_assets_wallet-util_psbt-6ebe29e9_mjs.js.map