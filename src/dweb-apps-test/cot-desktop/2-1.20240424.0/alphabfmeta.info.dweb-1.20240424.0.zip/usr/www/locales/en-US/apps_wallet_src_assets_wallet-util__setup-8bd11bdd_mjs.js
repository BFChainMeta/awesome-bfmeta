"use strict";
(self["webpackChunkwallet"] = self["webpackChunkwallet"] || []).push([["apps_wallet_src_assets_wallet-util__setup-8bd11bdd_mjs"],{

/***/ 80002:
/*!****************************************************************!*\
  !*** ./apps/wallet/src/assets/wallet-util/_setup-8bd11bdd.mjs ***!
  \****************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   prepareBip32: () => (/* binding */ m)
/* harmony export */ });
/* harmony import */ var D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 52542);
/* harmony import */ var _ripemd160_3baa091d_mjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./ripemd160-3baa091d.mjs */ 70972);
/* harmony import */ var _sha256_e58017d9_mjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./sha256-e58017d9.mjs */ 6612);
/* harmony import */ var _sha512_0b4c0803_mjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./sha512-0b4c0803.mjs */ 89918);
/* harmony import */ var _WASMInterface_b9f2203b_mjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./WASMInterface-b9f2203b.mjs */ 43670);
/* harmony import */ var _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./index-766bdb76.mjs */ 59809);






const m = /*#__PURE__*/function () {
  var _ref = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
    yield _ripemd160_3baa091d_mjs__WEBPACK_IMPORTED_MODULE_1__.p.prepare(), yield _sha256_e58017d9_mjs__WEBPACK_IMPORTED_MODULE_2__.p.prepare(), yield _sha512_0b4c0803_mjs__WEBPACK_IMPORTED_MODULE_3__.p.prepare();
  });
  return function m() {
    return _ref.apply(this, arguments);
  };
}();


/***/ })

}]);
//# sourceMappingURL=apps_wallet_src_assets_wallet-util__setup-8bd11bdd_mjs.js.map