"use strict";
(self["webpackChunkwallet"] = self["webpackChunkwallet"] || []).push([["apps_wallet_src_pages_home_pages_home-bitcoin-address-settings_home-bitcoin-address-settings_-cc9b00"],{

/***/ 32111:
/*!*******************************************************************************************************************!*\
  !*** ./apps/wallet/src/pages/home/pages/home-bitcoin-address-settings/home-bitcoin-address-settings.component.ts ***!
  \*******************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   HomeBitcoinAddressSettingsPage: () => (/* binding */ HomeBitcoinAddressSettingsPage),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 52542);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! tslib */ 90505);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/core */ 61039);
/* harmony import */ var _modules_page_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ~modules/page.module */ 77538);
/* harmony import */ var _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @bnqkl/wallet-base/services/wallet/chain-base */ 27187);
/* harmony import */ var _bnqkl_wallet_base_services_wallet_wallet_data_storage__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @bnqkl/wallet-base/services/wallet/wallet-data-storage */ 63024);
/* harmony import */ var _bnqkl_framework_helpers__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @bnqkl/framework/helpers */ 12169);
/* harmony import */ var _bnqkl_wallet_base_services__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @bnqkl/wallet-base/services */ 62479);
/* harmony import */ var _libs_bnf_modules_bottom_sheet_components_bottom_sheet_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../../../../../libs/bnf/modules/bottom-sheet/components/bottom-sheet.component */ 94072);
/* harmony import */ var _libs_bnf_components_ripple_button_ripple_button_directive__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../../../../../libs/bnf/components/ripple-button/ripple-button.directive */ 16505);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/common */ 6729);
/* harmony import */ var _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../../../../../libs/bnf/modules/page/common-page/common-page.component */ 62052);
/* harmony import */ var _components_icon_icon_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../../../components/icon/icon.component */ 74703);
/* harmony import */ var _pipes_color_color_pipe__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../../../pipes/color/color.pipe */ 76489);
/* harmony import */ var _libs_bnf_pipes_address_hidden_address_hidden_pipe__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../../../../../../libs/bnf/pipes/address-hidden/address-hidden.pipe */ 35222);

var _class;















const _c8 = a0 => ({
  "--color-1": a0
});
function HomeBitcoinAddressSettingsPage_ng_template_15_li_3_Template(rf, ctx) {
  if (rf & 1) {
    const _r5 = _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](0, "li")(1, "button", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵlistener"]("click", function HomeBitcoinAddressSettingsPage_ng_template_15_li_3_Template_button_click_1_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵrestoreView"](_r5);
      const item_r3 = restoredCtx.$implicit;
      const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵresetView"](ctx_r4.selectBitcoinAddressType(item_r3.addressKey));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](2, "div", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelement"](3, "w-icon", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵpipe"](4, "color");
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](5, "div", 17)(6, "div", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵi18n"](7, 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](8, "div", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtext"](9);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵpipe"](10, "addressHidden");
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]()()()()();
  }
  if (rf & 2) {
    const item_r3 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("ngStyle", _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵpureFunction1"](9, _c8, item_r3.actived ? _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵpipeBind1"](4, 5, "primart") : "transparent"));
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵi18nExp"](item_r3.type)(item_r3.path)(item_r3.index);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵi18nApply"](7);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵpipeBind1"](10, 7, item_r3.address));
  }
}
function HomeBitcoinAddressSettingsPage_ng_template_15_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](0, "common-page", 10, 11)(2, "ul", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtemplate"](3, HomeBitcoinAddressSettingsPage_ng_template_15_li_3_Template, 11, 11, "li", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("ngForOf", ctx_r0.bitcoinSelectAddressTypeBottomSheetInfo.list)("ngForTrackBy", ctx_r0.trackByKey("address"));
  }
}
/**
 * 添加钱包第一步页面
 * 选择一条链去做导入
 */
class HomeBitcoinAddressSettingsPage extends _modules_page_module__WEBPACK_IMPORTED_MODULE_1__.CommonPageBase {
  constructor() {
    super(...arguments);
    /** 传入的id, 由于数据是动态变化的，这里只用id就行  */
    this.mainWalletId = '';
    this.walletDataStorageV2Service = (0,_angular_core__WEBPACK_IMPORTED_MODULE_12__.inject)(_bnqkl_wallet_base_services_wallet_wallet_data_storage__WEBPACK_IMPORTED_MODULE_3__.WalletDataStorageV2Service);
    this.bottomSheetListTemplate = [{
      type: 'Native SegWit',
      path: 84,
      index: 0,
      addressKey: '',
      address: '',
      actived: false
    }, {
      type: 'Nested SegWit',
      path: 49,
      index: 0,
      addressKey: '',
      address: '',
      actived: false
    }, {
      type: 'Taproot',
      path: 86,
      index: 0,
      addressKey: '',
      address: '',
      actived: false
    }, {
      type: 'Legacy',
      path: 44,
      index: 0,
      addressKey: '',
      address: '',
      actived: false
    }];
    /** 选择器 */
    this.bitcoinSelectAddressTypeBottomSheetInfo = {
      open: false,
      list: []
    };
  }
  /** 初始化 */
  init() {
    var _this = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      if ((0,_bnqkl_framework_helpers__WEBPACK_IMPORTED_MODULE_4__.$isNoEmptyString)(_this.mainWalletId) === false) {
        _this.console.error("not find mainWalletId");
        _this.nav.back();
        return;
      }
    })();
  }
  /** 打开地址类型切换 */
  openAddressTypeSwitching() {
    var _this2 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const {
        bitcoinAddressList,
        lastBitcoinAddress
      } = yield _this2.getBitcoinAddresss();
      const useIndex = lastBitcoinAddress.index || 0;
      const indexAddressList = bitcoinAddressList.filter(item => item.index === useIndex);
      /// 开始塞数据
      _this2.bitcoinSelectAddressTypeBottomSheetInfo.list = _this2.bottomSheetListTemplate.map(item => {
        const addressInfo = indexAddressList.find(v => v.purpose === item.path);
        const address = (addressInfo === null || addressInfo === void 0 ? void 0 : addressInfo.address) || item.address;
        const actived = (addressInfo === null || addressInfo === void 0 ? void 0 : addressInfo.address) === lastBitcoinAddress.address;
        return {
          ...item,
          actived,
          address,
          index: useIndex,
          addressKey: (addressInfo === null || addressInfo === void 0 ? void 0 : addressInfo.addressKey) || ""
        };
      }).filter(item => (0,_bnqkl_framework_helpers__WEBPACK_IMPORTED_MODULE_4__.$isNoEmptyString)(item.address));
      _this2.cdRef.detectChanges();
      _this2.bitcoinSelectAddressTypeBottomSheetInfo.open = true;
    })();
  }
  /** 获取对应的bitcoin地址列表 */
  getBitcoinAddresss() {
    var _this3 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const mainWallet = yield _this3.walletDataStorageV2Service.getMainWalletInfo(_this3.mainWalletId);
      const bitcoinAddressList = mainWallet.addressKeyList.filter(item => item.chainName === _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_2__.CHAIN_NAME.Bitcoin);
      const lastBitcoinAddress = bitcoinAddressList.find(item => item.addressKey === mainWallet.lastBitcoinAddressKey);
      return {
        bitcoinAddressList,
        lastBitcoinAddress
      };
    })();
  }
  /** 选择地址类型 */
  selectBitcoinAddressType(addressKey) {
    var _this4 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this4.bitcoinSelectAddressTypeBottomSheetInfo.list.forEach(item => {
        item.actived = item.addressKey === addressKey;
      });
      _this4.cdRef.detectChanges();
      _this4.bitcoinSelectAddressTypeBottomSheetInfo.open = false;
      const mainWallet = yield _this4.walletDataStorageV2Service.getMainWalletInfo(_this4.mainWalletId);
      const lastBitcoinAddressKey = mainWallet.lastBitcoinAddressKey;
      /// 更新对应钱包的数据
      if (lastBitcoinAddressKey !== addressKey) {
        mainWallet.lastBitcoinAddressKey = addressKey;
        yield _this4.walletDataStorageV2Service.saveMainWalletInfo(mainWallet);
      }
      /// 需要判断当前激活的钱包是否需要替换
      const lastWalletActivate = _this4.walletDataStorageV2Service.walletAppSettings.lastWalletActivate;
      if ((lastWalletActivate === null || lastWalletActivate === void 0 ? void 0 : lastWalletActivate.mainWalletId) === _this4.mainWalletId && (lastWalletActivate === null || lastWalletActivate === void 0 ? void 0 : lastWalletActivate.addressKey) !== addressKey) {
        const walletV2Service = _this4.injectorForceGet(_bnqkl_wallet_base_services__WEBPACK_IMPORTED_MODULE_5__.WalletV2Service);
        _this4.walletDataStorageV2Service.walletAppSettings.lastWalletActivate = yield _this4.walletDataStorageV2Service.getChainAddressInfo(addressKey);
        yield walletV2Service.upDateActivateAddressWallet();
      }
    })();
  }
  /** 进入地址选择页面 */
  gotoAddressSelection() {
    return this.nav.routeTo("/home-bitcoin-address-selection", {
      mainWalletId: this.mainWalletId
    });
  }
}
_class = HomeBitcoinAddressSettingsPage;
_class.ɵfac = /*@__PURE__*/(() => {
  let ɵHomeBitcoinAddressSettingsPage_BaseFactory;
  return function HomeBitcoinAddressSettingsPage_Factory(t) {
    return (ɵHomeBitcoinAddressSettingsPage_BaseFactory || (ɵHomeBitcoinAddressSettingsPage_BaseFactory = _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵgetInheritedFactory"](_class)))(t || _class);
  };
})();
_class.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵdefineComponent"]({
  type: _class,
  selectors: [["w-home-bitcoin-address-settings-page"]],
  inputs: {
    mainWalletId: "mainWalletId"
  },
  standalone: true,
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵInheritDefinitionFeature"], _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵStandaloneFeature"]],
  decls: 16,
  vars: 7,
  consts: () => {
    let i18n_0;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_ADDRESS_TYPE_SWITCHING$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_BITCOIN_ADDRESS_SETTINGS_HOME_BITCOIN_ADDRESS_SETTINGS_COMPONENT_TS_1 = goog.getMsg("Address type switching");
      i18n_0 = MSG_EXTERNAL_ADDRESS_TYPE_SWITCHING$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_BITCOIN_ADDRESS_SETTINGS_HOME_BITCOIN_ADDRESS_SETTINGS_COMPONENT_TS_1;
    } else {
      i18n_0 = "\u5730\u5740\u7C7B\u578B\u9009\u62E9";
    }
    let i18n_2;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_ADDRESS_SELECTION$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_BITCOIN_ADDRESS_SETTINGS_HOME_BITCOIN_ADDRESS_SETTINGS_COMPONENT_TS_3 = goog.getMsg("Address selection");
      i18n_2 = MSG_EXTERNAL_ADDRESS_SELECTION$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_BITCOIN_ADDRESS_SETTINGS_HOME_BITCOIN_ADDRESS_SETTINGS_COMPONENT_TS_3;
    } else {
      i18n_2 = "\u9009\u62E9\u5730\u5740";
    }
    let i18n_4;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_ADDRESS_TYPE_SWITCHING$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_BITCOIN_ADDRESS_SETTINGS_HOME_BITCOIN_ADDRESS_SETTINGS_COMPONENT_TS__5 = goog.getMsg("Address type switching");
      i18n_4 = MSG_EXTERNAL_ADDRESS_TYPE_SWITCHING$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_BITCOIN_ADDRESS_SETTINGS_HOME_BITCOIN_ADDRESS_SETTINGS_COMPONENT_TS__5;
    } else {
      i18n_4 = "\u5730\u5740\u7C7B\u578B\u9009\u62E9";
    }
    let i18n_6;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_M_0_0_0$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_BITCOIN_ADDRESS_SETTINGS_HOME_BITCOIN_ADDRESS_SETTINGS_COMPONENT_TS___7 = goog.getMsg("{$interpolation}(m/{$interpolation_1}'/0'/0'/0/{$interpolation_2})", {
        "interpolation": "\uFFFD0\uFFFD",
        "interpolation_1": "\uFFFD1\uFFFD",
        "interpolation_2": "\uFFFD2\uFFFD"
      }, {
        original_code: {
          "interpolation": "{{ item.type }}",
          "interpolation_1": "{{ item.path }}",
          "interpolation_2": "{{ item.index }}"
        }
      });
      i18n_6 = MSG_EXTERNAL_M_0_0_0$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_BITCOIN_ADDRESS_SETTINGS_HOME_BITCOIN_ADDRESS_SETTINGS_COMPONENT_TS___7;
    } else {
      i18n_6 = "" + "\uFFFD0\uFFFD" + "(m/" + "\uFFFD1\uFFFD" + "'/0'/0'/0/" + "\uFFFD2\uFFFD" + ")";
    }
    return [[3, "titleColor", "headerBackground", "contentBackground", "contentSafeArea"], [1, "text-title", "overflow-hidden", "bg-white"], ["bnRippleButton", "", 1, "px-page-safe-area-inset", "flex", "h-14", "w-full", "items-stretch", "justify-between", 3, "click"], [1, "flex", "items-center"], [1, "text-sm"], i18n_0, [1, "flex", "items-center", "justify-end"], [1, "icon-4", "ml-1.5", 3, "name"], i18n_2, [3, "isOpen", "isOpenChange"], ["headerTitle", i18n_4], ["page", ""], [1, "w-full", "bg-white", "px-5"], [4, "ngFor", "ngForOf", "ngForTrackBy"], ["bnRippleButton", "", 1, "border-b-tiny", "border-line", "flex", "w-full", "items-center", "justify-start", "px-2", "py-4", 3, "click"], [1, "flex", "items-center", "justify-start"], ["name", "language-selected-1", 1, "border-tiny", "border-subtext", "mr-2", "mt-[2px]", "rounded-[4px]", "p-[2px]", 3, "ngStyle"], [1, "flex", "items-start", "justify-start", "flex-col"], [1, "font-bold"], i18n_6, [1, "text-subtext", "text-xs"]];
  },
  template: function HomeBitcoinAddressSettingsPage_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](0, "common-page", 0)(1, "div", 1)(2, "button", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵlistener"]("click", function HomeBitcoinAddressSettingsPage_Template_button_click_2_listener() {
        return ctx.openAddressTypeSwitching();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](3, "div", 3)(4, "span", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵi18n"](5, 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](6, "div", 6);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelement"](7, "w-icon", 7);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](8, "button", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵlistener"]("click", function HomeBitcoinAddressSettingsPage_Template_button_click_8_listener() {
        return ctx.gotoAddressSelection();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](9, "div", 3)(10, "span", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵi18n"](11, 8);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](12, "div", 6);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelement"](13, "w-icon", 7);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]()()()();
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](14, "common-bottom-sheet", 9);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵlistener"]("isOpenChange", function HomeBitcoinAddressSettingsPage_Template_common_bottom_sheet_isOpenChange_14_listener($event) {
        return $event || (ctx.bitcoinSelectAddressTypeBottomSheetInfo.open = false);
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtemplate"](15, HomeBitcoinAddressSettingsPage_ng_template_15_Template, 4, 2, "ng-template");
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("titleColor", "black")("headerBackground", "white")("contentBackground", "white")("contentSafeArea", false);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](7);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("name", "right");
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](6);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("name", "right");
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("isOpen", ctx.bitcoinSelectAddressTypeBottomSheetInfo.open);
    }
  },
  dependencies: [_modules_page_module__WEBPACK_IMPORTED_MODULE_1__.CommonPageModule, _libs_bnf_modules_bottom_sheet_components_bottom_sheet_component__WEBPACK_IMPORTED_MODULE_6__.BottomSheetComponent, _libs_bnf_components_ripple_button_ripple_button_directive__WEBPACK_IMPORTED_MODULE_7__.RippleButtonDirective, _angular_common__WEBPACK_IMPORTED_MODULE_13__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_13__.NgStyle, _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_8__.CommonPageComponent, _components_icon_icon_component__WEBPACK_IMPORTED_MODULE_9__.IconComponent, _pipes_color_color_pipe__WEBPACK_IMPORTED_MODULE_10__.ColorPipe, _libs_bnf_pipes_address_hidden_address_hidden_pipe__WEBPACK_IMPORTED_MODULE_11__.AddressHiddenPipe],
  styles: ["/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsInNvdXJjZVJvb3QiOiIifQ== */"],
  changeDetection: 0
});
(0,tslib__WEBPACK_IMPORTED_MODULE_14__.__decorate)([HomeBitcoinAddressSettingsPage.States(), (0,tslib__WEBPACK_IMPORTED_MODULE_14__.__metadata)("design:type", Object)], HomeBitcoinAddressSettingsPage.prototype, "bitcoinSelectAddressTypeBottomSheetInfo", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_14__.__decorate)([HomeBitcoinAddressSettingsPage.OnReady(), (0,tslib__WEBPACK_IMPORTED_MODULE_14__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_14__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_14__.__metadata)("design:returntype", Promise)], HomeBitcoinAddressSettingsPage.prototype, "init", null);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (HomeBitcoinAddressSettingsPage);

/***/ })

}]);
//# sourceMappingURL=apps_wallet_src_pages_home_pages_home-bitcoin-address-settings_home-bitcoin-address-settings_-cc9b00.js.map