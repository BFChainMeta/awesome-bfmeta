"use strict";
(self["webpackChunkwallet"] = self["webpackChunkwallet"] || []).push([["apps_wallet_src_pages_mnemonic_pages_mnemonic-recover-wallet_mnemonic-recover-wallet_component_ts"],{

/***/ 23449:
/*!***********************************************************************************************************!*\
  !*** ./apps/wallet/src/pages/mnemonic/pages/mnemonic-recover-wallet/mnemonic-recover-wallet.component.ts ***!
  \***********************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   MnemonicRecoverWalletPage: () => (/* binding */ MnemonicRecoverWalletPage),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 52542);
/* harmony import */ var D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncIterator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/esm/asyncIterator.js */ 9243);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! tslib */ 90505);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/core */ 61039);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/forms */ 7820);
/* harmony import */ var _bnqkl_framework_helpers__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @bnqkl/framework/helpers */ 12169);
/* harmony import */ var _bnqkl_framework_plugins__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @bnqkl/framework/plugins */ 43990);
/* harmony import */ var _bnqkl_framework_plugins_keyboard__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @bnqkl/framework/plugins/keyboard */ 87717);
/* harmony import */ var _bnqkl_wallet_base_services_wallet__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @bnqkl/wallet-base/services/wallet */ 20609);
/* harmony import */ var _bnqkl_wallet_base_services_wallet_bip39__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @bnqkl/wallet-base/services/wallet/bip39 */ 76659);
/* harmony import */ var _modules_page_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ~modules/page.module */ 77538);
/* harmony import */ var _libs_bnf_components_ripple_button_ripple_button_directive__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../../../../../libs/bnf/components/ripple-button/ripple-button.directive */ 16505);
/* harmony import */ var _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../../../../../../libs/bnf/modules/page/common-page/common-page.component */ 62052);
/* harmony import */ var _components_icon_icon_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../../../components/icon/icon.component */ 74703);
/* harmony import */ var _pipes_color_color_pipe__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../../../pipes/color/color.pipe */ 76489);


var _class;















const _c12 = a0 => ({
  "--color-1": a0
});
function MnemonicRecoverWalletPage_Conditional_11_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](0, "div", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelement"](1, "w-icon", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵpipe"](2, "color");
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](3, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵi18n"](4, 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵpureFunction1"](4, _c12, _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵpipeBind1"](2, 2, "white")));
  }
}
function MnemonicRecoverWalletPage_Conditional_12_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](0, "div", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelement"](1, "w-icon", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵpipe"](2, "color");
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](3, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵi18n"](4, 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵpureFunction1"](4, _c12, _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵpipeBind1"](2, 2, "white")));
  }
}
/**
 * 恢复钱包页面
 */
class MnemonicRecoverWalletPage extends _modules_page_module__WEBPACK_IMPORTED_MODULE_7__.CommonPageBase {
  constructor() {
    var _this;
    /** 键盘是否弹出 */
    super(...arguments);
    _this = this;
    this.keyboardShow = false;
    /** 键盘状态监听 */
    this.getKeyboardInfo = _bnqkl_framework_plugins_keyboard__WEBPACK_IMPORTED_MODULE_4__.Keyboard.getKeyboardInfo$().subscribe(data => {
      this.keyboardShow = data.height > 0;
    });
    /** 助记词服务 */
    this.bip39LibService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_12__.inject)(_bnqkl_wallet_base_services_wallet_bip39__WEBPACK_IMPORTED_MODULE_6__.Bip39LibService);
    /** 导入全部链 */
    this.importAllChain = false;
    /** 新增钱包 */
    this.addWallet = false;
    /** 传进来的返回路由 */
    this.backUrl = '';
    /** 助记词 */
    this.word = new _angular_forms__WEBPACK_IMPORTED_MODULE_13__.FormControl('', {
      nonNullable: true,
      validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_13__.Validators.required],
      asyncValidators: [(
      /*#__PURE__*/
      /** 判断助记词是否正确 */
      function () {
        var _ref = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (control) {
          /// 没有其它错误了
          if (control.errors) {
            return null;
          }
          try {
            yield _this.bip39LibService.checkMnemonic(control.value.trim() || '');
            _this.importAllChain = true;
          } catch (err) {
            _this.importAllChain = false;
          }
          return null;
        });
        return function (_x) {
          return _ref.apply(this, arguments);
        };
      }())]
    });
    /** 要提交的表单与复合验证 */
    this.form = new _angular_forms__WEBPACK_IMPORTED_MODULE_13__.FormGroup({
      word: this.word
    }, {
      validators: [],
      asyncValidators: []
    });
    /** 提交事件 */
    this.onSubmit = (0,_bnqkl_framework_helpers__WEBPACK_IMPORTED_MODULE_2__.$singleton)( /*#__PURE__*/(0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const data = _this.form.getRawValue();
      const chainV2Service = _this.injectorForceGet(_bnqkl_wallet_base_services_wallet__WEBPACK_IMPORTED_MODULE_5__.ChainV2Service);
      const walletDataStorageV2Service = _this.injectorForceGet(_bnqkl_wallet_base_services_wallet__WEBPACK_IMPORTED_MODULE_5__.WalletDataStorageV2Service);
      let deleteMainWalletId = '';
      try {
        /** 判断助记词是否已经导入过了
         * 直接用生物链做判断即可
         */
        const bfmChainConfig = chainV2Service.getChainInfo(_bnqkl_wallet_base_services_wallet__WEBPACK_IMPORTED_MODULE_5__.CHAIN_NAME.BFMeta);
        const {
          address
        } = yield chainV2Service.createAddressAndPrivkeyFromMnemonic(bfmChainConfig.chain, bfmChainConfig.coinId, data.word.trim());
        const allAddressInfo = yield walletDataStorageV2Service.getAllChainAddressInfoList();
        const hasFind = allAddressInfo.find(item => item.address === address);
        if (hasFind) {
          _bnqkl_framework_plugins__WEBPACK_IMPORTED_MODULE_3__.Toast.show("The Address already exists");
          return;
        }
        let allChain = true;
        try {
          yield _this.bip39LibService.checkMnemonic(data.word.trim());
        } catch {
          allChain = false;
        }
        if (allChain) {
          /// 值判断外链
          const chainConfigList = (() => {
            return [...chainV2Service.chainConfig_Map.values()].filter(item => {
              return !chainV2Service.isBioforestChainByChainName(item.chain);
            });
          })();
          const newAddress_Set = new Set();
          for (let i = 0; i < chainConfigList.length; i++) {
            const chainConfig = chainConfigList[i];
            const purposes = chainConfig.chain === _bnqkl_wallet_base_services_wallet__WEBPACK_IMPORTED_MODULE_5__.CHAIN_NAME.Bitcoin ? [44, 49, 84, 86] : [44];
            var _iteratorAbruptCompletion = false;
            var _didIteratorError = false;
            var _iteratorError;
            try {
              for (var _iterator = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncIterator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(purposes), _step; _iteratorAbruptCompletion = !(_step = yield _iterator.next()).done; _iteratorAbruptCompletion = false) {
                const purpose = _step.value;
                {
                  const {
                    address
                  } = yield chainV2Service.createAddressAndPrivkeyFromMnemonic(chainConfig.chain, chainConfig.coinId, data.word, 0, purpose);
                  newAddress_Set.add(address);
                }
              }
            } catch (err) {
              _didIteratorError = true;
              _iteratorError = err;
            } finally {
              try {
                if (_iteratorAbruptCompletion && _iterator.return != null) {
                  yield _iterator.return();
                }
              } finally {
                if (_didIteratorError) {
                  throw _iteratorError;
                }
              }
            }
          }
          const newAddressList = [...newAddress_Set.values()];
          /// 判断是否有使用私钥导入的情况
          const allMain = yield walletDataStorageV2Service.getAllMainWalletInfo();
          const privateKeyAddressList = allMain.filter(item => item.importType === _bnqkl_wallet_base_services_wallet__WEBPACK_IMPORTED_MODULE_5__.WALLET_IMPORT_TYPE.privateKey).map(item => {
            return item.addressKeyList.map(info => {
              return {
                ...info,
                walletName: item.name
              };
            });
          }).flat();
          let exists = undefined;
          var _iteratorAbruptCompletion2 = false;
          var _didIteratorError2 = false;
          var _iteratorError2;
          try {
            pLoop: for (var _iterator2 = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncIterator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(privateKeyAddressList), _step2; _iteratorAbruptCompletion2 = !(_step2 = yield _iterator2.next()).done; _iteratorAbruptCompletion2 = false) {
              const pAddress = _step2.value;
              {
                var _iteratorAbruptCompletion3 = false;
                var _didIteratorError3 = false;
                var _iteratorError3;
                try {
                  for (var _iterator3 = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncIterator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(newAddressList), _step3; _iteratorAbruptCompletion3 = !(_step3 = yield _iterator3.next()).done; _iteratorAbruptCompletion3 = false) {
                    const nAddress = _step3.value;
                    {
                      if (yield chainV2Service.isAddressEqual(pAddress.chainName, nAddress, pAddress.address)) {
                        exists = pAddress;
                        break pLoop;
                      }
                    }
                  }
                } catch (err) {
                  _didIteratorError3 = true;
                  _iteratorError3 = err;
                } finally {
                  try {
                    if (_iteratorAbruptCompletion3 && _iterator3.return != null) {
                      yield _iterator3.return();
                    }
                  } finally {
                    if (_didIteratorError3) {
                      throw _iteratorError3;
                    }
                  }
                }
              }
            }
          } catch (err) {
            _didIteratorError2 = true;
            _iteratorError2 = err;
          } finally {
            try {
              if (_iteratorAbruptCompletion2 && _iterator2.return != null) {
                yield _iterator2.return();
              }
            } finally {
              if (_didIteratorError2) {
                throw _iteratorError2;
              }
            }
          } /// 如果存在 通知用户是否覆盖
          if (exists) {
            const newWalletName = yield walletDataStorageV2Service.createMainWalletName();
            const confirmed = yield _this.confirm({
              headerTitle: "Hint",
              bodyMessage: "Delected that the upcoming import of " + newWalletName + " contains all addresses in " + exists.walletName + ". Confirm to delete " + exists.walletName + " and import " + newWalletName + "",
              footerTheme: 'blank',
              confirmText: "Continue"
            });
            if (confirmed === false) {
              return;
            }
            deleteMainWalletId = exists.mainWalletId;
          }
        }
      } catch (err) {
        _bnqkl_framework_plugins__WEBPACK_IMPORTED_MODULE_3__.Toast.show(String(err));
        return;
      }
      if (_this.addWallet) {
        /// 创建成功页面
        _this.nav.routeTo('/mnemonic/create-wallet', {
          mnemonic: data.word.trim(),
          addWallet: true,
          showBackupBtn: false,
          backUrl: _this.backUrl,
          deleteMainWalletId
        });
      } else {
        return _this.nav.routeTo('mnemonic/set-wallet-password', {
          mnemonic: data.word.trim(),
          showBackupBtn: false
        }, true);
      }
    }));
  }
  handleTextareaChange(textarea) {
    if (textarea.scrollHeight < 150) {
      textarea.style.height = 'auto';
      textarea.style.height = textarea.scrollHeight + 'px';
    }
  }
}
_class = MnemonicRecoverWalletPage;
_class.ɵfac = /*@__PURE__*/(() => {
  let ɵMnemonicRecoverWalletPage_BaseFactory;
  return function MnemonicRecoverWalletPage_Factory(t) {
    return (ɵMnemonicRecoverWalletPage_BaseFactory || (ɵMnemonicRecoverWalletPage_BaseFactory = _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵgetInheritedFactory"](_class)))(t || _class);
  };
})();
_class.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵdefineComponent"]({
  type: _class,
  selectors: [["w-mnemonic-recover-wallet-page"]],
  inputs: {
    addWallet: ["addWallet", "addWallet", _angular_core__WEBPACK_IMPORTED_MODULE_12__.booleanAttribute],
    backUrl: "backUrl"
  },
  standalone: true,
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵInputTransformsFeature"], _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵInheritDefinitionFeature"], _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵStandaloneFeature"]],
  decls: 17,
  vars: 14,
  consts: () => {
    let i18n_0;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_IMPORT_WALLET$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_MNEMONIC_RECOVER_WALLET_MNEMONIC_RECOVER_WALLET_COMPONENT_TS_1 = goog.getMsg("Import Wallet");
      i18n_0 = MSG_EXTERNAL_IMPORT_WALLET$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_MNEMONIC_RECOVER_WALLET_MNEMONIC_RECOVER_WALLET_COMPONENT_TS_1;
    } else {
      i18n_0 = "Import Wallet";
    }
    let i18n_2;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_SUPPORTS_THE_IMPORT_OF_BIP39_MNEMONIC_PHRASES_AND_PASSWORDS_OF_BIOFOREST_CHAIN$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_MNEMONIC_RECOVER_WALLET_MNEMONIC_RECOVER_WALLET_COMPONENT_TS_3 = goog.getMsg(" Supports the import of BIP39 mnemonic phrases and passwords of Bioforest Chain ");
      i18n_2 = MSG_EXTERNAL_SUPPORTS_THE_IMPORT_OF_BIP39_MNEMONIC_PHRASES_AND_PASSWORDS_OF_BIOFOREST_CHAIN$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_MNEMONIC_RECOVER_WALLET_MNEMONIC_RECOVER_WALLET_COMPONENT_TS_3;
    } else {
      i18n_2 = " Supports the import of BIP39 mnemonic phrases and passwords of Bioforest Chain ";
    }
    let i18n_4;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_MNEMONIC$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_MNEMONIC_RECOVER_WALLET_MNEMONIC_RECOVER_WALLET_COMPONENT_TS_5 = goog.getMsg("Mnemonic");
      i18n_4 = MSG_EXTERNAL_MNEMONIC$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_MNEMONIC_RECOVER_WALLET_MNEMONIC_RECOVER_WALLET_COMPONENT_TS_5;
    } else {
      i18n_4 = "Mnemonic";
    }
    let i18n_6;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_THE_MNEMONICS_ARE_SEPARATED_BY_SPACES_AND_12_15_18_21_24_36BIT_MNEMONICS_IN_SIPLIFIED_CHINESE_TRADITIONAL_CHINESE_AND_ENGLISH_ARE_SIPPORTED$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_MNEMONIC_RECOVER_WALLET_MNEMONIC_RECOVER_WALLET_COMPONENT_TS_7 = goog.getMsg("The mnemonics are separated by spaces, and 12/15/18/21/24/36-bit mnemonics in Simplified Chinese, Traditional Chinese, and English are supported. Just enter the passwords of Bioforest Chain directly");
      i18n_6 = MSG_EXTERNAL_THE_MNEMONICS_ARE_SEPARATED_BY_SPACES_AND_12_15_18_21_24_36BIT_MNEMONICS_IN_SIPLIFIED_CHINESE_TRADITIONAL_CHINESE_AND_ENGLISH_ARE_SIPPORTED$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_MNEMONIC_RECOVER_WALLET_MNEMONIC_RECOVER_WALLET_COMPONENT_TS_7;
    } else {
      i18n_6 = "The mnemonics are separated by spaces, and 12/15/18/21/24/36-bit mnemonics in Simplified Chinese, Traditional Chinese, and English are supported. Just enter the passwords of Bioforest Chain directly";
    }
    let i18n_8;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_RESTORE_IDENTITY$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_MNEMONIC_RECOVER_WALLET_MNEMONIC_RECOVER_WALLET_COMPONENT_TS_9 = goog.getMsg("Restore Identity");
      i18n_8 = MSG_EXTERNAL_RESTORE_IDENTITY$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_MNEMONIC_RECOVER_WALLET_MNEMONIC_RECOVER_WALLET_COMPONENT_TS_9;
    } else {
      i18n_8 = "Restore Identity";
    }
    let i18n_10;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_COMPLIES_WITH_THE_BIP39_MNEMONIC_FORMAT_AND_WILL_BE_IMPORTED_INTO_ALL_LINKS$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_MNEMONIC_RECOVER_WALLET_MNEMONIC_RECOVER_WALLET_COMPONENT_TS__11 = goog.getMsg("Complies with the BIP39 mnemonic format and will be imported into all links");
      i18n_10 = MSG_EXTERNAL_COMPLIES_WITH_THE_BIP39_MNEMONIC_FORMAT_AND_WILL_BE_IMPORTED_INTO_ALL_LINKS$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_MNEMONIC_RECOVER_WALLET_MNEMONIC_RECOVER_WALLET_COMPONENT_TS__11;
    } else {
      i18n_10 = "Complies with the BIP39 mnemonic format and will be imported into all links";
    }
    let i18n_13;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_COMPLIES_WITH_THE_BIOFOREST_CHAIN_ADDRESS_PASSWORD_RULES_AND_ONLY_IMPOTRS_INTO_THE_BIOFOREST_CHAIN$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_MNEMONIC_RECOVER_WALLET_MNEMONIC_RECOVER_WALLET_COMPONENT_TS__14 = goog.getMsg("Complies with the Bioforest Chain address password rules and only imports into the Bioforest Chain");
      i18n_13 = MSG_EXTERNAL_COMPLIES_WITH_THE_BIOFOREST_CHAIN_ADDRESS_PASSWORD_RULES_AND_ONLY_IMPOTRS_INTO_THE_BIOFOREST_CHAIN$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_MNEMONIC_RECOVER_WALLET_MNEMONIC_RECOVER_WALLET_COMPONENT_TS__14;
    } else {
      i18n_13 = "Complies with the Bioforest Chain address password rules and only imports into the Bioforest Chain";
    }
    return [["headerTitle", i18n_0, 3, "titleTheme", "contentSafeArea", "contentBackground", "headerBackground", "headerTranslucent", "footerTranslucent", "footerOpacity"], [1, "text-title", 3, "formGroup", "ngSubmit"], [1, "mt-2", "text-xs"], i18n_2, [1, "mb-2", "flex", "h-10", "w-full", "items-end", "justify-between", "text-xs", "font-semibold"], [1, "flex-shrink-0", "pr-2"], i18n_4, [1, "flex", "rounded-lg", "bg-white", "py-2"], ["rows", "6", "formControlName", "word", "type", "text", "placeholder", i18n_6, 1, "placeholder:text-subtext/60", "w-full", "px-2", 3, "ngModelChange"], ["textarea", ""], ["class", "mb-4 mt-6 flex"], ["footer", "", 1, "flex", "flex-col", "items-center", 3, "formGroup", "ngSubmit"], ["bnRippleButton", "", "type", "submit", 1, "h-10.5", "from-purple-gradient-start", "to-purple-gradient-end", "w-full", "rounded-full", "bg-gradient-to-b", "text-center", "text-sm", "text-white", 3, "disabled"], i18n_8, [1, "mb-4", "mt-6", "flex"], ["name", "language-selected-1", 1, "bg-primary", "mr-2", "mt-[2px]", "rounded-full", "p-[2px]"], i18n_10, i18n_13];
  },
  template: function MnemonicRecoverWalletPage_Template(rf, ctx) {
    if (rf & 1) {
      const _r3 = _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵgetCurrentView"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](0, "common-page", 0)(1, "form", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵlistener"]("ngSubmit", function MnemonicRecoverWalletPage_Template_form_ngSubmit_1_listener() {
        return ctx.onSubmit();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](2, "div", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵi18n"](3, 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](4, "fieldset")(5, "legend", 4)(6, "div", 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵi18n"](7, 6);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](8, "div", 7)(9, "textarea", 8, 9);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵlistener"]("ngModelChange", function MnemonicRecoverWalletPage_Template_textarea_ngModelChange_9_listener() {
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵrestoreView"](_r3);
        const _r0 = _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵreference"](10);
        return _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵresetView"](ctx.handleTextareaChange(_r0));
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]()()();
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtemplate"](11, MnemonicRecoverWalletPage_Conditional_11_Template, 5, 6, "div", 10)(12, MnemonicRecoverWalletPage_Conditional_12_Template, 5, 6, "div", 10);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](13, "form", 11);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵlistener"]("ngSubmit", function MnemonicRecoverWalletPage_Template_form_ngSubmit_13_listener() {
        return ctx.onSubmit();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](14, "button", 12)(15, "span");
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵi18n"](16, 13);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]()()()();
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("titleTheme", ctx.keyboardShow ? "center-aligned" : "large")("contentSafeArea", true)("contentBackground", "grey")("headerBackground", "transparent")("headerTranslucent", false)("footerTranslucent", false)("footerOpacity", 0.8);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("formGroup", ctx.form);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](10);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵconditional"](11, ctx.word.value && ctx.importAllChain ? 11 : -1);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵconditional"](12, ctx.word.value && !ctx.importAllChain ? 12 : -1);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("formGroup", ctx.form);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵclassProp"]("opacity-30", !ctx.form.valid);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("disabled", !ctx.form.valid);
    }
  },
  dependencies: [_modules_page_module__WEBPACK_IMPORTED_MODULE_7__.CommonPageModule, _libs_bnf_components_ripple_button_ripple_button_directive__WEBPACK_IMPORTED_MODULE_8__.RippleButtonDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_13__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_13__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_13__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_13__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_13__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_13__.FormControlName, _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_9__.CommonPageComponent, _components_icon_icon_component__WEBPACK_IMPORTED_MODULE_10__.IconComponent, _pipes_color_color_pipe__WEBPACK_IMPORTED_MODULE_11__.ColorPipe],
  styles: ["[_nghost-%COMP%]   ._hide-selected[_ngcontent-%COMP%] {\n  --color-1: transparent;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL2FwcHMvd2FsbGV0L3NyYy9wYWdlcy9tbmVtb25pYy9wYWdlcy9tbmVtb25pYy1yZWNvdmVyLXdhbGxldC9tbmVtb25pYy1yZWNvdmVyLXdhbGxldC5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFDRTtFQUNFLHNCQUFBO0FBQUoiLCJzb3VyY2VzQ29udGVudCI6WyI6aG9zdCB7XHJcbiAgLl9oaWRlLXNlbGVjdGVkIHtcclxuICAgIC0tY29sb3ItMTogdHJhbnNwYXJlbnQ7XHJcbiAgfVxyXG59XHJcbiJdLCJzb3VyY2VSb290IjoiIn0= */"],
  changeDetection: 0
});
(0,tslib__WEBPACK_IMPORTED_MODULE_14__.__decorate)([MnemonicRecoverWalletPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_14__.__metadata)("design:type", Object)], MnemonicRecoverWalletPage.prototype, "keyboardShow", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_14__.__decorate)([MnemonicRecoverWalletPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_14__.__metadata)("design:type", Object)], MnemonicRecoverWalletPage.prototype, "getKeyboardInfo", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_14__.__decorate)([MnemonicRecoverWalletPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_14__.__metadata)("design:type", Object)], MnemonicRecoverWalletPage.prototype, "importAllChain", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_14__.__decorate)([MnemonicRecoverWalletPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_14__.__metadata)("design:type", Object)], MnemonicRecoverWalletPage.prototype, "word", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_14__.__decorate)([MnemonicRecoverWalletPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_14__.__metadata)("design:type", Object)], MnemonicRecoverWalletPage.prototype, "form", void 0);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MnemonicRecoverWalletPage);

/***/ })

}]);
//# sourceMappingURL=apps_wallet_src_pages_mnemonic_pages_mnemonic-recover-wallet_mnemonic-recover-wallet_component_ts.js.map