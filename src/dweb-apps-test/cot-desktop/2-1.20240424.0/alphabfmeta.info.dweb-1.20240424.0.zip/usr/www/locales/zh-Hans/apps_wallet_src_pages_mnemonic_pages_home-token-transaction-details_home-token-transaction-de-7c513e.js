"use strict";
(self["webpackChunkwallet"] = self["webpackChunkwallet"] || []).push([["apps_wallet_src_pages_mnemonic_pages_home-token-transaction-details_home-token-transaction-de-7c513e"],{

/***/ 5685:
/*!*************************************************************************************************************************!*\
  !*** ./apps/wallet/src/pages/mnemonic/pages/home-token-transaction-details/home-token-transaction-details.component.ts ***!
  \*************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   HomeTokenTransactionDetailsPage: () => (/* binding */ HomeTokenTransactionDetailsPage),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 52542);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! tslib */ 90505);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @angular/core */ 61039);
/* harmony import */ var _angular_material_expansion__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! @angular/material/expansion */ 5101);
/* harmony import */ var _bnqkl_framework_pipes__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @bnqkl/framework/pipes */ 80909);
/* harmony import */ var _bnqkl_framework_plugins_browser__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @bnqkl/framework/plugins/browser */ 93173);
/* harmony import */ var _bnqkl_wallet_base_services__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @bnqkl/wallet-base/services */ 62479);
/* harmony import */ var _bnqkl_wallet_base_services_wallet_chain__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @bnqkl/wallet-base/services/wallet/chain */ 27434);
/* harmony import */ var _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @bnqkl/wallet-base/services/wallet/chain-base */ 27187);
/* harmony import */ var _modules_page_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ~modules/page.module */ 77538);
/* harmony import */ var _libs_bnf_components_ripple_button_ripple_button_directive__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../../../../../libs/bnf/components/ripple-button/ripple-button.directive */ 16505);
/* harmony import */ var _libs_bnf_directives_click_to_copy_directive__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../../../../../libs/bnf/directives/click-to-copy.directive */ 46413);
/* harmony import */ var _libs_bnf_directives_tab_directive__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../../../../../../libs/bnf/directives/tab.directive */ 384);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @angular/common */ 6729);
/* harmony import */ var _libs_bnf_modules_dialog_components_template_dialog_opener_template_dialog_opener_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../../../../../../libs/bnf/modules/dialog/components/template-dialog-opener/template-dialog-opener.component */ 57628);
/* harmony import */ var _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../../../../../../libs/bnf/modules/page/common-page/common-page.component */ 62052);
/* harmony import */ var _components_icon_icon_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../../../components/icon/icon.component */ 74703);
/* harmony import */ var _libs_bnf_pipes_day_format_day_format_pipe__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../../../../../../../libs/bnf/pipes/day-format/day-format.pipe */ 24562);
/* harmony import */ var _pipes_color_color_pipe__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../../../../pipes/color/color.pipe */ 76489);
/* harmony import */ var _libs_bnf_pipes_address_hidden_address_hidden_pipe__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ../../../../../../../libs/bnf/pipes/address-hidden/address-hidden.pipe */ 35222);
/* harmony import */ var _libs_bnf_pipes_amountFixed_amount_fixed_pipe__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ../../../../../../../libs/bnf/pipes/amountFixed/amount-fixed.pipe */ 44070);

var _class;






















function HomeTokenTransactionDetailsPage_ng_container_5_div_4_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](0, "div", 10)(1, "div", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵi18n"](2, 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](3, "div", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtextInterpolate1"](" ", ctx_r3.getTranscationTypeName(), " ");
  }
}
function HomeTokenTransactionDetailsPage_ng_container_5_div_5_button_5_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](0, "button", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelement"](1, "w-icon", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r11 = _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵproperty"]("wClickToCopy", ctx_r11.amountChangeCopyText);
  }
}
function HomeTokenTransactionDetailsPage_ng_container_5_div_5_Template(rf, ctx) {
  if (rf & 1) {
    const _r13 = _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](0, "div", 10)(1, "div", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](3, "div", 14)(4, "div", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵlistener"]("click", function HomeTokenTransactionDetailsPage_ng_container_5_div_5_Template_div_click_4_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵrestoreView"](_r13);
      const ctx_r12 = _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵresetView"](ctx_r12.showEntityImgs());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtemplate"](5, HomeTokenTransactionDetailsPage_ng_container_5_div_5_button_5_Template, 2, 1, "button", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtextInterpolate"](ctx_r4.amountChangeText);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵproperty"]("innerHtml", ctx_r4.amountChange, _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵsanitizeHtml"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵproperty"]("ngIf", !!ctx_r4.amountChangeCopyText);
  }
}
function HomeTokenTransactionDetailsPage_ng_container_5_div_6_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](0, "div", 10)(1, "div", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵi18n"](2, 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](3, "div", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtextInterpolate1"](" ", ctx_r5.tronContractTrsFee || ctx_r5.getShowTransactionmFee(), " ");
  }
}
function HomeTokenTransactionDetailsPage_ng_container_5_div_7_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](0, "div", 10)(1, "div", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵi18n"](2, 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](3, "div", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵpipe"](5, "addressHidden");
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](6, "button", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelement"](7, "w-icon", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const ctx_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵpipeBind1"](5, 2, ctx_r6.trsInfo.recipientId), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵproperty"]("wClickToCopy", ctx_r6.trsInfo.recipientId);
  }
}
function HomeTokenTransactionDetailsPage_ng_container_5_div_8_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](0, "div", 10)(1, "div", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵi18n"](2, 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](3, "div", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵpipe"](5, "addressHidden");
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](6, "button", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelement"](7, "w-icon", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const ctx_r7 = _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵpipeBind1"](5, 2, ctx_r7.trsInfo.senderId), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵproperty"]("wClickToCopy", ctx_r7.trsInfo.senderId);
  }
}
function HomeTokenTransactionDetailsPage_ng_container_5_div_9_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](0, "div", 10)(1, "div", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵi18n"](2, 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](3, "div", 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](5, "button", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelement"](6, "w-icon", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const ctx_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtextInterpolate1"](" ", ctx_r8.trs.signature, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵproperty"]("wClickToCopy", ctx_r8.trs.signature);
  }
}
function HomeTokenTransactionDetailsPage_ng_container_5_div_10_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](0, "div", 26)(1, "div", 27);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵi18n"](2, 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]()();
  }
}
const _forTrack20 = ($index, $item) => $item.txid;
function HomeTokenTransactionDetailsPage_ng_container_5_Conditional_11_ng_template_24_For_3_Conditional_0_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](0, "div", 51)(1, "div", 41);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](3, "div", 42);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵpipe"](5, "addressHidden");
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](6, "button", 52);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelement"](7, "w-icon", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](8, "div", 44);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtext"](9);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵpipe"](10, "amountFixed");
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r23 = _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵnextContext"]();
    const ɵ$index_4_r19 = ctx_r23.$index;
    const ɵ$count_4_r21 = ctx_r23.$count;
    const index_r18 = ctx_r23.$index;
    const item_r17 = ctx_r23.$implicit;
    const ctx_r22 = _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵnextContext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵclassProp"]("border-b-tiny", !(ɵ$index_4_r19 === ɵ$count_4_r21 - 1));
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtextInterpolate1"]("#", index_r18, "");
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtextInterpolate1"]("", _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵpipeBind1"](5, 6, item_r17.txid), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵproperty"]("wClickToCopy", item_r17.txid);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵpipeBind2"](10, 8, item_r17.value, ctx_r22.trs.decimals), " ");
  }
}
function HomeTokenTransactionDetailsPage_ng_container_5_Conditional_11_ng_template_24_For_3_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtemplate"](0, HomeTokenTransactionDetailsPage_ng_container_5_Conditional_11_ng_template_24_For_3_Conditional_0_Template, 11, 11, "div", 50);
  }
  if (rf & 2) {
    const index_r18 = ctx.$index;
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵconditional"](0, !(index_r18 === 0) ? 0 : -1);
  }
}
function HomeTokenTransactionDetailsPage_ng_container_5_Conditional_11_ng_template_24_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](0, "div")(1, "div", 49);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵrepeaterCreate"](2, HomeTokenTransactionDetailsPage_ng_container_5_Conditional_11_ng_template_24_For_3_Template, 1, 1, null, null, _forTrack20);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r14 = _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵrepeater"](ctx_r14.bitcoinVin);
  }
}
const _forTrack21 = ($index, $item) => $item.hex;
const _c22 = () => [];
function HomeTokenTransactionDetailsPage_ng_container_5_Conditional_11_ng_template_48_For_3_Conditional_0_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](0, "div", 51)(1, "div", 41);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](3, "div", 42);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵpipe"](5, "addressHidden");
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](6, "button", 52);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelement"](7, "w-icon", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](8, "div", 44);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtext"](9);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵpipe"](10, "amountFixed");
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r31 = _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵnextContext"]();
    const ɵ$index_4_r27 = ctx_r31.$index;
    const ɵ$count_4_r29 = ctx_r31.$count;
    const item_r25 = ctx_r31.$implicit;
    const index_r26 = ctx_r31.$index;
    const ctx_r30 = _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵnextContext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵclassProp"]("border-b-tiny", !(ɵ$index_4_r27 === ɵ$count_4_r29 - 1));
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵclassProp"]("!text-primary", ((item_r25 == null ? null : item_r25.addresses) || _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵpureFunction0"](17, _c22))[0] === ctx_r30.userAddress);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtextInterpolate1"]("#", index_r26, "");
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵclassProp"]("!text-primary", ((item_r25 == null ? null : item_r25.addresses) || _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵpureFunction0"](18, _c22))[0] === ctx_r30.userAddress);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtextInterpolate1"]("", _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵpipeBind1"](5, 12, ((item_r25 == null ? null : item_r25.addresses) || _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵpureFunction0"](19, _c22))[0]), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵproperty"]("wClickToCopy", ((item_r25 == null ? null : item_r25.addresses) || _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵpureFunction0"](20, _c22))[0]);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵclassProp"]("!text-primary", ((item_r25 == null ? null : item_r25.addresses) || _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵpureFunction0"](21, _c22))[0] === ctx_r30.userAddress);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵpipeBind2"](10, 14, item_r25.value, ctx_r30.trs.decimals), " ");
  }
}
function HomeTokenTransactionDetailsPage_ng_container_5_Conditional_11_ng_template_48_For_3_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtemplate"](0, HomeTokenTransactionDetailsPage_ng_container_5_Conditional_11_ng_template_48_For_3_Conditional_0_Template, 11, 22, "div", 50);
  }
  if (rf & 2) {
    const index_r26 = ctx.$index;
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵconditional"](0, !(index_r26 === 0) ? 0 : -1);
  }
}
function HomeTokenTransactionDetailsPage_ng_container_5_Conditional_11_ng_template_48_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](0, "div")(1, "div", 49);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵrepeaterCreate"](2, HomeTokenTransactionDetailsPage_ng_container_5_Conditional_11_ng_template_48_For_3_Template, 1, 1, null, null, _forTrack21);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r15 = _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵrepeater"](ctx_r15.bitcoinVout);
  }
}
const _c23 = a0 => ({
  "--color-1": a0
});
function HomeTokenTransactionDetailsPage_ng_container_5_Conditional_11_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](0, "div", 29)(1, "div", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵi18n"](2, 30);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](3, "div", 31)(4, "mat-accordion", 32)(5, "mat-expansion-panel", 33)(6, "mat-expansion-panel-header", 34)(7, "mat-panel-title", 35)(8, "div", 36)(9, "div", 37)(10, "span", 38);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵi18n"](11, 39);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelement"](12, "w-icon", 40);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵpipe"](13, "color");
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](14, "div", 41);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtext"](15, "#0");
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](16, "div", 42);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtext"](17);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵpipe"](18, "addressHidden");
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](19, "button", 43);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵlistener"]("click", function HomeTokenTransactionDetailsPage_ng_container_5_Conditional_11_Template_button_click_19_listener($event) {
      return $event.stopPropagation();
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelement"](20, "w-icon", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](21, "div", 44);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtext"](22);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵpipe"](23, "amountFixed");
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]()()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtemplate"](24, HomeTokenTransactionDetailsPage_ng_container_5_Conditional_11_ng_template_24_Template, 4, 0, "ng-template", 45);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]()()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelement"](25, "w-icon", 46);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](26, "div", 29)(27, "div", 47)(28, "mat-accordion", 32)(29, "mat-expansion-panel", 33)(30, "mat-expansion-panel-header", 34)(31, "mat-panel-title", 35)(32, "div", 36)(33, "div", 37)(34, "span", 38);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵi18n"](35, 48);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelement"](36, "w-icon", 40);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵpipe"](37, "color");
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](38, "div", 41);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtext"](39, "#0");
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](40, "div", 42);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtext"](41);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵpipe"](42, "addressHidden");
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](43, "button", 43);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵlistener"]("click", function HomeTokenTransactionDetailsPage_ng_container_5_Conditional_11_Template_button_click_43_listener($event) {
      return $event.stopPropagation();
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelement"](44, "w-icon", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](45, "div", 44);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtext"](46);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵpipe"](47, "amountFixed");
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]()()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtemplate"](48, HomeTokenTransactionDetailsPage_ng_container_5_Conditional_11_ng_template_48_Template, 4, 0, "ng-template", 45);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]()()()();
  }
  if (rf & 2) {
    const ctx_r10 = _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](12);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵpureFunction1"](30, _c23, _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵpipeBind1"](13, 16, "primary")));
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtextInterpolate1"]("", _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵpipeBind1"](18, 18, ctx_r10.bitcoinVin[0].txid), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵproperty"]("wClickToCopy", ctx_r10.bitcoinVin[0].txid);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵpipeBind2"](23, 20, ctx_r10.bitcoinVin[0].value, ctx_r10.trs.decimals), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](14);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵpureFunction1"](32, _c23, _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵpipeBind1"](37, 23, "primary")));
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵclassProp"]("!text-primary", (ctx_r10.bitcoinVout[0].addresses || _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵpureFunction0"](34, _c22))[0] === ctx_r10.userAddress);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵclassProp"]("!text-primary", (ctx_r10.bitcoinVout[0].addresses || _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵpureFunction0"](35, _c22))[0] === ctx_r10.userAddress);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtextInterpolate1"]("", _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵpipeBind1"](42, 25, (ctx_r10.bitcoinVout[0].addresses || _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵpureFunction0"](36, _c22))[0]), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵproperty"]("wClickToCopy", (ctx_r10.bitcoinVout[0].addresses || _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵpureFunction0"](37, _c22))[0]);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵclassProp"]("!text-primary", (ctx_r10.bitcoinVout[0].addresses || _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵpureFunction0"](38, _c22))[0] === ctx_r10.userAddress);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵpipeBind2"](47, 27, ctx_r10.bitcoinVout[0].value, ctx_r10.trs.decimals), " ");
  }
}
function HomeTokenTransactionDetailsPage_ng_container_5_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](1, "div", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵpipe"](3, "dayFormat");
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtemplate"](4, HomeTokenTransactionDetailsPage_ng_container_5_div_4_Template, 5, 1, "div", 8)(5, HomeTokenTransactionDetailsPage_ng_container_5_div_5_Template, 6, 3, "div", 8)(6, HomeTokenTransactionDetailsPage_ng_container_5_div_6_Template, 5, 1, "div", 8)(7, HomeTokenTransactionDetailsPage_ng_container_5_div_7_Template, 8, 4, "div", 8)(8, HomeTokenTransactionDetailsPage_ng_container_5_div_8_Template, 8, 4, "div", 8)(9, HomeTokenTransactionDetailsPage_ng_container_5_div_9_Template, 7, 2, "div", 8)(10, HomeTokenTransactionDetailsPage_ng_container_5_div_10_Template, 3, 0, "div", 9)(11, HomeTokenTransactionDetailsPage_ng_container_5_Conditional_11_Template, 49, 39);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵpipeBind1"](3, 9, ctx_r0.trs.timestamp));
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵproperty"]("ngIf", ctx_r0.isBioforestChain);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵproperty"]("ngIf", ctx_r0.amountChange);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵproperty"]("ngIf", !ctx_r0.isBitcoinChain);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵproperty"]("ngIf", !!ctx_r0.trsInfo.recipientId);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵproperty"]("ngIf", !ctx_r0.isBitcoinChain);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵproperty"]("ngIf", +ctx_r0.status === ctx_r0.TRANS_STATUS.CONFIRM);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵproperty"]("ngIf", +ctx_r0.status === ctx_r0.TRANS_STATUS.EFFECTIVED);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵconditional"](11, ctx_r0.isBitcoinChain ? 11 : -1);
  }
}
function HomeTokenTransactionDetailsPage_div_6_Template(rf, ctx) {
  if (rf & 1) {
    const _r35 = _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](0, "div", 53)(1, "button", 54);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵlistener"]("click", function HomeTokenTransactionDetailsPage_div_6_Template_button_click_1_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵrestoreView"](_r35);
      const ctx_r34 = _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵresetView"](ctx_r34.goScanDetail());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵi18n"](2, 55);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]()();
  }
}
const _forTrack26 = ($index, $item) => $item.content;
function HomeTokenTransactionDetailsPage_ng_template_8_For_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](0, "div", 61);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelement"](1, "img", 62);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const item_r39 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵproperty"]("src", item_r39.imgLink, _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵsanitizeUrl"]);
  }
}
function HomeTokenTransactionDetailsPage_ng_template_8_w_icon_3_Template(rf, ctx) {
  if (rf & 1) {
    const _r45 = _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](0, "w-icon", 63);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵlistener"]("click", function HomeTokenTransactionDetailsPage_ng_template_8_w_icon_3_Template_w_icon_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵrestoreView"](_r45);
      const ctx_r44 = _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵresetView"](ctx_r44.handleCurrActivityIndex(false));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
  }
}
function HomeTokenTransactionDetailsPage_ng_template_8_w_icon_4_Template(rf, ctx) {
  if (rf & 1) {
    const _r47 = _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](0, "w-icon", 64);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵlistener"]("click", function HomeTokenTransactionDetailsPage_ng_template_8_w_icon_4_Template_w_icon_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵrestoreView"](_r47);
      const ctx_r46 = _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵresetView"](ctx_r46.handleCurrActivityIndex(true));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
  }
}
function HomeTokenTransactionDetailsPage_ng_template_8_Template(rf, ctx) {
  if (rf & 1) {
    const _r49 = _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](0, "div", 56);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵlistener"]("selectedIndexChange$", function HomeTokenTransactionDetailsPage_ng_template_8_Template_div_selectedIndexChange__0_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵrestoreView"](_r49);
      const ctx_r48 = _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵresetView"](ctx_r48.selectPointActivity($event));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵrepeaterCreate"](1, HomeTokenTransactionDetailsPage_ng_template_8_For_2_Template, 2, 1, "div", 65, _forTrack26);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtemplate"](3, HomeTokenTransactionDetailsPage_ng_template_8_w_icon_3_Template, 1, 0, "w-icon", 57)(4, HomeTokenTransactionDetailsPage_ng_template_8_w_icon_4_Template, 1, 0, "w-icon", 58);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](5, "button", 59);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵlistener"]("click", function HomeTokenTransactionDetailsPage_ng_template_8_Template_button_click_5_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵrestoreView"](_r49);
      const ctx_r50 = _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵresetView"](ctx_r50.dialog_EntityImgs.is_open = false);
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelement"](6, "w-icon", 60);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵpipe"](7, "color");
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵproperty"]("selectedIndex", ctx_r2.dialog_EntityImgs.currActivityIndex);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵrepeater"](ctx_r2.dialog_EntityImgs.imgs);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵproperty"]("ngIf", ctx_r2.dialog_EntityImgs.currActivityIndex > 0);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵproperty"]("ngIf", ctx_r2.dialog_EntityImgs.currActivityIndex < ctx_r2.dialog_EntityImgs.imgs.length - 1);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵproperty"]("ngStyle", _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵpureFunction1"](6, _c23, _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵpipeBind1"](7, 4, "white")));
  }
}
/** 交易详情页面 */
class HomeTokenTransactionDetailsPage extends _modules_page_module__WEBPACK_IMPORTED_MODULE_6__.CommonPageBase {
  constructor() {
    super(...arguments);
    this.trsStringify = '';
    /** 用户地址 */
    this.userAddress = '';
    /** 精度 */
    this.decimals = '0';
    /** 事件状态 */
    this.status = '';
    /** 事件状态合集 */
    this.TRANS_STATUS = _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_5__.TRANS_STATUS;
    /** 链信息 */
    this.chainInfo = {
      symbol: '',
      decimals: 0
    };
    /** 状态提示 */
    this.message = '';
    /** 波场合约手续费 */
    this.tronContractTrsFee = '';
    /** 链服务 */
    this._chainV2Service = (0,_angular_core__WEBPACK_IMPORTED_MODULE_17__.inject)(_bnqkl_wallet_base_services_wallet_chain__WEBPACK_IMPORTED_MODULE_4__.ChainV2Service);
    /** 资产变动 */
    this.amountChange = '';
    /** 资产变动信息复制 */
    this.amountChangeCopyText = '';
    /** 同质化信息 */
    this.dialog_EntityImgs = {
      is_open: false,
      imgs: [],
      currActivityIndex: 0
    };
    this.trsInfo = {
      senderId: ''
    };
  }
  get bitcoinVin() {
    var _this$bitcoinTrs;
    return ((_this$bitcoinTrs = this.bitcoinTrs) === null || _this$bitcoinTrs === void 0 ? void 0 : _this$bitcoinTrs.vin) || [];
  }
  get bitcoinVout() {
    var _this$bitcoinTrs2;
    return ((_this$bitcoinTrs2 = this.bitcoinTrs) === null || _this$bitcoinTrs2 === void 0 ? void 0 : _this$bitcoinTrs2.vout) || [];
  }
  get isBitcoinChain() {
    return this._chain === _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_5__.CHAIN_NAME.Bitcoin;
  }
  /**  是否是生物链林-链 */
  get isBioforestChain() {
    return this._chainV2Service.isBioforestChainByChainName(this._chain);
  }
  /** 金额变动文本 */
  get amountChangeText() {
    return this.isBioforestChain ? "\u8D44\u4EA7\u4EA4\u6362" : "\u6570\u91CF";
  }
  /** 获取交易名称: 只有生物链林才会调用 */
  getTranscationTypeName() {
    if (this.isBioforestChain === false) {
      return;
    }
    let name = "\u672A\u6CE8\u518C\u5185\u5BB9";
    const transaction = this.trs.transaction;
    const {
      baseType
    } = (0,_bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_5__.getBioforestChainTransactionParseType)(transaction.type);
    const {
      typeName,
      i18n: typeNameI18n
    } = (0,_bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_5__.getBioforestChainTypeNameByBaseType)(this._chain, baseType, (0,_bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_5__.getBioforestChainTransactionParentAssetType)(transaction, this._chain));
    if (typeName && typeNameI18n) {
      name = typeNameI18n;
    }
    return name;
  }
  /** 获取交易的变动 */
  getShowTransactionAmount() {
    if (this.trs.chain === _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_5__.CHAIN_NAME.Tron) {
      let amount = '0';
      let assetType = this.chainInfo.symbol;
      const unknownTrs = "\u672A\u77E5";
      if (this.trs.type === 0) {
        amount = this.trs.amount;
        assetType = this.trs.assetSymbol;
      } else if (this.trs.type === 1) {
        amount = String(this.trs.transaction.amount);
      } else {
        amount = this.trs.transaction.value;
        assetType = this.trs.transaction.token_symbol;
      }
      if (isNaN(+amount)) {
        return this.amountChange = unknownTrs;
      }
      return this.amountChange = `${this.trs.senderId == this.userAddress ? '-' : '+'} ${_bnqkl_framework_pipes__WEBPACK_IMPORTED_MODULE_1__.AmountFixedPipe.transform(amount, this.trs.decimals, {
        removeZero: true,
        useGrouping: true
      })} ${assetType}`;
    } else if (this._chainV2Service.isBioforestChainByChainName(this.trs.chain)) {
      const res = (0,_bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_5__.analysisBioforestChainTransactionAssetChange)(this.trs.transaction, this.trs.decimals, {
        ...this.chainInfo,
        address: this.userAddress,
        chainName: this._chain
      }, true, false, true);
      if (res.detection.length > 0) {
        res.detection = res.detection.split(', ').join('<br />');
        res.detection = res.detection.replace(': ', ': <br />');
      }
      this.amountChangeCopyText = res.entityId;
      this.amountChange = res.detection;
      this.checkDpAsset();
    } else if (this.trs.chain === _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_5__.CHAIN_NAME.Binance || this.trs.chain === _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_5__.CHAIN_NAME.Ethereum) {
      let amount = '0';
      let assetType = this.chainInfo.symbol;
      const unknownTrs = "\u672A\u77E5";
      if (this.trs.type === 0) {
        amount = this.trs.amount;
        assetType = this.trs.assetSymbol;
      } else if (this.trs.type === 1) {
        amount = String(this.trs.transaction.value);
      } else {
        amount = this.trs.transaction.value;
        assetType = this.trs.transaction.tokenSymbol;
      }
      if (isNaN(+amount)) {
        return this.amountChange = unknownTrs;
      }
      return this.amountChange = `${this.trs.senderId.toLowerCase() == this.userAddress.toLowerCase() ? '-' : '+'} ${_bnqkl_framework_pipes__WEBPACK_IMPORTED_MODULE_1__.AmountFixedPipe.transform(amount, this.trs.decimals, {
        removeZero: true,
        useGrouping: true
      })} ${assetType}`;
    } else if (this.trs.chain === _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_5__.CHAIN_NAME.Bitcoin) {
      const {
        transaction
      } = this.trs;
      const vin = transaction.vin;
      const vout = transaction.vout;
      const inList = vin.filter(item => {
        return item.addresses.includes(this.userAddress);
      });
      const outList = vout.filter(item => {
        return item.addresses.includes(this.userAddress);
      });
      const inAmount_BI = inList.reduce((v, item) => {
        return v + BigInt(item.value);
      }, BigInt(0));
      const outAmount_BI = outList.reduce((v, item) => {
        return v + BigInt(item.value);
      }, BigInt(0));
      const amountChanges_BI = outAmount_BI - inAmount_BI;
      this.amountChange = `${amountChanges_BI <= BigInt(0) ? '' : '+'} ${_bnqkl_framework_pipes__WEBPACK_IMPORTED_MODULE_1__.AmountFixedPipe.transform(String(amountChanges_BI), this.trs.decimals, {
        removeZero: true,
        useGrouping: true
      })} ${this.chainInfo.symbol} <br /> ${this.userAddress}`;
      this.checkDpAsset();
      return;
    }
  }
  /** 滚动 */
  handleCurrActivityIndex(add) {
    const nextIndex = this.dialog_EntityImgs.currActivityIndex + 1 * (add ? 1 : -1);
    if (nextIndex >= 0 || nextIndex < this.dialog_EntityImgs.imgs.length) {
      this.dialog_EntityImgs.currActivityIndex = nextIndex;
    }
  }
  /** 当前激活的活动 */
  selectPointActivity(index) {
    this.dialog_EntityImgs.currActivityIndex = index;
  }
  /**
   * 显示同质化图片
   */
  showEntityImgs() {
    if (this.dialog_EntityImgs.imgs.length) {
      this.dialog_EntityImgs.currActivityIndex = 0;
      this.dialog_EntityImgs.is_open = true;
      this.cdRef.detectChanges();
    }
  }
  /** 检查是否为DP 需要展示图片 */
  checkDpAsset() {
    var _this = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      if (_this.amountChange && _this.amountChangeCopyText) {
        /** 检查是否有图片 */
        const dpService = _this.injectorForceGet(_bnqkl_wallet_base_services__WEBPACK_IMPORTED_MODULE_3__.WalletDpService);
        const dpDetails = yield dpService.getDpDetail(_this.amountChangeCopyText, _this._chain);
        if (dpDetails) {
          _this.amountChange = _this.amountChange.replace(new RegExp(_this.amountChangeCopyText, 'g'), `<span class='text-primary'>${_this.amountChangeCopyText}</span>`);
          _this.dialog_EntityImgs.imgs.push({
            imgLink: dpDetails.pic,
            content: dpDetails.dpName
          });
        }
      }
    })();
  }
  /** 获取手续费 */
  getShowTransactionmFee() {
    if (this.trs.chain === _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_5__.CHAIN_NAME.Tron) {
      if (this.trs.type === 0) {
        return '--';
      } else if (this.trs.type === 1) {
        const feeArray = [];
        const {
          fee,
          net_fee,
          net_usage,
          energy_fee,
          energy_usage
        } = this.trs.transaction;
        if (fee) {
          feeArray.push(`${_bnqkl_framework_pipes__WEBPACK_IMPORTED_MODULE_1__.AmountFixedPipe.transform(fee, this.chainInfo.decimals)} ${this.chainInfo.symbol}`);
        }
        if (net_fee + net_usage) {
          feeArray.push(`${net_fee + net_usage} ` + "\u5E26\u5BBD");
        }
        if (energy_fee + energy_usage) {
          feeArray.push(`${energy_fee + energy_usage} ` + "\u80FD\u91CF");
        }
        return feeArray.join(', ');
      } else {
        return '--';
      }
    } else if (this._chainV2Service.isBioforestChainByChainName(this.trs.chain)) {
      return `${_bnqkl_framework_pipes__WEBPACK_IMPORTED_MODULE_1__.AmountFixedPipe.transform(this.trs.transaction.fee, this.chainInfo.decimals)} ${this.chainInfo.symbol}`;
    } else if (this.trs.chain === _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_5__.CHAIN_NAME.Binance || this.trs.chain === _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_5__.CHAIN_NAME.Ethereum) {
      if (this.trs.type === 0) {
        return `${_bnqkl_framework_pipes__WEBPACK_IMPORTED_MODULE_1__.AmountFixedPipe.transform(this.trs.fee, this.chainInfo.decimals)} ${this.chainInfo.symbol}`;
      } else {
        return `${_bnqkl_framework_pipes__WEBPACK_IMPORTED_MODULE_1__.AmountFixedPipe.transform(String(BigInt(this.trs.transaction.gasUsed) * BigInt(this.trs.transaction.gasPrice)), this.chainInfo.decimals)} ${this.chainInfo.symbol}`;
      }
    }
  }
  dataInit() {
    var _this2 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this2.trs = JSON.parse(_this2.trsStringify);
      if (_this2.trs.chain === _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_5__.CHAIN_NAME.Bitcoin) {
        _this2.bitcoinTrs = _this2.trs.transaction;
      }
      switch (+_this2.status) {
        case _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_5__.TRANS_STATUS.EFFECTIVED:
          /// 超时
          _this2.iconName = 'trade-time';
          _this2.message = "\u8D85\u65F6";
          break;
        case _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_5__.TRANS_STATUS.BROADCASTED:
          /// pending
          _this2.iconName = 'trade-pending';
          _this2.message = "\u5E7F\u64AD\u4E2D";
          break;
        case _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_5__.TRANS_STATUS.CONFIRM:
          /// 成功
          _this2.iconName = 'trade-successful';
          _this2.message = "\u6210\u529F";
          break;
        default:
          /// 失败
          _this2.iconName = 'trade-failed';
          _this2.message = "\u5931\u8D25";
          break;
      }
      const chainInfo = _this2._chainV2Service.getChainInfo(_this2._chain);
      _this2.chainInfo = {
        ...chainInfo
      };
      _this2.trsInfo.senderId = _this2.trs.senderId;
      _this2.trsInfo.recipientId = _this2.trs.recipientId;
      _this2.getShowTransactionAmount();
    })();
  }
  getTronContractTrsFee() {
    var _this3 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      var _this3$trs;
      const trs = (_this3$trs = _this3.trs) !== null && _this3$trs !== void 0 ? _this3$trs : JSON.parse(_this3.trsStringify);
      if (trs.chain === _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_5__.CHAIN_NAME.Tron && trs.type === 2) {
        const tronService = _this3._chainV2Service.getChainService(_this3.trs.chain);
        const trsInfo = yield tronService.getTransactionByTxId(trs.transaction.txID);
        const {
          energy_fee,
          energy_usage_total,
          net_usage
        } = trsInfo.receipt;
        const feeArray = [];
        if (energy_fee) {
          feeArray.push(`${_bnqkl_framework_pipes__WEBPACK_IMPORTED_MODULE_1__.AmountFixedPipe.transform(energy_fee, _this3.chainInfo.decimals)} ${_this3.chainInfo.symbol}`);
        }
        if (net_usage) {
          feeArray.push(`${net_usage} ` + "\u5E26\u5BBD");
        }
        if (energy_usage_total) {
          feeArray.push(`${energy_usage_total} ` + "\u80FD\u91CF");
        }
        _this3.tronContractTrsFee = feeArray.join(', ');
      }
    })();
  }
  /** 跳转到区块链浏览器 */
  goScanDetail() {
    _bnqkl_framework_plugins_browser__WEBPACK_IMPORTED_MODULE_2__.Browser.open({
      url: this._chainV2Service.getChainScanTransactionByIdURL(this._chain, this.trs.signature)
    });
  }
}
_class = HomeTokenTransactionDetailsPage;
_class.ɵfac = /*@__PURE__*/(() => {
  let ɵHomeTokenTransactionDetailsPage_BaseFactory;
  return function HomeTokenTransactionDetailsPage_Factory(t) {
    return (ɵHomeTokenTransactionDetailsPage_BaseFactory || (ɵHomeTokenTransactionDetailsPage_BaseFactory = _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵgetInheritedFactory"](_class)))(t || _class);
  };
})();
_class.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵdefineComponent"]({
  type: _class,
  selectors: [["w-home-token-transaction-details-page"]],
  standalone: true,
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵInheritDefinitionFeature"], _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵStandaloneFeature"]],
  decls: 9,
  vars: 7,
  consts: () => {
    let i18n_0;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_TRANSACTION_DETAILS$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_HOME_TOKEN_TRANSACTION_DETAILS_HOME_TOKEN_TRANSACTION_DETAILS_COMPONENT_TS_1 = goog.getMsg("Transaction Details");
      i18n_0 = MSG_EXTERNAL_TRANSACTION_DETAILS$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_HOME_TOKEN_TRANSACTION_DETAILS_HOME_TOKEN_TRANSACTION_DETAILS_COMPONENT_TS_1;
    } else {
      i18n_0 = "\u4EA4\u6613\u8BE6\u60C5";
    }
    let i18n_2;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_EVENT$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_HOME_TOKEN_TRANSACTION_DETAILS_HOME_TOKEN_TRANSACTION_DETAILS_COMPONENT_TS___3 = goog.getMsg("Event");
      i18n_2 = MSG_EXTERNAL_EVENT$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_HOME_TOKEN_TRANSACTION_DETAILS_HOME_TOKEN_TRANSACTION_DETAILS_COMPONENT_TS___3;
    } else {
      i18n_2 = "\u4E8B\u4EF6";
    }
    let i18n_4;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_FEE$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_HOME_TOKEN_TRANSACTION_DETAILS_HOME_TOKEN_TRANSACTION_DETAILS_COMPONENT_TS___5 = goog.getMsg("Fee");
      i18n_4 = MSG_EXTERNAL_FEE$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_HOME_TOKEN_TRANSACTION_DETAILS_HOME_TOKEN_TRANSACTION_DETAILS_COMPONENT_TS___5;
    } else {
      i18n_4 = "\u77FF\u5DE5\u8D39";
    }
    let i18n_6;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_RECEIVER$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_HOME_TOKEN_TRANSACTION_DETAILS_HOME_TOKEN_TRANSACTION_DETAILS_COMPONENT_TS___7 = goog.getMsg("Receiver");
      i18n_6 = MSG_EXTERNAL_RECEIVER$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_HOME_TOKEN_TRANSACTION_DETAILS_HOME_TOKEN_TRANSACTION_DETAILS_COMPONENT_TS___7;
    } else {
      i18n_6 = "\u6536\u6B3E\u5730\u5740";
    }
    let i18n_8;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_PAYER$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_HOME_TOKEN_TRANSACTION_DETAILS_HOME_TOKEN_TRANSACTION_DETAILS_COMPONENT_TS___9 = goog.getMsg("Payer");
      i18n_8 = MSG_EXTERNAL_PAYER$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_HOME_TOKEN_TRANSACTION_DETAILS_HOME_TOKEN_TRANSACTION_DETAILS_COMPONENT_TS___9;
    } else {
      i18n_8 = "\u4ED8\u6B3E\u5730\u5740";
    }
    let i18n_10;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_TRANSACTION_HASH$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_HOME_TOKEN_TRANSACTION_DETAILS_HOME_TOKEN_TRANSACTION_DETAILS_COMPONENT_TS___11 = goog.getMsg("Transaction Hash");
      i18n_10 = MSG_EXTERNAL_TRANSACTION_HASH$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_HOME_TOKEN_TRANSACTION_DETAILS_HOME_TOKEN_TRANSACTION_DETAILS_COMPONENT_TS___11;
    } else {
      i18n_10 = "\u4EA4\u6613\u54C8\u5E0C";
    }
    let i18n_12;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_FOR_OVERTIME_TRANSACTION_TIPS$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_HOME_TOKEN_TRANSACTION_DETAILS_HOME_TOKEN_TRANSACTION_DETAILS_COMPONENT_TS___13 = goog.getMsg(" For overtime transactions, you can check whether the transaction is successful through the blockchain explorer. ");
      i18n_12 = MSG_EXTERNAL_FOR_OVERTIME_TRANSACTION_TIPS$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_HOME_TOKEN_TRANSACTION_DETAILS_HOME_TOKEN_TRANSACTION_DETAILS_COMPONENT_TS___13;
    } else {
      i18n_12 = "\u5BF9\u4E8E\u8D85\u65F6\u4EA4\u6613\uFF0C\u60A8\u53EF\u4EE5\u901A\u8FC7\u533A\u5757\u94FE\u6D4F\u89C8\u5668\u67E5\u770B\u4EA4\u6613\u662F\u5426\u6210\u529F\u3002";
    }
    let i18n_14;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_TRANSACTION_DETAILS$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_HOME_TOKEN_TRANSACTION_DETAILS_HOME_TOKEN_TRANSACTION_DETAILS_COMPONENT_TS___15 = goog.getMsg("Transaction details");
      i18n_14 = MSG_EXTERNAL_TRANSACTION_DETAILS$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_HOME_TOKEN_TRANSACTION_DETAILS_HOME_TOKEN_TRANSACTION_DETAILS_COMPONENT_TS___15;
    } else {
      i18n_14 = "\u4EA4\u6613\u8BE6\u60C5";
    }
    let i18n_16;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_MORE$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_HOME_TOKEN_TRANSACTION_DETAILS_HOME_TOKEN_TRANSACTION_DETAILS_COMPONENT_TS___17 = goog.getMsg("More");
      i18n_16 = MSG_EXTERNAL_MORE$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_HOME_TOKEN_TRANSACTION_DETAILS_HOME_TOKEN_TRANSACTION_DETAILS_COMPONENT_TS___17;
    } else {
      i18n_16 = "\u66F4\u591A";
    }
    let i18n_18;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_MORE$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_HOME_TOKEN_TRANSACTION_DETAILS_HOME_TOKEN_TRANSACTION_DETAILS_COMPONENT_TS___19 = goog.getMsg("More");
      i18n_18 = MSG_EXTERNAL_MORE$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_HOME_TOKEN_TRANSACTION_DETAILS_HOME_TOKEN_TRANSACTION_DETAILS_COMPONENT_TS___19;
    } else {
      i18n_18 = "\u66F4\u591A";
    }
    let i18n_24;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_QUERY_IN_BLOCKCHAIN_EXPLORER$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_HOME_TOKEN_TRANSACTION_DETAILS_HOME_TOKEN_TRANSACTION_DETAILS_COMPONENT_TS__25 = goog.getMsg(" Query In Blockchain Explorer ");
      i18n_24 = MSG_EXTERNAL_QUERY_IN_BLOCKCHAIN_EXPLORER$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_HOME_TOKEN_TRANSACTION_DETAILS_HOME_TOKEN_TRANSACTION_DETAILS_COMPONENT_TS__25;
    } else {
      i18n_24 = "\u5728\u533A\u5757\u94FE\u6D4F\u89C8\u5668\u4E2D\u67E5\u8BE2";
    }
    return [["headerTitle", i18n_0, 3, "contentSafeArea"], [1, "flex", "flex-col", "items-center", "justify-center"], [1, "mb-2", "mt-8", "text-7xl", 3, "name"], [1, "text-title", "text-base"], [4, "ngIf"], ["footer", "", "class", "flex items-center justify-center", 4, "ngIf"], [3, "panelClass", "isOpen", "isOpenChange"], [1, "text-subtext", "mb-8", "text-xs"], ["class", "mb-6 w-full text-sm", 4, "ngIf"], ["class", "mb-8 w-full text-sm", 4, "ngIf"], [1, "mb-6", "w-full", "text-sm"], [1, "text-title", "font-bold"], i18n_2, [1, "text-text", "rounded-2", "bg-env", "mt-2", "overflow-hidden", "text-ellipsis", "whitespace-nowrap", "break-all", "p-2"], [1, "text-text", "rounded-2", "bg-env", "mt-2", "flex", "max-h-32", "items-start", "justify-between", "overflow-x-hidden", "overflow-y-scroll", "break-all", "p-2"], [3, "innerHtml", "click"], ["bnRippleButton", "", "class", "text-title mt-1 shrink-0", 3, "wClickToCopy", 4, "ngIf"], ["bnRippleButton", "", 1, "text-title", "mt-1", "shrink-0", 3, "wClickToCopy"], ["name", "copy", 1, "icon-4", "ml-2"], i18n_4, [1, "text-text", "rounded-2", "bg-env", "mt-2", "flex", "items-center", "justify-between", "p-2"], i18n_6, ["bnRippleButton", "", 1, "text-title", "mt-1", "flex", "shrink-0", "items-center", "self-start", 3, "wClickToCopy"], i18n_8, i18n_10, [1, "text-text", "rounded-2", "bg-env", "mt-2", "flex", "items-center", "justify-between", "break-all", "p-2"], [1, "mb-8", "w-full", "text-sm"], [1, "text-warn", "font-bold"], i18n_12, [1, "w-full", "text-sm"], i18n_14, [1, "text-text", "rounded-2", "bg-env", "mt-2", "flex", "items-center", "justify-between", "break-all", "py-2", "px-4"], ["multi", "", 1, "w-full"], ["hideToggle", "", 1, "_trs-expansion-panel"], [1, "!p-0"], [1, "min-h-13", "text-base", "!m-0"], [1, "w-full", "pb-2", "border-b-tiny", "border-white"], [1, "flex", "justify-end", "items-center"], [1, "text-primary"], i18n_16, ["name", "right", 1, "icon-4", "ml-1"], [1, "text-subtext"], [1, "text-subtext", "flex", "items-center", "justify-between"], ["bnRippleButton", "", 1, "text-subtext", "mt-1", "shrink-0", 3, "wClickToCopy", "click"], [1, "font-bold", "text-title"], ["matExpansionPanelContent", ""], ["name", "dp-expand", 1, "icon-6", "my-2"], [1, "text-text", "rounded-2", "bg-env", "flex", "items-center", "justify-between", "break-all", "py-2", "px-4"], i18n_18, [1, "flex", "justify-around", "items-start", "text-base", "flex-wrap", "w-full", "max-h-[518px]"], ["class", "w-full py-2 border-white", 3, "border-b-tiny"], [1, "w-full", "py-2", "border-white"], ["bnRippleButton", "", 1, "text-subtext", "mt-1", "shrink-0", 3, "wClickToCopy"], ["footer", "", 1, "flex", "items-center", "justify-center"], ["bnRippleButton", "", 1, "text-primary", "mt-3", "text-center", "text-xs", 3, "click"], i18n_24, ["wTabGroup", "", 1, "no-scrollbar", "relative", "z-[1]", "grid", "h-full", "w-full", "flex-grow", "grid-flow-col", "overflow-x-scroll", 3, "selectedIndex", "selectedIndexChange$"], ["name", "back", "class", "icon-5 text-primary absolute left-2 top-0 z-10", 3, "click", 4, "ngIf"], ["name", "back", "class", "icon-5 text-primary absolute right-2 top-0 z-10 rotate-180", 3, "click", 4, "ngIf"], [1, "absolute", "-bottom-10", "left-1/2", "-translate-x-1/2", 3, "click"], ["name", "trade-failed", 1, "icon-5", 3, "ngStyle"], ["wTab", "", 1, "_slide-item", "w-cqw-100", "relative", "flex", "h-full", "flex-col", "items-center", "justify-start", "overflow-hidden", "p-10"], [1, "h-full", "w-full", 3, "src"], ["name", "back", 1, "icon-5", "text-primary", "absolute", "left-2", "top-0", "z-10", 3, "click"], ["name", "back", 1, "icon-5", "text-primary", "absolute", "right-2", "top-0", "z-10", "rotate-180", 3, "click"], ["class", "_slide-item w-cqw-100 relative flex h-full flex-col items-center justify-start overflow-hidden p-10", "wTab", ""]];
  },
  template: function HomeTokenTransactionDetailsPage_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](0, "common-page", 0)(1, "div", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelement"](2, "w-icon", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](3, "div", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtext"](4);
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtemplate"](5, HomeTokenTransactionDetailsPage_ng_container_5_Template, 12, 11, "ng-container", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtemplate"](6, HomeTokenTransactionDetailsPage_div_6_Template, 3, 0, "div", 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](7, "common-template-dialog-opener", 6);
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵlistener"]("isOpenChange", function HomeTokenTransactionDetailsPage_Template_common_template_dialog_opener_isOpenChange_7_listener($event) {
        return ctx.dialog_EntityImgs.is_open = $event;
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtemplate"](8, HomeTokenTransactionDetailsPage_ng_template_8_Template, 8, 8, "ng-template");
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵproperty"]("contentSafeArea", true);
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵproperty"]("name", ctx.iconName);
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtextInterpolate"](ctx.message);
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵproperty"]("ngIf", !!ctx.trs);
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵproperty"]("ngIf", +ctx.status === ctx.TRANS_STATUS.CONFIRM);
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵproperty"]("panelClass", "--overflow-y-display")("isOpen", ctx.dialog_EntityImgs.is_open);
    }
  },
  dependencies: [_modules_page_module__WEBPACK_IMPORTED_MODULE_6__.CommonPageModule, _libs_bnf_components_ripple_button_ripple_button_directive__WEBPACK_IMPORTED_MODULE_7__.RippleButtonDirective, _libs_bnf_directives_click_to_copy_directive__WEBPACK_IMPORTED_MODULE_8__.ClickToCopyDirective, _libs_bnf_directives_tab_directive__WEBPACK_IMPORTED_MODULE_9__.TabGroupDirective, _libs_bnf_directives_tab_directive__WEBPACK_IMPORTED_MODULE_9__.TabDirective, _angular_common__WEBPACK_IMPORTED_MODULE_18__.NgIf, _angular_common__WEBPACK_IMPORTED_MODULE_18__.NgStyle, _libs_bnf_modules_dialog_components_template_dialog_opener_template_dialog_opener_component__WEBPACK_IMPORTED_MODULE_10__.TemplateDialogOpenerComponent, _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_11__.CommonPageComponent, _components_icon_icon_component__WEBPACK_IMPORTED_MODULE_12__.IconComponent, _libs_bnf_pipes_day_format_day_format_pipe__WEBPACK_IMPORTED_MODULE_13__.DayFormatPipe, _pipes_color_color_pipe__WEBPACK_IMPORTED_MODULE_14__.ColorPipe, _libs_bnf_pipes_address_hidden_address_hidden_pipe__WEBPACK_IMPORTED_MODULE_15__.AddressHiddenPipe, _libs_bnf_pipes_amountFixed_amount_fixed_pipe__WEBPACK_IMPORTED_MODULE_16__.AmountFixedPipe, _angular_material_expansion__WEBPACK_IMPORTED_MODULE_19__.MatExpansionModule, _angular_material_expansion__WEBPACK_IMPORTED_MODULE_19__.MatAccordion, _angular_material_expansion__WEBPACK_IMPORTED_MODULE_19__.MatExpansionPanel, _angular_material_expansion__WEBPACK_IMPORTED_MODULE_19__.MatExpansionPanelHeader, _angular_material_expansion__WEBPACK_IMPORTED_MODULE_19__.MatExpansionPanelTitle, _angular_material_expansion__WEBPACK_IMPORTED_MODULE_19__.MatExpansionPanelContent],
  styles: ["[_nghost-%COMP%]     ._trs-expansion-panel {\n  box-shadow: none !important;\n}\n[_nghost-%COMP%]     ._trs-expansion-panel w-icon[name=right] {\n  transform: rotateZ(0);\n  transition: transform 300ms;\n}\n[_nghost-%COMP%]     ._trs-expansion-panel.mat-expanded w-icon[name=right] {\n  transform: rotateZ(90deg);\n}\n[_nghost-%COMP%]     ._trs-expansion-panel .mat-expansion-panel-body {\n  padding-inline: 0 !important;\n}\n[_nghost-%COMP%]     ._trs-expansion-panel .mat-content.mat-content-hide-toggle {\n  margin-right: 0 !important;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL2FwcHMvd2FsbGV0L3NyYy9wYWdlcy9tbmVtb25pYy9wYWdlcy9ob21lLXRva2VuLXRyYW5zYWN0aW9uLWRldGFpbHMvaG9tZS10b2tlbi10cmFuc2FjdGlvbi1kZXRhaWxzLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUVNO0VBQ0UsMkJBQUE7QUFEUjtBQUVRO0VBQ0UscUJBQUE7RUFDQSwyQkFBQTtBQUFWO0FBR1U7RUFDRSx5QkFBQTtBQURaO0FBSVE7RUFDRSw0QkFBQTtBQUZWO0FBSVE7RUFDRSwwQkFBQTtBQUZWIiwic291cmNlc0NvbnRlbnQiOlsiOmhvc3Qge1xyXG4gICAgOjpuZy1kZWVwIHtcclxuICAgICAgLl90cnMtZXhwYW5zaW9uLXBhbmVsIHtcclxuICAgICAgICBib3gtc2hhZG93OiBub25lICFpbXBvcnRhbnQ7XHJcbiAgICAgICAgdy1pY29uW25hbWU9XCJyaWdodFwiXSB7XHJcbiAgICAgICAgICB0cmFuc2Zvcm06IHJvdGF0ZVooMCk7XHJcbiAgICAgICAgICB0cmFuc2l0aW9uOiB0cmFuc2Zvcm0gMzAwbXM7XHJcbiAgICAgICAgfVxyXG4gICAgICAgICYubWF0LWV4cGFuZGVkIHtcclxuICAgICAgICAgIHctaWNvbltuYW1lPVwicmlnaHRcIl0ge1xyXG4gICAgICAgICAgICB0cmFuc2Zvcm06IHJvdGF0ZVooOTBkZWcpO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICAubWF0LWV4cGFuc2lvbi1wYW5lbC1ib2R5IHtcclxuICAgICAgICAgIHBhZGRpbmctaW5saW5lOiAwICFpbXBvcnRhbnQ7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIC5tYXQtY29udGVudC5tYXQtY29udGVudC1oaWRlLXRvZ2dsZSB7XHJcbiAgICAgICAgICBtYXJnaW4tcmlnaHQ6IDAgIWltcG9ydGFudDtcclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9XHJcbiAgIl0sInNvdXJjZVJvb3QiOiIifQ== */"],
  changeDetection: 0
});
(0,tslib__WEBPACK_IMPORTED_MODULE_20__.__decorate)([HomeTokenTransactionDetailsPage.State(), HomeTokenTransactionDetailsPage.QueryParam('trsStringify'), (0,tslib__WEBPACK_IMPORTED_MODULE_20__.__metadata)("design:type", Object)], HomeTokenTransactionDetailsPage.prototype, "trsStringify", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_20__.__decorate)([HomeTokenTransactionDetailsPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_20__.__metadata)("design:type", Object)], HomeTokenTransactionDetailsPage.prototype, "trs", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_20__.__decorate)([HomeTokenTransactionDetailsPage.State(), HomeTokenTransactionDetailsPage.QueryParam('userAddress'), (0,tslib__WEBPACK_IMPORTED_MODULE_20__.__metadata)("design:type", Object)], HomeTokenTransactionDetailsPage.prototype, "userAddress", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_20__.__decorate)([HomeTokenTransactionDetailsPage.State(), HomeTokenTransactionDetailsPage.QueryParam('decimals'), (0,tslib__WEBPACK_IMPORTED_MODULE_20__.__metadata)("design:type", Object)], HomeTokenTransactionDetailsPage.prototype, "decimals", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_20__.__decorate)([HomeTokenTransactionDetailsPage.QueryParam('status'), (0,tslib__WEBPACK_IMPORTED_MODULE_20__.__metadata)("design:type", Object)], HomeTokenTransactionDetailsPage.prototype, "status", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_20__.__decorate)([HomeTokenTransactionDetailsPage.QueryParam('chain'), (0,tslib__WEBPACK_IMPORTED_MODULE_20__.__metadata)("design:type", String)], HomeTokenTransactionDetailsPage.prototype, "_chain", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_20__.__decorate)([HomeTokenTransactionDetailsPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_20__.__metadata)("design:type", Object)], HomeTokenTransactionDetailsPage.prototype, "chainInfo", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_20__.__decorate)([HomeTokenTransactionDetailsPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_20__.__metadata)("design:type", String)], HomeTokenTransactionDetailsPage.prototype, "iconName", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_20__.__decorate)([HomeTokenTransactionDetailsPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_20__.__metadata)("design:type", Object)], HomeTokenTransactionDetailsPage.prototype, "message", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_20__.__decorate)([HomeTokenTransactionDetailsPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_20__.__metadata)("design:type", Object)], HomeTokenTransactionDetailsPage.prototype, "tronContractTrsFee", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_20__.__decorate)([HomeTokenTransactionDetailsPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_20__.__metadata)("design:type", Object)], HomeTokenTransactionDetailsPage.prototype, "amountChange", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_20__.__decorate)([HomeTokenTransactionDetailsPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_20__.__metadata)("design:type", Object)], HomeTokenTransactionDetailsPage.prototype, "amountChangeCopyText", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_20__.__decorate)([HomeTokenTransactionDetailsPage.States(), (0,tslib__WEBPACK_IMPORTED_MODULE_20__.__metadata)("design:type", Object)], HomeTokenTransactionDetailsPage.prototype, "dialog_EntityImgs", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_20__.__decorate)([HomeTokenTransactionDetailsPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_20__.__metadata)("design:type", Object)], HomeTokenTransactionDetailsPage.prototype, "trsInfo", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_20__.__decorate)([HomeTokenTransactionDetailsPage.OnInit(), (0,tslib__WEBPACK_IMPORTED_MODULE_20__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_20__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_20__.__metadata)("design:returntype", Promise)], HomeTokenTransactionDetailsPage.prototype, "dataInit", null);
(0,tslib__WEBPACK_IMPORTED_MODULE_20__.__decorate)([HomeTokenTransactionDetailsPage.OnReady(), (0,tslib__WEBPACK_IMPORTED_MODULE_20__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_20__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_20__.__metadata)("design:returntype", Promise)], HomeTokenTransactionDetailsPage.prototype, "getTronContractTrsFee", null);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (HomeTokenTransactionDetailsPage);

/***/ })

}]);
//# sourceMappingURL=apps_wallet_src_pages_mnemonic_pages_home-token-transaction-details_home-token-transaction-de-7c513e.js.map