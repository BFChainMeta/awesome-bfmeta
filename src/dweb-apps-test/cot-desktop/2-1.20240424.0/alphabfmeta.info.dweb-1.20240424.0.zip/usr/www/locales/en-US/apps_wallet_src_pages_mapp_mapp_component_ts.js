"use strict";
(self["webpackChunkwallet"] = self["webpackChunkwallet"] || []).push([["apps_wallet_src_pages_mapp_mapp_component_ts"],{

/***/ 1262:
/*!******************************************************!*\
  !*** ./apps/wallet/src/pages/mapp/mapp.component.ts ***!
  \******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   MappPage: () => (/* binding */ MappPage),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! tslib */ 90505);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 61039);
/* harmony import */ var _angular_material_button__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/material/button */ 12300);
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/platform-browser */ 15840);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ 56776);
/* harmony import */ var _bnqkl_framework_modules_mapp__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @bnqkl/framework/modules/mapp */ 97600);
/* harmony import */ var _modules_page_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ~modules/page.module */ 77538);
/* harmony import */ var _libs_bnf_modules_bottom_sheet_components_bottom_sheet_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../libs/bnf/modules/bottom-sheet/components/bottom-sheet.component */ 94072);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common */ 6729);
/* harmony import */ var _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../../libs/bnf/modules/page/common-page/common-page.component */ 62052);
var _class;











const _c0 = ["frame"];
function MappPage_iframe_6_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](0, "iframe", 7, 8);
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("src", ctx_r0.mappUrl, _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵsanitizeResourceUrl"]);
  }
}
function MappPage_ng_template_8_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵi18n"](1, 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
  }
}
const _c5 = a0 => [a0];
/** 钱包小程序主页面 */
class MappPage extends _modules_page_module__WEBPACK_IMPORTED_MODULE_1__.CommonPageBase {
  constructor() {
    super(...arguments);
    /** for safe url */
    this.sanitizer = (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.inject)(_angular_platform_browser__WEBPACK_IMPORTED_MODULE_5__.DomSanitizer);
    /** 启动标志 */
    this.mappStarted = false;
    /** 监听事件handle */
    this.listenerMap = new Set();
    /** 通信实例 */
    this._com = new _bnqkl_framework_modules_mapp__WEBPACK_IMPORTED_MODULE_0__.CommunicationDuplexManager((message, transfer) => this.mappFrame && this.mappFrame.contentWindow.postMessage(message, '*', transfer), handle => {
      this.listenerMap.add(handle);
      window.addEventListener('message', handle);
    }, {
      beforeOnMessage: (event, next) => {
        next();
      },
      cmd_list: [{
        cmd: 'getEnv',
        handle: () => {
          return {
            env: 'from mapp host'
          };
        }
      }, {
        cmd: 'bootstrap',
        handle: opts => {
          if (this.mappStarted !== true) {
            this.mappStarted = opts.start;
          }
          return true;
        }
      }, {
        cmd: 'setTitle',
        handle: title => {
          this.headerTitle = title;
          return true;
        }
      }]
    });
    /** 小程序标题 */
    this.headerTitle = 'MAPP HOST';
    /** 弹窗 */
    this.test = false;
  }
  /** 取消监听 */
  removeListener() {
    this.listenerMap.forEach(handle => {
      window.removeEventListener('message', handle);
    });
  }
  get mappFrame() {
    return this.frameEleRef && this.frameEleRef.nativeElement;
  }
  /** 初始化小程序 */
  initMappInfo() {
    var _this$_data;
    this.mappUrl = this.sanitizer.bypassSecurityTrustResourceUrl(((_this$_data = this._data) === null || _this$_data === void 0 ? void 0 : _this$_data.mappUrl) || '127.0.0.1:8000');
  }
  /** 进入小程序 */
  enterMapp() {
    this.mappStarted = true;
  }
  textdialog() {
    this.test = true;
    // this.confirm({headerTitle:'121212',bodyMessage:"fddf"});
  }
}
_class = MappPage;
_class.ɵfac = /*@__PURE__*/(() => {
  let ɵMappPage_BaseFactory;
  return function MappPage_Factory(t) {
    return (ɵMappPage_BaseFactory || (ɵMappPage_BaseFactory = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵgetInheritedFactory"](_class)))(t || _class);
  };
})();
_class.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineComponent"]({
  type: _class,
  selectors: [["w-mapp-page"]],
  viewQuery: function MappPage_Query(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵviewQuery"](_c0, 5);
    }
    if (rf & 2) {
      let _t;
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵloadQuery"]()) && (ctx.frameEleRef = _t.first);
    }
  },
  standalone: true,
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵInheritDefinitionFeature"], _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵStandaloneFeature"]],
  decls: 9,
  vars: 10,
  consts: () => {
    let i18n_1;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_354145559120776923$$APPS_WALLET_SRC_PAGES_MAPP_MAPP_COMPONENT_TS_2 = goog.getMsg("{$startTagDiv}\u6B63\u5728\u8FDB\u5165\u7B2C\u4E09\u65B9\u9875\u9762{$closeTagDiv}{$startTagButton}\u624B\u52A8\u8FDB\u5165{$closeTagButton}", {
        "closeTagButton": "\uFFFD/#4\uFFFD",
        "closeTagDiv": "\uFFFD/#3\uFFFD",
        "startTagButton": "\uFFFD#4\uFFFD",
        "startTagDiv": "\uFFFD#3\uFFFD"
      }, {
        original_code: {
          "closeTagButton": "</button>",
          "closeTagDiv": "</div>",
          "startTagButton": "<button class=\"bg-primary rounded-md text-white\" (click)=\"enterMapp()\">",
          "startTagDiv": "<div>"
        }
      });
      i18n_1 = MSG_EXTERNAL_354145559120776923$$APPS_WALLET_SRC_PAGES_MAPP_MAPP_COMPONENT_TS_2;
    } else {
      i18n_1 = "" + "\uFFFD#3\uFFFD" + "\u6B63\u5728\u8FDB\u5165\u7B2C\u4E09\u65B9\u9875\u9762" + "\uFFFD/#3\uFFFD" + "" + "\uFFFD#4\uFFFD" + "\u624B\u52A8\u8FDB\u5165" + "\uFFFD/#4\uFFFD" + "";
    }
    let i18n_3;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_2641904634440349356$$APPS_WALLET_SRC_PAGES_MAPP_MAPP_COMPONENT_TS__4 = goog.getMsg("\u6D4B\u8BD5");
      i18n_3 = MSG_EXTERNAL_2641904634440349356$$APPS_WALLET_SRC_PAGES_MAPP_MAPP_COMPONENT_TS__4;
    } else {
      i18n_3 = "\u6D4B\u8BD5";
    }
    return [[3, "headerBackground", "headerButtonColor", "titleColor", "headerTitle"], [1, "visible", "absolute", "h-full", "w-full", "bg-white", 3, "ngClass"], i18n_1, [1, "bg-primary", "rounded-md", "text-white", 3, "click"], [1, "h-full", "w-full"], ["class", "h-full w-full", 3, "src", 4, "ngIf"], [3, "isOpen", "panelClass", "isOpenChange"], [1, "h-full", "w-full", 3, "src"], ["frame", ""], [1, "h-full", "bg-white"], i18n_3];
  },
  template: function MappPage_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "common-page", 0)(1, "div", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵi18nStart"](2, 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](3, "div");
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](4, "button", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function MappPage_Template_button_click_4_listener() {
        return ctx.enterMapp();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵi18nEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](5, "div", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](6, MappPage_iframe_6_Template, 2, 1, "iframe", 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](7, "common-bottom-sheet", 6);
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("isOpenChange", function MappPage_Template_common_bottom_sheet_isOpenChange_7_listener($event) {
        return ctx.test = $event;
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](8, MappPage_ng_template_8_Template, 2, 0, "ng-template");
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("headerBackground", "primary")("headerButtonColor", "light")("titleColor", "white")("headerTitle", ctx.headerTitle);
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpureFunction1"](8, _c5, ctx.mappStarted ? "invisible opacity-0 transition-all duration-500 " : ""));
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](5);
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx.mappUrl);
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("isOpen", ctx.test)("panelClass", "h-1/2");
    }
  },
  dependencies: [_modules_page_module__WEBPACK_IMPORTED_MODULE_1__.CommonPageModule, _libs_bnf_modules_bottom_sheet_components_bottom_sheet_component__WEBPACK_IMPORTED_MODULE_2__.BottomSheetComponent, _angular_common__WEBPACK_IMPORTED_MODULE_6__.NgClass, _angular_common__WEBPACK_IMPORTED_MODULE_6__.NgIf, _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_3__.CommonPageComponent, _angular_router__WEBPACK_IMPORTED_MODULE_7__.RouterModule, _angular_material_button__WEBPACK_IMPORTED_MODULE_8__.MatButtonModule],
  styles: ["/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsInNvdXJjZVJvb3QiOiIifQ== */"],
  changeDetection: 0
});
(0,tslib__WEBPACK_IMPORTED_MODULE_9__.__decorate)([MappPage.QueryParams(), (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__metadata)("design:type", Object)], MappPage.prototype, "_data", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_9__.__decorate)([MappPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__metadata)("design:type", Object)], MappPage.prototype, "mappStarted", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_9__.__decorate)([MappPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__metadata)("design:type", Object)], MappPage.prototype, "mappUrl", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_9__.__decorate)([MappPage.OnDestroy(), (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__metadata)("design:returntype", void 0)], MappPage.prototype, "removeListener", null);
(0,tslib__WEBPACK_IMPORTED_MODULE_9__.__decorate)([MappPage.OnReady(), (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__metadata)("design:returntype", void 0)], MappPage.prototype, "initMappInfo", null);
(0,tslib__WEBPACK_IMPORTED_MODULE_9__.__decorate)([MappPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__metadata)("design:type", Object)], MappPage.prototype, "headerTitle", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_9__.__decorate)([MappPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__metadata)("design:type", Object)], MappPage.prototype, "test", void 0);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MappPage);

/***/ })

}]);
//# sourceMappingURL=apps_wallet_src_pages_mapp_mapp_component_ts.js.map