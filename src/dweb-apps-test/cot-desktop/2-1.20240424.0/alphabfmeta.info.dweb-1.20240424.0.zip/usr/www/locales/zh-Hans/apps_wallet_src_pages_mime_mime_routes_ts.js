"use strict";
(self["webpackChunkwallet"] = self["webpackChunkwallet"] || []).push([["apps_wallet_src_pages_mime_mime_routes_ts"],{

/***/ 64306:
/*!***************************************************!*\
  !*** ./apps/wallet/src/pages/mime/mime.routes.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   routes: () => (/* binding */ routes)
/* harmony export */ });
/* harmony import */ var _pages_modify_address_modify_address_resolver__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./pages/modify-address/modify-address.resolver */ 69796);

const routes = [{
  path: '',
  title: "\u6211",
  loadComponent: () => Promise.all(/*! import() */[__webpack_require__.e("default-apps_wallet_src_pages_mime_pages_verify-fingerprint_verify-fingerprint_component_ts"), __webpack_require__.e("default-apps_wallet_src_pages_mnemonic_pages_mnemonic-confirm-backup_mnemonic-confirm-backup_-f6fc5f"), __webpack_require__.e("default-apps_wallet_src_pages_home_pages_home-main-wallet-edit_home-main-wallet-edit_component_ts"), __webpack_require__.e("default-apps_wallet_src_pages_mime_mime_component_ts"), __webpack_require__.e("apps_wallet_src_helpers_utils_index_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./mime.component */ 30381))
}, {
  path: 'mime-language',
  title: "\u8BED\u8A00",
  loadComponent: () => __webpack_require__.e(/*! import() */ "apps_wallet_src_pages_mime_pages_mime-language_mime-language_component_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/mime-language/mime-language.component */ 98702))
}, {
  path: 'address-book',
  title: "\u5730\u5740\u7C3F",
  loadComponent: () => Promise.all(/*! import() */[__webpack_require__.e("default-apps_wallet_src_pages_scanner_scanner_component_ts"), __webpack_require__.e("default-apps_wallet_src_pages_mime_pages_modify-address_modify-address_component_ts"), __webpack_require__.e("default-apps_wallet_src_pages_mime_pages_address-book_address-book_component_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./pages/address-book/address-book.component */ 35866))
}, {
  path: 'modify-address',
  title: "\u7F16\u8F91\u5730\u5740",
  loadComponent: () => Promise.all(/*! import() */[__webpack_require__.e("default-apps_wallet_src_pages_scanner_scanner_component_ts"), __webpack_require__.e("default-apps_wallet_src_pages_mime_pages_modify-address_modify-address_component_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./pages/modify-address/modify-address.component */ 48072)),
  resolve: _pages_modify_address_modify_address_resolver__WEBPACK_IMPORTED_MODULE_0__.modifyAddressResolver
}, {
  path: 'select-address-type',
  title: "\u9009\u62E9\u5730\u5740\u7C7B\u578B",
  loadComponent: () => __webpack_require__.e(/*! import() */ "apps_wallet_src_pages_mime_pages_select-address-type_select-address-type_component_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/select-address-type/select-address-type.component */ 26390))
}, {
  path: 'verify-fingerprint',
  title: "\u6307\u7EB9\u9A8C\u8BC1",
  loadComponent: () => __webpack_require__.e(/*! import() */ "default-apps_wallet_src_pages_mime_pages_verify-fingerprint_verify-fingerprint_component_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/verify-fingerprint/verify-fingerprint.component */ 5780))
}, {
  path: 'application-lock',
  title: "\u5E94\u7528\u9501",
  loadComponent: () => Promise.all(/*! import() */[__webpack_require__.e("default-apps_wallet_src_pages_mime_pages_verify-fingerprint_verify-fingerprint_component_ts"), __webpack_require__.e("default-apps_wallet_src_pages_wallet-sign-in_wallet-sign-in_component_ts"), __webpack_require__.e("apps_wallet_src_pages_mime_pages_application-lock_application-lock_component_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./pages/application-lock/application-lock.component */ 18296))
}, {
  path: 'mapp',
  title: 'MAPP',
  loadComponent: () => __webpack_require__.e(/*! import() */ "apps_wallet_src_pages_mapp_mapp_component_ts").then(__webpack_require__.bind(__webpack_require__, /*! ~pages/mapp/mapp.component */ 1262))
}];
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (routes);

/***/ }),

/***/ 69796:
/*!************************************************************************************!*\
  !*** ./apps/wallet/src/pages/mime/pages/modify-address/modify-address.resolver.ts ***!
  \************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   addressResolver: () => (/* binding */ addressResolver),
/* harmony export */   modifyAddressResolver: () => (/* binding */ modifyAddressResolver)
/* harmony export */ });
/* harmony import */ var D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 52542);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 61039);
/* harmony import */ var _bnqkl_framework_helpers__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @bnqkl/framework/helpers */ 12169);
/* harmony import */ var _bnqkl_wallet_base_services_wallet_wallet_data_storage__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @bnqkl/wallet-base/services/wallet/wallet-data-storage */ 63024);




/** 地址簿列表 数据解析器 */
const addressResolver = /*#__PURE__*/function () {
  var _ref = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (route) {
    /** 钱包存储服务 */
    const walletDataStorageV2Service = (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.inject)(_bnqkl_wallet_base_services_wallet_wallet_data_storage__WEBPACK_IMPORTED_MODULE_2__.WalletDataStorageV2Service);
    const {
      addressBookId,
      address,
      name,
      remarks
    } = route.queryParams;
    let {
      chain,
      symbol,
      iconName
    } = route.queryParams;
    if ((0,_bnqkl_framework_helpers__WEBPACK_IMPORTED_MODULE_1__.$isNoEmptyString)(addressBookId) === false) {
      // 从转账带chain信息进来
      if (chain) {
        iconName = `icon-${chain}-${symbol.toLowerCase()}`;
      } else {
        const lastWalletActivate = walletDataStorageV2Service.walletAppSettings.lastWalletActivate;
        if (lastWalletActivate === undefined) {
          throw new Error(`not find lastWalletActivate`);
        }
        const {
          symbol: walletActivateSymbol,
          chain: walletActivateChain
        } = lastWalletActivate;
        iconName = `icon-${walletActivateChain}-${walletActivateSymbol.toLowerCase()}`;
        symbol = walletActivateSymbol;
        chain = walletActivateChain;
      }
    }
    return {
      addressBookId,
      chain,
      symbol,
      iconName,
      address,
      name,
      remarks
    };
  });
  return function addressResolver(_x) {
    return _ref.apply(this, arguments);
  };
}();
/**
 * ResolverData
 */
const modifyAddressResolver = {
  address: addressResolver
};

/***/ })

}]);
//# sourceMappingURL=apps_wallet_src_pages_mime_mime_routes_ts.js.map