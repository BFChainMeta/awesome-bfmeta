"use strict";
(self["webpackChunkwallet"] = self["webpackChunkwallet"] || []).push([["apps_wallet_src_pages_home_pages_home-create-wallet_home-create-wallet_component_ts"],{

/***/ 98366:
/*!*********************************************************************************************!*\
  !*** ./apps/wallet/src/pages/home/pages/home-create-wallet/home-create-wallet.component.ts ***!
  \*********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   HomeCreateWalletPage: () => (/* binding */ HomeCreateWalletPage),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 52542);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! tslib */ 90505);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @angular/forms */ 7820);
/* harmony import */ var _bnqkl_framework_controllers__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @bnqkl/framework/controllers */ 47919);
/* harmony import */ var _bnqkl_framework_plugins_toast__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @bnqkl/framework/plugins/toast */ 18030);
/* harmony import */ var _components_input_hidden_icon_swap_input_hidden_icon_swap_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ~components/input-hidden-icon-swap/input-hidden-icon-swap.component */ 68027);
/* harmony import */ var _modules_page_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ~modules/page.module */ 77538);
/* harmony import */ var _bnqkl_wallet_base_services_wallet_bip39__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @bnqkl/wallet-base/services/wallet/bip39 */ 76659);
/* harmony import */ var _bnqkl_wallet_base_services_wallet_wallet_data_storage__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @bnqkl/wallet-base/services/wallet/wallet-data-storage */ 63024);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @angular/core */ 61039);
/* harmony import */ var _libs_bnf_modules_bottom_sheet_components_bottom_sheet_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../../../../../libs/bnf/modules/bottom-sheet/components/bottom-sheet.component */ 94072);
/* harmony import */ var _libs_bnf_components_ripple_button_ripple_button_directive__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../../../../../libs/bnf/components/ripple-button/ripple-button.directive */ 16505);
/* harmony import */ var _libs_bnf_directives_form_errors_directive__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../../../../../../libs/bnf/directives/form-errors.directive */ 29541);
/* harmony import */ var _libs_bnf_directives_auto_complete_off_directive__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../../../../../../libs/bnf/directives/auto-complete-off.directive */ 66722);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @angular/common */ 6729);
/* harmony import */ var _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../../../../../../libs/bnf/modules/page/common-page/common-page.component */ 62052);
/* harmony import */ var _components_icon_icon_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../../../components/icon/icon.component */ 74703);
/* harmony import */ var _libs_bnf_pipes_errors_errors_pipe__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../../../../../../../libs/bnf/pipes/errors/errors.pipe */ 68362);
/* harmony import */ var _pipes_color_color_pipe__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../../../../pipes/color/color.pipe */ 76489);

var _class;



















function HomeCreateWalletPage_ng_template_9_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵi18n"](1, 39);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementContainerEnd"]();
  }
}
function HomeCreateWalletPage_ng_template_10_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵi18n"](1, 40);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const error_r12 = ctx.$error;
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵi18nExp"](error_r12.requiredLength);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵi18nApply"](1);
  }
}
function HomeCreateWalletPage_ng_template_20_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵi18n"](1, 41);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementContainerEnd"]();
  }
}
function HomeCreateWalletPage_ng_template_21_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵi18n"](1, 42);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const error_r14 = ctx.$error;
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵi18nExp"](error_r14.requiredLength);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵi18nApply"](1);
  }
}
function HomeCreateWalletPage_ng_template_22_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵi18n"](1, 43);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const error_r15 = ctx.$error;
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵi18nExp"](error_r15.requiredLength);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵi18nApply"](1);
  }
}
function HomeCreateWalletPage_ng_template_23_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵi18n"](1, 44);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementContainerEnd"]();
  }
}
function HomeCreateWalletPage_ng_template_24_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵi18n"](1, 45);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementContainerEnd"]();
  }
}
function HomeCreateWalletPage_ng_template_25_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵi18n"](1, 46);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementContainerEnd"]();
  }
}
function HomeCreateWalletPage_ng_template_26_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](0);
  }
  if (rf & 2) {
    const errors_r17 = ctx.$errors;
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtextInterpolate1"](" ", errors_r17, " ");
  }
}
function HomeCreateWalletPage_div_31_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](0, "div", 47);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelement"](1, "w-icon", 48);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](2, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵi18n"](3, 49);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]()();
  }
}
function HomeCreateWalletPage_div_41_div_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵi18n"](1, 52);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const errors_r18 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"]().ngIf;
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵi18nExp"](errors_r18 == null ? null : errors_r18["maxlength"] == null ? null : errors_r18["maxlength"].requiredLength);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵi18nApply"](1);
  }
}
function HomeCreateWalletPage_div_41_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](0, "div", 50);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](1, HomeCreateWalletPage_div_41_div_1_Template, 2, 1, "div", 51);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r10 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngIf", ctx_r10.tip.errors == null ? null : ctx_r10.tip.errors["maxlength"]);
  }
}
function HomeCreateWalletPage_ng_template_63_button_3_Template(rf, ctx) {
  if (rf & 1) {
    const _r26 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](0, "button", 57);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("click", function HomeCreateWalletPage_ng_template_63_button_3_Template_button_click_0_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵrestoreView"](_r26);
      const item_r23 = restoredCtx.$implicit;
      const ctx_r25 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵresetView"](ctx_r25.getChange(item_r23));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](1, "div", 58);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const item_r23 = ctx.$implicit;
    const last_r24 = ctx.last;
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngClass", last_r24 ? "border-0" : "border-b-[0.5px]");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtextInterpolate1"](" ", item_r23.text, " ");
  }
}
function HomeCreateWalletPage_ng_template_63_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](0, "common-page", 53, 54)(2, "div", 55);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](3, HomeCreateWalletPage_ng_template_63_button_3_Template, 3, 2, "button", 56);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r11 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("headerTitle", ctx_r11.mnemonicBottomSheetInfo.title);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngForOf", ctx_r11.mnemonicBottomSheetInfo.data);
  }
}
const _c42 = a0 => ({
  "text-error": a0
});
const _c43 = (a0, a1) => ({
  pwd: a0,
  cpwd: a1
});
const _c44 = a0 => ({
  "--color-1": a0
});
class HomeCreateWalletPage extends _modules_page_module__WEBPACK_IMPORTED_MODULE_4__.CommonPageBase {
  constructor() {
    super(...arguments);
    /** 表单验证服务 */
    this.validators = new _bnqkl_framework_controllers__WEBPACK_IMPORTED_MODULE_1__.FormValidatorsController(this);
    /** 存储key */
    this.notMainWalletKey = '';
    /** 是否显示密码的顶部提示 */
    this.showPwdTip = false;
    /** 是否展示密码 */
    this.showPwd = false;
    /** 是否展示确认密码 */
    this.showCPwd = false;
    /** 钱包名称 */
    this.name = new _angular_forms__WEBPACK_IMPORTED_MODULE_16__.FormControl('', {
      nonNullable: true,
      validators: [this.validators.trimRequired, _angular_forms__WEBPACK_IMPORTED_MODULE_16__.Validators.maxLength(12)]
    });
    /** 密码 */
    this.pwd = new _angular_forms__WEBPACK_IMPORTED_MODULE_16__.FormControl('', {
      nonNullable: true,
      validators: [this.validators.whitespace, _angular_forms__WEBPACK_IMPORTED_MODULE_16__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_16__.Validators.minLength(8), _angular_forms__WEBPACK_IMPORTED_MODULE_16__.Validators.maxLength(30)]
    });
    /** 确认密码 */
    this.cpwd = new _angular_forms__WEBPACK_IMPORTED_MODULE_16__.FormControl('', {
      nonNullable: true,
      validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_16__.Validators.required, this.validators.equals(this.pwd)]
    });
    /** 密码提示 */
    this.tip = new _angular_forms__WEBPACK_IMPORTED_MODULE_16__.FormControl('', {
      nonNullable: true,
      validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_16__.Validators.maxLength(50)]
    });
    /** 要提交的表单与复合验证 */
    this.form = new _angular_forms__WEBPACK_IMPORTED_MODULE_16__.FormGroup({
      name: this.name,
      pwd: this.pwd,
      cpwd: this.cpwd,
      tip: this.tip
    }, {
      validators: [],
      asyncValidators: []
    });
    /** 页面返回值的类型 */
    this.returnValue$ = new _modules_page_module__WEBPACK_IMPORTED_MODULE_4__.PageReturnValue();
    /** 底部选择器 */
    this.mnemonicBottomSheetInfo = {
      title: '',
      data: [],
      open: false
    };
    /** 助剂词信息 */
    this.mnemonicInfo = {
      length: 12,
      language: _bnqkl_wallet_base_services_wallet_bip39__WEBPACK_IMPORTED_MODULE_5__.MNEMONIC_LANGUAGE.english,
      text: "English"
    };
  }
  /** 钱包名称 */
  set walletName(value) {
    this.name.patchValue(value);
  }
  /** 提交表单 */
  onSubmit() {
    this.createMainWallet();
  }
  /** 创建身份钱包 */
  createMainWallet() {
    var _this = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const {
        name,
        pwd,
        tip
      } = _this.form.value;
      try {
        /// 返回根页面
        _this.nav.routeBack('/mnemonic/mnemonic-backup-tips', {
          export: true,
          backUrl: '/home-manage-wallets',
          name: name === null || name === void 0 ? void 0 : name.trim(),
          pwd,
          tip: tip === null || tip === void 0 ? void 0 : tip.trim(),
          importType: _bnqkl_wallet_base_services_wallet_wallet_data_storage__WEBPACK_IMPORTED_MODULE_6__.WALLET_IMPORT_TYPE.mnemonic,
          chain: _this.chainName,
          notMainWalletKey: _this.notMainWalletKey,
          ..._this.mnemonicInfo
        }, true);
      } catch (error) {
        _bnqkl_framework_plugins_toast__WEBPACK_IMPORTED_MODULE_2__.Toast.show(error instanceof Error ? error.message : String(error));
      }
    })();
  }
  /** 选择语言 */
  selectLanguage() {
    this.mnemonicBottomSheetInfo.title = "\u9009\u62E9\u52A9\u8BB0\u8BCD\u8BED\u8A00";
    this.mnemonicBottomSheetInfo.data = [{
      type: 'language',
      text: "English",
      value: _bnqkl_wallet_base_services_wallet_bip39__WEBPACK_IMPORTED_MODULE_5__.MNEMONIC_LANGUAGE.english
    }, {
      type: 'language',
      text: "\u4E2D\u6587\uFF08\u7B80\u4F53\uFF09",
      value: _bnqkl_wallet_base_services_wallet_bip39__WEBPACK_IMPORTED_MODULE_5__.MNEMONIC_LANGUAGE.chineseSimplified
    }, {
      type: 'language',
      text: "\u4E2D\u6587\uFF08\u7E41\u9AD4\uFF09",
      value: _bnqkl_wallet_base_services_wallet_bip39__WEBPACK_IMPORTED_MODULE_5__.MNEMONIC_LANGUAGE.chineseTraditional
    }];
    this.mnemonicBottomSheetInfo.open = true;
  }
  /** 选择长度 */
  selectLength() {
    this.mnemonicBottomSheetInfo.title = "\u9009\u62E9\u52A9\u8BB0\u8BCD\u6570\u91CF";
    this.mnemonicBottomSheetInfo.data = [12, 15, 18, 21, 24, 36].map(item => {
      return {
        type: 'length',
        text: "" + item + " \u4E2A\u5B57",
        value: item
      };
    });
    this.mnemonicBottomSheetInfo.open = true;
  }
  getChange(item) {
    if (item) {
      if (item.type === 'language') {
        this.mnemonicInfo.language = item.value;
        this.mnemonicInfo.text = item.text;
      } else {
        this.mnemonicInfo.length = item.value;
      }
    }
    this.mnemonicBottomSheetInfo.open = false;
    this.cdRef.detectChanges();
  }
}
_class = HomeCreateWalletPage;
_class.ɵfac = /*@__PURE__*/(() => {
  let ɵHomeCreateWalletPage_BaseFactory;
  return function HomeCreateWalletPage_Factory(t) {
    return (ɵHomeCreateWalletPage_BaseFactory || (ɵHomeCreateWalletPage_BaseFactory = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵgetInheritedFactory"](_class)))(t || _class);
  };
})();
_class.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵdefineComponent"]({
  type: _class,
  selectors: [["w-home-create-wallet-page"]],
  outputs: {
    returnValue$: "returnValue$"
  },
  standalone: true,
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵInheritDefinitionFeature"], _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵStandaloneFeature"]],
  decls: 64,
  vars: 65,
  consts: () => {
    let i18n_0;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_CREATE_WALLET__SYMBOL_$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_CREATE_WALLET_HOME_CREATE_WALLET_COMPONENT_TS_1 = goog.getMsg("Create Wallet ({$interpolation})", {
        "interpolation": "\uFFFD0\uFFFD"
      }, {
        original_code: {
          "interpolation": "{{ symbol }}"
        }
      });
      i18n_0 = MSG_EXTERNAL_CREATE_WALLET__SYMBOL_$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_CREATE_WALLET_HOME_CREATE_WALLET_COMPONENT_TS_1;
    } else {
      i18n_0 = "\u521B\u5EFA\u94B1\u5305 (" + "\uFFFD0\uFFFD" + ")";
    }
    let i18n_2;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_WALLET_NAME$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_CREATE_WALLET_HOME_CREATE_WALLET_COMPONENT_TS_3 = goog.getMsg(" Wallet Name ");
      i18n_2 = MSG_EXTERNAL_WALLET_NAME$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_CREATE_WALLET_HOME_CREATE_WALLET_COMPONENT_TS_3;
    } else {
      i18n_2 = "\u94B1\u5305\u540D\u79F0";
    }
    let i18n_4;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_ENTER_CHARACTERS$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_CREATE_WALLET_HOME_CREATE_WALLET_COMPONENT_TS_5 = goog.getMsg("Enter 1-12 characters");
      i18n_4 = MSG_EXTERNAL_ENTER_CHARACTERS$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_CREATE_WALLET_HOME_CREATE_WALLET_COMPONENT_TS_5;
    } else {
      i18n_4 = "\u8F93\u51651~12\u4E2A\u5B57\u7B26";
    }
    let i18n_6;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_WALLET_PASSWORD$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_CREATE_WALLET_HOME_CREATE_WALLET_COMPONENT_TS_7 = goog.getMsg(" Wallet Password ");
      i18n_6 = MSG_EXTERNAL_WALLET_PASSWORD$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_CREATE_WALLET_HOME_CREATE_WALLET_COMPONENT_TS_7;
    } else {
      i18n_6 = "\u94B1\u5305\u5BC6\u7801";
    }
    let i18n_8;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_PASSWORD_IS_NOT_LESS_THAN_DIGITS$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_CREATE_WALLET_HOME_CREATE_WALLET_COMPONENT_TS_9 = goog.getMsg("Password is not less than 8 digits");
      i18n_8 = MSG_EXTERNAL_PASSWORD_IS_NOT_LESS_THAN_DIGITS$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_CREATE_WALLET_HOME_CREATE_WALLET_COMPONENT_TS_9;
    } else {
      i18n_8 = "\u5BC6\u7801\u81F3\u5C118\u4E2A\u5B57\u7B26";
    }
    let i18n_10;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_REPEAT_PASSWORD$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_CREATE_WALLET_HOME_CREATE_WALLET_COMPONENT_TS_11 = goog.getMsg("Repeat Password");
      i18n_10 = MSG_EXTERNAL_REPEAT_PASSWORD$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_CREATE_WALLET_HOME_CREATE_WALLET_COMPONENT_TS_11;
    } else {
      i18n_10 = "\u786E\u8BA4\u5BC6\u7801";
    }
    let i18n_12;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_PASSWORD_HINT_OPTIONAL$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_CREATE_WALLET_HOME_CREATE_WALLET_COMPONENT_TS_13 = goog.getMsg(" Password Hint (optional) ");
      i18n_12 = MSG_EXTERNAL_PASSWORD_HINT_OPTIONAL$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_CREATE_WALLET_HOME_CREATE_WALLET_COMPONENT_TS_13;
    } else {
      i18n_12 = "\u5BC6\u7801\u63D0\u793A\uFF08\u53EF\u9009\uFF09";
    }
    let i18n_14;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_ENTER_PASSWORD_PROMPT_INFORMATION$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_CREATE_WALLET_HOME_CREATE_WALLET_COMPONENT_TS_15 = goog.getMsg("Enter password prompt information");
      i18n_14 = MSG_EXTERNAL_ENTER_PASSWORD_PROMPT_INFORMATION$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_CREATE_WALLET_HOME_CREATE_WALLET_COMPONENT_TS_15;
    } else {
      i18n_14 = "\u8F93\u5165\u5BC6\u7801\u63D0\u793A\u4FE1\u606F";
    }
    let i18n_16;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_MNEMONIC$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_CREATE_WALLET_HOME_CREATE_WALLET_COMPONENT_TS_17 = goog.getMsg("Mnemonic");
      i18n_16 = MSG_EXTERNAL_MNEMONIC$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_CREATE_WALLET_HOME_CREATE_WALLET_COMPONENT_TS_17;
    } else {
      i18n_16 = "\u52A9\u8BB0\u8BCD";
    }
    let i18n_18;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL___length___WORDS$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_CREATE_WALLET_HOME_CREATE_WALLET_COMPONENT_TS_19 = goog.getMsg("{$interpolation} words", {
        "interpolation": "\uFFFD0\uFFFD"
      }, {
        original_code: {
          "interpolation": "{{ mnemonicInfo.length }}"
        }
      });
      i18n_18 = MSG_EXTERNAL___length___WORDS$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_CREATE_WALLET_HOME_CREATE_WALLET_COMPONENT_TS_19;
    } else {
      i18n_18 = "" + "\uFFFD0\uFFFD" + " \u4E2A\u5B57";
    }
    let i18n_20;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_CREATE_WALLET$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_CREATE_WALLET_HOME_CREATE_WALLET_COMPONENT_TS_21 = goog.getMsg(" Create Wallet ");
      i18n_20 = MSG_EXTERNAL_CREATE_WALLET$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_CREATE_WALLET_HOME_CREATE_WALLET_COMPONENT_TS_21;
    } else {
      i18n_20 = "\u521B\u5EFA\u94B1\u5305";
    }
    let i18n_22;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_PLEASE_ENTER_IDENTITY_NAME$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_CREATE_WALLET_HOME_CREATE_WALLET_COMPONENT_TS__23 = goog.getMsg("Please enter Identity name");
      i18n_22 = MSG_EXTERNAL_PLEASE_ENTER_IDENTITY_NAME$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_CREATE_WALLET_HOME_CREATE_WALLET_COMPONENT_TS__23;
    } else {
      i18n_22 = "\u8BF7\u8F93\u5165\u94B1\u5305\u540D\u79F0";
    }
    let i18n_24;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_THE_MAXIMUM_LENGTH_OF_THE_NAME_IS_REQUIRED_LENGTH$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_CREATE_WALLET_HOME_CREATE_WALLET_COMPONENT_TS__25 = goog.getMsg(" The maximum length of the name is {$interpolation} ", {
        "interpolation": "\uFFFD0\uFFFD"
      }, {
        original_code: {
          "interpolation": "{{ error.requiredLength }}"
        }
      });
      i18n_24 = MSG_EXTERNAL_THE_MAXIMUM_LENGTH_OF_THE_NAME_IS_REQUIRED_LENGTH$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_CREATE_WALLET_HOME_CREATE_WALLET_COMPONENT_TS__25;
    } else {
      i18n_24 = "\u540D\u5B57\u8BF7\u52FF\u8D85\u8FC7 " + "\uFFFD0\uFFFD" + " \u4E2A\u5B57\u7B26 ";
    }
    let i18n_26;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_PLEASE_INPUT_THE_PASSWORD$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_CREATE_WALLET_HOME_CREATE_WALLET_COMPONENT_TS__27 = goog.getMsg("Please input the password");
      i18n_26 = MSG_EXTERNAL_PLEASE_INPUT_THE_PASSWORD$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_CREATE_WALLET_HOME_CREATE_WALLET_COMPONENT_TS__27;
    } else {
      i18n_26 = "\u8BF7\u8F93\u5165\u5BC6\u7801";
    }
    let i18n_28;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_THE_PASSWORD_IS_AT_LEAST_CHARACTERS_LONG$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_CREATE_WALLET_HOME_CREATE_WALLET_COMPONENT_TS__29 = goog.getMsg(" The password is at least {$interpolation} characters long ", {
        "interpolation": "\uFFFD0\uFFFD"
      }, {
        original_code: {
          "interpolation": "{{ error.requiredLength }}"
        }
      });
      i18n_28 = MSG_EXTERNAL_THE_PASSWORD_IS_AT_LEAST_CHARACTERS_LONG$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_CREATE_WALLET_HOME_CREATE_WALLET_COMPONENT_TS__29;
    } else {
      i18n_28 = "\u5BC6\u7801\u8BF7\u52FF\u5C11\u4E8E " + "\uFFFD0\uFFFD" + " \u4E2A\u5B57\u7B26 ";
    }
    let i18n_30;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_THE_MAXIMUM_LENGTH_OF_THE_PASSWORD_IS$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_CREATE_WALLET_HOME_CREATE_WALLET_COMPONENT_TS__31 = goog.getMsg(" The maximum length of the password is {$interpolation} ", {
        "interpolation": "\uFFFD0\uFFFD"
      }, {
        original_code: {
          "interpolation": "{{ error.requiredLength }}"
        }
      });
      i18n_30 = MSG_EXTERNAL_THE_MAXIMUM_LENGTH_OF_THE_PASSWORD_IS$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_CREATE_WALLET_HOME_CREATE_WALLET_COMPONENT_TS__31;
    } else {
      i18n_30 = "\u5BC6\u7801\u8BF7\u52FF\u8D85\u8FC7 " + "\uFFFD0\uFFFD" + " \u4E2A\u5B57\u7B26 ";
    }
    let i18n_32;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_THE_PASSWORD_CANNOT_CONTAINER_SPACES$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_CREATE_WALLET_HOME_CREATE_WALLET_COMPONENT_TS__33 = goog.getMsg(" The password cannot container spaces ! ");
      i18n_32 = MSG_EXTERNAL_THE_PASSWORD_CANNOT_CONTAINER_SPACES$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_CREATE_WALLET_HOME_CREATE_WALLET_COMPONENT_TS__33;
    } else {
      i18n_32 = "\u5BC6\u7801\u4E2D\u8BF7\u52FF\u5305\u542B\u7A7A\u683C\uFF01";
    }
    let i18n_34;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_PLEASE_INPUT_THE_PASSWORD_AGAIN$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_CREATE_WALLET_HOME_CREATE_WALLET_COMPONENT_TS__35 = goog.getMsg("Please input the password again");
      i18n_34 = MSG_EXTERNAL_PLEASE_INPUT_THE_PASSWORD_AGAIN$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_CREATE_WALLET_HOME_CREATE_WALLET_COMPONENT_TS__35;
    } else {
      i18n_34 = "\u8BF7\u518D\u6B21\u8F93\u5165\u5BC6\u7801";
    }
    let i18n_36;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_TWO_INPUTSDO_NOT_MATCH$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_CREATE_WALLET_HOME_CREATE_WALLET_COMPONENT_TS__37 = goog.getMsg("Two inputs don't match!");
      i18n_36 = MSG_EXTERNAL_TWO_INPUTSDO_NOT_MATCH$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_CREATE_WALLET_HOME_CREATE_WALLET_COMPONENT_TS__37;
    } else {
      i18n_36 = "\u4E24\u6B21\u8F93\u5165\u4E0D\u4E00\u81F4\uFF01";
    }
    let i18n_38;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_THIS_PASSWORD_IS_ONLY_USED_FOR_THE_SECURITY_PROTECTION_OF_THE_WALLET_COT_WILL_NOT_SAVE_YOUR_PASSWORD_NOR_WILL_IT_BE_ABLE_TO_HELP_YOU_RETRIEVE_IT_PLEASE_REMEMBER_AND_KEEP_YOUR_PASSWORD$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_CREATE_WALLET_HOME_CREATE_WALLET_COMPONENT_TS__39 = goog.getMsg(" This password is only used for the security protection of the wallet. COT will not save your password, nor will it be able to help you retrieve it. Please remember and keep your password! ");
      i18n_38 = MSG_EXTERNAL_THIS_PASSWORD_IS_ONLY_USED_FOR_THE_SECURITY_PROTECTION_OF_THE_WALLET_COT_WILL_NOT_SAVE_YOUR_PASSWORD_NOR_WILL_IT_BE_ABLE_TO_HELP_YOU_RETRIEVE_IT_PLEASE_REMEMBER_AND_KEEP_YOUR_PASSWORD$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_CREATE_WALLET_HOME_CREATE_WALLET_COMPONENT_TS__39;
    } else {
      i18n_38 = "\u8BE5\u5BC6\u7801\u4EC5\u4F5C\u94B1\u5305\u5B89\u5168\u7684\u4FDD\u62A4\u4F5C\u7528\uFF0CCOT\u4E0D\u4F1A\u4FDD\u5B58\u60A8\u7684\u5BC6\u7801\uFF0C\u4E5F\u65E0\u6CD5\u5E2E\u60A8\u627E\u56DE\u5BC6\u7801\uFF0C\u8BF7\u52A1\u5FC5\u8BB0\u5F97\u5E76\u4FDD\u7BA1\u597D\u5BC6\u7801\uFF01";
    }
    let i18n_40;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_THE_MAXIMUM_LENGTH_OF_THE_HINT_IS$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_CREATE_WALLET_HOME_CREATE_WALLET_COMPONENT_TS___41 = goog.getMsg(" The maximum length of the hint is {$interpolation} ", {
        "interpolation": "\uFFFD0\uFFFD"
      }, {
        original_code: {
          "interpolation": "{{errors?.['maxlength']?.requiredLength}}"
        }
      });
      i18n_40 = MSG_EXTERNAL_THE_MAXIMUM_LENGTH_OF_THE_HINT_IS$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_CREATE_WALLET_HOME_CREATE_WALLET_COMPONENT_TS___41;
    } else {
      i18n_40 = "\u63D0\u793A\u4FE1\u606F\u8BF7\u52FF\u8D85\u8FC7 " + "\uFFFD0\uFFFD" + " \u4E2A\u5B57\u7B26 ";
    }
    return [[3, "titleColor", "contentSafeArea", 6, "headerTitle"], ["headerTitle", i18n_0], [3, "formGroup", "ngSubmit"], [1, "mb-2", "flex", "h-10", "w-full", "items-end", "justify-between", "text-xs", "font-semibold"], [1, "flex-shrink-0", "pr-2", 3, "ngClass"], i18n_2, [1, "text-error", "text-xss", "text-right", 3, "wSwitchErrors"], ["wCaseKey", "trimRequired"], [1, "bg-env", "flex", "h-10", "rounded-lg"], ["formControlName", "name", "type", "text", "placeholder", i18n_4, 1, "w-full", "pl-2"], i18n_6, ["scope", "pwd", "wCaseKey", "required"], ["scope", "pwd", "wCaseKey", "minlength"], ["scope", "pwd", "wCaseKey", "maxlength"], ["scope", "pwd", "wCaseKey", "whitespace"], ["scope", "cpwd", "wCaseKey", "required"], ["scope", "cpwd", "wCaseKey", "equals"], [3, "wCaseDefault"], [1, "bg-env", "flex", "h-10", "items-center", "rounded-lg", "pr-4"], ["formControlName", "pwd", "placeholder", i18n_8, 1, "w-full", "pl-2", 3, "type", "focus", "blur"], [1, "text-subtext", "text-xl", 3, "show", "showChange"], ["class", "text-error my-2 text-xs", 4, "ngIf"], [1, "bg-env", "mt-2", "flex", "h-10", "items-center", "rounded-lg", "pr-4"], ["formControlName", "cpwd", "placeholder", i18n_10, 1, "w-full", "pl-2", 3, "type"], [1, "text-title", "flex-shrink-0", "pr-2", 3, "ngClass"], i18n_12, ["class", "text-error text-xss text-right", 4, "ngIf"], ["formControlName", "tip", "type", "text", "placeholder", i18n_14, 1, "w-full", "pl-2"], [1, "flex-shrink-0", "pr-2", "text-sm"], i18n_16, ["wRippleButton", "", "type", "button", 1, "bg-env", "flex", "h-12", "w-full", "items-center", "justify-between", "rounded-lg", "pr-4", 3, "click"], [1, "w-full", "px-3"], ["name", "right", 1, "icon-5", "ml-1.5"], ["wRippleButton", "", "type", "button", 1, "bg-env", "mb-2", "mt-2", "flex", "h-12", "w-full", "items-center", "justify-between", "rounded-lg", "pr-4", 3, "click"], i18n_18, ["footer", "", 3, "formGroup", "ngSubmit"], ["bnRippleButton", "", "type", "submit", 1, "h-10.5", "bg-primary-2", "w-full", "rounded-full", "text-center", "text-sm", "text-white", 3, "disabled"], i18n_20, [3, "isOpen", "isOpenChange"], i18n_22, i18n_24, i18n_26, i18n_28, i18n_30, i18n_32, i18n_34, i18n_36, [1, "text-error", "my-2", "text-xs"], ["name", "warn-grey", 1, "icon-5"], i18n_38, [1, "text-error", "text-xss", "text-right"], [4, "ngIf"], i18n_40, [3, "headerTitle"], ["page", ""], [1, "box-border", "flex", "flex-col"], ["wRippleButton", "", "class", "h-12 w-full px-5 text-sm", 3, "click", 4, "ngFor", "ngForOf"], ["wRippleButton", "", 1, "h-12", "w-full", "px-5", "text-sm", 3, "click"], [1, "border-line", "flex", "h-full", "w-full", "items-center", "justify-center", 3, "ngClass"]];
  },
  template: function HomeCreateWalletPage_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](0, "common-page", 0);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵi18nAttributes"](1, 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](2, "form", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("ngSubmit", function HomeCreateWalletPage_Template_form_ngSubmit_2_listener() {
        return ctx.onSubmit();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](3, "fieldset")(4, "legend", 3)(5, "div", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵi18n"](6, 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipe"](7, "errors");
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](8, "div", 6);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](9, HomeCreateWalletPage_ng_template_9_Template, 2, 0, "ng-template", 7)(10, HomeCreateWalletPage_ng_template_10_Template, 2, 1, "ng-template", 7);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](11, "div", 8);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelement"](12, "input", 9);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](13, "fieldset")(14, "legend", 3)(15, "div", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵi18n"](16, 10);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipe"](17, "errors");
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipe"](18, "errors");
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](19, "div", 6);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](20, HomeCreateWalletPage_ng_template_20_Template, 2, 0, "ng-template", 11)(21, HomeCreateWalletPage_ng_template_21_Template, 2, 1, "ng-template", 12)(22, HomeCreateWalletPage_ng_template_22_Template, 2, 1, "ng-template", 13)(23, HomeCreateWalletPage_ng_template_23_Template, 2, 0, "ng-template", 14)(24, HomeCreateWalletPage_ng_template_24_Template, 2, 0, "ng-template", 15)(25, HomeCreateWalletPage_ng_template_25_Template, 2, 0, "ng-template", 16)(26, HomeCreateWalletPage_ng_template_26_Template, 1, 1, "ng-template", 17);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](27, "div", 18)(28, "input", 19);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("focus", function HomeCreateWalletPage_Template_input_focus_28_listener() {
        return ctx.showPwdTip = true;
      })("blur", function HomeCreateWalletPage_Template_input_blur_28_listener() {
        return ctx.showPwdTip = false;
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](29, "w-input-hidden-icon-swap", 20);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("showChange", function HomeCreateWalletPage_Template_w_input_hidden_icon_swap_showChange_29_listener($event) {
        return ctx.showPwd = $event;
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipe"](30, "color");
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](31, HomeCreateWalletPage_div_31_Template, 4, 0, "div", 21);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](32, "div", 22);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelement"](33, "input", 23);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](34, "w-input-hidden-icon-swap", 20);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("showChange", function HomeCreateWalletPage_Template_w_input_hidden_icon_swap_showChange_34_listener($event) {
        return ctx.showCPwd = $event;
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipe"](35, "color");
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]()()();
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](36, "fieldset")(37, "legend", 3)(38, "div", 24);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵi18n"](39, 25);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipe"](40, "errors");
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](41, HomeCreateWalletPage_div_41_Template, 2, 1, "div", 26);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipe"](42, "errors");
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](43, "div", 8);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelement"](44, "input", 27);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](45, "fieldset")(46, "legend", 3)(47, "div", 28);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵi18n"](48, 29);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](49, "button", 30);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("click", function HomeCreateWalletPage_Template_button_click_49_listener() {
        return ctx.selectLanguage();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](50, "div", 31);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](51);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelement"](52, "w-icon", 32);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipe"](53, "color");
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](54, "button", 33);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("click", function HomeCreateWalletPage_Template_button_click_54_listener() {
        return ctx.selectLength();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](55, "div", 31);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵi18n"](56, 34);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelement"](57, "w-icon", 32);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipe"](58, "color");
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]()()();
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](59, "form", 35);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("ngSubmit", function HomeCreateWalletPage_Template_form_ngSubmit_59_listener() {
        return ctx.onSubmit();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](60, "button", 36);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵi18n"](61, 37);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]()()();
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](62, "common-bottom-sheet", 38);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("isOpenChange", function HomeCreateWalletPage_Template_common_bottom_sheet_isOpenChange_62_listener($event) {
        return $event || (ctx.mnemonicBottomSheetInfo.open = false);
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](63, HomeCreateWalletPage_ng_template_63_Template, 4, 2, "ng-template");
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵi18nExp"](ctx.symbol);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵi18nApply"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("titleColor", "title")("contentSafeArea", true);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("formGroup", ctx.form);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpureFunction1"](48, _c42, _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipeBind1"](7, 30, ctx.name)));
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("wSwitchErrors", ctx.name);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](7);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpureFunction1"](50, _c42, _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipeBind1"](17, 32, ctx.pwd) || _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipeBind1"](18, 34, ctx.cpwd)));
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](4);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("wSwitchErrors", _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpureFunction2"](52, _c43, ctx.pwd, ctx.cpwd));
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](9);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("type", ctx.showPwd ? "text" : "password");
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpureFunction1"](55, _c44, _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipeBind1"](30, 36, "subtext")));
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("show", ctx.showPwd);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngIf", ctx.showPwdTip);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("type", ctx.showCPwd ? "text" : "password");
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpureFunction1"](57, _c44, _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipeBind1"](35, 38, "subtext")));
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("show", ctx.showCPwd);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](4);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpureFunction1"](59, _c42, _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipeBind1"](40, 40, ctx.tip)));
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngIf", _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipeBind1"](42, 42, ctx.tip));
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](10);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtextInterpolate"](ctx.mnemonicInfo.text);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpureFunction1"](61, _c44, _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipeBind1"](53, 44, "subtext")));
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](4);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵi18nExp"](ctx.mnemonicInfo.length);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵi18nApply"](56);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpureFunction1"](63, _c44, _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipeBind1"](58, 46, "subtext")));
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("formGroup", ctx.form);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵclassProp"]("opacity-30", !ctx.form.valid);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("disabled", !ctx.form.valid);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("isOpen", ctx.mnemonicBottomSheetInfo.open);
    }
  },
  dependencies: [_modules_page_module__WEBPACK_IMPORTED_MODULE_4__.CommonPageModule, _libs_bnf_modules_bottom_sheet_components_bottom_sheet_component__WEBPACK_IMPORTED_MODULE_7__.BottomSheetComponent, _libs_bnf_components_ripple_button_ripple_button_directive__WEBPACK_IMPORTED_MODULE_8__.RippleButtonDirective, _libs_bnf_directives_form_errors_directive__WEBPACK_IMPORTED_MODULE_9__.SwitchErrorsDirective, _libs_bnf_directives_form_errors_directive__WEBPACK_IMPORTED_MODULE_9__.SwitchCaseDirective, _libs_bnf_directives_form_errors_directive__WEBPACK_IMPORTED_MODULE_9__.SwitchDefaultDirective, _libs_bnf_directives_auto_complete_off_directive__WEBPACK_IMPORTED_MODULE_10__.AutoCompleteOffDirective, _angular_common__WEBPACK_IMPORTED_MODULE_17__.NgClass, _angular_common__WEBPACK_IMPORTED_MODULE_17__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_17__.NgIf, _angular_forms__WEBPACK_IMPORTED_MODULE_16__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_16__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_16__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_16__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_16__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_16__.FormControlName, _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_11__.CommonPageComponent, _components_icon_icon_component__WEBPACK_IMPORTED_MODULE_12__.IconComponent, _libs_bnf_pipes_errors_errors_pipe__WEBPACK_IMPORTED_MODULE_13__.ErrorsPipe, _pipes_color_color_pipe__WEBPACK_IMPORTED_MODULE_14__.ColorPipe, _components_input_hidden_icon_swap_input_hidden_icon_swap_component__WEBPACK_IMPORTED_MODULE_3__["default"]],
  styles: ["/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsInNvdXJjZVJvb3QiOiIifQ== */"],
  changeDetection: 0
});
(0,tslib__WEBPACK_IMPORTED_MODULE_18__.__decorate)([HomeCreateWalletPage.QueryParam('notMainWalletKey'), (0,tslib__WEBPACK_IMPORTED_MODULE_18__.__metadata)("design:type", Object)], HomeCreateWalletPage.prototype, "notMainWalletKey", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_18__.__decorate)([HomeCreateWalletPage.QueryParam('token'), HomeCreateWalletPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_18__.__metadata)("design:type", String)], HomeCreateWalletPage.prototype, "chainName", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_18__.__decorate)([HomeCreateWalletPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_18__.__metadata)("design:type", Object)], HomeCreateWalletPage.prototype, "showPwdTip", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_18__.__decorate)([HomeCreateWalletPage.QueryParam('walletName'), (0,tslib__WEBPACK_IMPORTED_MODULE_18__.__metadata)("design:type", String), (0,tslib__WEBPACK_IMPORTED_MODULE_18__.__metadata)("design:paramtypes", [String])], HomeCreateWalletPage.prototype, "walletName", null);
(0,tslib__WEBPACK_IMPORTED_MODULE_18__.__decorate)([HomeCreateWalletPage.QueryParam('symbol'), (0,tslib__WEBPACK_IMPORTED_MODULE_18__.__metadata)("design:type", String)], HomeCreateWalletPage.prototype, "symbol", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_18__.__decorate)([HomeCreateWalletPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_18__.__metadata)("design:type", Object)], HomeCreateWalletPage.prototype, "showPwd", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_18__.__decorate)([HomeCreateWalletPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_18__.__metadata)("design:type", Object)], HomeCreateWalletPage.prototype, "showCPwd", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_18__.__decorate)([HomeCreateWalletPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_18__.__metadata)("design:type", Object)], HomeCreateWalletPage.prototype, "name", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_18__.__decorate)([HomeCreateWalletPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_18__.__metadata)("design:type", Object)], HomeCreateWalletPage.prototype, "pwd", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_18__.__decorate)([HomeCreateWalletPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_18__.__metadata)("design:type", Object)], HomeCreateWalletPage.prototype, "cpwd", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_18__.__decorate)([HomeCreateWalletPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_18__.__metadata)("design:type", Object)], HomeCreateWalletPage.prototype, "form", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_18__.__decorate)([HomeCreateWalletPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_18__.__metadata)("design:type", Object)], HomeCreateWalletPage.prototype, "mnemonicBottomSheetInfo", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_18__.__decorate)([HomeCreateWalletPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_18__.__metadata)("design:type", Object)], HomeCreateWalletPage.prototype, "mnemonicInfo", void 0);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (HomeCreateWalletPage);

/***/ }),

/***/ 11606:
/*!************************************************************!*\
  !*** ./libs/bnf/controllers/form-validators.controller.ts ***!
  \************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   FormValidatorsController: () => (/* binding */ FormValidatorsController)
/* harmony export */ });
/* harmony import */ var _bnqkl_framework_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @bnqkl/framework/core */ 63563);
/* harmony import */ var _bnqkl_util_web_extends_map__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @bnqkl/util-web/extends-map */ 37689);


/**
 * 页面表单扩展验证器
 *
 * > 因为涉及到FromControl的生命周期管理，所以这里需要使用Controller模式来获取组件/页面的生命周期
 *
 * 为了确保类型安全, 请遵循以下规则去定义验证器:
 * 1. 尽可能直接提供 $ValidatorFn,比如 `trimRequired(control: AbstractControl): $ValidationErrors | null {...}`
 * 2. 如果不能直接提供 $ValidatorFn, 那么作为工厂模式,必然要有参数传入,比如 `equals(leaderCtrl: AbstractControl): $ValidatorFn {...}`
 */
class FormValidatorsController {
  /**
   * 通过订阅原页面的生命周期，来对订阅的字段进行监听解除
   */
  constructor(comp) {
    /**
     * 判断两个数据字段相等的时，left===right 中 left的数据订阅
     */
    this._equalsLeaderMap = _bnqkl_util_web_extends_map__WEBPACK_IMPORTED_MODULE_1__.EasyMap.from({
      creater(ctrl) {
        const sub = {
          sub$: ctrl.valueChanges.subscribe(() => {
            for (const ctrl of sub.destControls) {
              ctrl.updateValueAndValidity();
            }
          }),
          destControls: new Set()
        };
        return sub;
      }
    });
    (0,_bnqkl_framework_core__WEBPACK_IMPORTED_MODULE_0__.addLifecycleMethods)(comp, 'ngOnDestroy', {
      origin: 'form-validator',
      method: () => {
        for (const {
          sub$
        } of this._equalsLeaderMap.values()) {
          sub$.unsubscribe();
        }
        this._equalsLeaderMap.clear();
      },
      order: Number.MAX_SAFE_INTEGER /* 最后才做这些事情 */
    });
  }
  /** 两个字段对比 相等就过 不相等返回 {equals:true} */
  equals(leaderCtrl) {
    const leader = this._equalsLeaderMap.forceGet(leaderCtrl);
    // pwdCtrl.val
    return follerCtrl => {
      leader.destControls.add(follerCtrl);
      if (leaderCtrl.value === follerCtrl.value) {
        return null;
      }
      return {
        equals: true
      };
    };
  }
  /** 是否包含空格 */
  whitespace(control) {
    const value = control.value;
    if (typeof value === 'string' && /\s/.test(value)) {
      return {
        whitespace: true
      };
    }
    return null;
  }
  /** required 变体, 左右两边不能包含空格 */
  trimRequired(control) {
    const value = control.value;
    if (typeof value === 'string' && value.trim().length === 0 || value == undefined) {
      return {
        trimRequired: true
      };
    }
    return null;
  }
}

/***/ }),

/***/ 47919:
/*!***************************************!*\
  !*** ./libs/bnf/controllers/index.ts ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   FormValidatorsController: () => (/* reexport safe */ _form_validators_controller__WEBPACK_IMPORTED_MODULE_0__.FormValidatorsController),
/* harmony export */   PageReturnController: () => (/* reexport safe */ _page_return_controller__WEBPACK_IMPORTED_MODULE_1__.PageReturnController)
/* harmony export */ });
/* harmony import */ var _form_validators_controller__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./form-validators.controller */ 11606);
/* harmony import */ var _page_return_controller__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./page-return.controller */ 62893);



/***/ }),

/***/ 62893:
/*!********************************************************!*\
  !*** ./libs/bnf/controllers/page-return.controller.ts ***!
  \********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   PageReturnController: () => (/* binding */ PageReturnController)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 54106);
/* harmony import */ var _bnqkl_util_web_decorator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @bnqkl/util-web/decorator */ 18112);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs */ 19177);



/**
 * 页面数据返回值的订阅功能
 * > Controller 必须在构造函数期间执行
 */
class PageReturnController {
  /** 继承日志 */
  get console() {
    return this.fromPage.console;
  }
  /**
   * 传入源页面与目标页面的构造函数，并通过订阅原页面的生命周期，来初始化对路由的订阅
   * 这里依赖 ion-router-outlet 来获取跳转过去的页面
   * 注：该监听返回是全触发（只要页面没被销毁掉不管页面是否处于激活状态）
   * @param specific 用于指定fromPage触发（需要手动指定），业务需要
   */
  constructor(fromPage, toPageCtor, specific = false) {
    this.fromPage = fromPage;
    /** 当前定阅过的页面 */
    this._toPages = new WeakSet();
    /**
     * 订阅到的返回内容，
     * 类型由对应页面的 returnValue$ 的定义决定
     */
    this.pageReturn$ = new rxjs__WEBPACK_IMPORTED_MODULE_1__.Subject();
    const {
      nav
    } = fromPage;
    fromPage.takeUntilDestroy(nav.pageActiveState$).subscribe(event => {
      /// 只监听新激活的页面
      if (event.type !== 'activate') {
        return;
      }
      const toPage = event.target;
      if (toPage instanceof toPageCtor &&
      // 去重
      this._toPages.has(toPage) === false) {
        if (toPage.returnValue$ === undefined) {
          return;
        }
        this._toPages.add(toPage);
        if (specific) {
          var _toPage$specificRetur;
          (_toPage$specificRetur = toPage.specificReturnPages) === null || _toPage$specificRetur === void 0 || _toPage$specificRetur.add(fromPage);
        }
        fromPage.takeUntilDestroy(toPage.returnValue$).subscribe({
          next: data => {
            /// 这里不用判断specific
            if (toPage.specificReturnPages && toPage.specificReturnPages.size) {
              /// 如果有写入，那么就只需要触发相对应页面就行
              toPage.specificReturnPages.has(fromPage) && this.pageReturn$.next(data);
              return;
            }
            this.pageReturn$.next(data);
          },
          complete: () => {
            var _toPage$specificRetur2;
            // 释放内存引用
            (_toPage$specificRetur2 = toPage.specificReturnPages) === null || _toPage$specificRetur2 === void 0 || _toPage$specificRetur2.delete(fromPage);
            return this._toPages.delete(toPage);
          }
        });
      }
    });
  }
}
(0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([_bnqkl_util_web_decorator__WEBPACK_IMPORTED_MODULE_0__.cacheGetter, (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__metadata)("design:type", Object), (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__metadata)("design:paramtypes", [])], PageReturnController.prototype, "console", null);

/***/ })

}]);
//# sourceMappingURL=apps_wallet_src_pages_home_pages_home-create-wallet_home-create-wallet_component_ts.js.map