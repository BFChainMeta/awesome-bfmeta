"use strict";
(self["webpackChunkwallet"] = self["webpackChunkwallet"] || []).push([["apps_wallet_src_pages_mnemonic_pages_set-wallet-fingerprint-pay_set-wallet-fingerprint-pay_co-05d0b8"],{

/***/ 28711:
/*!*****************************************************************************************************************!*\
  !*** ./apps/wallet/src/pages/mnemonic/pages/set-wallet-fingerprint-pay/set-wallet-fingerprint-pay.component.ts ***!
  \*****************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   SetWalletFingerprintPayPage: () => (/* binding */ SetWalletFingerprintPayPage),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 52542);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! tslib */ 90505);
/* harmony import */ var _bnqkl_framework_animations__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @bnqkl/framework/animations */ 43127);
/* harmony import */ var _bnqkl_framework_plugins_biometric__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @bnqkl/framework/plugins/biometric */ 52583);
/* harmony import */ var _bnqkl_framework_plugins_toast__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @bnqkl/framework/plugins/toast */ 18030);
/* harmony import */ var _bnqkl_util_web_extends_promise__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @bnqkl/util-web/extends-promise */ 87778);
/* harmony import */ var _modules_page_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ~modules/page.module */ 77538);
/* harmony import */ var _pages_mime_pages_verify_fingerprint_verify_fingerprint_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ~pages/mime/pages/verify-fingerprint/verify-fingerprint.component */ 5780);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/core */ 61039);
/* harmony import */ var _libs_bnf_components_ripple_button_ripple_button_directive__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../../../../../libs/bnf/components/ripple-button/ripple-button.directive */ 16505);
/* harmony import */ var _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../../../../../libs/bnf/modules/page/common-page/common-page.component */ 62052);
/* harmony import */ var _components_icon_icon_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../../../components/icon/icon.component */ 74703);

var _class;











class SetWalletFingerprintPayPage extends _modules_page_module__WEBPACK_IMPORTED_MODULE_5__.CommonPageBase {
  constructor() {
    super(...arguments);
    /** 传进来的助剂词 */
    this.showBackupBtn = true;
  }
  /** 校验指纹 */
  checkFingerprint() {
    var _this = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      /// 判断是否被系统禁用
      const isProhibited = sessionStorage.getItem(_pages_mime_pages_verify_fingerprint_verify_fingerprint_component__WEBPACK_IMPORTED_MODULE_6__.FINGERPRINT_PROHIBITION_OF_USE);
      if (isProhibited) {
        _bnqkl_framework_plugins_toast__WEBPACK_IMPORTED_MODULE_3__.Toast.show("System fingerprinting has been disabled");
        return;
      }
      /// 判断下间隔
      const fingerprintTimestamp = Number(sessionStorage.getItem(_pages_mime_pages_verify_fingerprint_verify_fingerprint_component__WEBPACK_IMPORTED_MODULE_6__.FINGERPRINT_INTERVAL_SESSION_KEY) || 0);
      if (fingerprintTimestamp > 0) {
        const interval = Date.now() - fingerprintTimestamp;
        if (interval < 30 * 1000) {
          const waiting = 30 - Math.floor(interval / 1000);
          _bnqkl_framework_plugins_toast__WEBPACK_IMPORTED_MODULE_3__.Toast.show("Please try again in " + waiting + " seconds");
          _this.nav.back();
          return;
        }
      }
      /// 判断是否开启
      try {
        const info = yield _bnqkl_framework_plugins_biometric__WEBPACK_IMPORTED_MODULE_2__.NativeBiometric.isAvailable();
        _this.console.log(info);
        if (info.isAvailable === false) {
          _this.alert({
            bodyMessage: "Please go to the phone system to register fingerprints"
          });
          return;
        }
      } catch (error) {
        _this.alert({
          bodyMessage: "Please go to the phone system to register fingerprints"
        });
        return;
      }
      const {
        success,
        code
      } = yield _bnqkl_framework_plugins_biometric__WEBPACK_IMPORTED_MODULE_2__.NativeBiometric.verifyIdentity({
        maxAttempts: 5,
        title: "Verify Fingerprint",
        negativeButtonText: "Cancel"
      });
      if (success) {
        _bnqkl_framework_plugins_toast__WEBPACK_IMPORTED_MODULE_3__.Toast.show("Validation succeeded");
        sessionStorage.removeItem(_pages_mime_pages_verify_fingerprint_verify_fingerprint_component__WEBPACK_IMPORTED_MODULE_6__.FINGERPRINT_INTERVAL_SESSION_KEY);
        yield (0,_bnqkl_util_web_extends_promise__WEBPACK_IMPORTED_MODULE_4__.sleep)(300);
        _this.onSubmit(true);
        return;
      } else if (code != undefined) {
        if (code === 0) {
          _this.alert({
            bodyMessage: "Fingerprint verification failed"
          });
          return;
        } else if (code === 7) {
          sessionStorage.setItem(_pages_mime_pages_verify_fingerprint_verify_fingerprint_component__WEBPACK_IMPORTED_MODULE_6__.FINGERPRINT_INTERVAL_SESSION_KEY, String(Date.now()));
          const waiting = 30;
          _bnqkl_framework_plugins_toast__WEBPACK_IMPORTED_MODULE_3__.Toast.show("Please try again in " + waiting + " seconds");
          return;
        } else if (code === 9) {
          localStorage.setItem(_pages_mime_pages_verify_fingerprint_verify_fingerprint_component__WEBPACK_IMPORTED_MODULE_6__.FINGERPRINT_PROHIBITION_OF_USE, '1');
          yield _this.alert({
            bodyMessage: "The system fingerprint has been banned, please reset the system fingerprint first.",
            buttonText: "Confirm",
            footerTheme: 'blank'
          });
          return;
        }
      }
    })();
  }
  /** 提交事件 */
  onSubmit(fingerprint = false) {
    /// 创建成功页面
    this.nav.routeTo('/mnemonic/create-wallet', {
      fingerprint,
      pwd: this._data.pwd,
      mnemonic: this._data.mnemonic,
      showBackupBtn: this.showBackupBtn
    }, true);
  }
}
_class = SetWalletFingerprintPayPage;
_class.ɵfac = /*@__PURE__*/(() => {
  let ɵSetWalletFingerprintPayPage_BaseFactory;
  return function SetWalletFingerprintPayPage_Factory(t) {
    return (ɵSetWalletFingerprintPayPage_BaseFactory || (ɵSetWalletFingerprintPayPage_BaseFactory = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵgetInheritedFactory"](_class)))(t || _class);
  };
})();
_class.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵdefineComponent"]({
  type: _class,
  selectors: [["w-set-wallet-fingerprint-pay-page"]],
  inputs: {
    showBackupBtn: "showBackupBtn"
  },
  standalone: true,
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵInheritDefinitionFeature"], _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵStandaloneFeature"]],
  decls: 11,
  vars: 5,
  consts: () => {
    let i18n_0;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_FINGERPRINT_UNLOCK$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_SET_WALLET_FINGERPRINT_PAY_SET_WALLET_FINGERPRINT_PAY_COMPONENT_TS_1 = goog.getMsg("Fingerprint unlock");
      i18n_0 = MSG_EXTERNAL_FINGERPRINT_UNLOCK$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_SET_WALLET_FINGERPRINT_PAY_SET_WALLET_FINGERPRINT_PAY_COMPONENT_TS_1;
    } else {
      i18n_0 = "Fingerprint unlock";
    }
    let i18n_2;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_WHEN_TURNES_ON_YOU_CAN_USE_YOUR_FINGERPRINT_INSTEAD_OF_PASSWORD$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_SET_WALLET_FINGERPRINT_PAY_SET_WALLET_FINGERPRINT_PAY_COMPONENT_TS_3 = goog.getMsg(" When turned on, the fingerprint lock will be enabled ");
      i18n_2 = MSG_EXTERNAL_WHEN_TURNES_ON_YOU_CAN_USE_YOUR_FINGERPRINT_INSTEAD_OF_PASSWORD$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_SET_WALLET_FINGERPRINT_PAY_SET_WALLET_FINGERPRINT_PAY_COMPONENT_TS_3;
    } else {
      i18n_2 = " When turned on, the fingerprint lock will be enabled ";
    }
    let i18n_4;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_TURN_ON$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_SET_WALLET_FINGERPRINT_PAY_SET_WALLET_FINGERPRINT_PAY_COMPONENT_TS_5 = goog.getMsg(" Turn on ");
      i18n_4 = MSG_EXTERNAL_TURN_ON$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_SET_WALLET_FINGERPRINT_PAY_SET_WALLET_FINGERPRINT_PAY_COMPONENT_TS_5;
    } else {
      i18n_4 = " Turn on ";
    }
    let i18n_6;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_SKIP$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_SET_WALLET_FINGERPRINT_PAY_SET_WALLET_FINGERPRINT_PAY_COMPONENT_TS_7 = goog.getMsg(" Skip ");
      i18n_6 = MSG_EXTERNAL_SKIP$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_SET_WALLET_FINGERPRINT_PAY_SET_WALLET_FINGERPRINT_PAY_COMPONENT_TS_7;
    } else {
      i18n_6 = " Skip ";
    }
    return [["headerTitle", i18n_0, 3, "contentBackground", "headerBackground", "headerTranslucent", "contentSafeArea"], [1, "flex", "min-h-full", "flex-col", "items-center", "justify-start", "text-center"], [1, "text-title", "mb-24", "mt-11", "text-center", "text-xl"], i18n_2, [1, "text-primary", "rounded-full"], ["name", "al-touch-id", 1, "icon-14", "text-primary"], ["footer", ""], ["bnRippleButton", "", "type", "submit", 1, "h-10.5", "from-purple-gradient-start", "to-purple-gradient-end", "mb-4", "w-full", "rounded-full", "bg-gradient-to-b", "text-center", "text-sm", "text-white", 3, "click"], i18n_4, ["bnRippleButton", "", "type", "submit", 1, "h-10.5", "text-title", "border-tiny", "border-primary", "w-full", "rounded-full", "text-center", "text-sm", 3, "click"], i18n_6];
  },
  template: function SetWalletFingerprintPayPage_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "common-page", 0)(1, "div", 1)(2, "div", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵi18n"](3, 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](4, "div", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](5, "w-icon", 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](6, "div", 6)(7, "button", 7);
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("click", function SetWalletFingerprintPayPage_Template_button_click_7_listener() {
        return ctx.checkFingerprint();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵi18n"](8, 8);
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](9, "button", 9);
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("click", function SetWalletFingerprintPayPage_Template_button_click_9_listener() {
        return ctx.onSubmit();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵi18n"](10, 10);
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()()();
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("contentBackground", "grey")("headerBackground", "grey")("headerTranslucent", false)("contentSafeArea", true);
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](6);
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("@fadeInUp", undefined);
    }
  },
  dependencies: [_modules_page_module__WEBPACK_IMPORTED_MODULE_5__.CommonPageModule, _libs_bnf_components_ripple_button_ripple_button_directive__WEBPACK_IMPORTED_MODULE_7__.RippleButtonDirective, _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_8__.CommonPageComponent, _components_icon_icon_component__WEBPACK_IMPORTED_MODULE_9__.IconComponent],
  styles: ["/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsInNvdXJjZVJvb3QiOiIifQ== */"],
  data: {
    animation: [_bnqkl_framework_animations__WEBPACK_IMPORTED_MODULE_1__.fadeInUpTrigger]
  },
  changeDetection: 0
});
(0,tslib__WEBPACK_IMPORTED_MODULE_11__.__decorate)([SetWalletFingerprintPayPage.QueryParams(), (0,tslib__WEBPACK_IMPORTED_MODULE_11__.__metadata)("design:type", Object)], SetWalletFingerprintPayPage.prototype, "_data", void 0);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SetWalletFingerprintPayPage);

/***/ })

}]);
//# sourceMappingURL=apps_wallet_src_pages_mnemonic_pages_set-wallet-fingerprint-pay_set-wallet-fingerprint-pay_co-05d0b8.js.map