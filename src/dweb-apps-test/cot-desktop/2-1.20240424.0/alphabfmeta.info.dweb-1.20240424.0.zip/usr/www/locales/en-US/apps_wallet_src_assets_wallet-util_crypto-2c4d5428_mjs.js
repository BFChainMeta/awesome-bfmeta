"use strict";
(self["webpackChunkwallet"] = self["webpackChunkwallet"] || []).push([["apps_wallet_src_assets_wallet-util_crypto-2c4d5428_mjs"],{

/***/ 8319:
/*!****************************************************************!*\
  !*** ./apps/wallet/src/assets/wallet-util/crypto-2c4d5428.mjs ***!
  \****************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   hash160: () => (/* binding */ i),
/* harmony export */   hash256: () => (/* binding */ m),
/* harmony export */   ripemd160: () => (/* binding */ o),
/* harmony export */   sha1: () => (/* binding */ a),
/* harmony export */   sha256: () => (/* binding */ c),
/* harmony export */   taggedHash: () => (/* binding */ s)
/* harmony export */ });
/* harmony import */ var _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./index-766bdb76.mjs */ 59809);
/* harmony import */ var _ripemd160_3baa091d_mjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./ripemd160-3baa091d.mjs */ 70972);
/* harmony import */ var _sha1_e1635d39_mjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./sha1-e1635d39.mjs */ 57);
/* harmony import */ var _sha256_e58017d9_mjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./sha256-e58017d9.mjs */ 6612);
/* harmony import */ var _WASMInterface_b9f2203b_mjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./WASMInterface-b9f2203b.mjs */ 43670);





function o(n) {
  return _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_0__.B.from((0,_ripemd160_3baa091d_mjs__WEBPACK_IMPORTED_MODULE_1__.c)().update(n).digest());
}
function a(t) {
  return _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_0__.B.from((0,_sha1_e1635d39_mjs__WEBPACK_IMPORTED_MODULE_2__.c)().update(t).digest());
}
function c(t) {
  return _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_0__.B.from((0,_sha256_e58017d9_mjs__WEBPACK_IMPORTED_MODULE_3__.c)().update(t).digest());
}
function i(r) {
  return o(c(r));
}
function m(r) {
  return c(c(r));
}
const f = Object.fromEntries(["BIP0340/challenge", "BIP0340/aux", "BIP0340/nonce", "TapLeaf", "TapBranch", "TapSighash", "TapTweak", "KeyAgg list", "KeyAgg coefficient"].map(t => {
  const n = c(_index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_0__.B.from(t));
  return [t, _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_0__.B.concat([n, n])];
}));
function s(t, n) {
  return c(_index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_0__.B.concat([f[t], n]));
}


/***/ }),

/***/ 57:
/*!**************************************************************!*\
  !*** ./apps/wallet/src/assets/wallet-util/sha1-e1635d39.mjs ***!
  \**************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   a: () => (/* binding */ e),
/* harmony export */   c: () => (/* binding */ i),
/* harmony export */   p: () => (/* binding */ s),
/* harmony export */   s: () => (/* binding */ t)
/* harmony export */ });
/* harmony import */ var D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 52542);
/* harmony import */ var _WASMInterface_b9f2203b_mjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./WASMInterface-b9f2203b.mjs */ 43670);


const s = (0,_WASMInterface_b9f2203b_mjs__WEBPACK_IMPORTED_MODULE_1__.c)("sha1", 20),
  t = /*#__PURE__*/function () {
    var _ref = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (a) {
      return (yield s()).calculate(a);
    });
    return function t(_x) {
      return _ref.apply(this, arguments);
    };
  }(),
  e = /*#__PURE__*/function () {
    var _ref2 = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      return i(yield s());
    });
    return function e() {
      return _ref2.apply(this, arguments);
    };
  }(),
  i = (a = s.wasm) => {
    a.init();
    const t = {
      init: () => (a.init(), t),
      update: s => (a.update(s), t),
      digest: s => a.digest(s),
      save: () => a.save(),
      load: s => (a.load(s), t),
      blockSize: 64,
      digestSize: 20
    };
    return t;
  };


/***/ })

}]);
//# sourceMappingURL=apps_wallet_src_assets_wallet-util_crypto-2c4d5428_mjs.js.map