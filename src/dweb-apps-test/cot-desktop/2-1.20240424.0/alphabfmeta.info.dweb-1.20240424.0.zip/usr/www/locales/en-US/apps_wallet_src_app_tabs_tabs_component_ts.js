"use strict";
(self["webpackChunkwallet"] = self["webpackChunkwallet"] || []).push([["apps_wallet_src_app_tabs_tabs_component_ts"],{

/***/ 36713:
/*!****************************************************!*\
  !*** ./apps/wallet/src/app/tabs/tabs.component.ts ***!
  \****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   TabsComponent: () => (/* binding */ TabsComponent),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 52542);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! tslib */ 90505);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! @angular/common */ 6729);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! @angular/core */ 61039);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! @angular/router */ 56776);
/* harmony import */ var _bnqkl_framework_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @bnqkl/framework/components */ 24182);
/* harmony import */ var _bnqkl_framework_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @bnqkl/framework/core */ 63563);
/* harmony import */ var _bnqkl_framework_directives__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @bnqkl/framework/directives */ 11100);
/* harmony import */ var _bnqkl_framework_helpers__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @bnqkl/framework/helpers */ 12169);
/* harmony import */ var _bnqkl_framework_pipes__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @bnqkl/framework/pipes */ 80909);
/* harmony import */ var _bnqkl_framework_plugins_splash_screen__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @bnqkl/framework/plugins/splash-screen */ 71739);
/* harmony import */ var _bnqkl_wallet_base_services_plaoc__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @bnqkl/wallet-base/services/plaoc */ 63878);
/* harmony import */ var _components_icon_icon_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ~components/icon/icon.component */ 74703);
/* harmony import */ var _components_version_upgrade_version_upgrade_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ~components/version-upgrade/version-upgrade.service */ 8701);
/* harmony import */ var _modules_page_module__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ~modules/page.module */ 77538);
/* harmony import */ var _pages_home_home_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ~pages/home/home.component */ 87552);
/* harmony import */ var _pages_mime_mime_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ~pages/mime/mime.component */ 30381);
/* harmony import */ var _pipes_chainIcon_chain_icon_pipe__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ~pipes/chainIcon/chain-icon.pipe */ 43040);
/* harmony import */ var _services_color_color_service__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ~services/color/color.service */ 64443);
/* harmony import */ var _bnqkl_util_web_extends_promise__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @bnqkl/util-web/extends-promise */ 87778);
/* harmony import */ var _bnqkl_wallet_base_services_wallet__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @bnqkl/wallet-base/services/wallet */ 20609);
/* harmony import */ var _bnqkl_framework_plugins__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @bnqkl/framework/plugins */ 43990);
/* harmony import */ var _helpers_utils__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ~helpers/utils */ 6596);

var _class;

























const _c0 = ["navSize"];
const _c1 = ["panel"];
const _c2 = ["linkContainer"];
function TabsComponent_div_3_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelement"](0, "div", 4, 5);
  }
}
const _c3 = (a0, a1, a2, a3) => ({
  "pl-3": a0,
  "pr-3": a1,
  "mr-[40px]": a2,
  "ml-[40px]": a3
});
const _c4 = a0 => [a0];
const _c5 = a0 => ({
  suffix: a0
});
function TabsComponent_Conditional_4_ng_container_8_Template(rf, ctx) {
  if (rf & 1) {
    const _r12 = _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementStart"](1, "button", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵlistener"]("click", function TabsComponent_Conditional_4_ng_container_8_Template_button_click_1_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵrestoreView"](_r12);
      const i_r8 = restoredCtx.index;
      const ctx_r11 = _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵresetView"](ctx_r11.selectTab(i_r8));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipe"](2, "class");
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementStart"](3, "div", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelement"](4, "w-icon", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipe"](5, "chainIcon");
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const link_r7 = ctx.$implicit;
    const first_r9 = ctx.first;
    const last_r10 = ctx.last;
    const ctx_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵproperty"]("animationType", "none")("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpureFunction1"](13, _c4, _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipeBind1"](2, 3, _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpureFunction4"](8, _c3, first_r9, last_r10, first_r9, last_r10))));
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵproperty"]("name", _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipeBind2"](5, 5, link_r7.icon, _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpureFunction1"](15, _c5, ctx_r6.currLink === link_r7 ? "s" : "n")));
  }
}
function TabsComponent_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    const _r14 = _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementStart"](0, "nav", 6, 7)(2, "button", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵlistener"]("click", function TabsComponent_Conditional_4_Template_button_click_2_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵrestoreView"](_r14);
      const ctx_r13 = _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵresetView"](ctx_r13.routeToScanner());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelement"](3, "w-icon", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementStart"](4, "div", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelement"](5, "div", 11)(6, "div", 12)(7, "div", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtemplate"](8, TabsComponent_Conditional_4_ng_container_8_Template, 6, 17, "ng-container", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"](8);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵproperty"]("ngForOf", ctx_r2.links);
  }
}
const _c6 = a0 => ({
  "--page-safe-area-inset-bottom": a0
});
/**
 * 主体导航页面
 */
class TabsComponent extends (0,_bnqkl_framework_core__WEBPACK_IMPORTED_MODULE_2__.MixinBrowser)(_modules_page_module__WEBPACK_IMPORTED_MODULE_10__.CommonPageBase) {
  constructor() {
    super(...arguments);
    /** 减少日志, 如果需要, 补充 logger+=`w-tabs=enable`  */
    this.__console_internal_config__ = {
      default: 'warn',
      matchMode: 'strict'
    };
    /** 导航栏的高度 */
    this.navHeight = '0px';
    /** 所有的 tab 链接 */
    this.links = [{
      index: 0,
      animation_state: 'home',
      href: 'home',
      icon: 'btn-wallet',
      label_text: "Wallet",
      component: _pages_home_home_component__WEBPACK_IMPORTED_MODULE_11__.HomePage,
      ref: undefined
    }, {
      index: 1,
      animation_state: 'mime',
      href: 'mime',
      icon: 'btn-me',
      label_text: "Me",
      component: _pages_mime_mime_component__WEBPACK_IMPORTED_MODULE_12__.MimePage,
      ref: undefined
    }];
    /** 是否移动端 */
    this.isMobile = (0,_helpers_utils__WEBPACK_IMPORTED_MODULE_18__.isMobile)();
    /** 颜色服务 */
    this._colorService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_19__.inject)(_services_color_color_service__WEBPACK_IMPORTED_MODULE_14__.ColorService);
  }
  /** 监听导航栏的大小 */
  set navSize(obSize) {
    this.takeUntilDestroy(obSize.resized$).subscribe(size => {
      this.navHeight = size.borderHeight + 'px';
    });
  }
  initLink() {
    var _this = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      /// @TODO 根据URL来变更
      _this.currLink = _this.selectTab(0);
      /// 在有空的时候把各个页面初始化出来
      for (const link of _this.links) {
        yield (0,_bnqkl_framework_helpers__WEBPACK_IMPORTED_MODULE_4__.$requestIdleCallback)();
        _this._initLinkRef(link);
      }
    })();
  }
  hideSplashScreen() {
    _bnqkl_framework_plugins_splash_screen__WEBPACK_IMPORTED_MODULE_6__.SplashScreen.hide();
  }
  /** 配置主题风格 */
  initTheme() {
    this.nav.storeState({
      theme: this._colorService.transform('primary')
    });
  }
  /**
   * 切换 tab
   */
  selectTab(index) {
    var _this2 = this;
    const linkContainer = this.linkContainerList.get(index);
    if (linkContainer === undefined) {
      return;
    }
    const link = this.links[index];
    if (this.currLink !== link) {
      this.prevLink = this.currLink;
      this.currLink = link;
      this._initLinkRef(link, linkContainer);
      (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
        _this2.panelAnimationsStart();
        yield (0,_bnqkl_framework_helpers__WEBPACK_IMPORTED_MODULE_4__.$requestAnimationFrame)();
        yield (0,_bnqkl_framework_helpers__WEBPACK_IMPORTED_MODULE_4__.$requestAnimationFrame)();
        _this2.panelAnimationsDone();
      })();
    }
    return link;
  }
  /** 初始化页面实例 */
  _initLinkRef(link, linkContainer = this.linkContainerList.get(this.links.indexOf(link))) {
    if (link.ref === undefined && link.component !== undefined) {
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      link.ref = this._panelVcRef.createComponent(link.component);
      this.renderer2.appendChild(linkContainer === null || linkContainer === void 0 ? void 0 : linkContainer.nativeElement, link.ref.location.nativeElement);
      link.ref.instance.requestUpdate();
    }
  }
  /** 监听tab-panel动画开始 */
  panelAnimationsStart() {
    var _this$currLink;
    this.console.info('animation start');
    const page = (_this$currLink = this.currLink) === null || _this$currLink === void 0 || (_this$currLink = _this$currLink.ref) === null || _this$currLink === void 0 ? void 0 : _this$currLink.instance;
    // const prePage = this.prevLink?.ref?.instance;
    // page?.ngPageWillEnter();
    page === null || page === void 0 || page.ngOnResume('tab');
    // prePage?.ngPageWillLeave();
  }
  /** 监听tab-panel动画结束 */
  panelAnimationsDone() {
    var _this$currLink2, _page$pageTheme$, _this$prevLink;
    this.console.info('animation done');
    /// 跟随子页面的风格
    const page = (_this$currLink2 = this.currLink) === null || _this$currLink2 === void 0 || (_this$currLink2 = _this$currLink2.ref) === null || _this$currLink2 === void 0 ? void 0 : _this$currLink2.instance;
    const pageTheme = page === null || page === void 0 || (_page$pageTheme$ = page.pageTheme$) === null || _page$pageTheme$ === void 0 ? void 0 : _page$pageTheme$.value;
    if (pageTheme !== undefined) {
      var _this$pageTheme$;
      (_this$pageTheme$ = this.pageTheme$) === null || _this$pageTheme$ === void 0 || _this$pageTheme$.next(pageTheme);
    }
    // page?.ngPageDidEnter();
    const prePage = (_this$prevLink = this.prevLink) === null || _this$prevLink === void 0 || (_this$prevLink = _this$prevLink.ref) === null || _this$prevLink === void 0 ? void 0 : _this$prevLink.instance;
    // prePage?.ngPageDidLeave();
    prePage === null || prePage === void 0 || prePage.ngOnPause('tab');
  }
  /** 将页面的生命周期向内传递给tab-panel的页面 */
  ngOnPause(reason) {
    var _this$currLink3;
    super.ngOnPause(reason);
    (_this$currLink3 = this.currLink) === null || _this$currLink3 === void 0 || (_this$currLink3 = _this$currLink3.ref) === null || _this$currLink3 === void 0 || (_this$currLink3 = _this$currLink3.instance) === null || _this$currLink3 === void 0 || _this$currLink3.ngOnPause(reason);
  }
  /** 将页面的生命周期向内传递给tab-panel的页面 */
  ngOnResume(reason) {
    var _this$currLink4;
    super.ngOnResume(reason);
    (_this$currLink4 = this.currLink) === null || _this$currLink4 === void 0 || (_this$currLink4 = _this$currLink4.ref) === null || _this$currLink4 === void 0 || (_this$currLink4 = _this$currLink4.instance) === null || _this$currLink4 === void 0 || _this$currLink4.ngOnResume(reason);
  }
  // /** 将页面的生命周期向内传递给tab-panel的页面 */
  // override ngPageWillEnter() {
  //   super.ngPageWillEnter();
  //   this.currLink?.ref?.instance?.ngPageWillEnter();
  // }
  // /** 将页面的生命周期向内传递给tab-panel的页面 */
  // override ngPageWillLeave() {
  //   super.ngPageWillLeave();
  //   this.currLink?.ref?.instance?.ngPageWillLeave();
  // }
  // /** 将页面的生命周期向内传递给tab-panel的页面 */
  // override ngPageDidEnter() {
  //   super.ngPageDidEnter();
  //   this.currLink?.ref?.instance?.ngPageDidEnter();
  // }
  // /** 将页面的生命周期向内传递给tab-panel的页面 */
  // override ngPageDidLeave() {
  //   super.ngPageDidLeave();
  //   this.currLink?.ref?.instance?.ngPageDidLeave();
  // }
  initPlaocApp() {
    var _this3 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      if (_this3.environment.DWEB_APP) {
        const plaoc = _this3.injectorForceGet(_bnqkl_wallet_base_services_plaoc__WEBPACK_IMPORTED_MODULE_7__.PlaocService);
        const versionUpgradeService = _this3.injectorForceGet(_components_version_upgrade_version_upgrade_service__WEBPACK_IMPORTED_MODULE_9__.VersionUpgradeService);
        yield versionUpgradeService.needUpgradeApp.waitClose.promise;
        /// 由于可能存在弹窗，等待1.5S 避免闪烁
        yield (0,_bnqkl_util_web_extends_promise__WEBPACK_IMPORTED_MODULE_15__.sleep)(1500);
        plaoc.initAppPlaocEventListener( /*#__PURE__*/function () {
          var _ref2 = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (eventId, url) {
            /// 有登录才继续
            const walletV2Service = _this3.injectorForceGet(_bnqkl_wallet_base_services_wallet__WEBPACK_IMPORTED_MODULE_16__.WalletV2Service);
            const mainWalletExists = yield walletV2Service.initMainWallet();
            if (mainWalletExists === false) {
              return;
            }
            if (url.pathname.endsWith(_bnqkl_wallet_base_services_plaoc__WEBPACK_IMPORTED_MODULE_7__.$WALLET_PLAOC_PATH.getAddress)) {
              _this3.nav.routeTo('/authorize/address/' + Date.now(), {
                eventId,
                chainName: url.searchParams.get('chainName'),
                type: url.searchParams.get('type'),
                signMessage: url.searchParams.get('signMessage') || ''
              });
            } else if (url.pathname.endsWith(_bnqkl_wallet_base_services_plaoc__WEBPACK_IMPORTED_MODULE_7__.$WALLET_PLAOC_PATH.signature)) {
              _this3.nav.routeTo('/authorize/signature/' + Date.now(), {
                eventId,
                signaturedata: url.searchParams.get('signaturedata')
              });
            }
            _this3.cdRef.detectChanges();
          });
          return function (_x, _x2) {
            return _ref2.apply(this, arguments);
          };
        }());
      }
    })();
  }
  /**
   * 跳转到扫一扫页面
   * 后续功能在home.ts内实现，这边只处理页面进入
   */
  routeToScanner() {
    // 暂时只提供QR_CODE
    this.nav.routeTo('scanner', {
      scanType: _bnqkl_framework_plugins__WEBPACK_IMPORTED_MODULE_17__.SUPPORTED_FORMAT.QR_CODE,
      cameraDirection: _bnqkl_framework_plugins__WEBPACK_IMPORTED_MODULE_17__.CAMERA_DIRECTION.BACK
    });
  }
}
_class = TabsComponent;
_class.ɵfac = /*@__PURE__*/(() => {
  let ɵTabsComponent_BaseFactory;
  return function TabsComponent_Factory(t) {
    return (ɵTabsComponent_BaseFactory || (ɵTabsComponent_BaseFactory = _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵgetInheritedFactory"](_class)))(t || _class);
  };
})();
_class.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵdefineComponent"]({
  type: _class,
  selectors: [["w-tabs"]],
  viewQuery: function TabsComponent_Query(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵviewQuery"](_c0, 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵviewQuery"](_c1, 5, _angular_core__WEBPACK_IMPORTED_MODULE_19__.ViewContainerRef);
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵviewQuery"](_c2, 5, _angular_core__WEBPACK_IMPORTED_MODULE_19__.ElementRef);
    }
    if (rf & 2) {
      let _t;
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵloadQuery"]()) && (ctx.navSize = _t.first);
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵloadQuery"]()) && (ctx._panelVcRef = _t.first);
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵloadQuery"]()) && (ctx.linkContainerList = _t);
    }
  },
  standalone: true,
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵInheritDefinitionFeature"], _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵStandaloneFeature"], _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵHostDirectivesFeature"]([_bnqkl_framework_core__WEBPACK_IMPORTED_MODULE_2__.ThemeStorageDirective])],
  decls: 5,
  vars: 7,
  consts: [["wTabGroup", "", 1, "grid-in-[panel/panel/tabs/tabs]", "z-[1]", "grid", "flex-grow", "grid-flow-col", "overflow-hidden", 3, "ngStyle", "selectedIndex", "scrollSmooth", "selectedIndexChange$"], ["panel", ""], ["class", "w-cqw-100 block h-full overflow-hidden", "wTab", "", 4, "ngFor", "ngForOf"], ["class", "grid-in-[tabs] bg-grey relative z-[2] pt-[34px]", "wObSize", ""], ["wTab", "", 1, "w-cqw-100", "block", "h-full", "overflow-hidden"], ["linkContainer", ""], ["wObSize", "", 1, "grid-in-[tabs]", "bg-grey", "relative", "z-[2]", "pt-[34px]"], ["navSize", "obSize"], ["bnRippleButton", "", 1, "_scan-btn", "absolute", "z-10", "flex", "items-center", "justify-center", 3, "click"], ["name", "scan", 1, "icon-7", "text-white"], [1, "_tabs", "rounded-t-5", "relative", "flex", "overflow-hidden"], [1, "_depressed-mask"], [1, "_bottom-color-completion", "let-0", "absolute", "top-0", "bg-black"], [1, "_bottom-color-completion", "absolute", "right-0", "top-0", "bg-black"], [4, "ngFor", "ngForOf"], ["bnRippleButton", "", 1, "text-primary", "relative", "h-16", "flex-1", 3, "animationType", "ngClass", "click"], [1, "relative", "grid", "place-items-center", "pb-2.5", "pt-2.5"], [1, "text-2xl", 3, "name"]],
  template: function TabsComponent_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementStart"](0, "main", 0);
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵlistener"]("selectedIndexChange$", function TabsComponent_Template_main_selectedIndexChange__0_listener($event) {
        return ctx.selectTab($event);
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementContainer"](1, null, 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtemplate"](3, TabsComponent_div_3_Template, 2, 0, "div", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtemplate"](4, TabsComponent_Conditional_4_Template, 9, 1, "nav", 3);
    }
    if (rf & 2) {
      let tmp_1_0;
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵproperty"]("ngStyle", _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpureFunction1"](5, _c6, ctx.navHeight))("selectedIndex", (tmp_1_0 = ctx.currLink == null ? null : ctx.currLink.index) !== null && tmp_1_0 !== undefined ? tmp_1_0 : 0)("scrollSmooth", false);
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵproperty"]("ngForOf", ctx.links);
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵconditional"](4, ctx.isMobile ? 4 : -1);
    }
  },
  dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_20__.CommonModule, _angular_common__WEBPACK_IMPORTED_MODULE_20__.NgClass, _angular_common__WEBPACK_IMPORTED_MODULE_20__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_20__.NgStyle, _angular_router__WEBPACK_IMPORTED_MODULE_21__.RouterModule,
  /// Component
  _bnqkl_framework_components__WEBPACK_IMPORTED_MODULE_1__.RippleButtonDirective, _components_icon_icon_component__WEBPACK_IMPORTED_MODULE_8__.IconComponent, _bnqkl_framework_pipes__WEBPACK_IMPORTED_MODULE_5__.ClassPipe, _pipes_chainIcon_chain_icon_pipe__WEBPACK_IMPORTED_MODULE_13__.ChainIconPipe,
  /// Directive
  _bnqkl_framework_directives__WEBPACK_IMPORTED_MODULE_3__.ObSizeDirective, _bnqkl_framework_directives__WEBPACK_IMPORTED_MODULE_3__.TabGroupDirective, _bnqkl_framework_directives__WEBPACK_IMPORTED_MODULE_3__.TabDirective],
  styles: ["@charset \"UTF-8\";\n[_nghost-%COMP%] {\n  width: 100%;\n  height: 100%;\n  display: grid;\n  \n\n\n\n\n  grid: 1fr auto/1fr;\n  grid-template-areas: \"panel\" \"tabs\";\n}\n[_nghost-%COMP%]   ._active-border[_ngcontent-%COMP%]{\n  position: absolute;\n  left: 50%;\n  top: 50%;\n  height: 3rem;\n  width: 3rem;\n  transform-origin: center;\n  border-radius: 9999px;\n  border-width: 1px;\n  border-style: solid;\n  border-color: rgb(255 255 255 / 0.5);\n  transform: translate(-50%, -50%);\n}\n[_nghost-%COMP%]   ._scan-btn[_ngcontent-%COMP%] {\n  background: linear-gradient(315deg, #8474fc 0%, #ff61e1 50%, #ff9ef5 100%);\n  border-radius: 50%;\n  width: 60px;\n  height: 60px;\n  top: 4px;\n  left: calc(50% - 29px);\n}\n[_nghost-%COMP%]   ._tabs[_ngcontent-%COMP%] {\n  width: 100%;\n  height: 84px;\n}\n[_nghost-%COMP%]   ._tabs[_ngcontent-%COMP%]   ._depressed-mask[_ngcontent-%COMP%] {\n  -webkit-mask-image: url('bg-tabs-mask.png');\n          mask-image: url('bg-tabs-mask.png');\n  -webkit-mask-size: auto 100%;\n          mask-size: auto 100%;\n  -webkit-mask-position: top center;\n          mask-position: top center;\n  -webkit-mask-repeat: no-repeat;\n          mask-repeat: no-repeat;\n  background-repeat: no-repeat;\n  background-color: black;\n  width: 100%;\n  height: 100%;\n  position: absolute;\n  inset: 0 0 0 0;\n}\n[_nghost-%COMP%]   ._tabs[_ngcontent-%COMP%]   ._bottom-color-completion[_ngcontent-%COMP%] {\n  width: calc(50% - 80px);\n  height: 100%;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL2FwcHMvd2FsbGV0L3NyYy9hcHAvdGFicy90YWJzLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLGdCQUFnQjtBQUFoQjtFQUNFLFdBQUE7RUFDQSxZQUFBO0VBQ0EsYUFBQTtFQUNBOzs7SUFBQTtFQUlBLGtCQUFBO0VBQ0EsbUNBQUE7QUFFRjtBQUNJO0VBQUEsa0JBQUE7RUFBQSxTQUFBO0VBQUEsUUFBQTtFQUFBLFlBQUE7RUFBQSxXQUFBO0VBQUEsd0JBQUE7RUFBQSxxQkFBQTtFQUFBLGlCQUFBO0VBQUEsbUJBQUE7RUFBQSxvQ0FBQTtFQUNBO0FBREE7QUFJRjtFQUNFLDBFQUFBO0VBQ0Esa0JBQUE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtFQUNBLFFBQUE7RUFDQSxzQkFBQTtBQUNKO0FBRUU7RUFDRSxXQUFBO0VBQ0EsWUFBQTtBQUFKO0FBRUk7RUFDRSwyQ0FBQTtVQUFBLG1DQUFBO0VBQ0EsNEJBQUE7VUFBQSxvQkFBQTtFQUNBLGlDQUFBO1VBQUEseUJBQUE7RUFDQSw4QkFBQTtVQUFBLHNCQUFBO0VBQ0EsNEJBQUE7RUFDQSx1QkFBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0VBQ0Esa0JBQUE7RUFDQSxjQUFBO0FBQU47QUFHSTtFQUNFLHVCQUFBO0VBQ0EsWUFBQTtBQUROIiwic291cmNlc0NvbnRlbnQiOlsiOmhvc3Qge1xyXG4gIHdpZHRoOiAxMDAlO1xyXG4gIGhlaWdodDogMTAwJTtcclxuICBkaXNwbGF5OiBncmlkO1xyXG4gIC8qKlxyXG4gICAqIHJvd3Mgw6bCqMKqw6XCkMKRIMOmwpzCicOkwrjCpMOkwrjCqsOlwozCusOlwp/CnyAgMWZyIGF1dG9cclxuICAgKiBjb2x1bW5zIMOnwrrCtcOlwpDCkcOmwpzCicOkwrjCgMOkwrjCqsOlwozCusOlwp/CnyAxZnJcclxuICAgKi9cclxuICBncmlkOiAxZnIgYXV0byAvIDFmcjtcclxuICBncmlkLXRlbXBsYXRlLWFyZWFzOiAncGFuZWwnICd0YWJzJztcclxuXHJcbiAgLl9hY3RpdmUtYm9yZGVyIHtcclxuICAgIEBhcHBseSBhYnNvbHV0ZSBsZWZ0LTEvMiB0b3AtMS8yIGgtMTIgdy0xMiBvcmlnaW4tY2VudGVyIHJvdW5kZWQtZnVsbCBib3JkZXIgYm9yZGVyLXNvbGlkIGJvcmRlci13aGl0ZS81MDtcclxuICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlKC01MCUsIC01MCUpO1xyXG4gIH1cclxuXHJcbiAgLl9zY2FuLWJ0biB7XHJcbiAgICBiYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoMzE1ZGVnLCAjODQ3NGZjIDAlLCAjZmY2MWUxIDUwJSwgI2ZmOWVmNSAxMDAlKTtcclxuICAgIGJvcmRlci1yYWRpdXM6IDUwJTtcclxuICAgIHdpZHRoOiA2MHB4O1xyXG4gICAgaGVpZ2h0OiA2MHB4O1xyXG4gICAgdG9wOiA0cHg7XHJcbiAgICBsZWZ0OiBjYWxjKDUwJSAtIDI5cHgpO1xyXG4gIH1cclxuXHJcbiAgLl90YWJzIHtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgaGVpZ2h0OiA4NHB4O1xyXG5cclxuICAgIC5fZGVwcmVzc2VkLW1hc2sge1xyXG4gICAgICBtYXNrLWltYWdlOiB1cmwoJy4vYXNzZXRzL2ltYWdlcy9iZy10YWJzLW1hc2sucG5nJyk7XHJcbiAgICAgIG1hc2stc2l6ZTogYXV0byAxMDAlO1xyXG4gICAgICBtYXNrLXBvc2l0aW9uOiB0b3AgY2VudGVyO1xyXG4gICAgICBtYXNrLXJlcGVhdDogbm8tcmVwZWF0O1xyXG4gICAgICBiYWNrZ3JvdW5kLXJlcGVhdDogbm8tcmVwZWF0O1xyXG4gICAgICBiYWNrZ3JvdW5kLWNvbG9yOiBibGFjaztcclxuICAgICAgd2lkdGg6IDEwMCU7XHJcbiAgICAgIGhlaWdodDogMTAwJTtcclxuICAgICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgICBpbnNldDogMCAwIDAgMDtcclxuICAgIH1cclxuXHJcbiAgICAuX2JvdHRvbS1jb2xvci1jb21wbGV0aW9uIHtcclxuICAgICAgd2lkdGg6IGNhbGMoNTAlIC0gODBweCk7XHJcbiAgICAgIGhlaWdodDogMTAwJTtcclxuICAgIH1cclxuICB9XHJcbn1cclxuXHJcbi8vIC4tLXJvdXRlci1vdXRsZXQtY29udGFpbmVyIHtcclxuLy8gICBncmlkLWFyZWE6IHBhbmVsIC8gcGFuZWwgLyB0YWJzIC8gdGFicztcclxuLy8gICB6LWluZGV4OiAxO1xyXG4vLyAgIGRpc3BsYXk6IGdyaWQ7XHJcbi8vICAgZ3JpZDogMWZyLzFmcjtcclxuLy8gICBncmlkLXRlbXBsYXRlLWFyZWFzOiAncGFuZWwnO1xyXG4vLyAgIDo6bmctZGVlcCA+ICoge1xyXG4vLyAgICAgZ3JpZC1hcmVhOiBwYW5lbDtcclxuXHJcbi8vICAgICBkaXNwbGF5OiBibG9jaztcclxuLy8gICAgIGhlaWdodDogMTAwJTtcclxuLy8gICAgIG92ZXJmbG93OiBoaWRkZW47XHJcbi8vICAgfVxyXG4vLyB9XHJcbi8vIC4tLXJvdXRlci1uYXYge1xyXG4vLyAgIGdyaWQtYXJlYTogdGFicztcclxuLy8gICB6LWluZGV4OiAyO1xyXG4vLyAgIC4tLWxhYmVsIHtcclxuLy8gICAgIEBhcHBseSB0ZXh0LXRleHQ7XHJcbi8vICAgfVxyXG4vLyAgIC4tLWFjdGl2ZWQge1xyXG4vLyAgICAgLi0tbGFiZWwge1xyXG4vLyAgICAgICBAYXBwbHkgdGV4dC1wcmltYXJ5O1xyXG4vLyAgICAgfVxyXG4vLyAgICAgLi0taWNvbi12aWV3Ym94IHtcclxuLy8gICAgICAgYW5pbWF0aW9uLW5hbWU6IGFuaS10YWItaWNvbjtcclxuLy8gICAgIH1cclxuLy8gICB9XHJcbi8vIH1cclxuXHJcbi8vIEBpbmNsdWRlIG1hdC50YWJzLXR5cG9ncmEoJHdhbGxldC1hcHAtdGhlbWUpO1xyXG4iXSwic291cmNlUm9vdCI6IiJ9 */"],
  changeDetection: 0
});
(0,tslib__WEBPACK_IMPORTED_MODULE_22__.__decorate)([TabsComponent.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_22__.__metadata)("design:type", Object)], TabsComponent.prototype, "navHeight", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_22__.__decorate)([TabsComponent.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_22__.__metadata)("design:type", Object)], TabsComponent.prototype, "currLink", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_22__.__decorate)([TabsComponent.AfterViewInit(), (0,tslib__WEBPACK_IMPORTED_MODULE_22__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_22__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_22__.__metadata)("design:returntype", Promise)], TabsComponent.prototype, "initLink", null);
(0,tslib__WEBPACK_IMPORTED_MODULE_22__.__decorate)([TabsComponent.OnInit(), (0,tslib__WEBPACK_IMPORTED_MODULE_22__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_22__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_22__.__metadata)("design:returntype", void 0)], TabsComponent.prototype, "hideSplashScreen", null);
(0,tslib__WEBPACK_IMPORTED_MODULE_22__.__decorate)([TabsComponent.OnInit(), (0,tslib__WEBPACK_IMPORTED_MODULE_22__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_22__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_22__.__metadata)("design:returntype", void 0)], TabsComponent.prototype, "initTheme", null);
(0,tslib__WEBPACK_IMPORTED_MODULE_22__.__decorate)([TabsComponent.OnReady(), (0,tslib__WEBPACK_IMPORTED_MODULE_22__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_22__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_22__.__metadata)("design:returntype", Promise)], TabsComponent.prototype, "initPlaocApp", null);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (TabsComponent);

/***/ })

}]);
//# sourceMappingURL=apps_wallet_src_app_tabs_tabs_component_ts.js.map