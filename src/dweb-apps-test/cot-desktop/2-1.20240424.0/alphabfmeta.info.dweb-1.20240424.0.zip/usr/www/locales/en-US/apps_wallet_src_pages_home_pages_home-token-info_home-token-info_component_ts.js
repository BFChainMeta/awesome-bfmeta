"use strict";
(self["webpackChunkwallet"] = self["webpackChunkwallet"] || []).push([["apps_wallet_src_pages_home_pages_home-token-info_home-token-info_component_ts"],{

/***/ 36490:
/*!***************************************************************************************!*\
  !*** ./apps/wallet/src/pages/home/pages/home-token-info/home-token-info.component.ts ***!
  \***************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   HomeTokenInfoPage: () => (/* binding */ HomeTokenInfoPage),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 52542);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! tslib */ 90505);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/core */ 61039);
/* harmony import */ var _modules_page_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ~modules/page.module */ 77538);
/* harmony import */ var _bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @bnqkl/wallet-base/services/wallet/chain-base */ 27187);
/* harmony import */ var _bnqkl_wallet_base_services_wallet_chain__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @bnqkl/wallet-base/services/wallet/chain */ 27434);
/* harmony import */ var _bnqkl_wallet_base_services_wallet_wallet_data_storage__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @bnqkl/wallet-base/services/wallet/wallet-data-storage */ 63024);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/common */ 6729);
/* harmony import */ var _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../../../../../libs/bnf/modules/page/common-page/common-page.component */ 62052);
/* harmony import */ var _components_icon_icon_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../../components/icon/icon.component */ 74703);
/* harmony import */ var _libs_bnf_pipes_day_format_day_format_pipe__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../../../../../libs/bnf/pipes/day-format/day-format.pipe */ 24562);
/* harmony import */ var _libs_bnf_pipes_number_format_number_format_pipe__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../../../../../libs/bnf/pipes/number-format/number-format.pipe */ 89873);
/* harmony import */ var _libs_bnf_pipes_amountFixed_amount_fixed_pipe__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../../../../../../libs/bnf/pipes/amountFixed/amount-fixed.pipe */ 44070);
/* harmony import */ var _pipes_chainIcon_chain_icon_pipe__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../../../pipes/chainIcon/chain-icon.pipe */ 43040);

var _class;














function HomeTokenInfoPage_ng_container_3_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](1, "img", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵclassProp"]("rounded-full", ctx_r0.isBioforestChain);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("src", ctx_r0.tokenInfo.logoUrl, _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵsanitizeUrl"]);
  }
}
const _c0 = a0 => ({
  chain: a0,
  prefix: "icon"
});
function HomeTokenInfoPage_ng_template_4_ng_container_0_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](1, "w-icon", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](2, "chainIcon");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const ctx_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("name", _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind2"](2, 1, ctx_r6.tokenInfo.assetType, _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpureFunction1"](4, _c0, ctx_r6.tokenInfo.chain)));
  }
}
function HomeTokenInfoPage_ng_template_4_ng_template_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](0, "w-icon", 10);
  }
}
function HomeTokenInfoPage_ng_template_4_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](0, HomeTokenInfoPage_ng_template_4_ng_container_0_Template, 3, 6, "ng-container", 3)(1, HomeTokenInfoPage_ng_template_4_ng_template_1_Template, 1, 0, "ng-template", null, 8, _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplateRefExtractor"]);
  }
  if (rf & 2) {
    const _r8 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵreference"](2);
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngIf", ctx_r1.isLocalLogo(ctx_r1.tokenInfo.assetType, ctx_r1.tokenInfo.chain))("ngIfElse", _r8);
  }
}
function HomeTokenInfoPage_ng_container_8_div_7_span_7_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "span", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r11 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](ctx_r11.tokenInfo.chainSymbol);
  }
}
const _c13 = () => ({
  round: true
});
function HomeTokenInfoPage_ng_container_8_div_7_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "div", 11)(1, "span", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵi18n"](2, 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](3, "span", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](5, "numberFormat");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](6, "amountFixed");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](7, HomeTokenInfoPage_ng_container_8_div_7_span_7_Template, 2, 1, "span", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r9 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate1"](" ", ctx_r9.tokenInfo.frozenMainAssetPrealnum ? _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind1"](5, 2, _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind3"](6, 4, ctx_r9.tokenInfo.frozenMainAssetPrealnum, ctx_r9.decimals, _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpureFunction0"](8, _c13))) : "--", " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngIf", ctx_r9.tokenInfo.frozenMainAssetPrealnum);
  }
}
function HomeTokenInfoPage_ng_container_8_span_15_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "span", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r10 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](ctx_r10.tokenInfo.assetType);
  }
}
function HomeTokenInfoPage_ng_container_8_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](1, "div", 11)(2, "span", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵi18n"](3, 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](4, "span", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](6, "dayFormat");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](7, HomeTokenInfoPage_ng_container_8_div_7_Template, 8, 9, "div", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](8, "div", 11)(9, "span", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵi18n"](10, 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](11, "span", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](12);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](13, "numberFormat");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](14, "amountFixed");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](15, HomeTokenInfoPage_ng_container_8_span_15_Template, 2, 1, "span", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](16, "div", 11)(17, "span", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵi18n"](18, 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](19, "span", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](20);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](21, "numberFormat");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](22, "amountFixed");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](23, "span", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](24);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](25, "div", 11)(26, "span", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵi18n"](27, 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](28, "span", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](29);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](30, "div", 11)(31, "span", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵi18n"](32, 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](33, "span", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](34);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate1"](" ", ctx_r3.tokenInfo.publishTime ? _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind2"](6, 8, ctx_r3.tokenInfo.publishTime, "YYYY-MM-DD") : "--", " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngIf", ctx_r3.tokenInfo.assetType !== ctx_r3.tokenInfo.chainSymbol);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate1"](" ", ctx_r3.tokenInfo.issuedAssetPrealnum ? _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind1"](13, 11, _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind3"](14, 13, ctx_r3.tokenInfo.issuedAssetPrealnum, ctx_r3.decimals, _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpureFunction0"](23, _c13))) : "--", " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngIf", ctx_r3.tokenInfo.issuedAssetPrealnum);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate1"](" ", ctx_r3.tokenInfo.remainAssetPrealnum ? _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind1"](21, 17, _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind3"](22, 19, ctx_r3.tokenInfo.remainAssetPrealnum, ctx_r3.decimals, _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpureFunction0"](24, _c13))) : "--", " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](ctx_r3.tokenInfo.assetType);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate1"](" ", ctx_r3.tokenInfo.applyAddress || "--", " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate1"](" ", ctx_r3.tokenInfo.genesisAddress || "--", " ");
  }
}
function HomeTokenInfoPage_ng_template_9_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "div", 11)(1, "span", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵi18n"](2, 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](3, "span", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](5, "div", 11)(6, "span", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵi18n"](7, 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](8, "span", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](9);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](10, "div", 11)(11, "span", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵi18n"](12, 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](13, "span", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](14);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](15, "div", 11)(16, "span", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵi18n"](17, 26);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](18, "span", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](19);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](20, "numberFormat");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](21, "amountFixed");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](22, "div", 11)(23, "span", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵi18n"](24, 27);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](25, "span", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](26);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](27, "dayFormat");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate1"](" ", ctx_r4.tokenInfo.project || "--", " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate1"](" ", ctx_r4.tokenInfo.website || "--", " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate1"](" ", ctx_r4.tokenInfo.applyAddress || "--", " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate1"](" ", ctx_r4.tokenInfo.issuedAssetPrealnum ? _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind1"](20, 5, _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind3"](21, 7, ctx_r4.tokenInfo.issuedAssetPrealnum, ctx_r4.decimals, _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpureFunction0"](14, _c13))) : "--", " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](7);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate1"](" ", ctx_r4.tokenInfo.publishTime ? _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind2"](27, 11, ctx_r4.tokenInfo.publishTime, "YYYY-MM-DD") : "--", " ");
  }
}
/**
 * 币种详情页
 */
class HomeTokenInfoPage extends _modules_page_module__WEBPACK_IMPORTED_MODULE_1__.CommonPageBase {
  constructor() {
    super(...arguments);
    /** 链服务 */
    this.chainService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_11__.inject)(_bnqkl_wallet_base_services_wallet_chain__WEBPACK_IMPORTED_MODULE_3__.ChainService);
    /** 钱包存储服务 */
    this.chainTokenDetailStoreService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_11__.inject)(_bnqkl_wallet_base_services_wallet_wallet_data_storage__WEBPACK_IMPORTED_MODULE_4__.ChainTokenDetailStoreService);
    /** 传入数据 */
    this.decimals = 0;
    /** 币种信息 */
    this.tokenInfo = {
      chain: '',
      assetType: '',
      logoUrl: '',
      applyAddress: '',
      publishTime: 0,
      issuedAssetPrealnum: '',
      chainSymbol: '',
      // 生物链林字段
      frozenMainAssetPrealnum: '',
      genesisAddress: '',
      remainAssetPrealnum: '',
      sourceChainMagic: '',
      sourceChainName: '',
      // 外链字段
      project: '',
      website: '',
      decimals: 0
    };
  }
  /** 初始化获取传参 */
  getTokenDetail() {
    var _this = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      /** 设置基础信息 */
      const setAssetInfo = /*#__PURE__*/function () {
        var _ref = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (info) {
          _this.tokenInfo.chain = info.chain;
          _this.tokenInfo.assetType = info.assetType;
          _this.tokenInfo.applyAddress = info.applyAddress;
          const chainInfo = _this.chainService.getChainInfo(_this.tokenInfo.chain);
          _this.tokenInfo.chainSymbol = chainInfo.symbol;
          const caCheData = yield _this.chainTokenDetailStoreService.getChainTokenDetail(_this.tokenInfo.chain, _this.tokenInfo.assetType, _this.tokenInfo.applyAddress);
          _this.tokenInfo = Object.assign(_this.tokenInfo, caCheData);
          _this.cdRef.detectChanges();
        });
        return function setAssetInfo(_x) {
          return _ref.apply(this, arguments);
        };
      }();
      const {
        _data
      } = _this;
      yield setAssetInfo(_data);
      _this.queryTokenDetail();
    })();
  }
  /** 查询币种详情 */
  queryTokenDetail() {
    var _this2 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const apiChain = _this2.chainService.getChainService(_this2.tokenInfo.chain);
      const queryTask = apiChain.getTokenDetail({
        assetType: _this2.tokenInfo.assetType,
        address: _this2.tokenInfo.applyAddress,
        chainSymbol: _this2.tokenInfo.chainSymbol,
        chain: _this2.tokenInfo.chain
      });
      const data = yield queryTask;
      _this2.tokenInfo = Object.assign(_this2.tokenInfo, data);
      yield _this2.chainTokenDetailStoreService.updateChainTokenDetail(_this2.tokenInfo);
      _this2.cdRef.detectChanges();
    })();
  }
  /** 是否是生物链林-链 */
  get isBioforestChain() {
    return this.chainService.isBioforestChainByChainName(this.tokenInfo.chain);
  }
  /** 本地是否存在图标 */
  isLocalLogo(assetType, chain) {
    return (0,_bnqkl_wallet_base_services_wallet_chain_base__WEBPACK_IMPORTED_MODULE_2__.CHECK_LOCAL_ASSET_LOGO)(assetType, chain);
  }
}
_class = HomeTokenInfoPage;
_class.ɵfac = /*@__PURE__*/(() => {
  let ɵHomeTokenInfoPage_BaseFactory;
  return function HomeTokenInfoPage_Factory(t) {
    return (ɵHomeTokenInfoPage_BaseFactory || (ɵHomeTokenInfoPage_BaseFactory = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵgetInheritedFactory"](_class)))(t || _class);
  };
})();
_class.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdefineComponent"]({
  type: _class,
  selectors: [["w-home-token-info-page"]],
  standalone: true,
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵInheritDefinitionFeature"], _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵStandaloneFeature"]],
  decls: 11,
  vars: 7,
  consts: () => {
    let i18n_1;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_DATE_CREATED$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_TOKEN_INFO_HOME_TOKEN_INFO_COMPONENT_TS__2 = goog.getMsg("Date Created");
      i18n_1 = MSG_EXTERNAL_DATE_CREATED$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_TOKEN_INFO_HOME_TOKEN_INFO_COMPONENT_TS__2;
    } else {
      i18n_1 = "Date Created";
    }
    let i18n_3;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_ISSUED_ASSET_PREALNUM$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_TOKEN_INFO_HOME_TOKEN_INFO_COMPONENT_TS__4 = goog.getMsg("Issued Asset Prealnum");
      i18n_3 = MSG_EXTERNAL_ISSUED_ASSET_PREALNUM$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_TOKEN_INFO_HOME_TOKEN_INFO_COMPONENT_TS__4;
    } else {
      i18n_3 = "Issued Asset Prealnum";
    }
    let i18n_5;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_REMAIN_ASSET_PREALNUM$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_TOKEN_INFO_HOME_TOKEN_INFO_COMPONENT_TS__6 = goog.getMsg("Remain Asset Prealnum");
      i18n_5 = MSG_EXTERNAL_REMAIN_ASSET_PREALNUM$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_TOKEN_INFO_HOME_TOKEN_INFO_COMPONENT_TS__6;
    } else {
      i18n_5 = "Remain Asset Prealnum";
    }
    let i18n_7;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_APPLY_ADDRESS$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_TOKEN_INFO_HOME_TOKEN_INFO_COMPONENT_TS__8 = goog.getMsg("Apply Address");
      i18n_7 = MSG_EXTERNAL_APPLY_ADDRESS$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_TOKEN_INFO_HOME_TOKEN_INFO_COMPONENT_TS__8;
    } else {
      i18n_7 = "Apply Address";
    }
    let i18n_9;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_GENESISADDRESS$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_TOKEN_INFO_HOME_TOKEN_INFO_COMPONENT_TS__10 = goog.getMsg("Genesis Address");
      i18n_9 = MSG_EXTERNAL_GENESISADDRESS$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_TOKEN_INFO_HOME_TOKEN_INFO_COMPONENT_TS__10;
    } else {
      i18n_9 = "Genesis Address";
    }
    let i18n_11;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_FROZE_MAIN_ASSET_PREALNUM$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_TOKEN_INFO_HOME_TOKEN_INFO_COMPONENT_TS___12 = goog.getMsg(" Frozen Main Asset Prealnum ");
      i18n_11 = MSG_EXTERNAL_FROZE_MAIN_ASSET_PREALNUM$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_TOKEN_INFO_HOME_TOKEN_INFO_COMPONENT_TS___12;
    } else {
      i18n_11 = " Frozen Main Asset Prealnum ";
    }
    let i18n_14;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_PROJECT$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_TOKEN_INFO_HOME_TOKEN_INFO_COMPONENT_TS__15 = goog.getMsg("Project");
      i18n_14 = MSG_EXTERNAL_PROJECT$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_TOKEN_INFO_HOME_TOKEN_INFO_COMPONENT_TS__15;
    } else {
      i18n_14 = "Project";
    }
    let i18n_16;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_WEBSITE$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_TOKEN_INFO_HOME_TOKEN_INFO_COMPONENT_TS__17 = goog.getMsg("Website");
      i18n_16 = MSG_EXTERNAL_WEBSITE$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_TOKEN_INFO_HOME_TOKEN_INFO_COMPONENT_TS__17;
    } else {
      i18n_16 = "Website";
    }
    let i18n_18;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_CONTRACT_ADDRESS$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_TOKEN_INFO_HOME_TOKEN_INFO_COMPONENT_TS__19 = goog.getMsg("Contract Address");
      i18n_18 = MSG_EXTERNAL_CONTRACT_ADDRESS$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_TOKEN_INFO_HOME_TOKEN_INFO_COMPONENT_TS__19;
    } else {
      i18n_18 = "Contract Address";
    }
    let i18n_20;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_TOTAL_SUPPLY$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_TOKEN_INFO_HOME_TOKEN_INFO_COMPONENT_TS__21 = goog.getMsg("Total Supply");
      i18n_20 = MSG_EXTERNAL_TOTAL_SUPPLY$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_TOKEN_INFO_HOME_TOKEN_INFO_COMPONENT_TS__21;
    } else {
      i18n_20 = "Total Supply";
    }
    let i18n_22;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_PUBLISH_DATE$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_TOKEN_INFO_HOME_TOKEN_INFO_COMPONENT_TS__23 = goog.getMsg("Publish Date");
      i18n_22 = MSG_EXTERNAL_PUBLISH_DATE$$APPS_WALLET_SRC_PAGES_HOME_PAGES_HOME_TOKEN_INFO_HOME_TOKEN_INFO_COMPONENT_TS__23;
    } else {
      i18n_22 = "Publish Date";
    }
    return [[3, "headerTitle", "contentSafeArea"], [1, "text-title-400", "box-border", "flex", "flex-col", "items-center", "py-8"], [1, "h-17", "mb-2", "flex", "w-full", "justify-center"], [4, "ngIf", "ngIfElse"], ["wIconViewByToken", ""], [1, "mb-8", "w-full", "text-center", "text-base", "font-bold", "tracking-normal"], ["showView", ""], [1, "_bioforest_asset_logo", "text-6xl", 3, "src"], ["wIconViewBySymbol", ""], [1, "text-6xl", 3, "name"], ["name", "icon-default", 1, "text-6xl"], [1, "mb-6", "flex", "w-full", "justify-between", "text-sm", "font-normal", "tracking-normal"], [1, "text-subtext", "w-24", "flex-shrink-0"], i18n_1, [1, "text-title", "flex", "flex-grow", "flex-wrap", "justify-end", "break-all", "text-right"], ["class", "mb-6 flex w-full justify-between text-sm font-normal tracking-normal", 4, "ngIf"], i18n_3, ["class", "ml-1", 4, "ngIf"], i18n_5, [1, "ml-1"], i18n_7, i18n_9, i18n_11, i18n_14, i18n_16, i18n_18, i18n_20, i18n_22];
  },
  template: function HomeTokenInfoPage_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "common-page", 0)(1, "div", 1)(2, "div", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](3, HomeTokenInfoPage_ng_container_3_Template, 2, 3, "ng-container", 3)(4, HomeTokenInfoPage_ng_template_4_Template, 3, 2, "ng-template", null, 4, _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplateRefExtractor"]);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](6, "div", 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](7);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](8, HomeTokenInfoPage_ng_container_8_Template, 35, 25, "ng-container", 3)(9, HomeTokenInfoPage_ng_template_9_Template, 28, 15, "ng-template", null, 6, _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplateRefExtractor"]);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()();
    }
    if (rf & 2) {
      const _r2 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵreference"](5);
      const _r5 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵreference"](10);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("headerTitle", ctx.tokenInfo.assetType)("contentSafeArea", true);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngIf", ctx.tokenInfo.logoUrl)("ngIfElse", _r2);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](4);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](ctx.tokenInfo.assetType);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngIf", ctx.isBioforestChain)("ngIfElse", _r5);
    }
  },
  dependencies: [_modules_page_module__WEBPACK_IMPORTED_MODULE_1__.CommonPageModule, _angular_common__WEBPACK_IMPORTED_MODULE_12__.NgIf, _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_5__.CommonPageComponent, _components_icon_icon_component__WEBPACK_IMPORTED_MODULE_6__.IconComponent, _libs_bnf_pipes_day_format_day_format_pipe__WEBPACK_IMPORTED_MODULE_7__.DayFormatPipe, _libs_bnf_pipes_number_format_number_format_pipe__WEBPACK_IMPORTED_MODULE_8__.NumberFormatPipe, _libs_bnf_pipes_amountFixed_amount_fixed_pipe__WEBPACK_IMPORTED_MODULE_9__.AmountFixedPipe, _pipes_chainIcon_chain_icon_pipe__WEBPACK_IMPORTED_MODULE_10__.ChainIconPipe],
  styles: ["[_nghost-%COMP%]   ._bioforest_asset_logo[_ngcontent-%COMP%] {\n  width: 1.1em;\n  height: 1.1em;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL2FwcHMvd2FsbGV0L3NyYy9wYWdlcy9ob21lL3BhZ2VzL2hvbWUtdG9rZW4taW5mby9ob21lLXRva2VuLWluZm8uY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQ0U7RUFDRSxZQUFBO0VBQ0EsYUFBQTtBQUFKIiwic291cmNlc0NvbnRlbnQiOlsiOmhvc3Qge1xyXG4gIC5fYmlvZm9yZXN0X2Fzc2V0X2xvZ28ge1xyXG4gICAgd2lkdGg6IDEuMWVtO1xyXG4gICAgaGVpZ2h0OiAxLjFlbTtcclxuICB9XHJcbn1cclxuIl0sInNvdXJjZVJvb3QiOiIifQ== */"],
  changeDetection: 0
});
(0,tslib__WEBPACK_IMPORTED_MODULE_13__.__decorate)([HomeTokenInfoPage.QueryParam('decimals'), (0,tslib__WEBPACK_IMPORTED_MODULE_13__.__metadata)("design:type", Object)], HomeTokenInfoPage.prototype, "decimals", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_13__.__decorate)([HomeTokenInfoPage.QueryParams(), (0,tslib__WEBPACK_IMPORTED_MODULE_13__.__metadata)("design:type", Object)], HomeTokenInfoPage.prototype, "_data", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_13__.__decorate)([HomeTokenInfoPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_13__.__metadata)("design:type", Object)], HomeTokenInfoPage.prototype, "tokenInfo", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_13__.__decorate)([HomeTokenInfoPage.OnReady(), (0,tslib__WEBPACK_IMPORTED_MODULE_13__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_13__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_13__.__metadata)("design:returntype", Promise)], HomeTokenInfoPage.prototype, "getTokenDetail", null);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (HomeTokenInfoPage);

/***/ })

}]);
//# sourceMappingURL=apps_wallet_src_pages_home_pages_home-token-info_home-token-info_component_ts.js.map