"use strict";
(self["webpackChunkwallet"] = self["webpackChunkwallet"] || []).push([["apps_wallet_src_pages_mnemonic_pages_export-private-key_export-private-key_component_ts"],{

/***/ 772:
/*!*************************************************************************************************!*\
  !*** ./apps/wallet/src/pages/mnemonic/pages/export-private-key/export-private-key.component.ts ***!
  \*************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ExportPrivateKeyPage: () => (/* binding */ ExportPrivateKeyPage),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! tslib */ 90505);
/* harmony import */ var _bnqkl_framework_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @bnqkl/framework/components */ 24182);
/* harmony import */ var _modules_page_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ~modules/page.module */ 77538);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 61039);
/* harmony import */ var _libs_bnf_components_ripple_button_ripple_button_directive__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../../../libs/bnf/components/ripple-button/ripple-button.directive */ 16505);
/* harmony import */ var _libs_bnf_directives_click_to_copy_directive__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../../../../libs/bnf/directives/click-to-copy.directive */ 46413);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common */ 6729);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/router */ 56776);
/* harmony import */ var _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../../../../../libs/bnf/modules/page/common-page/common-page.component */ 62052);
/* harmony import */ var _components_icon_icon_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../../components/icon/icon.component */ 74703);
var _class;










const _c6 = a0 => ({
  filter: a0
});
function ExportPrivateKeyPage_div_8_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "div", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](1, "bn-qrcode", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("padding", 4)("size", 220)("ngStyle", _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵpureFunction1"](4, _c6, ctx_r0.QRCodeFlag ? "blur(10px)" : "blur(0px)"))("text", ctx_r0.privateKey);
  }
}
function ExportPrivateKeyPage_div_9_Template(rf, ctx) {
  if (rf & 1) {
    const _r4 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "div", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("click", function ExportPrivateKeyPage_div_9_Template_div_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵrestoreView"](_r4);
      const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵresetView"](ctx_r3.QRCodeFlag = false);
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
  }
}
function ExportPrivateKeyPage_div_10_Template(rf, ctx) {
  if (rf & 1) {
    const _r6 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "div", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("click", function ExportPrivateKeyPage_div_10_Template_div_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵrestoreView"](_r6);
      const ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵresetView"](ctx_r5.filterClick());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](1, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵi18n"](2, 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
  }
}
const _c9 = () => ["/mnemonic/export-private-key"];
/**
 * 导出私钥页
 */
class ExportPrivateKeyPage extends _modules_page_module__WEBPACK_IMPORTED_MODULE_1__.CommonPageBase {
  constructor() {
    super(...arguments);
    /** 二维码是否模糊 true：模糊 false：不模糊 */
    this.QRCodeFlag = true;
  }
  /** 点击展示二维码 */
  filterClick() {
    this.QRCodeFlag = false;
  }
}
_class = ExportPrivateKeyPage;
_class.ɵfac = /*@__PURE__*/(() => {
  let ɵExportPrivateKeyPage_BaseFactory;
  return function ExportPrivateKeyPage_Factory(t) {
    return (ɵExportPrivateKeyPage_BaseFactory || (ɵExportPrivateKeyPage_BaseFactory = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵgetInheritedFactory"](_class)))(t || _class);
  };
})();
_class.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdefineComponent"]({
  type: _class,
  selectors: [["w-export-private-key-page"]],
  standalone: true,
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵInheritDefinitionFeature"], _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵStandaloneFeature"]],
  decls: 20,
  vars: 9,
  consts: () => {
    let i18n_0;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_MAKE_SURE_NO_ONE_ELSE_IS_AROUND_WHEN_BACKING_UP$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_EXPORT_PRIVATE_KEY_EXPORT_PRIVATE_KEY_COMPONENT_TS_1 = goog.getMsg(" Make sure no one else is around when backing up ");
      i18n_0 = MSG_EXTERNAL_MAKE_SURE_NO_ONE_ELSE_IS_AROUND_WHEN_BACKING_UP$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_EXPORT_PRIVATE_KEY_EXPORT_PRIVATE_KEY_COMPONENT_TS_1;
    } else {
      i18n_0 = " Make sure no one else is around when backing up ";
    }
    let i18n_2;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_PRIVATE_KEY$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_EXPORT_PRIVATE_KEY_EXPORT_PRIVATE_KEY_COMPONENT_TS_3 = goog.getMsg("Private Key");
      i18n_2 = MSG_EXTERNAL_PRIVATE_KEY$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_EXPORT_PRIVATE_KEY_EXPORT_PRIVATE_KEY_COMPONENT_TS_3;
    } else {
      i18n_2 = "Private Key";
    }
    let i18n_4;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_COPY_THE_PRIVATE_KEY$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_EXPORT_PRIVATE_KEY_EXPORT_PRIVATE_KEY_COMPONENT_TS_5 = goog.getMsg(" Copy The Private Key ");
      i18n_4 = MSG_EXTERNAL_COPY_THE_PRIVATE_KEY$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_EXPORT_PRIVATE_KEY_EXPORT_PRIVATE_KEY_COMPONENT_TS_5;
    } else {
      i18n_4 = " Copy The Private Key ";
    }
    let i18n_7;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_CLICK_TO_SHOW_THE_QR_CODE_OF_THE_PRIVATE_KEY$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_EXPORT_PRIVATE_KEY_EXPORT_PRIVATE_KEY_COMPONENT_TS__8 = goog.getMsg("Click to show the QR code of the private key");
      i18n_7 = MSG_EXTERNAL_CLICK_TO_SHOW_THE_QR_CODE_OF_THE_PRIVATE_KEY$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_EXPORT_PRIVATE_KEY_EXPORT_PRIVATE_KEY_COMPONENT_TS__8;
    } else {
      i18n_7 = "Click to show the QR code of the private key";
    }
    return [[3, "contentSafeArea"], [1, "pdStyle1", "w-full", "py-0", "pt-6", "text-center"], [1, "bg-env", "text-subtext", "mb-2", "flex", "h-10", "items-center", "justify-center", "rounded-lg", "text-xs"], [1, "text-base", 3, "name"], i18n_0, [1, "bg-env", "relative", "w-full", "rounded-t-sm", "p-7"], ["src", "./assets/images/currency_qr_bg.png"], ["class", "absolute left-1/2 top-1/2 w-8/12 -translate-x-1/2 -translate-y-1/2", 4, "ngIf"], ["class", "_mask absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 rounded-lg", 3, "click", 4, "ngIf"], ["class", "absolute left-1/2 top-1/2 z-10 -translate-x-1/2 -translate-y-1/2 text-white", 3, "click", 4, "ngIf"], [1, "bg-env", "rounded-b-sm", "pb-5"], [1, "px-5", "text-left", "text-xs", "font-normal", "tracking-normal"], [1, "text-subtext", "text-xs"], i18n_2, [1, "overflow-hidden", "break-all", "px-5", "text-left", "text-sm", "font-normal", "tracking-normal"], ["footer", ""], ["bnRippleButton", "", 1, "border-tiny", "border-primary-2", "text-primary-2", "h-10.5", "w-full", "rounded-full", "text-center", 3, "routerLink", "wClickToCopy"], i18n_4, [1, "absolute", "left-1/2", "top-1/2", "w-8/12", "-translate-x-1/2", "-translate-y-1/2"], [3, "padding", "size", "ngStyle", "text"], [1, "_mask", "absolute", "left-1/2", "top-1/2", "-translate-x-1/2", "-translate-y-1/2", "rounded-lg", 3, "click"], [1, "absolute", "left-1/2", "top-1/2", "z-10", "-translate-x-1/2", "-translate-y-1/2", "text-white", 3, "click"], i18n_7];
  },
  template: function ExportPrivateKeyPage_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "common-page", 0)(1, "div", 1)(2, "div", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](3, "w-icon", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](4, "span");
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵi18n"](5, 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](6, "div", 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](7, "img", 6);
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](8, ExportPrivateKeyPage_div_8_Template, 2, 6, "div", 7)(9, ExportPrivateKeyPage_div_9_Template, 1, 0, "div", 8)(10, ExportPrivateKeyPage_div_10_Template, 3, 0, "div", 9);
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](11, "div", 10)(12, "div", 11)(13, "span", 12);
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵi18n"](14, 13);
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](15, "div", 14);
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](16);
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()();
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](17, "div", 15)(18, "button", 16);
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵi18n"](19, 17);
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()();
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("contentSafeArea", true);
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("name", "warn-grey");
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](5);
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx.privateKey);
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx.QRCodeFlag);
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx.QRCodeFlag);
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](6);
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate1"](" ", ctx.privateKey, " ");
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("routerLink", _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵpureFunction0"](8, _c9))("wClickToCopy", ctx.privateKey);
    }
  },
  dependencies: [_modules_page_module__WEBPACK_IMPORTED_MODULE_1__.CommonPageModule, _libs_bnf_components_ripple_button_ripple_button_directive__WEBPACK_IMPORTED_MODULE_2__.RippleButtonDirective, _libs_bnf_directives_click_to_copy_directive__WEBPACK_IMPORTED_MODULE_3__.ClickToCopyDirective, _angular_common__WEBPACK_IMPORTED_MODULE_7__.NgIf, _angular_common__WEBPACK_IMPORTED_MODULE_7__.NgStyle, _angular_router__WEBPACK_IMPORTED_MODULE_8__.RouterLink, _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_4__.CommonPageComponent, _components_icon_icon_component__WEBPACK_IMPORTED_MODULE_5__.IconComponent, _bnqkl_framework_components__WEBPACK_IMPORTED_MODULE_0__.QrcodeSvgComponent],
  styles: ["[_nghost-%COMP%]   ._mask[_ngcontent-%COMP%] {\n  width: 70%;\n  height: 70%;\n  background: rgba(32, 77, 242, 0.22);\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL2FwcHMvd2FsbGV0L3NyYy9wYWdlcy9tbmVtb25pYy9wYWdlcy9leHBvcnQtcHJpdmF0ZS1rZXkvZXhwb3J0LXByaXZhdGUta2V5LmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUNFO0VBQ0UsVUFBQTtFQUNBLFdBQUE7RUFDQSxtQ0FBQTtBQUFKIiwic291cmNlc0NvbnRlbnQiOlsiOmhvc3Qge1xyXG4gIC5fbWFzayB7XHJcbiAgICB3aWR0aDogNzAlO1xyXG4gICAgaGVpZ2h0OiA3MCU7XHJcbiAgICBiYWNrZ3JvdW5kOiByZ2JhKDMyLCA3NywgMjQyLCAwLjIyKTtcclxuICB9XHJcbn1cclxuIl0sInNvdXJjZVJvb3QiOiIifQ== */"],
  changeDetection: 0
});
(0,tslib__WEBPACK_IMPORTED_MODULE_9__.__decorate)([ExportPrivateKeyPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__metadata)("design:type", Object)], ExportPrivateKeyPage.prototype, "QRCodeFlag", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_9__.__decorate)([ExportPrivateKeyPage.QueryParam('importPhrase'), ExportPrivateKeyPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__metadata)("design:type", String)], ExportPrivateKeyPage.prototype, "privateKey", void 0);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ExportPrivateKeyPage);

/***/ })

}]);
//# sourceMappingURL=apps_wallet_src_pages_mnemonic_pages_export-private-key_export-private-key_component_ts.js.map