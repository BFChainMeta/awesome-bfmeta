"use strict";
(self["webpackChunkwallet"] = self["webpackChunkwallet"] || []).push([["apps_wallet_src_assets_wallet-util_index-a32c6bef_mjs"],{

/***/ 60056:
/*!***************************************************************!*\
  !*** ./apps/wallet/src/assets/wallet-util/index-a32c6bef.mjs ***!
  \***************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   embed: () => (/* binding */ u),
/* harmony export */   p2ms: () => (/* reexport safe */ _p2pk_9b07c6f0_mjs__WEBPACK_IMPORTED_MODULE_5__.p),
/* harmony export */   p2pk: () => (/* reexport safe */ _p2pk_9b07c6f0_mjs__WEBPACK_IMPORTED_MODULE_5__.a),
/* harmony export */   p2pkh: () => (/* reexport safe */ _address_a3a74797_mjs__WEBPACK_IMPORTED_MODULE_2__.a),
/* harmony export */   p2sh: () => (/* reexport safe */ _address_a3a74797_mjs__WEBPACK_IMPORTED_MODULE_2__.b),
/* harmony export */   p2tr: () => (/* reexport safe */ _address_a3a74797_mjs__WEBPACK_IMPORTED_MODULE_2__.e),
/* harmony export */   p2wpkh: () => (/* reexport safe */ _address_a3a74797_mjs__WEBPACK_IMPORTED_MODULE_2__.c),
/* harmony export */   p2wsh: () => (/* reexport safe */ _address_a3a74797_mjs__WEBPACK_IMPORTED_MODULE_2__.d)
/* harmony export */ });
/* harmony import */ var _networks_0de0aba6_mjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./networks-0de0aba6.mjs */ 15108);
/* harmony import */ var _script_28a5953a_mjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./script-28a5953a.mjs */ 25453);
/* harmony import */ var _address_a3a74797_mjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./address-a3a74797.mjs */ 75036);
/* harmony import */ var _typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./typeforce-9b266dd0.mjs */ 26139);
/* harmony import */ var _ops_47b8fd99_mjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./ops-47b8fd99.mjs */ 62510);
/* harmony import */ var _p2pk_9b07c6f0_mjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./p2pk-9b07c6f0.mjs */ 73721);
/* harmony import */ var _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./index-766bdb76.mjs */ 59809);
/* harmony import */ var _index_f363275a_mjs__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./index-f363275a.mjs */ 89279);
/* harmony import */ var _sha256_e58017d9_mjs__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./sha256-e58017d9.mjs */ 6612);
/* harmony import */ var _WASMInterface_b9f2203b_mjs__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./WASMInterface-b9f2203b.mjs */ 43670);
/* harmony import */ var _crypto_2c4d5428_mjs__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./crypto-2c4d5428.mjs */ 8319);
/* harmony import */ var _ripemd160_3baa091d_mjs__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./ripemd160-3baa091d.mjs */ 70972);
/* harmony import */ var _sha1_e1635d39_mjs__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./sha1-e1635d39.mjs */ 57);














const n = _ops_47b8fd99_mjs__WEBPACK_IMPORTED_MODULE_4__.OPS;
function u(a, e) {
  if (!a.data && !a.output) throw new TypeError("Not enough data");
  e = Object.assign({
    validate: !0
  }, e || {}), (0,_typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_3__.t)({
    network: _typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_3__.t.maybe(_typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_3__.t.Object),
    output: _typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_3__.t.maybe(_typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_3__.t.Buffer),
    data: _typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_3__.t.maybe(_typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_3__.t.arrayOf(_typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_3__.t.Buffer))
  }, a);
  const p = {
    name: "embed",
    network: a.network || _networks_0de0aba6_mjs__WEBPACK_IMPORTED_MODULE_0__.b
  };
  if ((0,_address_a3a74797_mjs__WEBPACK_IMPORTED_MODULE_2__.p)(p, "output", () => {
    if (a.data) return (0,_script_28a5953a_mjs__WEBPACK_IMPORTED_MODULE_1__.c)([n.OP_RETURN].concat(a.data));
  }), (0,_address_a3a74797_mjs__WEBPACK_IMPORTED_MODULE_2__.p)(p, "data", () => {
    if (a.output) return (0,_script_28a5953a_mjs__WEBPACK_IMPORTED_MODULE_1__.d)(a.output).slice(1);
  }), e.validate && a.output) {
    const t = (0,_script_28a5953a_mjs__WEBPACK_IMPORTED_MODULE_1__.d)(a.output);
    if (t[0] !== n.OP_RETURN) throw new TypeError("Output is invalid");
    if (!t.slice(1).every(_typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_3__.t.Buffer)) throw new TypeError("Output is invalid");
    if (a.data && !function (t, r) {
      return t.length === r.length && t.every((t, a) => t.equals(r[a]));
    }(a.data, p.data)) throw new TypeError("Data mismatch");
  }
  return Object.assign(p, a);
}


/***/ })

}]);
//# sourceMappingURL=apps_wallet_src_assets_wallet-util_index-a32c6bef_mjs.js.map