"use strict";
(self["webpackChunkwallet"] = self["webpackChunkwallet"] || []).push([["apps_wallet_src_pages_mnemonic_pages_address-password-backup_address-password-backup_component_ts"],{

/***/ 66540:
/*!***********************************************************************************************************!*\
  !*** ./apps/wallet/src/pages/mnemonic/pages/address-password-backup/address-password-backup.component.ts ***!
  \***********************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AddressPasswordBackupPage: () => (/* binding */ AddressPasswordBackupPage),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! tslib */ 90505);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 61039);
/* harmony import */ var _modules_page_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ~modules/page.module */ 77538);
/* harmony import */ var _bnqkl_wallet_base_services_wallet_bip39__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @bnqkl/wallet-base/services/wallet/bip39 */ 76659);
/* harmony import */ var _libs_bnf_components_ripple_button_ripple_button_directive__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../../../libs/bnf/components/ripple-button/ripple-button.directive */ 16505);
/* harmony import */ var _libs_bnf_directives_click_to_copy_directive__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../../../../libs/bnf/directives/click-to-copy.directive */ 46413);
/* harmony import */ var _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../../../../../libs/bnf/modules/page/common-page/common-page.component */ 62052);
/* harmony import */ var _components_icon_icon_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../../components/icon/icon.component */ 74703);
var _class;









/**
 * 备份助记词页
 */
/**
 * 备份地址密码
 */
class AddressPasswordBackupPage extends _modules_page_module__WEBPACK_IMPORTED_MODULE_0__.CommonPageBase {
  constructor() {
    super(...arguments);
    /**
     * 引入助记词生成文件
     */
    this.bip39LibService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.inject)(_bnqkl_wallet_base_services_wallet_bip39__WEBPACK_IMPORTED_MODULE_1__.Bip39LibService);
    /**
     * 地址密码
     */
    this.addressPasswordContent = '';
    /**
     * 助记词字符串
     */
    this.mnemonicString = '';
    /** 是否为导出模式 */
    this.export = false;
    /** 返回页面 */
    this._backurl = '';
  }
  /** 初始化获取传参 */
  initMnemonicArr() {
    const {
      data
    } = this;
    if (data.export !== undefined) {
      this.export = data.export;
      this._backurl = data.backUrl || '';
      this.addressPasswordContent = data.mnemonicString;
      // 助记词转换成数组格式
      return;
    }
  }
}
_class = AddressPasswordBackupPage;
_class.ɵfac = /*@__PURE__*/(() => {
  let ɵAddressPasswordBackupPage_BaseFactory;
  return function AddressPasswordBackupPage_Factory(t) {
    return (ɵAddressPasswordBackupPage_BaseFactory || (ɵAddressPasswordBackupPage_BaseFactory = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵgetInheritedFactory"](_class)))(t || _class);
  };
})();
_class.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdefineComponent"]({
  type: _class,
  selectors: [["w-address-password-backup-page"]],
  standalone: true,
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵInheritDefinitionFeature"], _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵStandaloneFeature"]],
  decls: 14,
  vars: 4,
  consts: () => {
    let i18n_0;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_MAKE_SURE_NO_ONE_ELSE_IS_AROUND_WHEN_BACKING_UP$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_ADDRESS_PASSWORD_BACKUP_ADDRESS_PASSWORD_BACKUP_COMPONENT_TS_1 = goog.getMsg(" Make sure no one else is around when backing up ");
      i18n_0 = MSG_EXTERNAL_MAKE_SURE_NO_ONE_ELSE_IS_AROUND_WHEN_BACKING_UP$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_ADDRESS_PASSWORD_BACKUP_ADDRESS_PASSWORD_BACKUP_COMPONENT_TS_1;
    } else {
      i18n_0 = "\u5907\u4EFD\u65F6\u8BF7\u786E\u4FDD\u5468\u8FB9\u6CA1\u6709\u5176\u4ED6\u4EBA";
    }
    let i18n_2;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_ADDRESS_PASSWORD$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_ADDRESS_PASSWORD_BACKUP_ADDRESS_PASSWORD_BACKUP_COMPONENT_TS_3 = goog.getMsg(" Address Password ");
      i18n_2 = MSG_EXTERNAL_ADDRESS_PASSWORD$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_ADDRESS_PASSWORD_BACKUP_ADDRESS_PASSWORD_BACKUP_COMPONENT_TS_3;
    } else {
      i18n_2 = "\u5730\u5740\u5BC6\u7801";
    }
    let i18n_4;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_ADDRESS_PASSOWRD_CONTENT$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_ADDRESS_PASSWORD_BACKUP_ADDRESS_PASSWORD_BACKUP_COMPONENT_TS_5 = goog.getMsg(" {$interpolation} ", {
        "interpolation": "\uFFFD0\uFFFD"
      }, {
        original_code: {
          "interpolation": "{{ addressPasswordContent }}"
        }
      });
      i18n_4 = MSG_EXTERNAL_ADDRESS_PASSOWRD_CONTENT$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_ADDRESS_PASSWORD_BACKUP_ADDRESS_PASSWORD_BACKUP_COMPONENT_TS_5;
    } else {
      i18n_4 = "" + "\uFFFD0\uFFFD" + " ";
    }
    let i18n_6;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_COPY_ADDRESS_PASSWORD$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_ADDRESS_PASSWORD_BACKUP_ADDRESS_PASSWORD_BACKUP_COMPONENT_TS_7 = goog.getMsg(" Copy Address Password ");
      i18n_6 = MSG_EXTERNAL_COPY_ADDRESS_PASSWORD$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_ADDRESS_PASSWORD_BACKUP_ADDRESS_PASSWORD_BACKUP_COMPONENT_TS_7;
    } else {
      i18n_6 = "\u590D\u5236\u5730\u5740\u5BC6\u7801";
    }
    return [[3, "contentSafeArea"], [1, "pt-2"], [1, "bg-env", "text-subtext", "mb-2", "flex", "h-10", "items-center", "justify-center", "rounded-lg", "text-xs"], [1, "text-base", 3, "name"], i18n_0, [1, "bg-env", "relative", "w-full", "rounded-lg", "p-6"], [1, "text-subtext", "mb-5.5", "text-center", "text-base", "font-semibold"], i18n_2, [1, "text-title", "text-center", "text-sm", "font-normal"], i18n_4, ["footer", ""], ["bnRippleButton", "", "type", "button", 1, "border-tiny", "border-primary-2", "text-primary-2", "h-10.5", "w-full", "rounded-full", "text-center", 3, "wClickToCopy"], i18n_6];
  },
  template: function AddressPasswordBackupPage_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "common-page", 0)(1, "div", 1)(2, "div", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](3, "w-icon", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](4, "span");
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵi18n"](5, 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](6, "div", 5)(7, "div", 6);
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵi18n"](8, 7);
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](9, "div", 8);
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵi18n"](10, 9);
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()();
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](11, "div", 10)(12, "button", 11);
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵi18n"](13, 12);
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()();
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("contentSafeArea", true);
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("name", "warn-grey");
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](7);
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵi18nExp"](ctx.addressPasswordContent);
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵi18nApply"](10);
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("wClickToCopy", ctx.addressPasswordContent);
    }
  },
  dependencies: [_modules_page_module__WEBPACK_IMPORTED_MODULE_0__.CommonPageModule, _libs_bnf_components_ripple_button_ripple_button_directive__WEBPACK_IMPORTED_MODULE_2__.RippleButtonDirective, _libs_bnf_directives_click_to_copy_directive__WEBPACK_IMPORTED_MODULE_3__.ClickToCopyDirective, _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_4__.CommonPageComponent, _components_icon_icon_component__WEBPACK_IMPORTED_MODULE_5__.IconComponent],
  styles: ["[_nghost-%COMP%]   ._select-mne-box[_ngcontent-%COMP%] {\n  width: 27.6466666667vw;\n  height: 12.8vw;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL2FwcHMvd2FsbGV0L3NyYy9wYWdlcy9tbmVtb25pYy9wYWdlcy9hZGRyZXNzLXBhc3N3b3JkLWJhY2t1cC9hZGRyZXNzLXBhc3N3b3JkLWJhY2t1cC5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFDRTtFQUNFLHNCQUFBO0VBQ0EsY0FBQTtBQUFKIiwic291cmNlc0NvbnRlbnQiOlsiOmhvc3Qge1xyXG4gIC5fc2VsZWN0LW1uZS1ib3gge1xyXG4gICAgd2lkdGg6IGNhbGMoKDEwMHZ3IC0gMTcuMDZ2dykgLyAzKTtcclxuICAgIGhlaWdodDogMTIuOHZ3O1xyXG4gIH1cclxufVxyXG4iXSwic291cmNlUm9vdCI6IiJ9 */"],
  changeDetection: 0
});
(0,tslib__WEBPACK_IMPORTED_MODULE_7__.__decorate)([AddressPasswordBackupPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__metadata)("design:type", Object)], AddressPasswordBackupPage.prototype, "addressPasswordContent", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_7__.__decorate)([AddressPasswordBackupPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__metadata)("design:type", Object)], AddressPasswordBackupPage.prototype, "mnemonicString", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_7__.__decorate)([AddressPasswordBackupPage.QueryParams(), (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__metadata)("design:type", Object)], AddressPasswordBackupPage.prototype, "data", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_7__.__decorate)([AddressPasswordBackupPage.OnInit(), (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__metadata)("design:returntype", void 0)], AddressPasswordBackupPage.prototype, "initMnemonicArr", null);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (AddressPasswordBackupPage);

/***/ })

}]);
//# sourceMappingURL=apps_wallet_src_pages_mnemonic_pages_address-password-backup_address-password-backup_component_ts.js.map