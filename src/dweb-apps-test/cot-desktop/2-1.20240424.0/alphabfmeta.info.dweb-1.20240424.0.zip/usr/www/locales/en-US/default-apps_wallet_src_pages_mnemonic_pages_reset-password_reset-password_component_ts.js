"use strict";
(self["webpackChunkwallet"] = self["webpackChunkwallet"] || []).push([["default-apps_wallet_src_pages_mnemonic_pages_reset-password_reset-password_component_ts"],{

/***/ 85652:
/*!*****************************************************************************************!*\
  !*** ./apps/wallet/src/pages/mnemonic/pages/reset-password/reset-password.component.ts ***!
  \*****************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ResetPasswordPage: () => (/* binding */ ResetPasswordPage),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 52542);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! tslib */ 90505);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/core */ 61039);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/forms */ 7820);
/* harmony import */ var _bnqkl_framework_controllers__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @bnqkl/framework/controllers */ 47919);
/* harmony import */ var _bnqkl_framework_plugins_toast__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @bnqkl/framework/plugins/toast */ 18030);
/* harmony import */ var _components_input_hidden_icon_swap_input_hidden_icon_swap_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ~components/input-hidden-icon-swap/input-hidden-icon-swap.component */ 68027);
/* harmony import */ var _modules_page_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ~modules/page.module */ 77538);
/* harmony import */ var _bnqkl_wallet_base_services_wallet_wallet_data_storage__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @bnqkl/wallet-base/services/wallet/wallet-data-storage */ 63024);
/* harmony import */ var _libs_bnf_components_ripple_button_ripple_button_directive__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../../../../../libs/bnf/components/ripple-button/ripple-button.directive */ 16505);
/* harmony import */ var _libs_bnf_directives_form_errors_directive__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../../../../../libs/bnf/directives/form-errors.directive */ 29541);
/* harmony import */ var _libs_bnf_directives_auto_complete_off_directive__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../../../../../libs/bnf/directives/auto-complete-off.directive */ 66722);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/common */ 6729);
/* harmony import */ var _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../../../../../../libs/bnf/modules/page/common-page/common-page.component */ 62052);
/* harmony import */ var _libs_bnf_pipes_errors_errors_pipe__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../../../../../../libs/bnf/pipes/errors/errors.pipe */ 68362);
/* harmony import */ var _pipes_color_color_pipe__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../../../pipes/color/color.pipe */ 76489);

var _class;

















function ResetPasswordPage_ng_template_9_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵi18n"](1, 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementContainerEnd"]();
  }
}
function ResetPasswordPage_ng_template_10_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵi18n"](1, 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const error_r8 = ctx.$error;
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵi18nExp"](error_r8.requiredLength);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵi18nApply"](1);
  }
}
function ResetPasswordPage_ng_template_11_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵi18n"](1, 26);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const error_r9 = ctx.$error;
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵi18nExp"](error_r9.requiredLength);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵi18nApply"](1);
  }
}
function ResetPasswordPage_ng_template_12_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵi18n"](1, 27);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementContainerEnd"]();
  }
}
function ResetPasswordPage_ng_template_13_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵi18n"](1, 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementContainerEnd"]();
  }
}
function ResetPasswordPage_ng_template_14_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵi18n"](1, 29);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementContainerEnd"]();
  }
}
function ResetPasswordPage_ng_template_15_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtext"](0);
  }
  if (rf & 2) {
    const errors_r11 = ctx.$errors;
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtextInterpolate1"](" ", errors_r11, " ");
  }
}
const _c22 = a0 => ({
  "text-error": a0
});
const _c23 = (a0, a1) => ({
  pwd: a0,
  cpwd: a1
});
const _c24 = a0 => ({
  "--color-1": a0
});
class ResetPasswordPage extends _modules_page_module__WEBPACK_IMPORTED_MODULE_4__.CommonPageBase {
  constructor() {
    super(...arguments);
    /** 页面返回值的类型 */
    this.returnValue$ = new _modules_page_module__WEBPACK_IMPORTED_MODULE_4__.PageReturnValue();
    /** 链服务 */
    this.walletDataStorageV2Service = (0,_angular_core__WEBPACK_IMPORTED_MODULE_12__.inject)(_bnqkl_wallet_base_services_wallet_wallet_data_storage__WEBPACK_IMPORTED_MODULE_5__.WalletDataStorageV2Service);
    /** 表单验证服务 */
    this.validators = new _bnqkl_framework_controllers__WEBPACK_IMPORTED_MODULE_1__.FormValidatorsController(this);
    /**
     * 密码型内容显示与否
     */
    this.inputContentShow = false;
    /**
     * 确认密码型内容显示与否
     */
    this.confirmInputShow = false;
    /** 密码 */
    this.pwd = new _angular_forms__WEBPACK_IMPORTED_MODULE_13__.FormControl('', {
      nonNullable: true,
      validators: [this.validators.whitespace, _angular_forms__WEBPACK_IMPORTED_MODULE_13__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_13__.Validators.minLength(8), _angular_forms__WEBPACK_IMPORTED_MODULE_13__.Validators.maxLength(30)]
    });
    /** 确认密码 */
    this.cpwd = new _angular_forms__WEBPACK_IMPORTED_MODULE_13__.FormControl('', {
      nonNullable: true,
      validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_13__.Validators.required, this.validators.equals(this.pwd)]
    });
    /** 密码提示 */
    this.tip = new _angular_forms__WEBPACK_IMPORTED_MODULE_13__.FormControl('', {
      nonNullable: true,
      validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_13__.Validators.maxLength(50)]
    });
    /** 要提交的表单与复合验证 */
    this.form = new _angular_forms__WEBPACK_IMPORTED_MODULE_13__.FormGroup({
      pwd: this.pwd,
      cpwd: this.cpwd,
      tip: this.tip
    }, {
      validators: [],
      asyncValidators: []
    });
  }
  /** 提交事件 */
  onSubmit() {
    var _this = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const data = _this.form.getRawValue();
      _this.walletDataStorageV2Service.walletAppSettings.password = data.pwd;
      _this.walletDataStorageV2Service.walletAppSettings.passwordTips = data.tip;
      _bnqkl_framework_plugins_toast__WEBPACK_IMPORTED_MODULE_2__.Toast.show("reset password success");
      _this.returnValue$.next({
        result: 'success',
        tipContent: data.tip
      });
      _this.nav.back();
      _this.form.reset();
    })();
  }
}
_class = ResetPasswordPage;
_class.ɵfac = /*@__PURE__*/(() => {
  let ɵResetPasswordPage_BaseFactory;
  return function ResetPasswordPage_Factory(t) {
    return (ɵResetPasswordPage_BaseFactory || (ɵResetPasswordPage_BaseFactory = _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵgetInheritedFactory"](_class)))(t || _class);
  };
})();
_class.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵdefineComponent"]({
  type: _class,
  selectors: [["w-reset-password-page"]],
  outputs: {
    returnValue$: "returnValue$"
  },
  standalone: true,
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵInheritDefinitionFeature"], _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵStandaloneFeature"]],
  decls: 30,
  vars: 35,
  consts: () => {
    let i18n_0;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_NEW_PASSWORD$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_RESET_PASSWORD_RESET_PASSWORD_COMPONENT_TS_1 = goog.getMsg(" New Password ");
      i18n_0 = MSG_EXTERNAL_NEW_PASSWORD$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_RESET_PASSWORD_RESET_PASSWORD_COMPONENT_TS_1;
    } else {
      i18n_0 = " New Password ";
    }
    let i18n_2;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_PASSWORD_IS_NOT_LESS_THAN_DIGITS$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_RESET_PASSWORD_RESET_PASSWORD_COMPONENT_TS_3 = goog.getMsg("Password is not less than 8 digits");
      i18n_2 = MSG_EXTERNAL_PASSWORD_IS_NOT_LESS_THAN_DIGITS$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_RESET_PASSWORD_RESET_PASSWORD_COMPONENT_TS_3;
    } else {
      i18n_2 = "Password is not less than 8 digits";
    }
    let i18n_4;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_REPEAT_PASSWORD$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_RESET_PASSWORD_RESET_PASSWORD_COMPONENT_TS_5 = goog.getMsg("Repeat Password");
      i18n_4 = MSG_EXTERNAL_REPEAT_PASSWORD$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_RESET_PASSWORD_RESET_PASSWORD_COMPONENT_TS_5;
    } else {
      i18n_4 = "Repeat Password";
    }
    let i18n_6;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_THE_PASSWORD_WILL_BE_USED_TO_VERIFY_WALLET_TRANSFERS_VIEW_MNEMINIC_PHRASES_AND_OTHER_IMPORTANT_FUNCTIONS__THIS_IS_ALOCAL_PASSWORD_$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_RESET_PASSWORD_RESET_PASSWORD_COMPONENT_TS_7 = goog.getMsg(" The Password will be used to verify wallet transfers, view mnemonic phrases and other important functions (this is alocal password) ");
      i18n_6 = MSG_EXTERNAL_THE_PASSWORD_WILL_BE_USED_TO_VERIFY_WALLET_TRANSFERS_VIEW_MNEMINIC_PHRASES_AND_OTHER_IMPORTANT_FUNCTIONS__THIS_IS_ALOCAL_PASSWORD_$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_RESET_PASSWORD_RESET_PASSWORD_COMPONENT_TS_7;
    } else {
      i18n_6 = " The Password will be used to verify wallet transfers, view mnemonic phrases and other important functions (this is alocal password) ";
    }
    let i18n_8;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_RESET$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_RESET_PASSWORD_RESET_PASSWORD_COMPONENT_TS_9 = goog.getMsg(" Reset ");
      i18n_8 = MSG_EXTERNAL_RESET$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_RESET_PASSWORD_RESET_PASSWORD_COMPONENT_TS_9;
    } else {
      i18n_8 = " Reset ";
    }
    let i18n_10;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_PLEASE_INPUT_THE_PASSWORD$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_RESET_PASSWORD_RESET_PASSWORD_COMPONENT_TS__11 = goog.getMsg("Please input the password");
      i18n_10 = MSG_EXTERNAL_PLEASE_INPUT_THE_PASSWORD$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_RESET_PASSWORD_RESET_PASSWORD_COMPONENT_TS__11;
    } else {
      i18n_10 = "Please input the password";
    }
    let i18n_12;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_THE_PASSWORD_IS_AT_LEAST_CHARACTERS_LONG$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_RESET_PASSWORD_RESET_PASSWORD_COMPONENT_TS__13 = goog.getMsg(" The password is at least {$interpolation} characters long ", {
        "interpolation": "\uFFFD0\uFFFD"
      }, {
        original_code: {
          "interpolation": "{{ error.requiredLength }}"
        }
      });
      i18n_12 = MSG_EXTERNAL_THE_PASSWORD_IS_AT_LEAST_CHARACTERS_LONG$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_RESET_PASSWORD_RESET_PASSWORD_COMPONENT_TS__13;
    } else {
      i18n_12 = " The password is at least " + "\uFFFD0\uFFFD" + " characters long ";
    }
    let i18n_14;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_THE_MAXIMUM_LENGTH_OF_THE_PASSWORD_IS$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_RESET_PASSWORD_RESET_PASSWORD_COMPONENT_TS__15 = goog.getMsg(" The maximum length of the password is {$interpolation} ", {
        "interpolation": "\uFFFD0\uFFFD"
      }, {
        original_code: {
          "interpolation": "{{ error.requiredLength }}"
        }
      });
      i18n_14 = MSG_EXTERNAL_THE_MAXIMUM_LENGTH_OF_THE_PASSWORD_IS$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_RESET_PASSWORD_RESET_PASSWORD_COMPONENT_TS__15;
    } else {
      i18n_14 = " The maximum length of the password is " + "\uFFFD0\uFFFD" + " ";
    }
    let i18n_16;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_THE_PASSWORD_CANNOT_CONTAINER_SPACES$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_RESET_PASSWORD_RESET_PASSWORD_COMPONENT_TS__17 = goog.getMsg(" The password cannot container spaces ! ");
      i18n_16 = MSG_EXTERNAL_THE_PASSWORD_CANNOT_CONTAINER_SPACES$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_RESET_PASSWORD_RESET_PASSWORD_COMPONENT_TS__17;
    } else {
      i18n_16 = " The password cannot container spaces ! ";
    }
    let i18n_18;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_PLEASE_INPUT_THE_PASSWORD_AGAIN$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_RESET_PASSWORD_RESET_PASSWORD_COMPONENT_TS__19 = goog.getMsg("Please input the password again");
      i18n_18 = MSG_EXTERNAL_PLEASE_INPUT_THE_PASSWORD_AGAIN$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_RESET_PASSWORD_RESET_PASSWORD_COMPONENT_TS__19;
    } else {
      i18n_18 = "Please input the password again";
    }
    let i18n_20;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_TWO_INPUTSDO_NOT_MATCH$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_RESET_PASSWORD_RESET_PASSWORD_COMPONENT_TS__21 = goog.getMsg("Two inputs don't match!");
      i18n_20 = MSG_EXTERNAL_TWO_INPUTSDO_NOT_MATCH$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_RESET_PASSWORD_RESET_PASSWORD_COMPONENT_TS__21;
    } else {
      i18n_20 = "Two inputs don't match!";
    }
    return [[3, "contentSafeArea", "contentBackground", "headerBackground"], [3, "formGroup", "ngSubmit"], [1, "flex", "h-10", "w-full", "items-end", "justify-between", "text-xs", "font-semibold"], [1, "flex-shrink-0", "pr-2", 3, "ngClass"], i18n_0, [1, "text-error", "text-xss", "text-right", 3, "wSwitchErrors"], ["scope", "pwd", "wCaseKey", "required"], ["scope", "pwd", "wCaseKey", "minlength"], ["scope", "pwd", "wCaseKey", "maxlength"], ["scope", "pwd", "wCaseKey", "whitespace"], ["scope", "cpwd", "wCaseKey", "required"], ["scope", "cpwd", "wCaseKey", "equals"], [3, "wCaseDefault"], [1, "mt-1", "flex", "h-10", "items-stretch", "rounded-lg", "bg-white", "px-2"], ["formControlName", "pwd", "type", "text", "placeholder", i18n_2, 1, "w-full", 3, "type"], [1, "icon-5.5", "text-subtext", "ml-6", "flex-shrink-0", 3, "show", "showChange"], [1, "mt-2", "flex", "h-10", "items-stretch", "rounded-lg", "bg-white", "px-2"], ["formControlName", "cpwd", "type", "text", "placeholder", i18n_4, 1, "w-full", 3, "type"], ["footer", "", 3, "formGroup", "ngSubmit"], [1, "mb-6", "p-3"], [1, "text-title", "rounded-6", "bg-white", "px-5", "py-4", "shadow-[0_5px_5px_0px_rgba(29,24,228,0.08)]"], i18n_6, ["bnRippleButton", "", "type", "submit", 1, "h-10.5", "bg-primary-2", "w-full", "rounded-full", "text-center", "text-white", 3, "disabled"], i18n_8, i18n_10, i18n_12, i18n_14, i18n_16, i18n_18, i18n_20];
  },
  template: function ResetPasswordPage_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](0, "common-page", 0)(1, "form", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵlistener"]("ngSubmit", function ResetPasswordPage_Template_form_ngSubmit_1_listener() {
        return ctx.onSubmit();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](2, "fieldset")(3, "legend", 2)(4, "div", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵi18n"](5, 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵpipe"](6, "errors");
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵpipe"](7, "errors");
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](8, "div", 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtemplate"](9, ResetPasswordPage_ng_template_9_Template, 2, 0, "ng-template", 6)(10, ResetPasswordPage_ng_template_10_Template, 2, 1, "ng-template", 7)(11, ResetPasswordPage_ng_template_11_Template, 2, 1, "ng-template", 8)(12, ResetPasswordPage_ng_template_12_Template, 2, 0, "ng-template", 9)(13, ResetPasswordPage_ng_template_13_Template, 2, 0, "ng-template", 10)(14, ResetPasswordPage_ng_template_14_Template, 2, 0, "ng-template", 11)(15, ResetPasswordPage_ng_template_15_Template, 1, 1, "ng-template", 12);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](16, "div", 13);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelement"](17, "input", 14);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](18, "w-input-hidden-icon-swap", 15);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵlistener"]("showChange", function ResetPasswordPage_Template_w_input_hidden_icon_swap_showChange_18_listener($event) {
        return ctx.inputContentShow = $event;
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵpipe"](19, "color");
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](20, "div", 16);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelement"](21, "input", 17);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](22, "w-input-hidden-icon-swap", 15);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵlistener"]("showChange", function ResetPasswordPage_Template_w_input_hidden_icon_swap_showChange_22_listener($event) {
        return ctx.confirmInputShow = $event;
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵpipe"](23, "color");
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]()()()();
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](24, "form", 18);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵlistener"]("ngSubmit", function ResetPasswordPage_Template_form_ngSubmit_24_listener() {
        return ctx.onSubmit();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](25, "div", 19)(26, "div", 20);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵi18n"](27, 21);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](28, "button", 22);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵi18n"](29, 23);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]()()();
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("contentSafeArea", true)("contentBackground", "grey")("headerBackground", "grey");
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("formGroup", ctx.form);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵpureFunction1"](26, _c22, _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵpipeBind1"](6, 18, ctx.pwd) || _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵpipeBind1"](7, 20, ctx.cpwd)));
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](4);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("wSwitchErrors", _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵpureFunction2"](28, _c23, ctx.pwd, ctx.cpwd));
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](9);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("type", ctx.inputContentShow ? "text" : "password");
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵpureFunction1"](31, _c24, _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵpipeBind1"](19, 22, "subtext")));
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("show", ctx.inputContentShow);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("type", ctx.confirmInputShow ? "text" : "password");
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵpureFunction1"](33, _c24, _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵpipeBind1"](23, 24, "subtext")));
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("show", ctx.confirmInputShow);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("formGroup", ctx.form);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](4);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵclassProp"]("opacity-30", !ctx.form.valid);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("disabled", !ctx.form.valid);
    }
  },
  dependencies: [_modules_page_module__WEBPACK_IMPORTED_MODULE_4__.CommonPageModule, _libs_bnf_components_ripple_button_ripple_button_directive__WEBPACK_IMPORTED_MODULE_6__.RippleButtonDirective, _libs_bnf_directives_form_errors_directive__WEBPACK_IMPORTED_MODULE_7__.SwitchErrorsDirective, _libs_bnf_directives_form_errors_directive__WEBPACK_IMPORTED_MODULE_7__.SwitchCaseDirective, _libs_bnf_directives_form_errors_directive__WEBPACK_IMPORTED_MODULE_7__.SwitchDefaultDirective, _libs_bnf_directives_auto_complete_off_directive__WEBPACK_IMPORTED_MODULE_8__.AutoCompleteOffDirective, _angular_common__WEBPACK_IMPORTED_MODULE_14__.NgClass, _angular_forms__WEBPACK_IMPORTED_MODULE_13__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_13__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_13__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_13__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_13__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_13__.FormControlName, _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_9__.CommonPageComponent, _libs_bnf_pipes_errors_errors_pipe__WEBPACK_IMPORTED_MODULE_10__.ErrorsPipe, _pipes_color_color_pipe__WEBPACK_IMPORTED_MODULE_11__.ColorPipe, _components_input_hidden_icon_swap_input_hidden_icon_swap_component__WEBPACK_IMPORTED_MODULE_3__["default"]],
  styles: ["/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsInNvdXJjZVJvb3QiOiIifQ== */"],
  changeDetection: 0
});
(0,tslib__WEBPACK_IMPORTED_MODULE_15__.__decorate)([ResetPasswordPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_15__.__metadata)("design:type", Object)], ResetPasswordPage.prototype, "inputContentShow", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_15__.__decorate)([ResetPasswordPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_15__.__metadata)("design:type", Object)], ResetPasswordPage.prototype, "confirmInputShow", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_15__.__decorate)([ResetPasswordPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_15__.__metadata)("design:type", Object)], ResetPasswordPage.prototype, "pwd", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_15__.__decorate)([ResetPasswordPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_15__.__metadata)("design:type", Object)], ResetPasswordPage.prototype, "cpwd", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_15__.__decorate)([ResetPasswordPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_15__.__metadata)("design:type", _angular_forms__WEBPACK_IMPORTED_MODULE_13__.FormGroup)], ResetPasswordPage.prototype, "form", void 0);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ResetPasswordPage);

/***/ })

}]);
//# sourceMappingURL=default-apps_wallet_src_pages_mnemonic_pages_reset-password_reset-password_component_ts.js.map