"use strict";
(self["webpackChunkwallet"] = self["webpackChunkwallet"] || []).push([["apps_wallet_src_pages_mnemonic_pages_mnemonics-backup_mnemonics-backup_component_ts"],{

/***/ 6280:
/*!*********************************************************************************************!*\
  !*** ./apps/wallet/src/pages/mnemonic/pages/mnemonics-backup/mnemonics-backup.component.ts ***!
  \*********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   MnemonicsBackupPage: () => (/* binding */ MnemonicsBackupPage),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 52542);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! tslib */ 90505);
/* harmony import */ var _modules_page_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ~modules/page.module */ 77538);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 61039);
/* harmony import */ var _libs_bnf_components_ripple_button_ripple_button_directive__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../../../libs/bnf/components/ripple-button/ripple-button.directive */ 16505);
/* harmony import */ var _libs_bnf_directives_click_to_copy_directive__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../../../../libs/bnf/directives/click-to-copy.directive */ 46413);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common */ 6729);
/* harmony import */ var _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../../../../../libs/bnf/modules/page/common-page/common-page.component */ 62052);

var _class;







function MnemonicsBackupPage_ng_container_7_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](1, "div", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](3, "div", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const item_r1 = ctx.$implicit;
    const i_r2 = ctx.index;
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"](" ", item_r1, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"](" ", i_r2 + 1, " ");
  }
}
/**
 * 备份助记词页
 */
/**
 * 备份助记词页
 */
class MnemonicsBackupPage extends _modules_page_module__WEBPACK_IMPORTED_MODULE_1__.CommonPageBase {
  constructor() {
    super(...arguments);
    /**
     * 助记词数组
     */
    this.mnemonicArr = [];
    /**
     * 助记词字符串
     */
    this.mnemonicString = '';
    /** 是否为导出模式 */
    this.export = false;
  }
  /** 初始化获取传参 */
  initMnemonicArr() {
    var _this = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const resolveData = _this.resolveData;
      _this.mnemonicString = resolveData.mnemonic.mnemonicString;
      _this.mnemonicArr = resolveData.mnemonic.mnemonicArr;
      _this.console.log('resolveData', resolveData);
    })();
  }
  /** 确认已备份 */
  confirmClick() {
    var _this2 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      /**
       * 设置的钱包参数
       * @TODO 变量类型
       * */
      return _this2.nav.routeTo('/mnemonic/mnemonic-confirm-backup', {
        ..._this2.nav.getQueryParams(),
        mnemonicArr: _this2.mnemonicArr
      }, typeof _this2.export === 'string' ? _this2.export === 'true' : _this2.export);
    })();
  }
}
_class = MnemonicsBackupPage;
_class.ɵfac = /*@__PURE__*/(() => {
  let ɵMnemonicsBackupPage_BaseFactory;
  return function MnemonicsBackupPage_Factory(t) {
    return (ɵMnemonicsBackupPage_BaseFactory || (ɵMnemonicsBackupPage_BaseFactory = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵgetInheritedFactory"](_class)))(t || _class);
  };
})();
_class.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineComponent"]({
  type: _class,
  selectors: [["w-mnemonics-backup-page"]],
  standalone: true,
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵInheritDefinitionFeature"], _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵStandaloneFeature"]],
  decls: 15,
  vars: 8,
  consts: () => {
    let i18n_0;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_BACKUP_MNEMONIC$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_MNEMONICS_BACKUP_MNEMONICS_BACKUP_COMPONENT_TS_1 = goog.getMsg("Backup Mnemonic");
      i18n_0 = MSG_EXTERNAL_BACKUP_MNEMONIC$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_MNEMONICS_BACKUP_MNEMONICS_BACKUP_COMPONENT_TS_1;
    } else {
      i18n_0 = "\u5099\u4EFD\u52A9\u8A18\u8A5E";
    }
    let i18n_2;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_YOUR_MNEMONIC$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_MNEMONICS_BACKUP_MNEMONICS_BACKUP_COMPONENT_TS_3 = goog.getMsg("Your Mnemonic");
      i18n_2 = MSG_EXTERNAL_YOUR_MNEMONIC$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_MNEMONICS_BACKUP_MNEMONICS_BACKUP_COMPONENT_TS_3;
    } else {
      i18n_2 = "\u60A8\u7684\u52A9\u8A18\u8A5E";
    }
    let i18n_4;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_THIS_IS_YOUR_MNEMONIC_GET_THE_MNEMONIC_TO_OWN_THE_WALLET_ASSET_PLEASE_WRITE_IT_DOWN_ON_PAPER_AND_KEEP_IT_IN_A_SAFE_PLACE$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_MNEMONICS_BACKUP_MNEMONICS_BACKUP_COMPONENT_TS_5 = goog.getMsg(" This is your mnemonic.Get the mnemonic to own the wallet asset! Please write it down on paper and keep it in a safe place. ");
      i18n_4 = MSG_EXTERNAL_THIS_IS_YOUR_MNEMONIC_GET_THE_MNEMONIC_TO_OWN_THE_WALLET_ASSET_PLEASE_WRITE_IT_DOWN_ON_PAPER_AND_KEEP_IT_IN_A_SAFE_PLACE$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_MNEMONICS_BACKUP_MNEMONICS_BACKUP_COMPONENT_TS_5;
    } else {
      i18n_4 = "\u9019\u662F\u60A8\u7684\u52A9\u8A18\u8A5E\u3002\u7372\u5F97\u52A9\u8A18\u8A5E\u5C07\u64C1\u6709\u9322\u5305\u8CC7\u7522\u6240\u6709\u6B0A\uFF01\u8ACB\u5C07\u5176\u5BEB\u5728\u7D19\u4E0A\u4E26\u4FDD\u5B58\u5728\u5B89\u5168\u7684\u5730\u65B9\u3002";
    }
    let i18n_6;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_COPY_THE_MNEMONICE$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_MNEMONICS_BACKUP_MNEMONICS_BACKUP_COMPONENT_TS_7 = goog.getMsg(" Copy The Mnemonice ");
      i18n_6 = MSG_EXTERNAL_COPY_THE_MNEMONICE$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_MNEMONICS_BACKUP_MNEMONICS_BACKUP_COMPONENT_TS_7;
    } else {
      i18n_6 = "\u8907\u88FD\u52A9\u8A18\u8A5E";
    }
    let i18n_8;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_CONFIRM_BACKED_UP$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_MNEMONICS_BACKUP_MNEMONICS_BACKUP_COMPONENT_TS_9 = goog.getMsg(" Confirm Backed Up ");
      i18n_8 = MSG_EXTERNAL_CONFIRM_BACKED_UP$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_MNEMONICS_BACKUP_MNEMONICS_BACKUP_COMPONENT_TS_9;
    } else {
      i18n_8 = "\u78BA\u8A8D\u5DF2\u5099\u4EFD";
    }
    return [[3, "contentSafeArea", "contentBackground", "headerBackground", "headerTranslucent", "footerTranslucent", "footerOpacity"], [1, "text-title", "pt-2"], [1, "text-base", "font-semibold"], i18n_0, [1, "text-subtext", "mb-2", "text-xs", "font-normal"], i18n_2, [1, "bg-grey", "flex", "flex-wrap", "items-center", "justify-evenly", "rounded-lg", "pt-1.5"], [4, "ngFor", "ngForOf"], [1, "text-subtext", "mt-5", "text-sm"], i18n_4, ["footer", "", 1, "grid", "place-items-center", "gap-6"], ["bnRippleButton", "", 1, "text-primary", "mt-2", 3, "wClickToCopy"], i18n_6, ["bnRippleButton", "", "type", "button", 1, "h-10.5", "from-purple-gradient-start", "to-purple-gradient-end", "mb-4", "w-full", "rounded-full", "bg-gradient-to-b", "text-center", "text-sm", "text-white", 3, "click"], i18n_8, [1, "_select-mne-box", "relative", "mb-1.5", "flex", "items-center", "justify-center", "rounded-sm", "bg-white", "text-base", "font-semibold"], [1, "text-subtext", "text-xss", "absolute", "bottom-0", "right-1"]];
  },
  template: function MnemonicsBackupPage_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "common-page", 0)(1, "div", 1)(2, "div", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵi18n"](3, 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](4, "div", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵi18n"](5, 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](6, "div", 6);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](7, MnemonicsBackupPage_ng_container_7_Template, 5, 2, "ng-container", 7);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](8, "div", 8);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵi18n"](9, 9);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](10, "div", 10)(11, "button", 11);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵi18n"](12, 12);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](13, "button", 13);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("click", function MnemonicsBackupPage_Template_button_click_13_listener() {
        return ctx.confirmClick();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵi18n"](14, 14);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()()();
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("contentSafeArea", true)("contentBackground", "white")("headerBackground", "transparent")("headerTranslucent", false)("footerTranslucent", false)("footerOpacity", 0.8);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](7);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngForOf", ctx.mnemonicArr);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](4);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("wClickToCopy", ctx.mnemonicString);
    }
  },
  dependencies: [_modules_page_module__WEBPACK_IMPORTED_MODULE_1__.CommonPageModule, _libs_bnf_components_ripple_button_ripple_button_directive__WEBPACK_IMPORTED_MODULE_2__.RippleButtonDirective, _libs_bnf_directives_click_to_copy_directive__WEBPACK_IMPORTED_MODULE_3__.ClickToCopyDirective, _angular_common__WEBPACK_IMPORTED_MODULE_6__.NgForOf, _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_4__.CommonPageComponent],
  styles: ["[_nghost-%COMP%]   ._select-mne-box[_ngcontent-%COMP%] {\n  width: 27.6466666667vw;\n  height: 12.8vw;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL2FwcHMvd2FsbGV0L3NyYy9wYWdlcy9tbmVtb25pYy9wYWdlcy9tbmVtb25pY3MtYmFja3VwL21uZW1vbmljcy1iYWNrdXAuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQ0U7RUFDRSxzQkFBQTtFQUNBLGNBQUE7QUFBSiIsInNvdXJjZXNDb250ZW50IjpbIjpob3N0IHtcclxuICAuX3NlbGVjdC1tbmUtYm94IHtcclxuICAgIHdpZHRoOiBjYWxjKCgxMDB2dyAtIDE3LjA2dncpIC8gMyk7XHJcbiAgICBoZWlnaHQ6IDEyLjh2dztcclxuICB9XHJcbn1cclxuIl0sInNvdXJjZVJvb3QiOiIifQ== */"],
  changeDetection: 0
});
(0,tslib__WEBPACK_IMPORTED_MODULE_7__.__decorate)([MnemonicsBackupPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__metadata)("design:type", Array)], MnemonicsBackupPage.prototype, "mnemonicArr", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_7__.__decorate)([MnemonicsBackupPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__metadata)("design:type", Object)], MnemonicsBackupPage.prototype, "mnemonicString", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_7__.__decorate)([MnemonicsBackupPage.QueryParam('export'), (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__metadata)("design:type", Object)], MnemonicsBackupPage.prototype, "export", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_7__.__decorate)([MnemonicsBackupPage.OnInit(), (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__metadata)("design:returntype", Promise)], MnemonicsBackupPage.prototype, "initMnemonicArr", null);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MnemonicsBackupPage);

/***/ })

}]);
//# sourceMappingURL=apps_wallet_src_pages_mnemonic_pages_mnemonics-backup_mnemonics-backup_component_ts.js.map