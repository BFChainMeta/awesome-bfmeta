"use strict";
(self["webpackChunkwallet"] = self["webpackChunkwallet"] || []).push([["apps_wallet_src_pages_mnemonic_pages_change-password-before_change-password-before_component_ts"],{

/***/ 86168:
/*!*********************************************************************************************************!*\
  !*** ./apps/wallet/src/pages/mnemonic/pages/change-password-before/change-password-before.component.ts ***!
  \*********************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ChangePasswordBeforePage: () => (/* binding */ ChangePasswordBeforePage),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 52542);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! tslib */ 90505);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/core */ 61039);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/forms */ 7820);
/* harmony import */ var _bnqkl_framework_controllers__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @bnqkl/framework/controllers */ 47919);
/* harmony import */ var _bnqkl_util_web_decorator__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @bnqkl/util-web/decorator */ 18112);
/* harmony import */ var _bnqkl_wallet_base_services_wallet_wallet_data_storage__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @bnqkl/wallet-base/services/wallet/wallet-data-storage */ 63024);
/* harmony import */ var _components_input_hidden_icon_swap_input_hidden_icon_swap_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ~components/input-hidden-icon-swap/input-hidden-icon-swap.component */ 68027);
/* harmony import */ var _modules_page_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ~modules/page.module */ 77538);
/* harmony import */ var _libs_bnf_components_ripple_button_ripple_button_directive__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../../../../../libs/bnf/components/ripple-button/ripple-button.directive */ 16505);
/* harmony import */ var _libs_bnf_directives_form_errors_directive__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../../../../../libs/bnf/directives/form-errors.directive */ 29541);
/* harmony import */ var _libs_bnf_directives_auto_complete_off_directive__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../../../../../libs/bnf/directives/auto-complete-off.directive */ 66722);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/common */ 6729);
/* harmony import */ var _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../../../../../../libs/bnf/modules/page/common-page/common-page.component */ 62052);
/* harmony import */ var _libs_bnf_pipes_errors_errors_pipe__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../../../../../../libs/bnf/pipes/errors/errors.pipe */ 68362);
/* harmony import */ var _pipes_color_color_pipe__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../../../pipes/color/color.pipe */ 76489);

var _class;

















function ChangePasswordBeforePage_ng_template_8_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵi18n"](1, 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementContainerEnd"]();
  }
}
function ChangePasswordBeforePage_ng_template_9_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const error_r2 = ctx.$error;
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtextInterpolate"](error_r2);
  }
}
const _c8 = a0 => ({
  "text-error": a0
});
const _c9 = a0 => ({
  "--color-1": a0
});
/**
 * 修改安全密码页面
 */
class ChangePasswordBeforePage extends _modules_page_module__WEBPACK_IMPORTED_MODULE_5__.CommonPageBase {
  constructor() {
    var _this;
    /** 页面返回值的类型 */
    super(...arguments);
    _this = this;
    this.returnValue$ = new _modules_page_module__WEBPACK_IMPORTED_MODULE_5__.PageReturnValue();
    /** 引入钱包存储服务 */
    this.walletDataStorageV2Service = (0,_angular_core__WEBPACK_IMPORTED_MODULE_12__.inject)(_bnqkl_wallet_base_services_wallet_wallet_data_storage__WEBPACK_IMPORTED_MODULE_3__.WalletDataStorageV2Service);
    /** 表单验证服务 */
    this.validators = new _bnqkl_framework_controllers__WEBPACK_IMPORTED_MODULE_1__.FormValidatorsController(this);
    /**
     * 旧密码型内容显示与否
     */
    this.inputOldPwdContentShow = false;
    /** 当前密码 */
    this.currentPassword = new _angular_forms__WEBPACK_IMPORTED_MODULE_13__.FormControl('', {
      nonNullable: true,
      validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_13__.Validators.required],
      asyncValidators: [( /*#__PURE__*/function () {
        var _ref = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (control) {
          /// 存在其他错误，本次先不判断
          if (control.errors) {
            return null;
          }
          const password = _this._currentPwd;
          if (password !== control.value) {
            return {
              password: "\u5BC6\u78BC\u8F38\u5165\u932F\u8AA4"
            };
          }
          return null;
        });
        return function (_x) {
          return _ref.apply(this, arguments);
        };
      }())]
    });
    /** 要提交的表单与复合验证 */
    this.form = new _angular_forms__WEBPACK_IMPORTED_MODULE_13__.FormGroup({
      currentPassword: this.currentPassword
    }, {
      validators: [],
      asyncValidators: []
    });
  }
  /** 当前密码，缓存 */
  get _currentPwd() {
    return this.walletDataStorageV2Service.walletAppSettings.password;
  }
  /** 提交事件 */
  onSubmit() {
    var _this2 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this2.nav.routeTo('/mnemonic/change-password', undefined, true);
    })();
  }
}
_class = ChangePasswordBeforePage;
_class.ɵfac = /*@__PURE__*/(() => {
  let ɵChangePasswordBeforePage_BaseFactory;
  return function ChangePasswordBeforePage_Factory(t) {
    return (ɵChangePasswordBeforePage_BaseFactory || (ɵChangePasswordBeforePage_BaseFactory = _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵgetInheritedFactory"](_class)))(t || _class);
  };
})();
_class.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵdefineComponent"]({
  type: _class,
  selectors: [["w-change-password-before-page"]],
  outputs: {
    returnValue$: "returnValue$"
  },
  standalone: true,
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵInheritDefinitionFeature"], _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵStandaloneFeature"]],
  decls: 17,
  vars: 22,
  consts: () => {
    let i18n_0;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_CURRENT_PASSWORD$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_CHANGE_PASSWORD_BEFORE_CHANGE_PASSWORD_BEFORE_COMPONENT_TS_1 = goog.getMsg(" Current Password ");
      i18n_0 = MSG_EXTERNAL_CURRENT_PASSWORD$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_CHANGE_PASSWORD_BEFORE_CHANGE_PASSWORD_BEFORE_COMPONENT_TS_1;
    } else {
      i18n_0 = "\u7576\u524D\u5BC6\u78BC";
    }
    let i18n_2;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_ENTER_YOUR_CURRENT_PASSWORD$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_CHANGE_PASSWORD_BEFORE_CHANGE_PASSWORD_BEFORE_COMPONENT_TS_3 = goog.getMsg("Enter your current password");
      i18n_2 = MSG_EXTERNAL_ENTER_YOUR_CURRENT_PASSWORD$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_CHANGE_PASSWORD_BEFORE_CHANGE_PASSWORD_BEFORE_COMPONENT_TS_3;
    } else {
      i18n_2 = "\u8F38\u5165\u7576\u524D\u5BC6\u78BC";
    }
    let i18n_4;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_NEXT$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_CHANGE_PASSWORD_BEFORE_CHANGE_PASSWORD_BEFORE_COMPONENT_TS_5 = goog.getMsg(" Next ");
      i18n_4 = MSG_EXTERNAL_NEXT$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_CHANGE_PASSWORD_BEFORE_CHANGE_PASSWORD_BEFORE_COMPONENT_TS_5;
    } else {
      i18n_4 = "\u4E0B\u4E00\u6B65";
    }
    let i18n_6;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_ENTER_YOUR_CURRENT_PASSWORD$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_CHANGE_PASSWORD_BEFORE_CHANGE_PASSWORD_BEFORE_COMPONENT_TS__7 = goog.getMsg("Enter your current password");
      i18n_6 = MSG_EXTERNAL_ENTER_YOUR_CURRENT_PASSWORD$$APPS_WALLET_SRC_PAGES_MNEMONIC_PAGES_CHANGE_PASSWORD_BEFORE_CHANGE_PASSWORD_BEFORE_COMPONENT_TS__7;
    } else {
      i18n_6 = "\u8F38\u5165\u7576\u524D\u5BC6\u78BC";
    }
    return [[3, "contentSafeArea", "contentBackground", "headerBackground"], [3, "formGroup", "ngSubmit"], [1, "flex", "h-10", "w-full", "items-end", "justify-between", "text-xs", "font-semibold"], [1, "flex-shrink-0", "pr-2", 3, "ngClass"], i18n_0, [1, "text-error", "text-xss", "text-right", 3, "wSwitchErrors"], ["wCaseKey", "required"], ["wCaseKey", "password"], [1, "mt-1", "flex", "h-10", "items-center", "rounded-lg", "bg-white", "pr-2"], ["formControlName", "currentPassword", "placeholder", i18n_2, 1, "w-full", "px-2", 3, "type"], [1, "icon-5.5", "text-subtext", "ml-6", "flex-shrink-0", 3, "show", "showChange"], ["footer", "", 3, "formGroup", "ngSubmit"], ["bnRippleButton", "", "type", "submit", 1, "h-10.5", "bg-primary-2", "w-full", "rounded-full", "text-center", "text-white", 3, "disabled"], i18n_4, i18n_6];
  },
  template: function ChangePasswordBeforePage_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](0, "common-page", 0)(1, "form", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵlistener"]("ngSubmit", function ChangePasswordBeforePage_Template_form_ngSubmit_1_listener() {
        return ctx.onSubmit();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](2, "fieldset")(3, "legend", 2)(4, "div", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵi18n"](5, 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵpipe"](6, "errors");
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](7, "div", 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtemplate"](8, ChangePasswordBeforePage_ng_template_8_Template, 2, 0, "ng-template", 6)(9, ChangePasswordBeforePage_ng_template_9_Template, 2, 1, "ng-template", 7);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](10, "div", 8);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelement"](11, "input", 9);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](12, "w-input-hidden-icon-swap", 10);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵlistener"]("showChange", function ChangePasswordBeforePage_Template_w_input_hidden_icon_swap_showChange_12_listener($event) {
        return ctx.inputOldPwdContentShow = $event;
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵpipe"](13, "color");
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]()()()();
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](14, "form", 11);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵlistener"]("ngSubmit", function ChangePasswordBeforePage_Template_form_ngSubmit_14_listener() {
        return ctx.onSubmit();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](15, "button", 12);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵi18n"](16, 13);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]()()();
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("contentSafeArea", true)("contentBackground", "grey")("headerBackground", "grey");
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("formGroup", ctx.form);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵpureFunction1"](18, _c8, _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵpipeBind1"](6, 14, ctx.currentPassword)));
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("wSwitchErrors", ctx.currentPassword);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](4);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("type", ctx.inputOldPwdContentShow ? "text" : "password");
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵpureFunction1"](20, _c9, _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵpipeBind1"](13, 16, "subtext")));
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("show", ctx.inputOldPwdContentShow);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("formGroup", ctx.form);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵclassProp"]("opacity-30", !ctx.form.valid);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("disabled", !ctx.form.valid);
    }
  },
  dependencies: [_modules_page_module__WEBPACK_IMPORTED_MODULE_5__.CommonPageModule, _libs_bnf_components_ripple_button_ripple_button_directive__WEBPACK_IMPORTED_MODULE_6__.RippleButtonDirective, _libs_bnf_directives_form_errors_directive__WEBPACK_IMPORTED_MODULE_7__.SwitchErrorsDirective, _libs_bnf_directives_form_errors_directive__WEBPACK_IMPORTED_MODULE_7__.SwitchCaseDirective, _libs_bnf_directives_auto_complete_off_directive__WEBPACK_IMPORTED_MODULE_8__.AutoCompleteOffDirective, _angular_common__WEBPACK_IMPORTED_MODULE_14__.NgClass, _angular_forms__WEBPACK_IMPORTED_MODULE_13__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_13__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_13__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_13__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_13__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_13__.FormControlName, _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_9__.CommonPageComponent, _libs_bnf_pipes_errors_errors_pipe__WEBPACK_IMPORTED_MODULE_10__.ErrorsPipe, _pipes_color_color_pipe__WEBPACK_IMPORTED_MODULE_11__.ColorPipe, _components_input_hidden_icon_swap_input_hidden_icon_swap_component__WEBPACK_IMPORTED_MODULE_4__.InputHiddenIconSwapComponent],
  styles: ["/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsInNvdXJjZVJvb3QiOiIifQ== */"],
  changeDetection: 0
});
(0,tslib__WEBPACK_IMPORTED_MODULE_15__.__decorate)([ChangePasswordBeforePage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_15__.__metadata)("design:type", Object)], ChangePasswordBeforePage.prototype, "inputOldPwdContentShow", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_15__.__decorate)([ChangePasswordBeforePage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_15__.__metadata)("design:type", Object)], ChangePasswordBeforePage.prototype, "currentPassword", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_15__.__decorate)([_bnqkl_util_web_decorator__WEBPACK_IMPORTED_MODULE_2__.cacheGetter, (0,tslib__WEBPACK_IMPORTED_MODULE_15__.__metadata)("design:type", Object), (0,tslib__WEBPACK_IMPORTED_MODULE_15__.__metadata)("design:paramtypes", [])], ChangePasswordBeforePage.prototype, "_currentPwd", null);
(0,tslib__WEBPACK_IMPORTED_MODULE_15__.__decorate)([ChangePasswordBeforePage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_15__.__metadata)("design:type", Object)], ChangePasswordBeforePage.prototype, "form", void 0);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ChangePasswordBeforePage);

/***/ }),

/***/ 11606:
/*!************************************************************!*\
  !*** ./libs/bnf/controllers/form-validators.controller.ts ***!
  \************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   FormValidatorsController: () => (/* binding */ FormValidatorsController)
/* harmony export */ });
/* harmony import */ var _bnqkl_framework_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @bnqkl/framework/core */ 63563);
/* harmony import */ var _bnqkl_util_web_extends_map__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @bnqkl/util-web/extends-map */ 37689);


/**
 * 页面表单扩展验证器
 *
 * > 因为涉及到FromControl的生命周期管理，所以这里需要使用Controller模式来获取组件/页面的生命周期
 *
 * 为了确保类型安全, 请遵循以下规则去定义验证器:
 * 1. 尽可能直接提供 $ValidatorFn,比如 `trimRequired(control: AbstractControl): $ValidationErrors | null {...}`
 * 2. 如果不能直接提供 $ValidatorFn, 那么作为工厂模式,必然要有参数传入,比如 `equals(leaderCtrl: AbstractControl): $ValidatorFn {...}`
 */
class FormValidatorsController {
  /**
   * 通过订阅原页面的生命周期，来对订阅的字段进行监听解除
   */
  constructor(comp) {
    /**
     * 判断两个数据字段相等的时，left===right 中 left的数据订阅
     */
    this._equalsLeaderMap = _bnqkl_util_web_extends_map__WEBPACK_IMPORTED_MODULE_1__.EasyMap.from({
      creater(ctrl) {
        const sub = {
          sub$: ctrl.valueChanges.subscribe(() => {
            for (const ctrl of sub.destControls) {
              ctrl.updateValueAndValidity();
            }
          }),
          destControls: new Set()
        };
        return sub;
      }
    });
    (0,_bnqkl_framework_core__WEBPACK_IMPORTED_MODULE_0__.addLifecycleMethods)(comp, 'ngOnDestroy', {
      origin: 'form-validator',
      method: () => {
        for (const {
          sub$
        } of this._equalsLeaderMap.values()) {
          sub$.unsubscribe();
        }
        this._equalsLeaderMap.clear();
      },
      order: Number.MAX_SAFE_INTEGER /* 最后才做这些事情 */
    });
  }
  /** 两个字段对比 相等就过 不相等返回 {equals:true} */
  equals(leaderCtrl) {
    const leader = this._equalsLeaderMap.forceGet(leaderCtrl);
    // pwdCtrl.val
    return follerCtrl => {
      leader.destControls.add(follerCtrl);
      if (leaderCtrl.value === follerCtrl.value) {
        return null;
      }
      return {
        equals: true
      };
    };
  }
  /** 是否包含空格 */
  whitespace(control) {
    const value = control.value;
    if (typeof value === 'string' && /\s/.test(value)) {
      return {
        whitespace: true
      };
    }
    return null;
  }
  /** required 变体, 左右两边不能包含空格 */
  trimRequired(control) {
    const value = control.value;
    if (typeof value === 'string' && value.trim().length === 0 || value == undefined) {
      return {
        trimRequired: true
      };
    }
    return null;
  }
}

/***/ }),

/***/ 47919:
/*!***************************************!*\
  !*** ./libs/bnf/controllers/index.ts ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   FormValidatorsController: () => (/* reexport safe */ _form_validators_controller__WEBPACK_IMPORTED_MODULE_0__.FormValidatorsController),
/* harmony export */   PageReturnController: () => (/* reexport safe */ _page_return_controller__WEBPACK_IMPORTED_MODULE_1__.PageReturnController)
/* harmony export */ });
/* harmony import */ var _form_validators_controller__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./form-validators.controller */ 11606);
/* harmony import */ var _page_return_controller__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./page-return.controller */ 62893);



/***/ }),

/***/ 62893:
/*!********************************************************!*\
  !*** ./libs/bnf/controllers/page-return.controller.ts ***!
  \********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   PageReturnController: () => (/* binding */ PageReturnController)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 54106);
/* harmony import */ var _bnqkl_util_web_decorator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @bnqkl/util-web/decorator */ 18112);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs */ 19177);



/**
 * 页面数据返回值的订阅功能
 * > Controller 必须在构造函数期间执行
 */
class PageReturnController {
  /** 继承日志 */
  get console() {
    return this.fromPage.console;
  }
  /**
   * 传入源页面与目标页面的构造函数，并通过订阅原页面的生命周期，来初始化对路由的订阅
   * 这里依赖 ion-router-outlet 来获取跳转过去的页面
   * 注：该监听返回是全触发（只要页面没被销毁掉不管页面是否处于激活状态）
   * @param specific 用于指定fromPage触发（需要手动指定），业务需要
   */
  constructor(fromPage, toPageCtor, specific = false) {
    this.fromPage = fromPage;
    /** 当前定阅过的页面 */
    this._toPages = new WeakSet();
    /**
     * 订阅到的返回内容，
     * 类型由对应页面的 returnValue$ 的定义决定
     */
    this.pageReturn$ = new rxjs__WEBPACK_IMPORTED_MODULE_1__.Subject();
    const {
      nav
    } = fromPage;
    fromPage.takeUntilDestroy(nav.pageActiveState$).subscribe(event => {
      /// 只监听新激活的页面
      if (event.type !== 'activate') {
        return;
      }
      const toPage = event.target;
      if (toPage instanceof toPageCtor &&
      // 去重
      this._toPages.has(toPage) === false) {
        if (toPage.returnValue$ === undefined) {
          return;
        }
        this._toPages.add(toPage);
        if (specific) {
          var _toPage$specificRetur;
          (_toPage$specificRetur = toPage.specificReturnPages) === null || _toPage$specificRetur === void 0 || _toPage$specificRetur.add(fromPage);
        }
        fromPage.takeUntilDestroy(toPage.returnValue$).subscribe({
          next: data => {
            /// 这里不用判断specific
            if (toPage.specificReturnPages && toPage.specificReturnPages.size) {
              /// 如果有写入，那么就只需要触发相对应页面就行
              toPage.specificReturnPages.has(fromPage) && this.pageReturn$.next(data);
              return;
            }
            this.pageReturn$.next(data);
          },
          complete: () => {
            var _toPage$specificRetur2;
            // 释放内存引用
            (_toPage$specificRetur2 = toPage.specificReturnPages) === null || _toPage$specificRetur2 === void 0 || _toPage$specificRetur2.delete(fromPage);
            return this._toPages.delete(toPage);
          }
        });
      }
    });
  }
}
(0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([_bnqkl_util_web_decorator__WEBPACK_IMPORTED_MODULE_0__.cacheGetter, (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__metadata)("design:type", Object), (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__metadata)("design:paramtypes", [])], PageReturnController.prototype, "console", null);

/***/ })

}]);
//# sourceMappingURL=apps_wallet_src_pages_mnemonic_pages_change-password-before_change-password-before_component_ts.js.map