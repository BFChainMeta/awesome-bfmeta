(self["webpackChunkwallet"] = self["webpackChunkwallet"] || []).push([["common"],{

/***/ 86977:
/*!*************************************************************!*\
  !*** ./apps/wallet/src/pages/demo/pages/to/to.component.ts ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ToPage: () => (/* binding */ ToPage),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _modules_page_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ~modules/page.module */ 77538);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 61039);
/* harmony import */ var _libs_bnf_directives_auto_complete_off_directive__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../../../../../libs/bnf/directives/auto-complete-off.directive */ 66722);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ 7820);
/* harmony import */ var _angular_material_button__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/material/button */ 12300);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ 56776);
/* harmony import */ var _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../../../libs/bnf/modules/page/common-page/common-page.component */ 62052);
var _class;







/**
 * 测试数据返回的页面
 */
class ToPage extends _modules_page_module__WEBPACK_IMPORTED_MODULE_0__.CommonPageBase {
  constructor() {
    super(...arguments);
    /** 要返回的数据 */
    this.data = '返回数据';
  }
  /** 返回数据并退出路由 */
  doReturn() {
    this.returnValue$.next(this.data);
    this.nav.back();
  }
}
_class = ToPage;
_class.ɵfac = /*@__PURE__*/(() => {
  let ɵToPage_BaseFactory;
  return function ToPage_Factory(t) {
    return (ɵToPage_BaseFactory || (ɵToPage_BaseFactory = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵgetInheritedFactory"](_class)))(t || _class);
  };
})();
_class.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineComponent"]({
  type: _class,
  selectors: [["w-to-page"]],
  outputs: {
    returnValue$: "returnValue$"
  },
  standalone: true,
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵInheritDefinitionFeature"], _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵStandaloneFeature"]],
  decls: 6,
  vars: 2,
  consts: [[1, "bg-text-100", "rounded-lg", "p-4", 3, "ngModel", "ngModelChange"], ["mat-raised-button", "", 3, "click"], [3, "routerLink"]],
  template: function ToPage_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "common-page")(1, "input", 0);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("ngModelChange", function ToPage_Template_input_ngModelChange_1_listener($event) {
        return ctx.data = $event;
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](2, "button", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function ToPage_Template_button_click_2_listener() {
        return ctx.doReturn();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](3, "\u8FD4\u56DE\u6570\u636E");
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](4, "a", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](5, "to home");
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngModel", ctx.data);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("routerLink", "/home");
    }
  },
  dependencies: [_modules_page_module__WEBPACK_IMPORTED_MODULE_0__.CommonPageModule, _libs_bnf_directives_auto_complete_off_directive__WEBPACK_IMPORTED_MODULE_1__.AutoCompleteOffDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.NgModel, _angular_material_button__WEBPACK_IMPORTED_MODULE_5__.MatButton, _angular_router__WEBPACK_IMPORTED_MODULE_6__.RouterLink, _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_2__.CommonPageComponent],
  styles: ["/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsInNvdXJjZVJvb3QiOiIifQ== */"],
  changeDetection: 0
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ToPage);

/***/ }),

/***/ 75498:
/*!********************************************************************************************************!*\
  !*** ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/AsyncGenerator.js ***!
  \********************************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var OverloadYield = __webpack_require__(/*! ./OverloadYield.js */ 65646);
function AsyncGenerator(e) {
  var r, t;
  function resume(r, t) {
    try {
      var n = e[r](t),
        o = n.value,
        u = o instanceof OverloadYield;
      Promise.resolve(u ? o.v : o).then(function (t) {
        if (u) {
          var i = "return" === r ? "return" : "next";
          if (!o.k || t.done) return resume(i, t);
          t = e[i](t).value;
        }
        settle(n.done ? "return" : "normal", t);
      }, function (e) {
        resume("throw", e);
      });
    } catch (e) {
      settle("throw", e);
    }
  }
  function settle(e, n) {
    switch (e) {
      case "return":
        r.resolve({
          value: n,
          done: !0
        });
        break;
      case "throw":
        r.reject(n);
        break;
      default:
        r.resolve({
          value: n,
          done: !1
        });
    }
    (r = r.next) ? resume(r.key, r.arg) : t = null;
  }
  this._invoke = function (e, n) {
    return new Promise(function (o, u) {
      var i = {
        key: e,
        arg: n,
        resolve: o,
        reject: u,
        next: null
      };
      t ? t = t.next = i : (r = t = i, resume(e, n));
    });
  }, "function" != typeof e["return"] && (this["return"] = void 0);
}
AsyncGenerator.prototype["function" == typeof Symbol && Symbol.asyncIterator || "@@asyncIterator"] = function () {
  return this;
}, AsyncGenerator.prototype.next = function (e) {
  return this._invoke("next", e);
}, AsyncGenerator.prototype["throw"] = function (e) {
  return this._invoke("throw", e);
}, AsyncGenerator.prototype["return"] = function (e) {
  return this._invoke("return", e);
};
module.exports = AsyncGenerator, module.exports.__esModule = true, module.exports["default"] = module.exports;

/***/ }),

/***/ 65646:
/*!*******************************************************************************************************!*\
  !*** ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/OverloadYield.js ***!
  \*******************************************************************************************************/
/***/ ((module) => {

function _OverloadYield(t, e) {
  this.v = t, this.k = e;
}
module.exports = _OverloadYield, module.exports.__esModule = true, module.exports["default"] = module.exports;

/***/ }),

/***/ 23269:
/*!****************************************************************************************************************!*\
  !*** ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/asyncGeneratorDelegate.js ***!
  \****************************************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var OverloadYield = __webpack_require__(/*! ./OverloadYield.js */ 65646);
function _asyncGeneratorDelegate(t) {
  var e = {},
    n = !1;
  function pump(e, r) {
    return n = !0, r = new Promise(function (n) {
      n(t[e](r));
    }), {
      done: !1,
      value: new OverloadYield(r, 1)
    };
  }
  return e["undefined" != typeof Symbol && Symbol.iterator || "@@iterator"] = function () {
    return this;
  }, e.next = function (t) {
    return n ? (n = !1, t) : pump("next", t);
  }, "function" == typeof t["throw"] && (e["throw"] = function (t) {
    if (n) throw n = !1, t;
    return pump("throw", t);
  }), "function" == typeof t["return"] && (e["return"] = function (t) {
    return n ? (n = !1, t) : pump("return", t);
  }), e;
}
module.exports = _asyncGeneratorDelegate, module.exports.__esModule = true, module.exports["default"] = module.exports;

/***/ }),

/***/ 20278:
/*!*******************************************************************************************************!*\
  !*** ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/asyncIterator.js ***!
  \*******************************************************************************************************/
/***/ ((module) => {

function _asyncIterator(r) {
  var n,
    t,
    o,
    e = 2;
  for ("undefined" != typeof Symbol && (t = Symbol.asyncIterator, o = Symbol.iterator); e--;) {
    if (t && null != (n = r[t])) return n.call(r);
    if (o && null != (n = r[o])) return new AsyncFromSyncIterator(n.call(r));
    t = "@@asyncIterator", o = "@@iterator";
  }
  throw new TypeError("Object is not async iterable");
}
function AsyncFromSyncIterator(r) {
  function AsyncFromSyncIteratorContinuation(r) {
    if (Object(r) !== r) return Promise.reject(new TypeError(r + " is not an object."));
    var n = r.done;
    return Promise.resolve(r.value).then(function (r) {
      return {
        value: r,
        done: n
      };
    });
  }
  return AsyncFromSyncIterator = function AsyncFromSyncIterator(r) {
    this.s = r, this.n = r.next;
  }, AsyncFromSyncIterator.prototype = {
    s: null,
    n: null,
    next: function next() {
      return AsyncFromSyncIteratorContinuation(this.n.apply(this.s, arguments));
    },
    "return": function _return(r) {
      var n = this.s["return"];
      return void 0 === n ? Promise.resolve({
        value: r,
        done: !0
      }) : AsyncFromSyncIteratorContinuation(n.apply(this.s, arguments));
    },
    "throw": function _throw(r) {
      var n = this.s["return"];
      return void 0 === n ? Promise.reject(r) : AsyncFromSyncIteratorContinuation(n.apply(this.s, arguments));
    }
  }, new AsyncFromSyncIterator(r);
}
module.exports = _asyncIterator, module.exports.__esModule = true, module.exports["default"] = module.exports;

/***/ }),

/***/ 32190:
/*!**********************************************************************************************************!*\
  !*** ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/asyncToGenerator.js ***!
  \**********************************************************************************************************/
/***/ ((module) => {

function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) {
  try {
    var info = gen[key](arg);
    var value = info.value;
  } catch (error) {
    reject(error);
    return;
  }
  if (info.done) {
    resolve(value);
  } else {
    Promise.resolve(value).then(_next, _throw);
  }
}
function _asyncToGenerator(fn) {
  return function () {
    var self = this,
      args = arguments;
    return new Promise(function (resolve, reject) {
      var gen = fn.apply(self, args);
      function _next(value) {
        asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value);
      }
      function _throw(err) {
        asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err);
      }
      _next(undefined);
    });
  };
}
module.exports = _asyncToGenerator, module.exports.__esModule = true, module.exports["default"] = module.exports;

/***/ }),

/***/ 62748:
/*!*************************************************************************************************************!*\
  !*** ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/awaitAsyncGenerator.js ***!
  \*************************************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var OverloadYield = __webpack_require__(/*! ./OverloadYield.js */ 65646);
function _awaitAsyncGenerator(e) {
  return new OverloadYield(e, 0);
}
module.exports = _awaitAsyncGenerator, module.exports.__esModule = true, module.exports["default"] = module.exports;

/***/ }),

/***/ 33827:
/*!************************************************************************************************************!*\
  !*** ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/wrapAsyncGenerator.js ***!
  \************************************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var AsyncGenerator = __webpack_require__(/*! ./AsyncGenerator.js */ 75498);
function _wrapAsyncGenerator(fn) {
  return function () {
    return new AsyncGenerator(fn.apply(this, arguments));
  };
}
module.exports = _wrapAsyncGenerator, module.exports.__esModule = true, module.exports["default"] = module.exports;

/***/ }),

/***/ 95498:
/*!****************************************************************!*\
  !*** ./apps/wallet/src/assets/wallet-util/_setup-3b713780.mjs ***!
  \****************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   p: () => (/* binding */ p)
/* harmony export */ });
/* harmony import */ var D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 52542);
/* harmony import */ var _sha256_e58017d9_mjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./sha256-e58017d9.mjs */ 6612);


const p = /*#__PURE__*/function () {
  var _ref = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
    yield _sha256_e58017d9_mjs__WEBPACK_IMPORTED_MODULE_1__.p.prepare();
  });
  return function p() {
    return _ref.apply(this, arguments);
  };
}();


/***/ }),

/***/ 85354:
/*!****************************************************************!*\
  !*** ./apps/wallet/src/assets/wallet-util/_setup-975b01ba.mjs ***!
  \****************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   prepareTinySecp256k1: () => (/* binding */ i)
/* harmony export */ });
/* harmony import */ var D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 52542);
/* harmony import */ var _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./index-766bdb76.mjs */ 59809);
/* harmony import */ var _index_ae427201_mjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./index-ae427201.mjs */ 35059);



function e() {
  const s = (0,_index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_1__.r)(4);
  return (s[0] << 24) + (s[1] << 16) + (s[2] << 8) + s[3];
}
const i = (0,_index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_1__.a)( /*#__PURE__*/(0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
  (0,_index_ae427201_mjs__WEBPACK_IMPORTED_MODULE_2__.i)(yield (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
    const a = `${_index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_1__.c.wasmBaseUrl}/tiny-secp256k1/secp256k1.wasm`,
      t = yield _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_1__.c.wasmLoader(a);
    return (yield WebAssembly.instantiate(t, {
      "./validate_error.mjs": {
        throwError: _index_ae427201_mjs__WEBPACK_IMPORTED_MODULE_2__.t
      },
      "./rand.mjs": {
        generateInt32: e
      }
    })).instance.exports;
  })());
}));


/***/ }),

/***/ 84816:
/*!**************************************************************!*\
  !*** ./apps/wallet/src/assets/wallet-util/hmac-68b6dab4.mjs ***!
  \**************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   a: () => (/* binding */ n),
/* harmony export */   c: () => (/* binding */ r)
/* harmony export */ });
/* harmony import */ var _WASMInterface_b9f2203b_mjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./WASMInterface-b9f2203b.mjs */ 43670);

function e(e, n) {
  e.init();
  const {
      blockSize: r
    } = e,
    i = function (e, n) {
      const {
          blockSize: r
        } = e,
        i = (0,_WASMInterface_b9f2203b_mjs__WEBPACK_IMPORTED_MODULE_0__.g)(n);
      if (i.length > r) {
        e.update(i);
        const t = e.digest("binary");
        return e.init(), t;
      }
      return new Uint8Array(i.buffer, i.byteOffset, i.length);
    }(e, n),
    o = new Uint8Array(r);
  o.set(i);
  const s = new Uint8Array(r);
  for (let t = 0; t < r; t++) {
    const e = o[t];
    s[t] = 92 ^ e, o[t] = 54 ^ e;
  }
  e.update(o);
  const a = {
    init: () => (e.init(), e.update(o), a),
    update: t => (e.update(t), a),
    digest: t => {
      const n = e.digest("binary");
      return e.init(), e.update(s), e.update(n), e.digest(t);
    },
    save: () => {
      throw new Error("save() not supported");
    },
    load: () => {
      throw new Error("load() not supported");
    },
    blockSize: e.blockSize,
    digestSize: e.digestSize
  };
  return a;
}
function n(t, n) {
  if (!t || !t.then) throw new Error('Invalid hash function is provided! Usage: createHMAC(createMD5(), "key").');
  return t.then(t => e(t, n));
}
const r = e;


/***/ }),

/***/ 35059:
/*!***************************************************************!*\
  !*** ./apps/wallet/src/assets/wallet-util/index-ae427201.mjs ***!
  \***************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   a: () => (/* binding */ un),
/* harmony export */   i: () => (/* binding */ tn),
/* harmony export */   p: () => (/* binding */ on),
/* harmony export */   t: () => (/* binding */ c)
/* harmony export */ });
/* harmony import */ var _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./index-766bdb76.mjs */ 59809);
var _globalThis$indexedDB, _globalThis$indexedDB2;

const t = (_globalThis$indexedDB = (_globalThis$indexedDB2 = globalThis.indexedDB) === null || _globalThis$indexedDB2 === void 0 ? void 0 : _globalThis$indexedDB2.cmp) !== null && _globalThis$indexedDB !== void 0 ? _globalThis$indexedDB : function (n, t) {
    const i = Math.min(n.length, t.length);
    for (let l = 0; l < i; ++l) if (n[l] !== t[l]) return n[l] < t[l] ? -1 : 1;
    return n.length === t.length ? 0 : n.length > t.length ? 1 : -1;
  },
  i = 0,
  l = 1,
  r = 2,
  e = 3,
  o = 4,
  u = 5,
  f = 6,
  a = 7,
  s = {
    [i.toString()]: "Expected Private",
    [l.toString()]: "Expected Point",
    [r.toString()]: "Expected Tweak",
    [e.toString()]: "Expected Hash",
    [o.toString()]: "Expected Signature",
    [u.toString()]: "Expected Extra Data (32 bytes)",
    [f.toString()]: "Expected Parity (1 | 0)",
    [a.toString()]: "Bad Recovery Id"
  };
function c(n) {
  const t = s[n.toString()] || `Unknow error code: ${n}`;
  throw new TypeError(t);
}
const y = 32,
  d = 33,
  g = 65,
  v = 32,
  h = 32,
  p = 32,
  P = 32,
  b = new Uint8Array(32),
  A = new Uint8Array([255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 254, 186, 174, 220, 230, 175, 72, 160, 59, 191, 210, 94, 140, 208, 54, 65, 65]),
  S = new Uint8Array([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 69, 81, 35, 25, 80, 183, 95, 196, 64, 45, 161, 114, 47, 201, 186, 238]);
function _(n) {
  return n instanceof Uint8Array;
}
function x(n, t) {
  for (let i = 0; i < 32; ++i) if (n[i] !== t[i]) return n[i] < t[i] ? -1 : 1;
  return 0;
}
function T(n) {
  return 0 === x(n, b);
}
function U(n) {
  return _(n) && n.length === y && x(n, b) > 0 && x(n, A) < 0;
}
function E(n) {
  return _(n) && n.length === v;
}
function I(n) {
  U(n) || c(i);
}
function m(n) {
  (function (n) {
    return _(n) && (n.length === d || n.length === g || n.length === v);
  })(n) || c(l);
}
function w(n) {
  E(n) || c(l);
}
function N(n) {
  (function (n) {
    return _(n) && n.length === h && x(n, A) < 0;
  })(n) || c(r);
}
function O(n) {
  (function (n) {
    return _(n) && n.length === p;
  })(n) || c(e);
}
function C(n) {
  (function (n) {
    return void 0 === n || _(n) && n.length === P;
  })(n) || c(u);
}
function k(n) {
  (function (n) {
    return _(n) && 64 === n.length && x(n.subarray(0, 32), A) < 0 && x(n.subarray(32, 64), A) < 0;
  })(n) || c(o);
}
function B(n) {
  (function (n) {
    return _(n) && 64 === n.length && x(n.subarray(0, 32), S) < 0;
  })(n) || c(a);
}
let F, L, R, Y, K, X, z, D, H, M, j, G, V, W, $, q, J, Q, Z, nn;
const tn = (0,_index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_0__.a)(n => {
  F = n, L = new Uint8Array(F.memory.buffer), R = F.PRIVATE_INPUT.value, Y = F.PUBLIC_KEY_INPUT.value, K = F.PUBLIC_KEY_INPUT2.value, X = F.X_ONLY_PUBLIC_KEY_INPUT.value, z = F.X_ONLY_PUBLIC_KEY_INPUT2.value, D = F.TWEAK_INPUT.value, H = F.HASH_INPUT.value, M = F.EXTRA_DATA_INPUT.value, j = F.SIGNATURE_INPUT.value, G = L.subarray(R, R + y), V = L.subarray(Y, Y + g), W = L.subarray(K, K + g), $ = L.subarray(X, X + v), q = L.subarray(z, z + v), J = L.subarray(D, D + h), Q = L.subarray(H, H + p), Z = L.subarray(M, M + P), nn = L.subarray(j, j + 64);
});
function ln(n, t) {
  return void 0 === n ? void 0 !== t ? t.length : d : n ? d : g;
}
function rn(n) {
  try {
    return V.set(n), 1 === F.isPoint(n.length);
  } finally {
    V.fill(0);
  }
}
function en(n) {
  return E(n) && rn(n);
}
function on(n, t) {
  m(n);
  const i = ln(t, n);
  try {
    return V.set(n), F.pointCompress(n.length, i), V.slice(0, i);
  } finally {
    V.fill(0);
  }
}
var un = Object.freeze({
  __proto__: null,
  __initializeContext: function () {
    F.initializeContext();
  },
  init: tn,
  isPoint: function (n) {
    return function (n) {
      return _(n) && (n.length === d || n.length === g);
    }(n) && rn(n);
  },
  isPointCompressed: function (n) {
    return function (n) {
      return _(n) && n.length === d;
    }(n) && rn(n);
  },
  isPrivate: function (n) {
    return U(n);
  },
  isXOnlyPoint: en,
  pointAdd: function (n, t, i) {
    m(n), m(t);
    const l = ln(i, n);
    try {
      return V.set(n), W.set(t), 1 === F.pointAdd(n.length, t.length, l) ? V.slice(0, l) : null;
    } finally {
      V.fill(0), W.fill(0);
    }
  },
  pointAddScalar: function (n, t, i) {
    m(n), N(t);
    const l = ln(i, n);
    try {
      return V.set(n), J.set(t), 1 === F.pointAddScalar(n.length, l) ? V.slice(0, l) : null;
    } finally {
      V.fill(0), J.fill(0);
    }
  },
  pointCompress: on,
  pointFromScalar: function (n, t) {
    I(n);
    const i = ln(t);
    try {
      return G.set(n), 1 === F.pointFromScalar(i) ? V.slice(0, i) : null;
    } finally {
      G.fill(0), V.fill(0);
    }
  },
  pointMultiply: function (n, t, i) {
    m(n), N(t);
    const l = ln(i, n);
    try {
      return V.set(n), J.set(t), 1 === F.pointMultiply(n.length, l) ? V.slice(0, l) : null;
    } finally {
      V.fill(0), J.fill(0);
    }
  },
  privateAdd: function (n, t) {
    I(n), N(t);
    try {
      return G.set(n), J.set(t), 1 === F.privateAdd() ? G.slice(0, y) : null;
    } finally {
      G.fill(0), J.fill(0);
    }
  },
  privateNegate: function (n) {
    I(n);
    try {
      return G.set(n), F.privateNegate(), G.slice(0, y);
    } finally {
      G.fill(0);
    }
  },
  privateSub: function (n, t) {
    if (I(n), N(t), T(t)) return new Uint8Array(n);
    try {
      return G.set(n), J.set(t), 1 === F.privateSub() ? G.slice(0, y) : null;
    } finally {
      G.fill(0), J.fill(0);
    }
  },
  recover: function (n, t, i, l = !1) {
    O(n), k(t), function (n) {
      T(n.subarray(0, 32)) && c(o), T(n.subarray(32, 64)) && c(o);
    }(t), 2 & i && B(t), (() => en(t.subarray(0, 32)))() || c(o);
    const r = ln(l);
    try {
      return Q.set(n), nn.set(t), 1 === F.recover(r, i) ? V.slice(0, r) : null;
    } finally {
      Q.fill(0), nn.fill(0), V.fill(0);
    }
  },
  sign: function (n, t, i) {
    O(n), I(t), C(i);
    try {
      return Q.set(n), G.set(t), void 0 !== i && Z.set(i), F.sign(void 0 === i ? 0 : 1), nn.slice(0, 64);
    } finally {
      Q.fill(0), G.fill(0), void 0 !== i && Z.fill(0), nn.fill(0);
    }
  },
  signRecoverable: function (n, t, i) {
    O(n), I(t), C(i);
    try {
      Q.set(n), G.set(t), void 0 !== i && Z.set(i);
      const l = F.signRecoverable(void 0 === i ? 0 : 1);
      return {
        signature: nn.slice(0, 64),
        recoveryId: l
      };
    } finally {
      Q.fill(0), G.fill(0), void 0 !== i && Z.fill(0), nn.fill(0);
    }
  },
  signSchnorr: function (n, t, i) {
    O(n), I(t), C(i);
    try {
      return Q.set(n), G.set(t), void 0 !== i && Z.set(i), F.signSchnorr(void 0 === i ? 0 : 1), nn.slice(0, 64);
    } finally {
      Q.fill(0), G.fill(0), void 0 !== i && Z.fill(0), nn.fill(0);
    }
  },
  verify: function (n, t, i, l = !1) {
    O(n), m(t), k(i);
    try {
      return Q.set(n), V.set(t), nn.set(i), 1 === F.verify(t.length, !0 === l ? 1 : 0);
    } finally {
      Q.fill(0), V.fill(0), nn.fill(0);
    }
  },
  verifySchnorr: function (n, t, i) {
    O(n), w(t), k(i);
    try {
      return Q.set(n), $.set(t), nn.set(i), 1 === F.verifySchnorr();
    } finally {
      Q.fill(0), $.fill(0), nn.fill(0);
    }
  },
  xOnlyPointAddTweak: function (n, t) {
    w(n), N(t);
    try {
      $.set(n), J.set(t);
      const i = F.xOnlyPointAddTweak();
      return -1 !== i ? {
        parity: i,
        xOnlyPubkey: $.slice(0, v)
      } : null;
    } finally {
      $.fill(0), J.fill(0);
    }
  },
  xOnlyPointAddTweakCheck: function (n, i, l, r) {
    w(n), w(l), N(i);
    const e = void 0 !== r;
    var o;
    e && 0 !== (o = r) && 1 !== o && c(f);
    try {
      if ($.set(n), q.set(l), J.set(i), e) return 1 === F.xOnlyPointAddTweakCheck(r);
      {
        F.xOnlyPointAddTweak();
        const n = $.slice(0, v);
        return 0 === t(n, l);
      }
    } finally {
      $.fill(0), q.fill(0), J.fill(0);
    }
  },
  xOnlyPointFromPoint: function (n) {
    m(n);
    try {
      return V.set(n), F.xOnlyPointFromPoint(n.length), $.slice(0, v);
    } finally {
      V.fill(0), $.fill(0);
    }
  },
  xOnlyPointFromScalar: function (n) {
    I(n);
    try {
      return G.set(n), F.xOnlyPointFromScalar(), $.slice(0, v);
    } finally {
      G.fill(0), $.fill(0);
    }
  }
});


/***/ }),

/***/ 76536:
/*!***************************************************************!*\
  !*** ./apps/wallet/src/assets/wallet-util/index-c6d6a521.mjs ***!
  \***************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   d: () => (/* binding */ n),
/* harmony export */   e: () => (/* binding */ o)
/* harmony export */ });
/* harmony import */ var _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./index-766bdb76.mjs */ 59809);
/* harmony import */ var _index_f363275a_mjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./index-f363275a.mjs */ 89279);


function n(r, n) {
  return function (r, e) {
    if (void 0 !== e && r[0] !== e) throw new Error("Invalid network version");
    if (33 === r.length) return {
      version: r[0],
      privateKey: r.slice(1, 33),
      compressed: !1
    };
    if (34 !== r.length) throw new Error("Invalid WIF length");
    if (1 !== r[33]) throw new Error("Invalid compression flag");
    return {
      version: r[0],
      privateKey: r.slice(1, 33),
      compressed: !0
    };
  }(_index_f363275a_mjs__WEBPACK_IMPORTED_MODULE_1__.b.decode(r), n);
}
function o(n, o, i) {
  return _index_f363275a_mjs__WEBPACK_IMPORTED_MODULE_1__.b.encode(function (e, n, o) {
    var i = _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_0__.B.alloc(o ? 34 : 33);
    return i.writeUInt8(e, 0), n.copy(i, 1), o && (i[33] = 1), i;
  }(n, o, i));
}


/***/ }),

/***/ 92914:
/*!****************************************************************!*\
  !*** ./apps/wallet/src/assets/wallet-util/keccak-25c53245.mjs ***!
  \****************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   a: () => (/* binding */ t),
/* harmony export */   c: () => (/* binding */ i),
/* harmony export */   k: () => (/* binding */ s)
/* harmony export */ });
/* harmony import */ var D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 52542);
/* harmony import */ var _sha3_c4157b55_mjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./sha3-c4157b55.mjs */ 59746);


const s = /*#__PURE__*/function () {
    var _ref = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (_s, t = 512) {
      return (yield (0,_sha3_c4157b55_mjs__WEBPACK_IMPORTED_MODULE_1__.g)(t)()).calculate(_s, t, 1);
    });
    return function s(_x) {
      return _ref.apply(this, arguments);
    };
  }(),
  t = /*#__PURE__*/function () {
    var _ref2 = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (s = 512) {
      return i(s, yield (0,_sha3_c4157b55_mjs__WEBPACK_IMPORTED_MODULE_1__.g)(s)());
    });
    return function t() {
      return _ref2.apply(this, arguments);
    };
  }(),
  i = (s = 512, t = (0,_sha3_c4157b55_mjs__WEBPACK_IMPORTED_MODULE_1__.g)(s).wasm) => {
    const i = s / 8;
    t.init(s);
    const e = {
      init: () => (t.init(s), e),
      update: a => (t.update(a), e),
      digest: a => t.digest(a, 1),
      save: () => t.save(),
      load: a => (t.load(a), e),
      blockSize: 200 - 2 * i,
      digestSize: i
    };
    return e;
  };


/***/ }),

/***/ 73721:
/*!**************************************************************!*\
  !*** ./apps/wallet/src/assets/wallet-util/p2pk-9b07c6f0.mjs ***!
  \**************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   a: () => (/* binding */ b),
/* harmony export */   p: () => (/* binding */ f)
/* harmony export */ });
/* harmony import */ var _networks_0de0aba6_mjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./networks-0de0aba6.mjs */ 15108);
/* harmony import */ var _script_28a5953a_mjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./script-28a5953a.mjs */ 25453);
/* harmony import */ var _address_a3a74797_mjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./address-a3a74797.mjs */ 75036);
/* harmony import */ var _typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./typeforce-9b266dd0.mjs */ 26139);
/* harmony import */ var _ops_47b8fd99_mjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./ops-47b8fd99.mjs */ 62510);





const a = _ops_47b8fd99_mjs__WEBPACK_IMPORTED_MODULE_4__.OPS,
  m = a.OP_RESERVED;
function y(t, e) {
  return t.length === e.length && t.every((t, r) => t.equals(e[r]));
}
function f(s, p) {
  if (!(s.input || s.output || s.pubkeys && void 0 !== s.m || s.signatures)) throw new TypeError("Not enough data");
  function f(t) {
    return (0,_script_28a5953a_mjs__WEBPACK_IMPORTED_MODULE_1__.i)(t) || void 0 !== (p.allowIncomplete && t === a.OP_0);
  }
  p = Object.assign({
    validate: !0
  }, p || {}), (0,_typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_3__.t)({
    network: _typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_3__.t.maybe(_typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_3__.t.Object),
    m: _typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_3__.t.maybe(_typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_3__.t.Number),
    n: _typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_3__.t.maybe(_typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_3__.t.Number),
    output: _typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_3__.t.maybe(_typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_3__.t.Buffer),
    pubkeys: _typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_3__.t.maybe(_typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_3__.t.arrayOf(_script_28a5953a_mjs__WEBPACK_IMPORTED_MODULE_1__.f)),
    signatures: _typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_3__.t.maybe(_typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_3__.t.arrayOf(f)),
    input: _typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_3__.t.maybe(_typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_3__.t.Buffer)
  }, s);
  const w = {
    network: s.network || _networks_0de0aba6_mjs__WEBPACK_IMPORTED_MODULE_0__.b
  };
  let b = [],
    h = !1;
  function g(t) {
    h || (h = !0, b = (0,_script_28a5953a_mjs__WEBPACK_IMPORTED_MODULE_1__.d)(t), w.m = b[0] - m, w.n = b[b.length - 2] - m, w.pubkeys = b.slice(1, -2));
  }
  if ((0,_address_a3a74797_mjs__WEBPACK_IMPORTED_MODULE_2__.p)(w, "output", () => {
    if (s.m && w.n && s.pubkeys) return (0,_script_28a5953a_mjs__WEBPACK_IMPORTED_MODULE_1__.c)([].concat(m + s.m, s.pubkeys, m + w.n, a.OP_CHECKMULTISIG));
  }), (0,_address_a3a74797_mjs__WEBPACK_IMPORTED_MODULE_2__.p)(w, "m", () => {
    if (w.output) return g(w.output), w.m;
  }), (0,_address_a3a74797_mjs__WEBPACK_IMPORTED_MODULE_2__.p)(w, "n", () => {
    if (w.pubkeys) return w.pubkeys.length;
  }), (0,_address_a3a74797_mjs__WEBPACK_IMPORTED_MODULE_2__.p)(w, "pubkeys", () => {
    if (s.output) return g(s.output), w.pubkeys;
  }), (0,_address_a3a74797_mjs__WEBPACK_IMPORTED_MODULE_2__.p)(w, "signatures", () => {
    if (s.input) return (0,_script_28a5953a_mjs__WEBPACK_IMPORTED_MODULE_1__.d)(s.input).slice(1);
  }), (0,_address_a3a74797_mjs__WEBPACK_IMPORTED_MODULE_2__.p)(w, "input", () => {
    if (s.signatures) return (0,_script_28a5953a_mjs__WEBPACK_IMPORTED_MODULE_1__.c)([a.OP_0].concat(s.signatures));
  }), (0,_address_a3a74797_mjs__WEBPACK_IMPORTED_MODULE_2__.p)(w, "witness", () => {
    if (w.input) return [];
  }), (0,_address_a3a74797_mjs__WEBPACK_IMPORTED_MODULE_2__.p)(w, "name", () => {
    if (w.m && w.n) return `p2ms(${w.m} of ${w.n})`;
  }), p.validate) {
    if (s.output) {
      if (g(s.output), !_typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_3__.t.Number(b[0])) throw new TypeError("Output is invalid");
      if (!_typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_3__.t.Number(b[b.length - 2])) throw new TypeError("Output is invalid");
      if (b[b.length - 1] !== a.OP_CHECKMULTISIG) throw new TypeError("Output is invalid");
      if (w.m <= 0 || w.n > 16 || w.m > w.n || w.n !== b.length - 3) throw new TypeError("Output is invalid");
      if (!w.pubkeys.every(t => (0,_script_28a5953a_mjs__WEBPACK_IMPORTED_MODULE_1__.f)(t))) throw new TypeError("Output is invalid");
      if (void 0 !== s.m && s.m !== w.m) throw new TypeError("m mismatch");
      if (void 0 !== s.n && s.n !== w.n) throw new TypeError("n mismatch");
      if (s.pubkeys && !y(s.pubkeys, w.pubkeys)) throw new TypeError("Pubkeys mismatch");
    }
    if (s.pubkeys) {
      if (void 0 !== s.n && s.n !== s.pubkeys.length) throw new TypeError("Pubkey count mismatch");
      if (w.n = s.pubkeys.length, w.n < w.m) throw new TypeError("Pubkey count cannot be less than m");
    }
    if (s.signatures) {
      if (s.signatures.length < w.m) throw new TypeError("Not enough signatures provided");
      if (s.signatures.length > w.m) throw new TypeError("Too many signatures provided");
    }
    if (s.input) {
      if (s.input[0] !== a.OP_0) throw new TypeError("Input is invalid");
      if (0 === w.signatures.length || !w.signatures.every(f)) throw new TypeError("Input has invalid signature(s)");
      if (s.signatures && !y(s.signatures, w.signatures)) throw new TypeError("Signature mismatch");
      if (void 0 !== s.m && s.m !== s.signatures.length) throw new TypeError("Signature count mismatch");
    }
  }
  return Object.assign(w, s);
}
const w = _ops_47b8fd99_mjs__WEBPACK_IMPORTED_MODULE_4__.OPS;
function b(p, a) {
  if (!(p.input || p.output || p.pubkey || p.input || p.signature)) throw new TypeError("Not enough data");
  a = Object.assign({
    validate: !0
  }, a || {}), (0,_typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_3__.t)({
    network: _typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_3__.t.maybe(_typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_3__.t.Object),
    output: _typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_3__.t.maybe(_typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_3__.t.Buffer),
    pubkey: _typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_3__.t.maybe(_script_28a5953a_mjs__WEBPACK_IMPORTED_MODULE_1__.f),
    signature: _typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_3__.t.maybe(_script_28a5953a_mjs__WEBPACK_IMPORTED_MODULE_1__.i),
    input: _typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_3__.t.maybe(_typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_3__.t.Buffer)
  }, p);
  const m = (0,_address_a3a74797_mjs__WEBPACK_IMPORTED_MODULE_2__.g)(() => (0,_script_28a5953a_mjs__WEBPACK_IMPORTED_MODULE_1__.d)(p.input)),
    y = {
      name: "p2pk",
      network: p.network || _networks_0de0aba6_mjs__WEBPACK_IMPORTED_MODULE_0__.b
    };
  if ((0,_address_a3a74797_mjs__WEBPACK_IMPORTED_MODULE_2__.p)(y, "output", () => {
    if (p.pubkey) return (0,_script_28a5953a_mjs__WEBPACK_IMPORTED_MODULE_1__.c)([p.pubkey, w.OP_CHECKSIG]);
  }), (0,_address_a3a74797_mjs__WEBPACK_IMPORTED_MODULE_2__.p)(y, "pubkey", () => {
    if (p.output) return p.output.slice(1, -1);
  }), (0,_address_a3a74797_mjs__WEBPACK_IMPORTED_MODULE_2__.p)(y, "signature", () => {
    if (p.input) return m()[0];
  }), (0,_address_a3a74797_mjs__WEBPACK_IMPORTED_MODULE_2__.p)(y, "input", () => {
    if (p.signature) return (0,_script_28a5953a_mjs__WEBPACK_IMPORTED_MODULE_1__.c)([p.signature]);
  }), (0,_address_a3a74797_mjs__WEBPACK_IMPORTED_MODULE_2__.p)(y, "witness", () => {
    if (y.input) return [];
  }), a.validate) {
    if (p.output) {
      if (p.output[p.output.length - 1] !== w.OP_CHECKSIG) throw new TypeError("Output is invalid");
      if (!(0,_script_28a5953a_mjs__WEBPACK_IMPORTED_MODULE_1__.f)(y.pubkey)) throw new TypeError("Output pubkey is invalid");
      if (p.pubkey && !p.pubkey.equals(y.pubkey)) throw new TypeError("Pubkey mismatch");
    }
    if (p.signature && p.input && !p.input.equals(y.input)) throw new TypeError("Signature mismatch");
    if (p.input) {
      if (1 !== m().length) throw new TypeError("Input is invalid");
      if (!(0,_script_28a5953a_mjs__WEBPACK_IMPORTED_MODULE_1__.i)(y.signature)) throw new TypeError("Input has invalid signature");
    }
  }
  return Object.assign(y, p);
}


/***/ }),

/***/ 44615:
/*!****************************************************************!*\
  !*** ./apps/wallet/src/assets/wallet-util/pbkdf2-96cac7bc.mjs ***!
  \****************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   a: () => (/* binding */ n),
/* harmony export */   p: () => (/* binding */ i)
/* harmony export */ });
/* harmony import */ var D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 52542);
/* harmony import */ var _hmac_68b6dab4_mjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./hmac-68b6dab4.mjs */ 84816);
/* harmony import */ var _WASMInterface_b9f2203b_mjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./WASMInterface-b9f2203b.mjs */ 43670);



const n = /*#__PURE__*/function () {
    var _ref = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (t) {
      const e = yield t.hashFunction;
      if (!e) throw new Error('Invalid hash function is provided! Usage: pbkdf2("password", "salt", 1000, 32, createSHA1()).');
      return i({
        ...t,
        hashFunction: e
      });
    });
    return function n(_x) {
      return _ref.apply(this, arguments);
    };
  }(),
  i = n => {
    if (!n.hashFunction) throw new Error('Invalid hash function is provided! Usage: pbkdf2Sync("password", "salt", 1000, 32, createSHA1Sync()).');
    (t => {
      if (!t || "object" != typeof t) throw new Error("Invalid options parameter. It requires an object.");
      if (!Number.isInteger(t.iterations) || t.iterations < 1) throw new Error("Iterations should be a positive number");
      if (!Number.isInteger(t.hashLength) || t.hashLength < 1) throw new Error("Hash length should be a positive number");
      if (void 0 === t.outputType && (t.outputType = "binary"), !["hex", "binary"].includes(t.outputType)) throw new Error(`Insupported output type ${t.outputType}. Valid values: ['hex', 'binary']`);
    })(n);
    return function (t, n, i, a, s) {
      const o = new Uint8Array(a),
        h = new Uint8Array(n.length + 4),
        u = new DataView(h.buffer),
        p = (0,_WASMInterface_b9f2203b_mjs__WEBPACK_IMPORTED_MODULE_2__.g)(n),
        c = new Uint8Array(p.buffer, p.byteOffset, p.length);
      h.set(c);
      let f = 0;
      const d = t.digestSize,
        l = Math.ceil(a / d);
      let w, y;
      for (let e = 1; e <= l; e++) {
        u.setUint32(n.length, e), t.init(), t.update(h), w = t.digest("binary"), y = w.slice();
        for (let e = 1; e < i; e++) {
          t.init(), t.update(y), y = t.digest("binary");
          for (let t = 0; t < d; t++) w[t] ^= y[t];
        }
        o.set(w.subarray(0, a - f), f), f += d;
      }
      if ("hex" === s) {
        const t = new Uint8Array(2 * a);
        return (0,_WASMInterface_b9f2203b_mjs__WEBPACK_IMPORTED_MODULE_2__.b)(t, o, a);
      }
      return o;
    }((0,_hmac_68b6dab4_mjs__WEBPACK_IMPORTED_MODULE_1__.c)(n.hashFunction, n.password), n.salt, n.iterations, n.hashLength, n.outputType);
  };


/***/ }),

/***/ 59746:
/*!**************************************************************!*\
  !*** ./apps/wallet/src/assets/wallet-util/sha3-c4157b55.mjs ***!
  \**************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   a: () => (/* binding */ n),
/* harmony export */   c: () => (/* binding */ i),
/* harmony export */   g: () => (/* binding */ s),
/* harmony export */   s: () => (/* binding */ e)
/* harmony export */ });
/* harmony import */ var D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 52542);
/* harmony import */ var _WASMInterface_b9f2203b_mjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./WASMInterface-b9f2203b.mjs */ 43670);


const t = {
  224: (0,_WASMInterface_b9f2203b_mjs__WEBPACK_IMPORTED_MODULE_1__.c)("sha3", 28),
  256: (0,_WASMInterface_b9f2203b_mjs__WEBPACK_IMPORTED_MODULE_1__.c)("sha3", 32),
  384: (0,_WASMInterface_b9f2203b_mjs__WEBPACK_IMPORTED_MODULE_1__.c)("sha3", 48),
  512: (0,_WASMInterface_b9f2203b_mjs__WEBPACK_IMPORTED_MODULE_1__.c)("sha3", 64)
};
Object.setPrototypeOf(t, null);
const s = a => {
    if (a in t == !1) throw new Error(`Invalid variant! Valid values: ${Object.keys(t)}`);
    return t[a];
  },
  e = /*#__PURE__*/function () {
    var _ref = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (a, t = 512) {
      return (yield s(t)()).calculate(a, t, 6);
    });
    return function e(_x) {
      return _ref.apply(this, arguments);
    };
  }(),
  i = /*#__PURE__*/function () {
    var _ref2 = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (a = 512) {
      return n(a, yield s(a)());
    });
    return function i() {
      return _ref2.apply(this, arguments);
    };
  }(),
  n = (a = 512, t = s(a).wasm) => {
    const e = a / 8;
    t.init(a);
    const i = {
      init: () => (t.init(a), i),
      update: a => (t.update(a), i),
      digest: a => t.digest(a, 6),
      save: () => t.save(),
      load: a => (t.load(a), i),
      blockSize: 200 - 2 * e,
      digestSize: e
    };
    return i;
  };


/***/ }),

/***/ 89918:
/*!****************************************************************!*\
  !*** ./apps/wallet/src/assets/wallet-util/sha512-0b4c0803.mjs ***!
  \****************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   a: () => (/* binding */ e),
/* harmony export */   c: () => (/* binding */ i),
/* harmony export */   p: () => (/* binding */ s),
/* harmony export */   s: () => (/* binding */ t)
/* harmony export */ });
/* harmony import */ var D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 52542);
/* harmony import */ var _WASMInterface_b9f2203b_mjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./WASMInterface-b9f2203b.mjs */ 43670);


const s = (0,_WASMInterface_b9f2203b_mjs__WEBPACK_IMPORTED_MODULE_1__.c)("sha512", 64),
  t = /*#__PURE__*/function () {
    var _ref = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (a) {
      return (yield s()).calculate(a, 512);
    });
    return function t(_x) {
      return _ref.apply(this, arguments);
    };
  }(),
  e = /*#__PURE__*/function () {
    var _ref2 = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      return i(yield s());
    });
    return function e() {
      return _ref2.apply(this, arguments);
    };
  }(),
  i = (a = s.wasm) => {
    a.init(512);
    const t = {
      init: () => (a.init(512), t),
      update: s => (a.update(s), t),
      digest: s => a.digest(s),
      save: () => a.save(),
      load: s => (a.load(s), t),
      blockSize: 128,
      digestSize: 64
    };
    return t;
  };


/***/ }),

/***/ 12091:
/*!*******************************************************************!*\
  !*** ./apps/wallet/src/assets/wallet-util/wordlists-b107198c.mjs ***!
  \*******************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ALL_LANGUAGE: () => (/* binding */ e),
/* harmony export */   getDefaultWordlist: () => (/* binding */ r),
/* harmony export */   getWordList: () => (/* binding */ t),
/* harmony export */   setDefaultWordlist: () => (/* binding */ s)
/* harmony export */ });
/* harmony import */ var D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 52542);

const e = ["english", "japanese", "chinese_simplified", "chinese_traditional", "czech", "french", "italian", "korean", "portuguese", "spanish"],
  t = /*#__PURE__*/function () {
    var _ref = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (e) {
      switch (e) {
        case "chinese_simplified":
          return (yield __webpack_require__.e(/*! import() */ "apps_wallet_src_assets_wallet-util_wordlists_chinese_simplified_mjs").then(__webpack_require__.bind(__webpack_require__, /*! ./wordlists/chinese_simplified.mjs */ 5604))).default;
        case "chinese_traditional":
          return (yield __webpack_require__.e(/*! import() */ "apps_wallet_src_assets_wallet-util_wordlists_chinese_traditional_mjs").then(__webpack_require__.bind(__webpack_require__, /*! ./wordlists/chinese_traditional.mjs */ 6296))).default;
        case "czech":
          return (yield __webpack_require__.e(/*! import() */ "apps_wallet_src_assets_wallet-util_wordlists_czech_mjs").then(__webpack_require__.bind(__webpack_require__, /*! ./wordlists/czech.mjs */ 65181))).default;
        case "english":
          return (yield __webpack_require__.e(/*! import() */ "apps_wallet_src_assets_wallet-util_wordlists_english_mjs").then(__webpack_require__.bind(__webpack_require__, /*! ./wordlists/english.mjs */ 52003))).default;
        case "french":
          return (yield __webpack_require__.e(/*! import() */ "apps_wallet_src_assets_wallet-util_wordlists_french_mjs").then(__webpack_require__.bind(__webpack_require__, /*! ./wordlists/french.mjs */ 71962))).default;
        case "italian":
          return (yield __webpack_require__.e(/*! import() */ "apps_wallet_src_assets_wallet-util_wordlists_italian_mjs").then(__webpack_require__.bind(__webpack_require__, /*! ./wordlists/italian.mjs */ 37309))).default;
        case "japanese":
          return (yield __webpack_require__.e(/*! import() */ "apps_wallet_src_assets_wallet-util_wordlists_japanese_mjs").then(__webpack_require__.bind(__webpack_require__, /*! ./wordlists/japanese.mjs */ 51990))).default;
        case "korean":
          return (yield __webpack_require__.e(/*! import() */ "apps_wallet_src_assets_wallet-util_wordlists_korean_mjs").then(__webpack_require__.bind(__webpack_require__, /*! ./wordlists/korean.mjs */ 73770))).default;
        case "portuguese":
          return (yield __webpack_require__.e(/*! import() */ "apps_wallet_src_assets_wallet-util_wordlists_portuguese_mjs").then(__webpack_require__.bind(__webpack_require__, /*! ./wordlists/portuguese.mjs */ 64630))).default;
        case "spanish":
          return (yield __webpack_require__.e(/*! import() */ "apps_wallet_src_assets_wallet-util_wordlists_spanish_mjs").then(__webpack_require__.bind(__webpack_require__, /*! ./wordlists/spanish.mjs */ 81001))).default;
      }
      throw new Error(`unsupport language: ${e}`);
    });
    return function t(_x) {
      return _ref.apply(this, arguments);
    };
  }(),
  a = new Map();
let i;
function s(e, t) {
  if (void 0 === t && (t = a.get(e)), void 0 === t) throw new Error(`need load wordList first, call \`await getWordList('${e}')\`.`);
  i = {
    language: e,
    wordlist: t
  };
}
function r() {
  return i;
}


/***/ })

}]);
//# sourceMappingURL=common.js.map