"use strict";
(self["webpackChunkwallet"] = self["webpackChunkwallet"] || []).push([["default-apps_wallet_src_assets_wallet-util_script-28a5953a_mjs"],{

/***/ 62510:
/*!*************************************************************!*\
  !*** ./apps/wallet/src/assets/wallet-util/ops-47b8fd99.mjs ***!
  \*************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   OPS: () => (/* binding */ O),
/* harmony export */   REVERSE_OPS: () => (/* binding */ P)
/* harmony export */ });
const O = {
    OP_FALSE: 0,
    OP_0: 0,
    OP_PUSHDATA1: 76,
    OP_PUSHDATA2: 77,
    OP_PUSHDATA4: 78,
    OP_1NEGATE: 79,
    OP_RESERVED: 80,
    OP_TRUE: 81,
    OP_1: 81,
    OP_2: 82,
    OP_3: 83,
    OP_4: 84,
    OP_5: 85,
    OP_6: 86,
    OP_7: 87,
    OP_8: 88,
    OP_9: 89,
    OP_10: 90,
    OP_11: 91,
    OP_12: 92,
    OP_13: 93,
    OP_14: 94,
    OP_15: 95,
    OP_16: 96,
    OP_NOP: 97,
    OP_VER: 98,
    OP_IF: 99,
    OP_NOTIF: 100,
    OP_VERIF: 101,
    OP_VERNOTIF: 102,
    OP_ELSE: 103,
    OP_ENDIF: 104,
    OP_VERIFY: 105,
    OP_RETURN: 106,
    OP_TOALTSTACK: 107,
    OP_FROMALTSTACK: 108,
    OP_2DROP: 109,
    OP_2DUP: 110,
    OP_3DUP: 111,
    OP_2OVER: 112,
    OP_2ROT: 113,
    OP_2SWAP: 114,
    OP_IFDUP: 115,
    OP_DEPTH: 116,
    OP_DROP: 117,
    OP_DUP: 118,
    OP_NIP: 119,
    OP_OVER: 120,
    OP_PICK: 121,
    OP_ROLL: 122,
    OP_ROT: 123,
    OP_SWAP: 124,
    OP_TUCK: 125,
    OP_CAT: 126,
    OP_SUBSTR: 127,
    OP_LEFT: 128,
    OP_RIGHT: 129,
    OP_SIZE: 130,
    OP_INVERT: 131,
    OP_AND: 132,
    OP_OR: 133,
    OP_XOR: 134,
    OP_EQUAL: 135,
    OP_EQUALVERIFY: 136,
    OP_RESERVED1: 137,
    OP_RESERVED2: 138,
    OP_1ADD: 139,
    OP_1SUB: 140,
    OP_2MUL: 141,
    OP_2DIV: 142,
    OP_NEGATE: 143,
    OP_ABS: 144,
    OP_NOT: 145,
    OP_0NOTEQUAL: 146,
    OP_ADD: 147,
    OP_SUB: 148,
    OP_MUL: 149,
    OP_DIV: 150,
    OP_MOD: 151,
    OP_LSHIFT: 152,
    OP_RSHIFT: 153,
    OP_BOOLAND: 154,
    OP_BOOLOR: 155,
    OP_NUMEQUAL: 156,
    OP_NUMEQUALVERIFY: 157,
    OP_NUMNOTEQUAL: 158,
    OP_LESSTHAN: 159,
    OP_GREATERTHAN: 160,
    OP_LESSTHANOREQUAL: 161,
    OP_GREATERTHANOREQUAL: 162,
    OP_MIN: 163,
    OP_MAX: 164,
    OP_WITHIN: 165,
    OP_RIPEMD160: 166,
    OP_SHA1: 167,
    OP_SHA256: 168,
    OP_HASH160: 169,
    OP_HASH256: 170,
    OP_CODESEPARATOR: 171,
    OP_CHECKSIG: 172,
    OP_CHECKSIGVERIFY: 173,
    OP_CHECKMULTISIG: 174,
    OP_CHECKMULTISIGVERIFY: 175,
    OP_NOP1: 176,
    OP_NOP2: 177,
    OP_CHECKLOCKTIMEVERIFY: 177,
    OP_NOP3: 178,
    OP_CHECKSEQUENCEVERIFY: 178,
    OP_NOP4: 179,
    OP_NOP5: 180,
    OP_NOP6: 181,
    OP_NOP7: 182,
    OP_NOP8: 183,
    OP_NOP9: 184,
    OP_NOP10: 185,
    OP_PUBKEYHASH: 253,
    OP_PUBKEY: 254,
    OP_INVALIDOPCODE: 255
  },
  P = {};
for (const _ of Object.keys(O)) {
  P[O[_]] = _;
}


/***/ }),

/***/ 25453:
/*!****************************************************************!*\
  !*** ./apps/wallet/src/assets/wallet-util/script-28a5953a.mjs ***!
  \****************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   B: () => (/* binding */ A),
/* harmony export */   H: () => (/* binding */ I),
/* harmony export */   N: () => (/* binding */ z),
/* harmony export */   S: () => (/* binding */ p),
/* harmony export */   T: () => (/* binding */ U),
/* harmony export */   U: () => (/* binding */ D),
/* harmony export */   a: () => (/* binding */ L),
/* harmony export */   b: () => (/* binding */ S),
/* harmony export */   c: () => (/* binding */ Z),
/* harmony export */   d: () => (/* binding */ ee),
/* harmony export */   e: () => (/* binding */ te),
/* harmony export */   f: () => (/* binding */ h),
/* harmony export */   g: () => (/* binding */ Q),
/* harmony export */   h: () => (/* binding */ re),
/* harmony export */   i: () => (/* binding */ ie),
/* harmony export */   j: () => (/* binding */ v),
/* harmony export */   k: () => (/* binding */ m),
/* harmony export */   l: () => (/* binding */ a),
/* harmony export */   m: () => (/* binding */ B),
/* harmony export */   n: () => (/* binding */ P),
/* harmony export */   o: () => (/* binding */ x),
/* harmony export */   p: () => (/* binding */ ne),
/* harmony export */   q: () => (/* binding */ se),
/* harmony export */   s: () => (/* binding */ ue),
/* harmony export */   t: () => (/* binding */ N)
/* harmony export */ });
/* harmony import */ var _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./index-766bdb76.mjs */ 59809);
/* harmony import */ var _ops_47b8fd99_mjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./ops-47b8fd99.mjs */ 62510);
/* harmony import */ var _typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./typeforce-9b266dd0.mjs */ 26139);



function o(n, r) {
  const t = n.length,
    o = r.length;
  if (0 === t) throw new Error("R length is zero");
  if (0 === o) throw new Error("S length is zero");
  if (t > 33) throw new Error("R length is too long");
  if (o > 33) throw new Error("S length is too long");
  if (128 & n[0]) throw new Error("R value is negative");
  if (128 & r[0]) throw new Error("S value is negative");
  if (t > 1 && 0 === n[0] && !(128 & n[1])) throw new Error("R value excessively padded");
  if (o > 1 && 0 === r[0] && !(128 & r[1])) throw new Error("S value excessively padded");
  const i = _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_0__.B.allocUnsafe(6 + t + o);
  return i[0] = 48, i[1] = i.length - 2, i[2] = 2, i[3] = n.length, n.copy(i, 4), i[4 + t] = 2, i[5 + t] = r.length, r.copy(i, 6 + t), i;
}
function i(e) {
  return e < _ops_47b8fd99_mjs__WEBPACK_IMPORTED_MODULE_1__.OPS.OP_PUSHDATA1 ? 1 : e <= 255 ? 2 : e <= 65535 ? 3 : 5;
}
function f(e, r) {
  const t = e.readUInt8(r);
  let o, i;
  if (t < _ops_47b8fd99_mjs__WEBPACK_IMPORTED_MODULE_1__.OPS.OP_PUSHDATA1) o = t, i = 1;else if (t === _ops_47b8fd99_mjs__WEBPACK_IMPORTED_MODULE_1__.OPS.OP_PUSHDATA1) {
    if (r + 2 > e.length) return null;
    o = e.readUInt8(r + 1), i = 2;
  } else if (t === _ops_47b8fd99_mjs__WEBPACK_IMPORTED_MODULE_1__.OPS.OP_PUSHDATA2) {
    if (r + 3 > e.length) return null;
    o = e.readUInt16LE(r + 1), i = 3;
  } else {
    if (r + 5 > e.length) return null;
    if (t !== _ops_47b8fd99_mjs__WEBPACK_IMPORTED_MODULE_1__.OPS.OP_PUSHDATA4) throw new Error("Unexpected opcode");
    o = e.readUInt32LE(r + 1), i = 5;
  }
  return {
    opcode: t,
    number: o,
    size: i
  };
}
function u(n) {
  let r = Math.abs(n);
  const t = (o = r) > 2147483647 ? 5 : o > 8388607 ? 4 : o > 32767 ? 3 : o > 127 ? 2 : o > 0 ? 1 : 0;
  var o;
  const i = _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_0__.B.allocUnsafe(t),
    f = n < 0;
  for (let e = 0; e < t; ++e) i.writeUInt8(255 & r, e), r >>= 8;
  return 128 & i[t - 1] ? i.writeUInt8(f ? 128 : 0, t - 1) : f && (i[t - 1] |= 128), i;
}
var s = Object.freeze({
  __proto__: null,
  decode: function (e, n, r) {
    n = n || 4, r = void 0 === r || r;
    const t = e.length;
    if (0 === t) return 0;
    if (t > n) throw new TypeError("Script number overflow");
    if (r && 0 == (127 & e[t - 1]) && (t <= 1 || 0 == (128 & e[t - 2]))) throw new Error("Non-minimally encoded script number");
    if (5 === t) {
      const n = e.readUInt32LE(0),
        r = e.readUInt8(4);
      return 128 & r ? -(4294967296 * (-129 & r) + n) : 4294967296 * r + n;
    }
    let o = 0;
    for (let n = 0; n < t; ++n) o |= e[n] << 8 * n;
    return 128 & e[t - 1] ? -(o & ~(128 << 8 * (t - 1))) : o;
  },
  encode: u
});
const l = _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_0__.B.alloc(32, 0),
  c = _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_0__.B.from("fffffffffffffffffffffffffffffffffffffffffffffffffffffffefffffc2f", "hex");
function a(e, n) {
  return e.length === n.length && e.every((e, r) => e.equals(n[r]));
}
function h(n) {
  if (!_index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_0__.B.isBuffer(n)) return !1;
  if (n.length < 33) return !1;
  const r = n[0],
    t = n.subarray(1, 33);
  if (0 === t.compare(l)) return !1;
  if (t.compare(c) >= 0) return !1;
  if ((2 === r || 3 === r) && 33 === n.length) return !0;
  const o = n.subarray(33);
  return 0 !== o.compare(l) && !(o.compare(c) >= 0) && 4 === r && 65 === n.length;
}
const g = Math.pow(2, 31) - 1;
function w(e) {
  return _typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_2__.t.String(e) && !!e.match(/^(m\/)?(\d+'?\/)*\d+'?$/);
}
w.toJSON = () => "BIP32 derivation path";
function p(e) {
  return _typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_2__.t.UInt53(e) && e <= 21e14;
}
const d = _typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_2__.t.quacksLike("Point"),
  E = _typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_2__.t.compile({
    messagePrefix: _typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_2__.t.anyOf(_typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_2__.t.Buffer, _typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_2__.t.String),
    bip32: {
      public: _typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_2__.t.UInt32,
      private: _typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_2__.t.UInt32
    },
    pubKeyHash: _typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_2__.t.UInt8,
    scriptHash: _typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_2__.t.UInt8,
    wif: _typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_2__.t.UInt8
  }),
  U = 254;
function v(n) {
  return !(!n || !("output" in n)) && !!_index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_0__.B.isBuffer(n.output) && (void 0 === n.version || (n.version & U) === n.version);
}
function m(e) {
  return _(e) ? 2 === e.length && e.every(e => m(e)) : v(e);
}
const y = _typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_2__.t.BufferN(32),
  P = _typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_2__.t.BufferN(20),
  I = _typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_2__.t.BufferN(32),
  S = _typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_2__.t.Number,
  _ = _typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_2__.t.Array,
  O = _typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_2__.t.Boolean,
  b = _typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_2__.t.String,
  A = _typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_2__.t.Buffer,
  T = _typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_2__.t.Hex,
  B = _typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_2__.t.maybe,
  N = _typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_2__.t.tuple,
  x = _typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_2__.t.UInt8,
  D = _typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_2__.t.UInt32,
  H = _typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_2__.t.Function,
  R = _typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_2__.t.BufferN,
  z = _typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_2__.t.Null,
  j = _typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_2__.t.oneOf,
  q = _typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_2__.t.Nil,
  k = _typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_2__.t.anyOf;
var L = Object.freeze({
  __proto__: null,
  Array: _,
  BIP32Path: w,
  Boolean: O,
  Buffer: A,
  Buffer256bit: y,
  BufferN: R,
  ECPoint: d,
  Function: H,
  Hash160bit: P,
  Hash256bit: I,
  Hex: T,
  Network: E,
  Nil: q,
  Null: z,
  Number: S,
  Satoshi: p,
  Signer: function (e) {
    return (_typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_2__.t.Buffer(e.publicKey) || "function" == typeof e.getPublicKey) && "function" == typeof e.sign;
  },
  String: b,
  TAPLEAF_VERSION_MASK: U,
  UInt31: function (e) {
    return _typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_2__.t.UInt32(e) && e <= g;
  },
  UInt32: D,
  UInt8: x,
  anyOf: k,
  isPoint: h,
  isTapleaf: v,
  isTaptree: m,
  maybe: B,
  oneOf: j,
  stacksEqual: a,
  tuple: N,
  typeforce: _typeforce_9b266dd0_mjs__WEBPACK_IMPORTED_MODULE_2__.t
});
const {
    typeforce: M
  } = L,
  K = _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_0__.B.alloc(1, 0);
function C(n) {
  let r = 0;
  for (; 0 === n[r];) ++r;
  return r === n.length ? K : 128 & (n = n.slice(r))[0] ? _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_0__.B.concat([K, n], 1 + n.length) : n;
}
function F(n) {
  0 === n[0] && (n = n.slice(1));
  const r = _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_0__.B.alloc(32, 0),
    t = Math.max(0, 32 - n.length);
  return n.copy(r, t), r;
}
var G = Object.freeze({
  __proto__: null,
  decode: function (n) {
    const r = n.readUInt8(n.length - 1),
      t = -129 & r;
    if (t <= 0 || t >= 4) throw new Error("Invalid hashType " + r);
    const o = function (e) {
        if (e.length < 8) throw new Error("DER sequence length is too short");
        if (e.length > 72) throw new Error("DER sequence length is too long");
        if (48 !== e[0]) throw new Error("Expected DER sequence");
        if (e[1] !== e.length - 2) throw new Error("DER sequence length is invalid");
        if (2 !== e[2]) throw new Error("Expected DER integer");
        const n = e[3];
        if (0 === n) throw new Error("R length is zero");
        if (5 + n >= e.length) throw new Error("R length is too long");
        if (2 !== e[4 + n]) throw new Error("Expected DER integer (2)");
        const r = e[5 + n];
        if (0 === r) throw new Error("S length is zero");
        if (6 + n + r !== e.length) throw new Error("S length is invalid");
        if (128 & e[4]) throw new Error("R value is negative");
        if (n > 1 && 0 === e[4] && !(128 & e[5])) throw new Error("R value excessively padded");
        if (128 & e[n + 6]) throw new Error("S value is negative");
        if (r > 1 && 0 === e[n + 6] && !(128 & e[n + 7])) throw new Error("S value excessively padded");
        return {
          r: e.slice(4, 4 + n),
          s: e.slice(6 + n)
        };
      }(n.slice(0, -1)),
      i = F(o.r),
      f = F(o.s);
    return {
      signature: _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_0__.B.concat([i, f], 64),
      hashType: r
    };
  },
  encode: function (n, r) {
    M({
      signature: R(64),
      hashType: x
    }, {
      signature: n,
      hashType: r
    });
    const t = -129 & r;
    if (t <= 0 || t >= 4) throw new Error("Invalid hashType " + r);
    const i = _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_0__.B.allocUnsafe(1);
    i.writeUInt8(r, 0);
    const f = C(n.slice(0, 32)),
      u = C(n.slice(32, 64));
    return _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_0__.B.concat([o(f, u), i]);
  }
});
const {
    typeforce: V
  } = L,
  J = _ops_47b8fd99_mjs__WEBPACK_IMPORTED_MODULE_1__.OPS.OP_RESERVED;
function $(e) {
  return A(e) || function (e) {
    return S(e) && (e === _ops_47b8fd99_mjs__WEBPACK_IMPORTED_MODULE_1__.OPS.OP_0 || e >= _ops_47b8fd99_mjs__WEBPACK_IMPORTED_MODULE_1__.OPS.OP_1 && e <= _ops_47b8fd99_mjs__WEBPACK_IMPORTED_MODULE_1__.OPS.OP_16 || e === _ops_47b8fd99_mjs__WEBPACK_IMPORTED_MODULE_1__.OPS.OP_1NEGATE);
  }(e);
}
function Q(e) {
  return _(e) && e.every($);
}
function W(e) {
  return 0 === e.length ? _ops_47b8fd99_mjs__WEBPACK_IMPORTED_MODULE_1__.OPS.OP_0 : 1 === e.length ? e[0] >= 1 && e[0] <= 16 ? J + e[0] : 129 === e[0] ? _ops_47b8fd99_mjs__WEBPACK_IMPORTED_MODULE_1__.OPS.OP_1NEGATE : void 0 : void 0;
}
function X(n) {
  return _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_0__.B.isBuffer(n);
}
function Y(n) {
  return _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_0__.B.isBuffer(n);
}
function Z(r) {
  if (X(r)) return r;
  V(_, r);
  const t = r.reduce((e, n) => Y(n) ? 1 === n.length && void 0 !== W(n) ? e + 1 : e + i(n.length) + n.length : e + 1, 0),
    o = _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_0__.B.allocUnsafe(t);
  let f = 0;
  if (r.forEach(e => {
    if (Y(e)) {
      const r = W(e);
      if (void 0 !== r) return o.writeUInt8(r, f), void (f += 1);
      f += function (e, r, t) {
        const o = i(r);
        return 1 === o ? e.writeUInt8(r, t) : 2 === o ? (e.writeUInt8(_ops_47b8fd99_mjs__WEBPACK_IMPORTED_MODULE_1__.OPS.OP_PUSHDATA1, t), e.writeUInt8(r, t + 1)) : 3 === o ? (e.writeUInt8(_ops_47b8fd99_mjs__WEBPACK_IMPORTED_MODULE_1__.OPS.OP_PUSHDATA2, t), e.writeUInt16LE(r, t + 1)) : (e.writeUInt8(_ops_47b8fd99_mjs__WEBPACK_IMPORTED_MODULE_1__.OPS.OP_PUSHDATA4, t), e.writeUInt32LE(r, t + 1)), o;
      }(o, e.length, f), e.copy(o, f), f += e.length;
    } else o.writeUInt8(e, f), f += 1;
  }), f !== o.length) throw new Error("Could not decode chunks");
  return o;
}
function ee(e) {
  if (_(e)) return e;
  V(A, e);
  const r = [];
  let t = 0;
  for (; t < e.length;) {
    const o = e[t];
    if (o > _ops_47b8fd99_mjs__WEBPACK_IMPORTED_MODULE_1__.OPS.OP_0 && o <= _ops_47b8fd99_mjs__WEBPACK_IMPORTED_MODULE_1__.OPS.OP_PUSHDATA4) {
      const n = f(e, t);
      if (null === n) return null;
      if (t += n.size, t + n.number > e.length) return null;
      const o = e.slice(t, t + n.number);
      t += n.number;
      const i = W(o);
      void 0 !== i ? r.push(i) : r.push(o);
    } else r.push(o), t += 1;
  }
  return r;
}
function ne(e) {
  return X(e) && (e = ee(e)), e.map(e => {
    if (Y(e)) {
      const n = W(e);
      if (void 0 === n) return e.toString("hex");
      e = n;
    }
    return _ops_47b8fd99_mjs__WEBPACK_IMPORTED_MODULE_1__.REVERSE_OPS[e];
  }).join(" ");
}
function re(r) {
  return r = ee(r), V(Q, r), r.map(r => Y(r) ? r : r === _ops_47b8fd99_mjs__WEBPACK_IMPORTED_MODULE_1__.OPS.OP_0 ? _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_0__.B.allocUnsafe(0) : u(r - J));
}
function te(e) {
  return h(e);
}
function oe(e) {
  const n = -129 & e;
  return n > 0 && n < 4;
}
function ie(n) {
  return !!_index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_0__.B.isBuffer(n) && !!oe(n[n.length - 1]) && function (e) {
    if (e.length < 8) return !1;
    if (e.length > 72) return !1;
    if (48 !== e[0]) return !1;
    if (e[1] !== e.length - 2) return !1;
    if (2 !== e[2]) return !1;
    const n = e[3];
    if (0 === n) return !1;
    if (5 + n >= e.length) return !1;
    if (2 !== e[4 + n]) return !1;
    const r = e[5 + n];
    return !(0 === r || 6 + n + r !== e.length || 128 & e[4] || n > 1 && 0 === e[4] && !(128 & e[5]) || 128 & e[n + 6] || r > 1 && 0 === e[n + 6] && !(128 & e[n + 7]));
  }(n.slice(0, -1));
}
const fe = s,
  ue = G;
var se = Object.freeze({
  __proto__: null,
  OPS: _ops_47b8fd99_mjs__WEBPACK_IMPORTED_MODULE_1__.OPS,
  compile: Z,
  decompile: ee,
  fromASM: function (r) {
    return V(b, r), Z(r.split(" ").map(r => void 0 !== _ops_47b8fd99_mjs__WEBPACK_IMPORTED_MODULE_1__.OPS[r] ? _ops_47b8fd99_mjs__WEBPACK_IMPORTED_MODULE_1__.OPS[r] : (V(T, r), _index_766bdb76_mjs__WEBPACK_IMPORTED_MODULE_0__.B.from(r, "hex"))));
  },
  isCanonicalPubKey: te,
  isCanonicalScriptSignature: ie,
  isDefinedHashType: oe,
  isPushOnly: Q,
  number: fe,
  signature: ue,
  toASM: ne,
  toStack: re
});


/***/ })

}]);
//# sourceMappingURL=default-apps_wallet_src_assets_wallet-util_script-28a5953a_mjs.js.map