/**任务收集器
 * ```
 * const tl = new AggregateList();
 * tl.next = sleep(1)
 * tl.next = sleep(2)
 * await tl.toPromise();
 * ```
 */
export class AggregateList {
    constructor() {
        // private _tasks = new Set<Promise<T> | T>();
        Object.defineProperty(this, "_toPromise", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "_errors", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: []
        });
        Object.defineProperty(this, "_total", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 0
        });
        Object.defineProperty(this, "_finished", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 0
        });
        this._onSuccess = this._onSuccess.bind(this);
        this._onError = this._onError.bind(this);
    }
    toPromise() {
        if (this._total === this._finished) {
            if (this._errors.length) {
                return Promise.reject(this._getError());
            }
            return Promise.resolve();
        }
        if (this._toPromise === undefined) {
            let resolve;
            let reject;
            const promise = new Promise((_resolve, _reject) => {
                resolve = _resolve;
                reject = _reject;
            });
            this._toPromise = {
                promise,
                resolve: resolve,
                reject: reject,
            };
        }
        return this._toPromise.promise;
    }
    set next(task) {
        if (task instanceof Promise || (task && task.then instanceof Function)) {
            this._total += 1;
            task.then(this._onSuccess, this._onError);
        }
    }
    _onSuccess() {
        this._finished += 1;
        if (this._total === this._finished && this._toPromise) {
            if (this._errors.length === 0) {
                this._toPromise.resolve();
            }
            else {
                this._toPromise.reject(this._getError());
            }
            this._reset();
        }
    }
    _onError(err) {
        this._finished += 1;
        this._errors.push(err);
        if (this._total === this._finished && this._toPromise) {
            this._toPromise.reject(this._getError());
            this._reset();
        }
    }
    _reset() {
        this._toPromise = undefined;
        this._errors = [];
        this._finished = 0;
        this._total = 0;
    }
    _getError() {
        const errors = Object.freeze(this._errors);
        const message = errors.length === this._total ? "All Promise rejeced" : "Some Promise rejected";
        const aggregateError = new Error(message);
        Object.defineProperty(aggregateError, "errors", {
            value: errors,
            writable: false,
        });
        aggregateError.name = "AggregateError";
        return aggregateError;
    }
}
export const wrapAggregateList = async (cb) => {
    const aggregateList = new AggregateList();
    try {
        await cb(aggregateList);
    }
    catch (err) {
        aggregateList.next = Promise.reject(err);
    }
    return aggregateList.toPromise();
};
