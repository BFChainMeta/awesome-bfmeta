import { IPC_METHOD } from "../index.js";
import { $makeExtends } from "./$makeExtends.js";
import { fetchExtends } from "./$makeFetchExtends.js";
// ipcRequest to Request
export function toRequest(ipcRequest) {
    const method = ipcRequest.method;
    let body = "";
    if (method === IPC_METHOD.GET || method === IPC_METHOD.HEAD) {
        return new Request(ipcRequest.url, {
            method,
            headers: ipcRequest.headers,
        });
    }
    if (ipcRequest.body) {
        body = ipcRequest.body;
    }
    /**
     * 这里的请求是这样的，要发给用户转发需要添加http
     * /barcode-scanning.sys.dweb/process?X-Dweb-Host=api.cotdemo.bfs.dweb%3A443&rotation=0&formats=QR_CODE
     */
    return new Request(`${ipcRequest.url}`, {
        method,
        headers: ipcRequest.headers,
        body,
    });
}
export function buildRequest(url, init) {
    const search = init?.search;
    if (search) {
        let extendsSearch;
        if (search instanceof URLSearchParams) {
            extendsSearch = search;
        }
        else if (typeof search === "string") {
            extendsSearch = new URLSearchParams(search);
        }
        else {
            extendsSearch = new URLSearchParams(Object.entries(search)
                .filter(([_, value]) => value != undefined /* null undefined 都不传输*/)
                .map(([key, value]) => {
                return [key, typeof value === "object" ? JSON.stringify(value) : String(value)];
            }));
        }
        extendsSearch.forEach((value, key) => {
            url.searchParams.append(key, value);
        });
    }
    return Object.assign(new Request(url, init), $makeExtends()({
        fetch() {
            return Object.assign(fetch(this), fetchExtends);
        },
    }));
}
