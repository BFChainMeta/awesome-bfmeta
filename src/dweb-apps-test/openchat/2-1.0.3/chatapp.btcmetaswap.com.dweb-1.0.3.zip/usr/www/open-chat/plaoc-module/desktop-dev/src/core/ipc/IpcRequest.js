import { once } from "../../helper/$once.js";
import { binaryToU8a, isBinary } from "../../helper/binaryHelper.js";
import { CacheGetter } from "../../helper/cacheGetter.js";
import { ReadableStreamOut } from "../../helper/stream/readableStreamHelper.js";
import { parseUrl } from "../../helper/urlHelper.js";
import { buildRequestX } from "../helper/ipcRequestHelper.js";
import { IpcBodySender } from "./IpcBodySender.js";
import { IpcHeaders } from "./IpcHeaders.js";
import { PureChannel } from "./PureChannel.js";
import { IPC_MESSAGE_TYPE, IPC_METHOD, IpcMessage, toIpcMethod } from "./const.js";
const PURE_CHANNEL_EVENT_PREFIX = "§";
const X_IPC_UPGRADE_KEY = "X-Dweb-Ipc-Upgrade-Key";
export class IpcRequest extends IpcMessage {
    constructor(req_id, url, method, headers, body, ipc) {
        super(IPC_MESSAGE_TYPE.REQUEST);
        Object.defineProperty(this, "req_id", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: req_id
        });
        Object.defineProperty(this, "url", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: url
        });
        Object.defineProperty(this, "method", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: method
        });
        Object.defineProperty(this, "headers", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: headers
        });
        Object.defineProperty(this, "body", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: body
        });
        Object.defineProperty(this, "ipc", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: ipc
        });
        Object.defineProperty(this, "_parsed_url", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "duplexEventBaseName", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: new CacheGetter(() => {
                let eventNameBase;
                const upgrade_key = this.headers.get(X_IPC_UPGRADE_KEY);
                if (upgrade_key?.startsWith(PURE_CHANNEL_EVENT_PREFIX)) {
                    eventNameBase = upgrade_key;
                }
                return eventNameBase;
            })
        });
        Object.defineProperty(this, "channel", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: new CacheGetter(() => {
                const channelId = this.channelId;
                const income = new ReadableStreamOut();
                const outgoing = new ReadableStreamOut();
                const channel = new PureChannel(income, outgoing);
                void this.ipc.pipeToChannel(channelId, channel);
                return channel;
            })
        });
        Object.defineProperty(this, "ipcReqMessage", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: once(() => new IpcReqMessage(this.req_id, this.method, this.url, this.headers.toJSON(), this.body.metaBody))
        });
        if (body instanceof IpcBodySender) {
            IpcBodySender.$usableByIpc(ipc, body);
        }
    }
    get parsed_url() {
        return (this._parsed_url ?? (this._parsed_url = parseUrl(this.url)));
    }
    static fromText(req_id, url, method = IPC_METHOD.GET, headers = new IpcHeaders(), text, ipc) {
        // 这里 content-length 默认不写，因为这是要算二进制的长度，我们这里只有在字符串的长度，不是一个东西
        return new IpcRequest(req_id, url, method, headers, IpcBodySender.fromText(text, ipc), ipc);
    }
    static fromBinary(req_id, url, method = IPC_METHOD.GET, headers = new IpcHeaders(), binary, ipc) {
        headers.init("Content-Type", "application/octet-stream");
        headers.init("Content-Length", binary.byteLength + "");
        return new IpcRequest(req_id, url, method, headers, IpcBodySender.fromBinary(binaryToU8a(binary), ipc), ipc);
    }
    // 如果需要发送stream数据 一定要使用这个方法才可以传递数据否则数据无法传递
    static fromStream(req_id, url, method = IPC_METHOD.GET, headers = new IpcHeaders(), stream, ipc) {
        headers.init("Content-Type", "application/octet-stream");
        return new IpcRequest(req_id, url, method, headers, IpcBodySender.fromStream(stream, ipc), ipc);
    }
    static fromRequest(req_id, ipc, url, init = {}) {
        const method = toIpcMethod(init.method);
        const headers = init.headers instanceof IpcHeaders ? init.headers : new IpcHeaders(init.headers);
        let ipcBody;
        if (isBinary(init.body)) {
            ipcBody = IpcBodySender.fromBinary(init.body, ipc);
        }
        else if (init.body instanceof ReadableStream) {
            ipcBody = IpcBodySender.fromStream(init.body, ipc);
        }
        else if (init.body instanceof Blob) {
            ipcBody = IpcBodySender.fromStream(init.body.stream(), ipc);
        }
        else {
            ipcBody = IpcBodySender.fromText(init.body ?? "", ipc);
        }
        return new IpcRequest(req_id, url, method, headers, ipcBody, ipc);
    }
    /**
     * 判断是否是双工协议
     *
     * 比如目前双工协议可以由 WebSocket 来提供支持
     */
    get hasDuplex() {
        return this.channelId !== undefined;
    }
    get channelId() {
        return this.duplexEventBaseName.value;
    }
    getChannel() {
        return this.channel.value;
    }
    toRequest() {
        return buildRequestX(this.url, { method: this.method, headers: this.headers, body: this.body.raw });
    }
    toJSON() {
        const { method } = this;
        // let body: undefined | $BodyData;
        if ((method === IPC_METHOD.GET || method === IPC_METHOD.HEAD) === false) {
            // body = this.body.raw;
            return new IpcReqMessage(this.req_id, this.method, this.url, this.headers.toJSON(), this.body.metaBody);
        }
        return this.ipcReqMessage();
    }
}
export class IpcReqMessage extends IpcMessage {
    constructor(req_id, method, url, headers, metaBody) {
        super(IPC_MESSAGE_TYPE.REQUEST);
        Object.defineProperty(this, "req_id", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: req_id
        });
        Object.defineProperty(this, "method", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: method
        });
        Object.defineProperty(this, "url", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: url
        });
        Object.defineProperty(this, "headers", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: headers
        });
        Object.defineProperty(this, "metaBody", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: metaBody
        });
    }
}
