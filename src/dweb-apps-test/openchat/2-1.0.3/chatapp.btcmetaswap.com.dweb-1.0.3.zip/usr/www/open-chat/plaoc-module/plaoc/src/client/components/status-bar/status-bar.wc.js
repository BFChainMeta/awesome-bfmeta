import { __decorate, __metadata } from "../../../../../../tslib/modules/index.js";
import { cacheGetter } from "../../helper/cacheGetter.js";
import { statusBarPlugin } from "./status-bar.plugin.js";
class HTMLDwebStatusBarElement extends HTMLElement {
    constructor() {
        super(...arguments);
        Object.defineProperty(this, "plugin", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: statusBarPlugin
        });
    }
    get setColor() {
        return statusBarPlugin.setColor;
    }
    get getColor() {
        return statusBarPlugin.getColor;
    }
    get setStyle() {
        return statusBarPlugin.setStyle;
    }
    get getStyle() {
        return statusBarPlugin.getStyle;
    }
    get show() {
        return statusBarPlugin.show;
    }
    get hide() {
        return statusBarPlugin.hide;
    }
    get setVisible() {
        return statusBarPlugin.setVisible;
    }
    get getVisible() {
        return statusBarPlugin.getVisible;
    }
    get getState() {
        return statusBarPlugin.getState;
    }
    get setOverlay() {
        return statusBarPlugin.setOverlay;
    }
    get getOverlay() {
        return statusBarPlugin.getOverlay;
    }
}
Object.defineProperty(HTMLDwebStatusBarElement, "tagName", {
    enumerable: true,
    configurable: true,
    writable: true,
    value: "dweb-status-bar"
});
__decorate([
    cacheGetter(),
    __metadata("design:type", Object),
    __metadata("design:paramtypes", [])
], HTMLDwebStatusBarElement.prototype, "setColor", null);
__decorate([
    cacheGetter(),
    __metadata("design:type", Object),
    __metadata("design:paramtypes", [])
], HTMLDwebStatusBarElement.prototype, "getColor", null);
__decorate([
    cacheGetter(),
    __metadata("design:type", Object),
    __metadata("design:paramtypes", [])
], HTMLDwebStatusBarElement.prototype, "setStyle", null);
__decorate([
    cacheGetter(),
    __metadata("design:type", Object),
    __metadata("design:paramtypes", [])
], HTMLDwebStatusBarElement.prototype, "getStyle", null);
__decorate([
    cacheGetter(),
    __metadata("design:type", Object),
    __metadata("design:paramtypes", [])
], HTMLDwebStatusBarElement.prototype, "show", null);
__decorate([
    cacheGetter(),
    __metadata("design:type", Object),
    __metadata("design:paramtypes", [])
], HTMLDwebStatusBarElement.prototype, "hide", null);
__decorate([
    cacheGetter(),
    __metadata("design:type", Object),
    __metadata("design:paramtypes", [])
], HTMLDwebStatusBarElement.prototype, "setVisible", null);
__decorate([
    cacheGetter(),
    __metadata("design:type", Object),
    __metadata("design:paramtypes", [])
], HTMLDwebStatusBarElement.prototype, "getVisible", null);
__decorate([
    cacheGetter(),
    __metadata("design:type", Object),
    __metadata("design:paramtypes", [])
], HTMLDwebStatusBarElement.prototype, "getState", null);
__decorate([
    cacheGetter(),
    __metadata("design:type", Object),
    __metadata("design:paramtypes", [])
], HTMLDwebStatusBarElement.prototype, "setOverlay", null);
__decorate([
    cacheGetter(),
    __metadata("design:type", Object),
    __metadata("design:paramtypes", [])
], HTMLDwebStatusBarElement.prototype, "getOverlay", null);
export { HTMLDwebStatusBarElement };
if (!customElements.get(HTMLDwebStatusBarElement.tagName)) {
    customElements.define(HTMLDwebStatusBarElement.tagName, HTMLDwebStatusBarElement);
}
