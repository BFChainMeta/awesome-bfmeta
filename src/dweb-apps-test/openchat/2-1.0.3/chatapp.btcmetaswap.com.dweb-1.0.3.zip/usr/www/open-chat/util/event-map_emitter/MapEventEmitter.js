import { __decorate, __metadata } from "../../tslib/modules/index.js";
import { cacheGetter, renameFunction, GetCallerInfo, isDev, EVENT_DESCRIPTION_SYMBOL, eventDebugStyle, } from "../event-base/index.js";
export class MapEventEmitter {
    constructor() {
        /**导出类型 */
        Object.defineProperty(this, "TYPE", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "_e", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: Object.create(null)
        });
        /**是否由过自定义异常处理 */
        Object.defineProperty(this, "_hasEmitErrorHandlerSet", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        //#endregion
    }
    on(eventname, handler, opts = {}) {
        this._on(eventname, handler, opts.taskname, opts.once);
    }
    /** on函数的具体实现 */
    _on(eventname, handler, taskname, once) {
        const eventHanldersMap = this._e;
        let eventSet = eventHanldersMap[eventname];
        if (!eventSet) {
            eventSet = eventHanldersMap[eventname] = new Map();
        }
        else if (eventSet.has(handler)) {
            console.warn(`hanlder '${handler.name}' already exits in event set ${String(eventname)}.`);
        }
        if (taskname === undefined) {
            taskname = GetCallerInfo(this.constructor);
        }
        eventSet.set(handler, {
            taskname,
            once,
        });
    }
    once(eventname, handler, opts = {}) {
        this._on(eventname, handler, opts.taskname, true);
    }
    off(eventname, handler) {
        return this._off(eventname, handler);
    }
    _off(eventname, handler) {
        const eventMap = this._e[eventname];
        let res = true;
        if (eventMap) {
            if (handler) {
                const res = eventMap.delete(handler);
                if (res && eventMap.size === 0) {
                    delete this._e[eventname];
                }
            }
            else {
                eventMap.clear();
                delete this._e[eventname];
            }
        }
        else {
            res = false;
        }
        return res;
    }
    get [EVENT_DESCRIPTION_SYMBOL]() {
        return "";
    }
    emit(eventname, ...args) {
        this._emit(eventname, args);
    }
    _emit(eventname, args) {
        /**
         * 触发针对性的监听任务
         */
        const eventMap = this._e[eventname];
        if (isDev) {
            console.group(...eventDebugStyle.head("%s EMIT [%s]", eventDebugStyle.MIDNIGHTBLUE_BOLD_UNDERLINE), this[EVENT_DESCRIPTION_SYMBOL] || this, eventname);
            console.log(...eventDebugStyle.head("%s ARGS:", eventDebugStyle.MIDNIGHTBLUE_BOLD_UNDERLINE), ...args);
        }
        if (eventMap) {
            for (const [handler, opts] of eventMap.entries()) {
                try {
                    if (isDev) {
                        const { taskname = handler.name } = opts;
                        console.log(...eventDebugStyle.head("%s RUN [%s]", eventDebugStyle.MIDNIGHTBLUE_BOLD_UNDERLINE), this[EVENT_DESCRIPTION_SYMBOL] || this, taskname);
                    }
                    const res = handler(...args);
                    if (res instanceof Promise) {
                        res.catch((err) => this._emitErrorHanlder(err, eventname, args));
                    }
                }
                catch (err) {
                    this._emitErrorHanlder(err, eventname, args);
                }
                finally {
                    if (opts.once) {
                        eventMap.delete(handler);
                    }
                }
            }
        }
        isDev && console.groupEnd();
    }
    //#region on emit error
    /**
     * 触发内部的异常处理函数
     * @param err
     * @param han
     * @param name
     */
    _emitErrorHanlder(err, eventname, args) {
        if (this._hasEmitErrorHandlerSet) {
            for (const errorHandler of this._emitErrorHandlerSet) {
                /// 这里如果还是异常就不作处理了，直接抛到未捕获异常中就好
                errorHandler(err, {
                    // hanlder: hanlder ,//as $MutArgEventHandler<EM[keyof EM]>,
                    eventname,
                    args,
                });
            }
        }
        else {
            isDev &&
                console.error(`EventEmitter '${this.constructor.name}' emit '${eventname.toString()}' fail:`, err);
            throw err;
        }
    }
    get _emitErrorHandlerSet() {
        this._hasEmitErrorHandlerSet = true;
        return new Set();
    }
    /**
     * 自定义函数执行异常处理器
     * @param errorHandler
     */
    onError(errorHandler, taskname) {
        if (typeof taskname === "string") {
            renameFunction(errorHandler, taskname);
        }
        if (this._emitErrorHandlerSet.has(errorHandler)) {
            console.warn(`hanlder '${errorHandler.name}' already exits in custom error hanlder event set.`);
        }
        this._emitErrorHandlerSet.add(errorHandler);
    }
    /**
     * 移除自定义函数的执行异常处理器
     * @param errorHandler
     */
    offError(errorHandler) {
        if (!this._hasEmitErrorHandlerSet) {
            return false;
        }
        if (errorHandler) {
            return this._emitErrorHandlerSet.delete(errorHandler);
        }
        this._emitErrorHandlerSet.clear();
        return true;
    }
    //#endregion
    /**
     * 移除所有的事件
     */
    clear(opts = {}) {
        /// 直接清理掉
        this._e = Object.create(null);
        const { ignoreCustomErrorHanlder } = opts;
        /// 默认清理掉自定义错误的回调合集
        if (!ignoreCustomErrorHanlder && this._hasEmitErrorHandlerSet) {
            this._emitErrorHandlerSet.clear();
        }
    }
    //#region 同名拓展
    get removeAllListeners() {
        return this.clear;
    }
    get addListener() {
        return this.on;
    }
    get removeListener() {
        return this.off;
    }
}
__decorate([
    cacheGetter,
    __metadata("design:type", Object),
    __metadata("design:paramtypes", [])
], MapEventEmitter.prototype, "_emitErrorHandlerSet", null);
__decorate([
    cacheGetter,
    __metadata("design:type", Object),
    __metadata("design:paramtypes", [])
], MapEventEmitter.prototype, "removeAllListeners", null);
__decorate([
    cacheGetter,
    __metadata("design:type", Object),
    __metadata("design:paramtypes", [])
], MapEventEmitter.prototype, "addListener", null);
__decorate([
    cacheGetter,
    __metadata("design:type", Object),
    __metadata("design:paramtypes", [])
], MapEventEmitter.prototype, "removeListener", null);
