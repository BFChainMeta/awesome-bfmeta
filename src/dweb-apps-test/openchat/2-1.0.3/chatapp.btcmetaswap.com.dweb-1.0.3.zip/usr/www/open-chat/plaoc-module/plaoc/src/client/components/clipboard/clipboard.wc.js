import { __decorate, __metadata } from "../../../../../../tslib/modules/index.js";
import { cacheGetter } from "../../helper/cacheGetter.js";
import { clipboardPlugin } from "./clipboard.plugin.js";
class HTMLDwebClipboardElement extends HTMLElement {
    constructor() {
        super(...arguments);
        Object.defineProperty(this, "plugin", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: clipboardPlugin
        });
    }
    get read() {
        return this.plugin.read;
    }
    get write() {
        return this.plugin.write;
    }
}
Object.defineProperty(HTMLDwebClipboardElement, "tagName", {
    enumerable: true,
    configurable: true,
    writable: true,
    value: "dweb-clipboard"
});
__decorate([
    cacheGetter(),
    __metadata("design:type", Object),
    __metadata("design:paramtypes", [])
], HTMLDwebClipboardElement.prototype, "read", null);
__decorate([
    cacheGetter(),
    __metadata("design:type", Object),
    __metadata("design:paramtypes", [])
], HTMLDwebClipboardElement.prototype, "write", null);
export { HTMLDwebClipboardElement };
if (!customElements.get(HTMLDwebClipboardElement.tagName)) {
    customElements.define(HTMLDwebClipboardElement.tagName, HTMLDwebClipboardElement);
}
