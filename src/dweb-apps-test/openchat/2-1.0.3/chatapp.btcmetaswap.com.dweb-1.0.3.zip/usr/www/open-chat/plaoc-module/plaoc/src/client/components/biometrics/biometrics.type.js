export var BiometricsTypes;
(function (BiometricsTypes) {
    BiometricsTypes["fingerprint"] = "fingerprint";
    BiometricsTypes["faceRecognition"] = "faceRecognition";
})(BiometricsTypes || (BiometricsTypes = {}));
