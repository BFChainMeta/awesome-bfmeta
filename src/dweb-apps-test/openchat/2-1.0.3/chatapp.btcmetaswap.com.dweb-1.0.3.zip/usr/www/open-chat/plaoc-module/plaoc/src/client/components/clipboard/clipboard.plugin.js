import { __decorate, __metadata } from "../../../../../../tslib/modules/index.js";
import { bindThis } from "../../helper/bindThis.js";
import { BasePlugin } from "../base/BasePlugin.js";
export class ClipboardPlugin extends BasePlugin {
    constructor() {
        super("clipboard.sys.dweb");
    }
    /** 读取剪切板 */
    async read() {
        return await this.fetchApi("/read").object();
    }
    /** 写入剪切板 */
    async write(options) {
        await this.fetchApi("/write", {
            search: {
                string: options.string,
                url: options.url,
                image: options.image,
                label: options.label,
            },
        });
    }
}
__decorate([
    bindThis,
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], ClipboardPlugin.prototype, "read", null);
__decorate([
    bindThis,
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], ClipboardPlugin.prototype, "write", null);
export const clipboardPlugin = new ClipboardPlugin();
