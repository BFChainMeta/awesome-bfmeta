import { WindowModalController } from "./WindowModalController.js";
export class WindowBottomSheetsController extends WindowModalController {
    constructor(plugin, modal, onCallback) {
        super(plugin, modal, onCallback);
    }
}
