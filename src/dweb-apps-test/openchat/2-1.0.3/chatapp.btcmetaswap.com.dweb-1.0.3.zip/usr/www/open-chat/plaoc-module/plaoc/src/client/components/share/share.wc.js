import { __decorate, __metadata } from "../../../../../../tslib/modules/index.js";
import { cacheGetter } from "../../helper/cacheGetter.js";
import { sharePlugin } from "./share.plugin.js";
class HTMLDwebShareElement extends HTMLElement {
    constructor() {
        super(...arguments);
        Object.defineProperty(this, "plugin", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: sharePlugin
        });
    }
    get canShare() {
        return sharePlugin.canShare;
    }
    get share() {
        return sharePlugin.share;
    }
}
Object.defineProperty(HTMLDwebShareElement, "tagName", {
    enumerable: true,
    configurable: true,
    writable: true,
    value: "dweb-share"
});
__decorate([
    cacheGetter(),
    __metadata("design:type", Object),
    __metadata("design:paramtypes", [])
], HTMLDwebShareElement.prototype, "canShare", null);
__decorate([
    cacheGetter(),
    __metadata("design:type", Object),
    __metadata("design:paramtypes", [])
], HTMLDwebShareElement.prototype, "share", null);
export { HTMLDwebShareElement };
if (!customElements.get(HTMLDwebShareElement.tagName)) {
    customElements.define(HTMLDwebShareElement.tagName, HTMLDwebShareElement);
}
