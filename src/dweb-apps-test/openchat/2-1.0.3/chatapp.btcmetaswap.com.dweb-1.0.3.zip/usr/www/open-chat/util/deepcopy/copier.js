import { getFromCopyMap } from "./copy_map.js";
import { detectType } from "./detector.js";
/**
 * no operation
 */
function noop() { }
/**
 * copy value
 *
 * @param {*} value
 * @param {string} [type=null]
 * @param {Function} [customizer=noop]
 * @return {*}
 */
export function copy(value, valueType = detectType(value), customizer = noop) {
    const copyFunction = getFromCopyMap(valueType);
    if (valueType === "Object") {
        const result = customizer(value, valueType);
        if (result !== undefined) {
            return result;
        }
    }
    // NOTE: TypedArray needs pass type to argument
    return copyFunction ? copyFunction(value, valueType) : value;
}
