import { decode } from "../../../../deps/deno.land/x/cbor@v1.5.4/index.js";
import { $messageToIpcMessage } from "./$messageToIpcMessage.js";
export const $messagePackToIpcMessage = (data, ipc) => {
    return $messageToIpcMessage(decode(data), ipc);
};
