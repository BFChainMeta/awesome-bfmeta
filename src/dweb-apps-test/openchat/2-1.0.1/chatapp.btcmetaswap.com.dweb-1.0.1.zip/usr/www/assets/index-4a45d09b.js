import {
  c as se,
  m as K,
  n as N,
  d as V,
  r as k,
  u as ge,
  a as j,
  b as oe,
  w as ne,
  e as ae,
  f as m,
  L as me,
  g as fe,
  h as he,
  p as ce,
  i as re,
  j as H,
  k as q,
  l as Ce,
  o as pe,
  q as ve,
  s as xe,
  t as Se,
  v as ie,
  x as we,
  y as X,
  z as De,
  I as F,
  C as G,
  A as Ee,
  B as S,
  D as M,
  E as d,
  _ as le,
  F as u,
  G as b,
  H as Y,
  J as U,
  K as Be,
  M as P,
  N as ue,
  O as Te,
  S as _,
  P as $,
  Q as L,
  R as Fe,
  T as Re,
  U as ee,
  V as z,
  W as Oe,
  X as ye,
  Y as be,
  Z as I,
} from "./index-0085351d.js";
import "./index-44364ad2.js";
import { S as ke } from "./index-08277207.js";
import { P as Me } from "./index-5417b32f.js";
import { V as Ve } from "./virtual-list-986f13ac.js";
import { n as Je } from "./not_accept-1b9d42a2.js";
import { B as Ge } from "./index-df8775be.js";
import "./use-id-f9988c90.js";
import "./use-sync-prop-ref-17d54694.js";
const [Ie, Q, He] = se("pull-refresh"),
  Ae = 50,
  Qe = ["pulling", "loosing", "success"],
  Ye = {
    disabled: Boolean,
    modelValue: Boolean,
    headHeight: K(Ae),
    successText: String,
    pullingText: String,
    loosingText: String,
    loadingText: String,
    pullDistance: N,
    successDuration: K(500),
    animationDuration: K(300),
  };
var Ke = V({
  name: Ie,
  props: Ye,
  emits: ["change", "refresh", "update:modelValue"],
  setup(t, { emit: A, slots: s }) {
    let o;
    const r = k(),
      f = k(),
      h = ge(r),
      n = j({ status: "normal", distance: 0, duration: 0 }),
      g = oe(),
      x = () => {
        if (t.headHeight !== Ae) return { height: `${t.headHeight}px` };
      },
      l = () => n.status !== "loading" && n.status !== "success" && !t.disabled,
      v = (e) => {
        const i = +(t.pullDistance || t.headHeight);
        return (
          e > i &&
            (e < i * 2
              ? (e = i + (e - i) / 2)
              : (e = i * 1.5 + (e - i * 2) / 4)),
          Math.round(e)
        );
      },
      C = (e, i) => {
        const w = +(t.pullDistance || t.headHeight);
        (n.distance = e),
          i
            ? (n.status = "loading")
            : e === 0
            ? (n.status = "normal")
            : e < w
            ? (n.status = "pulling")
            : (n.status = "loosing"),
          A("change", { status: n.status, distance: e });
      },
      p = () => {
        const { status: e } = n;
        return e === "normal" ? "" : t[`${e}Text`] || He(e);
      },
      E = () => {
        const { status: e, distance: i } = n;
        if (s[e]) return s[e]({ distance: i });
        const w = [];
        return (
          Qe.includes(e) && w.push(m("div", { class: Q("text") }, [p()])),
          e === "loading" &&
            w.push(m(me, { class: Q("loading") }, { default: p })),
          w
        );
      },
      R = () => {
        (n.status = "success"),
          setTimeout(() => {
            C(0);
          }, +t.successDuration);
      },
      O = (e) => {
        (o = he(h.value) === 0), o && ((n.duration = 0), g.start(e));
      },
      c = (e) => {
        l() && O(e);
      },
      B = (e) => {
        if (l()) {
          o || O(e);
          const { deltaY: i } = g;
          g.move(e),
            o && i.value >= 0 && g.isVertical() && (ce(e), C(v(i.value)));
        }
      },
      T = () => {
        o &&
          g.deltaY.value &&
          l() &&
          ((n.duration = +t.animationDuration),
          n.status === "loosing"
            ? (C(+t.headHeight, !0),
              A("update:modelValue", !0),
              fe(() => A("refresh")))
            : C(0));
      };
    return (
      ne(
        () => t.modelValue,
        (e) => {
          (n.duration = +t.animationDuration),
            e
              ? C(+t.headHeight, !0)
              : s.success || t.successText
              ? R()
              : C(0, !1);
        }
      ),
      ae("touchmove", B, { target: f }),
      () => {
        var e;
        const i = {
          transitionDuration: `${n.duration}ms`,
          transform: n.distance ? `translate3d(0,${n.distance}px, 0)` : "",
        };
        return m("div", { ref: r, class: Q() }, [
          m(
            "div",
            {
              ref: f,
              class: Q("track"),
              style: i,
              onTouchstartPassive: c,
              onTouchend: T,
              onTouchcancel: T,
            },
            [
              m("div", { class: Q("head"), style: x() }, [E()]),
              (e = s.default) == null ? void 0 : e.call(s),
            ]
          ),
        ]);
      }
    );
  },
});
const Le = re(Ke),
  [Ue, W] = se("swipe-cell"),
  Pe = {
    name: K(""),
    disabled: Boolean,
    leftWidth: N,
    rightWidth: N,
    beforeClose: Function,
    stopPropagation: Boolean,
  };
var ze = V({
  name: Ue,
  props: Pe,
  emits: ["open", "close", "click"],
  setup(t, { emit: A, slots: s }) {
    let o, r, f, h;
    const n = k(),
      g = k(),
      x = k(),
      l = j({ offset: 0, dragging: !1 }),
      v = oe(),
      C = (a) => (a.value ? ve(a).width : 0),
      p = H(() => (q(t.leftWidth) ? +t.leftWidth : C(g))),
      E = H(() => (q(t.rightWidth) ? +t.rightWidth : C(x))),
      R = (a) => {
        (l.offset = a === "left" ? p.value : -E.value),
          o || ((o = !0), A("open", { name: t.name, position: a }));
      },
      O = (a) => {
        (l.offset = 0),
          o && ((o = !1), A("close", { name: t.name, position: a }));
      },
      c = (a) => {
        const D = Math.abs(l.offset),
          y = 0.15,
          de = o ? 1 - y : y,
          Z = a === "left" ? p.value : E.value;
        Z && D > Z * de ? R(a) : O(a);
      },
      B = (a) => {
        t.disabled || ((f = l.offset), v.start(a));
      },
      T = (a) => {
        if (t.disabled) return;
        const { deltaX: D } = v;
        v.move(a),
          v.isHorizontal() &&
            ((r = !0),
            (l.dragging = !0),
            (!o || D.value * f < 0) && ce(a, t.stopPropagation),
            (l.offset = xe(D.value + f, -E.value, p.value)));
      },
      e = () => {
        l.dragging &&
          ((l.dragging = !1),
          c(l.offset > 0 ? "left" : "right"),
          setTimeout(() => {
            r = !1;
          }, 0));
      },
      i = (a = "outside") => {
        h ||
          (A("click", a),
          o &&
            !r &&
            ((h = !0),
            Se(t.beforeClose, {
              args: [{ name: t.name, position: a }],
              done: () => {
                (h = !1), O(a);
              },
              canceled: () => (h = !1),
              error: () => (h = !1),
            })));
      },
      w = (a, D) => (y) => {
        D && y.stopPropagation(), i(a);
      },
      J = (a, D) => {
        const y = s[a];
        if (y)
          return m("div", { ref: D, class: W(a), onClick: w(a, !0) }, [y()]);
      };
    return (
      Ce({ open: R, close: O }),
      pe(n, () => i("outside"), { eventName: "touchstart" }),
      ae("touchmove", T, { target: n }),
      () => {
        var a;
        const D = {
          transform: `translate3d(${l.offset}px, 0, 0)`,
          transitionDuration: l.dragging ? "0s" : ".6s",
        };
        return m(
          "div",
          {
            ref: n,
            class: W(),
            onClick: w("cell", r),
            onTouchstartPassive: B,
            onTouchend: e,
            onTouchcancel: e,
          },
          [
            m("div", { class: W("wrapper"), style: D }, [
              J("left", g),
              (a = s.default) == null ? void 0 : a.call(s),
              J("right", x),
            ]),
          ]
        );
      }
    );
  },
});
const We = re(ze),
  Ne =
    "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACkAAAAoCAYAAABjPNNTAAAAAXNSR0IArs4c6QAABp9JREFUWEfVmGlsVFUUx//nTaeUzptWSun2plAiadFAsTMsVgXqkhA1aeKCRFFiQD5oiBojkoiYgOLKZgJGE4lKghuJxmhcUBMXktbKtCwiq9DS94qUpS19M13fO+a+mWmHcdq+N4DG+2EymTnL75577znnXsL/YNDlYPQqM8dC6q9mliYIewTuBps/dWoNtQD4Un1cEmRGfvnENLd7PYC7koIwtwJYpWtXbwV2GKnCpgwpF/kXQKKP7DhmYGfIxF1oCYbtyCfKpASZ6au4XYL0VZwxZvA3BKnO+o05H4T7AOTEZBioC2V0zMGxYz1OQR1Div3H1K8BNMriAU4QUbXevPv3ROeyElgDwkoAkvjPZF4Z1upfuuKQsuJfC6JnIxFDq651jAeGjo6nKPA0SXjNOk/ig125nVrdOSegziI5adIouTvrAkDpESdmla42/DSSQ9nnPw1QnqUB486wuid+q4ykHpmd3ZFRcF1JWprrRESe23S1fmDPDWfD4wusIOCVqMyHuhp8wK5PK/pOhOXxFdfClA5EdVRdDRbb0c9S/NebRDXRLRLUteB0O3oxmX8fElyjq/U3XDHIzAmBQslAS+TMIBxSgx47zjxK4H0iLLL0GOtDWvBpO3opRVKkEtkXEFVkbGTp+CVdqxcpZtgh+wIXAHitg2MgED4VrB9JJ/5/R8stFGUlMB+ET6JGek0DlcM5lX3+HwGaG92PnTql50Ot6bqikCipypD7OveAUBZ11Gcyrw5r59cDjd0x595i/2yTaR0BMweAyJyrNzf87ATQ8emOGR/tm6a4OO0gKLKE0cFg/hVE3QyUEVAYD2MyXgxrwedT6YocL3fMsZxfnsdp7m+IUDFSZNjE8lBLUHRLKbVtKUNGwOa7vL4/F5vAUgLNSIDtALCDe6RVoTO//TXSRIb7/xIhB017SmYUuPqMEpOkDJert6mjaV9jqpFLBE4dMrfMK4/yzCCSJpowSyWK1Ob4wUxNIBxCn7FP/6vhYKrQziBFg9GTvQSMewHc7GwJWWPgWyJpY7K27nIst+RRKhYSSa8i4dQ6A41IV99x86fb335dfPUDaALwJhHFcu8/TNqJpORR/BuI6ImExTSZqQHEe4mokcDNidZNg8pIsvLpnFiVml05HZ9v3wy3Oy1R/Cki2phs0iNCZioVz0kkvTCYDKESm2v1rvQPcP5XUe5sDa9SUcmgxw/UfrlgvK+QvjigY3NtuH9RZZ628FpYt0wAChFZvUH8GBbSWxSYzBLEho8O/lRXu+8H/ui1RZZEiJnFZWx08SYdaq9sSbQ/iXPZ6VY/cBsR/eAI0uPzbyXQ4qjSPl0NTksVbmCazFZCH7OuC+3maOvnpiXdofFjM0RHNY+IdtqGzM8v94Tc7jYAbqHEbFSEtD17nEIycxaApYC1N4Wth4WNnE1mV1uvZFEefrCDS4uyxaoKQHGQjgH4ioisy92Qyy0XT58C5v1RKNtdePwkmFl04L8AyEicXM4bCLX1wOpHDy1sR5lyVaJIP4AniWjL0JCK/xYM7o8GXQ2KdOFoMHOn6O5awzj5zj4U9RkYONKv1KK324B1oVs2tRu5WYPzuG8yWq4ZiyIAAnSKPUiG43sJM2cDENuF5I3oDfVFgOyOw0txpnQMxgF4ZkhIb1HgJpaspRJjv64Gy+06iOxhLhXbTXxPXwejz4TLif6uhTh9o4J88ZY0JGT2hPKJhuE+HjXcoatdeU5TDzOLJ5X0bQdwdsdhhAxzEPO7Rvj6o+A35Ort2Vmy6JqsUVWMjOWzkEuwJjZv2Dwp+wKqSLCWJuMtXQs+6iQazLwCwMvJDuiYDT1Ge/8oK7pHH7pgTCrMShbpj4jo/mEhPUrFQ0TStiiYiMOHxK41nVrdEbuwzLwAwCMAro6+CVnVJT5PnnrMPF8gS+Kh4TQAcQXRAOsetYWI+kcoiwG3R6GvifjWi6H4KEC7AToCsEnEJ5NBM1MWQDkAKyAuAdPczubdVt6Nhzy9DGfzMpHrOJnHnObkzMrqzex7F6C77UZvOLlzx2uQ7nYjf0MIrf2Ra3vrMpwbl2mVRWcVJ9GR7JtexYyniHieOAypAp/Y+z3n5lxFq3eZLWtqpIJ7SnH242rkEFk5dGqsysTbH7EL+idMwO0toplwmaWRN3ImooEu5iJxZnQA1AbTPGMSmphde8NanSiRq5JM8jOi5KuVAmSqMRzUY2bx6iHeODOjv74nCg8RhZJZ/08grYzGLLaMKH1tRDSQI5NB/g0Cw12ZvKDOOwAAAABJRU5ErkJggg==",
  je =
    "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACoAAAAoCAYAAACIC2hQAAAAAXNSR0IArs4c6QAAB71JREFUWEfVmH9sG+UZx7/Pne3YPlNok0DqS7WgBdZ1WevYjdZ1GRStiCJajfJDZBLVqFQ2oVJpiG60QtUKQwK0onYIsU6JtDCCaEcHbOt+aIw2iLLCis+hpSgd3ZauOde0Kek6X+I49j3Te/Y5dhrb5xRp2v1l+Z73+37ueZ/3eZ73JfyfPFQzp7qwPkC+NjFu0swmJuJHT9SsMYsBjkH9wdA3JZI3g9BZPA8zhom4JzmRegbnPkrOgsHREAegLV5FnddNRPdWUmTgw8wEr504p510NHONRlVBFTX8MhF1FXSZkwy8CyAFUIgIzVPvsDupRx+okcGReUVQXzB8jyzRHluJmXcZ6dS24iVW5ofvJQk/BVGAGZsNPfqMsPfVL1Fln9RqshSAyYmxM9oHADKOqGYwqgiqNEeOEWBtHDbxlBGPbp1pIqVxURM8niZDHxjIxbK0BUTLSmwZI8zoMcayT+PCwIVagcuC1jWGW9119LElyBhJ6ucXAEOpChO4FDUsYvm+irHMPATw7YYeEx52/JQF9avh1RLRby1O5j2Grn2rkmogGOmGhA3TYrkfQJKApSBqLYQQkDB5smNcPzrslLQsaCDY3gVJejkP2mvo2vpyosUfJWxM8HNjSXNb8RL71SWriVzdBDTlNfcburbmskF9aniZTHQ4J4oBQ4+2lxMNqJG37fxqQQ5rm2aMZTUUAuQjRHDldLPtIq6dwFbaTK6AGh4Vuzknaq409Nibl4gGr28ISFecy4UyUkYyO7/SZlHU8M/tOGbT3GLEY09fLigUNbyTiL6Xh0hMZjIr04kPjhcLe4NLOl2S6+3cpuNDSV37euVYdh5SxTqVE34w0qBIECnKjqsUM/cBNAAyh8b0gd8FmkMrAPmg07ibtkkrxr5jUEVtXwLgUYDuFoOISr/LNM0fZSfpF3YaE3Xf0KMLKnnUHwz/UJJoe/7Ddhm69tCsl74uuPgLbsn1FEC3VxIR3jV0bZ2iRk7bpTRrctd4XNs747jGRQGlzvdxYYWyfKtxRvvjrECV+eFbSMI+exOVirBoOOLMNIfZPJVF9hHR5vnV8KMS0RP5OE1msrw6lYi9VTJWQHq8rxHRytz/fDI5rH3RaVktWUvPNYvbPC7X4amdLmoz94H5JSM+eqh8ZWrxBtT6GAgLbThRJBjoJ1CKgFYmbLA9KWxM5jVjurbfiTetsCs2DDRHxKZYYX9xejKzNv3J0Q+diImS6/LgDSJqqRwuyICw2RiO/sSJrm1TAFXUUIhIjuVTUWrSTLen48cGaxHLNSfeJ8vXez7JJj9gxGN/rkW3xKOKGnmYCDssARM9yXj0/lrFbHuroXHjFhC1MdjLjCECv2PEY6L2z6rVK3g00NzeDUhWU8Hgdcaw1lcTaOOigN/ju5HIbANTGxFNNdS5zXOBAeHRwWxG6p84G/17LfpFSz9V2oDsTcnhAfH1VR+Ra4loO4NWEeCtOiBvII4u4OwOQ7+wt0r7aI2YEdShR13+5vBOCfSgU7jpdvVzr0L3s4+P3rxi+RX5kBCr+BARXXJILICW5sLqZx+/GnlFItxlT86MDOXOUv1g8zgkTmRZSsmZTBJuqUEcSYjo82BeSqBVIDS8+uKzuHnFcnxy/iICim9S8brdAPYQ0SW97xTo/PalkiwdsXe9aWZXjscH3pnJW341/F2JaLf9zmTsy6Z5q/MTaIv3pjU3/uDAb3ofOxG/iFCfFy5ZTuub5P/M8eBKAI1EVHJcKcmjihoWedCqHMJDAO8zGa9LxIOGPnoiF0stXqW5/p+FMgjeYQxr3691+ZlZ5OuDL/z1PO7rr7eGH75jZHxZa4MPwLVENFSsWQoq8mCdL1ZcQQrGjMFkerxDcXk7SaY/5P6vrQzmHMDfAKwjtqhiW/qi/55c9+aVYsnx1m1x3PCloPi5GcAIgEEieq9kM9lAPnVxM8G9szj+CkucNTtAdJvd/YDxRFKPbnPiTWYWXf0rAEoanX0fTX569373vGmgxZK9RLS+bD/qbQq1yLJ8JwHLWNRq5kNjcW1TSYfOvN7QtV6HoBsBPPePURjPx5AZz2BcjBv8FNKBf+Fq8fvWxrO4Vr06IX773PA+8hWg0Y+rAHRVvSmZDnEZoK8Jb37tJcT/osNa32rPHdfh1K/W4nMAemoHDUaeJAlbxCSmydvH4tpj1SbMx2Y3gA0b30D8+Zgz0G3LcfrxTohGfEfNoKVHYz6ZnEi1O7nFY2ZxC2gdWS5OYCidhZXUe94bbdh6ZK5VbneHBo07Oxdalx4eGYE5dRB3AeLSo71m0OnpCczvmiYeHDujRat5lplXA/hxfsdb5mXSky0ljtKiUvXPAhSwLsZkerEYjK2rGojedYQIJTmwkDWABmI0gNB6w1c7Qr//5W5XMeiJDXzq+nkkYrJyHq3mkeL3/mB4IxHtsi8TahkrbDvCbTjw617sff8sug5Ymx5/ux9D182FaLw/O1ArjoJfXuiB52FIfBdAIo04fhTFlzl97CCZDPM7f5ITXhdJP1uFa/KJfgERlfSts1r6mWgEtJvdLZDQJJpliUhMWniYRUfE501wkkwMjWUmBvns8W+L3FpkJuDWEU3dydrvPjNQx66cZpiv+ffk27wXiOj9mbT+56BOP/C/xBJG70tRf3YAAAAASUVORK5CYII=",
  Xe =
    "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACgAAAAoCAYAAACM/rhtAAAAAXNSR0IArs4c6QAAAwRJREFUWEftmE1oE1EQx//zdkOabg4e1LZJDoIF8dTuRtGDYEUFwUvBihWR9lBB70LxZLzpwbOCSisUrCioB/FgD4oIFcnHTYUKCt3FSg895KO1zXtlkwbTZHezm21rqekx783M7/1n+97MELb5H21zPrQA/WZoRygoK13aSUiil0BtdYpwfM0aqadWSild2iWS0F27JgRlAZ7J6en3AFacVHZUMNQRPyIFxARAdUGqnXJe7M8bmVfVv4Vi6jkJ7LlzisVMkfPhgpH5aLfPFrCtUz0uSWyKCHKj76go+PmCnl4HE4qqAxKxZ41sBbDIl9FXmEt+stprByiHY9qXv8qJBQ5MMGC+PsXiW9ZIT1o5D0fUQTA6ULvGBXUyYACE3eU1MZOdTR20SrcloBJRTxFjb8u2mF8pFg8v/sr8aKSGl/XgHq07EMRngHaVwnB+Omekp2p9WAPG1FECu21u5gL383rympfgbveGI/EHYBgpAQpcz+nJu64AwzHtJkCJNfkT2dnULbdBvexzE8dSQTeGXkDs9rqJ0wJ0UnoHK1i6v9iT0uk5v2h3z/n9DpWoNkxEY05xbF8S8yUgIVbyRualXxAnezOOuV77ElVsrAETQkYIQwBimwlX5XsWBTxGguoKB2vAO6IfwIstgquEGcEoPXJ1UeNfAHJcwQ166A7QTHEQw2CIbomKHDqWMO4+xQDao/GzJlxeT77eTMhGcSy/wXXFJheDdhWzX/BwRLsARuVSzSZO66n7T5+6Vj1YTnzT1YyyRSV/ezR+jxGuei75lS7tDEn0Zq3kX1j+Q4eWfie/+71Wqu2De+P7AwFMVzo7T00TgPVtp8A8JzFp3XY6TBaivUNEbF/dwbiIgdFApaPz3HaaDkMd2lEm0wc3jXvzkwWzqzUbd3GiMJeatsqQ4+ijLdJzTGbSWKPRR/OTBTFTXMZlOzgT2M10S1Yiah+I9RCJcO0phcDPnJ4atzq93WRBQCyCI5kz0u98DY828p+iWV9uFGzW94bYtQD9yrjtFVwFbNWQOMrHGBcAAAAASUVORK5CYII=",
  Ze =
    "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACgAAAAoCAYAAACM/rhtAAAAAXNSR0IArs4c6QAAA81JREFUWEftWD9oE3EU/t411TQX8T+2vRQUFKHU0lwQHBwcFBHqICoo6CAuLqKDGkVFh4IWHRQEB91UujgULFiwQwdHc0YRFVpQMKeVLhVyadok9+QuvXhJ7nKXNEKHZAv53nvf73vv/X7vhbDCP7TC+aFFcLkZ8lZwfWytGOQ9EKhzucEse+bCnK7jQ3Ym+d3LpyvB1d39O9uF9rvMGCRCwMtRI78z+B0KuKn9Usbd7B0JdkSiRwUIzwkINhK4XhsG39dSymUnuyqCYpd8EAKN2VUzT8r4VG/gGvgIiPaWCcAYSquJm5U2FQS3BkVp4xQRIiaQ8ZVROKmpyWQTyZmuxM29nVgVfEJEg2YoRh4o7K6MVUYw1B09KwjC0yI3zGBhPqrNfp5pNjmbv4Aoya+JaH+RJD/XVOW0PV4ZQVGSX5VOBFzUUomH/5FcUUlpYICo7X0xY5xOq8oaV4LhiDwF0HYTkMvtSv/+6L/uhvkWGDcATOIqHajnYGEpNgvCJsOmwLmeefVjyrIvUzAsyV8YtN1okHy+sM3PPVUiMszfAGxd+t6DOJWCeJEVJfkbEZm2lXErU+wK9AoCO0Ed23CNPC9hy2eLoKlES0Gz5d2L1dYMxW6t9T4zUDXIMSbcuru5NVjerc6940TQQBK6cIWqLv5mE7y+pKD7IOFMcBRxOuJ0ouYSdLtvWk3it0laCpY/sa5PXW6BdyzMKtOeT5wFWNZbHPthzaBeb/Gb0mxW4FPaL+VFHQTjYNwGYdytW518dWzoj7SF2n+Y0xaQ1VIJY9zKO04zIUm+LhANLYE/aalE1A72TbYOYFiKPQbhXHEc5AlNVcpGtfIUb+7tpFXBKRCFDQNd59FMRj+DueRcHTH9QgMhSY5bgpjxmA9nVGXM7qB6aYrELhDwwAIZoz+DXxJoGsx/TEfg9Lz6ftRN3ZAkDxKKA+i/DzHARIwwgyQIMDB9NsBoOpWousgd104xIt8j0KWaUjC/TS9mD2H2c9qGC4Sk2IhAOOZXxmJqMaktzh+u8GW6cF3cOzqjx9oCdKe0AjhENEvgp3LcUtJeT/4I8pzOuJ9RlWG3bHj99REQu6P7ICAGNv/6WEegMGwK6eBHmZRyXoxE42BhyNqnGTwORtVgQKAsiGd0Xf+QyS1OOKlWswb9nLyyBIwUEWFfqW4d1kc/fp0wXgq6+hUleYSITlQCzHpSE8ZVUbrLGiVXswZ9ODWW7md2kkZatYXsca+0+fBdgjSsoOUhvKW/j9sDA5TLJ+vao32yXDZBn3EahrUINizdkuGKV/AvclE4R8R1zasAAAAASUVORK5CYII=",
  qe =
    "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADgAAAA4CAYAAACohjseAAAAAXNSR0IArs4c6QAABrVJREFUaEPtWl1sFFUUPufO7Hb/EiFtBXY2sUQaEPlpZyVipBETTXzACNEHiBhLIAHUB0140IChRniSNzFghFATCCRiwMiDiSaYtAklZqcFUUqooSY7pUgbMM5ut7uzc8zMdpbd7s/M7uzS0jCvc8/Pd86559x7zkWY4x/OcXzwGOCj7uG6eLAhuGopB9w6huw5AloCAEsQYR4AzjMMRjRGAAoADCHgEEG6TyWtb3Lk6o1aG7RmAD2L2p9iiJ0MYSsg6qAq/4iGNIBuTaOTidv9f1fOoJDCMcCGJ8NP8y7aB4BbEYGvhVJEoALQSTWFByb/ifzlhKcDgC2egNC4lwA+LgqMoFcD+omAbhBpo6BhNDF6fxSafbyHczfxPLSkCZsQcCkDfA0Q1k0HQgAJJDikyOMHAYYT1QCtCqB74epnXTx/BgFW5Akl6iWA4zHCCzASGatIoWC4yY+0AQG2A2IeWAK4llLVzcnRK39UxBOg8jLhDbW/yRF2A2IgK4xgUKP0J/GRgfOVKlBsvS/YtpEx9gVAzl4mUtJInRPR/u8rkVGRB32CuBMBD5shqYcQkfZRXO4/BqDvm5p+vE9o34HAvszKI1AJ6IO4LH1tV5JtgL6g+D5jeNhkTACjWoo2TdyR+uwKq2add4G4lrnwHAIsNOk1ol12QdoCqIclI3Ymx5IDGqRen5CvRqtRulIar7AqxMD1IyK0ZcooqBpqm+2EqyVAPaG4Oa7P3HNEMBBLTnTA3T/1Qv3wvublAb/b22OCBCIlmU6vtUo8FgBbPP5Q429mtjTCklJrHpbnplvP8CS6dH2McNWzayw6vqZcCSkLMCCEPweEfVPMElqKXq73nrMKCU9w9ToO+YvZ2ktwQJEjn5aiKwmwoVlcwrvxuslII213XO4/aqVAyf/zw0/4fdSj/4/FsQPuRf6tlpdPaN/FkB0xDa9O0srJu9JQMX4lAfoF8QQidhpEBIOKHFnppBT4guH3GIOvdHaVZMESRuADIfG6WSeJqDsmS9tsA/QsbGvhOO5m1ntaepPTIh4IifsBsCujBHUpUemzaj2o02UOA9w5M6um0+nWxOjA8HSeRT3oC4r7GZtShqhXkaUOJ8rotLUGaPAUxB7zWKcR7YvL0kFbAAOCeNO88lCa3ondlk7ORoB+QexExBOZoKAhRZZaLQG6gyuXuZn7urlQ0aC54oNzEWvUw4MQDDcFGNw1xSW15DPJkd8Hc8UXhKgv2L6dMaafLfXk0qvIEcfhWa8QzYRpuMe8ahFBZ0yOfFsWYEAIHwGEXVPZrmhcVxOudfGgnmwEcS9DPDDlkKOKHNldFqBfEH9GxFcMgDXInqawegH0Cu1vcci+y2xD+iUmS69aAbyFiC36IlVTOxIjV3qr8dh0mnoBDITa1gNwF6cADsdkaXH5EA2J98zul6qmFxerLbkMjDsiYlfudaYWBtHPvUTUZXUt0ms2z3O3pjLpmCJLzRYAw5TNoNFxr1UvJJBjkFoAy+dB95WoNL8s3+blgUCD978HOkfyEmdBFg2EKgM40x6EygFWFqJ2vVavPZgfojCmyJHyIeoXxLmdZOZ8mZjzhd63qG0H47hvHs2jGm2LyVJ32TLxKB+2U5PUOv1mX/Q+OO26tDV2WzplN1uWWlePLOoXwu8iQsZjdq9L+to5f+Et0rLYGB8Z+MGJF2vtQV+w7Q3GOGMWojeCK2pZ6ET5TScaVGTJWdNJEHcyRKMrN+NNJ12Jwrah/XlAUU8/aBtqsTi+5Kxt+MBY+gCoqrahrmRh4xfWT9yJXHYSqk5pvcG2Fxlyvzpu/GYUmV2teyM38NylmrXudYjuBatWuHn+0qwcvqjqC8k7V6+ViwrL6ZJOrLcFGLDTeeMzVDdMRK/ITkPODr3+goNj7Hze+Ay0LRNy/1krelsAjdqYkwWN1GwMQGFjvfeksecYd7auA1DTSsVH2PRhXJaOO5lblPAC7xPE7Xkj83qOsE0ljC4W4Im8RwhAQ5qm7XF6GMga0iji7FDBIwSgbXbCsuxh2yqmzcTjcrlOF39Goh2LQeICyIPjdnhl1wjLGv3g2YDAdhR9RpJKbbFKKMXk2d6DhcRTD4EQ9iCAp+C/+RAIaZADGFPTMJxQJw3QHr6hkeegJQ3QhITLZt1DoFwwmRMP7K3LU64kHCw12LQbHQ48mC9CL8KMY28zgE7Hj/HS2imrfuxDB5grUL80u9C1FgGfzz6nBAwAQpOxjmCMgHKeU9LlFKX6pk+G7IJwXOhrIWimeNQsRGcKgJXcxwCtLDTb//8PKADXZlfSrGkAAAAASUVORK5CYII=",
  _e =
    "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADgAAAA4CAYAAACohjseAAAAAXNSR0IArs4c6QAAC4NJREFUaEPtWnlwW8UZ/3b37XuSbMuSfMgyoWPLVxJoJhzhzgy0QCgQjgIDbaHcJNMOaYEWppSrlJYQQsoAQ7kGQoByhqMdoBQGKFDSAQolkDg2kp1y+MnxIfmS9K7dzj7pObKRLNkJwTDZv6w9vu/7fffuM4Jv+UDfcnywG+A33cK7LVjAghL4FpZDol8D+Dw1m608XQviyrqmSwmyziHAqzgC0+LkjRQoV6bV9v/NRqDTAUj9oYa1FFk/nnyIAU6kuHzIqPpJ+2wDWSLA/ag/FL9fRsaZDgAOMCEFM467kyY6ZKxva2w2gSwB4JfBmYxsMDi9HWP2PRnpFzhEDE5eGFS3nggAZnGQDS4Ier2QskwY3jQCAEbxM9PfUQRgHnBcemVAI6fAYGQYAEhVfeOzEpjHC9bCqgZXVsbVyG+mFCXYVFuFrdcx4vM4QIJzNMQBdVpcesUC+vxobPOm6UPJf2IqgMQfarxfRuZPnaPmRHCZ6frW6mrQ3yZgtdggOZhJcJ0+qn7ydCEhvfWtZ7gg9Wg+5hyQZnLyus7kVaO9Ha/uKNCCACtDLRcpKH23syEvuCz3stq2BR6SfhMj5hVTIumkQTl4pKdzSz4B3YGmPT2K9RZB7DsZu0+MZ0dRBqdPxQGvgFikb6ZACwFEgfqG9ylYCwVhk5FXB3Tp5Kxb5uXlDTWf6QLtAYRAss9w0j6gSQcVPBNcUOZhyVZMJC8C1kDBPBxhtoSAFcoVyuLk0ySSTkr2RD6YCcj8AAPN3mrF6CSIBRkgGGLyXnossrkYA1+oeY2CtEucfTqnd8fVruXFzm1fb3B5g/SHFBtXS8ia68wLj9CYcvRwrPPd0mllduYH6A9XVrusjgxADH2g1EBPZ39x4vvRQGjgbxRZS2xX5Wi0b9TTACNbBgqcpXmz55w5bp8l30DBWIGzHmEBHtJ09wEj/Vs6i8uxfUchF5WqQw0dBFlhBgCjzH1gKtb5TimEK2paF7to6g2czarDhntxuq/zrQlna+aXB6T0OozYAgZojDH0nsXlZ0d68UsAm3Vnb2VteLlCjNUIQVnW7T8a0KTDpgqVyTIWTDL++vBfZTCWigNprlw5pEZuLAlgsPl8N9HuE4SFeydN18KxbZ0f5p6trGs+VcHak7nMRaphIG1MWeiysd6uV5z9vmDTxTLRb3P2iuwaj0WvKEWWwi4KAJWhlmUKSt8lCJtc+nhA7d6nWAGvqG071C2lXkbA3bbGgUQHejzzc60i5iuqWucqsvYORqxisoY5oKTO6DWJWPQWB4Q/FH7I6aKE2w+bdB+tLxopBWThOljdVl9N0+0EMa/QbporxwyrkZcKEfUGmw9SiP4CBu7PxB9YGqcnDMe6Xsh3xhVsCSuAFgFhjYRbx0vIPNQRhnEwdZB/NqRG7xVn3VWte5Qp2scEmE/81rhya0KNjCezqYBO2ckE6sOPUjDOEAQMLv1rUO1enA2tCTS9da2LFKz9A2cFEArRmHzFUCy6qhQti2TnqWs5tgxrazHwaltBgJJJy3PQWO+Wj8Rvf114pYwN2zUtwJ/396AWgK3pYvSnBOgJte1fBsl/YwTEtiJzHzsc63wxl6iwRDnR3iXAA868zuTb47HoimLMJ6+XB+ft7SZjb2LgtqUMkJ8Y7ImeLv4ur5u/lxuNfogRt2VJgXvxSM+k5JWHYdFmOxAKP0WRcUo2i20aUGH/XM35Qs2XKEhb49A2OH1mUO06zVb0DIagJyNtTSZJ4dRourI1NbjxcwCQqkINH0rImp9108sSamScbyFWRQHaWsVjGzDi5dlm+sp4Tkb1hObtW47GNiDgclYJWwY06cDppPIJwvnDlVUuKyohVmVbirnPGYl1Pij2BELhJygyhPLAAOnBwZ7uc4rpsCjAjP83rZKx/utM8kCjSeY5xImNDOOmeynSL3CYaSDfkuiJ/qoY80LrgVDjGxSZIt5BY8q1iVjk+qwcN8lYvzwL8OXBnu6ji/EoCSDYrZv5X4KsRps4J28Pqp4jnPRfXtdc40bmJoysGrHOAelJ5j5mNNbxWjEB8q37Q+GHZWT8JOOK9E8JtetS8bevrukyBeurdz5AACirbTnKQ9IvOgnHAPnmeE/U1qYY3mDrGS6ceiin2f50ALv2hS8KtmkFsVfUNh2qSObjnCMjbSknjm3r2Cg2i4RWho3nEUCZzvHyQiUol3BpFsye8IXCtyrI+EXWSlqa0ZOHY9HxrJqr+aylxQ3/pJnd1ue4AVwMIKJN1MR8EesywObRUrxjWgABGlyBELxOkXWgHY+A+kcs9wHp3o5um5mdINgGCVnzxuORS7cl1G5bKV/HmCZAgMpgS5gS/V0CzK57Ficf9KfxERDvGhK/K+pb57pA25Bb9HVGr0vEun73jQBox1uo6RgXMp5zSoPOpefiavepTq/qrQsf58Lmk05Pyjk3Ne66aigWuWlXg5y2BR0BRUaTsb56vMufdLn1hhrPdIG5FiEgmZgFMDI3AfEgJW5hUw0MtXvXKMzwaZYRc7xjJsqZMUA75ELhP8vIsG/sNoBJmdUfCi+nYNyRC9Lk9KlBDZ9fqBHw1LUuciFjDUFsEQBXOEdxk0uPJHT025k0DzsEUDwbBkKNj1Jk2t2FAKkz5fpELHKto237rQbp9zjuKuZNjj9OgefspNr+fq5VvHXhYxVkPoERty+4uUPEumYoPxrp7+iYjiV3FCBAMFgWwO5nKLKOskFyMDVQrh1SI38cB1kXPk7B1sNO4hHzoiMyQL4moVbeAfAfoyLYfIKb6I85ihDrHHCSIKvWoWMBHtSZctZwrDPvFSwf8B0HKKgGmr1VLmu9BOaR2+ONrorHusZv3uKSK8va0xJi4yVEWNzk5G3Opb9QrN/sgLMY3jhiuk/TzPQ2vxvfSJGxPPeuaHDlhkQs8vsSYnknfuGtmFtVVZ76u4TY/ttjkt4Z7+m6eFwQf7gy4IZbJW6c5cSls9cBYDGyMWV5loz1bR7/xuGrb1ohg7FyPCvbiqHPDKbYeZDYmpjKZXeOBbMcyoNNtQq2HpeQdbjDVGf0sbjluhD6tnceFfVNJylg3kmAhSbEWR5wznpZsOVIN9Efd+pvJpZJu2lJS4e2RaKFQO5UgDYT4a6KtV5CGXcVw+DkzbThPj3Z366OC+Jr8Pnc5DqKjIuEZRgn76dMz3G5lpsstLcm3EIltl5C1ndz4vKLsbR0cGow+tlXF4OTKdfUlPtJ+SMyNk8YF0S8UINySlLteC93u7hvEmTMG9LhpZLKgGgH3fwhCUz7xU8Mncv3xNXosl0HMMNJ8oea7qBIX7Y9QaBRndFLh3ozj0k7MCR/XePTMs6ANDn5dED1tEx+vRNrO99FJ0ntr2++QuLaH8Q1SyxlXgXow3EN/7wkixXQQmVd0+UurNutn8VJb7/pac6Nc+fYVw5QMKoINi91EWNdbh20OOlOc+X8mVyKRSwq1PwnBm4nKZNL7w2o3Qfke/HbJQBtkNVtbTLVHpGQtZ+jXfEt0ODSA3EkXV3atw8AAU6m1msE2B6OR6SY69yR2Cdrd3UMfplfdVuFXzZWUm4sy62DwsUMJl011CuvyxdHDqHJ4MS8AXTtYE/XuYXieZdZMFcA0XNSxO6SkLXndmuKWJI+MoCsGlbT6yf//00+cLqIZbXr7Kk6mq8FoA3K1+Dzu/ANFJsXOvdKx+UsIJ9ZDD3LgL6oc95BgeylkORdBHi9o5BSwO2SLFqsFJTVzF+oSKmVBMzvO98Cc63KAQES73Q5hEoFNysAOnJX1LceRrn5SwLmEoR4eT7XypQYeV1cjZ5X6sv51+eiBUzrDiyYI8vJpRhbP8CcL0DAXaJcM4RUi9M7h9TO+/KVg1mVZIq5bc46BX/YA4Qy6O8Qz4SZf8mYxph1FpyG7CVt3Q2wJDXN4k27LTiLjVOSaP8HbvT+dcz+ixMAAAAASUVORK5CYII=",
  te =
    "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAAAXNSR0IArs4c6QAAAfFJREFUSEvNlLFrFFEQh7+5y2kMMYiaJsTKVFbRUiwE8R9QsbYMiIUQcklsXuPd7TUWImgjprAJCSksbTWtou3FxhCQBBGVi/HgRt7ubbLre7vZVQu3ecXO/L73m3kzQpkv0DdheF3OF02TooFhXKA6ABTOKxz4bwB39CgTnGGLjzyUPcddnoOGjlPhJn2WWZTtODftoKlTVDgHfGOTdQeSBYjEVxCmUBrMyyM/wDqY5CJw3AvxAdLiHfrcyHZgsXmQlvbCm81LLTwPEbch/ib/DtnlNUZ+0tJLA8ArjJ5kmLVBWZyb+0uU7GoSUmWdWdlJNb2pl6nwHCVTPNtBrGT0CKOMOeLxfwvZ4x1GPmfNU7k5KDWVUbAQ6DWE057cPj1ecE8+5ere12lqPAaGnLg+74WmXqfKqb8CDPEEoeoH/IHtMin5PTA6gl0eC9Lxirb1Al06GPlavslGRznGLZRxlCUW5ENKxIqDATapschd+eKD+B0kxYVtdnmKkS5tPRuKzMkGRscYoQVM5kFcgCv+DCPfQ+FAoyVWl9vh+UBP0KORB0kD8sStYFvtc7QOZvbLcQgkDYh2zVWishzcPFbzAVwnS8zJapziOhhmmh+83S9LsnNZgAPIFbq8TL6qcqsiD5DxTv8zQKD1wSsKik7zLzx24mX4HVKOAAAAAElFTkSuQmCC",
  $e =
    "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAAAXNSR0IArs4c6QAAAtVJREFUSEu1VltIFGEYPWfWVg0zg4IV96JgL1GgpM4SBQX2FriCgZFSL0FvBQnpQ0+9CBYUBD0WpCgktFFvBvUgtdMFgyCEgtqLKBR0Eylx5ot/Zte9ODtuYPM4e+Y75zvfbQmPR9obI6je1g+gG8L9IAI2XLAEymsAs6A1zheZhXJh6PaDHGqMwPSPgtIHsMpLBCBrEE7DtzrM54vJUuwGAukKn4GGWwDrHLB8hGAawBvQ+uq80nYDOAhCCWjN4pYB6zwTmYlCkiIC0cMXQN7IAuZhWSN8mY572tgVikHj2DqRyEUaqZu5b9YJHOW8m/U4jl8rg3z/ZbkweBazxkSySKXs21OHHdvvgYg5eHMgl4lNINFAM+B/Z9siiNNI9paqlraGBtTs/Ga///1jF99+/74BEw0/AngCkGVg9QATS58dAj0yCUJ1yzx+rnSWKs+LqP7kBP3Toj7eQKAyqa+ds+0SGaeRGqS0BZpR4/9gd4tl9Zbz3MnSm8AWYtdEe+B0l9lCiYYvAxxV3cJEam+5glZK4GQbVoJbARlWBDMAuyEySiM1siUEemgM1IYAeUzRI4v2hIqcpJFS/e76/FMGergP5H018ZRoRJzWlCM0UrNbQhANHgV8T1WsPAHMY0xknm09wX+xKNQPapNZiyosMlAFPZK2MzSSIQJrZbMtKnKFbWqXSQ2S8rVkhbhMdEGbFg6aWDEa6Yceyi7ZBEb6ugemB9Ti64NW8aroDHfDxxk7sCnH+Sr1pKJVkd8zmyw7vSkI+OacoGY7jYWMizXuy84m6QydhU+748wE3Ne1KrSyqKTAdm3qayedTaq+t07RSE9lsXkdxQdHXTIZ8qqJY2+oB+S1TQ9Ojkb04ACo3S4+mRIHtAQ0M3syGYCgA2Ss6GSKnMspz8VzP/pqNYv/qnMjKjn6mAJXr7jdCFeCfDZNQdB3GsBhCDtc/7aIOeFW8FyMvyuHj8xzTcYyAAAAAElFTkSuQmCC",
  et = { class: "header flex items-center px-[22px] py-4" },
  tt = { class: "mx-3 flex-1 text-xs" },
  st = { class: "flex items-center" },
  ot = { class: "max-w-[30vw] truncate text-base" },
  nt = {
    key: 0,
    class:
      "ml-3 flex h-[22px] w-[76px] items-center justify-center rounded-md bg-[#F2F8FF]",
  },
  at = ["src"],
  ct = { class: "ml-0.5 text-xs text-primary" },
  rt = {
    key: 1,
    class:
      "ml-3 flex h-[22px] w-[76px] items-center justify-center rounded-md bg-[#F2F8FF]",
  },
  it = ["src"],
  lt = { class: "ml-0.5 text-xs text-primary" },
  ut = {
    key: 2,
    class:
      "ml-3 flex h-[22px] w-[76px] items-center justify-center rounded-md bg-[#FFE1DD]",
  },
  At = ["src"],
  dt = { class: "ml-0.5 text-xs text-error-text" },
  gt = { class: "flex" },
  mt = ["src"],
  ft = ["src"],
  ht = V({
    __name: "ConversationHeader",
    setup(t) {
      const { t: A, locale: s } = ie(),
        o = [
          { text: A("scanQr"), icon: Xe },
          { text: A("addFriend"), icon: Ne },
          { text: A("addGroup"), icon: je },
          { text: A("launchGroup"), icon: Ze },
        ];
      ne(s, () => {
        (o[0].text = A("scanQr")),
          (o[1].text = A("addFriend")),
          (o[2].text = A("addGroup")),
          (o[3].text = A("launchGroup"));
      });
      const r = we(),
        f = X(),
        h = k(!1),
        n = k(1),
        g = () => (n.value = 0),
        x = () => (n.value = 1),
        l = () => (n.value = 2);
      De(() => {
        F.on(G.OnConnecting, g),
          F.on(G.OnConnectSuccess, x),
          F.on(G.OnConnectFailed, l);
      }),
        Ee(() => {
          F.off(G.OnConnecting, g),
            F.off(G.OnConnectSuccess, x),
            F.off(G.OnConnectFailed, l);
        });
      const v = (C, p) => {
        switch (p) {
          case 0:
            f.push("scanPage");
            break;
          case 1:
          case 2:
            f.push({
              path: "searchToJoin",
              query: { isGroup: String(p === 2) },
            });
            break;
          case 3:
            f.push({
              path: "createGroup",
              query: { groupType: Be.WorkingGroup },
            });
            break;
        }
      };
      return (C, p) => {
        const E = Me;
        return (
          S(),
          M("div", et, [
            m(
              le,
              {
                size: 48,
                src: d(r).storeSelfInfo.faceURL,
                desc: d(r).storeSelfInfo.nickname,
              },
              null,
              8,
              ["src", "desc"]
            ),
            u("div", tt, [
              u("div", st, [
                u("div", ot, b(d(r).storeSelfInfo.nickname), 1),
                d(r).isSyncing
                  ? (S(),
                    M("view", nt, [
                      u(
                        "img",
                        { class: "loading h-3 w-3", src: d(te), alt: "" },
                        null,
                        8,
                        at
                      ),
                      u("text", ct, b(C.$t("syncing")), 1),
                    ]))
                  : Y("", !0),
                n.value === 0
                  ? (S(),
                    M("view", rt, [
                      u(
                        "img",
                        { class: "loading h-3 w-3", src: d(te), alt: "" },
                        null,
                        8,
                        it
                      ),
                      u("text", lt, b(C.$t("connecting")), 1),
                    ]))
                  : Y("", !0),
                n.value === 2
                  ? (S(),
                    M("view", ut, [
                      u(
                        "img",
                        { class: "h-3 w-3", src: d($e), alt: "" },
                        null,
                        8,
                        At
                      ),
                      u("text", dt, b(C.$t("connectFailed")), 1),
                    ]))
                  : Y("", !0),
              ]),
            ]),
            u("div", gt, [
              // u(
              //   "img",
              //   { src: d(_e), alt: "call", width: "24", class: "mr-2" },
              //   null,
              //   8,
              //   mt
              // ),
              m(
                E,
                {
                  "show-arrow": !1,
                  show: h.value,
                  "onUpdate:show": p[0] || (p[0] = (R) => (h.value = R)),
                  actions: o,
                  placement: "bottom-end",
                  onSelect: v,
                },
                {
                  reference: U(() => [
                    u(
                      "img",
                      { src: d(qe), alt: "add", width: "24" },
                      null,
                      8,
                      ft
                    ),
                  ]),
                  _: 1,
                },
                8,
                ["show"]
              ),
            ]),
          ])
        );
      };
    },
  });
const Ct = P(ht, [["__scopeId", "data-v-1610f4e5"]]);
const pt = { key: 0, class: "pinned" },
  vt = { class: "mx-3 flex h-12 flex-1 flex-col justify-evenly" },
  xt = { class: "max-w-[40vw] truncate text-[15px]" },
  St = { class: "max-w-[40vw] truncate text-[13px] text-[#666]" },
  wt = { class: "w-max" },
  Dt = ["src"],
  Et = V({
    __name: "ConversationListItem",
    props: { source: null },
    emits: [],
    setup(t, { emit: A }) {
      const s = t,
        o = X(),
        { t: r } = ie(),
        f = ue(),
        h = Te.includes(s.source.conversationType),
        n = s.source.conversationType === _.Notification,
        g = s.source.recvMsgOpt !== $.Nomal,
        x = H(() => {
          if (s.source.draftText) {
            const T = new DOMParser().parseFromString(
              s.source.draftText,
              "text/html"
            );
            return (
              T.querySelectorAll("b.at_el").forEach((i) => {
                const w = i.textContent,
                  J = i.parentNode;
                J == null || J.replaceChild(document.createTextNode(w), i);
              }),
              T.body.innerHTML
            );
          }
          let c;
          try {
            c = JSON.parse(s.source.latestMsg);
          } catch {}
          return c ? ye(c) : "";
        }),
        l = H(() => be(s.source.latestMsgSendTime)),
        v = H(() => {
          var B;
          if (s.source.draftText) return r("messageDesc.drftMessage");
          let c = "";
          if (
            (((B = s.source) == null ? void 0 : B.recvMsgOpt) !== $.Nomal &&
              s.source.unreadCount > 0 &&
              (c = r("pieces", { number: s.source.unreadCount })),
            s.source.groupAtType !== I.AtNormal)
          )
            switch (s.source.groupAtType) {
              case I.AtAll:
                c = r("messageDesc.atAll");
                break;
              case I.AtMe:
                c = r("messageDesc.atYou");
                break;
              case I.AtAllAtMe:
                c = r("messageDesc.atYou");
                break;
              case I.AtGroupNotice:
                c = r("messageDesc.groupAnnouncement");
                break;
            }
          return c;
        }),
        C = H(() => s.source.groupAtType !== I.AtNormal || s.source.draftText),
        p = () => {
          f.updateCurrentConversation(s.source);
          let c = "chat";
          s.source.conversationType === _.Notification &&
            (c = "notifyMessageList"),
            o.push(c);
        },
        E = () => {
          F.pinConversation({
            conversationID: s.source.conversationID,
            isPinned: !s.source.isPinned,
          }).catch((c) => z({ error: c }));
        },
        R = () => {
          F.deleteConversationAndDeleteAllMsg(s.source.conversationID)
            .then(() => f.delConversationByCID(s.source.conversationID))
            .catch((c) => z({ error: c }));
        },
        O = () => {
          F.markConversationMessageAsRead(s.source.conversationID).catch((c) =>
            z({ error: c })
          );
        };
      return (c, B) => {
        const T = Oe,
          e = Ge,
          i = We;
        return (
          S(),
          L(i, null, {
            right: U(() => [
              m(
                e,
                {
                  color: "#1B72EC",
                  text: c.$t(
                    t.source.isPinned ? "buttons.cancelPin" : "buttons.pin"
                  ),
                  onClick: E,
                },
                null,
                8,
                ["text"]
              ),
              m(
                e,
                { color: "#FF381F", text: c.$t("buttons.remove"), onClick: R },
                null,
                8,
                ["text"]
              ),
              t.source.unreadCount > 0
                ? (S(),
                  L(
                    e,
                    {
                      key: 0,
                      color: "#8E9AB0",
                      text: c.$t("buttons.markAsRead"),
                      onClick: O,
                    },
                    null,
                    8,
                    ["text"]
                  ))
                : Y("", !0),
            ]),
            default: U(() => [
              u(
                "div",
                {
                  onClick: p,
                  class:
                    "flex items-center py-[10px] px-[22px] active:bg-[#F3F3F3]",
                },
                [
                  t.source.isPinned ? (S(), M("div", pt)) : Y("", !0),
                  m(
                    le,
                    {
                      size: 48,
                      src: t.source.faceURL,
                      desc: t.source.showName,
                      "is-group": d(h),
                      "is-notification": n,
                    },
                    null,
                    8,
                    ["src", "desc", "is-group"]
                  ),
                  u("div", vt, [
                    u("div", xt, b(t.source.showName), 1),
                    u("div", St, [
                      Fe(
                        u(
                          "span",
                          { class: ee(["mr-1", { "text-[#1B72EC]": d(C) }]) },
                          b(d(v)),
                          3
                        ),
                        [[Re, d(v)]]
                      ),
                      u("span", null, b(d(x)), 1),
                    ]),
                  ]),
                  u(
                    "div",
                    {
                      class: ee([
                        "flex h-12 flex-col items-end text-xs text-[#999]",
                        { "justify-evenly": g || t.source.unreadCount > 0 },
                      ]),
                    },
                    [
                      u("span", wt, b(d(l)), 1),
                      g
                        ? (S(),
                          M(
                            "img",
                            { key: 0, class: "h-4 w-4", src: d(Je), alt: "" },
                            null,
                            8,
                            Dt
                          ))
                        : (S(),
                          L(
                            T,
                            {
                              key: 1,
                              class: "w-fit",
                              color: "#F44038",
                              content: t.source.unreadCount,
                              max: "99",
                              "show-zero": !1,
                            },
                            null,
                            8,
                            ["content"]
                          )),
                    ],
                    2
                  ),
                ]
              ),
            ]),
            _: 1,
          })
        );
      };
    },
  });
const Bt = P(Et, [["__scopeId", "data-v-5736ff43"]]),
  Tt = V({
    __name: "ConversationList",
    emits: [],
    setup(t, { emit: A }) {
      const s = ue(),
        o = j({ loading: !1, pullLoading: !1, hasMore: !0 }),
        r = k(!1),
        f = async () => {
          o.hasMore &&
            !o.loading &&
            ((o.loading = !0),
            (o.hasMore = await s.getConversationListFromReq(!0)),
            (o.loading = !1));
        },
        h = (g) => {
          r.value = g.target.scrollTop > 0;
        },
        n = async () => {
          await s.getConversationListFromReq(), (o.pullLoading = !1);
        };
      return (g, x) => {
        const l = Le;
        return (
          S(),
          L(
            l,
            {
              modelValue: o.pullLoading,
              "onUpdate:modelValue":
                x[0] || (x[0] = (v) => (o.pullLoading = v)),
              disabled: r.value,
              onRefresh: n,
            },
            {
              default: U(() => [
                m(
                  d(Ve),
                  {
                    ref: "vsl",
                    class: "my_scrollbar h-full overflow-y-auto",
                    "data-key": "conversationID",
                    "data-sources": d(s).storeConversationList,
                    "data-component": Bt,
                    "estimate-size": 88,
                    onTobottom: f,
                    onScroll: h,
                  },
                  null,
                  8,
                  ["data-sources"]
                ),
              ]),
              _: 1,
            },
            8,
            ["modelValue", "disabled"]
          )
        );
      };
    },
  });
const Ft = P(Tt, [["__scopeId", "data-v-2f06546e"]]),
  Rt = { class: "flex h-full flex-col" },
  Ot = V({ name: "conversation" }),
  yt = V({
    ...Ot,
    emits: [],
    setup(t, { emit: A }) {
      const s = X(),
        o = () => {
          s.push("globalSearch");
        };
      return (r, f) => {
        const h = ke;
        return (
          S(),
          M("div", Rt, [
            m(Ct),
            m(
              h,
              {
                background: "#fff",
                readonly: "",
                placeholder: r.$t("placeholder.search"),
                onClickInput: o,
              },
              null,
              8,
              ["placeholder"]
            ),
            m(Ft),
          ])
        );
      };
    },
  });
const Yt = P(yt, [["__scopeId", "data-v-67b373a7"]]);
export { Yt as default };
