export const insetsToDom = (insets) => new DOMInsets(insets.left, insets.top, insets.right, insets.bottom);
export const domInsetsToJson = (domInsets) => ({
    left: domInsets.left,
    top: domInsets.top,
    right: domInsets.right,
    bottom: domInsets.bottom,
});
export class DOMInsets {
    constructor(left, top, right, bottom) {
        Object.defineProperty(this, "left", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: left
        });
        Object.defineProperty(this, "top", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: top
        });
        Object.defineProperty(this, "right", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: right
        });
        Object.defineProperty(this, "bottom", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: bottom
        });
    }
    toCss(options) {
        const { css_var_prefix, density } = formatInsetsToCssOptions(options);
        return [
            [`${css_var_prefix}left`, `${this.left / density}px`],
            [`${css_var_prefix}top`, `${this.top / density}px`],
            [`${css_var_prefix}right`, `${this.right / density}px`],
            [`${css_var_prefix}bottom`, `${this.bottom / density}px`],
        ];
    }
    toCssText(options) {
        return this.toCss(options)
            .map(([key, value]) => `${key}:${value};`)
            .join(" ");
    }
    setStyle(style, options) {
        for (const [key, value] of this.toCss(options)) {
            style.setProperty(key, value);
        }
    }
    effect(options) {
        const eleId = options.css_var_prefix?.concat("<<prefix") ?? options.css_var_name?.concat("<<name") ?? "default";
        let ele = document.getElementById(eleId);
        if (ele == undefined) {
            ele = document.createElement("style");
            document.head.appendChild(ele);
            ele.id = eleId;
        }
        let cssText = `:root {${this.toCssText(options)}}`;
        if (options.layer) {
            cssText = `@layer ${options.layer} {${cssText}}`;
        }
        ele.innerHTML = cssText;
    }
}
const formatInsetsToCssOptions = (options = {}) => {
    const css_var_prefix = options.css_var_prefix ?? (options.css_var_name ? `--${options.css_var_name}-inset-` : `--inset-`);
    const density = options.density ?? globalThis.devicePixelRatio;
    return { css_var_prefix, density };
};
