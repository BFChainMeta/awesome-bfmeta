export var UpdateControllerEvent;
(function (UpdateControllerEvent) {
    UpdateControllerEvent["start"] = "start";
    UpdateControllerEvent["progress"] = "progress";
    UpdateControllerEvent["end"] = "end";
    UpdateControllerEvent["cancel"] = "cancel";
})(UpdateControllerEvent || (UpdateControllerEvent = {}));
