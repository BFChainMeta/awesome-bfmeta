var I18N_1;
import { __decorate, __metadata, __param } from "../../tslib/modules/index.js";
///<reference lib="dom" />
import { Injectable, Inject, ModuleStroge, Resolve, } from "../dep_inject/index.js";
export const ERROR_CODE_LANG = Symbol("errorCodeLang");
let I18N = I18N_1 = class I18N {
    constructor(lang = "en_US.UTF-8" /* I18N_LANGUAGE_TYPE.ENGLISH */) {
        Object.defineProperty(this, "__lang", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "__store", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: new Map()
        });
        this.__checkLanguage(lang);
        this.__lang = lang;
    }
    static from(lang, moduleMap = new ModuleStroge()) {
        return Resolve(I18N_1, moduleMap.installMask(new ModuleStroge([[ERROR_CODE_LANG, lang]])));
    }
    __checkLanguage(lang) {
        if (lang !== "zh_CN.UTF-8" /* I18N_LANGUAGE_TYPE.CHINESE */ &&
            lang !== "en_US.UTF-8" /* I18N_LANGUAGE_TYPE.ENGLISH */) {
            throw new Error(`Invalid lang type ${lang}`);
        }
    }
    getErrorCodeList(uuid) {
        const errorCodeList = this.__store.get(uuid);
        if (!errorCodeList) {
            throw new Error(`Failed to get error code list by ${uuid}`);
        }
        return errorCodeList.sourceErrorCodeList;
    }
    formatErrorCodeList(sourceErrorCodeList, translatedErrorCodeListMap) {
        const errorCodeList = translatedErrorCodeListMap.get(this.__lang);
        if (!errorCodeList) {
            console.debug(`Translated error code list not found, language ${this.__lang}`);
            return sourceErrorCodeList;
        }
        for (const key in sourceErrorCodeList) {
            const errorInfo = sourceErrorCodeList[key];
            errorInfo.message = errorCodeList[errorInfo.code] || errorInfo.message;
        }
        return sourceErrorCodeList;
    }
    addErrorCodeList(uuid, sourceErrorCodeList, translatedErrorCodeListMap) {
        this.formatErrorCodeList(sourceErrorCodeList, translatedErrorCodeListMap);
        this.__store.set(uuid, {
            sourceErrorCodeList,
            translatedErrorCodeListMap,
        });
    }
    setLanguage(newLang) {
        if (this.__lang === newLang) {
            return;
        }
        this.__checkLanguage(newLang);
        this.__lang = newLang;
        for (const { sourceErrorCodeList, translatedErrorCodeListMap, } of this.__store.values()) {
            this.formatErrorCodeList(sourceErrorCodeList, translatedErrorCodeListMap);
        }
    }
};
I18N = I18N_1 = __decorate([
    Injectable(),
    __param(0, Inject(ERROR_CODE_LANG, { optional: true })),
    __metadata("design:paramtypes", [String])
], I18N);
export { I18N };
