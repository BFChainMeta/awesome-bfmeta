/**
 * 模块分类
 * 参考链接：
 * 1. https://developer.apple.com/library/archive/documentation/General/Reference/InfoPlistKeyReference/Articles/LaunchServicesKeys.html
 * 2. https://github.com/w3c/manifest/wiki/Categories
 */
export var MICRO_MODULE_CATEGORY;
(function (MICRO_MODULE_CATEGORY) {
    //#region 1. Service 服务
    /** 服务大类
     * > 任何跟服务有关联的请填写该项，用于范索引
     * > 服务拥有后台运行的特征，如果不填写该项，那么程序可能会被当作普通应用程序被直接回收资源
     */
    MICRO_MODULE_CATEGORY["Service"] = "service";
    //#region 1.1 内核服务
    /** 路由服务
     * > 通常指 `dns.std.dweb` 这个核心，它决策着模块之间通讯的路径
     */
    MICRO_MODULE_CATEGORY["Routing_Service"] = "routing-service";
    /** 进程服务
     * > 提供python、js、wasm等语言的运行服务
     * > 和 计算服务 不同，进程服务通常是指 概念上运行在本地 的程序
     */
    MICRO_MODULE_CATEGORY["Process_Service"] = "process-service";
    /** 渲染服务
     * > 可视化图形的能力
     * > 比如：Web渲染器、Terminal渲染器、WebGPU渲染器、WebCanvas渲染器 等
     */
    MICRO_MODULE_CATEGORY["Render_Service"] = "render-service";
    /** 协议服务
     * > 比如 `http.std.dweb` 这个模块，提供 http/1.1 协议到 Ipc 的映射
     * > 比如 `bluetooth.std.dweb` 这个模块，提供了接口化的 蓝牙协议 管理
     */
    MICRO_MODULE_CATEGORY["Protocol_Service"] = "protocol-service";
    /** 设备管理服务
     * > 通常指外部硬件设备
     * > 比如其它的计算机设备、或者通过蓝牙协议管理设备、键盘鼠标打印机等等
     */
    MICRO_MODULE_CATEGORY["Device_Management_Service"] = "device-management-service";
    //#endregion
    //#region 1.2 基础服务
    /** 计算服务
     * > 通常指云计算平台所提供的服务，可以远程部署程序
     */
    MICRO_MODULE_CATEGORY["Computing_Service"] = "computing-service";
    /** 存储服务
     * > 比如：文件、对象存储、区块存储
     * > 和数据库的区别是，它不会对存储的内容进行拆解，只能提供基本的写入和读取功能
     */
    MICRO_MODULE_CATEGORY["Storage_Service"] = "storage-service";
    /** 数据库服务
     * > 比如：关系型数据库、键值数据库、时序数据库
     * > 和存储服务的区别是，它提供了一套接口来 写入数据、查询数据
     */
    MICRO_MODULE_CATEGORY["Database_Service"] = "database-service";
    /** 网络服务
     * > 比如：网关、负载均衡
     */
    MICRO_MODULE_CATEGORY["Network_Service"] = "network-service";
    //#endregion
    //#region 1.3 中间件服务
    /** 聚合服务
     * > 特征：服务编排、服务治理、统一接口、兼容转换
     * > 比如：聚合查询、分布式管理
     */
    MICRO_MODULE_CATEGORY["Hub_Service"] = "hub-service";
    /** 分发服务
     * > 特征：减少网络访问的成本、提升网络访问的体验
     * > 比如：CDN、网络加速、文件共享
     */
    MICRO_MODULE_CATEGORY["Distribution_Service"] = "distribution-service";
    /** 安全服务
     * > 比如：数据加密、访问控制
     */
    MICRO_MODULE_CATEGORY["Security_Service"] = "security-service";
    //#endregion
    //#region 分析服务
    /** 日志服务 */
    MICRO_MODULE_CATEGORY["Log_Service"] = "log-service";
    /** 指标服务 */
    MICRO_MODULE_CATEGORY["Indicator_Service"] = "indicator-service";
    /** 追踪服务 */
    MICRO_MODULE_CATEGORY["Tracking_Service"] = "tracking-service";
    //#endregion
    //#region 人工智能服务
    /** 视觉服务 */
    MICRO_MODULE_CATEGORY["Visual_Service"] = "visual-service";
    /** 语音服务 */
    MICRO_MODULE_CATEGORY["Audio_Service"] = "audio-service";
    /** 文字服务 */
    MICRO_MODULE_CATEGORY["Text_Service"] = "text-service";
    /** 机器学习服务 */
    MICRO_MODULE_CATEGORY["Machine_Learning_Service"] = "machine-learning-service";
    //#endregion
    //#endregion
    //#region 2. Application 应用
    /** 应用 大类
     * > 如果存在应用特征的模块，都应该填写该项
     * > 应用特征意味着有可视化的图形界面模块，如果不填写该项，那么应用将无法被显示在用户桌面上
     */
    MICRO_MODULE_CATEGORY["Application"] = "application";
    //#region 2.1 Application 应用 · 系统
    /**
     * 设置
     * > 通常指 `setting.std.dweb` 这个核心，它定义了一种模块管理的标准
     * > 通过这个标准，用户可以在该模块中聚合管理注册的模块
     * > 包括：权限管理、偏好管理、功能开关、主题与个性化、启动程序 等等
     * > 大部分 service 会它们的管理视图注册到该模块中
     */
    MICRO_MODULE_CATEGORY["Settings"] = "settings";
    /** 桌面 */
    MICRO_MODULE_CATEGORY["Desktop"] = "desktop";
    /** 网页浏览器 */
    MICRO_MODULE_CATEGORY["Web_Browser"] = "web-browser";
    /** 文件管理 */
    MICRO_MODULE_CATEGORY["Files"] = "files";
    /** 钱包 */
    MICRO_MODULE_CATEGORY["Wallet"] = "wallet";
    /** 助理
     * > 该类应用通常拥有极高的权限，比如 屏幕阅读工具、AI助理工具 等
     */
    MICRO_MODULE_CATEGORY["Assistant"] = "assistant";
    //#endregion
    //#region 2.2 Application 应用 · 工作效率
    /** 商业 */
    MICRO_MODULE_CATEGORY["Business"] = "business";
    /** 开发者工具 */
    MICRO_MODULE_CATEGORY["Developer"] = "developer";
    /** 教育 */
    MICRO_MODULE_CATEGORY["Education"] = "education";
    /** 财务 */
    MICRO_MODULE_CATEGORY["Finance"] = "finance";
    /** 办公效率 */
    MICRO_MODULE_CATEGORY["Productivity"] = "productivity";
    /** 消息软件
     * > 讯息、邮箱
     */
    MICRO_MODULE_CATEGORY["Messages"] = "messages";
    /** 实时互动 */
    MICRO_MODULE_CATEGORY["Live"] = "live";
    //#endregion
    //#region 2.3 Application 应用 · 娱乐
    /** 娱乐 */
    MICRO_MODULE_CATEGORY["Entertainment"] = "entertainment";
    /** 游戏 */
    MICRO_MODULE_CATEGORY["Games"] = "games";
    /** 生活休闲 */
    MICRO_MODULE_CATEGORY["Lifestyle"] = "lifestyle";
    /** 音乐 */
    MICRO_MODULE_CATEGORY["Music"] = "music";
    /** 新闻 */
    MICRO_MODULE_CATEGORY["News"] = "news";
    /** 体育 */
    MICRO_MODULE_CATEGORY["Sports"] = "sports";
    /** 视频 */
    MICRO_MODULE_CATEGORY["Video"] = "video";
    /** 照片 */
    MICRO_MODULE_CATEGORY["Photo"] = "photo";
    //#endregion
    //#region 2.4 Application 应用 · 创意
    /** 图形和设计 */
    MICRO_MODULE_CATEGORY["Graphics_a_Design"] = "graphics-design";
    /** 摄影与录像 */
    MICRO_MODULE_CATEGORY["Photography"] = "photography";
    /** 个性化 */
    MICRO_MODULE_CATEGORY["Personalization"] = "personalization";
    //#endregion
    //#region 2.5 Application 应用 · 实用工具
    /** 书籍 */
    MICRO_MODULE_CATEGORY["Books"] = "books";
    /** 杂志 */
    MICRO_MODULE_CATEGORY["Magazines"] = "magazines";
    /** 食物 */
    MICRO_MODULE_CATEGORY["Food"] = "food";
    /** 健康 */
    MICRO_MODULE_CATEGORY["Health"] = "health";
    /** 健身 */
    MICRO_MODULE_CATEGORY["Fitness"] = "fitness";
    /** 医疗 */
    MICRO_MODULE_CATEGORY["Medical"] = "medical";
    /** 导航 */
    MICRO_MODULE_CATEGORY["Navigation"] = "navigation";
    /** 参考工具 */
    MICRO_MODULE_CATEGORY["Reference"] = "reference";
    /** 实用工具 */
    MICRO_MODULE_CATEGORY["Utilities"] = "utilities";
    /** 旅行 */
    MICRO_MODULE_CATEGORY["Travel"] = "travel";
    /** 天气 */
    MICRO_MODULE_CATEGORY["Weather"] = "weather";
    /** 儿童 */
    MICRO_MODULE_CATEGORY["Kids"] = "kids";
    /** 购物 */
    MICRO_MODULE_CATEGORY["Shopping"] = "shopping";
    /** 安全 */
    MICRO_MODULE_CATEGORY["Security"] = "security";
    //#endregion
    //#region 2.6 Application 应用 · 社会
    /** 社交网络 */
    MICRO_MODULE_CATEGORY["Social"] = "social";
    /** 职业生涯 */
    MICRO_MODULE_CATEGORY["Career"] = "career";
    /** 政府 */
    MICRO_MODULE_CATEGORY["Government"] = "government";
    /** 政治 */
    MICRO_MODULE_CATEGORY["Politics"] = "politics";
    //#endregion
    //#endregion
    //#region 3. Game 游戏（属于应用的细分）
    /** 动作游戏 */
    MICRO_MODULE_CATEGORY["Action_Games"] = "action-games";
    /** 冒险游戏 */
    MICRO_MODULE_CATEGORY["Adventure_Games"] = "adventure-games";
    /** 街机游戏 */
    MICRO_MODULE_CATEGORY["Arcade_Games"] = "arcade-games";
    /** 棋盘游戏 */
    MICRO_MODULE_CATEGORY["Board_Games"] = "board-games";
    /** 卡牌游戏 */
    MICRO_MODULE_CATEGORY["Card_Games"] = "card-games";
    /** 赌场游戏 */
    MICRO_MODULE_CATEGORY["Casino_Games"] = "casino-games";
    /** 骰子游戏 */
    MICRO_MODULE_CATEGORY["Dice_Games"] = "dice-games";
    /** 教育游戏 */
    MICRO_MODULE_CATEGORY["Educational_Games"] = "educational-games";
    /** 家庭游戏 */
    MICRO_MODULE_CATEGORY["Family_Games"] = "family-games";
    /** 儿童游戏 */
    MICRO_MODULE_CATEGORY["Kids_Games"] = "kids-games";
    /** 音乐游戏 */
    MICRO_MODULE_CATEGORY["Music_Games"] = "music-games";
    /** 益智游戏 */
    MICRO_MODULE_CATEGORY["Puzzle_Games"] = "puzzle-games";
    /** 赛车游戏 */
    MICRO_MODULE_CATEGORY["Racing_Games"] = "racing-games";
    /** 角色扮演游戏 */
    MICRO_MODULE_CATEGORY["Role_Playing_Games"] = "role-playing-games";
    /** 模拟经营游戏 */
    MICRO_MODULE_CATEGORY["Simulation_Games"] = "simulation-games";
    /** 运动游戏 */
    MICRO_MODULE_CATEGORY["Sports_Games"] = "sports-games";
    /** 策略游戏 */
    MICRO_MODULE_CATEGORY["Strategy_Games"] = "strategy-games";
    /** 问答游戏 */
    MICRO_MODULE_CATEGORY["Trivia_Games"] = "trivia-games";
    /** 文字游戏 */
    MICRO_MODULE_CATEGORY["Word_Games"] = "word-games";
    //#endregion
})(MICRO_MODULE_CATEGORY || (MICRO_MODULE_CATEGORY = {}));
