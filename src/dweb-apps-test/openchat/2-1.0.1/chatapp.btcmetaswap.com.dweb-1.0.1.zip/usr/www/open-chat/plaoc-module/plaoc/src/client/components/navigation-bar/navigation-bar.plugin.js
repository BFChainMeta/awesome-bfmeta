var _a;
import { __decorate, __metadata } from "../../../../../../tslib/modules/index.js";
import { bindThis } from "../../helper/bindThis.js";
import { DOMInsets } from "../../util/insets.js";
import { BAR_STYLE } from "../base/BarPlugin.js";
import { BasePlugin } from "../base/BasePlugin.js";
import { windowPlugin } from "../index.js";
/**
 * 访问 navigation-bar 能力的插件
 */
export class NavigationBarPlugin extends BasePlugin {
    constructor() {
        super("window.sys.dweb");
    }
    async setState(state) {
        let bottomBarContentColor = undefined;
        switch (state.style) {
            case BAR_STYLE.Dark:
                bottomBarContentColor = "#000000";
                break;
            case BAR_STYLE.Light:
                bottomBarContentColor = "#FFFFFF";
                break;
            default:
                bottomBarContentColor = "auto";
        }
        windowPlugin.setStyle({
            bottomBarBackgroundColor: state.color,
            bottomBarContentColor,
            bottomBarOverlay: state.overlay,
        });
    }
    setStateByKey(key, value) {
        return this.setState({
            [key]: value,
        });
    }
    async getState() {
        const winState = await windowPlugin.getState();
        let style = BAR_STYLE.Default;
        switch (winState.bottomBarContentColor) {
            case "#FFFFFF":
                style = BAR_STYLE.Light;
                break;
            case "#000000":
                style = BAR_STYLE.Dark;
                break;
        }
        return {
            color: winState.bottomBarBackgroundColor,
            style,
            overlay: winState.bottomBarOverlay,
            visible: true,
            insets: new DOMInsets(0, 0, 0, 0),
        };
    }
    setColor(color) {
        return this.setStateByKey("color", color);
    }
    async getColor() {
        return (await this.getState()).color;
    }
    setStyle(style) {
        return this.setState({ style });
    }
    async getStyle() {
        return (await this.getState()).style;
    }
    setOverlay(overlay) {
        return this.setState({ overlay });
    }
    async getOverlay() {
        return (await this.getState()).overlay;
    }
    setVisible(visible) {
        return this.setState({ visible });
    }
    async getVisible() {
        return (await this.getState()).visible;
    }
    async show() { }
    async hide() { }
}
__decorate([
    bindThis,
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], NavigationBarPlugin.prototype, "setState", null);
__decorate([
    bindThis,
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [typeof (_a = typeof K !== "undefined" && K) === "function" ? _a : Object, Object]),
    __metadata("design:returntype", void 0)
], NavigationBarPlugin.prototype, "setStateByKey", null);
__decorate([
    bindThis,
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], NavigationBarPlugin.prototype, "getState", null);
__decorate([
    bindThis,
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], NavigationBarPlugin.prototype, "setColor", null);
__decorate([
    bindThis,
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], NavigationBarPlugin.prototype, "getColor", null);
__decorate([
    bindThis,
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], NavigationBarPlugin.prototype, "setStyle", null);
__decorate([
    bindThis,
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], NavigationBarPlugin.prototype, "getStyle", null);
__decorate([
    bindThis,
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Boolean]),
    __metadata("design:returntype", void 0)
], NavigationBarPlugin.prototype, "setOverlay", null);
__decorate([
    bindThis,
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], NavigationBarPlugin.prototype, "getOverlay", null);
__decorate([
    bindThis,
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Boolean]),
    __metadata("design:returntype", void 0)
], NavigationBarPlugin.prototype, "setVisible", null);
__decorate([
    bindThis,
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], NavigationBarPlugin.prototype, "getVisible", null);
__decorate([
    bindThis,
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], NavigationBarPlugin.prototype, "show", null);
__decorate([
    bindThis,
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], NavigationBarPlugin.prototype, "hide", null);
export const navigationBarPlugin = new NavigationBarPlugin();
