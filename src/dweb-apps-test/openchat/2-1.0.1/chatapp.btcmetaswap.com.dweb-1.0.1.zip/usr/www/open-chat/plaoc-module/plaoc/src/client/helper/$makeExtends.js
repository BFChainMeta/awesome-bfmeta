export const $makeExtends = () => {
    return (exts) => {
        return exts;
    };
};
