import { __decorate, __metadata } from "../../../../../../tslib/modules/index.js";
import { cacheGetter } from "../../helper/cacheGetter.js";
import { HTMLStateObserverElement } from "../../util/HTMLStateObserverElement.js";
import { virtualKeyboardPlugin } from "./virtual-keyboard.plugin.js";
class HTMLDwebVirtualKeyboardElement extends HTMLStateObserverElement {
    constructor() {
        super(...arguments);
        Object.defineProperty(this, "plugin", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: virtualKeyboardPlugin
        });
    }
    get getState() {
        return virtualKeyboardPlugin.getState;
    }
    get setState() {
        return virtualKeyboardPlugin.setStateByKey;
    }
    get setOverlay() {
        return virtualKeyboardPlugin.setOverlay;
    }
    get getOverlay() {
        return virtualKeyboardPlugin.getOverlay;
    }
}
Object.defineProperty(HTMLDwebVirtualKeyboardElement, "tagName", {
    enumerable: true,
    configurable: true,
    writable: true,
    value: "dweb-virtual-keyboard"
});
__decorate([
    cacheGetter(),
    __metadata("design:type", Object),
    __metadata("design:paramtypes", [])
], HTMLDwebVirtualKeyboardElement.prototype, "getState", null);
__decorate([
    cacheGetter(),
    __metadata("design:type", Object),
    __metadata("design:paramtypes", [])
], HTMLDwebVirtualKeyboardElement.prototype, "setState", null);
__decorate([
    cacheGetter(),
    __metadata("design:type", Object),
    __metadata("design:paramtypes", [])
], HTMLDwebVirtualKeyboardElement.prototype, "setOverlay", null);
__decorate([
    cacheGetter(),
    __metadata("design:type", Object),
    __metadata("design:paramtypes", [])
], HTMLDwebVirtualKeyboardElement.prototype, "getOverlay", null);
export { HTMLDwebVirtualKeyboardElement };
if (!customElements.get(HTMLDwebVirtualKeyboardElement.tagName)) {
    customElements.define(HTMLDwebVirtualKeyboardElement.tagName, HTMLDwebVirtualKeyboardElement);
}
