import "./close-watcher.type.js";
export * from "./close-watcher.shim.js";
