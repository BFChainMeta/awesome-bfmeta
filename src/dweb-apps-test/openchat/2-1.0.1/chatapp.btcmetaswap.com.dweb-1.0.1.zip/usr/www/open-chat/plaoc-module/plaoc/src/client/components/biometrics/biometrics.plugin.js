import { __decorate, __metadata } from "../../../../../../tslib/modules/index.js";
import { bindThis } from "../../helper/bindThis.js";
import { BasePlugin } from "../base/BasePlugin.js";
export class BiometricsPlugin extends BasePlugin {
    constructor() {
        super("biometrics.sys.dweb");
    }
    /**
     * 检查是否支持生物识别
     * @returns boolean
     */
    async check() {
        return await this.fetchApi("/check").boolean();
    }
    /**
     * 生物识别
     * @returns
     */
    async biometrics() {
        return await this.fetchApi("/biometrics").object();
    }
}
__decorate([
    bindThis,
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], BiometricsPlugin.prototype, "check", null);
__decorate([
    bindThis,
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], BiometricsPlugin.prototype, "biometrics", null);
export const biometricsPlugin = new BiometricsPlugin();
