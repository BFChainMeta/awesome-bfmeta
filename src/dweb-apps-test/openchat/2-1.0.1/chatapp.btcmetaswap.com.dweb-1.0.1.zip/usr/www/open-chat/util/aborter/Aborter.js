import { PromiseOut } from "../extends-promise-out/index.js";
import { safePromiseRace } from "../extends-promise-safe/index.js";
/**中断器 */
export class Aborter {
    constructor() {
        Object.defineProperty(this, "_labels", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: new Set()
        });
        Object.defineProperty(this, "_waitTaskAborterWM", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: new Map()
        });
        Object.defineProperty(this, "_isAborted", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: false
        });
        Object.defineProperty(this, "_abortReason", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "_afterAborted_po", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "_abortedPromise_po", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
    }
    hasLabel(label) {
        return this._labels.has(label);
    }
    wait(task, finallycb, label) {
        const pTask = (task instanceof Promise ? task : Promise.resolve(task)).then((res) => {
            finallycb();
            if (label) {
                this._labels.add(label);
            }
            return res;
        }, (err) => {
            finallycb();
            throw err;
        });
        return pTask;
    }
    wrapAsync(task, label, stackIndex = 0) {
        const waitTask = this.wait(task, 
        /// 及时从等待任务队列中移除
        () => {
            this._waitTaskAborterWM.delete(waitTask);
        }, label);
        /// 写入到等待任务队列中
        if (typeof stackIndex === "number") {
            const stackStartLine = stackIndex;
            const aborter = new PromiseOut();
            stackIndex = {
                aborter,
                get runtimErrorStack() {
                    return (new Error().stack || "")
                        .split("\n")
                        .slice(stackStartLine + 3)
                        .join("\n");
                },
            };
        }
        this._waitTaskAborterWM.set(waitTask, stackIndex);
        // 等待race返回
        return safePromiseRace([waitTask, stackIndex.aborter.promise]);
    }
    wrapAsyncRunner(task, label) {
        return (...args) => this.wrapAsync(task(...args), label, 1);
    }
    async *wrapAsyncIterator(aIterator) {
        const aborter = new PromiseOut();
        const stackIndex = {
            aborter,
            get runtimErrorStack() {
                return (new Error().stack || "").split("\n").slice(3).join("\n");
            },
        };
        do {
            const item = await this.wrapAsync(aIterator.next(), undefined, stackIndex);
            if (item.done) {
                break;
            }
            yield item.value;
        } while (true);
    }
    async wrapAsyncIteratorReturn(aIterator) {
        do {
            const item = await this.wrapAsync(aIterator.next());
            if (item.done) {
                return item.value;
            }
        } while (true);
    }
    /**
     * 是否已经中断
     */
    get isAborted() {
        return this._isAborted;
    }
    /**
     * 中断的原因是什么
     */
    get abortReason() {
        return this._abortReason;
    }
    /**
     * 这个promise不会抛出异常
     */
    get afterAborted() {
        return this._afterAborted.promise;
    }
    get _afterAborted() {
        const po = this._afterAborted_po || (this._afterAborted_po = new PromiseOut());
        if (this._isAborted) {
            po.resolve(this._abortReason);
        }
        return po;
    }
    /**
     * 这个promise会抛出异常
     */
    get abortedPromise() {
        return this._abortedPromise.promise;
    }
    get _abortedPromise() {
        const po = this._abortedPromise_po || (this._abortedPromise_po = new PromiseOut());
        if (this._isAborted) {
            po.reject(this._abortReason);
        }
        return po;
    }
    /**
     * @param reason
     */
    abort(reason) {
        if (this._isAborted) {
            return;
        }
        this._isAborted = true;
        // 写入原因
        this._afterAborted_po?.resolve((this._abortReason = reason));
        this._abortedPromise_po?.reject(reason);
        /// 中断正在进行中的任务
        for (const { aborter, runtimErrorStack, } of this._waitTaskAborterWM.values()) {
            let err;
            if (reason instanceof Error) {
                const cloneErr = new reason.constructor(reason.message);
                cloneErr.stack =
                    (reason.stack ? reason.stack + "\n(abort)\n" : "") + runtimErrorStack;
                err = cloneErr;
            }
            else if (typeof reason === "string") {
                const wrapError = new Error(reason);
                wrapError.stack =
                    (wrapError.stack || "").split("\n")[0] + "\n" + runtimErrorStack;
                err = wrapError;
            }
            else {
                err = reason;
            }
            aborter.reject(err);
        }
    }
}
