var _WindowModalController_state;
import { __classPrivateFieldGet, __classPrivateFieldSet } from "../../../../../../tslib/modules/index.js";
import { PromiseOut } from "../../helper/PromiseOut.js";
import { SafeEvent, SafeEventTarget, SafeStateEvent } from "../../helper/SafeEventTarget.js";
export var WindowModalState;
(function (WindowModalState) {
    WindowModalState["INIT"] = "init";
    WindowModalState["OPENING"] = "opening";
    WindowModalState["OPEN"] = "open";
    WindowModalState["CLOSING"] = "closing";
    WindowModalState["CLOSE"] = "close";
    WindowModalState["DESTROYING"] = "destroying";
    WindowModalState["DESTROY"] = "destroy";
})(WindowModalState || (WindowModalState = {}));
export class WindowModalController extends SafeEventTarget {
    constructor(plugin, modal, onCallback) {
        super();
        Object.defineProperty(this, "plugin", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: plugin
        });
        Object.defineProperty(this, "modal", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: modal
        });
        _WindowModalController_state.set(this, WindowModalState.INIT);
        onCallback.listen((callbackData) => {
            switch (callbackData.type) {
                case "open":
                    this.setState(WindowModalState.OPEN);
                    break;
                case "close":
                    this.setState(WindowModalState.CLOSE);
                    break;
                case "close-alert":
                    this.setState(WindowModalState.CLOSE);
                    break;
            }
        });
        this._init();
    }
    _init() { }
    setState(value) {
        if (value === __classPrivateFieldGet(this, _WindowModalController_state, "f")) {
            return;
        }
        __classPrivateFieldSet(this, _WindowModalController_state, value, "f");
        this.dispatchEvent(new SafeStateEvent("statechange", { state: value }));
        switch (value) {
            case WindowModalState.OPEN:
                this.dispatchEvent(new SafeEvent(WindowModalState.OPEN));
                break;
            case WindowModalState.CLOSE:
                this.dispatchEvent(new SafeEvent(WindowModalState.CLOSE));
                break;
            case WindowModalState.DESTROY:
                this.dispatchEvent(new SafeEvent(WindowModalState.DESTROY));
                break;
        }
    }
    get state() {
        return __classPrivateFieldGet(this, _WindowModalController_state, "f");
    }
    isState(...states) {
        for (const state of states) {
            if (state === this.state) {
                return true;
            }
        }
        return false;
    }
    awaitState(waitState) {
        if (this.state === waitState) {
            return;
        }
        const waiter = new PromiseOut();
        // deno-lint-ignore no-this-alias
        const self = this;
        this.addEventListener("statechange", function statechange(event) {
            if (event.state === waitState) {
                waiter.resolve();
                self.removeEventListener("statechange", statechange);
            }
        });
        return waiter.promise;
    }
    get isDestroyed() {
        return this.isState(WindowModalState.DESTROYING, WindowModalState.DESTROY);
    }
    async open() {
        if (this.isDestroyed || this.isState(WindowModalState.OPENING, WindowModalState.OPEN)) {
            return;
        }
        this.setState(WindowModalState.OPENING);
        await this.plugin
            .fetchApi("/openModal", { pathPrefix: "window.sys.dweb", search: { modalId: this.modal.modalId } })
            .boolean();
        await this.awaitState(WindowModalState.OPEN);
    }
    async close() {
        if (this.isDestroyed || this.isState(WindowModalState.CLOSING, WindowModalState.CLOSE)) {
            return;
        }
        this.setState(WindowModalState.CLOSING);
        await this.plugin
            .fetchApi("/closeModal", { pathPrefix: "window.sys.dweb", search: { modalId: this.modal.modalId } })
            .boolean();
        await this.awaitState(WindowModalState.CLOSE);
    }
    async destroy() {
        if (this.isDestroyed) {
            return;
        }
        this.setState(WindowModalState.DESTROYING);
        await this.plugin
            .fetchApi("/removeModal", { pathPrefix: "window.sys.dweb", search: { modalId: this.modal.modalId } })
            .boolean();
        await this.awaitState(WindowModalState.DESTROY);
    }
}
_WindowModalController_state = new WeakMap();
