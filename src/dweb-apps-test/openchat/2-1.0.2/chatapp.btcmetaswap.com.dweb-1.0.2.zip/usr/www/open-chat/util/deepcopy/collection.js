import { detectType } from "./detector.js";
/**
 * collection types
 */
const collectionTypeSet = new Set(["Arguments", "Array", "Map", "Object", "Set"]);
const COLLECTION = new (class {
    get(collection, key, valueType = detectType(collection)) {
        switch (valueType) {
            case "Arguments":
            case "Array":
            case "Object":
                return collection[key];
            case "Map":
                return collection.get(key);
            case "Set":
                // NOTE: Set.prototype.keys is alias of Set.prototype.values
                // it means key is equals value
                return key;
            default:
        }
    }
    set(collection, key, value, valueType = detectType(collection)) {
        switch (valueType) {
            case "Arguments":
            case "Array":
            case "Object":
                collection[key] = value;
                break;
            case "Map":
                collection.set(key, value);
                break;
            case "Set":
                collection.add(value);
                break;
            default:
        }
        return collection;
    }
})();
export const get = COLLECTION.get;
export const set = COLLECTION.set;
/**
 * check to type string is collection
 *
 * @param {string} type
 */
export function isCollection(type) {
    return collectionTypeSet.has(type);
}
