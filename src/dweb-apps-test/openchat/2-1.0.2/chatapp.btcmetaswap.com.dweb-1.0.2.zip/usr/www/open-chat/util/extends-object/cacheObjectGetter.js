const SYM = Symbol("cog");
export function cacheObjectGetter(obj) {
    for (const [key, dep] of Object.entries(Object.getOwnPropertyDescriptors(obj))) {
        const sourceGet = dep.get;
        if (sourceGet && !sourceGet[SYM]) {
            dep.get = () => {
                const res = sourceGet();
                Object.defineProperty(obj, key, { value: res });
                return res;
            };
            dep.get[SYM] = true;
            Object.defineProperty(obj, key, dep);
        }
    }
    return obj;
}
