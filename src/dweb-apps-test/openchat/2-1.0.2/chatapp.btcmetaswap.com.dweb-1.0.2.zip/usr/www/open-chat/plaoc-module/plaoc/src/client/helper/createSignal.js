// deno-lint-ignore no-explicit-any
export const createSignal = () => {
    const signal = new Signal();
    return signal;
};
// deno-lint-ignore no-explicit-any
export class Signal {
    constructor() {
        Object.defineProperty(this, "_cbs", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: new Set()
        });
        Object.defineProperty(this, "listen", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: (cb) => {
                this._cbs.add(cb);
                return () => this._cbs.delete(cb);
            }
        });
        Object.defineProperty(this, "emit", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: (...args) => {
                for (const cb of this._cbs) {
                    cb.apply(null, args);
                }
            }
        });
        Object.defineProperty(this, "clear", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: () => {
                this._cbs.clear();
            }
        });
    }
}
