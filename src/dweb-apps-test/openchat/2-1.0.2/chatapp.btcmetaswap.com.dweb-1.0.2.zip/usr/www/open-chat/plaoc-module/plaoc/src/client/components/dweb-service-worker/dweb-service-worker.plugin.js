import { __decorate, __metadata } from "../../../../../../tslib/modules/index.js";
import { IpcHeaders } from "../../../../../desktop-dev/src/core/ipc/index.js";
import { createMockModuleServerIpc } from "../../common/websocketIpc.js";
import { bindThis } from "../../helper/bindThis.js";
import { BasePlugin } from "../base/BasePlugin.js";
export class DwebServiceWorkerPlugin extends BasePlugin {
    constructor() {
        super("dns.std.dweb");
        Object.defineProperty(this, "tagName", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: "dweb-service-worker"
        });
        Object.defineProperty(this, "ipcPromise", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: this.createIpc()
        });
    }
    async createIpc() {
        const api_url = BasePlugin.api_url.replace("://api", "://external");
        const url = new URL(api_url.replace(/^http/, "ws"));
        const mmid = location.host.slice(9);
        const hash = BasePlugin.external_url;
        url.pathname = `/${hash}`;
        const ipc = await createMockModuleServerIpc(url, {
            mmid: mmid,
            ipc_support_protocols: {
                cbor: false,
                protobuf: false,
                raw: false,
            },
            dweb_deeplinks: [],
            categories: [],
            name: mmid,
        });
        return ipc;
    }
    /**
     * 关闭前端
     * @returns
     */
    close() {
        return this.fetchApi("/close").boolean();
    }
    /**重启后前端 */
    restart() {
        return this.fetchApi("/restart").object();
    }
    /**
     * 查看应用是否安装
     * @param mmid
     */
    async canOpenUrl(mmid) {
        try {
            const res = await this.fetchApi(`/query`, {
                search: {
                    mmid: mmid,
                },
            });
            if (res.ok && (await res.json())) {
                return { success: true, message: "true" };
            }
            return { success: false, message: "false" };
        }
        catch (e) {
            return { success: false, message: e };
        }
    }
    /**
     * 跟外部app通信
     * @param pathname
     * @param init
     * @returns
     * https://desktop.dweb.waterbang.top.dweb/say/hi?message="hi 今晚吃螃🦀️蟹吗？"
     */
    async externalFetch(mmid, input, init) {
        const request = new Request(input, { ...init, headers: new IpcHeaders(init?.headers).init("mmid", mmid) });
        const ipc = await this.ipcPromise;
        const ipcResponse = await ipc.request(request.url, request);
        return ipcResponse.toResponse();
    }
}

__decorate([
    bindThis,
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", void 0)
], DwebServiceWorkerPlugin.prototype, "close", null);
__decorate([
    bindThis,
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", void 0)
], DwebServiceWorkerPlugin.prototype, "restart", null);
__decorate([
    bindThis,
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], DwebServiceWorkerPlugin.prototype, "canOpenUrl", null);
__decorate([
    bindThis,
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", Promise)
], DwebServiceWorkerPlugin.prototype, "externalFetch", null);
export const dwebServiceWorkerPlugin = new DwebServiceWorkerPlugin();
