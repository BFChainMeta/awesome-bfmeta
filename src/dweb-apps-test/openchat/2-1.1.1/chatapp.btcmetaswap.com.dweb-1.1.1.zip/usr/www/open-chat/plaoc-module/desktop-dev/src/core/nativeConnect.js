import { AdaptersManager } from "../helper/AdaptersManager.js";
export const connectAdapterManager = new AdaptersManager();
/** 外部程序与内部程序建立链接的方法 */
export const connectMicroModules = async (fromMM, toMM, reason) => {
    for (const connectAdapter of connectAdapterManager.adapters) {
        const ipc = await connectAdapter(fromMM, toMM, reason);
        if (ipc != null) {
            return ipc;
        }
    }
    throw new Error(`no support connect MicroModules, from:${fromMM.mmid} to:${toMM.mmid}`);
};
