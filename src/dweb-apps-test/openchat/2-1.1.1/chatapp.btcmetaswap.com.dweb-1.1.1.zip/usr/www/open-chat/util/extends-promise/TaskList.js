/**任务收集器
 * ```
 * const tl = new TaskList();
 * tl.next = sleep(1)
 * tl.next = sleep(2)
 * await tl.toPromise();
 * ```
 */
export class TaskList {
    constructor() {
        Object.defineProperty(this, "_task_list", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: []
        });
    }
    toPromise() {
        return Promise.all(this._task_list);
    }
    set next(task) {
        this._task_list.push(task);
    }
    /**
     * @deprecated
     */
    tryToPromise() {
        if (this._task_list.some((task) => task && typeof task.then === "function")) {
            return Promise.all(this._task_list);
        }
        return this._task_list;
    }
}
export const wrapTaskList = async (cb) => {
    const taskList = new TaskList();
    try {
        await cb(taskList);
    }
    catch (err) {
        taskList.next = Promise.reject(err);
    }
    return taskList.toPromise();
};
