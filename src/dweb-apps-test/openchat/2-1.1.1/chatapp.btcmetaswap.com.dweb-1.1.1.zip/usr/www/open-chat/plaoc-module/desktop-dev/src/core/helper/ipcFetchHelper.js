var _FetchEvent_request;
import { __classPrivateFieldGet, __classPrivateFieldSet } from "../../../../../tslib/modules/index.js";
import { isBinary } from "../../helper/binaryHelper.js";
import { IpcBody, IpcHeaders, IpcResponse } from "../ipc/index.js";
import { $bodyInitToIpcBodyArgs, isWebSocket } from "./ipcRequestHelper.js";
/**
 * 对即将要进行的响应内容，作出额外的处理
 */
export const fetchMid = (handler) => Object.assign(handler, { [FETCH_MID_SYMBOL]: true });
export const FETCH_MID_SYMBOL = Symbol("fetch.middleware");
/**
 * 对即将要进行的响应内容，做出最后的处理
 *
 * 如果没有返回值，那么就不会执行 ipc.postMessage
 */
export const fetchEnd = (handler) => Object.assign(handler, { [FETCH_END_SYMBOL]: true });
export const FETCH_END_SYMBOL = Symbol("fetch.end");
/**
 * 响应 WebSocket
 * @param handler
 * @returns
 */
export const fetchWs = (handler) => Object.assign(((event) => {
    if (isWebSocket(event.method, event.headers)) {
        return handler(event);
    }
}), { [FETCH_WS_SYMBOL]: true });
export const FETCH_WS_SYMBOL = Symbol("fetch.websocket");
const $throw = (err) => {
    throw err;
};
export const fetchHanlderFactory = {
    NoFound: () => fetchEnd((_event, res) => res ?? $throw(new FetchError("No Found", { status: 404 }))),
    Forbidden: () => fetchEnd((_event, res) => res ?? $throw(new FetchError("Forbidden", { status: 403 }))),
    BadRequest: () => fetchEnd((_event, res) => res ?? $throw(new FetchError("Bad Request", { status: 400 }))),
    InternalServerError: (message = "Internal Server Error") => fetchEnd((_event, res) => res ?? $throw(new FetchError(message, { status: 500 }))),
    // deno-lint-ignore no-explicit-any
};
/**
 * 一个通用的 ipcRequest 处理器
 * 开发不需要面对 ipcRequest，而是面对 web 标准的 Request、Response 即可
 */
export const createFetchHandler = (onFetchs) => {
    const onFetchHanlders = [...onFetchs];
    // deno-lint-ignore ban-types
    const extendsTo = (_to) => {
        // deno-lint-ignore no-explicit-any
        const wrapFactory = (factory) => {
            return (...args) => {
                onFetchHanlders.push(factory(...args));
                return to;
            };
        };
        const EXT = {
            onFetch: (handler) => {
                onFetchHanlders.push(handler);
                return to;
            },
            onWebSocket: (hanlder) => {
                onFetchHanlders.push(hanlder);
                return to;
            },
            mid: (handler) => {
                onFetchHanlders.push(fetchMid(handler));
                return to;
            },
            end: (handler) => {
                onFetchHanlders.push(fetchEnd(handler));
                return to;
            },
            /**
             * 配置跨域，一般是最后调用
             * @param config
             */
            cors: (config = {}) => {
                /// options 请求一般是跨域时，询问能否post，这里统一返回空就行，后面再加上 Access-Control-Allow-Methods
                onFetchHanlders.unshift(((event) => {
                    if (event.method === "OPTIONS") {
                        return { body: "" };
                    }
                }));
                /// 如果有响应，统一加上响应头
                onFetchHanlders.push(fetchMid((res) => {
                    res?.headers
                        .init("Access-Control-Allow-Origin", config.origin ?? "*")
                        .init("Access-Control-Allow-Headers", config.headers ?? "*")
                        .init("Access-Control-Allow-Methods", config.methods ?? "*");
                    return res;
                }));
                return to;
            },
            noFound: wrapFactory(fetchHanlderFactory.NoFound),
            forbidden: wrapFactory(fetchHanlderFactory.Forbidden),
            badRequest: wrapFactory(fetchHanlderFactory.BadRequest),
            internalServerError: wrapFactory(fetchHanlderFactory.InternalServerError),
            extendsTo,
        };
        const to = _to;
        Object.assign(to, EXT);
        return to;
    };
    const onRequest = (async (request, ipc) => {
        const event = new FetchEvent(request, ipc);
        let res;
        for (const handler of onFetchHanlders) {
            try {
                let result = undefined;
                if (FETCH_MID_SYMBOL in handler) {
                    if (res !== undefined) {
                        result = await handler(res, event);
                    }
                }
                else if (FETCH_END_SYMBOL in handler) {
                    result = await handler(event, res);
                }
                else {
                    if (res === undefined) {
                        result = await handler(event);
                    }
                }
                if (result instanceof IpcResponse) {
                    res = result;
                }
                else if (result instanceof Response) {
                    /// TODO 需要加入对 Response.error() 的支持，这需要新增 IpcError { message:string, reqId?:number } 的消息
                    res = await IpcResponse.fromResponse(request.req_id, result, ipc);
                }
                else if (typeof result === "object") {
                    /// 尝试构建出 IpcResponse
                    const req_id = request.req_id;
                    const status = result.status ?? 200;
                    const headers = new IpcHeaders(result.headers);
                    if (result.body instanceof IpcBody) {
                        res = new IpcResponse(req_id, status, headers, result.body, ipc);
                    }
                    else {
                        const body = await $bodyInitToIpcBodyArgs(result.body, (bodyInit) => {
                            /// 尝试使用 JSON 解码
                            if (headers.has("Content-Type") === false ||
                                headers.get("Content-Type").startsWith("application/javascript")) {
                                headers.init("Content-Type", "application/javascript;charset=utf8");
                                return JSON.stringify(bodyInit);
                            }
                            // 否则直接处理成字符串
                            return String(bodyInit);
                        });
                        if (typeof body === "string") {
                            res = IpcResponse.fromText(req_id, status, headers, body, ipc);
                        }
                        else if (isBinary(body)) {
                            res = IpcResponse.fromBinary(req_id, status, headers, body, ipc);
                        }
                        else if (body instanceof ReadableStream) {
                            res = IpcResponse.fromStream(req_id, status, headers, body, ipc);
                        }
                    }
                }
            }
            catch (err) {
                if (err instanceof Response) {
                    res = await IpcResponse.fromResponse(request.req_id, err, ipc);
                }
                else {
                    /// 处理异常，尝试返回
                    let err_code = 500;
                    let err_message = "";
                    let err_detail = "";
                    if (err instanceof Error) {
                        err_message = err.message;
                        err_detail = err.stack ?? err.name;
                        if (err instanceof FetchError) {
                            err_code = err.code;
                        }
                    }
                    else {
                        err_message = String(err);
                    }
                    /// 根据对方的接收需求，尝试返回 JSON
                    if (request.headers.get("Accept") === "application/json") {
                        res = IpcResponse.fromJson(request.req_id, err_code, new IpcHeaders().init("Content-Type", "text/html;charset=utf8"), { message: err_message, detail: err_detail }, ipc);
                    }
                    else {
                        res = IpcResponse.fromText(request.req_id, err_code, new IpcHeaders().init("Content-Type", "text/html;charset=utf8"), err instanceof Error ? `<h1>${err.message}</h1><hr/><pre>${err.stack}</pre>` : String(err), ipc);
                    }
                }
            }
        }
        /// 发送
        if (res) {
            ipc.postMessage(res);
            return res;
        }
    });
    return extendsTo(onRequest);
};
export class FetchEvent {
    constructor(ipcRequest, ipc) {
        Object.defineProperty(this, "ipcRequest", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: ipcRequest
        });
        Object.defineProperty(this, "ipc", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: ipc
        });
        _FetchEvent_request.set(this, void 0);
    }
    get url() {
        return this.ipcRequest.parsed_url;
    }
    get pathname() {
        return this.url.pathname;
    }
    get search() {
        return this.url.search;
    }
    get searchParams() {
        return this.url.searchParams;
    }
    get request() {
        return (__classPrivateFieldSet(this, _FetchEvent_request, __classPrivateFieldGet(this, _FetchEvent_request, "f") ?? this.ipcRequest.toRequest(), "f"));
    }
    //#region Body 相关的属性与方法
    /** A simple getter used to expose a `ReadableStream` of the body contents. */
    get body() {
        return this.request.body;
    }
    /** Stores a `Boolean` that declares whether the body has been used in a
     * response yet.
     */
    get bodyUsed() {
        return this.request.bodyUsed;
    }
    /** Takes a `Response` stream and reads it to completion. It returns a promise
     * that resolves with an `ArrayBuffer`.
     */
    arrayBuffer() {
        return this.request.arrayBuffer();
    }
    async typedArray() {
        return new Uint8Array(await this.request.arrayBuffer());
    }
    /** Takes a `Response` stream and reads it to completion. It returns a promise
     * that resolves with a `Blob`.
     */
    blob() {
        return this.request.blob();
    }
    /** Takes a `Response` stream and reads it to completion. It returns a promise
     * that resolves with a `FormData` object.
     */
    formData() {
        return this.request.formData();
    }
    /** Takes a `Response` stream and reads it to completion. It returns a promise
     * that resolves with the result of parsing the body text as JSON.
     */
    // deno-lint-ignore no-explicit-any
    json() {
        return this.request.json();
    }
    /** Takes a `Response` stream and reads it to completion. It returns a promise
     * that resolves with a `USVString` (text).
     */
    text() {
        return this.request.text();
    }
    //#endregion
    /** Returns a Headers object consisting of the headers associated with request. Note that headers added in the network layer by the user agent will not be accounted for in this object, e.g., the "Host" header. */
    get headers() {
        return this.ipcRequest.headers;
    }
    /** Returns request's HTTP method, which is "GET" by default. */
    get method() {
        return this.ipcRequest.method;
    }
    /** Returns the URL of request as a string. */
    get href() {
        return this.url.href;
    }
    get req_id() {
        return this.ipcRequest.req_id;
    }
}
_FetchEvent_request = new WeakMap();
export class FetchError extends Error {
    constructor(message, options) {
        super(message);
        Object.defineProperty(this, "code", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        this.code = options?.status ?? 500;
    }
}
