export const once = (fn) => {
    let first = true;
    let resolved;
    let rejected;
    let success = false;
    return function (...args) {
        if (first) {
            first = false;
            try {
                resolved = fn.apply(this, args);
                success = true;
            }
            catch (err) {
                rejected = err;
            }
        }
        if (success) {
            return resolved;
        }
        throw rejected;
    };
};
