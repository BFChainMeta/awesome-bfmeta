var _WindowAlertController_result;
import { __classPrivateFieldGet, __classPrivateFieldSet } from "../../../../../../tslib/modules/index.js";
import { WindowModalController } from "./WindowModalController.js";
export class WindowAlertController extends WindowModalController {
    constructor(plugin, modal, onCallback) {
        super(plugin, modal, onCallback);
        _WindowAlertController_result.set(this, false);
        onCallback.listen((data) => {
            if (data.type === "close-alert") {
                __classPrivateFieldSet(this, _WindowAlertController_result, data.confirm, "f");
            }
            if (data.type === "open") {
                __classPrivateFieldSet(this, _WindowAlertController_result, false, "f");
            }
        });
    }
    get result() {
        return __classPrivateFieldGet(this, _WindowAlertController_result, "f");
    }
}
_WindowAlertController_result = new WeakMap();
