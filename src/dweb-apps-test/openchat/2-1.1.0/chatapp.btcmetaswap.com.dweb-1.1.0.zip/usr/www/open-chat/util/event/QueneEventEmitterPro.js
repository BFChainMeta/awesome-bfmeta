import { __decorate, __metadata } from "../../tslib/modules/index.js";
import { cacheGetter, GetCallerInfo, isDev, EVENT_DESCRIPTION_SYMBOL, eventDebugStyle, } from "../event-base/index.js";
import { QueneEventEmitter } from "../event-quene_emitter/index.js";
/**一个极简的事件管理模块 */
export class QueneEventEmitterPro extends QueneEventEmitter {
    constructor() {
        super(...arguments);
        //#region on emit any event
        /**是否有过监听通用事件处理 */
        Object.defineProperty(this, "_hasCommonEmitHandlerMap", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
    }
    /**触发事件监听 */
    emit(eventname, data) {
        /**
         * 处理通用监听器
         */
        if (this._hasCommonEmitHandlerMap) {
            if (isDev) {
                if (this._commonEmitHandlerMap.size) {
                    const self = this[EVENT_DESCRIPTION_SYMBOL] || this;
                    console.log(...eventDebugStyle.head("%s QUENE EMIT WILDCARDS * [%s]", eventDebugStyle.DARKVIOLET_BOLD_UNDERLINE), self, eventname, data);
                }
            }
            for (const [commonHanlder, opts] of this._commonEmitHandlerMap) {
                try {
                    if (isDev) {
                        const { taskname = commonHanlder.name } = opts;
                        console.log(...eventDebugStyle.head("RUN [%s]", eventDebugStyle.DARKVIOLET_BOLD_UNDERLINE), taskname);
                    }
                    const res = commonHanlder({ eventname, args: data });
                    if (res instanceof Promise) {
                        res.catch((err) => this._emitErrorHanlder(err, eventname, data));
                    }
                }
                catch (err) {
                    this._emitErrorHanlder(err, eventname, data);
                }
                finally {
                    if (opts.once) {
                        this._commonEmitHandlerMap.delete(commonHanlder);
                    }
                }
            }
        }
        /// 触发事件
        return super.emit(eventname, data);
    }
    get _commonEmitHandlerMap() {
        this._hasCommonEmitHandlerMap = true;
        return new Map();
    }
    /**
     * 监听所有事件
     * @param commonHanlder
     * @param taskname
     */
    onEmit(commonHanlder, opts = {}) {
        if (this._commonEmitHandlerMap.has(commonHanlder)) {
            console.warn(`hanlder '${commonHanlder.name}' already exits in common hanlder event set.`);
        }
        if (opts.taskname === undefined) {
            opts.taskname = GetCallerInfo(this.onEmit);
        }
        this._commonEmitHandlerMap.set(commonHanlder, opts);
    }
    /**
     * 移除所有事件的监听
     * @param commonHanlder
     */
    offEmit(commonHanlder) {
        if (!this._hasCommonEmitHandlerMap) {
            return false;
        }
        if (commonHanlder) {
            return this._commonEmitHandlerMap.delete(commonHanlder);
        }
        this._commonEmitHandlerMap.clear();
        return true;
    }
    //#endregion
    /**
     * 移除所有的事件
     */
    clear(opts = {}) {
        super.clear(opts);
        const { ignoreCommonErrorHanlder } = opts;
        if (!ignoreCommonErrorHanlder && this._hasCommonEmitHandlerMap) {
            /// 默认清理掉通用监听的回调合集
            this._commonEmitHandlerMap.clear();
        }
    }
}
__decorate([
    cacheGetter,
    __metadata("design:type", Object),
    __metadata("design:paramtypes", [])
], QueneEventEmitterPro.prototype, "_commonEmitHandlerMap", null);
export function syncQueneEventEmitterPro() {
    return new QueneEventEmitterPro();
}
