let uuid_accer = 0;
/* 基于callback风格的锁，兼容Promise，性能比Promise好 */
export class AtomLock {
    // uuid = `${process_name}(${process.pid})-${uuid_accer++}`
    constructor(key) {
        Object.defineProperty(this, "key", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: key
        });
        Object.defineProperty(this, "uid", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: uuid_accer++ % 4294967296
        });
        Object.defineProperty(this, "is_finished", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: false
        });
        Object.defineProperty(this, "_cbs", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: []
        });
        Object.defineProperty(this, "after_unlock", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
    }
    then(cb) {
        if (this.is_finished) {
            try {
                cb();
            }
            catch (err) { }
            return;
        }
        this._cbs.push(cb);
    }
    unlock() {
        if (this.is_finished) {
            return;
        }
        this.is_finished = true;
        for (const cb of this._cbs) {
            try {
                cb();
            }
            catch (err) { }
        }
        this._cbs.length = 0;
        this.after_unlock && this.after_unlock();
    }
}
export function isAtomLockKey(key) {
    const type = typeof key;
    return type === "number" || type === "string";
}
export class AtomLocksRef {
    /* 指定某一个 */
    constructor(cur_job_map, pre_job_map, 
    /* 当前锁的下标索引 */
    cur_index, pre_index) {
        Object.defineProperty(this, "cur_job_map", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: cur_job_map
        });
        Object.defineProperty(this, "pre_job_map", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: pre_job_map
        });
        Object.defineProperty(this, "uid", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: uuid_accer++ % 4294967296
        });
        Object.defineProperty(this, "cur_index", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "pre_index", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        if (!cur_index) {
            cur_index = new Map();
            let i = 0;
            for (const atomLock of cur_job_map.values()) {
                cur_index.set(i, atomLock);
                i += 1;
            }
        }
        this.cur_index = cur_index;
        if (!pre_index) {
            pre_index = new Map();
            let i = 0;
            for (const atomLock of pre_job_map.values()) {
                pre_index.set(i, atomLock);
                i += 1;
            }
        }
        this.pre_index = pre_index;
    }
    finish(ids) {
        const { cur_job_map } = this;
        if (typeof ids === "object" && Symbol.iterator in ids) {
            for (const id of ids) {
                const job = cur_job_map.get(id);
                if (job) {
                    job.unlock();
                }
            }
        }
        else {
            const job = cur_job_map.get(ids);
            if (job) {
                job.unlock();
            }
        }
    }
    finishAll() {
        for (const cur_lock of this.cur_job_map.values()) {
            cur_lock.unlock();
        }
    }
    async getPreJobsDone() {
        for (const pre_lock of this.pre_job_map.values()) {
            if (!pre_lock.is_finished) {
                await pre_lock; // 因为有.then属性，强行当成Promise对象来用
            }
        }
    }
    async getJobsDone() {
        for (const cur_lock of this.cur_job_map.values()) {
            if (!cur_lock.is_finished) {
                await cur_lock; // 因为有.then属性，强行当成Promise对象来用
            }
        }
    }
}
const ATOMLOCKSET_LAST_LOCK = new WeakMap();
export class AtomLocksManager {
    constructor() {
        Object.defineProperty(this, "_map", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: new Map()
        });
    }
    static isLockKey(id) {
        const id_type = typeof id;
        return id_type === "string" || id_type === "number" || id_type === "symbol";
    }
    appendLocksWithDetail(ids) {
        /* 迭代器的最大上限为uint16:65536个元素，溢出会导致异常 */
        // debug('appendLocks', ids);
        const pre_locks_map = new Map();
        const cur_locks_map = new Map();
        /* 方便快速用下标定位一个atomLock */
        const cur_locks_index_map = new Map();
        const pre_locks_index_map = new Map();
        const pre_lock_index_list = [];
        let is_over_uint8 = false;
        let is_over_uint16 = false;
        let i = 0;
        // 注意：和旧版的API不一样的是，这里不做去重了，而是在入口那边进行去重，毕竟是用于进程之间通讯，为了避免不必要的数据传输，应该在传输前就完成去重。
        for (const id of ids) {
            // 获取锁的队列
            const locks = this._map.get(id) || new Set();
            // debug('has', id, [...locks.values()].map(l => l.uid));
            if (locks.size === 0) {
                this._map.set(id, locks);
            }
            else {
                // 获取前锁放入前锁队列
                const pre_lock = ATOMLOCKSET_LAST_LOCK.get(locks);
                pre_locks_map.set(id, pre_lock);
                pre_locks_index_map.set(pre_locks_index_map.size, pre_lock);
                pre_lock_index_list.push(i);
            }
            // 生成新锁
            const new_lock = new AtomLock(id);
            new_lock.after_unlock = () => {
                locks.delete(new_lock);
                if (locks.size === 0) {
                    this._map.delete(id);
                    ATOMLOCKSET_LAST_LOCK.delete(locks);
                }
            };
            // 将新锁放入集合中与当前锁队列中
            // debug("new", id, new_lock.uid);
            locks.add(new_lock);
            // 注册自动删除事件
            new_lock.after_unlock = () => {
                locks.delete(new_lock);
                // debug(new_lock.id, '完成', [...locks.values()].map(l => l.uid));
                if (locks.size === 0) {
                    this._map.delete(id);
                }
            };
            ATOMLOCKSET_LAST_LOCK.set(locks, new_lock);
            cur_locks_map.set(id, new_lock);
            cur_locks_index_map.set(i, new_lock);
            i += 1;
            if (i === 256) {
                // > 255
                console.warn("Too many locks at once, please divide the task reasonably.");
                is_over_uint8 = true;
            }
            if (i === 65536) {
                // > 65535
                console.warn("Too many locks at once, please divide the task reasonably.");
                is_over_uint16 = true;
            }
        }
        return {
            locksRef: new AtomLocksRef(cur_locks_map, pre_locks_map, cur_locks_index_map),
            pre_lock_index_list,
            is_over_uint8,
            is_over_uint16,
        };
    }
    appendLocks(ids) {
        return this.appendLocksWithDetail(ids).locksRef;
    }
    getLocks(ids) {
        const pre_locks_map = new Map();
        for (const id of ids) {
            const locks = this._map.get(id);
            if (locks) {
                const pre_lock = ATOMLOCKSET_LAST_LOCK.get(locks);
                pre_locks_map.set(id, pre_lock);
            }
        }
        return new AtomLocksRef(pre_locks_map, new Map());
    }
}
