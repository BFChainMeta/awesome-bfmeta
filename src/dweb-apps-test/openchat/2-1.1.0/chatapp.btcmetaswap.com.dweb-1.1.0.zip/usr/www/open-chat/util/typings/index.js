export * from "./$types.js";
export * from "./global.js";
/**
 * @inline
 */
export const $ignoreAwait = (_promise) => {
    void _promise;
};
/**
 * @inline
 */
export const $shouldNever = (_val) => { };
/**
 * @inline
 */
export const $safeEnd = (() => { });
