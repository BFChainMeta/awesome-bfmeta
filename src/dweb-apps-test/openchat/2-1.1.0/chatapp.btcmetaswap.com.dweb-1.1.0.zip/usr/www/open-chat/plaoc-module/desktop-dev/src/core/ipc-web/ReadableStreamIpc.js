var _a, _ReadableStreamIpc_rso;
import { __classPrivateFieldGet } from "../../../../../tslib/modules/index.js";
import { encode } from "../../../../deps/deno.land/x/cbor@v1.5.4/index.js";
import { IPC_MESSAGE_TYPE } from "../ipc/const.js";
import { once } from "../../helper/$once.js";
import { u8aConcat } from "../../helper/binaryHelper.js";
import { simpleDecoder, simpleEncoder } from "../../helper/encoding.js";
import { ReadableStreamOut, binaryStreamRead } from "../../helper/stream/readableStreamHelper.js";
import { Ipc } from "../ipc/ipc.js";
import { $messagePackToIpcMessage } from "./$messagePackToIpcMessage.js";
import { $jsonToIpcMessage } from "./$messageToIpcMessage.js";
/**
 * 基于 WebReadableStream 的IPC
 *
 * 它会默认构建出一个输出流，
 * 以及需要手动绑定输入流 {@link bindIncomeStream}
 */
class ReadableStreamIpc extends Ipc {
    constructor(remote, role, self_support_protocols = {
        raw: false,
        cbor: true,
        protobuf: false,
    }) {
        super();
        Object.defineProperty(this, "remote", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: remote
        });
        Object.defineProperty(this, "role", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: role
        });
        Object.defineProperty(this, "self_support_protocols", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: self_support_protocols
        });
        _ReadableStreamIpc_rso.set(this, new ReadableStreamOut());
        Object.defineProperty(this, "PONG_DATA", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: once(() => {
                const pong = encode("pong");
                return ReadableStreamIpc.concatLen(pong);
            })
        });
        Object.defineProperty(this, "CLOSE_DATA", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: once(() => {
                const close = encode("close");
                return ReadableStreamIpc.concatLen(close);
            })
        });
        Object.defineProperty(this, "_incomne_stream", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        /** JS 环境里支持 cbor 协议 */
        this._support_cbor = self_support_protocols.cbor && remote.ipc_support_protocols.cbor;
    }
    /** 这是输出流，给外部读取用的 */
    get stream() {
        return __classPrivateFieldGet(this, _ReadableStreamIpc_rso, "f").stream;
    }
    get controller() {
        return __classPrivateFieldGet(this, _ReadableStreamIpc_rso, "f").controller;
    }
    /**
     * 输入流要额外绑定
     * 注意，非必要不要 await 这个promise
     */
    async bindIncomeStream(stream, options = {}) {
        if (this._incomne_stream !== undefined) {
            throw new Error("in come stream alreay binded.");
        }
        this._incomne_stream = await stream;
        const { signal } = options;
        const reader = binaryStreamRead(this._incomne_stream, { signal });
        this.onClose(() => {
            reader.throw("output stream closed");
        });
        while ((await reader.available()) > 0) {
            const size = await reader.readInt();
            const data = await reader.readBinary(size);
            /// 开始处理数据并做响应
            const message = this.support_cbor
                ? $messagePackToIpcMessage(data, this)
                : $jsonToIpcMessage(simpleDecoder(data, "utf8"), this);
            if (message === undefined) {
                console.error("unkonwn message", data);
                return;
            }
            if (message === "pong") {
                return;
            }
            if (message === "close") {
                this.close();
                return;
            }
            if (message === "ping") {
                this.controller.enqueue(this.PONG_DATA());
                return;
            }
            this._messageSignal.emit(message, this);
        }
        /// 输入流结束，输出流也要一并关闭
        this.close();
    }
    _doPostMessage(message) {
        // deno-lint-ignore no-explicit-any
        let message_raw;
        // 使用 type 判断
        if (message.type === IPC_MESSAGE_TYPE.REQUEST) {
            message_raw = message.ipcReqMessage();
        }
        else if (message.type === IPC_MESSAGE_TYPE.RESPONSE) {
            message_raw = message.ipcResMessage();
        }
        else {
            message_raw = message;
        }
        const message_data = this.support_cbor ? encode(message_raw) : simpleEncoder(JSON.stringify(message_raw), "utf8");
        const chunk = ReadableStreamIpc.concatLen(message_data);
        this.controller.enqueue(chunk);
    }
    _doClose() {
        this.controller.enqueue(this.CLOSE_DATA());
        this.controller.close();
    }
}
_a = ReadableStreamIpc, _ReadableStreamIpc_rso = new WeakMap();
Object.defineProperty(ReadableStreamIpc, "_len", {
    enumerable: true,
    configurable: true,
    writable: true,
    value: new Uint32Array(1)
});
Object.defineProperty(ReadableStreamIpc, "_len_u8a", {
    enumerable: true,
    configurable: true,
    writable: true,
    value: new Uint8Array(_a._len.buffer)
});
Object.defineProperty(ReadableStreamIpc, "concatLen", {
    enumerable: true,
    configurable: true,
    writable: true,
    value: (data) => {
        _a._len[0] = data.length;
        return u8aConcat([_a._len_u8a, data]);
    }
});
export { ReadableStreamIpc };
