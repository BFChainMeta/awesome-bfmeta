///<reference lib="dom" />
export default () => ({ TextDecoder, TextEncoder });
