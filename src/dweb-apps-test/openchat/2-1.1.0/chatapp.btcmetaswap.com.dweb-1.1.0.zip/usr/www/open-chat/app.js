// let apiHost = "172.30.92.81";
let apiHost = "qaimapi.btcmetaswap.com";
if (location.pathname == "/index.html") {
  localStorage.setItem(
    "url:X-Plaoc-External-Url",
    new URL(location.href).searchParams.get("X-Plaoc-External-Url")
  );
  history.replaceState(null, null, "/");
} else {
  // apiHost = "web.rentsoft.cn";
  // apiHost = "172.30.92.81";
  apiHost = apiHost;
}
const getProxyChatUrl = () => {
  // if(location.protocol == "https"){
  //   return location.origin.replace("www","proxy-chat")
  // }
  // https://web.rentsoft.cn/chat_enterprise
  return `https://${apiHost}/chat`;
};
const getProxyApiUrl = () => {
  // if(location.protocol == "https"){
  //   return location.origin.replace("www","proxy-api")
  // }
  // https://web.rentsoft.cn/chat_enterprise
  return `https://${apiHost}/api`;
};

const getProxyWsUrl = () => {
  // if(location.protocol == "https"){
  //   return location.origin.replace("www","proxy-api")
  // }
  return `wss://${apiHost}/msg_gateway`;
};
Object.assign(self, {
  getProxyChatUrl,
  getProxyApiUrl,
  getProxyWsUrl,
  openChatVersion: "1.1.0",
});
