import {
  d,
  B as a,
  D as o,
  F as A,
  G as C,
  E as l,
  f as r,
  _ as p,
  W as G,
  $ as S,
  M as I,
  v as M,
  y as U,
  a0 as f,
  j as Q,
  a1 as u,
  a2 as B,
  Q as F,
  a3 as z,
  a4 as D,
} from "./index-367d22e2.js";
const q =
    "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADgAAAA4CAYAAACohjseAAAAAXNSR0IArs4c6QAABb1JREFUaEPtmV+IVHUUx7/nd6/7787DRmy4eycyMjBJmr2zQYIP+uQGPiglCCooKhk9ZGSUaGSUYGRkpGRUKCREKLShgtBDgkKCzp2lwjbY0HDu7JKbCM6dndmduSd+Mzu7s7szOzP33h03mXm88zvfcz7n/O75/bmEh/xHDzkfGoD/9wo3Ktio4ALPQGOK+lggFUDGR72qpOapgkta2roe2UxE60HUQ8DiXDTMCSYMsIPz2QydTv8T+auqKD0M8h1Q6zQ2Q6Ejk1BlgmNGholPJNOpfbhzI+GBYU5TPwHVgB7+HITdpTxKICLIaTrtx4z+rOOsTw1F/54PSN8ANd04SUTbCkEyIwbCkWwm+2NquP9W7nnH8kBrU3OvQuI1AKungHgw4dBKxCMjfkP6AqgFw68TcHQKjk/Z1t1XgVupcgFrncYWKPQVAS3519O5ZFvRNQsPsD3UHgiImwC154Jz8HUiHtlVTaBap9ELQecKUzfr8KbRuPl9NbbVjvFcwYAe/gCEA/kuiYGEFVlRy3JQbM/A73YsZ+/bzzOgFjSuEahHRpRlZ+OoFT1bU3RyBmjiNogC0m48zU+n75iDNWnMMdgbYMfyQKC59X6+eEjZ6dEONy1f041zRLQur8Nb7Zh5ekEAtiwOLVFV5Wa+SfAt2zKfdBNY8TR1mA8kLfOQG51SNp4q2NbZ3SMUcW0i89ftmPm8m8ACQeM9gA7mbflgIma+70bHd8DpFUTMtiKPuwlM041PiWjPxFTfY8cin7nR8R1QCgZ0477XBlHcqBwnuyEZ7+9bMIDFDcLN9NL0UIhIiXptVOUS4ukdzFWwq3sThPiuEGDGGQ+l47/+WWUFVE0P/0Q0uW3rS8QiG6q0rWqYZ0DpRdPDUSKE8j0CAzw2usa+c2O4QgRqIBj+AsDOfBdGJjPGz/i5BkpdnwBDIYK4XHgXGRhmxs6kFblQCrL5sfBTqsrHSFBv4X+G844di35UVVlqGOQLoPTX1hVaT6ScmToSMZipn4DzTBghcDbrAIKwFqDeaUenGvavNbDlhvoC2NLZ/YQQuaB3gtFDOdVS0jzruePwwWTcv3VvZgK8AKqaHtoMKHsm37+K6Z0GeMnJOm8lh6LXS5ipbbqxg4jb7XT6uJvtX0HTFaDWaawlBccAWlqOSb6HYAwTOMGQG2m+y4wbAhjIOM6FyUNwCQE53YVQfphoWh8mrMi7FXNXZkCtgGpbl7FfiMK2akJVXiYBlxh8gcBX7bGxQS9Z13RjGxGdzHdXeXg2t9cFUNONb4loy1Tnk92SjyVt5zju9d9zG8RMuwcC2KYbrwiiE5NwDl+0QVvn4x6l7oDNHcZStZl+K9yf1HIt4aaqdQfUgsbHBNo7sePot61/V851oeQGqtim3oCqFgzfLlzkcpZftIfMi14hpL2mh98E+NkSa9dSEK3KP+dBZlyZ5Y952B5PH6rUzCp20VbdeEEh+mWievLMJ0/tnr8xFOvOTlbxejl7czDZBxh7bSvyyVzJrgKw+2WFxJmJNelswops9KN6TV0rljWJpj9Ka1ULyNttyzzlCbD4UpeZj9qW+YYfgFJDVlEAy2bpEa8iiB35pPIVBr6ZOYaBkaRlnq8US8UKasHutwnicM6Xg8N2PLKvkqjX/+vaZFr1+ZmicyWhroDTb86QyqR5hd+H0ge+k5l5Yh8fx7r5/HhZ1wrK7AaCodWA8nNRe84w0EcO9zEw4IBH5vy+17E80KI2P1pcqdRQ1Cq33NQdMLcoy89dgk6W+ojprqlwXyJmlrxgaul6bpUq1MtS12HenbTML935qPFELx0rQtlPmLpLcetYnhftWKSznL1cJxVa1D5qmVfd+pB2FZeJUuLSuUqLXhKEHmZaAnA7QMGy1c2fFye/3hIoxYQTft5gl0uCK0AvGa23bQOw3hn321+jgn5ntN56jQrWO+N++2tU0O+M1lvvP3R9glcd8JpOAAAAAElFTkSuQmCC",
  x =
    "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADgAAAA4CAYAAACohjseAAAAAXNSR0IArs4c6QAABRtJREFUaEPtWt9rW1Uc/3zPzfrrxqe10CQFO1Acg2maTFyxwwobDNaH7UHocIMJAwVfhfVBWAeCE/8BfRAnVjqYsIIVJhWMdGJlJqkKY+JgEXrTwrYnc7Osvfd85dyb23Ztt957k7Is5DwF8j3f7/dzPt8fJ98TQpMvanJ8aAF81hluMdhisMFPoBWiDU7Qtu61GNz2iLYSSOzdrcuuoxAYIaJeZu4noFuJMnCPiArMvASJaVOUr8G4dT+UHR+b6spgZzz5uiAxDtAwESI+7IMZFsAZyXL8QXH+Fz97gsjUBWB7/OWXdonIRYCOBzG+WZanVqQ19rD459+16VnbXTPArkTymIC4DKKop1axQsAcs5wmwb9ZFgoVe/me+r5Da+uORNDPkl4jEiMMHHyEbeaShBwtG/Pf1wNkTQD1voFzYPGR52A13CZsW16oLM0X/DjY0Zvs1zRxnojOrD8gkPzQXMh/4kfHk2RCA1TgCOLimnK+LW0+WV7M/x7Gqa7YwAGh0SRAL6wChRyrFWQogCosCdrUOuYyJuMtFLNOGIZe8XS3TrhChGGn4jIshn28lnANDLAtvn9vG+264eUcMzKmkT0CqGpYlxXRE+kZDySYS8u88upy8a9bYbQHBhjtS18FUK2WfLskabBm5jZ6Hk93RwX/ui5cp0oL2RM7DjDaN/AGIDKr4SPlYNic285ZNyfFDU/OlvZQmD4ZiEE9kZohosMuQL5kGrl3tnO0lu/1ROpLr7oy84+mkVOpEGj5B+gWgEVVWFTy27b9ot9WEMijdcJuC9H+8WyajFjQdPANUI+l3iaNJhz7jOslI3sorONB9kUT6VkQhhyzNp8yF3PfBNnvH2AiNUlEo44hKcfMYu1N2I+jenzgHAm33zLzhGnkTvvZ58n4BhjtS/8EuP3JktahSvGP60EMhZWN9iWHAU3ZVitTWsi+GUSXb4B6InWHiPodgJa9Z6fzzwOh8jAS0e5UGSyYRm7PzgDsSz8goEMpLy3c7wQKlSCGQsv27ItG2zv/c3OfSyUj91wQXf4ZbHqAzR6i0URqFkROuW7WItPcbUKPpU6RRl8/5UZ/2lzMuZcNn8t3kUGzX9XUgTX3ZVsNjOKvDEVEZNZtSbBY8sHyYi7rM1oCiXXFUmmh0er4I2xh8x+iVfea+gevwrh5ZCEzppGv88hiYIZIOPdedXuxbLk/7NUwMIPKZlciNUKgq2tDJ5kxWdRp6CSveODcoROfKBu56UDxvU44FECn4Gw5NsRo2Jx0ck7gMgPO2JCIwE9rbOgd0MbBb/XGf8mWPF5ZzP/r59Q7YgPPa4LG1WiCmR1gVT2hRhQbbYZm0FOkwlUAk48f3WPOslGoWA+dF6SOSPvuiKZG92pk/+jofj1AF6R9xjTmv/JzUI+TqRngauERbR+vjRPDuSQlTxFIJwFnuOTOfuThylL+53AaUd//yag+qZF2Pszzmc32BWdK0LMvqrd1zhIh6VXRFbYOhH1xqguDm05XXeuY1QPosSc8gC5A4geT6NrGSZnes68X7Z15Anqr+VjAcmXQvHtzKSiTOwMwqBdbyOuJZJIg1E8091mOea60XDmCuzdLQdQ3LECnFcVSRyHoO6/fSsa3ZSN7Msg7SEMDrF4q3hVEn3msSSnPlov5L/yy2PAA3UtF6lMCfaA+S+b3ykbu86YC6DAZT70PghUEnNr3TDDol62t5FoAazm9RtjbYrARWKjFhxaDtZxeI+z9H84ujFdb6dngAAAAAElFTkSuQmCC",
  E = { class: "px-[22px] py-1 flex justify-between items-center bg-white" },
  N = { class: "text-[22px] font-semibold" },
  O = { class: "flex flex-row" },
  V = ["src"],
  Z = ["src"],
  k = d({
    __name: "ContactHeader",
    setup(c) {
      return (n, e) => (
        a(),
        o("div", E, [
          A("span", N, C(n.$t("contact")), 1),
          A("div", O, [
            A(
              "img",
              {
                class: "h-7 w-7 mr-2",
                src: l(x),
                onClick: e[0] || (e[0] = (s) => n.$router.push("globalSearch")),
                alt: "search",
              },
              null,
              8,
              V
            ),
            A(
              "img",
              {
                class: "h-7 w-7",
                src: l(q),
                onClick: e[1] || (e[1] = (s) => n.$router.push("contactAdd")),
                alt: "add",
              },
              null,
              8,
              Z
            ),
          ]),
        ])
      );
    },
  }),
  w =
    "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFQAAABUCAYAAAAcaxDBAAAAAXNSR0IArs4c6QAABuZJREFUeF7tnXlsFUUcxz/zSrmvconcR7lB2oBRE44YEDmiImBVIlEgsYAJYPQPg6LGqIloIsGjYFAOJaAcIgoqchgIiahAC5WrUEBALqGUcvTg7ZjplqPta9/b92b21cfOf83O7zu/36fzZmd/M7sjqKTIeT07YvlGQNwgfHRCylYg6lVmE3vXZB5CnMAiC2FtoNC/TkzNPFxRnCLQBRtktbcQPAXCF3uQIorID3Ip4vqbIrU82HJAZVrvFIRvAVA7omZj3lheQcpxYnLGt7eHWgqoTEt+CSHfBxGw58Y8I8cBSgspXxaTMz68YXoTnPw0aSQ+Vno/cadUpYXFaDElfbWyLAZaMmamI0Rdp3Je/WKCeVj+JDFlT7YNNC1pCUKM9eBEQkAuFpPSnxVyfnJbimQ2wrubR4IT8CNlopBzk6aBmB2hmGdeTMCaqoCuBTHcI6KBgJRrhJybvA/oqkHOk4D9QqYl5yKo79HQQEBySfVQqUHKkygh4AHV3BU8oB5QzQQ0y3k91AOqmYBmuarbQ+OqQ1wNO1x/AfgLNYduRq5qAa3dBJr1hLp3Qc2GpSPOvwh5p+FsJlw7b4aGBtWqAbROM2jRB+q3Dp7blhJyj8OpHXDlrAYEeiWiD7R5ErS813leW1pwYjuc2a2XSIRq0QXa6n5o3juyEE5nwInfItPQaB09oE27Q9v+ekI5thXO7dWjFaFKdIDWagTdRoEvLkL3S8wtP+xdCfk5evQiUIkO0MRh0LBNBG4HMM05AofX69UMQ819oDUToMcTwe/mToNRd/+/vgE1vYpicR/o3X2gZV8zIZ/8A07tNKMdoqr7QDuNgAatQnTPYTU1P81a59BIb3X3gfZ6GmoYWiAouAR7luol5FDNfaBJz0G1kmd0h84GrX69ANIXBq1mskKMAc2H9EUmeQXVdh9ojxSolRDUsbAqXMux7/RRLO4DbT8IGieaCfn8ITiyMbC2rxqoG6IqWWvBum7EB/eBNu4M7R80EgzZm+BCVmBt9WQ24DX72pa3Yd8qIz64D9QXD73HQVy83oBUAjrjy4p7Xp9U6Jtqt/nnPNgxT2/7JWruA1UN68gylcVxKh1Obq8YUkwDVeNZ9zFQs4GeXpKfC3tXVD4uxjRQhVFl6bs8GnnGSWWaDqwJnr2PeaAKasP20GFQ+FAVzOwNcPFo6Z7efwZ0HQnqlxBqyVwG22aFWrvCetEZQ293p3ZT+67vdG6q5pxHN8OVc+WDSw0jQaJWVuc/EANAVQhq83SzXtD8HogP8jZP0VU4vRvO7gG1rhSoDJjpfDjJ/Bq2vRcjQG+GIaBeC0hoBzUa3BoK1E+7INf+aV/6R70V4DzwO2IMdY4lfAsPaPjsAlrGJFC1ONemHzTtAXWaQnydyJdCiq7Zi3P/7geVsc+p4L3WmAKqttjcNw06DtH/yFm2O6rl5J3z4eivpa/EzLN8i74w5ANzWfqKRoZjW2DjDFCzAlViItukFuSGf2wuQx9smM3Jhu8m2jMEl4q5ib2asI9Z5nzCrjtwtVtPQbWKdCsH1DMHdODr9uNfVSjb57i21mQGqNrbOe6X8J/Rdf8TCi/D4ofsjbuGixmg3UbDgFcNu+5QfvMbcPB7h0bOq5sBOuhdSBzq3BuTFmoDxKaSJRCD7ZgBmrICEjoYdDsMabXWtPzJMAydmZgBOmEbxNdy5onp2gV5sHCg6VYwA/T5HZE/UuoOXVO+M5hbZoCO3wrV6wRr293r1y7A4sHG2zQDdPRSaNLFuPOOGjiTAavHOzIJp7IZoP1eAbXlpiqVXQvg94+Me2QGqHqz4zH1cbIqVJanwIVDxh0yA1S5PXQ2tB1gPICQGlATejWxd6GYA6rW3Ud9BSoXGs2idjWvegYK81zxwhxQ5X79Vnb6roHmNz5CRXNuH/w0Ha4GWGoOVcNhPbNAlTPqrWJ1g0p8GBp1sv82Wa7n28shasvivtUg/SZbK6dtHmjZJms1NpdwVjDVfDOKxX2gUQzWjaY9oJope0A9oJoJaJbzeqgHVDMBzXLexwR1ArU/Jph0AERnnbp3rpY8qID+DGLInQtBZ+RyvffJYJ08kdOFTEtqhyC76i0CaY3UBTEpqSbal3x2vffnCN8EF1qN3Sak9YWYnDHRBvpJz9bExasvSpX5Plrsxq85slz8Rb3EC5nHbx1d8VnyMCz5g/NPfGl27f8n58fiETFl14/K9UCHq8zyoIb6X1WHq4gXxeRdc25YBDr+53GEWHTnHUQVKsQb9eRlsMaKSbtL7UCr4ICq7m3wV38HH2O93loOtB9LLiGucKZI3ft32auVnptUfIqNjBuO9A32jlAjC/wb8VlrA530dQPsfxtpkfccR1QVAAAAAElFTkSuQmCC",
  T =
    "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFQAAABUCAYAAAAcaxDBAAAAAXNSR0IArs4c6QAABq5JREFUeF7tnVtsVEUYx3+zvdByvxYitlCgIkil1QcTEBQxKhAFAoKgSIAHaI2I0ReNREIkRjSRSLBgRIQIKKbcFPBCDXKLGJWWFigCRSgPXIVCubZ7xkxP1+1lW86eM2nLdual2Z75/jPfb7+dmTMz54ygniSXDeiN5RsFUcPxkYKU94JoU59N5F2TVxHiNBZHEdZ2bvu3itkFx+vyU4S6YIOMno/gBRC+yIPkySM/yLWI8nliZm2wtYDKrIETEL4VQEtPxUa8sbyGlFNERt6Gqq5WAyqz0t9AyA9BhIzciGcUtoPSQso3RUbexwHT/8HJT9PG4CPb/MTDpSotLMaJzNyNyrICaGWbmYsQrcOVM/krCF7F8qeJzPwiG2hW2mqEmGzgeCEgV4lZuVOF/Dy9B2WyCGF6cy84AT9S9hFyadprIBZ5FDPmFQSs2QroFhAjDRENBKTcLOTS9MPA/RrkjAQUCpmVXoKgraGhgYDkiopQqUHKSFQSMEA1h4IBaoBqJqBZzkSoAaqZgGY5E6EGqGYCmuX0R2h0PMR30FzNOuRuXILyGw1TlsNS9AHtmgaPvQMdejksWlO2i0dh1wI4e0CToDcZPUC79IcxX4Iv2ltt3Fpb5bDhZbhQ6FZBm50eoGNXQcIAbZVyJXQmDzZNc2Wq00gP0Bl7ITpOZ73C1yq/CcsHhW+n2UIP0Jl/aa6WS7llD7k01GfW+EDLb0HxXmhzD3Tu680zAxTY8wEUfGMvwE5cD+17uIdqgAJbMuH0bzbEZxZBj6EGKF7a0K2vQvEeG+KIxZA02AA1QIMx0LCdUtl1yF0B184Fa3B6X/Bz90egdYJ9TURB0hBIHuY8YptdG1rwNexZ6ByQgjp9N0S3cGazIsz2V41d1V2WxtSwEXpkM+yY57z6sa1h2k7n+f9Y5jxvIOeNi3ByF1w7G75tCIuGBaoqcHIn3LwcrMqBr+DfY/bn1BehU0rwWrc0aJfk3FE3QJW6tKBwA1y/4LysOnI2PNCaFdHZy7sFqupUegaObDJAqxHwAlS1pfuXG6DagCqhP120wTW+gsb/yeevgb0fQXxHeH6d/ddt+n2JtznZiACq4N26AjEtvcFQOuunQNKjbr+OCIlQ9+7Xtlz7HKSMcq8YMRHqHkF1y7WjIcXDVtcmA3RiNrRP1oXFnc7lE7BtToQAHfI29B/vDoQuq4PrYN9iaNs9qBjTCrqlQ1SMs1KaTITGtoHxa6BNFWecuaAnV0kxZE8CNflSMyUOdr6A2GSAKid8MZA6CRJSIa6d7VZUC+iaWj+0SyecT34opdKzIP22prqFPZsPatLFKgtdTs9h0Ok+Z19ckwIassoCpuZAXPvQDh1eDzvfg4dnOnO4AmKJfZsYSGpy41y+/UmNYRMeDF5TK7HhLKk0faDA8Pehz9O1gRVuhF/n2/8PB2hNpZJTcGyb/d+2iRHSKdUXX31Hw+PvVs9xdCv8MldN8xigzn+blTlbJcBLPwTNjv8MOW/ZU2aBZCI0TKyBxbei7bBdwazsVHQALbsBh761d+ElDrI7RbfprmhDlXPqMdLWXeGq6kxCPMXjJUKVvop21curUYWXdNcAvZOTXoHeSd/pdQPUKSmH+SIG6AMTIK6Bdj3XxfbmJVC3rx6Tnglmj5WoWH9Xm3YbM50/CKd2e65B0wAaFQv9xkGLRnqG91YJHMqu+/Y1DMxNA2hgJKCGPGrc6nbzbkz8nZsOtf5uVQ7b1FCr9BycL6g+Lg4DYM2sTQeoByeqmSYNhS79QqupnSJ5K3WVFFIn8oAqN9WWyM4hoKoNFSdyDFBXBJKfgI5VdqEokX92wMUjruScGkVmhFZ4L6DXcOjQu5KFBLXtJ9QktFNaDvJFMNAA1Cfth9FKTsKxKpM0DuC4yRLhQCuRqF18t6+FnkdwQ60em+YBVDO0+uQMUM2wDVADVDMBzXImQg1QzQQ0y5kINUA1E9AsZ14mqBOo/TLBtCMgHG7+0Vl6JGrJvxXQH0E8FYnuNbxP8ifzymCt1OUcIbPSeiIoMocBeCUrJdEiufK16wOXI3zTvUo2a3tpfSEy8mbYQJcMSCQqRr1Jqo6NnM0alRPnS/CXpYpXCoqDR1d8lj4CS35vjq5wwq9aHj8Wz4rM/RWbVEMdrrLQQHUKVR2uIl4XGfs/CViEOv5nLEKsbH4HUTmFGMgnS8GaLGYd+K6qZR0HVPVPwh+7AB+TTbTWAu3HkquJuj1XzDx0qubVes9NqjjFRkaNRPqeNEeocRT8OfisLaFO+gqA/Q9TFJ73I+3lNAAAAABJRU5ErkJggg==",
  X =
    "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFQAAABUCAIAAACTCYeWAAAACXBIWXMAAAsSAAALEgHS3X78AAAGd0lEQVR4nO2cX2xTVRzHv1wGXbLBGpbMBWR2wrQxJTaRGJMZLFNwIMgwPgz/hPKkPg0ffaImRuOTM9FITAwjRsUHsSIuxAdWDDMzIWaLizRsyOh02ZqwtIOaXRnM/HZvb9t7zrrennO7dnefLFlze/e753vPub/zO7/f2V0zPz8PhqSKH0Zw9hqi05i4g9v/saeUOxvWY0stvPV46RG8uB11Lk57zeKnUnh/AJ8PYvZe5QlejOq1eMOPd57CAzU5Z+SI/+k6XvkRMxXYz4WwcT2+PECjwEDRfs0DoX4c/G7FKgdIWsdZvPcrjN7We/6rP/Ha+WVuXMk4tQ/BHdDF98Ww91vMcRzfymSdgt6X8ZxnYdh/fMVBygHcvY9PfqcPSvxfnBtd/gaVmHOjmExBOXsNTup1nXkgPALlzNWyaE3pOXMVyuCU01TrDE5BWUmRnCVm70FRnSpevZeO8JzJqninsireqayKdypVpdR9qAWBrfA30GdPHf0AGEvSD4VccUTGKXdYMtbgQ9vXNUd96GhBoAluXhbRREJFJEarjtPDtt8De8UHmvBRm97VVhmM4+2LdCPswy7x/gaSHWgStROJ0S0YjMtplQlbHF5HC/qOSFCujR1Zpljki+96At8fLujxLhC3C32dCPqkt1T2sD+1P18rk2lnNjaTcfKa2/ds1J0it7Si0TOMY70SGytV/PGd9JxzuTmD0GVq/ZIEfQg9jYc28s871luQkQKRJr6jhUY7S1Klckj3FWvWQq10K7mjYPcZaVOAHPH+BnJL7HOeVBH4huOrG2tQnRVeTaYwO8exGTnC0Z9QsZtnswjkiO/r5DjkoTgpT6iZI546kuStp8qhieg0uYCBiZyjbhfpf5wJEyIx6v+yEE+zUaf5YFKF52RGeWMN2pv1eDYPCRUXbiB6K3OG24WxNzn9L2XwS5jqWCenjXZDub+BamNLKtekdnrJfRgkFkwlVfOZi3lWS4iKD/o40WuoP/NM+htIDDvO80A3K2u+HIxz/KXpnOIQFZ/dSxo3ZzJt9dZzTigET13OH4b6yeySl7aKqPhnGD8Xuqx/cLuE2qe5RtZsnktbRUh8R4t5ekuqmSAk0GRttLO0N2dmxJ5h85PvdonG/ELi2afd8MBuV5Er2WxMRlj3HtgqZF9IPHvjw+k8TPaIFSFbfJhJ8ixnz7OMpd2Sd5Mcg9mx4Bjj8wQREs8uP7SFGjW6VloTG9P7xxKz5q/yLAELQUg8G7cY4gVdHRc2nhd0KxWQum6sKeCkohASP8R0RSExrFUmU/ofsP3MNsASQuITTMhtiGe/EsddvXQDSieexZN2gUZ3iWP4Ec8i6Z2iERLPRh1GPJu9LBUhOs0xnqcBlhASz7pfI96OTsvZt519E9lgPjIuZFxIfHiEE29rK83ZOXNapggmU5n7G/Rx1hHL2fPcgXeiVf8wMCH65F+4wTGb59JWERXPxtueOsq9ap0fHil+8FN6P+3qQq2cSZS9tFVExfcMcybbrp36nDyZQs8fxegfmMjJBXXtNJ8wFJeQwJcw1R2/aD5CBaZ0JlvTb2n8h0cyAz7bVP6LFoEE8ZEYLjFe16x/mDzzkkMgOk0pMKPPF1N+aVxO3UJa0aKQAkN1FS11vfXmBe9kimRHb+UMEKuFkCKwvVyVUKkz3+3nfFVdxSnUaJxYKFdxS70Sy1VrsSckxVB0mvqkvdl8vLqK8i1BH90Fk2ucu8+xc9SH8OGFbDdvu9CxXglO3kByibpnP7V+MYz9NmNJulPa0PU30POi5arz79s5PYxg2ZaoNfIUqkWQW5zWkJ/M6L5CjyVbYCqapEoGpSu3K5MTiZFDZue/Irg0TqZs2pNl+1a07jZOjbkQhuIUyVTkVrRsgr6l99sYGPt27BjnJkoh3iDQRDUWrdLgdukjYiiuZ6MiMYoCbe1qEyUVX26sbjl3KqvincqqeKfibPEuG2rJFUHdeij2FYDLnMZaKOLbhioU7yYoNv0HR/nT/jAUNuvmFPHNULz1eN55+g9tp6zhwntynoWjfL5rLT7dA32ef3QTTu5d/jaVjC/2YcsGZIKc4A5ODXhF8sEuvPqYLiznlXDnRvH6+ZX8SrivD+KFbZkj5pcB/n0bb/2M89eXoXG2cmAbPtuLBzfkXIP/GshfxtEXw28T+CuJf27jzt3KU1u7Dptrsc2NJzejrQm7mP3ZAP4H1J9GwCVK69gAAAAASUVORK5CYII=",
  K = { class: "px-[22px] h-[66px] flex items-center bg-white" },
  j = { class: "flex justify-between items-center w-full h-full ml-4" },
  v = { class: "flex items-center" },
  H = d({
    __name: "ContactMenuListItem",
    props: { icon: null, title: null, badge: null },
    setup(c) {
      return (n, e) => {
        const s = G,
          g = S;
        return (
          a(),
          o("div", K, [
            r(p, { src: c.icon, size: 42 }, null, 8, ["src"]),
            A("div", j, [
              A("div", null, C(c.title), 1),
              A("div", v, [
                r(
                  s,
                  {
                    class: "mr-1",
                    content: c.badge,
                    "show-zero": !1,
                    max: "99",
                  },
                  null,
                  8,
                  ["content"]
                ),
                r(g, { size: "16", name: "arrow", color: "#999" }),
              ]),
            ]),
          ])
        );
      };
    },
  });
const m = I(H, [["__scopeId", "data-v-1040f641"]]),
  y = { class: "mt-[10px]" },
  W = { class: "mt-[10px]" },
  J = d({
    __name: "ContactMenuList",
    setup(c) {
      const { t: n } = M(),
        e = U(),
        s = f(),
        g = Q(() => [
          {
            id: 0,
            text: n("contactMenu.newFriends"),
            icon: w,
            badge: s.recvFriendApplicationList.filter(
              (i) => i.handleResult === 0
            ).length,
          },
          {
            id: 1,
            text: n("contactMenu.newGroup"),
            icon: T,
            badge: s.recvGroupApplicationList.filter(
              (i) => i.handleResult === 0
            ).length,
          },
        ]),
        R = Q(() => [
          { id: 2, text: n("contactMenu.myGoodFriend"), icon: z, badge: 0 },
          { id: 3, text: n("contactMenu.myGroup"), icon: D, badge: 0 },
        ]),
        P = Q(() => [{ id: 6, text: n("moments"), icon: X, badge: 0 }]),
        b = (i) => {
          switch ((console.log("menuClick"), i)) {
            case 2:
              e.push("/myFriend");
              break;
            case 3:
              e.push("/myGroup");
              break;
            case 0:
              e.push("/newFriend");
              break;
            case 1:
              e.push("/newGroup");
              break;
            case 6:
              e.push("/moments");
              break;
          }
        };
      return (i, _) => (
        a(),
        o(
          u,
          null,
          [
            (a(!0),
            o(
              u,
              null,
              B(
                l(g),
                (t) => (
                  a(),
                  F(
                    m,
                    {
                      icon: t.icon,
                      title: t.text,
                      badge: t.badge,
                      onClick: (h) => b(t.id),
                    },
                    null,
                    8,
                    ["icon", "title", "badge", "onClick"]
                  )
                )
              ),
              256
            )),
            A("div", y, [
              (a(!0),
              o(
                u,
                null,
                B(
                  l(R),
                  (t) => (
                    a(),
                    F(
                      m,
                      {
                        icon: t.icon,
                        title: t.text,
                        badge: t.badge,
                        onClick: (h) => b(t.id),
                      },
                      null,
                      8,
                      ["icon", "title", "badge", "onClick"]
                    )
                  )
                ),
                256
              )),
            ]),
            // A("div", W, [
            //   (a(!0),
            //   o(
            //     u,
            //     null,
            //     B(
            //       l(P),
            //       (t) => (
            //         a(),
            //         F(
            //           m,
            //           {
            //             icon: t.icon,
            //             title: t.text,
            //             badge: t.badge,
            //             onClick: (h) => b(t.id),
            //           },
            //           null,
            //           8,
            //           ["icon", "title", "badge", "onClick"]
            //         )
            //       )
            //     ),
            //     256
            //   )),
            // ]),
          ],
          64
        )
      );
    },
  }),
  Y = { class: "page_container" },
  L = d({ name: "contact" }),
  tt = d({
    ...L,
    props: {},
    emits: [],
    setup(c, { emit: n }) {
      return (e, s) => (a(), o("div", Y, [r(k), r(J)]));
    },
  });
export { tt as default };
