import {
  d as R,
  v as T,
  y as z,
  r,
  a as J,
  B as i,
  D as d,
  F as s,
  G as n,
  f as l,
  J as v,
  aI as y,
  E as D,
  e0 as X,
  e1 as K,
  $ as L,
  aF as Y,
  as as W,
  at as q,
  M as _,
} from "./index-367d22e2.js";
import { A as Z } from "./index-df22ba30.js";
import "./index-02886b08.js";
import { P as j } from "./index-50825771.js";
import { F as $ } from "./index-9e32bade.js";
import { m as ee } from "./md5-b8127720.js";
import { l as te, s as oe, w as code, x as auth  } from "./login-083206d0.js";
import { c as se } from "./areaCode-4740d148.js";
import ae from "./Config-f9f182d1.js";
import { B as ne } from "./index-0f5c28c4.js";
import { F as le } from "./index-02f535b1.js";
import "./use-id-ce6fd248.js";
import "./use-sync-prop-ref-9c65a825.js";
import "./index.vue_vue_type_script_setup_true_lang-d7754eca.js";
import "./index-e4ec3b15.js";
import "./arrows_left-58dc349e.js";
const re =
    "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEEAAABCCAYAAAAIY7vrAAAAAXNSR0IArs4c6QAAD0JJREFUeF7tXHuMXNV5/517Z2bnset9+YEfaxs7tAQrNE0gjkgFTkkUCmmjRCWt1Db/VG3KI5VaMFWqNK5pIkJVqQnBdShVk1RNKkFL/0hagoMiJ6IGTGJAGNusH8SPXT/WXq/3NTP33nO+6juPO2dmZ7yzy8ZEYley5s7MvXPv9zu/7/X7DgiYP2Ff35EvznhBRO9MAIRIGbAIArvDIhMWQTCBcZEJiyAsMmExRS6mSEAsgnBlQBB7h9CbCbA+lnh3otQ1kaSNCsFSKRFIUmMJicOU0FGJcLCicDhzEOfvvBPqSpWvvzAmHBlFVxTJDyUI7pagDycKJamAhIBEAXws02OCsu8loSoJz8fAY+VK+ONnj+Ecg7HpThC2G1i2bcOC1vcLDgIbrxR+TxF9SRItZ6NjaQzXxpMBIAVCf0YaHPcdU4CPlUK5mtDOUxcyjz71PIYKw6CuVaBl14EcKAsByEKCII5ewhZIfCshGjBGU2q8v/oMQuzYoNlhzmM2aDD4GIBiIBhEhequn+Nnu06Eu5IEP8lL7P/Vfox1nbaAHDDMmC8gCwLC2bMoljvwZSL684QgnMGxBaHRDfh7Zof7XDOhgSkMCAOgGQHSr2+MCnznYICJSFwC4at5iW9uSHB6OaA0Ow6A5gPEWwbh1Dh6laLvKeAmyUZ7Pq+N1StujbTfxUog0S5CiA3tDQj22LmFdQkoMiAwO8YqwOOvhThfFqyATIJwf18R/3HVKCrzBeMtgXB6Av1EeCYhep9ZVWOsDnoWADY2tj7vVptBkO5zPtePGc4lHAs0MJS6CEse0zHw+P4UCICwu5DFZ1Znca57P9SGj0DNhRXzBuEsUFQTtFsSbnArx8ayQSkANi7waqcAzPjesMWBZxhhsoULpC42aBexsWIiMkBMx5oR/HcCwG3vKuBYdwfUht72gZgXCLt3I3z3jfiWVPQHabTXhpKmeS0GkDbQGZlmCV555xrMCOcOaWC02cIySpGw8YEgLQikgBMTAk8Ohvo7C8RZKNy0vorhIqA2XQfZDiPmDML27RCfvV/+IUh8u+a7wq50fTbgwKhZ4OhuX5sBUweEC6guRtjUqoTNHNZV2DVeOC2w90zoK6SvLMni1r5xTPevhGyHEXMG4dAQ+pb2qMMxodcVPJIDnU5tBoR05X0QvBXX39v3jh0+MIk0MSAtqHj1LVu8GiLNHt85FGKq5hYcI76+IsTnuzqQuBjxxGUq0DmBwCy4e6v6GhHubcz7zAobwKuRRK6cIIwlIfJo7xgRNYCgGWONTFOnTZEdWSATmKwwHRlgmP2ahbaOODIm8JOh0NfMFQRuXtWNl3t6kSw/ALUFUK3SZ9sgMAB33Y9lQUAnpaJsfcXHTQiige4gDAD9NFMx1JsXlRiLILSRiakN3Iq7YwYmamAQ+3hfHvjYxhDruk3U44zw8J4EF6dtKmUgXEGlgP8+OoMNu5YK/G7ncsT9kXGLVmyYEwj3/pXarpT4AtNe1/3S0hTA8pKYLmVFsbHpqSSEQxcURqaBKgNhC6W6VwsCG7+yU+BjGwL05GeOQV4aJnzzZYnEGs8guFriwKjAa+fr2IAscGNfgIPsFmtGIVuxoS0QmAXXbYP4zTIdVYR1nAVSn2XfBbCyKxjLh+gRTUY4HMB45Q9eUHhzjFBJDIDOLSAIG3sFbloTIp/RrJrxx7/x+gjhkb2ydm+PDZMR8IMTGeMr7nrC1/qK+GIxQbyihKRVkGwbhHu24n1C0EsmWJlUqMtaC0JXTpxZVhJX6aevf5D0odgQvmbwgsK+MxxECb+2PMB7VgQION3XHt43JD3+530SLw4pcCB2xZmrG5gRHBfGqkEtNhCOdRNuyGcQ9a9D3Co2zAoCswDbgLun1AOBEA+Z9tcywaUwXhEFtaY7GClksKLZPK+x9z0yShqra/rqz2517ctnCTv2JhrExIKg3dK5BAEHLgY4Nh7WLUKOcH1nBceXrEO0fj2SLVugtpkz0r+2Qbh3mv6TgE+ah6gHgX2UwQHEhV/pE10CyLUSRPSkTwAnxwl8vNYGvssNQllguO+HCcrWjTQINiVrRnCMADA8KfDqhXqXCAl/1FXB94tAtHIl4mYBsm0QPlfB60rRtWmBZN1C52+XshTQlRPnBpaI5a382oEzPGHcamBJzfxW1zy2T+KnwyoVYWaAwIwUwKWqwPNnMuYWNZf84pIydhRKqLJLbMLMKvKyIDhXeP1JiJ0fp3EiFNMCya6EZoaLDbYmWLdEjPYURF9T/cfaPDIFcOYYsExode7eYcK/vpykXabpQUwZXcdIABUpsHtoBgiPdEk82BEi6ikgapYl5gIC9zVpFefo2AyE8SrhxlUB8mFrknM0H4+AVZ2tlcTphPD5H0lEslZMORDc/V29YgoogR+eagCB8Finwt/kIlSXANF6INmyrT4utAUCdiO4dzNxk1gDwbmDzwSnIUpugAQ2rzKRuhnNGbyzU1wX1IPg7w74xj6p06LWHfz2nGx28FJ1SxCARzsD/F1uCpVWwbEtEKw71DNBl7WmaKoJpuaYy2Veof5SgHf1GDY0A+JSFejuaA7Ci8OEJw5Iq082MKEJCBwYGfhnG5gQEB4sSPxTLkSllEPE9cJv/ymknyHmAsIYETprTdNMEJxG6FrqqURg8+oAxcsUQI3gMBMmY+DLzyWmzNaldo0JWrj1U6TrMLm0TgR+PFzvDqHCH+cV/scHoTFDzAWE/US41g+MNZnc9P/KtsqaDWnXJ/Aba1qzweeBc4XHX5G6snQgaHewGoQRaIw76Pu7fwAuVAVePGtLZ5sdsjE25wSOLwgTdnycnhDAp3wmuBihZTVXOHmCiWurl5cEru0XTV2iEYQXhhSeOapMSe36DOteGlgLgrtfCgSA4xMCr43WgfBmnrAlU0ElhwWICTtuV1tFIB5yq88PwepOWkb7gqk3ZGFDOBV+cHWIrlzz2KDTOnGeB3b+NNEs8kHwNQonyKYzCscIAvadD3Bi0pbNpibcWUjwUCaPcodEtbOMeP0tM6vGtt3hH29LPpDPhHs0DW1GcLK4ztduqGK7S19m5+/5RresbZ4tnBv8+36JoXFPW3C6g23AXADWMwr7DLWFAP73eIiytGmZgAzh1qzEG5kAlXyEancfYl0nzCdFcnbYtAzins00SISrGyVxV8P7GoPWGr3YwKCs6BLYtLQ+PjgAXhxWeOGUMnGglf5YN7ozv69BIOB8GdjlMgNzQGFXPoM/CyJUsgyCbaLmXTHybzIQO+5QfwuIL7gsoFVgqw775bSuIJ2u6M0huAf4wOpQCyb+34UK8OTrMs0CqS7p2m238k0GNFbRwp4zAQ6PWVdgCBLclicMZjpQzkpUCxXErndoFF/b7h0YhAc/ioGlOToqFQLdvbkpkXMHf87ouQUbZeaPBN4xeOvVQV17/V+HFC5Ok4kD6YCmpl7XBjM1QTeV4Qm6sfruYKgrRts3PN5B+PsgQCVTRqWj0DoemBpmln2Mfv/AFzx6u/o2ILTUzg9nMoRVmlxF6c0UNSPgxm5GhxCBwPUrhA6ArBZNRl4KtHHADHJr4o0BwqRGbrycvsj3f+50gFdHUhacyiW4I1CYCDtQzkhUF0xPcC7x4EcrA0tzHW/ECrm6MZnzVy9L+JWkb1SqKnnMYUHWF1k1I1zdYbNQOrm24gy74mgF+LdDdvaglxU7OxJ8NVAoh4GOB5GrFN+yssTCCrsE3+eR23EfiB52A1MTnOrH64b+tXG7cQnDBDeN0qnPp7+tMUzpXT+VSl2Pf8dK8Hz/7x4KcHKy1qgFEltzAk9pV8ii0jGOqFVWcHFpVnfgExtd4vZlyN52Az1DwM01Nli/d7HCG7Jqd7EGazp7GcB87oHjM8AFVa9x07GAQZDAvnMC33szdQOtIQQKX8rl8C9hFZVsjCqLKT1AcrlpVFsgNANi65apZQPF0h6p6GqXJfxmyuiPNlZ4dK6N7f2VrrGozgXcDNPS38UBFxR3vhpgyGOBFVJ+UAD+JBOikp1ExJ0jS+6NTZOfneYGAl9p3WLkAMQjd2Ftf4H+TwFX6cLJiwuGId5M0fN/J8KkexLqWOPtW0i38NSm0mlaVsBfPxfWNjY51VDgUiHGpmwR5TpXWIjhi88GFyRHlkF8/dexrlfQ0wq4JlWf06035uH96XJd2etR359C+8WYywb8206t1gGXkPzl7vA+AB8GcDMIfVZqP1dM8N7ZCqR5McFd1BgfGIiHr0H3VZ20EwJ3+g2NiwV1kpzn564JcoxIy3BvxOYHRNan+RwNBoCnBsNP7D6JEyBkiNCfCGzMEF7JKxxuJyvMKTD6qGkQPLfgQwbiU2sQ/lYfficb0mOKePeKzRhpQWW1SF+PtL7uzzUdEC7zpHFA700wCrVmBXeNl8T2r7wUPCEkJCIkIos4DBAFCWLWFNsZwbVVLNUXuOZdUyAOQOAW4Cvr0N/XrX4/I8QDkrCqntq2+LFjtFQ1dsWPE0hcHeA2cbn3tttkALT4EtHTf7EnvIc37TAQQQ5xECDJJIgLvYjTYWxDw9RoU9uBsfHCZkA4VvDrA9ejuDrGjfkMPqFAnyTC6kSRcHFDu4KrAC3NmemRws8vTtPTp8v4WTkOJ3pyGOgr0K25kD4EQrdzBX6tSvHsXc+Lz+A8EMSQIgeZYRC6IEtFJG4QO9tGjXmD0MgIFywdWOwifDwxCPHpTci/f2V1ZSmX2ZgJwg2JVKsQBp1xrESkMDEtg5HRaXlycDQ8+v0jOH/0IhKU7C9NgUc5tGUApQ+uwtq1JbW5mBN3cBw4eFbc9w9H8IaIQOIcKFOADAOowlLI4nEo3sjFbTNvAr3crra3BEJjsGwEwmcGg8Hvy70Q0RmIpAsiOo5AliBUEYImIVQBgjogaBoCPfbXxwBRNFMJUQUFZZDobJhSjIAn0CpYAspnoHKjoLnsZFsQEGZjRcoOGzc0IO8HysdqgPA5yUUIVWr+nyYGU9bwk0Cme+aohvcoFVaaz7lH4Fd2Ax3DZ9kGvGAg1LHCvdlmDlzP0RhXuODiYOrcRjPldHMQnIH+b/COVveeN3Nqw3kPtF6V2Y131y44CJcDoxEE/30roBqv8Td6N/u92Va92TW/MBD8m6WZ5HIoNHznG9Ps+vkY2+r2VwSEOdj+tpy6CEI78trbsjRX+KaLTGhkwhVegF+q272j/78Jaa3wS7Ukb9PD/D9gMeJG/GFPJgAAAABJRU5ErkJggg==",
  ie = (A) => (W("data-v-ad761f85"), (A = A()), q(), A),
  de = { class: "page_container !bg-white px-10 relative" },
  me = { class: "text-lg font-semibold mx-auto text-primary" },
  ce = { key: 0 },
  pe = { class: "text-sm mb-1 text-sub-text" },
  ue = { class: "border border-gap-text rounded-lg flex items-center" },
  ve = { class: "mr-1" },
  Ae = { key: 1 },
  Ce = { class: "text-sm mb-1 text-sub-text" },
  ge = { class: "border border-gap-text rounded-lg" },
  fe = { key: 2, class: "mt-5" },
  we = { class: "text-sm mb-1 text-sub-text" },
  he = { class: "border border-gap-text rounded-lg" },
  be = { key: 3, class: "mt-5" },
  xe = { class: "text-sm mb-1 text-sub-text" },
  Ie = { class: "border border-gap-text rounded-lg" },
  Be = { key: 1, class: "text-primary" },
  Ee = { class: "mt-3 flex justify-between" },
  Ne = { class: "mt-16" },
  Ge = ie(() =>
    s("div", { class: "w-full h-[1px] bg-[#707070] opacity-10 my-4" }, null, -1)
  ),
  ye = {
    class:
      "text-xs absolute bottom-6 left-1/2 -translate-x-1/2 flex flex-col w-[300px] items-center",
  },
  De = { class: "flex flex-row text-primary" },
  Fe = { class: "text-sub-text" },
  Ve = { class: "text-sub-text" },
  Pe = R({
    __name: "index",
    setup(A) {
      const F = "IM-HCER 3.5.1+3 SDK v3.5.1-e-v1.0.0",
        { t: C } = T(),
        B = z(),
        w = r(!1),
        h = r(!1),
        E = r(!1),
        b = r([]),
        o = J({
          phoneNumber: localStorage.getItem("IMAccount") ?? "",
          email: "",
          areaCode: "+86",
          password: "",
          verificationCode: "",
          accept: !0,
        }),
        x = r(!1),
        c = r(!0),
        p = r(!1),
        u = r(!1),
        m = r(0);
      let g;
      const V = async () => {
          (x.value = !0), localStorage.setItem("IMAccount", o.phoneNumber);
          try {
            const {
              data: { chatToken: t, imToken: e, userID: I },
            } = await te({
              phoneNumber: p.value ? "" : o.phoneNumber,
              password: c.value ? ee(o.password) : "",
              areaCode: o.areaCode,
              verifyCode: o.verificationCode,
              email: o.email,
            });
            X({ chatToken: t, imToken: e, userID: I }), B.push("/conversation");
          } catch {}
          x.value = !1;
        },
        P = ({ selectedValues: t }) => {
          (o.areaCode = String(t[0])), (u.value = !1);
        },
        M = () => {
          m.value > 0 ||
            oe({
              phoneNumber: o.phoneNumber,
              areaCode: o.areaCode,
              email: o.email,
              usedFor: K.Login,
            }).then(H);
        },
        H = () => {
          g && clearInterval(g),
            (m.value = 60),
            (g = setInterval(() => {
              m.value > 0 ? (m.value -= 1) : clearInterval(g);
            }, 1e3));
        },
        N = (t) => {
          (E.value = t),
            t
              ? (b.value = [
                  { idx: 0, name: C("buttons.emailRegiste") },
                  { idx: 1, name: C("buttons.phoneNumberRegiste") },
                ])
              : (b.value = [
                  { idx: 0, name: C("buttons.emailRetrieve") },
                  { idx: 1, name: C("buttons.phoneNumberRetrieve") },
                ]),
            (h.value = !0);
        },
        k = (t) => {
          B.push({
            path: "getCode",
            query: {
              isRegiste: E.value + "",
              isByEmail: t.idx === 0 ? !0 + "" : !1 + "",
            },
          });
        };
      return (t, e) => {
        const I = L,
          f = $,
          G = ne,
          U = le,
          O = j,
          S = Y,
          Q = Z;
        return (
          i(),
          d("div", de, [
            s("img", {
              class: "w-16 h-16 mx-auto mt-[88px]",
              src: re,
              alt: "",
              onClick: e[0] || (e[0] = (a) => (w.value = !0)),
            }),
            s("div", me, n(t.$t("welcome")), 1),
            l(
              U,
              { onSubmit: V, class: "mt-[76px]" },
              {
                default: v(() => [
                  p.value
                    ? (i(),
                      d("div", Ae, [
                        s("div", Ce, n(t.$t("email")), 1),
                        s("div", ge, [
                          l(
                            f,
                            {
                              class: "!py-1",
                              clearable: "",
                              modelValue: o.email,
                              "onUpdate:modelValue":
                                e[3] || (e[3] = (a) => (o.email = a)),
                              name: "email",
                              placeholder: t.$t("placeholder.inputEmail"),
                            },
                            null,
                            8,
                            ["modelValue", "placeholder"]
                          ),
                        ]),
                      ]))
                    : (i(),
                      d("div", ce, [
                        s("div", pe, n(t.$t("cellphone")), 1),
                        s("div", ue, [
                          s(
                            "div",
                            {
                              class:
                                "flex items-center border-r border-gap-text px-3",
                              onClick: e[1] || (e[1] = (a) => (u.value = !0)),
                            },
                            [
                              s("span", ve, n(o.areaCode), 1),
                              l(I, { name: "arrow-down" }),
                            ]
                          ),
                          l(
                            f,
                            {
                              class: "!py-1 !text-base",
                              clearable: "",
                              modelValue: o.phoneNumber,
                              "onUpdate:modelValue":
                                e[2] || (e[2] = (a) => (o.phoneNumber = a)),
                              name: "phoneNumber",
                              type: "number",
                              placeholder: t.$t("placeholder.inputPhoneNumber"),
                            },
                            null,
                            8,
                            ["modelValue", "placeholder"]
                          ),
                        ]),
                      ])),
                  c.value
                    ? (i(),
                      d("div", fe, [
                        s("div", we, n(t.$t("password")), 1),
                        s("div", he, [
                          l(
                            f,
                            {
                              class: "!py-1",
                              clearable: "",
                              modelValue: o.password,
                              "onUpdate:modelValue":
                                e[4] || (e[4] = (a) => (o.password = a)),
                              name: "password",
                              type: "password",
                              placeholder: t.$t("placeholder.inputPassword"),
                            },
                            null,
                            8,
                            ["modelValue", "placeholder"]
                          ),
                        ]),
                      ]))
                    : (i(),
                      d("div", be, [
                        s("div", xe, n(t.$t("reAcquireDesc")), 1),
                        s("div", Ie, [
                          l(
                            f,
                            {
                              class: "!py-1",
                              clearable: "",
                              modelValue: o.verificationCode,
                              "onUpdate:modelValue":
                                e[5] ||
                                (e[5] = (a) => (o.verificationCode = a)),
                              name: "verificationCode",
                              type: "text",
                              placeholder: t.$t(
                                "placeholder.inputVerificationCode"
                              ),
                            },
                            {
                              button: v(() => [
                                m.value <= 0
                                  ? (i(),
                                    d(
                                      "span",
                                      {
                                        key: 0,
                                        class: "text-primary",
                                        onClick: M,
                                      },
                                      n(t.$t("buttons.verificationCode")),
                                      1
                                    ))
                                  : (i(), d("span", Be, n(m.value) + "S", 1)),
                              ]),
                              _: 1,
                            },
                            8,
                            ["modelValue", "placeholder"]
                          ),
                        ]),
                      ])),
                  s("div", Ee, [
                    s(
                      "div",
                      {
                        class: "text-xs text-sub-text",
                        onClick: e[6] || (e[6] = (a) => N(!1)),
                      },
                      n(t.$t("forgetPasswordTitle")),
                      1
                    ),
                    s(
                      "div",
                      {
                        class: "text-xs text-primary",
                        onClick: e[7] || (e[7] = (a) => (c.value = !c.value)),
                      },
                      n(
                        `${
                          c.value
                            ? t.$t("buttons.verificationCodeLogin")
                            : t.$t("buttons.passwordLogin")
                        }`
                      ),
                      1
                    ),
                  ]),
                  s("div", Ne, [
                    l(
                      G,
                      {
                        loading: x.value,
                        disabled: !(
                          (o.phoneNumber || o.email) &&
                          (o.password || o.verificationCode)
                        ),
                        block: "",
                        type: "primary",
                        "native-type": "submit",
                      },
                      {
                        default: v(() => [y(n(t.$t("buttons.login")), 1)]),
                        _: 1,
                      },
                      8,
                      ["loading", "disabled"]
                    ),
                    Ge,
                    l(
                      G,
                      {
                        onClick: e[8] || (e[8] = (a) => (p.value = !p.value)),
                        block: "",
                      },
                      {
                        default: v(() => [
                          y(
                            n(
                              p.value
                                ? t.$t("buttons.phoneNumberLogin")
                                : t.$t("buttons.emailLogin")
                            ),
                            1
                          ),
                        ]),
                        _: 1,
                      }
                    ),
                  ]),
                ]),
                _: 1,
              }
            ),
            s("div", ye, [
              s("div", De, [
                s("div", Fe, n(t.$t("notHaveAccount")), 1),
                s(
                  "div",
                  { onClick: e[9] || (e[9] = (a) => N(!0)) },
                  n(t.$t("nowRegister")),
                  1
                ),
              ]),
              s("div", Ve, n(D(F)), 1),
            ]),
            l(
              S,
              {
                show: u.value,
                "onUpdate:show": e[11] || (e[11] = (a) => (u.value = a)),
                round: "",
                position: "bottom",
              },
              {
                default: v(() => [
                  l(
                    O,
                    {
                      columns: D(se),
                      onCancel: e[10] || (e[10] = (a) => (u.value = !1)),
                      onConfirm: P,
                      "columns-field-names": {
                        text: "phone_code",
                        value: "phone_code",
                        children: "children",
                      },
                    },
                    null,
                    8,
                    ["columns"]
                  ),
                ]),
                _: 1,
              },
              8,
              ["show"]
            ),
            l(
              Q,
              {
                show: h.value,
                "onUpdate:show": e[12] || (e[12] = (a) => (h.value = a)),
                actions: b.value,
                onSelect: k,
              },
              null,
              8,
              ["show", "actions"]
            ),
            l(
              ae,
              {
                show: w.value,
                onClose: e[13] || (e[13] = (a) => (w.value = !1)),
              },
              null,
              8,
              ["show"]
            ),
          ])
        );
      };
    },
  });
const qe = _(Pe, [["__scopeId", "data-v-ad761f85"]]);
export { qe as default };
