import { PromiseOut } from "../../helper/PromiseOut.js";
import { CacheGetter } from "../../helper/cacheGetter.js";
import { createSignal } from "../../helper/createSignal.js";
import { MicroModule } from "../micro-module.js";
import { IpcRequest } from "./IpcRequest.js";
import { IPC_MESSAGE_TYPE, } from "./const.js";
import { once } from "../../helper/helper.js";
import { mapHelper } from "../../helper/mapHelper.js";
import { createFetchHandler } from "../helper/ipcFetchHelper.js";
import { IpcEvent } from "./IpcEvent.js";
import { pureChannelToIpcEvent } from "./PureChannel.js";
export { FetchError, FetchEvent } from "../helper/ipcFetchHelper.js";
let ipc_uid_acc = 0;
export class Ipc {
    constructor() {
        Object.defineProperty(this, "uid", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: ipc_uid_acc++
        });
        Object.defineProperty(this, "_support_cbor", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: false
        });
        Object.defineProperty(this, "_support_protobuf", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: false
        });
        Object.defineProperty(this, "_support_raw", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: false
        });
        Object.defineProperty(this, "_support_binary", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: false
        });
        Object.defineProperty(this, "_closeSignal", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: createSignal(false)
        });
        Object.defineProperty(this, "onClose", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: this._closeSignal.listen
        });
        Object.defineProperty(this, "_messageSignal", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: this._createSignal(false)
        });
        Object.defineProperty(this, "onMessage", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: this._messageSignal.listen
        });
        /**
         * 强制触发消息传入，而不是依赖远端的 postMessage
         */
        Object.defineProperty(this, "emitMessage", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: (args) => this._messageSignal.emit(args, this)
        });
        Object.defineProperty(this, "__onRequestSignal", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: new CacheGetter(() => {
                const signal = this._createSignal(false);
                this.onMessage((request, ipc) => {
                    if (request.type === IPC_MESSAGE_TYPE.REQUEST) {
                        signal.emit(request, ipc);
                    }
                });
                return signal;
            })
        });
        Object.defineProperty(this, "__onStreamSignal", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: new CacheGetter(() => {
                const signal = this._createSignal(false);
                this.onMessage((request, ipc) => {
                    if ("stream_id" in request) {
                        signal.emit(request, ipc);
                    }
                });
                return signal;
            })
        });
        Object.defineProperty(this, "__onEventSignal", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: new CacheGetter(() => {
                const signal = this._createSignal(false);
                this.onMessage((event, ipc) => {
                    if (event.type === IPC_MESSAGE_TYPE.EVENT) {
                        signal.emit(event, ipc);
                    }
                });
                return signal;
            })
        });
        Object.defineProperty(this, "_closed", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: false
        });
        Object.defineProperty(this, "_req_id_acc", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 0
        });
        Object.defineProperty(this, "__reqresMap", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: new CacheGetter(() => {
                const reqresMap = new Map();
                this.onMessage((message) => {
                    if (message.type === IPC_MESSAGE_TYPE.RESPONSE) {
                        const response_po = reqresMap.get(message.req_id);
                        if (response_po) {
                            reqresMap.delete(message.req_id);
                            response_po.resolve(message);
                        }
                        else {
                            throw new Error(`no found response by req_id: ${message.req_id}`);
                        }
                    }
                });
                return reqresMap;
            })
        });
        Object.defineProperty(this, "readyListener", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: once(async () => {
                const ready = new PromiseOut();
                this.onEvent((event, ipc) => {
                    if (event.name === "ping") {
                        ipc.postMessage(new IpcEvent("pong", event.data, event.encoding));
                    }
                    else if (event.name === "pong") {
                        ready.resolve(event);
                    }
                });
                (async () => {
                    let timeDelay = 50;
                    while (!ready.is_resolved && !this.isClosed && timeDelay < 5000) {
                        this.postMessage(IpcEvent.fromText("ping", ""));
                        await PromiseOut.sleep(timeDelay).promise;
                        timeDelay *= 3;
                    }
                })();
                return await ready.promise;
            })
        });
    }
    /**
     * 是否支持使用 MessagePack 直接传输二进制
     * 在一些特殊的场景下支持字符串传输，比如与webview的通讯
     * 二进制传输在网络相关的服务里被支持，里效率会更高，但前提是对方有 MessagePack 的编解码能力
     * 否则 JSON 是通用的传输协议
     */
    get support_cbor() {
        return this._support_cbor;
    }
    /**
     * 是否支持使用 Protobuf 直接传输二进制
     * 在网络环境里，protobuf 是更加高效的协议
     */
    get support_protobuf() {
        return this._support_protobuf;
    }
    /**
     * 是否支持结构化内存协议传输：
     * 就是说不需要对数据手动序列化反序列化，可以直接传输内存对象
     */
    get support_raw() {
        return this._support_raw;
    }
    /**
     * 是否支持二进制传输
     */
    get support_binary() {
        return this._support_binary ?? (this.support_cbor || this.support_protobuf || this.support_raw);
    }
    asRemoteInstance() {
        if (this.remote instanceof MicroModule) {
            return this.remote;
        }
    }
    // deno-lint-ignore no-explicit-any
    _createSignal(autoStart) {
        const signal = createSignal(autoStart);
        this.onClose(() => signal.clear());
        return signal;
    }
    postMessage(message) {
        if (this._closed) {
            return;
        }
        this._doPostMessage(message);
    }
    get _onRequestSignal() {
        return this.__onRequestSignal.value;
    }
    onRequest(cb) {
        return this._onRequestSignal.listen(cb);
    }
    onFetch(...handlers) {
        const onRequest = createFetchHandler(handlers);
        return onRequest.extendsTo(this.onRequest(onRequest));
    }
    get _onStreamSignal() {
        return this.__onStreamSignal.value;
    }
    onStream(cb) {
        return this._onStreamSignal.listen(cb);
    }
    get _onEventSignal() {
        return this.__onEventSignal.value;
    }
    onEvent(cb) {
        return this._onEventSignal.listen(cb);
    }
    close() {
        if (this._closed) {
            return;
        }
        this._closed = true;
        this._doClose();
        this._closeSignal.emitAndClear();
    }
    get isClosed() {
        return this._closed;
    }
    allocReqId(_url) {
        return this._req_id_acc++;
    }
    get _reqresMap() {
        return this.__reqresMap.value;
    }
    _buildIpcRequest(url, init) {
        const req_id = this.allocReqId();
        const ipcRequest = IpcRequest.fromRequest(req_id, this, url, init);
        return ipcRequest;
    }
    request(input, init) {
        const ipcRequest = input instanceof IpcRequest ? input : this._buildIpcRequest(input, init);
        const result = this.registerReqId(ipcRequest.req_id);
        this.postMessage(ipcRequest);
        return result.promise;
    }
    /** 自定义注册 请求与响应 的id */
    registerReqId(req_id = this.allocReqId()) {
        return mapHelper.getOrPut(this._reqresMap, req_id, () => new PromiseOut());
    }
    /**
     * 代理管道 发送数据 与 接收数据
     * @param channel
     */
    async pipeToChannel(channelId, channel) {
        await pureChannelToIpcEvent(channelId, this, channel, channel.income.controller, channel.outgoing.stream, () => channel.afterStart());
    }
    /**
     * 代理管道 发送数据 与 接收数据
     * @param channel
     */
    async pipeFromChannel(channelId, channel) {
        await pureChannelToIpcEvent(channelId, this, channel, channel.outgoing.controller, channel.income.stream, () => channel.start());
    }
    ready() {
        return this.readyListener();
    }
}
