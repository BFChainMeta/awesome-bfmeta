import {
  d as U,
  B as e,
  D as u,
  R as L,
  T,
  F as t,
  G as I,
  a1 as _,
  a2 as b,
  Q as d,
  f as m,
  y as H,
  x as O,
  v as W,
  r as N,
  a as V,
  E as y,
  J as w,
  _ as X,
  S as Y,
  I as C,
  aK as Z,
  ao as ee,
  aT as se,
  M as te,
} from "./index-367d22e2.js";
import { T as oe, a as ae } from "./index-02886b08.js";
import "./index-9e32bade.js";
import { S as ne } from "./index-f45378d2.js";
import { a as re } from "./arrows_left-58dc349e.js";
import { b as le } from "./back-099fa84a.js";
import { _ as f } from "./GlobalSearchResult.vue_vue_type_script_setup_true_lang-4af2d211.js";
import { _ as S } from "./index.vue_vue_type_script_setup_true_lang-4539ec1d.js";
import { V as j } from "./virtual-list-12e0a9ef.js";
import { _ as $ } from "./index.vue_vue_type_script_setup_true_lang-b5597b8b.js";
import { u as ie } from "./useConversationToggle-d470852f.js";
import "./use-id-ce6fd248.js";
const M = "/assets/search_null-4e2550d3.png",
  ce = { class: "flex-1 overflow-y-auto" },
  de = { class: "bg-white mt-[10px] mx-[10px] rounded-md overflow-hidden" },
  ue = { class: "flex justify-between px-4 pt-2 text-xs" },
  me = { class: "text-sm text-sub-text" },
  pe = { class: "bg-white mt-[10px] mx-[10px] rounded-md overflow-hidden" },
  he = { class: "flex justify-between px-4 pt-2 text-xs" },
  ve = { class: "text-sm text-sub-text" },
  ge = { class: "bg-white mt-[10px] mx-[10px] rounded-md overflow-hidden" },
  fe = { class: "flex justify-between px-4 pt-2 text-xs" },
  xe = { class: "text-sm text-sub-text" },
  ye = {
    class: "bg-white mt-[10px] mx-[10px] rounded-md overflow-hidden mb-4",
  },
  _e = { class: "flex justify-between px-4 pt-2 text-xs" },
  be = { class: "text-sm text-sub-text" },
  we = U({
    __name: "ComprehensiveTab",
    props: { data: null },
    emits: ["toggleTab", "checkConversation"],
    setup(g, { emit: B }) {
      return (c, p) => (
        e(),
        u("div", ce, [
          L(
            t(
              "div",
              de,
              [
                t("div", ue, [
                  t("text", me, I(c.$t("contactMenu.contacts")), 1),
                ]),
                (e(!0),
                u(
                  _,
                  null,
                  b(
                    g.data.contacts.slice(0, 2),
                    (r) => (
                      e(),
                      d(f, { source: r, key: r.userID }, null, 8, ["source"])
                    )
                  ),
                  128
                )),
                m(
                  S,
                  {
                    class: "border-t text-primary pl-4",
                    arrow: "",
                    lable: c.$t("moreContacts"),
                    onClick: p[0] || (p[0] = (r) => c.$emit("toggleTab", 1)),
                  },
                  null,
                  8,
                  ["lable"]
                ),
              ],
              512
            ),
            [[T, g.data.contacts.length > 0]]
          ),
          L(
            t(
              "div",
              pe,
              [
                t("div", he, [t("text", ve, I(c.$t("group")), 1)]),
                (e(!0),
                u(
                  _,
                  null,
                  b(
                    g.data.groups.slice(0, 2),
                    (r) => (
                      e(),
                      d(f, { source: r, key: r.groupID }, null, 8, ["source"])
                    )
                  ),
                  128
                )),
                m(
                  S,
                  {
                    class: "border-t text-primary pl-4",
                    arrow: "",
                    lable: c.$t("moreGroup"),
                    onClick: p[1] || (p[1] = (r) => c.$emit("toggleTab", 2)),
                  },
                  null,
                  8,
                  ["lable"]
                ),
              ],
              512
            ),
            [[T, g.data.groups.length > 0]]
          ),
          L(
            t(
              "div",
              ge,
              [
                t("div", fe, [t("text", xe, I(c.$t("chatRecord")), 1)]),
                (e(!0),
                u(
                  _,
                  null,
                  b(
                    g.data.chatLogs.slice(0, 2),
                    (r) => (
                      e(),
                      d(
                        f,
                        {
                          source: r,
                          key: r.conversationID,
                          onClick: (x) => c.$emit("checkConversation", r),
                        },
                        null,
                        8,
                        ["source", "onClick"]
                      )
                    )
                  ),
                  128
                )),
                m(
                  S,
                  {
                    class: "border-t text-primary pl-4",
                    arrow: "",
                    lable: c.$t("moreChatRecord"),
                    onClick: p[2] || (p[2] = (r) => c.$emit("toggleTab", 3)),
                  },
                  null,
                  8,
                  ["lable"]
                ),
              ],
              512
            ),
            [[T, g.data.chatLogs.length > 0]]
          ),
          L(
            t(
              "div",
              ye,
              [
                t("div", _e, [t("text", be, I(c.$t("documentation")), 1)]),
                (e(!0),
                u(
                  _,
                  null,
                  b(
                    g.data.documents.slice(0, 2),
                    (r) => (
                      e(),
                      d(
                        f,
                        { source: r, key: r.clientMsgID, isFile: !0 },
                        null,
                        8,
                        ["source"]
                      )
                    )
                  ),
                  128
                )),
                m(
                  S,
                  {
                    class: "border-t text-primary pl-4",
                    arrow: "",
                    lable: c.$t("moreDocumnet"),
                    onClick: p[3] || (p[3] = (r) => c.$emit("toggleTab", 4)),
                  },
                  null,
                  8,
                  ["lable"]
                ),
              ],
              512
            ),
            [[T, g.data.documents.length > 0]]
          ),
        ])
      );
    },
  }),
  ke = { class: "page_container" },
  $e = { class: "flex items-center pl-4 border-b !bg-white" },
  Ie = ["src"],
  De = { class: "flex-1 overflow-y-auto" },
  Le = { key: 0, class: "m-[10px] rounded-md overflow-hidden" },
  Te = { class: "flex-1 overflow-y-auto" },
  Ce = { key: 0, class: "m-[10px] rounded-md overflow-hidden" },
  Se = { class: "flex-1 overflow-y-auto" },
  Me = { key: 0, class: "m-[10px] rounded-md overflow-hidden" },
  Re = { key: 1, class: "flex-1 flex flex-col overflow-hidden" },
  Ne = { class: "flex-1 ml-2 overflow-hidden" },
  Ue = { class: "flex items-baseline" },
  Be = { class: "max-w-[200px] truncate" },
  Fe = ["src"],
  Ge = U({ name: "globalSearch" }),
  ze = U({
    ...Ge,
    setup(g) {
      const { toSpecifiedConversation: B } = ie(),
        c = H(),
        p = O(),
        { t: r } = W(),
        x = N(),
        R = N(0),
        a = V({ contacts: [], groups: [], chatLogs: [], documents: [] }),
        l = N(),
        h = V({ pageIndex: 1, hasMore: !0, loading: !1 }),
        E = () => {
          var o, v, n;
          let s;
          ((o = l.value) == null ? void 0 : o.conversationType) === Y.Single
            ? (s =
                l.value.messageList[0].recvID === p.selfInfo.userID
                  ? l.value.messageList[0].sendID
                  : l.value.messageList[0].recvID)
            : (s = (v = l.value) == null ? void 0 : v.groupID),
            B({
              sourceID: s,
              sessionType: (n = l.value) == null ? void 0 : n.conversationType,
            });
        },
        P = () => {
          if (l.value) {
            l.value = void 0;
            return;
          }
          c.push("/conversation");
        },
        K = () => {
          x.value && ((h.pageIndex = 1), (h.hasMore = !0), Q(), q(), A(), F());
        },
        J = () => {
          h.hasMore && !h.loading && F();
        },
        Q = () => {
          const s = {
            keywordList: [x.value],
            isSearchUserID: !0,
            isSearchNickname: !0,
            isSearchRemark: !0,
          };
          C.searchFriends(s).then(({ data: o }) => {
            a.contacts = o;
          });
        },
        q = () => {
          const s = {
            keywordList: [x.value],
            isSearchGroupID: !0,
            isSearchGroupName: !0,
          };
          C.searchGroups(s).then(({ data: o }) => {
            a.groups = o;
          });
        },
        A = () => {
          const s = {
            conversationID: "",
            keywordList: [x.value],
            keywordListMatchType: 0,
            senderUserIDList: [],
            messageTypeList: [],
            searchTimePosition: 0,
            searchTimePeriod: 0,
            pageIndex: 0,
            count: 0,
          };
          C.searchLocalMessages(s).then(({ data: o }) => {
            const v = o.searchResultItems ?? [];
            v.map((n) => {
              (n.groupID = n.messageList[0].groupID),
                (n.sendTime = n.messageList[0].sendTime),
                (n.latestMsg =
                  n.messageCount > 1
                    ? r("someChatRecord", { count: n.messageCount })
                    : Z(n.messageList[0]));
            }),
              (a.chatLogs = [...v]);
          });
        },
        F = () => {
          h.loading = !0;
          const s = {
            conversationID: "",
            keywordList: [x.value],
            keywordListMatchType: 0,
            senderUserIDList: [],
            messageTypeList: [ee.FileMessage],
            searchTimePosition: 0,
            searchTimePeriod: 0,
            pageIndex: h.pageIndex,
            count: 20,
          };
          C.searchLocalMessages(s)
            .then(({ data: o }) => {
              const v = o.searchResultItems
                  ? o.searchResultItems
                      .map((D) =>
                        D.messageList.map((k) => ({
                          ...k,
                          showName: D.showName,
                          faceURL: se(k.fileElem.fileName),
                        }))
                      )
                      .flat()
                  : [],
                n = h.pageIndex === 1 ? [] : a.documents;
              (a.documents = [...n, ...v]),
                (h.hasMore = v.length === 20),
                (h.pageIndex += 1),
                console.error(a.documents);
            })
            .finally(() => (h.loading = !1));
        };
      return (s, o) => {
        var k, G, z;
        const v = ne,
          n = oe,
          D = ae;
        return (
          e(),
          u("div", ke, [
            t("div", $e, [
              t(
                "img",
                { class: "h-[24px] w-[24px]", src: y(re), alt: "", onClick: P },
                null,
                8,
                Ie
              ),
              m(
                v,
                {
                  class: "w-full",
                  modelValue: x.value,
                  "onUpdate:modelValue": o[0] || (o[0] = (i) => (x.value = i)),
                  placeholder: s.$t("placeholder.search"),
                  onSearch: K,
                },
                null,
                8,
                ["modelValue", "placeholder"]
              ),
            ]),
            l.value
              ? (e(),
                u("div", Re, [
                  t(
                    "div",
                    {
                      class:
                        "flex items-center px-4 py-[10px] m-[10px] mb-0 bg-white rounded-md",
                      onClick: E,
                    },
                    [
                      m(
                        X,
                        {
                          src: l.value.faceURL,
                          desc: l.value.showName,
                          isGroup: l.value.groupID !== void 0,
                          size: 42,
                        },
                        null,
                        8,
                        ["src", "desc", "isGroup"]
                      ),
                      t("div", Ne, [
                        t("div", Ue, [t("div", Be, I(l.value.showName), 1)]),
                      ]),
                      t(
                        "img",
                        { class: "w-[24px] h-[24px]", src: y(le), alt: "" },
                        null,
                        8,
                        Fe
                      ),
                    ]
                  ),
                  m(
                    y(j),
                    {
                      class:
                        "my_scrollbar flex-1 overflow-y-auto m-[10px] rounded-md",
                      "data-key": "clientMsgID",
                      "data-sources":
                        (k = l.value) == null ? void 0 : k.messageList,
                      "data-component": f,
                      "estimate-size": 88,
                      "extra-props": {
                        preview: !0,
                        conversationID:
                          (G = l.value) == null ? void 0 : G.conversationID,
                        conversationName:
                          (z = l.value) == null ? void 0 : z.showName,
                      },
                    },
                    null,
                    8,
                    ["data-sources", "extra-props"]
                  ),
                ]))
              : (e(),
                d(
                  D,
                  {
                    key: 0,
                    "title-active-color": "#1B72EC",
                    active: R.value,
                    "onUpdate:active": o[3] || (o[3] = (i) => (R.value = i)),
                  },
                  {
                    default: w(() => [
                      m(
                        n,
                        { title: s.$t("comprehensive") },
                        {
                          default: w(() => [
                            [
                              ...a.chatLogs,
                              ...a.contacts,
                              ...a.documents,
                              ...a.groups,
                            ].length > 0
                              ? (e(),
                                d(
                                  we,
                                  {
                                    key: 0,
                                    data: a,
                                    onToggleTab:
                                      o[1] || (o[1] = (i) => (R.value = i)),
                                    onCheckConversation:
                                      o[2] || (o[2] = (i) => (l.value = i)),
                                  },
                                  null,
                                  8,
                                  ["data"]
                                ))
                              : (e(),
                                d(
                                  $,
                                  {
                                    key: 1,
                                    description: s.$t("emptySearchDesc"),
                                    image: y(M),
                                    size: 163,
                                  },
                                  null,
                                  8,
                                  ["description", "image"]
                                )),
                          ]),
                          _: 1,
                        },
                        8,
                        ["title"]
                      ),
                      m(
                        n,
                        { title: s.$t("contactMenu.contacts") },
                        {
                          default: w(() => [
                            t("div", De, [
                              a.contacts.length > 0
                                ? (e(),
                                  u("div", Le, [
                                    (e(!0),
                                    u(
                                      _,
                                      null,
                                      b(
                                        a.contacts,
                                        (i) => (
                                          e(),
                                          d(
                                            f,
                                            { source: i, key: i.userID },
                                            null,
                                            8,
                                            ["source"]
                                          )
                                        )
                                      ),
                                      128
                                    )),
                                  ]))
                                : (e(),
                                  d(
                                    $,
                                    {
                                      key: 1,
                                      description: s.$t("emptySearchDesc"),
                                      image: y(M),
                                      size: 163,
                                    },
                                    null,
                                    8,
                                    ["description", "image"]
                                  )),
                            ]),
                          ]),
                          _: 1,
                        },
                        8,
                        ["title"]
                      ),
                      m(
                        n,
                        { title: s.$t("group") },
                        {
                          default: w(() => [
                            t("div", Te, [
                              a.groups.length > 0
                                ? (e(),
                                  u("div", Ce, [
                                    (e(!0),
                                    u(
                                      _,
                                      null,
                                      b(
                                        a.groups,
                                        (i) => (
                                          e(),
                                          d(
                                            f,
                                            { source: i, key: i.groupID },
                                            null,
                                            8,
                                            ["source"]
                                          )
                                        )
                                      ),
                                      128
                                    )),
                                  ]))
                                : (e(),
                                  d(
                                    $,
                                    {
                                      key: 1,
                                      description: s.$t("emptySearchDesc"),
                                      image: y(M),
                                      size: 163,
                                    },
                                    null,
                                    8,
                                    ["description", "image"]
                                  )),
                            ]),
                          ]),
                          _: 1,
                        },
                        8,
                        ["title"]
                      ),
                      m(
                        n,
                        { title: s.$t("chatRecord") },
                        {
                          default: w(() => [
                            t("div", Se, [
                              a.chatLogs.length > 0
                                ? (e(),
                                  u("div", Me, [
                                    (e(!0),
                                    u(
                                      _,
                                      null,
                                      b(
                                        a.chatLogs,
                                        (i) => (
                                          e(),
                                          d(
                                            f,
                                            {
                                              source: i,
                                              key: i.conversationID,
                                              onClick: (Ve) => (l.value = i),
                                            },
                                            null,
                                            8,
                                            ["source", "onClick"]
                                          )
                                        )
                                      ),
                                      128
                                    )),
                                  ]))
                                : (e(),
                                  d(
                                    $,
                                    {
                                      key: 1,
                                      description: s.$t("emptySearchDesc"),
                                      image: y(M),
                                      size: 163,
                                    },
                                    null,
                                    8,
                                    ["description", "image"]
                                  )),
                            ]),
                          ]),
                          _: 1,
                        },
                        8,
                        ["title"]
                      ),
                      m(
                        n,
                        { title: s.$t("documentation") },
                        {
                          default: w(() => [
                            a.documents.length > 0
                              ? (e(),
                                d(
                                  y(j),
                                  {
                                    key: 0,
                                    class:
                                      "my_scrollbar h-full m-[10px] rounded-md overflow-hidden",
                                    "data-key": "clientMsgID",
                                    "data-sources": a.documents,
                                    "data-component": f,
                                    "estimate-size": 88,
                                    onTobottom: J,
                                    "extra-props": { isFile: !0 },
                                  },
                                  null,
                                  8,
                                  ["data-sources"]
                                ))
                              : (e(), d($, { key: 1 })),
                          ]),
                          _: 1,
                        },
                        8,
                        ["title"]
                      ),
                    ]),
                    _: 1,
                  },
                  8,
                  ["active"]
                )),
          ])
        );
      };
    },
  });
const Ye = te(ze, [["__scopeId", "data-v-b655a725"]]);
export { Ye as default };
