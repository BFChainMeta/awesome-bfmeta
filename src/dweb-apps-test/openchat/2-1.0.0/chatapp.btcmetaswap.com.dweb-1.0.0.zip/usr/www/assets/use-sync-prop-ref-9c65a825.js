import{r as c,w as o}from"./index-367d22e2.js";const n=(s,a)=>{const f=c(s());return o(s,r=>{r!==f.value&&(f.value=r)}),o(f,r=>{r!==s()&&a(r)}),f};export{n as u};
