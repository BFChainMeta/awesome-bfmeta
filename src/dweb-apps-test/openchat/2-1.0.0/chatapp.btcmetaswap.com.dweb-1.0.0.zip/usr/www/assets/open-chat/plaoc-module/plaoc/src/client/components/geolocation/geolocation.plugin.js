import { __decorate, __metadata } from "../../../../../../tslib/modules/index.js";
import { bindThis } from "../../helper/bindThis.js";
import { BasePlugin } from "../base/BasePlugin.js";
export class GeolocationPlugin extends BasePlugin {
    constructor() {
        super("geolocation.sys.dweb");
    }
    getLocation() {
        return this.fetchApi(`/location`).object();
    }
}
__decorate([
    bindThis,
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", void 0)
], GeolocationPlugin.prototype, "getLocation", null);
export const geolocationPlugin = new GeolocationPlugin();
