export * from "./splash-screen.plugin.js";
export * from "./splash-screen.type.js";
export * from "./splash-screen.wc.js";
