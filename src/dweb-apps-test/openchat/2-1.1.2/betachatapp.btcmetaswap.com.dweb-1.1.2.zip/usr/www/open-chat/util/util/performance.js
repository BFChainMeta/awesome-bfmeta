import Perf from "./performance@browser.js";
export default Perf;
