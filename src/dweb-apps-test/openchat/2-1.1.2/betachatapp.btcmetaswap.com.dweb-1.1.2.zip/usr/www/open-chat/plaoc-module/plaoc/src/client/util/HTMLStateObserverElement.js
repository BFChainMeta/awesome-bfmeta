var _HTMLStateObserverElement_onStateChange;
import { __classPrivateFieldGet, __classPrivateFieldSet } from "../../../../../tslib/modules/index.js";
export class HTMLStateObserverElement extends HTMLElement {
    constructor(state) {
        super();
        Object.defineProperty(this, "state", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: state
        });
        _HTMLStateObserverElement_onStateChange.set(this, void 0);
        (async () => {
            for await (const _info of state.jsonlines()) {
                // console.log("stateChange", _info);
            }
        })();
    }
    async connectedCallback() {
        __classPrivateFieldSet(this, _HTMLStateObserverElement_onStateChange, this.state.onChange((info) => {
            this.dispatchEvent(new CustomEvent("statechange", { detail: info }));
        }), "f");
        await this.state.getState(true); // 强制刷新
    }
    async disconnectedCallback() {
        if (__classPrivateFieldGet(this, _HTMLStateObserverElement_onStateChange, "f")) {
            __classPrivateFieldGet(this, _HTMLStateObserverElement_onStateChange, "f").call(this);
            __classPrivateFieldSet(this, _HTMLStateObserverElement_onStateChange, undefined, "f");
        }
        await this.state.stopObserve();
    }
}
_HTMLStateObserverElement_onStateChange = new WeakMap();
export class HTMLIteratorObserverElement extends HTMLElement {
    constructor(state) {
        super();
        Object.defineProperty(this, "state", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: state
        });
        (async () => {
            for await (const info of state) {
                // console.log("stateChange", _info);
                this.dispatchEvent(new CustomEvent("statechange", { detail: info }));
            }
        })();
    }
}
