import { BAR_STYLE as NAVIGATION_BAR_STYLE } from "../base/BarPlugin.js";
export { NAVIGATION_BAR_STYLE };
