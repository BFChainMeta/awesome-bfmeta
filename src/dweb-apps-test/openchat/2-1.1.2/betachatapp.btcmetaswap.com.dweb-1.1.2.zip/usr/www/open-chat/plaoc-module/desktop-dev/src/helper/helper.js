import { simpleEncoder } from "./encoding.js";
// deno-lint-ignore no-explicit-any
export function once(func) {
    let result;
    let called = false;
    return function (...args) {
        if (!called) {
            result = func(...args);
            called = true;
        }
        return result;
    };
}
/**
 * 查找子数组对象
 * @param arr
 * @param subArr
 * @returns
 */
export function injectSubArray(arr, subList) {
    const arrList = Array.from(arr);
    for (let i = 0; i <= arrList.length - subList.length; i++) {
        if (arrList.slice(i, i + subList.length).toString() === subList.toString()) {
            // 找到目标子数组，使用splice方法插入新数组
            const insertList = simpleEncoder(`\n    <meta is="dweb-config"/>`, "utf8");
            arr.set(insertList, i + subList.length);
            return arr;
        }
    }
    return arr;
}
