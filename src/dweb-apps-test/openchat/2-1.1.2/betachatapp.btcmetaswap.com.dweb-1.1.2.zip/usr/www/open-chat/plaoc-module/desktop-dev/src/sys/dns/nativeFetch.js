import { AdaptersManager } from "../../helper/AdaptersManager.js";
export const nativeFetchAdaptersManager = new AdaptersManager();
