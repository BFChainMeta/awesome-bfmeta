import { sleep, unsleep } from "../../extends-promise/index.js";
import { isPromiseLike } from "../../extends-promise-is/index.js";
const durationToPromise = (duration, value) => {
    if (typeof duration === "number") {
        return sleep(duration);
    }
    const d = duration(value);
    if (typeof d === "number") {
        return sleep(d);
    }
    if (isPromiseLike(d)) {
        return d;
    }
    return Promise.resolve(d);
};
export const time = (config = {}) => {
    const { duration: throttleDuration, leading = true, trailing = false, } = config.throttle ?? { duration: 0, leading: false, trailing: false };
    const { duration: debounceDuration, onDebunce } = config.debounce ?? { duration: 0 };
    let leadingEndTime;
    let trailingStartTime;
    let debounceTimmer;
    let latestEnqueueIndex = -1;
    const enqueue = (controller, chunk, index) => {
        if (index <= latestEnqueueIndex) {
            return;
        }
        latestEnqueueIndex = index;
        controller.enqueue(chunk);
    };
    let chunkIndex = -1;
    return new TransformStream({
        transform(chunk, controller) {
            const index = chunkIndex++;
            if (leading) {
                if (leadingEndTime === undefined) {
                    enqueue(controller, chunk, index);
                    leadingEndTime = durationToPromise(throttleDuration, chunk).then(() => (leadingEndTime = undefined), controller.error);
                    return;
                }
            }
            if (trailing) {
                if (trailingStartTime === undefined) {
                    const tst = (trailingStartTime = {
                        po: durationToPromise(throttleDuration, chunk).then(() => {
                            enqueue(controller, tst.va, tst.i);
                            trailingStartTime = undefined;
                        }, controller.error),
                        va: chunk,
                        i: index,
                    });
                }
                else {
                    trailingStartTime.va = chunk;
                    trailingStartTime.i = index;
                }
            }
            if (debounceDuration > 0) {
                if (debounceTimmer !== undefined) {
                    unsleep(debounceTimmer);
                    onDebunce?.(debounceTimmer);
                }
                debounceTimmer = durationToPromise(debounceDuration, chunk).then(() => {
                    enqueue(controller, chunk, index);
                }, controller.error);
            }
        },
    });
};
