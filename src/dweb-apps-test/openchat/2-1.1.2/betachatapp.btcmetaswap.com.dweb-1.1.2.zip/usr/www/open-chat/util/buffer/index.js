export * from "./$types.js";
import { Buffer } from "buffer";
export class BBuffer extends Buffer {
    static from(arg1, arg2, arg3) {
        return Buffer.from(arg1, arg2, arg3);
    }
    static alloc(arg1, arg2, arg3) {
        return Buffer.alloc(arg1, arg2, arg3);
    }
    static allocUnsafe(size) {
        return Buffer.allocUnsafe(size);
    }
    static allocUnsafeSlow(size) {
        return Buffer.allocUnsafeSlow(size);
    }
}
// const b =  Buffer.from('1');
// b.update
