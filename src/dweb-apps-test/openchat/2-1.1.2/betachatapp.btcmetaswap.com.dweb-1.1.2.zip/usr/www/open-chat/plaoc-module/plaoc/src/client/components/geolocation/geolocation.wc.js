import { geolocationPlugin } from "./geolocation.plugin.js";
class HTMLGeolocationElement extends HTMLElement {
    constructor() {
        super(...arguments);
        Object.defineProperty(this, "plugin", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: geolocationPlugin
        });
    }
    getLocation() {
        return this.plugin.getLocation();
    }
}
Object.defineProperty(HTMLGeolocationElement, "tagName", {
    enumerable: true,
    configurable: true,
    writable: true,
    value: "dweb-geolocation"
});
export { HTMLGeolocationElement };
if (!customElements.get(HTMLGeolocationElement.tagName)) {
    customElements.define(HTMLGeolocationElement.tagName, HTMLGeolocationElement);
}
