import{p}from"./sha256-D8gXK8xS.js";const a=async()=>{await p.prepare()};export{a as p};
