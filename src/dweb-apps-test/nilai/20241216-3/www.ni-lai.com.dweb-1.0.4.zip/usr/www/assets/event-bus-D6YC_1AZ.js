import{Z as o}from"./index-BThTOnf_.js";const s=o(),n=o();export{s as a,n as o};
