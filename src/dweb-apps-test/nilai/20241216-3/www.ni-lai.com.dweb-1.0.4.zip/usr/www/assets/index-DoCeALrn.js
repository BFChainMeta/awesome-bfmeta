import{ah as a}from"./messages-D_hAcQBr.js";import{ae as n}from"./index-BThTOnf_.js";const o=r=>(r=r.toUpperCase(),a[r]?a[r]():r),e=()=>n()==="zh-hans"||n()==="zh-hant";export{e as h,o as i};
