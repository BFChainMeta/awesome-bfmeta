import{b1 as e}from"./index-BRTM05WP.js";const r=e();export{r as o};
