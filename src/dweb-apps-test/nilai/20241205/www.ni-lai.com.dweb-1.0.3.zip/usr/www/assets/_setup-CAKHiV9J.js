import{p}from"./sha256-D93Y98PT.js";const a=async()=>{await p.prepare()};export{a as p};
