import{ah as a}from"./messages-BSsY1h3_.js";import{al as n}from"./index-BJlHI0I4.js";const o=r=>(r=r.toUpperCase(),a[r]?a[r]():r),e=()=>n()==="zh-hans"||n()==="zh-hant";export{e as h,o as i};
