import{a4 as o}from"./index-BJlHI0I4.js";const s=o(),a=o();export{s as a,a as o};
