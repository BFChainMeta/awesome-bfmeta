import{an as a}from"./index-BJlHI0I4.js";const i=async t=>{await a.write({string:t})},e=async t=>{await i(t)};export{e as w};
