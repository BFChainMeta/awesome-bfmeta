import{aA as a}from"./messages-BDf2yblJ.js";import{ag as n}from"./index-CbMw4ga5.js";const h=r=>(r=r.toUpperCase(),a[r]?a[r]():r),e=()=>n()==="zh-hans"||n()==="zh-hant";export{e as h,h as i};
