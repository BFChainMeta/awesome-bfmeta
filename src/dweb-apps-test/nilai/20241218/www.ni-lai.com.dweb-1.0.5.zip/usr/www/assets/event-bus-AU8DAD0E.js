import{X as o}from"./index-CbMw4ga5.js";const s=o(),n=o();export{s as a,n as o};
