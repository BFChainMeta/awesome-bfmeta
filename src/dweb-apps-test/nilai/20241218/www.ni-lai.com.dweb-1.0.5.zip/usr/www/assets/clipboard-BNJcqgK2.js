import{e as i}from"./core-DKQmdIuN.js";import"./index-CbMw4ga5.js";const a=async t=>{await i.write({string:t})},o=async t=>{await a(t)};export{o as w};
