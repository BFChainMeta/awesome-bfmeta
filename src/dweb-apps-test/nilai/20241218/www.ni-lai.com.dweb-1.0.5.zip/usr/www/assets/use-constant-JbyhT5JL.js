import{ad as v,r}from"./index-CbMw4ga5.js";var f={exports:{}},s={};/**
 * @license React
 * react-jsx-runtime.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var _;function E(){if(_)return s;_=1;var n=v(),o=Symbol.for("react.element"),m=Symbol.for("react.fragment"),d=Object.prototype.hasOwnProperty,R=n.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner,y={key:!0,ref:!0,__self:!0,__source:!0};function c(u,e,p){var t,i={},a=null,x=null;p!==void 0&&(a=""+p),e.key!==void 0&&(a=""+e.key),e.ref!==void 0&&(x=e.ref);for(t in e)d.call(e,t)&&!y.hasOwnProperty(t)&&(i[t]=e[t]);if(u&&u.defaultProps)for(t in e=u.defaultProps,e)i[t]===void 0&&(i[t]=e[t]);return{$$typeof:o,type:u,key:a,ref:x,props:i,_owner:R.current}}return s.Fragment=m,s.jsx=c,s.jsxs=c,s}var l;function C(){return l||(l=1,f.exports=E()),f.exports}var w=C();const L=r.createContext(null),h=r.createContext({}),j=r.createContext({transformPagePoint:n=>n,isStatic:!1,reducedMotion:"never"}),O=typeof window<"u",q=O?r.useLayoutEffect:r.useEffect;function S(n){const o=r.useRef(null);return o.current===null&&(o.current=n()),o.current}export{h as L,j as M,L as P,q as a,O as i,w as j,S as u};
