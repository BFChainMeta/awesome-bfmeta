import{p}from"./sha256-7X5j33xV.js";const a=async()=>{await p.prepare()};export{a as p};
