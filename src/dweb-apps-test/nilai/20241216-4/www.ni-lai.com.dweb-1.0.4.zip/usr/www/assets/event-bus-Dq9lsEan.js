import{Z as o}from"./index-OGauJOWk.js";const s=o(),n=o();export{s as a,n as o};
