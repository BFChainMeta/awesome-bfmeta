import{e as i}from"./core-B0Oib4Kp.js";import"./index-OGauJOWk.js";const a=async t=>{await i.write({string:t})},o=async t=>{await a(t)};export{o as w};
