import{ah as a}from"./messages-ChF_Pekm.js";import{ae as n}from"./index-OGauJOWk.js";const o=r=>(r=r.toUpperCase(),a[r]?a[r]():r),e=()=>n()==="zh-hans"||n()==="zh-hant";export{e as h,o as i};
