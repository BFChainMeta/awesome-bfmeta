import{ax as a}from"./messages-Cia_IP3l.js";import{ag as n}from"./index-D_65q0CG.js";const h=r=>(r=r.toUpperCase(),a[r]?a[r]():r),e=()=>n()==="zh-hans"||n()==="zh-hant";export{e as h,h as i};
