import{e as i}from"./core-CL5_LiWM.js";import"./index-D_65q0CG.js";const a=async t=>{await i.write({string:t})},o=async t=>{await a(t)};export{o as w};
