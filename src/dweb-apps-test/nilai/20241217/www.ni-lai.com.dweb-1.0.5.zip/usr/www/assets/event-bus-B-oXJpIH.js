import{Z as o}from"./index-D_65q0CG.js";const s=o(),n=o();export{s as a,n as o};
