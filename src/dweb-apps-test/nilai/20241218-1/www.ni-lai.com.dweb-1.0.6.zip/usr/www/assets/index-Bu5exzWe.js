import{aA as a}from"./messages-Cn7zg9nW.js";import{ag as n}from"./index-gAvI2s0f.js";const h=r=>(r=r.toUpperCase(),a[r]?a[r]():r),e=()=>n()==="zh-hans"||n()==="zh-hant";export{e as h,h as i};
