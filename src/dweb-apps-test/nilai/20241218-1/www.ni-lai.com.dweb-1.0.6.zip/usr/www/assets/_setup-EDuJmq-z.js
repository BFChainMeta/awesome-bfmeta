import{p}from"./sha256-tuvDC9Jp.js";const a=async()=>{await p.prepare()};export{a as p};
