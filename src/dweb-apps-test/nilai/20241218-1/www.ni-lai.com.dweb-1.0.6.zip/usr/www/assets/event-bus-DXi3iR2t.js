import{X as o}from"./index-gAvI2s0f.js";const s=o(),n=o();export{s as a,n as o};
