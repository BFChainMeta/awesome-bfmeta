import{p}from"./sha256-DdTP392k.js";const a=async()=>{await p.prepare()};export{a as p};
