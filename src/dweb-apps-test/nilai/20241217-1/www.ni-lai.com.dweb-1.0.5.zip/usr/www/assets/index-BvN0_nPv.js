import{ay as a}from"./messages-BYCF3b-8.js";import{ag as n}from"./index-BIHPLpU1.js";const h=r=>(r=r.toUpperCase(),a[r]?a[r]():r),e=()=>n()==="zh-hans"||n()==="zh-hant";export{e as h,h as i};
