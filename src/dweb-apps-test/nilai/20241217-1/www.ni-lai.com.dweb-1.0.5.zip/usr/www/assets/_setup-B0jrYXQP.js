import{p}from"./sha256-K7HryHtc.js";const a=async()=>{await p.prepare()};export{a as p};
