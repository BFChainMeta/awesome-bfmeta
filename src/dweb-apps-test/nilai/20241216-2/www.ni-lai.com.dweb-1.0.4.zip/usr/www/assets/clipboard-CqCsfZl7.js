import{e as i}from"./core-cGzHVcRM.js";import"./index-DOUXvMZQ.js";const a=async t=>{await i.write({string:t})},o=async t=>{await a(t)};export{o as w};
