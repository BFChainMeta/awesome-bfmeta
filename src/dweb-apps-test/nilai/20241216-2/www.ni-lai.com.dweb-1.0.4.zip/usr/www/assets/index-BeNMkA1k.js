import{ah as a}from"./messages-vbrNYiq5.js";import{ae as n}from"./index-DOUXvMZQ.js";const o=r=>(r=r.toUpperCase(),a[r]?a[r]():r),e=()=>n()==="zh-hans"||n()==="zh-hant";export{e as h,o as i};
