import{ah as a}from"./messages-Cj0oR78G.js";import{al as n}from"./index-B42i71xW.js";const o=r=>(r=r.toUpperCase(),a[r]?a[r]():r),e=()=>n()==="zh-hans"||n()==="zh-hant";export{e as h,o as i};
