import{a4 as o}from"./index-B42i71xW.js";const s=o(),a=o();export{s as a,a as o};
