import{Z as o}from"./index-CND38HbY.js";const s=o(),n=o();export{s as a,n as o};
