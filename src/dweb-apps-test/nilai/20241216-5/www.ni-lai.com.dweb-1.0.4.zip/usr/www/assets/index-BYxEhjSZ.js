import{ah as a}from"./messages-Cy5MZHAE.js";import{ae as n}from"./index-CND38HbY.js";const o=r=>(r=r.toUpperCase(),a[r]?a[r]():r),e=()=>n()==="zh-hans"||n()==="zh-hant";export{e as h,o as i};
