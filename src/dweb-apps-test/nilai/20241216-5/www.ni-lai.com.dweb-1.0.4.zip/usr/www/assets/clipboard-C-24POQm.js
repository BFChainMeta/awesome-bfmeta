import{e as i}from"./core-ROk4i8Hl.js";import"./index-CND38HbY.js";const a=async t=>{await i.write({string:t})},o=async t=>{await a(t)};export{o as w};
