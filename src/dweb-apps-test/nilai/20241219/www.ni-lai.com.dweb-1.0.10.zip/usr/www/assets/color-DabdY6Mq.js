const p="#F7C80C";export{p};
