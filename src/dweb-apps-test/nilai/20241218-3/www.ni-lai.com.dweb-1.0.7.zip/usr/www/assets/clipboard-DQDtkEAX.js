import{e as i}from"./core-D4rmlUjv.js";import"./index-DGXSE6Zw.js";const a=async t=>{await i.write({string:t})},o=async t=>{await a(t)};export{o as w};
