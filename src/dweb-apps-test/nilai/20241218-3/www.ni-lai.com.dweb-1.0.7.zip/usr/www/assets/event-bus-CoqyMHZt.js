import{X as o}from"./index-DGXSE6Zw.js";const s=o(),n=o();export{s as a,n as o};
