import{p}from"./sha256-ijqzDS14.js";const a=async()=>{await p.prepare()};export{a as p};
