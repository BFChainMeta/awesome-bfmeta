import{X as o}from"./index-CJE5QwxM.js";const s=o(),n=o();export{s as a,n as o};
