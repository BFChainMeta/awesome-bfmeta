import{aA as a}from"./messages-URdPazFO.js";import{ag as n}from"./index-CJE5QwxM.js";const h=r=>(r=r.toUpperCase(),a[r]?a[r]():r),e=()=>n()==="zh-hans"||n()==="zh-hant";export{e as h,h as i};
