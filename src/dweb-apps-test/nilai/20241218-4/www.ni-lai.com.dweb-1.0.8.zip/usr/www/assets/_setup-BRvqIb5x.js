import{p}from"./sha256-DB61Ki_n.js";const a=async()=>{await p.prepare()};export{a as p};
