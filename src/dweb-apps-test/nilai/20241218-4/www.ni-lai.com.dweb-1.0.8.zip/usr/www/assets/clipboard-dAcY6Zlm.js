import{e as i}from"./core-Ch8I2HrT.js";import"./index-CJE5QwxM.js";const a=async t=>{await i.write({string:t})},o=async t=>{await a(t)};export{o as w};
