const s="/assets/success-_sYIPFmR.png";export{s as _};
