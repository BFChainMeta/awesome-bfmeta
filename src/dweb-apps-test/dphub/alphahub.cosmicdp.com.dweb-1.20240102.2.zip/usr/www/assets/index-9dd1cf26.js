import{l as c,o as e,c as n}from"./index-e05f4011.js";const o={},s={class:"min-h-full bg-black-10"};function t(a,r){return e(),n("div",s,"launchpad")}const _=c(o,[["render",t]]);export{_ as default};
