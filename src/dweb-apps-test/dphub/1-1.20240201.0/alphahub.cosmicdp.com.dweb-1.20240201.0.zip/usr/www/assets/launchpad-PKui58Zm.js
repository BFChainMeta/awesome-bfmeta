import{_ as c,c as e,o as a}from"./index-kAKWYTRf.js";const n={},o={class:"min-h-full bg-black-10"};function s(t,r){return a(),e("div",o,"launchpad")}const l=c(n,[["render",s]]);export{l as default};
