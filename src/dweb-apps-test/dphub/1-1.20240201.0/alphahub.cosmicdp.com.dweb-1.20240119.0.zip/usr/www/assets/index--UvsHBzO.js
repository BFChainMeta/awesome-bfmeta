import{j as e,o as c,c as t}from"./index-Bv4nMoqE.js";const n={},o={class:"min-h-full bg-black-10"};function s(r,a){return c(),t("div",o," trade ")}const l=e(n,[["render",s]]);export{l as default};
