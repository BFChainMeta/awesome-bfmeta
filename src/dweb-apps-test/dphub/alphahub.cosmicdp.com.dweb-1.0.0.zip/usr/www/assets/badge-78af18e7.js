const s="/assets/search-e285891b.svg",a="/assets/badge-408272fe.svg";export{s as _,a};
