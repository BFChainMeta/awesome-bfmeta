import{e,o as c,c as n}from"./index-bb2a3ec4.js";const o={};function r(t,s){return c(),n("div",null,"404")}const _=e(o,[["render",r]]);export{_ as default};
