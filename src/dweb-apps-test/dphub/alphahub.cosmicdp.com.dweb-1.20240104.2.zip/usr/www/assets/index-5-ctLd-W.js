import{l as e,o as c,c as n}from"./index-Fco5kT4W.js";const o={};function r(t,s){return c(),n("div",null,"404")}const _=e(o,[["render",r]]);export{_ as default};
