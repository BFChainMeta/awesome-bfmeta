const p="/assets/dp-WUpoY-nP.png";export{p as d};
