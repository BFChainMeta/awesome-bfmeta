import{j as e,o as c,c as t}from"./index-5W2Yssn5.js";const n={},o={class:"min-h-full bg-black-10"};function s(r,a){return c(),t("div",o," trade ")}const l=e(n,[["render",s]]);export{l as default};
