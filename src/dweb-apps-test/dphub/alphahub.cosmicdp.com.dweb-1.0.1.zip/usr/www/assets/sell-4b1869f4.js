const s="/assets/sell-27b667a7.svg";export{s as _};
