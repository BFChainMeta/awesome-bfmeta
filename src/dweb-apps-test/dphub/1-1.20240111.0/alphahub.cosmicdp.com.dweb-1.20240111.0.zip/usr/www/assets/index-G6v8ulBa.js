import{j as c,o as e,c as n}from"./index--KhaU7UW.js";const o={},s={class:"min-h-full bg-black-10"};function t(a,r){return e(),n("div",s,"launchpad")}const l=c(o,[["render",t]]);export{l as default};
