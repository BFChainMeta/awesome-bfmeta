import{_ as e,c,o as n}from"./index-k-dIfXra.js";const o={};function r(t,_){return n(),c("div",null,"404")}const a=e(o,[["render",r]]);export{a as default};
