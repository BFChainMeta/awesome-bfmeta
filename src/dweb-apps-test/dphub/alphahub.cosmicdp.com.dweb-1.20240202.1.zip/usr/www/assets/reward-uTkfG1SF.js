import{_ as e,c,o as r}from"./index-9mTVSmRw.js";const o={},s={class:"min-h-full bg-black-10"};function t(a,n){return r(),c("div",s," reward ")}const l=e(o,[["render",t]]);export{l as default};
