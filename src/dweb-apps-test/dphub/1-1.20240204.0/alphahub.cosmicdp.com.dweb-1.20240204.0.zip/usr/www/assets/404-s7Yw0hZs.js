import{_ as e,o as c,c as n}from"./index-EpbKQs9G.js";const o={};function r(t,_){return c(),n("div",null,"404")}const a=e(o,[["render",r]]);export{a as default};
