import{_ as e,o as c,c as r}from"./index-EpbKQs9G.js";const o={},s={class:"min-h-full bg-black-10"};function t(a,n){return c(),r("div",s," reward ")}const l=e(o,[["render",t]]);export{l as default};
