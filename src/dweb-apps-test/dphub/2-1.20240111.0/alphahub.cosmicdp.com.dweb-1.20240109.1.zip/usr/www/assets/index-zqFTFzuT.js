import{j as e,o as c,c as n}from"./index-T2vCn6u8.js";const o={};function r(t,s){return c(),n("div",null,"404")}const _=e(o,[["render",r]]);export{_ as default};
