import{l as c,o as e,c as n}from"./index-1d5dfc36.js";const o={},s={class:"min-h-full bg-black-10"};function t(a,r){return e(),n("div",s,"launchpad")}const _=c(o,[["render",t]]);export{_ as default};
