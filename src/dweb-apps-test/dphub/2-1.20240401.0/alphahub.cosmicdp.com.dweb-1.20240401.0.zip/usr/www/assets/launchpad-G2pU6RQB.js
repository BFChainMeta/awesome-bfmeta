import{_ as c,o as e,c as a}from"./index-H1PrI8aQ.js";const n={},o={class:"min-h-full bg-black-10"};function s(t,r){return e(),a("div",o,"launchpad")}const l=c(n,[["render",s]]);export{l as default};
