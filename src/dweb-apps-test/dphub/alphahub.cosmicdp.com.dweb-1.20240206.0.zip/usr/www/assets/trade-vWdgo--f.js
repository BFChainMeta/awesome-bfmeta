import{_ as e,o as c,c as t}from"./index-8JOuaTzj.js";const o={},r={class:"min-h-full bg-black-10"};function s(a,n){return c(),t("div",r," trade ")}const l=e(o,[["render",s]]);export{l as default};
