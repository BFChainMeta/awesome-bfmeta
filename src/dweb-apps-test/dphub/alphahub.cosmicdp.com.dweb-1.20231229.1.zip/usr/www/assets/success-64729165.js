const s="/assets/success-7accd306.png";export{s as _};
