import{j as e,o as c,c as n}from"./index-jbhxJlMg.js";const o={},r={class:"min-h-full bg-black-10"};function s(t,a){return c(),n("div",r," reward ")}const l=e(o,[["render",s]]);export{l as default};
