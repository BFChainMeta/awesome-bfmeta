import { CommonModule } from '@angular/common';
import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import {
  fadeInLeftTrigger,
  fadeInRightTrigger,
  listFadeInRightTrigger,
  listFadeOutLeftTrigger,
  listFadeRightTrigger,
} from '@bnqkl/framework/animations';
import BigNumber from 'bignumber.js';
import { Subscription } from 'rxjs';
import { CHAIN_NAME } from '@bnqkl/wallet-base/services';
import { CommonPageBase, CommonPageModule } from '~modules/page.module';
import { $CHAIN_CARD_INFO, $CHAIN_CARD_INFO_MAP, $SupportChain } from './assets.type';
import { WalletService } from '~services/wallet/wallet.service';
import { $WalletAsset } from '~services/swap-data-storage/swap-data-storage.type';
import { AddressHiddenPipe } from '@bnqkl/framework/pipes';
import { LiquidityUserService } from '~services/liquidity-user/liquidity-user.service';
import { $WalletAssetMap } from '~services/wallet/wallet.type';
import {  BNQKL_SWAP_COIN_NAME } from '@bnqkl/bnqkl-swap-core';
import { NODE_CHAIN_NAME_TRANSFER } from '~services/wallet/wallet.helper';
import { AmountFormatPipe } from '~pipes/amount-format/amount-format.pipe';
import { SwapTokenChainIconComponent } from '~components/swap-token-chain-icon/swap-token-chain-icon.component';

/** 钱包页 */
@Component({
  selector: 'bs-assets',
  standalone: true,
  imports: [SwapTokenChainIconComponent,AmountFormatPipe, AddressHiddenPipe, CommonPageModule, CommonModule],
  templateUrl: './assets.component.html',
  styleUrls: ['./assets.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
  animations: [
    listFadeRightTrigger,
    listFadeInRightTrigger,
    listFadeOutLeftTrigger,
    fadeInLeftTrigger,
    fadeInRightTrigger,
  ],
})
export class AssetsPage extends CommonPageBase {
  /** 连接钱包变化 */
  connectWallet$: Subscription | undefined;
  /** 钱包服务 */
  private walletService = inject(WalletService);
  /** 用户服务 */
  private userService = inject(LiquidityUserService);

  /** 各个链的链信息详情 */
  chainListDetail = [];

  /** 可支持的链列表  */
  @AssetsPage.State()
  supportChainList: $SupportChain[] = [];

  /** 选中的链名称 */
  @AssetsPage.State()
  activeChainName: $SupportChain['chain'] | undefined;

  /** 已连接的钱包 */
  @AssetsPage.State()
  connectedWallet = this.walletService.connectedWallet;
  /** 用户总资产 */
  @AssetsPage.State()
  totalUAmount = '- -';

  /** 余额的显示与隐藏 */
  @AssetsPage.State()
  showMyAsset = false;
  /** loading */
  @AssetsPage.State()
  loading = true;
  /** 监听余额 */
  walletAssets$ = this.walletService.curentWalletAssets_subject.subscribe(async (assetTaskInfo) => {
    if (assetTaskInfo.updating || assetTaskInfo.connectedWallet === undefined) {
      return;
    }
    if (
      this.connectedWallet === undefined ||
      this.connectedWallet.pmchainAddress !== assetTaskInfo.connectedWallet.pmchainAddress
    ) {
      return;
    }
    this.console.info('更新资产页余额');
    this.connectedWallet = assetTaskInfo.connectedWallet;
    return;
  });
  /** 打开提示窗口 */
  async openTip() {
    await this.alert({
      headerTitle: `总资产`,
      bodyMessage:
        '总资产仅根据钱包授权的，且在BTCSwap中支持兑换的权益（即：BFT，PMC，ETHM，BTCM，KPM，FTC，USDM等）换算成USDM计算，范围包括地址中的权益，以及各流动池权益。',
      buttonText: '好的',
      bodyClass:'swap'
    });
  }

  /** 要展示的链信息（资产列表） */
  get showChainInfo() {
    const chainCardInfo = this.CHAIN_CARD_INFO.get(this.activeChainName as CHAIN_NAME);
    if (this.activeChainName && this.connectedWallet) {
      const assetsList = this.connectedWallet.assetInfoListMap.get(this.activeChainName);
      if (assetsList) {
       
        return {
          bgIconUrl: chainCardInfo?.bgIconUrl || this.CHAIN_CARD_DEFAULT_INFO.bgIconUrl,
          bgColor: chainCardInfo?.bgColor || this.CHAIN_CARD_DEFAULT_INFO.bgColor,
          ...assetsList,
        };
      }
     
      
    }
    return {
      bgIconUrl: chainCardInfo?.bgIconUrl || this.CHAIN_CARD_DEFAULT_INFO.bgIconUrl,
      bgColor: chainCardInfo?.bgColor || this.CHAIN_CARD_DEFAULT_INFO.bgColor,
      chainName: this.activeChainName as CHAIN_NAME,
      assets: [] as $WalletAsset[],
      address: '',
    };
  }

  /** 链卡片信息 */
  private readonly CHAIN_CARD_INFO: $CHAIN_CARD_INFO_MAP = new Map([
    [CHAIN_NAME.BFChainV2, { bgColor: '#A484EE', bgIconUrl: './assets/images/chain-BFChainV2-w.png' }],
    [CHAIN_NAME.BFMeta, { bgColor: '#7D65F7', bgIconUrl: './assets/images/chain-BFMeta-w.png' }],
    [CHAIN_NAME.BTCMeta, { bgColor: '#F7931A', bgIconUrl: './assets/images/chain-BTCMeta-w.png' }],
    [CHAIN_NAME.ETHMeta, { bgColor: '#1829F5', bgIconUrl: './assets/images/chain-ETHMeta-w.png' }],
    [CHAIN_NAME.PMChain, { bgColor: '#8265F9', bgIconUrl: './assets/images/chain-Pay-Meta-Chain-w.png' }],
  ]);

  /** 默认卡片信息 */
  CHAIN_CARD_DEFAULT_INFO: $CHAIN_CARD_INFO = { bgColor: '#A484EE', bgIconUrl: './assets/images/chain-normal-w.png' };

  /** 是否是选中的链 */
  isSelectedChain(chain: $SupportChain) {
    return chain.chain === this.activeChainName;
  }
  /** 刷新资产 */
  async reGetAsset() {
    await this.walletService.updateAsset();
  }

  /** 清除订阅监听 */
  @AssetsPage.OnDestroy()
  private unsubscribe() {
    this.console.log('清除 订阅 walletAssets$');
    this.walletAssets$.unsubscribe();
    this.walletService.allSubscribes.delete('AssetsPage');
  }

  /** 默认选中第一条 */
  @AssetsPage.OnReady()
  async selectDefaultChain() {
    this.activeChainName = this.supportChainList[0].chain;
    // this.walletService.allSubscribes.set('AssetsPage', [this.walletAssets$]);
  }

  /** 链名 */
  CHAIN_NAME = CHAIN_NAME;
  /** 选中链 */
  selectChain(chain: $SupportChain) {
    this.activeChainName = chain.chain;
  }

  /** 动画的状态机 */
  get listFadeInRightState() {
    return this.activeChainName + ':' + this.showChainInfo.assets.length;
  }
  /** 动画状态机 */
  get chianNameFadeInRightState() {
    return this.activeChainName;
  }
  /** 初始化资产 */
  initAssets() {
    this.totalUAmount = '- -';
    this.pieChartData.totalAmount = '- -';
    this.pieChartData.list = [];
  }
  @AssetsPage.OnInit()
  walletInit() {
    // 监听钱包变化
    this.connectWallet$ = this.walletService.wallletConnected_subject.subscribe(async (data) => {
      if (data === undefined) {
        return;
      }
      const wallet = data.wallet;
      this.console.info('兑换面板监听到钱包变化==========', wallet);
      this.connectedWallet = wallet;
       if(wallet===undefined){
        this.initAssets();
       }
      
      
    });
    // 监听余额变化
    this.walletAssets$ = this.walletService.curentWalletAssets_subject.subscribe(async (assetTaskInfo) => {
      const { updating, connectedWallet } = assetTaskInfo;
      /** 实时变更界面余额(如果余额发生变化的话) */
      this.console.info('兑换面板监听到余额变化---------', updating, connectedWallet);
      if (updating) {
       
        this.loading = true;
      } else {
        if (connectedWallet) {
          this.connectedWallet = connectedWallet;
          this.getUserPositonList();
        }
      }
    });
  }
  /** 跳转个人资产页面 */
  jumpAssetAllocation() {
    this.nav.routeTo('/mine/my-asset-allocation', { pieChartData: JSON.stringify(this.pieChartData) });
  }
  /** 获取用户持仓 */
  async getUserPositonList() {
    const { connectedWallet } = this;
    if (connectedWallet) {
      const userId = connectedWallet.pmchainAddress;
      const result = await this.userService.getLiquidityUserAssetsList({ userId });
      
      
      if (result) {
        const walletAssets = connectedWallet.assetInfoListMap;
        const positionAsset = this.handlerPositionAssetGenMap(result);
        const walletAsset = this.handleWalletAsset(walletAssets, positionAsset);
        const walletTotalU = this.calculateWalletTotalU(walletAsset);
        const positonTotalU = this.calculatePostitonTotalU(result);
        const totalU = walletTotalU + positonTotalU;
        this.totalUAmount = String(totalU);
        this.handlePieChartData(walletAsset, result);
        this.loading = false;
      }
    } else {
      this.totalUAmount = '- -';
    }
  }
  /** 处理饼图需要的的数据  免去再次查询 */
  handlePieChartData(
    walletAsset: { coin: string; amount: number }[],
    postionAsset: BnqklSwap.User.GetUserAssetsListRes
  ) {
    const { totalUAmount } = this;

    const list: { name: string; amount: number }[] = [];
    walletAsset.forEach((item) => {
      const ratio = new BigNumber(item.amount).div(totalUAmount);

      list.push({ name: item.coin, amount: Number(ratio) });
    });
    postionAsset.forEach((item) => {
      const { userRedeemableQuoteCoinsAmount } = item;
      if (Number(userRedeemableQuoteCoinsAmount) > 0) {
        const amount = new BigNumber(userRedeemableQuoteCoinsAmount).multipliedBy(2);
        const ratio = amount.div(totalUAmount);
        list.push({
          name: `池${item.anchorCoinsName}-${item.quoteCoinsName}`,
          amount: Number(ratio),
        });
      }
    });
    this.pieChartData.totalAmount = totalUAmount;
    this.pieChartData.list = list;
  }
  /** 传递给饼图的数据 */
  pieChartData: { totalAmount: string; list: { name: string; amount: number }[] } = {
    totalAmount: '- -',
    list: [],
  };
  /** 计算持仓全部的U  */
  calculatePostitonTotalU(assetList: BnqklSwap.User.GetUserAssetsListRes) {
    let totalU = 0n;
    assetList.forEach((asset) => {
      totalU += BigInt(asset.userRedeemableQuoteCoinsAmount) * 2n;
    });

    return totalU;
  }
  /** 计算钱包全部的U */
  calculateWalletTotalU(assetList: { coin: string; amount: number }[]) {
    let totalU = 0n;
    assetList.forEach((asset) => {
      totalU += BigInt(asset.amount);
    });

    return totalU;
  }
  /** 处理持仓资产生成Map方便获取 */
  private handlerPositionAssetGenMap(assetList: BnqklSwap.User.GetUserAssetsListRes) {
    const assetMap = new Map<string, BnqklSwap.User.UserPosition>();
    assetList.forEach((asset) => {
      const anchorCoinName = asset.anchorCoinsName;
      const anchorChainName = asset.anchorCoinsChainName;
      const key = `${anchorCoinName}-${NODE_CHAIN_NAME_TRANSFER[anchorChainName]}`;
      assetMap.set(key, asset);
    });
    return assetMap;
  }
  /** 处理钱包的资产 */
  private handleWalletAsset(walletAssets: $WalletAssetMap, positionAssets: Map<string, BnqklSwap.User.UserPosition>) {
    let walletUAmount = 0;
    const assetList: { coin: string; amount: number }[] = [];
    for (const [chainName, value] of walletAssets) {
      value.assets.forEach((element) => {
        const { assetType: coinName, amount: coinAmount } = element;
        if (Number(coinAmount) > 0) {
          // 如果是U 不需要换算 不是U 要根据池子中币的数量 等比换算成U
          if (coinName === BNQKL_SWAP_COIN_NAME.USDM) {
            walletUAmount += Number(coinAmount);
          } else {
            const key = `${coinName}-${chainName}`;
            const positionAsset = positionAssets.get(key);
            if (positionAsset) {
              const { price } = positionAsset;
              const equivalenceU = parseInt(new BigNumber(price).multipliedBy(coinAmount).toString());
              assetList.push({ coin: coinName, amount: equivalenceU });
            }
          }
        }
      });
    }
    if (walletUAmount > 0) {
      assetList.unshift({ coin: BNQKL_SWAP_COIN_NAME.USDM, amount: walletUAmount });
    }
    return assetList;
  }
  /** 跳转充值页面 */
  jumpToRecharge(){
    this.nav.routeTo('/recharge')
  }
}
export default AssetsPage;
