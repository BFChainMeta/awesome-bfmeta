"use strict";
(self["webpackChunkbfswap"] = self["webpackChunkbfswap"] || []).push([["apps_bfswap_src_assets_wallet-util_index-b6e920cf_mjs"],{

/***/ 84467:
/*!***************************************************************!*\
  !*** ./apps/bfswap/src/assets/wallet-util/index-b6e920cf.mjs ***!
  \***************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   coins: () => (/* binding */ g),
/* harmony export */   etc: () => (/* binding */ S),
/* harmony export */   getCoin: () => (/* binding */ d),
/* harmony export */   networks: () => (/* binding */ s),
/* harmony export */   rsk: () => (/* binding */ r),
/* harmony export */   tron: () => (/* binding */ C)
/* harmony export */ });
/* harmony import */ var D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 52542);
/* harmony import */ var _networks_0de0aba6_mjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./networks-0de0aba6.mjs */ 30274);


const o = (e, n, i, o, s, a, t) => {
    const c = {
      messagePrefix: e,
      bech32: n,
      bip32: {
        public: i[0],
        private: i[1]
      },
      pubKeyHash: o,
      scriptHash: s,
      wif: a
    };
    return Object.assign(c, t);
  },
  s = {
    bitcoin: _networks_0de0aba6_mjs__WEBPACK_IMPORTED_MODULE_1__.b,
    regtest: _networks_0de0aba6_mjs__WEBPACK_IMPORTED_MODULE_1__.r,
    testnet: _networks_0de0aba6_mjs__WEBPACK_IMPORTED_MODULE_1__.t,
    dummyNetwork: o("", "", [0, 0], 0, 0, 0, {}),
    shadow: o("unused", "", [4001376362, 4001378792], 63, 125, 191, {}),
    shadowtn: o("unused", "", [1992359419, 1992361850], 127, 196, 255, {}),
    clam: o("unused", "", [2831314276, 2831251494], 137, 13, 133, {}),
    crown: o("unused", "", [76067358, 76066276], 0, 5, 128, {}),
    dash: o("unused", "", [76067358, 76066276], 76, 16, 204, {}),
    maza: o("unused", "", [76067358, 76066276], 50, 9, 224, {}),
    dashtn: o("unused", "", [70617039, 70615956], 140, 19, 239, {}),
    game: o("unused", "", [76067358, 76066276], 38, 5, 166, {}),
    namecoin: o("unused", "", [76067358, 76066276], 52, 13, 180, {}),
    peercoin: o("unused", "", [76067358, 76066276], 55, 117, 183, {}),
    axe: o("unused", "", [76067358, 76066276], 55, 16, 204, {}),
    scribe: o("unused", "", [76067358, 76066276], 60, 125, 110, {}),
    slimcoin: o("unused", "", [4016758544, 4016695936], 63, 125, 70, {}),
    slimcointn: o("unused", "", [70617039, 70615956], 111, 196, 87, {}),
    dogecoin: o("Dogecoin Signed Message:\n", "", [49990397, 49988504], 30, 22, 158, {}),
    dogecointestnet: o("Dogecoin Signed Message:\n", "", [70617039, 70615956], 113, 196, 241, {}),
    denarius: o("Denarius Signed Message:\n", "", [76067358, 76066276], 30, 90, 158, {}),
    neblio: o("Neblio Signed Message:\n", "", [76067358, 76066276], 53, 112, 181, {}),
    viacoin: o("Viacoin Signed Message:\n", "", [76067358, 76066276], 71, 33, 199, {}),
    viacointestnet: o("Viacoin Signed Message:\n", "", [70617039, 70615956], 127, 196, 255, {}),
    gamerscoin: o("Gamerscoin Signed Message:\n", "", [27108450, 27106558], 38, 5, 166, {}),
    jumbucks: o("Jumbucks Signed Message:\n", "", [58353818, 58352736], 43, 5, 171, {}),
    zetacoin: o("Zetacoin Signed Message:\n", "", [76067358, 76066276], 80, 9, 224, {}),
    myriadcoin: o("unused", "", [76067358, 76066276], 50, 9, 178, {}),
    bolivarcoin: o("Bolivarcoin Signed Message:\n", "", [76067358, 76066276], 85, 5, 213, {}),
    onixcoin: o("ONIX Signed Message:\n", "", [76067358, 76066276], 75, 5, 203, {}),
    lkrcoin: o("LKRcoin Signed Message:\n", "", [76067358, 76066276], 48, 85, 176, {}),
    pivx: o("unused", "", [36513075, 35729707], 30, 13, 212, {}),
    pivxtestnet: o("unused", "", [981492128, 981489719], 139, 19, 239, {}),
    fix: o("unused", "", [36513075, 35729707], 35, 95, 60, {}),
    fixtestnet: o("unused", "", [981492128, 981489719], 76, 137, 237, {}),
    fujicoin: o("FujiCoin Signed Message:\n", "", [76067358, 76066276], 36, 16, 164, {}),
    nubits: o("Nu Signed Message:\n", "", [76067358, 76066276], 25, 26, 150, {}),
    bgold: o("Bitcoin Gold Signed Message:\n", "", [76067358, 76066276], 38, 23, 128, {}),
    monacoin: o("Monacoin Signed Message:\n", "", [76067358, 76066276], 50, 55, 176, {}),
    litecoinXprv: o("Litecoin Signed Message:\n", "", [76067358, 76066276], 48, 50, 176, {}),
    komodo: o("Komodo Signed Message:\n", "", [76067358, 76066276], 60, 85, 188, {}),
    blackcoin: o("BlackCoin Signed Message:\n", "", [47169246, 47169376], 25, 85, 153, {}),
    beetlecoin: o("Beetlecoin Signed Message:\n", "", [76067358, 76066276], 26, 85, 153, {}),
    adcoin: o("AdCoin Signed Message:\n", "", [76067358, 76066276], 23, 5, 176, {}),
    asiacoin: o("AsiaCoin Signed Message:\n", "", [76067358, 76066276], 23, 8, 151, {}),
    auroracoin: o("AuroraCoin Signed Message:\n", "", [76067358, 76066276], 23, 5, 151, {}),
    bata: o("Bata Signed Message:\n", "", [2752284410, 2752221629], 25, 5, 164, {}),
    belacoin: o("BelaCoin Signed Message:\n", "", [76067358, 76066276], 25, 5, 153, {}),
    atom: o("Bitcoin Signed Message:\n", "", [76067358, 76066276], 23, 10, 128, {}),
    bitcoinplus: o("BitcoinPlus Signed Message:\n", "", [76067358, 76066276], 25, 8, 153, {}),
    bitcloud: o("BitCloud Signed Message:\n", "", [76067358, 76066276], 25, 5, 153, {}),
    bitcore: o("BitCore Signed Message:\n", "", [76067358, 76066276], 3, 125, 128, {}),
    bitsend: o("Bitsend Signed Message:\n", "", [76067358, 76066276], 102, 5, 204, {}),
    britcoin: o("BritCoin Signed Message:\n", "", [76067358, 76066276], 25, 85, 153, {}),
    canadaecoin: o("Canada eCoin Signed Message:\n", "", [76067358, 76066276], 28, 5, 156, {}),
    cannacoin: o("Cannacoin Signed Message:\n", "", [76067358, 76066276], 28, 5, 156, {}),
    cranepay: o("Bitcoin Signed Message:\n", "", [76067358, 76066276], 28, 10, 123, {}),
    cryptoescudo: o("Cryptoescudo Signed Message:\n", "", [76067358, 76066276], 28, 5, 156, {}),
    clubcoin: o("ClubCoin Signed Message:\n", "", [76067358, 76066276], 28, 85, 153, {}),
    compcoin: o("CompCoin Signed Message:\n", "", [76067358, 76066276], 28, 85, 156, {}),
    crave: o("DarkNet Signed Message:\n", "", [76067358, 76066276], 70, 85, 153, {}),
    defcoin: o("defcoin Signed Message:\n", "", [76067358, 76066276], 30, 5, 158, {}),
    diamond: o("Diamond Signed Message:\n", "", [76067358, 76066276], 90, 8, 218, {}),
    digibyte: o("DigiByte Signed Message:\n", "", [76067358, 76066276], 30, 5, 128, {}),
    digitalcoin: o("Digitalcoin Signed Message:\n", "", [2651097266, 76066276], 30, 5, 158, {}),
    divi: o("Divi Signed Message:\n", "", [36513075, 35729707], 30, 13, 212, {}),
    divitestnet: o("Divi Signed Message:\n", "", [981492128, 981489719], 139, 19, 239, {}),
    ecoin: o("eCoin Signed Message:\n", "", [76067358, 76066276], 92, 20, 220, {}),
    edrcoin: o("EDRcoin Signed Message:\n", "", [76067358, 76066276], 93, 28, 221, {}),
    egulden: o("Egulden Signed Message:\n", "", [76067358, 76066276], 48, 5, 176, {}),
    einsteinium: o("Einsteinium Signed Message:\n", "", [76067358, 76066276], 33, 5, 161, {}),
    europecoin: o("Bitcoin Signed Message:\n", "", [76067358, 76066276], 33, 5, 168, {}),
    exclusivecoin: o("ExclusiveCoin Signed Message:\n", "", [76067358, 76066276], 33, 137, 161, {}),
    feathercoin: o("Feathercoin Signed Message:\n", "", [76069926, 76077806], 14, 5, 142, {}),
    firo: o("Firo Signed Message:\n", "", [76067358, 76066276], 82, 7, 210, {}),
    zcoin: o("Zcoin Signed Message:\n", "", [76067358, 76066276], 82, 7, 210, {}),
    firstcoin: o("FirstCoin Signed Message:\n", "", [76067358, 76066276], 35, 5, 163, {}),
    flashcoin: o("Flashcoin Signed Message:\n", "", [76067358, 76066276], 68, 130, 196, {}),
    gcr: o("GCR Signed Message:\n", "", [76067358, 76066276], 38, 97, 154, {}),
    gobyte: o("DarkCoin Signed Message:\n", "", [76067358, 76066276], 38, 10, 198, {}),
    gridcoin: o("Gridcoin Signed Message:\n", "", [76067358, 76066276], 62, 85, 190, {}),
    groestlcoin: o("GroestlCoin Signed Message:\n", "", [76067358, 76066276], 36, 5, 128, {}),
    groestlcointestnet: o("GroestlCoin Signed Message:\n", "", [70617039, 70615956], 111, 196, 239, {}),
    gulden: o("Guldencoin Signed Message:\n", "", [76067358, 76066276], 38, 98, 98, {}),
    helleniccoin: o("helleniccoin Signed Message:\n", "", [76067358, 76066276], 48, 5, 176, {}),
    hempcoin: o("Hempcoin Signed Message:\n", "", [76067358, 76066276], 40, 8, 168, {}),
    insane: o("INSaNe Signed Message:\n", "", [76067358, 76066276], 102, 57, 55, {}),
    iop: o("IoP Signed Message:\n", "", [662737247, 2922649334], 117, 174, 49, {}),
    ixcoin: o("Ixcoin Signed Message:\n", "", [76067358, 76066276], 138, 5, 128, {}),
    kobocoin: o("Kobocoin Signed Message:\n", "", [76067358, 76066276], 35, 28, 163, {}),
    landcoin: o("Landcoin Signed Message:\n", "", [76067358, 76066276], 48, 122, 176, {}),
    lbry: o("LBRYcrd Signed Message:\n", "", [76067358, 76066276], 85, 122, 28, {}),
    linx: o("LinX Signed Message:\n", "", [76067358, 76066276], 75, 5, 203, {}),
    litecointestnet: o("Litecoin Signed Message:\n", "", [70617039, 70615956], 111, 196, 239, {}),
    litecoin: o("Litecoin Signed Message:\n", "", [27108450, 27106558], 48, 50, 176, {
      p2wpkh: o("Litecoin Signed Message:\n", "ltc", [78792518, 78791436], 48, 50, 176, {
        baseNetwork: "litecoin"
      }),
      p2wpkhInP2sh: o("Litecoin Signed Message:\n", "ltc", [28471030, 28469138], 48, 50, 176, {
        baseNetwork: "litecoin"
      })
    }),
    litecoincash: o("Litecoin Signed Message:\n", "", [76067358, 76066276], 28, 5, 176, {}),
    lynx: o("Lynx Signed Message:\n", "", [76067358, 76066276], 45, 50, 173, {}),
    megacoin: o("Megacoin Signed Message:\n", "", [76067358, 76066276], 50, 5, 178, {}),
    minexcoin: o("Bitcoin Signed Message:\n", "", [76067358, 76066276], 75, 5, 128, {}),
    navcoin: o("Navcoin Signed Message:\n", "", [76067358, 76066276], 53, 85, 150, {}),
    neoscoin: o("NeosCoin Signed Message:\n", "", [76067358, 76066276], 53, 5, 177, {}),
    nix: o("Nix Signed Message:\n", "", [76067358, 76066276], 38, 53, 128, {}),
    neurocoin: o("PPCoin Signed Message:\n", "", [76067358, 76066276], 53, 117, 181, {}),
    newyorkc: o("newyorkc Signed Message:\n", "", [76067358, 76066276], 60, 22, 188, {}),
    novacoin: o("NovaCoin Signed Message:\n", "", [76067358, 76066276], 8, 20, 136, {}),
    nushares: o("Nu Signed Message:\n", "", [76067358, 76066276], 63, 64, 149, {}),
    okcash: o("OKCash Signed Message:\n", "", [63710167, 63708275], 55, 28, 3, {}),
    omnicore: o("Bitcoin Signed Message:\n", "", [76067358, 76066276], 0, 5, 128, {}),
    pesobit: o("Pesobit Signed Message:\n", "", [76067358, 76066276], 55, 85, 183, {}),
    pinkcoin: o("Pinkcoin Signed Message:\n", "", [76067358, 76066276], 3, 28, 131, {}),
    poswcoin: o("Poswcoin Signed Message:\n", "", [76067358, 76066276], 55, 85, 183, {}),
    potcoin: o("Potcoin Signed Message:\n", "", [76067358, 76066276], 55, 5, 183, {}),
    putincoin: o("PutinCoin Signed Message:\n", "", [76067358, 76066276], 55, 20, 183, {}),
    ravencoin: o("Raven Signed Message:\n", "", [76067358, 76066276], 60, 122, 128, {}),
    reddcoin: o("Reddcoin Signed Message:\n", "", [76067358, 76066276], 61, 5, 189, {}),
    revolutionvr: o("Voxels Signed Message:\n", "", [76067358, 76066276], 70, 5, 198, {}),
    ritocoin: o("Rito Signed Message:\n", "", [76067358, 76066276], 25, 105, 139, {}),
    rsk: o("RSK Signed Message:\n", "", [76067358, 76066276], 0, 5, 128, {}),
    rsktestnet: o("RSK Testnet Signed Message:\n", "", [70617039, 70615956], 111, 196, 239, {}),
    rubycoin: o("Rubycoin Signed Message:\n", "", [76067358, 76066276], 60, 85, 188, {}),
    safecoin: o("Safecoin Signed Message:\n", "", [76067358, 76066276], 61, 86, 189, {}),
    salus: o("Salus Signed Message:\n", "", [76067358, 76066276], 63, 196, 191, {}),
    smileycoin: o("Smileycoin Signed Message:\n", "", [508964250, 508965308], 25, 5, 5, {}),
    solarcoin: o("SolarCoin Signed Message:\n", "", [76067358, 76066276], 18, 5, 146, {}),
    stash: o("Stash Signed Message:\n", "", [76067358, 76066276], 76, 16, 204, {}),
    stashtn: o("Stash Test Signed Message:\n", "", [70617039, 70615956], 140, 19, 239, {}),
    stratis: o("Stratis Signed Message:\n", "", [76067358, 76066276], 63, 125, 191, {}),
    stratistest: o("Stratis Test Signed Message:\n", "", [76067358, 76066276], 65, 125, 191, {}),
    syscoin: o("Syscoin Signed Message:\n", "", [76067358, 76066276], 63, 5, 128, {}),
    toa: o("TOA Signed Message:\n", "", [76067358, 76066276], 65, 23, 193, {}),
    twins: o("unused", "", [36513075, 35729707], 73, 83, 66, {}),
    twinstestnet: o("unused", "", [981492128, 981489719], 76, 137, 237, {}),
    ultimatesecurecash: o("UltimateSecureCash Signed Message:\n", "", [4001376362, 4001378792], 68, 125, 191, {}),
    unobtanium: o("Unobtanium Signed Message:\n", "", [76067358, 76066276], 130, 30, 224, {}),
    vcash: o("Vcash Signed Message:\n", "", [76067358, 76066276], 71, 8, 199, {}),
    verge: o("VERGE Signed Message:\n", "", [76067358, 76066276], 30, 33, 158, {}),
    vertcoin: o("Vertcoin Signed Message:\n", "", [76067358, 76066276], 71, 5, 128, {}),
    vivo: o("DarkCoin Signed Message:\n", "", [76067358, 76066276], 70, 10, 198, {}),
    vpncoin: o("VpnCoin Signed Message:\n", "", [76067358, 76066276], 71, 5, 199, {}),
    whitecoin: o("Whitecoin Signed Message:\n", "", [76054302, 76059885], 73, 87, 201, {}),
    wincoin: o("WinCoin Signed Message:\n", "", [76067358, 76066276], 73, 28, 201, {}),
    zcash: o("Zcash Signed Message:\n", "", [76067358, 76066276], 7352, 7357, 128, {}),
    xuez: o("unused", "", [36513075, 35729707], 75, 18, 212, {}),
    bitcoinprivate: o("BitcoinPrivate Signed Message:\n", "", [76067358, 76066276], 4901, 5039, 128, {}),
    bitcoinprivatetestnet: o("BitcoinPrivate Signed Message:\n", "", [70617039, 70615956], 6487, 6624, 239, {}),
    bitcoinz: o("BitcoinZ Signed Message:\n", "", [76067358, 76066276], 7352, 7357, 128, {}),
    hush: o("Hush Signed Message:\n", "", [76067358, 76066276], 7352, 7357, 128, {}),
    hush3: o("Hush Signed Message:\n", "", [76067358, 76066276], 60, 85, 188, {}),
    zoobc: o("ZooBC Signed Message:\n", "bc", [76067358, 76066276], 0, 5, 128, {}),
    zclassic: o("Zcash Signed Message:\n", "", [76067358, 76066276], 7352, 7357, 128, {}),
    zencash: o("Zcash Signed Message:\n", "", [76067358, 76066276], 8329, 8342, 128, {}),
    energi: o("DarkCoin Signed Message:\n", "", [62441558, 3621547679], 33, 53, 106, {}),
    exchangecoin: o("ExchangeCoin Signed Message:\n", "", [76067358, 76066276], 8633, 13487, 128, {}),
    artax: o("Artax Signed Message:\n", "", [76067358, 76066276], 23, 7357, 151, {}),
    bitcoingreen: o("BitcoinGreen Signed Message:\n", "", [76067358, 76066276], 38, 7357, 46, {}),
    anon: o("ANON Signed Message:\n", "", [76067358, 76066276], 1410, 21385, 128, {}),
    projectcoin: o("ProjectCoin Signed Message:\n", "", [36513075, 35729707], 55, 8, 117, {}),
    phore: o("Phore Signed Message:\n", "", [36513075, 35729707], 55, 13, 212, {}),
    blocknode: o("Blocknode Signed Message:\n", "", [76067358, 76066276], 25, 63, 75, {}),
    blocknode_testnet: o("Blocknode Testnet Signed Message:\n", "", [70617039, 70615956], 85, 125, 137, {}),
    litecoinz: o("LitecoinZ Signed Message:\n", "", [76067358, 76066275], 2739, 2744, 128, {}),
    blockstamp: o("BlockStamp Signed Message:\n", "", [76067358, 76066276], 0, 5, 128, {}),
    deeponion: o("x18DeepOnion Signed Message:\n", "", [76067358, 76066276], 31, 78, 159, {}),
    cpuchain: o("x18CPUchain Signed Message:\n", "", [76067358, 76066276], 28, 30, 128, {}),
    wagerr: o("unused", "", [36513075, 35729707], 73, 63, 199, {}),
    bitcoinsv: o("unused", "", [76067358, 76066276], 0, 5, 128, {}),
    monkeyproject: o("Monkey Signed Message:\n", "", [76067358, 76078564], 51, 28, 55, {}),
    rapids: o("DarkNet Signed Message:\n", "", [76067358, 76066276], 61, 6, 46, {}),
    aryacoin: o("Aryacoin Signed Message:\n", "arya", [76067358, 76066276], 23, 111, 151, {}),
    thought: o("unused", "", [4224098317, 1525405894], 7, 9, 123, {}),
    elastos: o("unused", "", [76067358, 76066276], 33, 196, 239, {}),
    sugarchain: o("Sugarchain Signed Message:\n", "", [76067358, 76066276], 63, 125, 128, {}),
    sugarchaintestnet: o("Sugarchain Signed Message:\n", "", [73342198, 73341116], 66, 128, 239, {}),
    argoneum: o("unused", "", [76067358, 76066276], 50, 97, 191, {}),
    particl: o("Bitcoin Signed Message:\n", "pw", [1768850129, 2401087160], 56, 60, 108, {})
  };
Object.setPrototypeOf(s, null);
const a = (e, n, i, o) => {
    const a = {
      symbol: e,
      network: s[n],
      hdCoin: i,
      derivationPath: `m/44'/${i}'/0'/0`
    };
    return Object.assign(a, o);
  },
  t = {
    prefixs: ["Ltpv / Ltub", "xprv / xpub"]
  },
  c = {
    derived_addresses: ["CashAddr", "BitPay-style", "legacy"]
  },
  g = {
    "AC - Asiacoin": a("AC", "asiacoin", 51),
    "ACC - Adcoin": a("ACC", "adcoin", 161),
    "AGM - Argoneum": a("AGM", "argoneum", 421),
    "ARYA - Aryacoin": a("ARYA", "aryacoin", 357),
    "ATOM - Cosmos Hub": a("ATOM", "bitcoin", 118),
    "AUR - Auroracoin": a("AUR", "auroracoin", 85),
    "AXE - Axe": a("AXE", "axe", 4242),
    "ANON - ANON": a("ANON", "anon", 220),
    "BOLI - Bolivarcoin": a("BOLI", "bolivarcoin", 278),
    "BCA - Bitcoin Atom": a("BCA", "atom", 185),
    "BCH - Bitcoin Cash": a("BCH", "bitcoin", 145, c),
    "BEET - Beetlecoin": a("BEET", "beetlecoin", 800),
    "BELA - Belacoin": a("BELA", "belacoin", 73),
    "BLK - BlackCoin": a("BLK", "blackcoin", 10),
    "BND - Blocknode": a("BND", "blocknode", 2941),
    "tBND - Blocknode Testnet": a("tBND", "blocknode_testnet", 1),
    "BRIT - Britcoin": a("BRIT", "britcoin", 70),
    "BSD - Bitsend": a("BSD", "bitsend", 91),
    "BST - BlockStamp": a("BST", "blockstamp", 254),
    "BTA - Bata": a("BTA", "bata", 89),
    "BTC - Bitcoin": a("BTC", "bitcoin", 0),
    "BTC - Bitcoin RegTest": a("BTC", "regtest", 1),
    "BTC - Bitcoin Testnet": a("BTC", "testnet", 1),
    "BITG - Bitcoin Green": a("BITG", "bitcoingreen", 222),
    "BTCP - Bitcoin Private": a("BTCP", "bitcoinprivate", 183),
    "BTCPt - Bitcoin Private Testnet": a("BTCPt", "bitcoinprivatetestnet", 1),
    "BSC - Binance Smart Chain": a("BSC", "bitcoin", 60),
    "BNB - Binance Smart Chain": a("BNB", "bitcoin", 60),
    "BSV - BitcoinSV": a("BSV", "bitcoinsv", 236),
    "BTCZ - Bitcoinz": a("BTCZ", "bitcoinz", 177),
    "BTDX - BitCloud": a("BTDX", "bitcloud", 218),
    "BTG - Bitcoin Gold": a("BTG", "bgold", 156),
    "BTX - Bitcore": a("BTX", "bitcore", 160),
    "CCN - Cannacoin": a("CCN", "cannacoin", 19),
    "CESC - Cryptoescudo": a("CESC", "cannacoin", 111),
    "CDN - Canadaecoin": a("CDN", "canadaecoin", 34),
    "CLAM - Clams": a("CLAM", "clam", 23),
    "CLO - Callisto": a("CLO", "bitcoin", 820, {
      segwitAvailable: !1
    }),
    "CLUB - Clubcoin": a("CLUB", "clubcoin", 79),
    "CMP - Compcoin": a("CMP", "compcoin", 71),
    "CPU - CPUchain": a("CPU", "cpuchain", 363),
    "CRAVE - Crave": a("CRAVE", "crave", 186),
    "CRP - CranePay": a("CRP", "cranepay", 2304),
    "CRW - Crown": a("CRW", "crown", 72),
    "CSC - CasinoCoin": a("CSC", "bitcoin", 359),
    "DASH - Dash": a("DASH", "dash", 5),
    "DASH - Dash Testnet": a("DASH", "dashtn", 1),
    "DFC - Defcoin": a("DFC", "defcoin", 1337),
    "DGB - Digibyte": a("DGB", "digibyte", 20),
    "DGC - Digitalcoin": a("DGC", "digitalcoin", 18),
    "DIVI - DIVI": a("DIVI", "divi", 301),
    "DIVI - DIVI Testnet": a("DIVI", "divitestnet", 1),
    "DMD - Diamond": a("DMD", "diamond", 152),
    "DNR - Denarius": a("DNR", "denarius", 116),
    "DOGE - Dogecoin": a("DOGE", "dogecoin", 3),
    "DOGEt - Dogecoin Testnet": a("DOGEt", "dogecointestnet", 1),
    "DXN - DEXON": a("DXN", "bitcoin", 237),
    "ECN - Ecoin": a("ECN", "ecoin", 115),
    "EDRC - Edrcoin": a("EDRC", "edrcoin", 56),
    "EFL - Egulden": a("EFL", "egulden", 78),
    "ELA - Elastos": a("ELA", "elastos", 2305),
    "ELLA - Ellaism": a("ELLA", "bitcoin", 163, {
      segwitAvailable: !1
    }),
    "EMC2 - Einsteinium": a("EMC2", "einsteinium", 41),
    "ERC - Europecoin": a("ERC", "europecoin", 151),
    "EOS - EOSIO": a("EOS", "bitcoin", 194),
    "ERE - EtherCore": a("ERE", "bitcoin", 466, {
      segwitAvailable: !1
    }),
    "ESN - Ethersocial Network": a("ESN", "bitcoin", 31102, {
      segwitAvailable: !1
    }),
    "ETC - Ethereum Classic": a("ETC", "bitcoin", 61, {
      segwitAvailable: !1
    }),
    "ETH - Ethereum": a("ETH", "bitcoin", 60),
    "EWT - EnergyWeb": a("EWT", "bitcoin", 246),
    "EXCL - Exclusivecoin": a("EXCL", "exclusivecoin", 190),
    "EXCC - ExchangeCoin": a("EXCC", "exchangecoin", 0),
    "EXP - Expanse": a("EXP", "bitcoin", 40, {
      segwitAvailable: !1
    }),
    "FIO - Foundation for Interwallet Operability": a("FIO", "bitcoin", 235),
    "FIRO - Firo (Zcoin rebrand)": a("FIRO", "firo", 136),
    "FIX - FIX": a("FIX", "fix", 336),
    "FIX - FIX Testnet": a("FIX", "fixtestnet", 1),
    "FJC - Fujicoin": a("FJC", "fujicoin", 75),
    "FLASH - Flashcoin": a("FLASH", "flashcoin", 120),
    "FRST - Firstcoin": a("FRST", "firstcoin", 167),
    "FTC - Feathercoin": a("FTC", "feathercoin", 8),
    "GAME - GameCredits": a("GAME", "game", 101),
    "GBX - Gobyte": a("GBX", "gobyte", 176),
    "GCR - GCRCoin": a("GCR", "gcr", 79),
    "GRC - Gridcoin": a("GRC", "gridcoin", 84),
    "GRS - Groestlcoin": a("GRS", "groestlcoin", 17),
    "GRS - Groestlcoin Testnet": a("GRS", "groestlcointestnet", 1),
    "HNS - Handshake": a("HNS", "bitcoin", 5353),
    "HUSH - Hush (Legacy)": a("HUSH", "hush", 197),
    "HUSH - Hush3": a("HUSH", "hush3", 197),
    "INSN - Insane": a("INSN", "insane", 68),
    "IOP - Iop": a("IOP", "iop", 66),
    "IOV - Starname": a("IOV", "bitcoin", 234),
    "IXC - Ixcoin": a("IXC", "ixcoin", 86),
    "JBS - Jumbucks": a("JBS", "jumbucks", 26),
    "KMD - Komodo": a("KMD", "komodo", 141, {
      bip49available: !1
    }),
    "KOBO - Kobocoin": a("KOBO", "kobocoin", 196, {
      bip49available: !1
    }),
    "LBC - Library Credits": a("LBC", "lbry", 140),
    "LCC - Litecoincash": a("LCC", "litecoincash", 192),
    "LDCN - Landcoin": a("LDCN", "landcoin", 63),
    "LINX - Linx": a("LINX", "linx", 114),
    "LKR - Lkrcoin": a("LKR", "lkrcoin", 557, {
      segwitAvailable: !1
    }),
    "LTC - Litecoin": a("LTC", "litecoin", 2, t),
    "LTCt - Litecoin Testnet": a("LTCt", "litecointestnet", 1, t),
    "LTZ - LitecoinZ": a("LTZ", "litecoinz", 221),
    "LUNA - Terra": a("LUNA", "bitcoin", 330),
    "LYNX - Lynx": a("LYNX", "lynx", 191),
    "MAZA - Maza": a("MAZA", "maza", 13),
    "MEC - Megacoin": a("MEC", "megacoin", 217),
    "MIX - MIX": a("MIX", "bitcoin", 76, {
      segwitAvailable: !1
    }),
    "MNX - Minexcoin": a("MNX", "minexcoin", 182),
    "MONA - Monacoin": a("MONA", "monacoin", 22),
    "MONK - Monkey Project": a("MONK", "monkeyproject", 214),
    "MOAC - MOAC": a("MOAC", "bitcoin", 314, {
      segwitAvailable: !1
    }),
    "MUSIC - Musicoin": a("MUSIC", "bitcoin", 184, {
      segwitAvailable: !1
    }),
    "NANO - Nano": a("NANO", "dummyNetwork", 165),
    "NAV - Navcoin": a("NAV", "navcoin", 130),
    "NAS - Nebulas": a("NAS", "bitcoin", 2718),
    "NEBL - Neblio": a("NEBL", "neblio", 146),
    "NEOS - Neoscoin": a("NEOS", "neoscoin", 25),
    "NIX - NIX Platform": a("NIX", "nix", 400),
    "NLG - Gulden": a("NLG", "gulden", 87),
    "NMC - Namecoin": a("NMC", "namecoin", 7),
    "NRG - Energi": a("NRG", "energi", 204),
    "NRO - Neurocoin": a("NRO", "neurocoin", 110),
    "NSR - Nushares": a("NSR", "nushares", 11),
    "NYC - Newyorkc": a("NYC", "newyorkc", 179),
    "NVC - Novacoin": a("NVC", "novacoin", 50),
    "OK - Okcash": a("OK", "okcash", 69),
    "OMNI - Omnicore": a("OMNI", "omnicore", 200),
    "ONION - DeepOnion": a("ONION", "deeponion", 305),
    "ONX - Onixcoin": a("ONX", "onixcoin", 174),
    "PART - Particl": a("PART", "particl", 44),
    "PHR - Phore": a("PHR", "phore", 444),
    "PINK - Pinkcoin": a("PINK", "pinkcoin", 117),
    "PIRL - Pirl": a("PIRL", "bitcoin", 164, {
      segwitAvailable: !1
    }),
    "PIVX - PIVX": a("PIVX", "pivx", 119),
    "PIVX - PIVX Testnet": a("PIVX", "pivxtestnet", 1),
    "POA - Poa": a("POA", "bitcoin", 178, {
      segwitAvailable: !1
    }),
    "POSW - POSWcoin": a("POSW", "poswcoin", 47),
    "POT - Potcoin": a("POT", "potcoin", 81),
    "PPC - Peercoin": a("PPC", "peercoin", 6),
    "PRJ - ProjectCoin": a("PRJ", "projectcoin", 533),
    "PSB - Pesobit": a("PSB", "pesobit", 62),
    "PUT - Putincoin": a("PUT", "putincoin", 122),
    "RPD - Rapids": a("RPD", "rapids", 320),
    "RVN - Ravencoin": a("RVN", "ravencoin", 175),
    "R-BTC - RSK": a("R", "rsk", 137),
    "tR-BTC - RSK Testnet": a("tR", "rsktestnet", 37310),
    "RBY - Rubycoin": a("RBY", "rubycoin", 16),
    "RDD - Reddcoin": a("RDD", "reddcoin", 4),
    "RITO - Ritocoin": a("RITO", "ritocoin", 19169),
    "RUNE - THORChain": a("RUNE", "bitcoin", 931),
    "RVR - RevolutionVR": a("RVR", "revolutionvr", 129),
    "SAFE - Safecoin": a("SAFE", "safecoin", 19165),
    "SCRIBE - Scribe": a("SCRIBE", "scribe", 545),
    "SLS - Salus": a("SLS", "salus", 63),
    "SDC - ShadowCash": a("SDC", "shadow", 35),
    "SDC - ShadowCash Testnet": a("SDC", "shadowtn", 1),
    "SLM - Slimcoin": a("SLM", "slimcoin", 63),
    "SLM - Slimcoin Testnet": a("SLM", "slimcointn", 111),
    "SLP - Simple Ledger Protocol": a("SLP", "bitcoin", 245, c),
    "SLR - Solarcoin": a("SLR", "solarcoin", 58),
    "SMLY - Smileycoin": a("SMLY", "smileycoin", 59),
    "STASH - Stash": a("STASH", "stash", 49344),
    "STASH - Stash Testnet": a("STASH", "stashtn", 51966),
    "STRAT - Stratis": a("STRAT", "stratis", 105),
    "SUGAR - Sugarchain": a("SUGAR", "sugarchain", 408),
    "TUGAR - Sugarchain Testnet": a("TUGAR", "sugarchaintestnet", 408),
    "SWTC - Jingtum": a("SWTC", "bitcoin", 315),
    "TSTRAT - Stratis Testnet": a("TSTRAT", "stratistest", 105),
    "SYS - Syscoin": a("SYS", "syscoin", 57),
    "THC - Hempcoin": a("THC", "hempcoin", 113),
    "THT - Thought": a("THT", "thought", 1618),
    "TOA - Toa": a("TOA", "toa", 159),
    "TRX - Tron": a("TRX", "bitcoin", 195),
    "TWINS - TWINS Testnet": a("TWINS", "twinstestnet", 1),
    "USC - Ultimatesecurecash": a("USC", "ultimatesecurecash", 112),
    "USNBT - NuBits": a("USNBT", "nubits", 12),
    "UNO - Unobtanium": a("UNO", "unobtanium", 92),
    "VASH - Vpncoin": a("VASH", "vpncoin", 33),
    "VET - VeChain": a("VET", "bitcoin", 818),
    "VIA - Viacoin": a("VIA", "viacoin", 14),
    "VIA - Viacoin Testnet": a("VIA", "viacointestnet", 1),
    "VIVO - Vivo": a("VIVO", "vivo", 166),
    "VTC - Vertcoin": a("VTC", "vertcoin", 28),
    "WGR - Wagerr": a("WGR", "wagerr", 7825266),
    "WC - Wincoin": a("WC", "wincoin", 181),
    "XAX - Artax": a("XAX", "artax", 219),
    "XBC - Bitcoinplus": a("XBC", "bitcoinplus", 65),
    "XLM - Stellar": a("XLM", "dummyNetwork", 148),
    "XMY - Myriadcoin": a("XMY", "myriadcoin", 90),
    "XRP - Ripple": a("XRP", "bitcoin", 144),
    "XVC - Vcash": a("XVC", "vcash", 127),
    "XVG - Verge": a("XVG", "verge", 77),
    "XUEZ - Xuez": a("XUEZ", "xuez", 225, {
      segwitAvailable: !1
    }),
    "XWCC - Whitecoin Classic": a("XWCC", "whitecoin", 155),
    "XZC - Zcoin (rebranded to Firo)": a("XZC", "zcoin", 136),
    "ZBC - ZooBlockchain": a("ZBC", "zoobc", 883),
    "ZCL - Zclassic": a("ZCL", "zclassic", 147),
    "ZEC - Zcash": a("ZEC", "zcash", 133),
    "ZEN - Horizen": a("ZEN", "zencash", 121),
    "XWC - Whitecoin": a("XWC", "bitcoin", 559)
  };
Object.setPrototypeOf(g, null);
const d = /*#__PURE__*/function () {
  var _ref = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (e) {
    const n = g[e];
    if (void 0 === n) throw new Error(`coin: ${e} is not define.`);
    return n;
  });
  return function d(_x) {
    return _ref.apply(this, arguments);
  };
}();
var S = Object.freeze({
  __proto__: null,
  isEthereum: e => "ETH - Ethereum" == e || "ETC - Ethereum Classic" == e || "EWT - EnergyWeb" == e || "PIRL - Pirl" == e || "MIX - MIX" == e || "MOAC - MOAC" == e || "MUSIC - Musicoin" == e || "POA - Poa" == e || "EXP - Expanse" == e || "CLO - Callisto" == e || "DXN - DEXON" == e || "ELLA - Ellaism" == e || "ESN - Ethersocial Network" == e || "VET - VeChain" == e || "ERE - EtherCore" == e || "BSC - Binance Smart Chain" == e
});
var r = Object.freeze({
  __proto__: null,
  isRsk: e => "R-BTC - RSK" == e || "tR-BTC - RSK Testnet" == e
});
var C = Object.freeze({
  __proto__: null,
  isTron: e => "TRX - Tron" == e
});


/***/ }),

/***/ 30274:
/*!******************************************************************!*\
  !*** ./apps/bfswap/src/assets/wallet-util/networks-0de0aba6.mjs ***!
  \******************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   b: () => (/* binding */ e),
/* harmony export */   r: () => (/* binding */ i),
/* harmony export */   t: () => (/* binding */ s)
/* harmony export */ });
const e = {
    messagePrefix: "Bitcoin Signed Message:\n",
    bech32: "bc",
    bip32: {
      public: 76067358,
      private: 76066276
    },
    pubKeyHash: 0,
    scriptHash: 5,
    wif: 128
  },
  i = {
    messagePrefix: "Bitcoin Signed Message:\n",
    bech32: "bcrt",
    bip32: {
      public: 70617039,
      private: 70615956
    },
    pubKeyHash: 111,
    scriptHash: 196,
    wif: 239
  },
  s = {
    messagePrefix: "Bitcoin Signed Message:\n",
    bech32: "tb",
    bip32: {
      public: 70617039,
      private: 70615956
    },
    pubKeyHash: 111,
    scriptHash: 196,
    wif: 239
  };


/***/ })

}]);
//# sourceMappingURL=apps_bfswap_src_assets_wallet-util_index-b6e920cf_mjs.js.map