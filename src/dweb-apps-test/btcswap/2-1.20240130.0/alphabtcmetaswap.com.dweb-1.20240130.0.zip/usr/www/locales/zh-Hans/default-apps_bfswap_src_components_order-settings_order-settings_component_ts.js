"use strict";
(self["webpackChunkbfswap"] = self["webpackChunkbfswap"] || []).push([["default-apps_bfswap_src_components_order-settings_order-settings_component_ts"],{

/***/ 67877:
/*!*******************************************************************************!*\
  !*** ./apps/bfswap/src/components/order-settings/order-settings.component.ts ***!
  \*******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   OrderSettingsPage: () => (/* binding */ OrderSettingsPage),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 52542);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 61039);
/* harmony import */ var _bnqkl_util_web_extends_promise__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @bnqkl/util-web/extends-promise */ 87778);
/* harmony import */ var _modules_page_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ~modules/page.module */ 16381);
/* harmony import */ var _services_transaction_settings_transaction_settings_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ~services/transaction-settings/transaction-settings.service */ 80348);
/* harmony import */ var _libs_bnf_components_ripple_button_ripple_button_directive__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../../../libs/bnf/components/ripple-button/ripple-button.directive */ 16505);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/common */ 6729);
/* harmony import */ var _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../../../libs/bnf/modules/page/common-page/common-page.component */ 62052);
/* harmony import */ var _icon_icon_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../icon/icon.component */ 18840);

var _class;









const _c8 = a0 => ({
  "mr-3": a0
});
function OrderSettingsPage_ng_container_3_button_6_Template(rf, ctx) {
  if (rf & 1) {
    const _r8 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](0, "button", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("click", function OrderSettingsPage_ng_container_3_button_6_Template_button_click_0_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵrestoreView"](_r8);
      const slippage_r4 = restoredCtx.$implicit;
      const i_r6 = restoredCtx.index;
      const ctx_r7 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵresetView"](ctx_r7.service.selectSlippage(slippage_r4, i_r6));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const slippage_r4 = ctx.$implicit;
    const isLast_r5 = ctx.last;
    const i_r6 = ctx.index;
    const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵclassMap"](i_r6 === ctx_r3.service.tempSlippageIndex ? "text-white bg-primary" : "text-base-500 bg-base-400");
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpureFunction1"](4, _c8, !isLast_r5));
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtextInterpolate1"](" ", slippage_r4.label, " ");
  }
}
function OrderSettingsPage_ng_container_3_Template(rf, ctx) {
  if (rf & 1) {
    const _r10 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](1, "div", 12)(2, "span", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵi18n"](3, 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](4, "bs-icon", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("click", function OrderSettingsPage_ng_container_3_Template_bs_icon_click_4_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵrestoreView"](_r10);
      const ctx_r9 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵresetView"](ctx_r9.showSlippageTip());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](5, "div", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtemplate"](6, OrderSettingsPage_ng_container_3_button_6_Template, 2, 6, "button", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("ngForOf", ctx_r0.service.slippages);
  }
}
function OrderSettingsPage_button_9_Template(rf, ctx) {
  if (rf & 1) {
    const _r15 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](0, "button", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("click", function OrderSettingsPage_button_9_Template_button_click_0_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵrestoreView"](_r15);
      const time_r11 = restoredCtx.$implicit;
      const i_r13 = restoredCtx.index;
      const ctx_r14 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵresetView"](ctx_r14.service.selectEndTime(time_r11, i_r13));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const time_r11 = ctx.$implicit;
    const isLast_r12 = ctx.last;
    const i_r13 = ctx.index;
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵclassMap"](i_r13 === ctx_r1.service.tempEndTimesIndex ? "text-white bg-primary" : "text-base-500 bg-base-400");
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpureFunction1"](4, _c8, !isLast_r12));
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtextInterpolate1"](" ", time_r11.label, " ");
  }
}
function OrderSettingsPage_ng_container_10_button_6_Template(rf, ctx) {
  if (rf & 1) {
    const _r21 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](0, "button", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("click", function OrderSettingsPage_ng_container_10_button_6_Template_button_click_0_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵrestoreView"](_r21);
      const i_r19 = restoredCtx.index;
      const ctx_r20 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵresetView"](ctx_r20.service.selectAddLiquidityRatio(i_r19));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const time_r17 = ctx.$implicit;
    const isLast_r18 = ctx.last;
    const i_r19 = ctx.index;
    const ctx_r16 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵclassMap"](i_r19 === ctx_r16.service.tempAddRatioIndex ? "text-white bg-primary" : "text-base-500 bg-base-400");
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpureFunction1"](4, _c8, !isLast_r18));
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtextInterpolate1"](" ", time_r17.label, " ");
  }
}
function OrderSettingsPage_ng_container_10_Template(rf, ctx) {
  if (rf & 1) {
    const _r23 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](1, "div", 4)(2, "span", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵi18n"](3, 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](4, "bs-icon", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("click", function OrderSettingsPage_ng_container_10_Template_bs_icon_click_4_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵrestoreView"](_r23);
      const ctx_r22 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵresetView"](ctx_r22.showAddLiquidityTip());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](5, "div", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtemplate"](6, OrderSettingsPage_ng_container_10_button_6_Template, 2, 6, "button", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("ngForOf", ctx_r2.service.addLiquidityRatio);
  }
}
/**
 * 设置滑点容忍度的页面
 */
class OrderSettingsPage extends _modules_page_module__WEBPACK_IMPORTED_MODULE_2__.CommonPageBase {
  constructor() {
    super(...arguments);
    /** 是否展示滑点选项 */
    this.showSlippages = true;
    /** 是否展示增流比例 */
    this.showAddLiquidityRatio = true;
    /** 服务 */
    this.service = (0,_angular_core__WEBPACK_IMPORTED_MODULE_7__.inject)(_services_transaction_settings_transaction_settings_service__WEBPACK_IMPORTED_MODULE_3__.TransactionSettingsService);
  }
  /** 关闭事件 */
  handleClose() {
    var _this = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this.nav.back();
      yield (0,_bnqkl_util_web_extends_promise__WEBPACK_IMPORTED_MODULE_1__.sleep)(400);
      _this.service.close();
    })();
  }
  /** 确认事件 */
  handleConfirm() {
    this.service.confirm();
    this.nav.back();
  }
  /** 展示滑点 */
  showSlippageTip() {
    var _this2 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      yield _this2.alert({
        headerTitle: `滑点容忍度`,
        bodyMessage: '若价格变动幅度超过百分比，交易将退回。',
        buttonText: '好的'
      });
    })();
  }
  /** 添加流动性提示 */
  showAddLiquidityTip() {
    var _this3 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      yield _this3.alert({
        headerTitle: `固定增流规则`,
        segmentBodyMessage: ['【固定增流】：用户兑换成功时，将向交易池中增加一定比例流动性，并获得相关合约池权益，同时此增流部分将锁定一个月后方可移除。', '【固定增流比例】：当A兑换U，固定增流5%时，将使用5%A以及对应量的U用于增加流动性，所需的U从兑得量中扣除。'],
        buttonText: '好的',
        bodyAlign: 'left'
      });
    })();
  }
  /** 展示结束时间 */
  showEndTimeTip() {
    var _this4 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      yield _this4.alert({
        headerTitle: `截至时间`,
        bodyMessage: '若交易超时未确认，交易将退回。',
        buttonText: '好的'
      });
    })();
  }
}
_class = OrderSettingsPage;
_class.ɵfac = /*@__PURE__*/(() => {
  let ɵOrderSettingsPage_BaseFactory;
  return function OrderSettingsPage_Factory(t) {
    return (ɵOrderSettingsPage_BaseFactory || (ɵOrderSettingsPage_BaseFactory = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵgetInheritedFactory"](_class)))(t || _class);
  };
})();
_class.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdefineComponent"]({
  type: _class,
  selectors: [["bs-order-settings-page"]],
  inputs: {
    showSlippages: "showSlippages",
    showAddLiquidityRatio: "showAddLiquidityRatio"
  },
  standalone: true,
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵInheritDefinitionFeature"], _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵStandaloneFeature"]],
  decls: 13,
  vars: 10,
  consts: () => {
    let i18n_0;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_TRANSACTION_SETTINGS$$APPS_BFSWAP_SRC_COMPONENTS_ORDER_SETTINGS_ORDER_SETTINGS_COMPONENT_TS_1 = goog.getMsg("Advanced Settings");
      i18n_0 = MSG_EXTERNAL_TRANSACTION_SETTINGS$$APPS_BFSWAP_SRC_COMPONENTS_ORDER_SETTINGS_ORDER_SETTINGS_COMPONENT_TS_1;
    } else {
      i18n_0 = "\u9AD8\u7EA7\u8BBE\u7F6E";
    }
    let i18n_2;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_DEADLINE$$APPS_BFSWAP_SRC_COMPONENTS_ORDER_SETTINGS_ORDER_SETTINGS_COMPONENT_TS_3 = goog.getMsg("Deadline");
      i18n_2 = MSG_EXTERNAL_DEADLINE$$APPS_BFSWAP_SRC_COMPONENTS_ORDER_SETTINGS_ORDER_SETTINGS_COMPONENT_TS_3;
    } else {
      i18n_2 = "\u622A\u6B62\u65F6\u95F4";
    }
    let i18n_4;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_CONFIRM$$APPS_BFSWAP_SRC_COMPONENTS_ORDER_SETTINGS_ORDER_SETTINGS_COMPONENT_TS_5 = goog.getMsg(" Confirm ");
      i18n_4 = MSG_EXTERNAL_CONFIRM$$APPS_BFSWAP_SRC_COMPONENTS_ORDER_SETTINGS_ORDER_SETTINGS_COMPONENT_TS_5;
    } else {
      i18n_4 = "\u786E\u8BA4";
    }
    let i18n_6;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_SLIPPAGE_TOLERANCE$$APPS_BFSWAP_SRC_COMPONENTS_ORDER_SETTINGS_ORDER_SETTINGS_COMPONENT_TS__7 = goog.getMsg("Slippage Tolerance");
      i18n_6 = MSG_EXTERNAL_SLIPPAGE_TOLERANCE$$APPS_BFSWAP_SRC_COMPONENTS_ORDER_SETTINGS_ORDER_SETTINGS_COMPONENT_TS__7;
    } else {
      i18n_6 = "\u6ED1\u70B9\u5BB9\u5FCD\u5EA6";
    }
    let i18n_9;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_4831345542927439531$$APPS_BFSWAP_SRC_COMPONENTS_ORDER_SETTINGS_ORDER_SETTINGS_COMPONENT_TS__10 = goog.getMsg("\u56FA\u5B9A\u589E\u6D41\u89C4\u5219");
      i18n_9 = MSG_EXTERNAL_4831345542927439531$$APPS_BFSWAP_SRC_COMPONENTS_ORDER_SETTINGS_ORDER_SETTINGS_COMPONENT_TS__10;
    } else {
      i18n_9 = "\u56FA\u5B9A\u589E\u6D41\u89C4\u5219";
    }
    return [["headerTitle", i18n_0, 3, "hideBackButton", "titleClass", "headerClass", "contentBackground", "contentClass", "contentSafeArea"], ["endMenu", "", "bnRippleButton", "", 1, "icon-7", 3, "mode", "click"], ["name", "icon-popup-close"], [4, "ngIf"], [1, "my-4", "flex", "items-center"], [1, "text-info", "font-semibold"], i18n_2, ["name", "icon-info", 1, "ml-1", "text-base", 3, "click"], [1, "mb-4", "flex"], ["bnRippleButton", "", "class", "rounded-8 flex h-8 flex-1 items-center justify-center", 3, "ngClass", "class", "click", 4, "ngFor", "ngForOf"], ["bnRippleButton", "", 1, "bg-primary", "rounded-12", "mb-6", "mt-12", "flex", "h-12", "w-full", "items-center", "justify-center", "text-lg", "font-extrabold", "text-white", 3, "click"], i18n_4, [1, "mt-4", "flex", "items-center"], [1, "text-info", "text-sm", "font-semibold"], i18n_6, [1, "mt-4", "flex"], ["bnRippleButton", "", "class", "rounded-8 flex h-8 flex-1 items-center justify-center ", 3, "ngClass", "class", "click", 4, "ngFor", "ngForOf"], ["bnRippleButton", "", 1, "rounded-8", "flex", "h-8", "flex-1", "items-center", "justify-center", 3, "ngClass", "click"], i18n_9, [1, "flex"]];
  },
  template: function OrderSettingsPage_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](0, "common-page", 0)(1, "button", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("click", function OrderSettingsPage_Template_button_click_1_listener() {
        return ctx.handleClose();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](2, "bs-icon", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtemplate"](3, OrderSettingsPage_ng_container_3_Template, 7, 1, "ng-container", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](4, "div", 4)(5, "span", 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵi18n"](6, 6);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](7, "bs-icon", 7);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("click", function OrderSettingsPage_Template_bs_icon_click_7_listener() {
        return ctx.showEndTimeTip();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](8, "div", 8);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtemplate"](9, OrderSettingsPage_button_9_Template, 2, 6, "button", 9);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtemplate"](10, OrderSettingsPage_ng_container_10_Template, 7, 1, "ng-container", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](11, "button", 10);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("click", function OrderSettingsPage_Template_button_click_11_listener() {
        return ctx.handleConfirm();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵi18n"](12, 11);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]()();
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("hideBackButton", true)("titleClass", "!text-title-10")("headerClass", "pt-2.5 text-lg font-extrabold")("contentBackground", "white")("contentClass", "px-4")("contentSafeArea", true);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("mode", "icon");
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("ngIf", ctx.showSlippages);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](6);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("ngForOf", ctx.service.endTimes);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("ngIf", ctx.showAddLiquidityRatio);
    }
  },
  dependencies: [_modules_page_module__WEBPACK_IMPORTED_MODULE_2__.CommonPageModule, _libs_bnf_components_ripple_button_ripple_button_directive__WEBPACK_IMPORTED_MODULE_4__.RippleButtonDirective, _angular_common__WEBPACK_IMPORTED_MODULE_8__.NgClass, _angular_common__WEBPACK_IMPORTED_MODULE_8__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_8__.NgIf, _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_5__.CommonPageComponent, _icon_icon_component__WEBPACK_IMPORTED_MODULE_6__.IconComponent],
  styles: ["/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsInNvdXJjZVJvb3QiOiIifQ== */"],
  changeDetection: 0
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (OrderSettingsPage);

/***/ }),

/***/ 80348:
/*!***************************************************************************************!*\
  !*** ./apps/bfswap/src/services/transaction-settings/transaction-settings.service.ts ***!
  \***************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   TransactionSettingsService: () => (/* binding */ TransactionSettingsService)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 61039);
var _class;

/** 高级设置服务 */
class TransactionSettingsService {
  constructor() {
    /** 默认选中的滑点 */
    this.defaultSlippageIndex = 2;
    /** 临时 */
    this.tempSlippageIndex = 2;
    /** 默认选中的过期事件 */
    this.defaultEndTimesIndex = 2;
    /** 临时 */
    this.tempEndTimesIndex = 2;
    /** 默认选中的增流比例 */
    this.defaultAddRatioIndex = 0;
    /** 临时 */
    this.tempAddRatioIndex = 0;
    /** 滑点容忍度 */
    this.slippages = [{
      label: '0.5%',
      value: '0.005'
    }, {
      label: '1%',
      value: '0.01'
    }, {
      label: '5%',
      value: '0.05'
    }, {
      label: '10%',
      value: '0.1'
    }];
    /** 过期时间 */
    this.endTimes = [{
      label: '5分钟',
      value: 5 * 60 * 1000
    }, {
      label: '15分钟',
      value: 15 * 60 * 1000
    }, {
      label: '30分钟',
      value: 30 * 60 * 1000
    }, {
      label: '45分钟',
      value: 45 * 60 * 1000
    }];
    /** 固定增流比例 */
    this.addLiquidityRatio = [{
      label: '5%',
      value: '0.05'
    }, {
      label: '7%',
      value: '0.07'
    }, {
      label: '9%',
      value: '0.09'
    }, {
      label: '12%',
      value: '0.12'
    }];
  }
  /** 选择滑点 */
  selectSlippage(slippage, index) {
    this.tempSlippageIndex = index;
  }
  /** 选择截至时间 */
  selectEndTime(time, index) {
    this.tempEndTimesIndex = index;
  }
  /** 选择增流比例 */
  selectAddLiquidityRatio(index) {
    this.tempAddRatioIndex = index;
  }
  /** 获取过期时间label */
  getEndTimeLabelByValue(value) {
    return Math.round(value / 1000 / 60);
  }
  /** 获取滑点的label */
  getSlippageLabelByValue(value) {
    return parseFloat(value) * 100;
  }
  /** 获取滑点的label */
  getIncreasedLiquidityRatioByValue(value) {
    return Math.round(parseFloat(value) * 100);
  }
  /** 获取增流比例的label */
  getAddRaioLabelByValue(value) {
    return Number(value) * 100 + '%';
  }
  /** 重置 */
  reset() {
    this.tempEndTimesIndex = 2;
    this.tempSlippageIndex = 2;
    this.tempAddRatioIndex = 0;
    this.defaultEndTimesIndex = 2;
    this.defaultSlippageIndex = 2;
    this.defaultAddRatioIndex = 0;
  }
  /** 关闭 */
  close() {
    this.tempEndTimesIndex = this.defaultEndTimesIndex;
    this.tempSlippageIndex = this.defaultSlippageIndex;
    this.tempAddRatioIndex = this.defaultAddRatioIndex;
  }
  /** 确认 */
  confirm() {
    this.defaultEndTimesIndex = this.tempEndTimesIndex;
    this.defaultSlippageIndex = this.tempSlippageIndex;
    this.defaultAddRatioIndex = this.tempAddRatioIndex;
  }
  /** 获取选中的值 */
  getSelectedValue() {
    const expirationTime = this.endTimes[this.defaultEndTimesIndex];
    const slippageTolerance = this.slippages[this.defaultSlippageIndex];
    const addLiquidityRatio = this.addLiquidityRatio[this.defaultAddRatioIndex];
    return {
      expirationTime,
      slippageTolerance,
      addLiquidityRatio
    };
  }
}
_class = TransactionSettingsService;
_class.ɵfac = function TransactionSettingsService_Factory(t) {
  return new (t || _class)();
};
_class.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjectable"]({
  token: _class,
  factory: _class.ɵfac,
  providedIn: 'root'
});

/***/ })

}]);
//# sourceMappingURL=default-apps_bfswap_src_components_order-settings_order-settings_component_ts.js.map