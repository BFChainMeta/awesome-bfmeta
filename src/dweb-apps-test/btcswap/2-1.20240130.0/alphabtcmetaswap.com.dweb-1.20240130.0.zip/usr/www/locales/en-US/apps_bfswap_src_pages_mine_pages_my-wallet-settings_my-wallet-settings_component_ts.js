"use strict";
(self["webpackChunkbfswap"] = self["webpackChunkbfswap"] || []).push([["apps_bfswap_src_pages_mine_pages_my-wallet-settings_my-wallet-settings_component_ts"],{

/***/ 85080:
/*!*********************************************************************************************!*\
  !*** ./apps/bfswap/src/pages/mine/pages/my-wallet-settings/my-wallet-settings.component.ts ***!
  \*********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   MyWalletSettingsPage: () => (/* binding */ MyWalletSettingsPage),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 52542);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! tslib */ 90505);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/common */ 6729);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/core */ 61039);
/* harmony import */ var _modules_page_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ~modules/page.module */ 16381);
/* harmony import */ var _components_connect_wallet_panel_connect_wallet_penel_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../components/connect-wallet-panel/connect-wallet-penel.component */ 43551);
/* harmony import */ var _bnqkl_util_web_extends_promise__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @bnqkl/util-web/extends-promise */ 87778);
/* harmony import */ var _services_wallet_wallet_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ~services/wallet/wallet.service */ 54275);
/* harmony import */ var _bnqkl_framework_plugins__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @bnqkl/framework/plugins */ 43990);
/* harmony import */ var _components_connect_wallet_panel_connect_wallet_panel_type__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../../components/connect-wallet-panel/connect-wallet-panel.type */ 9218);
/* harmony import */ var _services_wallet_wallet_config__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ~services/wallet/wallet.config */ 57839);
/* harmony import */ var _libs_bnf_modules_bottom_sheet_components_bottom_sheet_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../../../../../libs/bnf/modules/bottom-sheet/components/bottom-sheet.component */ 94072);
/* harmony import */ var _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../../../../../../libs/bnf/modules/page/common-page/common-page.component */ 62052);
/* harmony import */ var _components_icon_icon_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../../../components/icon/icon.component */ 18840);

var _class;















function MyWalletSettingsPage_ng_container_10_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](1, "div", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](3, "div", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const addressInfo_r2 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](addressInfo_r2.chainName);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](addressInfo_r2.address);
  }
}
function MyWalletSettingsPage_ng_template_16_Template(rf, ctx) {
  if (rf & 1) {
    const _r4 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "bs-connect-wallet-panel-page", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵlistener"]("returnValue$", function MyWalletSettingsPage_ng_template_16_Template_bs_connect_wallet_panel_page_returnValue__0_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵrestoreView"](_r4);
      const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵresetView"](ctx_r3.onConnectWallet($event));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("connectType", ctx_r1.selectWalletSheet.conncetType)("presetWallets", ctx_r1.selectWalletSheet.presetWallets);
  }
}
/** 钱包配置页 */
class MyWalletSettingsPage extends _modules_page_module__WEBPACK_IMPORTED_MODULE_1__.CommonPageBase {
  constructor() {
    var _this$walletService$c;
    super(...arguments);
    this.walletService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_11__.inject)(_services_wallet_wallet_service__WEBPACK_IMPORTED_MODULE_4__.WalletService);
    /** 钱包选择器的数据 */
    this.selectWalletSheet = {
      is_open: false,
      conncetType: _components_connect_wallet_panel_connect_wallet_panel_type__WEBPACK_IMPORTED_MODULE_6__.CONNECT_TYPE.CONNECT_WALLET,
      presetWallets: []
    };
    /** 钱包授权地址 */
    this.walletAddressList = Array.from(((_this$walletService$c = this.walletService.connectedWallet) === null || _this$walletService$c === void 0 ? void 0 : _this$walletService$c.assetInfoListMap.values()) || new Map().values());
    /** 已连接钱包 */
    this.currentWallet = this.walletService.connectedWallet;
  }
  /** 断开钱包 */
  disconnectWallet() {
    var _this = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const result = yield _this.confirm({
        bodyMessage: "Do you want to exit the current wallet account?",
        footerTheme: 'normal'
      });
      _this._templateDialogService;
      yield (0,_bnqkl_util_web_extends_promise__WEBPACK_IMPORTED_MODULE_3__.sleep)(250);
      if (result) {
        const result = yield _this.walletService.disconnectWallet();
        if (result) {
          _this.console.info('disconnect wallet success');
          _this._returnRootPage();
          _bnqkl_framework_plugins__WEBPACK_IMPORTED_MODULE_5__.Toast.show(`已断开连接`);
        } else {
          _bnqkl_framework_plugins__WEBPACK_IMPORTED_MODULE_5__.Toast.show(`断开失败`);
        }
      }
    })();
  }
  get walletIcon() {
    if (this.currentWallet) {
      const wallet = _services_wallet_wallet_config__WEBPACK_IMPORTED_MODULE_7__.PRESETS_WALLET_CONFIG.find(item => {
        var _this$currentWallet;
        return item.id === ((_this$currentWallet = this.currentWallet) === null || _this$currentWallet === void 0 ? void 0 : _this$currentWallet.walletId);
      });
      if (wallet) {
        return wallet.iconName;
      }
    }
    return 'icon-wallet-user';
  }
  /** 打开钱包连接选择弹窗 */
  openSwapWalletSheet() {
    var _this2 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const {
        selectWalletSheet
      } = _this2;
      if (selectWalletSheet.is_open) {
        return;
      }
      _this2.selectWalletSheet.presetWallets = yield _this2.walletService.getPresetWallet();
      selectWalletSheet.is_open = true;
    })();
  }
  /** 连接钱包事件 */
  onConnectWallet(data) {
    var _this3 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      if (data.walletName) {
        _this3.console.info('switch to wallet', data);
        _this3._returnRootPage();
      }
    })();
  }
  /** 跳转到root页面 */
  _returnRootPage() {
    // 取消所有订阅，修复setroot无法触发destroy的bug
    Array.from(this.walletService.allSubscribes.values()).forEach(subscribes => {
      subscribes.forEach(sub => {
        sub.unsubscribe();
      });
    });
    this.walletService.allSubscribes = new Map();
    // this.nav.routeBack('tabs');
    this.nav.setPageRoot('tabs');
  }
}
_class = MyWalletSettingsPage;
_class.ɵfac = /*@__PURE__*/(() => {
  let ɵMyWalletSettingsPage_BaseFactory;
  return function MyWalletSettingsPage_Factory(t) {
    return (ɵMyWalletSettingsPage_BaseFactory || (ɵMyWalletSettingsPage_BaseFactory = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵgetInheritedFactory"](_class)))(t || _class);
  };
})();
_class.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdefineComponent"]({
  type: _class,
  selectors: [["bs-mine-my-wallet-settings"]],
  standalone: true,
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵInheritDefinitionFeature"], _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵStandaloneFeature"]],
  decls: 17,
  vars: 4,
  consts: () => {
    let i18n_0;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_CURRENT_CONNECTED_WALLET$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_WALLET_SETTINGS_MY_WALLET_SETTINGS_COMPONENT_TS_1 = goog.getMsg(" Current connected wallet:{$interpolation} ", {
        "interpolation": "\uFFFD0\uFFFD"
      }, {
        original_code: {
          "interpolation": "{{ currentWallet?.walletName }}"
        }
      });
      i18n_0 = MSG_EXTERNAL_CURRENT_CONNECTED_WALLET$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_WALLET_SETTINGS_MY_WALLET_SETTINGS_COMPONENT_TS_1;
    } else {
      i18n_0 = " Current connected wallet:" + "\uFFFD0\uFFFD" + " ";
    }
    let i18n_2;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_WALLET_ADDRESSES$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_WALLET_SETTINGS_MY_WALLET_SETTINGS_COMPONENT_TS_3 = goog.getMsg("Linked wallet address:");
      i18n_2 = MSG_EXTERNAL_WALLET_ADDRESSES$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_WALLET_SETTINGS_MY_WALLET_SETTINGS_COMPONENT_TS_3;
    } else {
      i18n_2 = "Linked wallet address:";
    }
    let i18n_4;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_SWITCH_WALLET$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_WALLET_SETTINGS_MY_WALLET_SETTINGS_COMPONENT_TS_5 = goog.getMsg(" Reconnect ");
      i18n_4 = MSG_EXTERNAL_SWITCH_WALLET$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_WALLET_SETTINGS_MY_WALLET_SETTINGS_COMPONENT_TS_5;
    } else {
      i18n_4 = " Reconnect ";
    }
    let i18n_6;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_DISCONNECT_WALLET$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_WALLET_SETTINGS_MY_WALLET_SETTINGS_COMPONENT_TS_7 = goog.getMsg(" Exit wallet ");
      i18n_6 = MSG_EXTERNAL_DISCONNECT_WALLET$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_WALLET_SETTINGS_MY_WALLET_SETTINGS_COMPONENT_TS_7;
    } else {
      i18n_6 = " Exit wallet ";
    }
    return [[1, "pt-15", "text-base-content-100", "flex", "flex-col", "items-center", "px-4"], [1, "text-[6.5rem]", 3, "name"], [1, "mb-6", "mt-4"], i18n_0, [1, "bg-base-300", "rounded-2", "w-full", "p-4"], [1, "mb-3", "inline-block"], i18n_2, [1, "bg-base-200", "h-[1px]"], [1, "_content-h", "overflow-scroll"], [4, "ngFor", "ngForOf"], [1, "duibs-btn", "duibs-btn-primary", "w-cqw-92", "mx-auto", "mt-8", "block", "rounded-full", "text-white", 3, "click"], i18n_4, [1, "text-gray-10", "duibs-btn", "duibs-btn-ghost", "w-cqw-92", "border-1", "border-base-200", "mx-auto", "mt-6", "block", "rounded-full", "border-solid", 3, "click"], i18n_6, [3, "isOpen", "isOpenChange"], [1, "mt-4", "text-xs", "font-semibold"], [1, "mt-2", "text-xs", "font-semibold"], [3, "connectType", "presetWallets", "returnValue$"]];
  },
  template: function MyWalletSettingsPage_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "common-page")(1, "div", 0);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](2, "bs-icon", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](3, "h3", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵi18n"](4, 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](5, "div", 4)(6, "span", 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵi18n"](7, 6);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](8, "div", 7);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](9, "div", 8);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](10, MyWalletSettingsPage_ng_container_10_Template, 5, 2, "ng-container", 9);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()()();
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](11, "button", 10);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵlistener"]("click", function MyWalletSettingsPage_Template_button_click_11_listener() {
        return ctx.openSwapWalletSheet();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵi18n"](12, 11);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](13, "button", 12);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵlistener"]("click", function MyWalletSettingsPage_Template_button_click_13_listener() {
        return ctx.disconnectWallet();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵi18n"](14, 13);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](15, "common-bottom-sheet", 14);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵlistener"]("isOpenChange", function MyWalletSettingsPage_Template_common_bottom_sheet_isOpenChange_15_listener($event) {
        return ctx.selectWalletSheet.is_open = $event;
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](16, MyWalletSettingsPage_ng_template_16_Template, 1, 2, "ng-template");
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("name", ctx.walletIcon);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵi18nExp"](ctx.currentWallet == null ? null : ctx.currentWallet.walletName);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵi18nApply"](4);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](6);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngForOf", ctx.walletAddressList);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](5);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("isOpen", ctx.selectWalletSheet.is_open);
    }
  },
  dependencies: [_modules_page_module__WEBPACK_IMPORTED_MODULE_1__.CommonPageModule, _libs_bnf_modules_bottom_sheet_components_bottom_sheet_component__WEBPACK_IMPORTED_MODULE_8__.BottomSheetComponent, _angular_common__WEBPACK_IMPORTED_MODULE_12__.NgForOf, _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_9__.CommonPageComponent, _components_icon_icon_component__WEBPACK_IMPORTED_MODULE_10__.IconComponent, _angular_common__WEBPACK_IMPORTED_MODULE_12__.CommonModule, _components_connect_wallet_panel_connect_wallet_penel_component__WEBPACK_IMPORTED_MODULE_2__["default"]],
  styles: ["[_nghost-%COMP%]   ._content-h[_ngcontent-%COMP%] {\n  height: calc(100vh - 36.5rem);\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL2FwcHMvYmZzd2FwL3NyYy9wYWdlcy9taW5lL3BhZ2VzL215LXdhbGxldC1zZXR0aW5ncy9teS13YWxsZXQtc2V0dGluZ3MuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQ0U7RUFDRSw2QkFBQTtBQUFKIiwic291cmNlc0NvbnRlbnQiOlsiOmhvc3Qge1xyXG4gIC5fY29udGVudC1oIHtcclxuICAgIGhlaWdodDogY2FsYygxMDB2aCAtIDM2LjVyZW0pO1xyXG4gIH1cclxufVxyXG4iXSwic291cmNlUm9vdCI6IiJ9 */"],
  changeDetection: 0
});
(0,tslib__WEBPACK_IMPORTED_MODULE_13__.__decorate)([MyWalletSettingsPage.States(1), (0,tslib__WEBPACK_IMPORTED_MODULE_13__.__metadata)("design:type", Object)], MyWalletSettingsPage.prototype, "selectWalletSheet", void 0);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MyWalletSettingsPage);

/***/ })

}]);
//# sourceMappingURL=apps_bfswap_src_pages_mine_pages_my-wallet-settings_my-wallet-settings_component_ts.js.map