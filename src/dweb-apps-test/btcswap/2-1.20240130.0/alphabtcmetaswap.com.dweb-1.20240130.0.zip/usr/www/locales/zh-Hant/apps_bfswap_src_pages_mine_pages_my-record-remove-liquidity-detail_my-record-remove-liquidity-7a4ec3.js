"use strict";
(self["webpackChunkbfswap"] = self["webpackChunkbfswap"] || []).push([["apps_bfswap_src_pages_mine_pages_my-record-remove-liquidity-detail_my-record-remove-liquidity-7a4ec3"],{

/***/ 95921:
/*!***************************************************************************************************************************!*\
  !*** ./apps/bfswap/src/pages/mine/pages/my-record-remove-liquidity-detail/my-record-remove-liquidity-detail.component.ts ***!
  \***************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   MyRecordRemoveLiquidityDetailPage: () => (/* binding */ MyRecordRemoveLiquidityDetailPage),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 52542);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! tslib */ 90505);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @angular/common */ 6729);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @angular/core */ 61039);
/* harmony import */ var _modules_page_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ~modules/page.module */ 16381);
/* harmony import */ var _services_liquidity_order_liquidity_order_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ~services/liquidity-order/liquidity-order.service */ 84435);
/* harmony import */ var _services_wallet_wallet_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ~services/wallet/wallet.service */ 54275);
/* harmony import */ var _services_transaction_settings_transaction_settings_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ~services/transaction-settings/transaction-settings.service */ 80348);
/* harmony import */ var _bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @bnqkl/bnqkl-swap-core */ 70195);
/* harmony import */ var _pipes_chain_name_transfer_chain_name_transfer_pipe__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ~pipes/chain-name-transfer/chain-name-transfer.pipe */ 37514);
/* harmony import */ var _pipes_record_state_record_state_pipe__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ~pipes/record-state/record-state.pipe */ 7372);
/* harmony import */ var _components_related_events_related_events_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ~components/related-events/related-events.component */ 40941);
/* harmony import */ var _services_liquidity_order_lquidity_order_type__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ~services/liquidity-order/lquidity-order.type */ 84601);
/* harmony import */ var _bnqkl_framework_pipes__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @bnqkl/framework/pipes */ 80909);
/* harmony import */ var _pipes_record_state_record_state_img_pipe__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ~pipes/record-state/record-state-img.pipe */ 24787);
/* harmony import */ var _components_swap_token_chain_icon_swap_token_chain_icon_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ~components/swap-token-chain-icon/swap-token-chain-icon.component */ 26193);
/* harmony import */ var _libs_bnf_directives_click_to_copy_directive__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../../../../../../../libs/bnf/directives/click-to-copy.directive */ 46413);
/* harmony import */ var _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../../../../../../../libs/bnf/modules/page/common-page/common-page.component */ 62052);
/* harmony import */ var _components_icon_icon_component__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ../../../../components/icon/icon.component */ 18840);
/* harmony import */ var _libs_bnf_pipes_amountFixed_amount_fixed_pipe__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ../../../../../../../libs/bnf/pipes/amountFixed/amount-fixed.pipe */ 44070);

var _class;





















function MyRecordRemoveLiquidityDetailPage_Conditional_2_Conditional_63_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](0, "div", 39)(1, "div", 40);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵi18n"](2, 41);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](3, "div", 42);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtextInterpolate1"](" ", ctx_r2.detail == null ? null : ctx_r2.detail.failureReason, " ");
  }
}
const _c26 = () => ({
  removeZero: true
});
function MyRecordRemoveLiquidityDetailPage_Conditional_2_Conditional_64_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](0, "div", 7)(1, "div", 8)(2, "div", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵi18n"](3, 43);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](4, "div", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtext"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵpipe"](6, "date");
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](7, "div", 12)(8, "div", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵi18n"](9, 44);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](10, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtext"](11);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵpipe"](12, "amountFixed");
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](13, "div", 12)(14, "div", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵi18n"](15, 45);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelement"](16, "bs-icon", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](17, "div", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelement"](18, "bs-swap-token-chain-icon", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](19, "div", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtext"](20);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](21, "div", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelement"](22, "bs-swap-token-chain-icon", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](23, "div", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtext"](24);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵpipe"](25, "chainNameTransfer");
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](26, "div", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtext"](27);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵpipe"](28, "amountFixed");
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](29, "div", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelement"](30, "bs-swap-token-chain-icon", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](31, "div", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtext"](32);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](33, "div", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelement"](34, "bs-swap-token-chain-icon", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](35, "div", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtext"](36);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵpipe"](37, "chainNameTransfer");
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](38, "div", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtext"](39);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵpipe"](40, "amountFixed");
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵpipeBind2"](6, 14, ctx_r3.detail == null ? null : ctx_r3.detail.finishTime, "yyyy.MM.dd HH:mm"));
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtextInterpolate1"]("- ", (ctx_r3.detail == null ? null : ctx_r3.detail.lpCoinsAmount) ? _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵpipeBind3"](12, 17, ctx_r3.detail == null ? null : ctx_r3.detail.lpCoinsAmount, 8, _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵpureFunction0"](33, _c26)) : "", "");
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](7);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵproperty"]("swapCoinName", ctx_r3.anchorTran == null ? null : ctx_r3.anchorTran.coinName)("swapChainName", ctx_r3.anchorTran == null ? null : ctx_r3.anchorTran.chainName);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtextInterpolate"](ctx_r3.anchorTran == null ? null : ctx_r3.anchorTran.coinName);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵproperty"]("swapChainName", ctx_r3.anchorTran == null ? null : ctx_r3.anchorTran.chainName);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵpipeBind1"](25, 21, ctx_r3.anchorTran == null ? null : ctx_r3.anchorTran.chainName));
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtextInterpolate1"]("+ ", _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵpipeBind3"](28, 23, ctx_r3.detail == null ? null : ctx_r3.detail.gainAnchorCoinsAmount, 8, _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵpureFunction0"](34, _c26)), "");
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵproperty"]("swapCoinName", ctx_r3.quoteTran == null ? null : ctx_r3.quoteTran.coinName)("swapChainName", ctx_r3.quoteTran == null ? null : ctx_r3.quoteTran.chainName);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtextInterpolate"](ctx_r3.quoteTran == null ? null : ctx_r3.quoteTran.coinName);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵproperty"]("swapChainName", ctx_r3.quoteTran == null ? null : ctx_r3.quoteTran.chainName);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵpipeBind1"](37, 27, ctx_r3.quoteTran == null ? null : ctx_r3.quoteTran.chainName));
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtextInterpolate1"]("+ ", _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵpipeBind3"](40, 29, ctx_r3.detail == null ? null : ctx_r3.detail.gainQuoteCoinsAmount, 8, _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵpureFunction0"](35, _c26)), "");
  }
}
function MyRecordRemoveLiquidityDetailPage_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](0, "div", 3)(1, "div", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵi18n"](2, 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵpipe"](3, "recordState");
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelement"](4, "img", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵpipe"](5, "recordStateImage");
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](6, "div", 7)(7, "div", 8)(8, "div", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵi18n"](9, 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](10, "div", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtext"](11);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵpipe"](12, "date");
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](13, "div", 12)(14, "div", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵi18n"](15, 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](16, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtext"](17);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵpipe"](18, "amountFixed");
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](19, "div", 12)(20, "div", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵi18n"](21, 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelement"](22, "bs-icon", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](23, "div", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelement"](24, "bs-swap-token-chain-icon", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](25, "div", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtext"](26);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](27, "div", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelement"](28, "bs-swap-token-chain-icon", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](29, "div", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtext"](30);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵpipe"](31, "chainNameTransfer");
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](32, "div", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtext"](33);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵpipe"](34, "amountFixed");
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](35, "div", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelement"](36, "bs-swap-token-chain-icon", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](37, "div", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtext"](38);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](39, "div", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelement"](40, "bs-swap-token-chain-icon", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](41, "div", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtext"](42);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵpipe"](43, "chainNameTransfer");
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](44, "div", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtext"](45);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵpipe"](46, "amountFixed");
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](47, "div", 24)(48, "div", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵi18n"](49, 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](50, "div", 26);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtext"](51);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵpipe"](52, "addressHidden");
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelement"](53, "bs-icon", 27);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](54, "div", 28)(55, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵi18n"](56, 29);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](57, "div", 30);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtext"](58);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](59, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵi18n"](60, 31);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](61, "div", 30);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵi18n"](62, 32);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtemplate"](63, MyRecordRemoveLiquidityDetailPage_Conditional_2_Conditional_63_Template, 5, 1, "div", 33);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtemplate"](64, MyRecordRemoveLiquidityDetailPage_Conditional_2_Conditional_64_Template, 41, 36, "div", 34);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](65, "div", 35)(66, "div", 36);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵi18n"](67, 37);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelement"](68, "bs-related-events-component", 38);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵi18nExp"](_angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵpipeBind2"](3, 23, ctx_r0.detail == null ? null : ctx_r0.detail.state, ctx_r0.RECORDTYPE));
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵi18nApply"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵproperty"]("src", _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵpipeBind1"](5, 26, ctx_r0.detail == null ? null : ctx_r0.detail.state), _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵsanitizeUrl"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](7);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵpipeBind2"](12, 28, ctx_r0.detail == null ? null : ctx_r0.detail.startTime, "yyyy.MM.dd HH:mm"));
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtextInterpolate1"]("- ", (ctx_r0.detail == null ? null : ctx_r0.detail.lpCoinsAmount) ? _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵpipeBind3"](18, 31, ctx_r0.detail == null ? null : ctx_r0.detail.lpCoinsAmount, 8, _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵpureFunction0"](49, _c26)) : "", "");
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](7);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵproperty"]("swapCoinName", ctx_r0.anchorTran == null ? null : ctx_r0.anchorTran.coinName)("swapChainName", ctx_r0.anchorTran == null ? null : ctx_r0.anchorTran.chainName);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtextInterpolate"](ctx_r0.anchorTran == null ? null : ctx_r0.anchorTran.coinName);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵproperty"]("swapChainName", ctx_r0.quoteTran == null ? null : ctx_r0.quoteTran.chainName);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵpipeBind1"](31, 35, ctx_r0.anchorTran == null ? null : ctx_r0.anchorTran.chainName));
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtextInterpolate1"]("+ ", _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵpipeBind3"](34, 37, ctx_r0.detail == null ? null : ctx_r0.detail.anchorCoinsAmount, 8, _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵpureFunction0"](50, _c26)), "");
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵproperty"]("swapCoinName", ctx_r0.quoteTran == null ? null : ctx_r0.quoteTran.coinName)("swapChainName", ctx_r0.quoteTran == null ? null : ctx_r0.quoteTran.chainName);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtextInterpolate"](ctx_r0.quoteTran == null ? null : ctx_r0.quoteTran.coinName);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵproperty"]("swapChainName", ctx_r0.quoteTran == null ? null : ctx_r0.quoteTran.chainName);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵpipeBind1"](43, 41, ctx_r0.quoteTran == null ? null : ctx_r0.quoteTran.chainName));
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtextInterpolate1"]("+ ", _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵpipeBind3"](46, 43, ctx_r0.detail == null ? null : ctx_r0.detail.quoteCoinsAmount, 8, _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵpureFunction0"](51, _c26)), "");
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵpipeBind1"](52, 47, ctx_r0.detail == null ? null : ctx_r0.detail.orderId), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵproperty"]("wClickToCopy", ctx_r0.detail == null ? null : ctx_r0.detail.orderId);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtextInterpolate1"]("", ctx_r0.slippage, " %");
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵi18nExp"](ctx_r0.endTime);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵi18nApply"](62);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵconditional"](63, ctx_r0.orderState === ctx_r0.ORDER_STATE.FAIL ? 63 : -1);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵconditional"](64, ctx_r0.orderState === ctx_r0.ORDER_STATE.SUCCESS ? 64 : -1);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵproperty"]("eventList", ctx_r0.eventList);
  }
}
function MyRecordRemoveLiquidityDetailPage_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](0, "div", 46);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelement"](1, "img", 47);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](2, "div", 40);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵi18n"](3, 48);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]()();
  }
}
/** 流动性详情页面 */
class MyRecordRemoveLiquidityDetailPage extends _modules_page_module__WEBPACK_IMPORTED_MODULE_1__.CommonPageBase {
  constructor() {
    super(...arguments);
    /** 订单服务 */
    this.orderService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_17__.inject)(_services_liquidity_order_liquidity_order_service__WEBPACK_IMPORTED_MODULE_2__.LiquidityOrderService);
    /** 钱包服务 */
    this.walletService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_17__.inject)(_services_wallet_wallet_service__WEBPACK_IMPORTED_MODULE_3__.WalletService);
    /** 记录的类型 */
    this.RECORDTYPE = _bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_5__.ORDER_RECORD_TYPES.REMOVE_LIQUIDITY;
    /** 订单状态 */
    this.ORDER_STATE = _services_liquidity_order_lquidity_order_type__WEBPACK_IMPORTED_MODULE_9__.$ORDER_STATE;
    /** 价格枚举 */
    this.PRICE_TYPE = _services_liquidity_order_lquidity_order_type__WEBPACK_IMPORTED_MODULE_9__.$PRICE_TYPE;
    /** 已连接钱包 */
    this.connectedWallet = this.walletService.connectedWallet;
    /** 页面初始化 */
    this.init = false;
    /** 滑点 */
    this.slippage = 0;
    /** 过期时间 */
    this.endTime = 0;
    /** 高级设置服务 */
    this.settingsService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_17__.inject)(_services_transaction_settings_transaction_settings_service__WEBPACK_IMPORTED_MODULE_4__.TransactionSettingsService);
    /** 订单的状态 */
    this.orderState = _services_liquidity_order_lquidity_order_type__WEBPACK_IMPORTED_MODULE_9__.$ORDER_STATE.FAIL;
    /** 相关事件列表 */
    this.eventList = [];
  }
  /** 初始化 */
  iniParams() {
    const {
      params
    } = this;
    if (params) {
      const {
        orderId
      } = params;
      this.getDetail(orderId);
    }
  }
  /** 获取详情 */
  getDetail(orderId) {
    var _this = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const result = yield _this.orderService.getPoolOrderInfo(orderId);
      if (result) {
        _this.slippage = _this.settingsService.getSlippageLabelByValue(result.slippageTolerance);
        _this.endTime = _this.settingsService.getEndTimeLabelByValue(result.expirationTime - result.startTime);
        _this.detail = result;
        _this.handleTran();
        _this.handleOrderState();
        _this.handleOrderEvent(result);
        _this.init = true;
      }
    })();
  }
  /** 处理交易的数据 */
  handleTran() {
    const {
      detail
    } = this;
    if (detail === undefined) return;
    const {
      orderTransactionList,
      anchorTxId,
      quoteTxId
    } = detail;
    this.anchorTran = orderTransactionList.find(order => {
      return order.transactionId === anchorTxId;
    });
    this.quoteTran = orderTransactionList.find(order => {
      return order.transactionId === quoteTxId;
    });
  }
  /** 订单的状态 */
  handleOrderState() {
    const {
      detail
    } = this;
    if (detail === undefined) return;
    const {
      state
    } = detail;
    const fail = _bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_5__.ORDER_RECORD_STATUS.RETURN_COMPLETE;
    const success = _bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_5__.ORDER_RECORD_STATUS.SUCCESS;
    if (state === success) {
      this.orderState = _services_liquidity_order_lquidity_order_type__WEBPACK_IMPORTED_MODULE_9__.$ORDER_STATE.SUCCESS;
    } else if (fail === state) {
      this.orderState = _services_liquidity_order_lquidity_order_type__WEBPACK_IMPORTED_MODULE_9__.$ORDER_STATE.FAIL;
    } else {
      this.orderState = _services_liquidity_order_lquidity_order_type__WEBPACK_IMPORTED_MODULE_9__.$ORDER_STATE.ING;
    }
  }
  /** 相关事件处理 */
  handleOrderEvent(detail) {
    const {
      orderTransactionList,
      anchorTxId,
      quoteTxId
    } = detail;
    const anchorTran = orderTransactionList.find(order => order.transactionId === anchorTxId);
    const quoteTran = orderTransactionList.find(order => order.transactionId === quoteTxId);
    const list = [];
    if (anchorTran) {
      list.push({
        leftName: " Liquidity pool infor ",
        rightName: anchorTran.coinName,
        txHash: anchorTran.txHash,
        state: anchorTran === null || anchorTran === void 0 ? void 0 : anchorTran.state,
        chainName: anchorTran.chainName,
        isRetrun: anchorTran.type === _bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_5__.TRANSACTION_TYPE.RETURN
      });
    }
    if (quoteTran) {
      list.push({
        leftName: " Liquidity pool infor ",
        rightName: quoteTran.coinName,
        txHash: quoteTran.txHash,
        state: quoteTran.state,
        chainName: quoteTran.chainName,
        isRetrun: quoteTran.type === _bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_5__.TRANSACTION_TYPE.RETURN
      });
    }
    this.eventList = list;
  }
}
_class = MyRecordRemoveLiquidityDetailPage;
_class.ɵfac = /*@__PURE__*/(() => {
  let ɵMyRecordRemoveLiquidityDetailPage_BaseFactory;
  return function MyRecordRemoveLiquidityDetailPage_Factory(t) {
    return (ɵMyRecordRemoveLiquidityDetailPage_BaseFactory || (ɵMyRecordRemoveLiquidityDetailPage_BaseFactory = _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵgetInheritedFactory"](_class)))(t || _class);
  };
})();
_class.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵdefineComponent"]({
  type: _class,
  selectors: [["bs-my-record-remove-liquidity-detail"]],
  standalone: true,
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵInheritDefinitionFeature"], _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵStandaloneFeature"]],
  decls: 4,
  vars: 4,
  consts: () => {
    let i18n_0;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_7130242044355020058$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_RECORD_REMOVE_LIQUIDITY_DETAIL_MY_RECORD_REMOVE_LIQUIDITY_DETAIL_COMPONENT_TS__1 = goog.getMsg(" {$interpolation} ", {
        "interpolation": "\uFFFD0\uFFFD"
      }, {
        original_code: {
          "interpolation": "{{ detail?.state | recordState : RECORDTYPE }}"
        }
      });
      i18n_0 = MSG_EXTERNAL_7130242044355020058$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_RECORD_REMOVE_LIQUIDITY_DETAIL_MY_RECORD_REMOVE_LIQUIDITY_DETAIL_COMPONENT_TS__1;
    } else {
      i18n_0 = " " + "\uFFFD0\uFFFD" + " ";
    }
    let i18n_2;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_8789057272766768352$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_RECORD_REMOVE_LIQUIDITY_DETAIL_MY_RECORD_REMOVE_LIQUIDITY_DETAIL_COMPONENT_TS__3 = goog.getMsg("\u53D1\u8D77\u79FB\u9664");
      i18n_2 = MSG_EXTERNAL_8789057272766768352$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_RECORD_REMOVE_LIQUIDITY_DETAIL_MY_RECORD_REMOVE_LIQUIDITY_DETAIL_COMPONENT_TS__3;
    } else {
      i18n_2 = "\u53D1\u8D77\u79FB\u9664";
    }
    let i18n_4;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_2160098162517155843$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_RECORD_REMOVE_LIQUIDITY_DETAIL_MY_RECORD_REMOVE_LIQUIDITY_DETAIL_COMPONENT_TS__5 = goog.getMsg("\u5408\u7EA6\u6C60\u6743\u76CA");
      i18n_4 = MSG_EXTERNAL_2160098162517155843$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_RECORD_REMOVE_LIQUIDITY_DETAIL_MY_RECORD_REMOVE_LIQUIDITY_DETAIL_COMPONENT_TS__5;
    } else {
      i18n_4 = "\u5408\u7EA6\u6C60\u6743\u76CA";
    }
    let i18n_6;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_4895373489419699476$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_RECORD_REMOVE_LIQUIDITY_DETAIL_MY_RECORD_REMOVE_LIQUIDITY_DETAIL_COMPONENT_TS__7 = goog.getMsg("\u9884\u8BA1\u83B7\u5F97\u8D44\u4EA7");
      i18n_6 = MSG_EXTERNAL_4895373489419699476$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_RECORD_REMOVE_LIQUIDITY_DETAIL_MY_RECORD_REMOVE_LIQUIDITY_DETAIL_COMPONENT_TS__7;
    } else {
      i18n_6 = "\u9884\u8BA1\u83B7\u5F97\u8D44\u4EA7";
    }
    let i18n_8;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_ID$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_RECORD_REMOVE_LIQUIDITY_DETAIL_MY_RECORD_REMOVE_LIQUIDITY_DETAIL_COMPONENT_TS__9 = goog.getMsg("\u8BA2\u5355 ID");
      i18n_8 = MSG_EXTERNAL_ID$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_RECORD_REMOVE_LIQUIDITY_DETAIL_MY_RECORD_REMOVE_LIQUIDITY_DETAIL_COMPONENT_TS__9;
    } else {
      i18n_8 = "\u8BA2\u5355 ID";
    }
    let i18n_10;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_SLIPPAGE_TOLERANCE$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_RECORD_REMOVE_LIQUIDITY_DETAIL_MY_RECORD_REMOVE_LIQUIDITY_DETAIL_COMPONENT_TS__11 = goog.getMsg("Slippage Tolerance");
      i18n_10 = MSG_EXTERNAL_SLIPPAGE_TOLERANCE$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_RECORD_REMOVE_LIQUIDITY_DETAIL_MY_RECORD_REMOVE_LIQUIDITY_DETAIL_COMPONENT_TS__11;
    } else {
      i18n_10 = "Slippage Tolerance";
    }
    let i18n_12;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_DEADLINE$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_RECORD_REMOVE_LIQUIDITY_DETAIL_MY_RECORD_REMOVE_LIQUIDITY_DETAIL_COMPONENT_TS__13 = goog.getMsg("Deadline");
      i18n_12 = MSG_EXTERNAL_DEADLINE$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_RECORD_REMOVE_LIQUIDITY_DETAIL_MY_RECORD_REMOVE_LIQUIDITY_DETAIL_COMPONENT_TS__13;
    } else {
      i18n_12 = "Deadline";
    }
    let i18n_14;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_MINUTE$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_RECORD_REMOVE_LIQUIDITY_DETAIL_MY_RECORD_REMOVE_LIQUIDITY_DETAIL_COMPONENT_TS__15 = goog.getMsg("{$interpolation} Minute", {
        "interpolation": "\uFFFD0\uFFFD"
      }, {
        original_code: {
          "interpolation": "{{ endTime }}"
        }
      });
      i18n_14 = MSG_EXTERNAL_MINUTE$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_RECORD_REMOVE_LIQUIDITY_DETAIL_MY_RECORD_REMOVE_LIQUIDITY_DETAIL_COMPONENT_TS__15;
    } else {
      i18n_14 = "" + "\uFFFD0\uFFFD" + "Minute";
    }
    let i18n_16;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_RELATED_EVENT$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_RECORD_REMOVE_LIQUIDITY_DETAIL_MY_RECORD_REMOVE_LIQUIDITY_DETAIL_COMPONENT_TS__17 = goog.getMsg("Related events");
      i18n_16 = MSG_EXTERNAL_RELATED_EVENT$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_RECORD_REMOVE_LIQUIDITY_DETAIL_MY_RECORD_REMOVE_LIQUIDITY_DETAIL_COMPONENT_TS__17;
    } else {
      i18n_16 = "Related events";
    }
    let i18n_18;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_FAILURE_REASON$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_RECORD_REMOVE_LIQUIDITY_DETAIL_MY_RECORD_REMOVE_LIQUIDITY_DETAIL_COMPONENT_TS___19 = goog.getMsg("Failure reason");
      i18n_18 = MSG_EXTERNAL_FAILURE_REASON$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_RECORD_REMOVE_LIQUIDITY_DETAIL_MY_RECORD_REMOVE_LIQUIDITY_DETAIL_COMPONENT_TS___19;
    } else {
      i18n_18 = "Failure reason";
    }
    let i18n_20;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_2192413672555514113$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_RECORD_REMOVE_LIQUIDITY_DETAIL_MY_RECORD_REMOVE_LIQUIDITY_DETAIL_COMPONENT_TS___21 = goog.getMsg("\u5B9E\u9645\u79FB\u9664");
      i18n_20 = MSG_EXTERNAL_2192413672555514113$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_RECORD_REMOVE_LIQUIDITY_DETAIL_MY_RECORD_REMOVE_LIQUIDITY_DETAIL_COMPONENT_TS___21;
    } else {
      i18n_20 = "\u5B9E\u9645\u79FB\u9664";
    }
    let i18n_22;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_2160098162517155843$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_RECORD_REMOVE_LIQUIDITY_DETAIL_MY_RECORD_REMOVE_LIQUIDITY_DETAIL_COMPONENT_TS___23 = goog.getMsg("\u5408\u7EA6\u6C60\u6743\u76CA");
      i18n_22 = MSG_EXTERNAL_2160098162517155843$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_RECORD_REMOVE_LIQUIDITY_DETAIL_MY_RECORD_REMOVE_LIQUIDITY_DETAIL_COMPONENT_TS___23;
    } else {
      i18n_22 = "\u5408\u7EA6\u6C60\u6743\u76CA";
    }
    let i18n_24;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_4895373489419699476$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_RECORD_REMOVE_LIQUIDITY_DETAIL_MY_RECORD_REMOVE_LIQUIDITY_DETAIL_COMPONENT_TS___25 = goog.getMsg("\u9884\u8BA1\u83B7\u5F97\u8D44\u4EA7");
      i18n_24 = MSG_EXTERNAL_4895373489419699476$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_RECORD_REMOVE_LIQUIDITY_DETAIL_MY_RECORD_REMOVE_LIQUIDITY_DETAIL_COMPONENT_TS___25;
    } else {
      i18n_24 = "\u9884\u8BA1\u83B7\u5F97\u8D44\u4EA7";
    }
    let i18n_27;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_7825757923954104189$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_RECORD_REMOVE_LIQUIDITY_DETAIL_MY_RECORD_REMOVE_LIQUIDITY_DETAIL_COMPONENT_TS__28 = goog.getMsg("\u83B7\u53D6\u6570\u636E\u4E2D");
      i18n_27 = MSG_EXTERNAL_7825757923954104189$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_RECORD_REMOVE_LIQUIDITY_DETAIL_MY_RECORD_REMOVE_LIQUIDITY_DETAIL_COMPONENT_TS__28;
    } else {
      i18n_27 = "\u83B7\u53D6\u6570\u636E\u4E2D";
    }
    return [[3, "headerBackground", "headerTranslucent", "contentBackground"], [1, "h-75", "bg-linear-page-top", "absolute", "top-0", "w-full"], ["class", "relative px-3 pb-4"], [1, "relative", "px-3", "pb-4"], [1, "text-title-10", "pb-8", "pl-4", "pt-4", "text-2xl", "font-semibold"], i18n_0, [1, "h-29", "absolute", "-top-10", "right-0", "w-40", 3, "src"], [1, "rounded-4", "mb-2", "bg-white", "px-4", "pb-4", "pt-6"], [1, "mb-2", "flex", "justify-between"], [1, "text-title-10"], i18n_2, [1, "text-subtitle-2", "text-xs"], [1, "mb-2", "flex", "items-center", "justify-between"], [1, "text-subtitle", "text-xs"], i18n_4, i18n_6, ["name", "icon-arrow-down", 1, "text-xl"], [1, "mb-2", "flex", "items-center", "text-xs"], [3, "swapCoinName", "swapChainName"], [1, "mx-1"], [1, "bg-blue-10", "rounded-1", "flex", "items-center", "pr-1"], [3, "swapChainName"], [1, "text-primary", "text-xxxs"], [1, "ml-auto"], [1, "rounded-2", "bg-base-300", "mb-2", "mt-6", "flex", "items-center", "px-3", "py-2"], i18n_8, [1, "text-base-gray", "ml-auto", "text-xs"], ["name", "icon-copy", 1, "ml-2", "text-xl", 3, "wClickToCopy"], [1, "text-subtitle-2", "rounded-2", "bg-base-300", "grid", "grid-cols-2", "gap-y-3", "px-3", "py-4", "text-xs"], i18n_10, [1, "text-right"], i18n_12, i18n_14, ["class", "text-subtitle-2 rounded-2 bg-base-300 flex items-center justify-between px-3 py-2 text-xs"], ["class", "rounded-4 mb-2 bg-white px-4 pb-4 pt-6"], [1, "rounded-4", "bg-white", "p-4"], [1, "text-subtitle-2", "mb-2"], i18n_16, [3, "eventList"], [1, "text-subtitle-2", "rounded-2", "bg-base-300", "flex", "items-center", "justify-between", "px-3", "py-2", "text-xs"], [1, "text-base-200"], i18n_18, [1, "break-all"], i18n_20, i18n_22, i18n_24, [1, "absolute", "top-1/2", "flex", "w-full", "-translate-y-1/2", "flex-col", "items-center", "justify-center"], ["src", "./assets/images/order-ing.png", 1, "h-45", "w-60"], i18n_27];
  },
  template: function MyRecordRemoveLiquidityDetailPage_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](0, "common-page", 0);
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelement"](1, "div", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtemplate"](2, MyRecordRemoveLiquidityDetailPage_Conditional_2_Template, 69, 52, "div", 2)(3, MyRecordRemoveLiquidityDetailPage_Conditional_3_Template, 4, 0);
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵproperty"]("headerBackground", "transparent")("headerTranslucent", false)("contentBackground", "#f6f7fc");
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵconditional"](2, ctx.init ? 2 : 3);
    }
  },
  dependencies: [_components_swap_token_chain_icon_swap_token_chain_icon_component__WEBPACK_IMPORTED_MODULE_12__.SwapTokenChainIconComponent, _pipes_record_state_record_state_pipe__WEBPACK_IMPORTED_MODULE_7__.RecordStatePipe, _bnqkl_framework_pipes__WEBPACK_IMPORTED_MODULE_10__.AddressHiddenPipe, _pipes_record_state_record_state_img_pipe__WEBPACK_IMPORTED_MODULE_11__.RecordStateImagePipe, _modules_page_module__WEBPACK_IMPORTED_MODULE_1__.CommonPageModule, _libs_bnf_directives_click_to_copy_directive__WEBPACK_IMPORTED_MODULE_13__.ClickToCopyDirective, _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_14__.CommonPageComponent, _components_icon_icon_component__WEBPACK_IMPORTED_MODULE_15__.IconComponent, _angular_common__WEBPACK_IMPORTED_MODULE_18__.DatePipe, _libs_bnf_pipes_amountFixed_amount_fixed_pipe__WEBPACK_IMPORTED_MODULE_16__.AmountFixedPipe, _angular_common__WEBPACK_IMPORTED_MODULE_18__.CommonModule, _components_related_events_related_events_component__WEBPACK_IMPORTED_MODULE_8__["default"], _pipes_chain_name_transfer_chain_name_transfer_pipe__WEBPACK_IMPORTED_MODULE_6__.ChainNameTransferPipe],
  encapsulation: 2,
  changeDetection: 0
});
(0,tslib__WEBPACK_IMPORTED_MODULE_19__.__decorate)([MyRecordRemoveLiquidityDetailPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_19__.__metadata)("design:type", Object)], MyRecordRemoveLiquidityDetailPage.prototype, "ORDER_STATE", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_19__.__decorate)([MyRecordRemoveLiquidityDetailPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_19__.__metadata)("design:type", Object)], MyRecordRemoveLiquidityDetailPage.prototype, "PRICE_TYPE", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_19__.__decorate)([MyRecordRemoveLiquidityDetailPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_19__.__metadata)("design:type", Object)], MyRecordRemoveLiquidityDetailPage.prototype, "connectedWallet", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_19__.__decorate)([MyRecordRemoveLiquidityDetailPage.QueryParams(), (0,tslib__WEBPACK_IMPORTED_MODULE_19__.__metadata)("design:type", Object)], MyRecordRemoveLiquidityDetailPage.prototype, "params", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_19__.__decorate)([MyRecordRemoveLiquidityDetailPage.OnReady(), (0,tslib__WEBPACK_IMPORTED_MODULE_19__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_19__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_19__.__metadata)("design:returntype", void 0)], MyRecordRemoveLiquidityDetailPage.prototype, "iniParams", null);
(0,tslib__WEBPACK_IMPORTED_MODULE_19__.__decorate)([MyRecordRemoveLiquidityDetailPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_19__.__metadata)("design:type", Object)], MyRecordRemoveLiquidityDetailPage.prototype, "init", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_19__.__decorate)([MyRecordRemoveLiquidityDetailPage.States(1), (0,tslib__WEBPACK_IMPORTED_MODULE_19__.__metadata)("design:type", Object)], MyRecordRemoveLiquidityDetailPage.prototype, "detail", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_19__.__decorate)([MyRecordRemoveLiquidityDetailPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_19__.__metadata)("design:type", Object)], MyRecordRemoveLiquidityDetailPage.prototype, "slippage", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_19__.__decorate)([MyRecordRemoveLiquidityDetailPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_19__.__metadata)("design:type", Object)], MyRecordRemoveLiquidityDetailPage.prototype, "endTime", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_19__.__decorate)([MyRecordRemoveLiquidityDetailPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_19__.__metadata)("design:type", Object)], MyRecordRemoveLiquidityDetailPage.prototype, "anchorTran", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_19__.__decorate)([MyRecordRemoveLiquidityDetailPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_19__.__metadata)("design:type", Object)], MyRecordRemoveLiquidityDetailPage.prototype, "quoteTran", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_19__.__decorate)([MyRecordRemoveLiquidityDetailPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_19__.__metadata)("design:type", String)], MyRecordRemoveLiquidityDetailPage.prototype, "orderState", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_19__.__decorate)([MyRecordRemoveLiquidityDetailPage.States(1), (0,tslib__WEBPACK_IMPORTED_MODULE_19__.__metadata)("design:type", Array)], MyRecordRemoveLiquidityDetailPage.prototype, "eventList", void 0);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MyRecordRemoveLiquidityDetailPage);

/***/ })

}]);
//# sourceMappingURL=apps_bfswap_src_pages_mine_pages_my-record-remove-liquidity-detail_my-record-remove-liquidity-7a4ec3.js.map