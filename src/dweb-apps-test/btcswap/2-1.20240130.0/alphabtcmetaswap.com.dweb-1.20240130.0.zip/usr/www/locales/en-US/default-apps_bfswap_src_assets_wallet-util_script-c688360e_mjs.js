"use strict";
(self["webpackChunkbfswap"] = self["webpackChunkbfswap"] || []).push([["default-apps_bfswap_src_assets_wallet-util_script-c688360e_mjs"],{

/***/ 97370:
/*!****************************************************************!*\
  !*** ./apps/bfswap/src/assets/wallet-util/script-c688360e.mjs ***!
  \****************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   B: () => (/* binding */ R),
/* harmony export */   H: () => (/* binding */ g),
/* harmony export */   N: () => (/* binding */ m),
/* harmony export */   O: () => (/* binding */ t),
/* harmony export */   S: () => (/* binding */ a),
/* harmony export */   U: () => (/* binding */ D),
/* harmony export */   a: () => (/* binding */ J),
/* harmony export */   b: () => (/* binding */ C),
/* harmony export */   c: () => (/* binding */ W),
/* harmony export */   d: () => (/* binding */ ne),
/* harmony export */   e: () => (/* binding */ X),
/* harmony export */   f: () => (/* binding */ Q),
/* harmony export */   g: () => (/* binding */ Z),
/* harmony export */   h: () => (/* binding */ H),
/* harmony export */   i: () => (/* binding */ c),
/* harmony export */   j: () => (/* binding */ w),
/* harmony export */   k: () => (/* binding */ I),
/* harmony export */   l: () => (/* binding */ $),
/* harmony export */   m: () => (/* binding */ T),
/* harmony export */   n: () => (/* binding */ oe),
/* harmony export */   s: () => (/* binding */ te),
/* harmony export */   t: () => (/* binding */ N)
/* harmony export */ });
/* harmony import */ var _index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./index-d96f2042.mjs */ 99449);
/* harmony import */ var _typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./typeforce-a57e57b8.mjs */ 75473);


function r(n, r) {
  const t = n.length,
    o = r.length;
  if (0 === t) throw new Error("R length is zero");
  if (0 === o) throw new Error("S length is zero");
  if (t > 33) throw new Error("R length is too long");
  if (o > 33) throw new Error("S length is too long");
  if (128 & n[0]) throw new Error("R value is negative");
  if (128 & r[0]) throw new Error("S value is negative");
  if (t > 1 && 0 === n[0] && !(128 & n[1])) throw new Error("R value excessively padded");
  if (o > 1 && 0 === r[0] && !(128 & r[1])) throw new Error("S value excessively padded");
  const f = _index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_0__.B.allocUnsafe(6 + t + o);
  return f[0] = 48, f[1] = f.length - 2, f[2] = 2, f[3] = n.length, n.copy(f, 4), f[4 + t] = 2, f[5 + t] = r.length, r.copy(f, 6 + t), f;
}
const t = {
    OP_FALSE: 0,
    OP_0: 0,
    OP_PUSHDATA1: 76,
    OP_PUSHDATA2: 77,
    OP_PUSHDATA4: 78,
    OP_1NEGATE: 79,
    OP_RESERVED: 80,
    OP_TRUE: 81,
    OP_1: 81,
    OP_2: 82,
    OP_3: 83,
    OP_4: 84,
    OP_5: 85,
    OP_6: 86,
    OP_7: 87,
    OP_8: 88,
    OP_9: 89,
    OP_10: 90,
    OP_11: 91,
    OP_12: 92,
    OP_13: 93,
    OP_14: 94,
    OP_15: 95,
    OP_16: 96,
    OP_NOP: 97,
    OP_VER: 98,
    OP_IF: 99,
    OP_NOTIF: 100,
    OP_VERIF: 101,
    OP_VERNOTIF: 102,
    OP_ELSE: 103,
    OP_ENDIF: 104,
    OP_VERIFY: 105,
    OP_RETURN: 106,
    OP_TOALTSTACK: 107,
    OP_FROMALTSTACK: 108,
    OP_2DROP: 109,
    OP_2DUP: 110,
    OP_3DUP: 111,
    OP_2OVER: 112,
    OP_2ROT: 113,
    OP_2SWAP: 114,
    OP_IFDUP: 115,
    OP_DEPTH: 116,
    OP_DROP: 117,
    OP_DUP: 118,
    OP_NIP: 119,
    OP_OVER: 120,
    OP_PICK: 121,
    OP_ROLL: 122,
    OP_ROT: 123,
    OP_SWAP: 124,
    OP_TUCK: 125,
    OP_CAT: 126,
    OP_SUBSTR: 127,
    OP_LEFT: 128,
    OP_RIGHT: 129,
    OP_SIZE: 130,
    OP_INVERT: 131,
    OP_AND: 132,
    OP_OR: 133,
    OP_XOR: 134,
    OP_EQUAL: 135,
    OP_EQUALVERIFY: 136,
    OP_RESERVED1: 137,
    OP_RESERVED2: 138,
    OP_1ADD: 139,
    OP_1SUB: 140,
    OP_2MUL: 141,
    OP_2DIV: 142,
    OP_NEGATE: 143,
    OP_ABS: 144,
    OP_NOT: 145,
    OP_0NOTEQUAL: 146,
    OP_ADD: 147,
    OP_SUB: 148,
    OP_MUL: 149,
    OP_DIV: 150,
    OP_MOD: 151,
    OP_LSHIFT: 152,
    OP_RSHIFT: 153,
    OP_BOOLAND: 154,
    OP_BOOLOR: 155,
    OP_NUMEQUAL: 156,
    OP_NUMEQUALVERIFY: 157,
    OP_NUMNOTEQUAL: 158,
    OP_LESSTHAN: 159,
    OP_GREATERTHAN: 160,
    OP_LESSTHANOREQUAL: 161,
    OP_GREATERTHANOREQUAL: 162,
    OP_MIN: 163,
    OP_MAX: 164,
    OP_WITHIN: 165,
    OP_RIPEMD160: 166,
    OP_SHA1: 167,
    OP_SHA256: 168,
    OP_HASH160: 169,
    OP_HASH256: 170,
    OP_CODESEPARATOR: 171,
    OP_CHECKSIG: 172,
    OP_CHECKSIGVERIFY: 173,
    OP_CHECKMULTISIG: 174,
    OP_CHECKMULTISIGVERIFY: 175,
    OP_NOP1: 176,
    OP_NOP2: 177,
    OP_CHECKLOCKTIMEVERIFY: 177,
    OP_NOP3: 178,
    OP_CHECKSEQUENCEVERIFY: 178,
    OP_NOP4: 179,
    OP_NOP5: 180,
    OP_NOP6: 181,
    OP_NOP7: 182,
    OP_NOP8: 183,
    OP_NOP9: 184,
    OP_NOP10: 185,
    OP_PUBKEYHASH: 253,
    OP_PUBKEY: 254,
    OP_INVALIDOPCODE: 255
  },
  o = {};
for (const e of Object.keys(t)) {
  o[t[e]] = e;
}
function f(e) {
  return e < t.OP_PUSHDATA1 ? 1 : e <= 255 ? 2 : e <= 65535 ? 3 : 5;
}
function i(e, n) {
  const r = e.readUInt8(n);
  let o, f;
  if (r < t.OP_PUSHDATA1) o = r, f = 1;else if (r === t.OP_PUSHDATA1) {
    if (n + 2 > e.length) return null;
    o = e.readUInt8(n + 1), f = 2;
  } else if (r === t.OP_PUSHDATA2) {
    if (n + 3 > e.length) return null;
    o = e.readUInt16LE(n + 1), f = 3;
  } else {
    if (n + 5 > e.length) return null;
    if (r !== t.OP_PUSHDATA4) throw new Error("Unexpected opcode");
    o = e.readUInt32LE(n + 1), f = 5;
  }
  return {
    opcode: r,
    number: o,
    size: f
  };
}
function O(n) {
  let r = Math.abs(n);
  const t = (o = r) > 2147483647 ? 5 : o > 8388607 ? 4 : o > 32767 ? 3 : o > 127 ? 2 : o > 0 ? 1 : 0;
  var o;
  const f = _index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_0__.B.allocUnsafe(t),
    i = n < 0;
  for (let e = 0; e < t; ++e) f.writeUInt8(255 & r, e), r >>= 8;
  return 128 & f[t - 1] ? f.writeUInt8(i ? 128 : 0, t - 1) : i && (f[t - 1] |= 128), f;
}
var P = Object.freeze({
  __proto__: null,
  decode: function (e, n, r) {
    n = n || 4, r = void 0 === r || r;
    const t = e.length;
    if (0 === t) return 0;
    if (t > n) throw new TypeError("Script number overflow");
    if (r && 0 == (127 & e[t - 1]) && (t <= 1 || 0 == (128 & e[t - 2]))) throw new Error("Non-minimally encoded script number");
    if (5 === t) {
      const n = e.readUInt32LE(0),
        r = e.readUInt8(4);
      return 128 & r ? -(4294967296 * (-129 & r) + n) : 4294967296 * r + n;
    }
    let o = 0;
    for (let n = 0; n < t; ++n) o |= e[n] << 8 * n;
    return 128 & e[t - 1] ? -(o & ~(128 << 8 * (t - 1))) : o;
  },
  encode: O
});
const u = _index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_0__.B.alloc(32, 0),
  s = _index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_0__.B.from("fffffffffffffffffffffffffffffffffffffffffffffffffffffffefffffc2f", "hex");
function c(n) {
  if (!_index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_0__.B.isBuffer(n)) return !1;
  if (n.length < 33) return !1;
  const r = n[0],
    t = n.subarray(1, 33);
  if (0 === t.compare(u)) return !1;
  if (t.compare(s) >= 0) return !1;
  if ((2 === r || 3 === r) && 33 === n.length) return !0;
  const o = n.subarray(33);
  return 0 !== o.compare(u) && !(o.compare(s) >= 0) && 4 === r && 65 === n.length;
}
const _ = Math.pow(2, 31) - 1;
function l(e) {
  return _typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_1__.t.String(e) && !!e.match(/^(m\/)?(\d+'?\/)*\d+'?$/);
}
l.toJSON = () => "BIP32 derivation path";
function a(e) {
  return _typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_1__.t.UInt53(e) && e <= 21e14;
}
const E = _typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_1__.t.quacksLike("Point"),
  h = _typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_1__.t.compile({
    messagePrefix: _typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_1__.t.anyOf(_typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_1__.t.Buffer, _typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_1__.t.String),
    bip32: {
      public: _typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_1__.t.UInt32,
      private: _typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_1__.t.UInt32
    },
    pubKeyHash: _typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_1__.t.UInt8,
    scriptHash: _typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_1__.t.UInt8,
    wif: _typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_1__.t.UInt8
  }),
  U = _typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_1__.t.BufferN(32),
  g = _typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_1__.t.BufferN(20),
  w = _typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_1__.t.BufferN(32),
  I = _typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_1__.t.Number,
  S = _typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_1__.t.Array,
  A = _typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_1__.t.Boolean,
  p = _typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_1__.t.String,
  R = _typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_1__.t.Buffer,
  d = _typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_1__.t.Hex,
  T = _typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_1__.t.maybe,
  N = _typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_1__.t.tuple,
  D = _typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_1__.t.UInt8,
  H = _typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_1__.t.UInt32,
  v = _typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_1__.t.Function,
  y = _typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_1__.t.BufferN,
  m = _typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_1__.t.Null,
  L = _typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_1__.t.oneOf,
  b = _typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_1__.t.Nil,
  B = _typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_1__.t.anyOf;
var C = Object.freeze({
  __proto__: null,
  typeforce: _typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_1__.t,
  isPoint: c,
  UInt31: function (e) {
    return _typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_1__.t.UInt32(e) && e <= _;
  },
  BIP32Path: l,
  Signer: function (e) {
    return (_typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_1__.t.Buffer(e.publicKey) || "function" == typeof e.getPublicKey) && "function" == typeof e.sign;
  },
  Satoshi: a,
  ECPoint: E,
  Network: h,
  Buffer256bit: U,
  Hash160bit: g,
  Hash256bit: w,
  Number: I,
  Array: S,
  Boolean: A,
  String: p,
  Buffer: R,
  Hex: d,
  maybe: T,
  tuple: N,
  UInt8: D,
  UInt32: H,
  Function: v,
  BufferN: y,
  Null: m,
  oneOf: L,
  Nil: b,
  anyOf: B
});
const {
    typeforce: F
  } = C,
  V = _index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_0__.B.alloc(1, 0);
function M(n) {
  let r = 0;
  for (; 0 === n[r];) ++r;
  return r === n.length ? V : 128 & (n = n.slice(r))[0] ? _index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_0__.B.concat([V, n], 1 + n.length) : n;
}
function x(n) {
  0 === n[0] && (n = n.slice(1));
  const r = _index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_0__.B.alloc(32, 0),
    t = Math.max(0, 32 - n.length);
  return n.copy(r, t), r;
}
var K = Object.freeze({
  __proto__: null,
  decode: function (n) {
    const r = n.readUInt8(n.length - 1),
      t = -129 & r;
    if (t <= 0 || t >= 4) throw new Error("Invalid hashType " + r);
    const o = function (e) {
        if (e.length < 8) throw new Error("DER sequence length is too short");
        if (e.length > 72) throw new Error("DER sequence length is too long");
        if (48 !== e[0]) throw new Error("Expected DER sequence");
        if (e[1] !== e.length - 2) throw new Error("DER sequence length is invalid");
        if (2 !== e[2]) throw new Error("Expected DER integer");
        const n = e[3];
        if (0 === n) throw new Error("R length is zero");
        if (5 + n >= e.length) throw new Error("R length is too long");
        if (2 !== e[4 + n]) throw new Error("Expected DER integer (2)");
        const r = e[5 + n];
        if (0 === r) throw new Error("S length is zero");
        if (6 + n + r !== e.length) throw new Error("S length is invalid");
        if (128 & e[4]) throw new Error("R value is negative");
        if (n > 1 && 0 === e[4] && !(128 & e[5])) throw new Error("R value excessively padded");
        if (128 & e[n + 6]) throw new Error("S value is negative");
        if (r > 1 && 0 === e[n + 6] && !(128 & e[n + 7])) throw new Error("S value excessively padded");
        return {
          r: e.slice(4, 4 + n),
          s: e.slice(6 + n)
        };
      }(n.slice(0, -1)),
      f = x(o.r),
      i = x(o.s);
    return {
      signature: _index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_0__.B.concat([f, i], 64),
      hashType: r
    };
  },
  encode: function (n, t) {
    F({
      signature: y(64),
      hashType: D
    }, {
      signature: n,
      hashType: t
    });
    const o = -129 & t;
    if (o <= 0 || o >= 4) throw new Error("Invalid hashType " + t);
    const f = _index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_0__.B.allocUnsafe(1);
    f.writeUInt8(t, 0);
    const i = M(n.slice(0, 32)),
      O = M(n.slice(32, 64));
    return _index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_0__.B.concat([r(i, O), f]);
  }
});
const {
    typeforce: G
  } = C,
  z = t.OP_RESERVED;
function j(e) {
  return R(e) || function (e) {
    return I(e) && (e === t.OP_0 || e >= t.OP_1 && e <= t.OP_16 || e === t.OP_1NEGATE);
  }(e);
}
function Q(e) {
  return S(e) && e.every(j);
}
function Y(e) {
  return 0 === e.length ? t.OP_0 : 1 === e.length ? e[0] >= 1 && e[0] <= 16 ? z + e[0] : 129 === e[0] ? t.OP_1NEGATE : void 0 : void 0;
}
function k(n) {
  return _index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_0__.B.isBuffer(n);
}
function q(n) {
  return _index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_0__.B.isBuffer(n);
}
function W(n) {
  if (k(n)) return n;
  G(S, n);
  const r = n.reduce((e, n) => q(n) ? 1 === n.length && void 0 !== Y(n) ? e + 1 : e + f(n.length) + n.length : e + 1, 0),
    o = _index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_0__.B.allocUnsafe(r);
  let i = 0;
  if (n.forEach(e => {
    if (q(e)) {
      const n = Y(e);
      if (void 0 !== n) return o.writeUInt8(n, i), void (i += 1);
      i += function (e, n, r) {
        const o = f(n);
        return 1 === o ? e.writeUInt8(n, r) : 2 === o ? (e.writeUInt8(t.OP_PUSHDATA1, r), e.writeUInt8(n, r + 1)) : 3 === o ? (e.writeUInt8(t.OP_PUSHDATA2, r), e.writeUInt16LE(n, r + 1)) : (e.writeUInt8(t.OP_PUSHDATA4, r), e.writeUInt32LE(n, r + 1)), o;
      }(o, e.length, i), e.copy(o, i), i += e.length;
    } else o.writeUInt8(e, i), i += 1;
  }), i !== o.length) throw new Error("Could not decode chunks");
  return o;
}
function X(e) {
  if (S(e)) return e;
  G(R, e);
  const n = [];
  let r = 0;
  for (; r < e.length;) {
    const o = e[r];
    if (o > t.OP_0 && o <= t.OP_PUSHDATA4) {
      const t = i(e, r);
      if (null === t) return null;
      if (r += t.size, r + t.number > e.length) return null;
      const o = e.slice(r, r + t.number);
      r += t.number;
      const f = Y(o);
      void 0 !== f ? n.push(f) : n.push(o);
    } else n.push(o), r += 1;
  }
  return n;
}
function J(e) {
  return k(e) && (e = X(e)), e.map(e => {
    if (q(e)) {
      const n = Y(e);
      if (void 0 === n) return e.toString("hex");
      e = n;
    }
    return o[e];
  }).join(" ");
}
function Z(n) {
  return n = X(n), G(Q, n), n.map(n => q(n) ? n : n === t.OP_0 ? _index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_0__.B.allocUnsafe(0) : O(n - z));
}
function $(e) {
  return c(e);
}
function ee(e) {
  const n = -129 & e;
  return n > 0 && n < 4;
}
function ne(n) {
  return !!_index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_0__.B.isBuffer(n) && !!ee(n[n.length - 1]) && function (e) {
    if (e.length < 8) return !1;
    if (e.length > 72) return !1;
    if (48 !== e[0]) return !1;
    if (e[1] !== e.length - 2) return !1;
    if (2 !== e[2]) return !1;
    const n = e[3];
    if (0 === n) return !1;
    if (5 + n >= e.length) return !1;
    if (2 !== e[4 + n]) return !1;
    const r = e[5 + n];
    return !(0 === r || 6 + n + r !== e.length || 128 & e[4] || n > 1 && 0 === e[4] && !(128 & e[5]) || 128 & e[n + 6] || r > 1 && 0 === e[n + 6] && !(128 & e[n + 7]));
  }(n.slice(0, -1));
}
const re = P,
  te = K;
var oe = Object.freeze({
  __proto__: null,
  OPS: t,
  isPushOnly: Q,
  compile: W,
  decompile: X,
  toASM: J,
  fromASM: function (n) {
    return G(p, n), W(n.split(" ").map(n => void 0 !== t[n] ? t[n] : (G(d, n), _index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_0__.B.from(n, "hex"))));
  },
  toStack: Z,
  isCanonicalPubKey: $,
  isDefinedHashType: ee,
  isCanonicalScriptSignature: ne,
  number: re,
  signature: te
});


/***/ })

}]);
//# sourceMappingURL=default-apps_bfswap_src_assets_wallet-util_script-c688360e_mjs.js.map