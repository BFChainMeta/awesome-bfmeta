"use strict";
(self["webpackChunkbfswap"] = self["webpackChunkbfswap"] || []).push([["apps_bfswap_src_components_swap-token-chain-icon_swap-token-chain-icon_component_ts-apps_bfsw-e25298"],{

/***/ 9038:
/*!***********************************************************************************!*\
  !*** ./apps/bfswap/src/components/add-detail-panel/add-detail-panel.component.ts ***!
  \***********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AddDetailPanelPage: () => (/* binding */ AddDetailPanelPage),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 52542);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! tslib */ 90505);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @angular/core */ 61039);
/* harmony import */ var _bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @bnqkl/bnqkl-swap-core */ 70195);
/* harmony import */ var _modules_page_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ~modules/page.module */ 16381);
/* harmony import */ var bignumber_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! bignumber.js */ 61994);
/* harmony import */ var _services_transaction_settings_transaction_settings_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ~services/transaction-settings/transaction-settings.service */ 80348);
/* harmony import */ var _bnqkl_framework_pipes__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @bnqkl/framework/pipes */ 80909);
/* harmony import */ var _bnqkl_framework_plugins_toast__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @bnqkl/framework/plugins/toast */ 18030);
/* harmony import */ var _services_wallet_wallet_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ~services/wallet/wallet.service */ 54275);
/* harmony import */ var _pipes_remove_trailing_zeros_remove_trailing_zeros_pipe__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ~pipes/remove-trailing-zeros/remove-trailing-zeros.pipe */ 53494);
/* harmony import */ var _environments_index__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ~environments/index */ 11295);
/* harmony import */ var _plaoc_plugins__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @plaoc/plugins */ 53396);
/* harmony import */ var _services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ~services/wallet/wallet.helper */ 84813);
/* harmony import */ var _libs_bnf_components_ripple_button_ripple_button_directive__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../../../../libs/bnf/components/ripple-button/ripple-button.directive */ 16505);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @angular/common */ 6729);
/* harmony import */ var _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../../../../../libs/bnf/modules/page/common-page/common-page.component */ 62052);
/* harmony import */ var _icon_icon_component__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../icon/icon.component */ 18840);
/* harmony import */ var _libs_bnf_components_loading_wrapper_loading_wrapper_component__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ../../../../../libs/bnf/components/loading-wrapper/loading-wrapper.component */ 51263);

var _class;



















function AddDetailPanelPage_div_9_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](0, "div", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵi18n"](1, 29);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵi18nExp"](ctx_r0.slippageTolerance)(ctx_r0.quotePanel.coin);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵi18nApply"](1);
  }
}
function AddDetailPanelPage_ng_container_33_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](1, "div", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵi18n"](2, 30);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](3, "div", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtextInterpolate"](ctx_r1.slippageTolerance);
  }
}
const _c14 = () => ({
  removeZero: true
});
/**
 * 添加流动性详情弹窗
 */
class AddDetailPanelPage extends _modules_page_module__WEBPACK_IMPORTED_MODULE_2__.CommonPageBase {
  constructor() {
    super(...arguments);
    /** 高级选项服务 */
    this.service = (0,_angular_core__WEBPACK_IMPORTED_MODULE_16__.inject)(_services_transaction_settings_transaction_settings_service__WEBPACK_IMPORTED_MODULE_4__.TransactionSettingsService);
    /** lp数量 */
    this.gainLPAmount = '0';
    /** 合约池份额 */
    this.lpShare = '';
    /** 手续费 */
    this.transactionFee = 0;
    /** 滑点 */
    this.slippageTolerance = '';
    /** 过期时间 */
    this.expirationTime = '';
    /** 是否首次添加 */
    this.isCreate = true;
    /** 签名参数 */
    this.transferOptions = undefined;
    /** 钱包服务 */
    this.walletService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_16__.inject)(_services_wallet_wallet_service__WEBPACK_IMPORTED_MODULE_7__.WalletService);
    /** 按钮文本 */
    this.btnText = "\u786E\u8BA4\u63D0\u4F9B\u6D41\u52A8\u6027";
    /** loading */
    this.loading = false;
    /** disabled */
    this.disabled = false;
    /** 卖币图标 */
    this.anchorCoinIcon = undefined;
    /** 卖链图标 */
    this.anchorChainIcon = undefined;
    /** 卖币图标 */
    this.quoteCoinIcon = undefined;
    /** 卖链图标 */
    this.quoteChainIcon = undefined;
    /** 返回类型 */
    this.returnValue$ = new _modules_page_module__WEBPACK_IMPORTED_MODULE_2__.PageReturnValue();
  }
  /** 初始化数据 */
  init() {
    var _slippageTolerance$la, _expirationTime$label;
    const {
      slippageTolerance,
      expirationTime
    } = this.service.getSelectedValue();
    const {
      poolDetail
    } = this;
    if (slippageTolerance === undefined || expirationTime === undefined || poolDetail === undefined) return;
    this.slippageTolerance = (_slippageTolerance$la = slippageTolerance === null || slippageTolerance === void 0 ? void 0 : slippageTolerance.label) !== null && _slippageTolerance$la !== void 0 ? _slippageTolerance$la : '';
    this.expirationTime = (_expirationTime$label = expirationTime === null || expirationTime === void 0 ? void 0 : expirationTime.label) !== null && _expirationTime$label !== void 0 ? _expirationTime$label : '';
    const {
      amount: anchorAmount
    } = this.anchorPanel;
    const {
      amount: quoteAmount
    } = this.quotePanel;
    const gainLPAmount = _bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_1__.calculateHelper.calculateLPCoinByAdd(new bignumber_js__WEBPACK_IMPORTED_MODULE_3__["default"](anchorAmount).multipliedBy(1e8).toString(), new bignumber_js__WEBPACK_IMPORTED_MODULE_3__["default"](quoteAmount).multipliedBy(1e8).toString(), this.poolDetail);
    this.gainLPAmount = gainLPAmount.toString();
    const total = new bignumber_js__WEBPACK_IMPORTED_MODULE_3__["default"](poolDetail.lpCoinsAmount).plus(gainLPAmount.toString());
    const lpShare = new bignumber_js__WEBPACK_IMPORTED_MODULE_3__["default"](gainLPAmount.toString()).div(total).multipliedBy(1e2);
    this.lpShare = _pipes_remove_trailing_zeros_remove_trailing_zeros_pipe__WEBPACK_IMPORTED_MODULE_8__.RemoveTrailingZerosPipe.transform(lpShare.toFixed(4, 1)) + '%';
    this.initIcon();
  }
  /** 提交 */
  submit() {
    var _this = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const {
        preParams,
        transferOptions
      } = _this;
      if (preParams === undefined || transferOptions === undefined) {
        _this.console.error('增流面板数据出错：', preParams, transferOptions);
        _bnqkl_framework_plugins_toast__WEBPACK_IMPORTED_MODULE_6__.Toast.show('数据出错');
        return;
      }
      _this.btnText = "\u7B7E\u540D\u8BF7\u6C42\u4E2D";
      _this.loading = true;
      _this.disabled = true;
      preParams.lpCoinsAmount = _this.gainLPAmount;
      const params = yield _this.walletService.getAddLiquidityOrderInfoWithSignature(preParams, transferOptions);
      if (_this.loading && params) {
        if (_environments_index__WEBPACK_IMPORTED_MODULE_9__.environment.DWEB_APP) {
          _plaoc_plugins__WEBPACK_IMPORTED_MODULE_10__.windowPlugin.focusWindow();
        }
        _this.returnValue$.return({
          transactionData: params
        });
        _this.nav.back();
      } else {
        if (params === undefined) {
          _bnqkl_framework_plugins_toast__WEBPACK_IMPORTED_MODULE_6__.Toast.show('无钱包连接');
        } else if (params === null) {
          if (_environments_index__WEBPACK_IMPORTED_MODULE_9__.environment.DWEB_APP) {
            _plaoc_plugins__WEBPACK_IMPORTED_MODULE_10__.windowPlugin.focusWindow();
          }
          _bnqkl_framework_plugins_toast__WEBPACK_IMPORTED_MODULE_6__.Toast.show('签名被拒绝');
        } else {
          _bnqkl_framework_plugins_toast__WEBPACK_IMPORTED_MODULE_6__.Toast.show('签名出错');
        }
        _this.btnText = "\u786E\u8BA4\u63D0\u4F9B\u6D41\u52A8\u6027";
        _this.console.error('签名出错:sinature:', params);
      }
      _this.disabled = false;
      _this.loading = false;
    })();
  }
  /** 关闭事件 */
  handleClose() {
    this.disabled = false;
    this.loading = false;
    _bnqkl_framework_plugins_toast__WEBPACK_IMPORTED_MODULE_6__.Toast.show('交易取消');
    this.nav.back();
  }
  /** 初始化图标 */
  initIcon() {
    const {
      anchorPanel,
      quotePanel
    } = this;
    this.anchorCoinIcon = (0,_services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_11__.transferToTokenIcon)(_services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_11__.NODE_CHAIN_NAME_TRANSFER_REVERSE[anchorPanel.chain], anchorPanel.coin);
    this.anchorChainIcon = (0,_services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_11__.transferToChainIcon)(anchorPanel.chain || 'Default');
    this.quoteCoinIcon = (0,_services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_11__.transferToTokenIcon)(_services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_11__.NODE_CHAIN_NAME_TRANSFER_REVERSE[quotePanel.chain], quotePanel.coin);
    this.quoteChainIcon = (0,_services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_11__.transferToChainIcon)(quotePanel.chain || 'Default');
  }
}
_class = AddDetailPanelPage;
_class.ɵfac = /*@__PURE__*/(() => {
  let ɵAddDetailPanelPage_BaseFactory;
  return function AddDetailPanelPage_Factory(t) {
    return (ɵAddDetailPanelPage_BaseFactory || (ɵAddDetailPanelPage_BaseFactory = _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵgetInheritedFactory"](_class)))(t || _class);
  };
})();
_class.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵdefineComponent"]({
  type: _class,
  selectors: [["bs-add-detail-panel-page"]],
  inputs: {
    isCreate: "isCreate",
    poolDetail: "poolDetail",
    preParams: "preParams",
    transferOptions: "transferOptions",
    anchorPanel: "anchorPanel",
    quotePanel: "quotePanel"
  },
  outputs: {
    returnValue$: "returnValue$"
  },
  standalone: true,
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵInheritDefinitionFeature"], _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵStandaloneFeature"]],
  decls: 47,
  vars: 33,
  consts: () => {
    let i18n_0;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_YOU_WILL_GET$$APPS_BFSWAP_SRC_COMPONENTS_ADD_DETAIL_PANEL_ADD_DETAIL_PANEL_COMPONENT_TS_1 = goog.getMsg("\u60A8\u5C06\u83B7\u5F97");
      i18n_0 = MSG_EXTERNAL_YOU_WILL_GET$$APPS_BFSWAP_SRC_COMPONENTS_ADD_DETAIL_PANEL_ADD_DETAIL_PANEL_COMPONENT_TS_1;
    } else {
      i18n_0 = "\u60A8\u5C06\u83B7\u5F97";
    }
    let i18n_2;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_LIQUIDITY_POOL_TOKEN_A$$APPS_BFSWAP_SRC_COMPONENTS_ADD_DETAIL_PANEL_ADD_DETAIL_PANEL_COMPONENT_TS_3 = goog.getMsg(" {$interpolation} - {$interpolation_1} LPcoin ", {
        "interpolation": "\uFFFD0\uFFFD",
        "interpolation_1": "\uFFFD1\uFFFD"
      }, {
        original_code: {
          "interpolation": "{{ anchorPanel.coin }}",
          "interpolation_1": "{{ quotePanel.coin }}"
        }
      });
      i18n_2 = MSG_EXTERNAL_LIQUIDITY_POOL_TOKEN_A$$APPS_BFSWAP_SRC_COMPONENTS_ADD_DETAIL_PANEL_ADD_DETAIL_PANEL_COMPONENT_TS_3;
    } else {
      i18n_2 = "" + "\uFFFD0\uFFFD" + " - " + "\uFFFD1\uFFFD" + " \u5408\u7EA6\u6C60\u6743\u76CA ";
    }
    let i18n_4;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_NEED_TO_TRANSFER_ASSETS$$APPS_BFSWAP_SRC_COMPONENTS_ADD_DETAIL_PANEL_ADD_DETAIL_PANEL_COMPONENT_TS_5 = goog.getMsg("Assets required");
      i18n_4 = MSG_EXTERNAL_NEED_TO_TRANSFER_ASSETS$$APPS_BFSWAP_SRC_COMPONENTS_ADD_DETAIL_PANEL_ADD_DETAIL_PANEL_COMPONENT_TS_5;
    } else {
      i18n_4 = "\u9700\u8F6C\u5165\u8D44\u4EA7";
    }
    let i18n_6;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_DEADLINE$$APPS_BFSWAP_SRC_COMPONENTS_ADD_DETAIL_PANEL_ADD_DETAIL_PANEL_COMPONENT_TS_7 = goog.getMsg("Deadline");
      i18n_6 = MSG_EXTERNAL_DEADLINE$$APPS_BFSWAP_SRC_COMPONENTS_ADD_DETAIL_PANEL_ADD_DETAIL_PANEL_COMPONENT_TS_7;
    } else {
      i18n_6 = "\u622A\u6B62\u65F6\u95F4";
    }
    let i18n_8;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_LIQUIDITY_POOL_SHARE$$APPS_BFSWAP_SRC_COMPONENTS_ADD_DETAIL_PANEL_ADD_DETAIL_PANEL_COMPONENT_TS_9 = goog.getMsg("Liquidity pool proportion");
      i18n_8 = MSG_EXTERNAL_LIQUIDITY_POOL_SHARE$$APPS_BFSWAP_SRC_COMPONENTS_ADD_DETAIL_PANEL_ADD_DETAIL_PANEL_COMPONENT_TS_9;
    } else {
      i18n_8 = "\u5408\u7EA6\u6C60\u4EFD\u989D";
    }
    let i18n_10;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_IF_THE_PRICE_EXCEEDS_YOUR_TRANSACTION_PLEASE_MAKE_SURE_YOU_LEAVE_ENOUGH_TO_PAY_ABOVE_FEE_OTHERWISE_IT_WILL_BE_CANCELED$$APPS_BFSWAP_SRC_COMPONENTS_ADD_DETAIL_PANEL_ADD_DETAIL_PANEL_COMPONENT_TS__11 = goog.getMsg(" If the price changes by more than {$interpolation}, your transaction will be relled back. Please reserve enough {$interpolation_1} for mining fees to ensure successful transactions. ", {
        "interpolation": "\uFFFD0\uFFFD",
        "interpolation_1": "\uFFFD1\uFFFD"
      }, {
        original_code: {
          "interpolation": "{{ slippageTolerance }}",
          "interpolation_1": "{{ quotePanel.coin }}"
        }
      });
      i18n_10 = MSG_EXTERNAL_IF_THE_PRICE_EXCEEDS_YOUR_TRANSACTION_PLEASE_MAKE_SURE_YOU_LEAVE_ENOUGH_TO_PAY_ABOVE_FEE_OTHERWISE_IT_WILL_BE_CANCELED$$APPS_BFSWAP_SRC_COMPONENTS_ADD_DETAIL_PANEL_ADD_DETAIL_PANEL_COMPONENT_TS__11;
    } else {
      i18n_10 = "\u5982\u679C\u4EF7\u683C\u53D8\u5316\u8D85\u8FC7 " + "\uFFFD0\uFFFD" + ", \u60A8\u7684\u4EA4\u6613\u5C06\u88AB\u56DE\u9000\u3002\u8BF7\u4FDD\u8BC1\u60A8\u7559\u6709\u8DB3\u591F " + "\uFFFD1\uFFFD" + " \u652F\u4ED8\u4E0A\u94FE\u8D39\uFF0C\u5426\u5219\u4EA4\u6613\u5C06\u53D6\u6D88\u3002 ";
    }
    let i18n_12;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_SLIPPAGE_TOLERANCE$$APPS_BFSWAP_SRC_COMPONENTS_ADD_DETAIL_PANEL_ADD_DETAIL_PANEL_COMPONENT_TS__13 = goog.getMsg("Slippage Tolerance");
      i18n_12 = MSG_EXTERNAL_SLIPPAGE_TOLERANCE$$APPS_BFSWAP_SRC_COMPONENTS_ADD_DETAIL_PANEL_ADD_DETAIL_PANEL_COMPONENT_TS__13;
    } else {
      i18n_12 = "\u6ED1\u70B9\u5BB9\u5FCD\u5EA6";
    }
    return [["headerTitle", i18n_0, 3, "hideBackButton", "titleClass", "headerClass", "contentBackground", "contentClass", "contentSafeArea"], ["endMenu", "", "bnRippleButton", "", 1, "icon-7", 3, "mode", "click"], ["name", "icon-popup-close"], [1, "rounded-4", "bg-base-300", "mb-6", "pt-6", "pb-4", "mt-2.5"], [1, "text-title-10", "mb-0.5", "text-center", "text-2xl", "font-extrabold"], [1, "text-gray-10", "text-center", "mb-6"], i18n_2, ["class", "text-base-200 text-xs px-4 text-center", 4, "ngIf"], [1, "text-base-200", "mb-1", "text-xs"], i18n_4, [1, "mb-2", "flex", "items-center"], [1, "icon-4", 3, "name"], [1, "ml-1", "text-title-10"], [1, "bg-blue-10", "ml-1", "flex", "items-center", "rounded-1", "pr-1"], [1, "text-primary", "text-xxxs"], [1, "ml-auto", "text-xs", "text-title-10", "font-medium"], [1, "mb-6", "flex", "items-center"], [1, "ml-1"], [1, "ml-auto", "text-title-10", "text-xs", "font-medium"], [1, "mb-6", "grid", "grid-cols-2", "items-center", "gap-y-1", "text-xs"], [4, "ngIf"], [1, "text-base-200"], i18n_6, [1, "text-title-10", "text-right", "font-medium"], i18n_8, ["bnRippleButton", "", 1, "bg-primary", "rounded-12", "mb-6", "flex", "h-12", "w-full", "items-center", "justify-center", "text-lg", "font-extrabold", "text-white", 3, "disabled", "click"], [1, "relative"], [1, "icon-6", "absolute", "-right-6", "top-0", 3, "loadingTheme", "showLoading"], [1, "text-base-200", "text-xs", "px-4", "text-center"], i18n_10, i18n_12];
  },
  template: function AddDetailPanelPage_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](0, "common-page", 0)(1, "button", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵlistener"]("click", function AddDetailPanelPage_Template_button_click_1_listener() {
        return ctx.handleClose();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelement"](2, "bs-icon", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](3, "div", 3)(4, "div", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtext"](5);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipe"](6, "amountFixed");
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](7, "div", 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵi18n"](8, 6);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtemplate"](9, AddDetailPanelPage_div_9_Template, 2, 2, "div", 7);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](10, "div", 8);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵi18n"](11, 9);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](12, "div", 10);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelement"](13, "bs-icon", 11);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](14, "span", 12);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtext"](15);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](16, "div", 13);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelement"](17, "bs-icon", 11);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](18, "span", 14);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtext"](19);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](20, "span", 15);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtext"](21);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](22, "div", 16);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelement"](23, "bs-icon", 11);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](24, "span", 17);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtext"](25);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](26, "div", 13);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelement"](27, "bs-icon", 11);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](28, "span", 14);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtext"](29);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](30, "span", 18);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtext"](31);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](32, "div", 19);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtemplate"](33, AddDetailPanelPage_ng_container_33_Template, 5, 1, "ng-container", 20);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](34, "div", 21);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵi18n"](35, 22);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](36, "div", 23);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtext"](37);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](38, "div", 21);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵi18n"](39, 24);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](40, "div", 23);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtext"](41);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](42, "section")(43, "button", 25);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵlistener"]("click", function AddDetailPanelPage_Template_button_click_43_listener() {
        return ctx.submit();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](44, "div", 26);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtext"](45);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelement"](46, "bn-loading-wrapper", 27);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]()()()();
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵproperty"]("hideBackButton", true)("titleClass", "!text-title-10")("headerClass", "pt-2.5 text-lg")("contentBackground", "white")("contentClass", "px-4")("contentSafeArea", true);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵproperty"]("mode", "icon");
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](4);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipeBind3"](6, 28, ctx.gainLPAmount, 8, _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpureFunction0"](32, _c14)), " ");
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵi18nExp"](ctx.anchorPanel.coin)(ctx.quotePanel.coin);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵi18nApply"](8);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵproperty"]("ngIf", !ctx.isCreate);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](4);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵproperty"]("name", ctx.quoteCoinIcon);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtextInterpolate1"](" ", ctx.quotePanel.coin, "");
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵproperty"]("name", ctx.quoteChainIcon);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtextInterpolate1"](" ", ctx.quotePanel.chain, "");
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtextInterpolate1"](" ", ctx.quotePanel.amount, "");
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵproperty"]("name", ctx.anchorCoinIcon);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtextInterpolate1"](" ", ctx.anchorPanel.coin, "");
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵproperty"]("name", ctx.anchorChainIcon);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtextInterpolate1"](" ", ctx.anchorPanel.chain, "");
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtextInterpolate1"](" ", ctx.anchorPanel.amount, "");
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵproperty"]("ngIf", !ctx.isCreate);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](4);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtextInterpolate"](ctx.expirationTime);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](4);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtextInterpolate"](ctx.lpShare);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵproperty"]("disabled", ctx.disabled);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtextInterpolate1"](" ", ctx.btnText, " ");
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵproperty"]("loadingTheme", "ellipsis")("showLoading", ctx.loading);
    }
  },
  dependencies: [_bnqkl_framework_pipes__WEBPACK_IMPORTED_MODULE_5__.AmountFixedPipe, _modules_page_module__WEBPACK_IMPORTED_MODULE_2__.CommonPageModule, _libs_bnf_components_ripple_button_ripple_button_directive__WEBPACK_IMPORTED_MODULE_12__.RippleButtonDirective, _angular_common__WEBPACK_IMPORTED_MODULE_17__.NgIf, _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_13__.CommonPageComponent, _icon_icon_component__WEBPACK_IMPORTED_MODULE_14__.IconComponent, _libs_bnf_components_loading_wrapper_loading_wrapper_component__WEBPACK_IMPORTED_MODULE_15__.LoadingWrapperComponent],
  encapsulation: 2,
  changeDetection: 0
});
(0,tslib__WEBPACK_IMPORTED_MODULE_18__.__decorate)([AddDetailPanelPage.OnInit(), (0,tslib__WEBPACK_IMPORTED_MODULE_18__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_18__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_18__.__metadata)("design:returntype", void 0)], AddDetailPanelPage.prototype, "init", null);
(0,tslib__WEBPACK_IMPORTED_MODULE_18__.__decorate)([AddDetailPanelPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_18__.__metadata)("design:type", Object)], AddDetailPanelPage.prototype, "gainLPAmount", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_18__.__decorate)([AddDetailPanelPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_18__.__metadata)("design:type", Object)], AddDetailPanelPage.prototype, "lpShare", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_18__.__decorate)([AddDetailPanelPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_18__.__metadata)("design:type", Object)], AddDetailPanelPage.prototype, "transactionFee", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_18__.__decorate)([AddDetailPanelPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_18__.__metadata)("design:type", Object)], AddDetailPanelPage.prototype, "slippageTolerance", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_18__.__decorate)([AddDetailPanelPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_18__.__metadata)("design:type", Object)], AddDetailPanelPage.prototype, "expirationTime", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_18__.__decorate)([AddDetailPanelPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_18__.__metadata)("design:type", Object)], AddDetailPanelPage.prototype, "btnText", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_18__.__decorate)([AddDetailPanelPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_18__.__metadata)("design:type", Object)], AddDetailPanelPage.prototype, "loading", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_18__.__decorate)([AddDetailPanelPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_18__.__metadata)("design:type", Object)], AddDetailPanelPage.prototype, "disabled", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_18__.__decorate)([AddDetailPanelPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_18__.__metadata)("design:type", Object)], AddDetailPanelPage.prototype, "anchorCoinIcon", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_18__.__decorate)([AddDetailPanelPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_18__.__metadata)("design:type", Object)], AddDetailPanelPage.prototype, "anchorChainIcon", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_18__.__decorate)([AddDetailPanelPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_18__.__metadata)("design:type", Object)], AddDetailPanelPage.prototype, "quoteCoinIcon", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_18__.__decorate)([AddDetailPanelPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_18__.__metadata)("design:type", Object)], AddDetailPanelPage.prototype, "quoteChainIcon", void 0);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (AddDetailPanelPage);

/***/ }),

/***/ 26193:
/*!*********************************************************************************************!*\
  !*** ./apps/bfswap/src/components/swap-token-chain-icon/swap-token-chain-icon.component.ts ***!
  \*********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   SwapTokenChainIconComponent: () => (/* binding */ SwapTokenChainIconComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! tslib */ 90505);
/* harmony import */ var _bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @bnqkl/bnqkl-swap-core */ 70195);
/* harmony import */ var _services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ~services/wallet/wallet.helper */ 84813);
/* harmony import */ var _modules_comp_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ~modules/comp.module */ 58281);
/* harmony import */ var _modules_page_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ~modules/page.module */ 16381);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 61039);
/* harmony import */ var _icon_icon_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../icon/icon.component */ 18840);
var _class;







/** 封装一层的链和币种图标组件 直接传链名和币种即可 */
class SwapTokenChainIconComponent extends _modules_comp_module__WEBPACK_IMPORTED_MODULE_2__.CommonCompBase {
  constructor() {
    super(...arguments);
    /** 图标的大小 */
    this.iconSize = 'icon-4';
    /** 图标名称 */
    this.iconName = 'token-Default';
  }
  init() {
    const {
      swapChainName,
      swapCoinName
    } = this;
    if (swapChainName) {
      let iconName = 'token-Default';
      const chainName = swapChainName in _bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_0__.BNQKL_SWAP_CHAIN_NAME ? _services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_1__.NODE_CHAIN_NAME_TRANSFER[swapChainName] : swapChainName;
      const chainIcon = (0,_services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_1__.transferToChainIcon)(chainName);
      iconName = chainIcon;
      if (swapCoinName) {
        const coinIcon = (0,_services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_1__.transferToTokenIconBychainName)(chainName, swapCoinName);
        iconName = coinIcon;
      }
      this.iconName = iconName;
    }
  }
}
_class = SwapTokenChainIconComponent;
_class.ɵfac = /*@__PURE__*/(() => {
  let ɵSwapTokenChainIconComponent_BaseFactory;
  return function SwapTokenChainIconComponent_Factory(t) {
    return (ɵSwapTokenChainIconComponent_BaseFactory || (ɵSwapTokenChainIconComponent_BaseFactory = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵgetInheritedFactory"](_class)))(t || _class);
  };
})();
_class.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineComponent"]({
  type: _class,
  selectors: [["bs-swap-token-chain-icon"]],
  inputs: {
    iconSize: "iconSize",
    swapChainName: "swapChainName",
    swapCoinName: "swapCoinName"
  },
  standalone: true,
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵInheritDefinitionFeature"], _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵStandaloneFeature"]],
  decls: 1,
  vars: 3,
  consts: [[3, "name"]],
  template: function SwapTokenChainIconComponent_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](0, "bs-icon", 0);
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵclassMap"](ctx.iconSize);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("name", ctx.iconName);
    }
  },
  dependencies: [_modules_page_module__WEBPACK_IMPORTED_MODULE_3__.CommonPageModule, _icon_icon_component__WEBPACK_IMPORTED_MODULE_4__.IconComponent],
  styles: ["[_nghost-%COMP%] {\n  display: flex;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL2FwcHMvYmZzd2FwL3NyYy9jb21wb25lbnRzL3N3YXAtdG9rZW4tY2hhaW4taWNvbi9zd2FwLXRva2VuLWNoYWluLWljb24uY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxhQUFBO0FBQ0oiLCJzb3VyY2VzQ29udGVudCI6WyI6aG9zdHtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbn0iXSwic291cmNlUm9vdCI6IiJ9 */"],
  changeDetection: 0
});
(0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([SwapTokenChainIconComponent.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__metadata)("design:type", String)], SwapTokenChainIconComponent.prototype, "iconName", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([SwapTokenChainIconComponent.OnChanges(), (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__metadata)("design:returntype", void 0)], SwapTokenChainIconComponent.prototype, "init", null);

/***/ }),

/***/ 11342:
/*!*********************************************************************************************!*\
  !*** ./apps/bfswap/src/components/token-with-chain-icon/token-with-chain-icon.component.ts ***!
  \*********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   TokenWithnChainIconComponent: () => (/* binding */ TokenWithnChainIconComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! tslib */ 90505);
/* harmony import */ var _bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @bnqkl/bnqkl-swap-core */ 70195);
/* harmony import */ var _services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ~services/wallet/wallet.helper */ 84813);
/* harmony import */ var _modules_comp_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ~modules/comp.module */ 58281);
/* harmony import */ var _modules_page_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ~modules/page.module */ 16381);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 61039);
/* harmony import */ var _icon_icon_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../icon/icon.component */ 18840);
var _class;







function TokenWithnChainIconComponent_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](1, "bs-icon", 1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵstyleMap"](ctx_r0.sizeClass.chainTranslate);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵstyleMap"](ctx_r0.sizeClass.chainSize);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("name", ctx_r0.chainName);
  }
}
/** Token和chain组合图标 */
class TokenWithnChainIconComponent extends _modules_comp_module__WEBPACK_IMPORTED_MODULE_2__.CommonCompBase {
  constructor() {
    super(...arguments);
    /** token的大小 */
    this.tokenSize = 'icon-8';
    /** chain的大小 */
    this.chainSize = 'icon-4';
    /** 尺寸默认32 */
    this.size = 0;
    /** 尺寸样式 */
    this.sizeClass = {
      chainSize: 'font-size:1rem',
      coinSize: 'font-size:2rem',
      chainTranslate: 'transform: translate(6px,8px)'
    };
  }
  /** 初始化参数 */
  init() {
    this.handleIcon();
    this.handleSize();
  }
  /** 处理尺寸 */
  handleSize() {
    const {
      size
    } = this;
    if (size > 0) {
      const CHAINSIZE = 16;
      const COINSIZE = 32;
      const TRANSLATEX = 6;
      const TRANSLATEY = 8;
      const times = size / COINSIZE;
      this.sizeClass.chainSize = `font-size:${CHAINSIZE * times}px`;
      this.sizeClass.coinSize = `font-size:${COINSIZE * times}px`;
      this.sizeClass.chainTranslate = `transform: translate(${TRANSLATEX * times}px,${TRANSLATEY * times}px)`;
    }
  }
  /** 处理图标名称 */
  handleIcon() {
    const {
      swapChainName,
      swapCoinName
    } = this;
    if (swapChainName) {
      const chainName = swapChainName in _bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_0__.BNQKL_SWAP_CHAIN_NAME ? _services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_1__.NODE_CHAIN_NAME_TRANSFER[swapChainName] : swapChainName;
      const chainIcon = (0,_services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_1__.transferToChainIcon)(chainName);
      this.chainName = chainIcon;
      if (swapCoinName) {
        const coinIcon = (0,_services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_1__.transferToTokenIconBychainName)(chainName, swapCoinName);
        this.tokenName = coinIcon;
      }
    }
  }
}
_class = TokenWithnChainIconComponent;
_class.ɵfac = /*@__PURE__*/(() => {
  let ɵTokenWithnChainIconComponent_BaseFactory;
  return function TokenWithnChainIconComponent_Factory(t) {
    return (ɵTokenWithnChainIconComponent_BaseFactory || (ɵTokenWithnChainIconComponent_BaseFactory = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵgetInheritedFactory"](_class)))(t || _class);
  };
})();
_class.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineComponent"]({
  type: _class,
  selectors: [["bs-token-with-chain-icon"]],
  inputs: {
    tokenSize: "tokenSize",
    tokenName: "tokenName",
    chainSize: "chainSize",
    chainName: "chainName",
    size: "size",
    swapChainName: "swapChainName",
    swapCoinName: "swapCoinName"
  },
  standalone: true,
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵInheritDefinitionFeature"], _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵStandaloneFeature"]],
  decls: 3,
  vars: 4,
  consts: [[1, "relative", "flex", "items-center", "justify-center"], [3, "name"], ["class", "bg-blue-10 rounded-1 absolute bottom-0 right-0 flex  items-center justify-center border-[2px] border-white", 3, "style"], [1, "bg-blue-10", "rounded-1", "absolute", "bottom-0", "right-0", "flex", "items-center", "justify-center", "border-[2px]", "border-white"]],
  template: function TokenWithnChainIconComponent_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 0);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](1, "bs-icon", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](2, TokenWithnChainIconComponent_Conditional_2_Template, 2, 5, "div", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵstyleMap"](ctx.sizeClass.coinSize);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("name", ctx.tokenName);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵconditional"](2, ctx.chainName ? 2 : -1);
    }
  },
  dependencies: [_modules_page_module__WEBPACK_IMPORTED_MODULE_3__.CommonPageModule, _icon_icon_component__WEBPACK_IMPORTED_MODULE_4__.IconComponent],
  encapsulation: 2,
  changeDetection: 0
});
(0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([TokenWithnChainIconComponent.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__metadata)("design:type", Object)], TokenWithnChainIconComponent.prototype, "sizeClass", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([TokenWithnChainIconComponent.OnChanges(), (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__metadata)("design:returntype", void 0)], TokenWithnChainIconComponent.prototype, "init", null);

/***/ }),

/***/ 89594:
/*!************************************************************************!*\
  !*** ./apps/bfswap/src/pages/add-liquidity/add-liquidity.component.ts ***!
  \************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AddLiquidityPage: () => (/* binding */ AddLiquidityPage),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 52542);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(/*! tslib */ 90505);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(/*! @angular/common */ 6729);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! @angular/core */ 61039);
/* harmony import */ var _components_add_detail_panel_add_detail_panel_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ~components/add-detail-panel/add-detail-panel.component */ 9038);
/* harmony import */ var _modules_page_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ~modules/page.module */ 16381);
/* harmony import */ var _components_order_settings_order_settings_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ~components/order-settings/order-settings.component */ 67877);
/* harmony import */ var _services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ~services/wallet/wallet.helper */ 84813);
/* harmony import */ var _bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @bnqkl/bnqkl-swap-core */ 70195);
/* harmony import */ var _components_select_token_panel_select_token_panel_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ~components/select-token-panel/select-token-panel.component */ 87002);
/* harmony import */ var _services_liquidity_pool_liquidity_pool_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ~services/liquidity-pool/liquidity-pool.service */ 20213);
/* harmony import */ var _bnqkl_framework_plugins_toast__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @bnqkl/framework/plugins/toast */ 18030);
/* harmony import */ var _services_wallet_wallet_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ~services/wallet/wallet.service */ 54275);
/* harmony import */ var _services_liquidity_order_liquidity_order_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ~services/liquidity-order/liquidity-order.service */ 84435);
/* harmony import */ var _components_connect_wallet_panel_connect_wallet_panel_type__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ~components/connect-wallet-panel/connect-wallet-panel.type */ 9218);
/* harmony import */ var _components_connect_wallet_panel_connect_wallet_penel_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ~components/connect-wallet-panel/connect-wallet-penel.component */ 43551);
/* harmony import */ var _bnqkl_wallet_base_services__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @bnqkl/wallet-base/services */ 62479);
/* harmony import */ var _bnqkl_framework_pipes__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @bnqkl/framework/pipes */ 80909);
/* harmony import */ var _services_transaction_settings_transaction_settings_service__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ~services/transaction-settings/transaction-settings.service */ 80348);
/* harmony import */ var _bnqkl_util_web_extends_promise__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @bnqkl/util-web/extends-promise */ 87778);
/* harmony import */ var bignumber_js__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! bignumber.js */ 61994);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! @angular/forms */ 7820);
/* harmony import */ var _bnqkl_wallet_base_tools__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @bnqkl/wallet-base/tools */ 38881);
/* harmony import */ var _services_liquidity_pool_liquidity_pool_helper__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ~services/liquidity-pool/liquidity-pool.helper */ 17827);
/* harmony import */ var _pipes_remove_trailing_zeros_remove_trailing_zeros_pipe__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ~pipes/remove-trailing-zeros/remove-trailing-zeros.pipe */ 53494);
/* harmony import */ var _add_liquidity_type__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! ./add-liquidity.type */ 97684);
/* harmony import */ var _libs_bnf_modules_bottom_sheet_components_bottom_sheet_component__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! ../../../../../libs/bnf/modules/bottom-sheet/components/bottom-sheet.component */ 94072);
/* harmony import */ var _libs_bnf_components_ripple_button_ripple_button_directive__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! ../../../../../libs/bnf/components/ripple-button/ripple-button.directive */ 16505);
/* harmony import */ var _libs_bnf_directives_auto_complete_off_directive__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! ../../../../../libs/bnf/directives/auto-complete-off.directive */ 66722);
/* harmony import */ var _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! ../../../../../libs/bnf/modules/page/common-page/common-page.component */ 62052);
/* harmony import */ var _components_icon_icon_component__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! ../../components/icon/icon.component */ 18840);
/* harmony import */ var _libs_bnf_components_loading_wrapper_loading_wrapper_component__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! ../../../../../libs/bnf/components/loading-wrapper/loading-wrapper.component */ 51263);

var _class;


































const _c0 = ["anchorInputRef"];
const _c1 = ["quoteInputRef"];
function AddLiquidityPage_Conditional_13_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](0, "div", 35);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelement"](1, "bs-icon", 36);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](2, "div", 37);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("name", ctx_r0.quotePanel.chainIcon);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtextInterpolate1"](" ", ctx_r0.quotePanel.chain, " ");
  }
}
function AddLiquidityPage_Conditional_15_Template(rf, ctx) {
  if (rf & 1) {
    const _r18 = _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](0, "div", 38);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵlistener"]("click", function AddLiquidityPage_Conditional_15_Template_div_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵrestoreView"](_r18);
      const ctx_r17 = _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵresetView"](ctx_r17.openSelectAssetSheet(ctx_r17.OPERATE.QUOTE));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](1, "div", 39);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵi18n"](2, 40);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelement"](3, "bs-icon", 41);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("mode", "icon");
  }
}
function AddLiquidityPage_Conditional_16_Template(rf, ctx) {
  if (rf & 1) {
    const _r20 = _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](0, "div", 42);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵlistener"]("click", function AddLiquidityPage_Conditional_16_Template_div_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵrestoreView"](_r20);
      const ctx_r19 = _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵresetView"](ctx_r19.openSelectAssetSheet(ctx_r19.OPERATE.QUOTE));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelement"](1, "bs-icon", 43);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](2, "span", 44);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](4, "button", 45);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelement"](5, "bs-icon", 46);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("name", ctx_r2.quotePanel.coinIcon);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtextInterpolate"](ctx_r2.quotePanel.coin);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("mode", "icon");
  }
}
function AddLiquidityPage_Conditional_23_Template(rf, ctx) {
  if (rf & 1) {
    const _r22 = _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](0, "button", 47);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵlistener"]("click", function AddLiquidityPage_Conditional_23_Template_button_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵrestoreView"](_r22);
      const ctx_r21 = _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵresetView"](ctx_r21.handleMaxBtn(ctx_r21.OPERATE.QUOTE));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵi18n"](1, 48);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
  }
}
function AddLiquidityPage_Conditional_30_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](0, "div", 35);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelement"](1, "bs-icon", 36);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](2, "div", 37);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("name", ctx_r5.anchorPanel.chainIcon);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtextInterpolate1"](" ", ctx_r5.anchorPanel.chain, " ");
  }
}
function AddLiquidityPage_Conditional_32_Template(rf, ctx) {
  if (rf & 1) {
    const _r24 = _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](0, "div", 38);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵlistener"]("click", function AddLiquidityPage_Conditional_32_Template_div_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵrestoreView"](_r24);
      const ctx_r23 = _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵresetView"](ctx_r23.openSelectAssetSheet(ctx_r23.OPERATE.ANCHOR));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](1, "div", 39);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵi18n"](2, 49);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelement"](3, "bs-icon", 41);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("mode", "icon");
  }
}
function AddLiquidityPage_Conditional_33_Template(rf, ctx) {
  if (rf & 1) {
    const _r26 = _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](0, "div", 42);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵlistener"]("click", function AddLiquidityPage_Conditional_33_Template_div_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵrestoreView"](_r26);
      const ctx_r25 = _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵresetView"](ctx_r25.openSelectAssetSheet(ctx_r25.OPERATE.ANCHOR));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelement"](1, "bs-icon", 50);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](2, "span", 44);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](4, "button", 45);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelement"](5, "bs-icon", 46);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r7 = _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("defaultName", "token-Default")("name", ctx_r7.anchorPanel.coinIcon);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtextInterpolate"](ctx_r7.anchorPanel.coin);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("mode", "icon");
  }
}
function AddLiquidityPage_Conditional_40_Template(rf, ctx) {
  if (rf & 1) {
    const _r28 = _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](0, "button", 47);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵlistener"]("click", function AddLiquidityPage_Conditional_40_Template_button_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵrestoreView"](_r28);
      const ctx_r27 = _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵresetView"](ctx_r27.handleMaxBtn(ctx_r27.OPERATE.ANCHOR));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵi18n"](1, 51);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
  }
}
function AddLiquidityPage_div_42_img_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelement"](0, "img", 56);
  }
}
function AddLiquidityPage_div_42_img_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelement"](0, "img", 57);
  }
}
function AddLiquidityPage_div_42_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](0, "div", 52);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtemplate"](1, AddLiquidityPage_div_42_img_1_Template, 1, 0, "img", 53)(2, AddLiquidityPage_div_42_img_2_Template, 1, 0, "img", 54);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](3, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵi18n"](4, 55);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r10 = _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("ngIf", ctx_r10.gasFeePre.success);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("ngIf", !ctx_r10.gasFeePre.success);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵclassMapInterpolate1"]("", ctx_r10.gasFeePre.success ? "text-green-20" : "text-red-10", "  ml-2 text-xs");
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵi18nExp"](ctx_r10.gasFeePre.text);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵi18nApply"](4);
  }
}
const _c20 = () => ({
  "--color-1": "#7a7b90"
});
function AddLiquidityPage_div_47_Template(rf, ctx) {
  if (rf & 1) {
    const _r32 = _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](0, "div", 58)(1, "span", 59);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](3, "bs-icon", 60);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵlistener"]("click", function AddLiquidityPage_div_47_Template_bs_icon_click_3_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵrestoreView"](_r32);
      const ctx_r31 = _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵresetView"](ctx_r31.handleReversePrice());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r11 = _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtextInterpolate3"]("1 ", ctx_r11.price.leftCoin, " = ", ctx_r11.price.showPrice, " ", ctx_r11.price.rightCoin, "");
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("ngStyle", _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵpureFunction0"](4, _c20));
  }
}
function AddLiquidityPage_div_48_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](0, "div", 61);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵi18n"](1, 62);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r12 = _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵi18nExp"](ctx_r12.anchorPanel.coin)(ctx_r12.quotePanel.coin);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵi18nApply"](1);
  }
}
function AddLiquidityPage_ng_template_50_Template(rf, ctx) {
  if (rf & 1) {
    const _r34 = _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](0, "bs-add-detail-panel-page", 63);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵlistener"]("returnValue$", function AddLiquidityPage_ng_template_50_Template_bs_add_detail_panel_page_returnValue__0_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵrestoreView"](_r34);
      const ctx_r33 = _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵresetView"](ctx_r33.onAddLIquiditySubmited($event));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r13 = _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("poolDetail", ctx_r13.poolDetail)("anchorPanel", ctx_r13.anchorPanel)("quotePanel", ctx_r13.quotePanel)("isCreate", ctx_r13.showCreatePoolTip)("preParams", ctx_r13.preParams)("transferOptions", ctx_r13.transferOptions);
  }
}
function AddLiquidityPage_ng_template_52_Template(rf, ctx) {
  if (rf & 1) {
    const _r36 = _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](0, "bs-order-settings-page", 64);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵlistener"]("returnValue$", function AddLiquidityPage_ng_template_52_Template_bs_order_settings_page_returnValue__0_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵrestoreView"](_r36);
      const ctx_r35 = _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵresetView"](ctx_r35.onAdvancedSettinged($event));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r14 = _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("showSlippages", !ctx_r14.showCreatePoolTip)("showAddLiquidityRatio", false);
  }
}
function AddLiquidityPage_ng_template_54_Template(rf, ctx) {
  if (rf & 1) {
    const _r38 = _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](0, "bs-select-token-panel-page", 65);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵlistener"]("returnValue$", function AddLiquidityPage_ng_template_54_Template_bs_select_token_panel_page_returnValue__0_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵrestoreView"](_r38);
      const ctx_r37 = _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵresetView"](ctx_r37.onSelectToken($event));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r15 = _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("liquidityPoolAssetsInfo", ctx_r15.selectAssetSheet.data.liquidityPoolAssetsInfo)("selectedAsset", ctx_r15.selectAssetSheet.data.selectedAsset)("disabledAsset", ctx_r15.selectAssetSheet.data.disabledAsset)("chainGroupInfo", ctx_r15.selectAssetSheet.data.chainGroupInfo)("onlyUSDM", ctx_r15.selectAssetSheet.data.onlyUSDM)("noUSDM", ctx_r15.selectAssetSheet.data.noUSDM);
  }
}
function AddLiquidityPage_ng_template_56_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelement"](0, "bs-connect-wallet-panel-page", 66);
  }
  if (rf & 2) {
    const ctx_r16 = _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("connectType", ctx_r16.selectWalletSheet.conncetType)("presetWallets", ctx_r16.selectWalletSheet.presetWallets);
  }
}
/** 增加流动性 */
class AddLiquidityPage extends _modules_page_module__WEBPACK_IMPORTED_MODULE_2__.CommonPageBase {
  constructor() {
    super(...arguments);
    /** 订单服务 */
    this.orderService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_28__.inject)(_services_liquidity_order_liquidity_order_service__WEBPACK_IMPORTED_MODULE_10__.LiquidityOrderService);
    /** 给页面用的枚举 赋值给属性 */
    this.OPERATE = _add_liquidity_type__WEBPACK_IMPORTED_MODULE_21__.OPERATE;
    /** 操作类型 买和卖 */
    this.operate = _add_liquidity_type__WEBPACK_IMPORTED_MODULE_21__.OPERATE.ANCHOR;
    /** 最后一次输入 */
    this.lastInput = undefined;
    /** 合约池服务 */
    this.poolService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_28__.inject)(_services_liquidity_pool_liquidity_pool_service__WEBPACK_IMPORTED_MODULE_7__.LiquidityPoolService);
    /** 合约池列表 */
    this.poolList = [];
    /** 钱包服务 */
    this.walletService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_28__.inject)(_services_wallet_wallet_service__WEBPACK_IMPORTED_MODULE_9__.WalletService);
    /** 滑点容忍度 */
    this.slippageTolerance = '';
    /** 过期时间 */
    this.expirationTime = 0;
    /** 已连接钱包 */
    this.connectedWallet = this.walletService.connectedWallet;
    /** 按钮的文字 */
    this.btnText = '连接钱包';
    /** 按钮是否禁用 */
    this.btnDisabled = false;
    /** loading状态 */
    this.btnLoading = false;
    /** 按钮对应的事件 */
    this.btnEvent = this.openConnectWalletPanel;
    /** 高级设置服务 */
    this.settingsService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_28__.inject)(_services_transaction_settings_transaction_settings_service__WEBPACK_IMPORTED_MODULE_15__.TransactionSettingsService);
    /** 从别的页面跳转来的 */
    this.fromRouter = false;
    /** 大个按钮上的loading  */
    this.loading = false;
    /** 汇率对象  */
    this.price = {
      leftCoin: _bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_5__.BNQKL_SWAP_COIN_NAME.USDM,
      rightCoin: undefined,
      forwordPrice: _services_liquidity_pool_liquidity_pool_helper__WEBPACK_IMPORTED_MODULE_19__.PRICE_NONE.AMOUNT_NONE,
      backwordPirce: _services_liquidity_pool_liquidity_pool_helper__WEBPACK_IMPORTED_MODULE_19__.PRICE_NONE.AMOUNT_NONE,
      showPrice: _services_liquidity_pool_liquidity_pool_helper__WEBPACK_IMPORTED_MODULE_19__.PRICE_NONE.AMOUNT_NONE,
      direction: _services_liquidity_pool_liquidity_pool_helper__WEBPACK_IMPORTED_MODULE_19__.PRICE_DIRECTION.FORWARD
    };
    /** 钱包选择器的数据 */
    this.selectWalletSheet = {
      is_open: false,
      conncetType: _components_connect_wallet_panel_connect_wallet_panel_type__WEBPACK_IMPORTED_MODULE_11__.CONNECT_TYPE.CONNECT_WALLET,
      presetWallets: []
    };
    /** 汇率动画开光 */
    this.rateAnimationState = false;
    /** 添加流动性提交面板的数据 */
    this.swapSheet = {
      is_open: false
    };
    /** 签名参数 */
    this.preParams = undefined;
    /** 签名参数 */
    this.transferOptions = undefined;
    /** 锚定的各项参数 */
    this.anchorPanel = {
      coinIcon: undefined,
      chainIcon: undefined,
      chain: undefined,
      coin: undefined,
      amount: '',
      balance: '- -'
    };
    /** 报价的各项参数 */
    this.quotePanel = {
      coinIcon: undefined,
      chainIcon: undefined,
      chain: undefined,
      coin: undefined,
      amount: '',
      balance: '- -'
    };
    this.showGasTip = false;
    this.gasFeeTipList = [];
    /** 按钮事件列表 */
    this.btnObjList = [{
      text: '暂无该币种池子',
      disabled: true,
      check: this.checkPool.bind(this),
      event: undefined
    }, {
      text: "\u8FDE\u63A5\u94B1\u5305",
      disabled: false,
      check: this.checkWallet.bind(this),
      event: this.openConnectWalletPanel
    }, {
      text: "\u9009\u62E9\u8D44\u4EA7",
      disabled: false,
      check: this.checkToken.bind(this),
      event: this.openSelectAssetSheet
    }, {
      text: "\u6B63\u5728\u83B7\u53D6\u6570\u636E",
      disabled: true,
      check: () => !this.loading,
      event: undefined
    }, {
      text: "\u8F93\u5165\u6570\u91CF",
      disabled: false,
      check: this.checkAmount.bind(this),
      event: this.onManuallyFocus
    }, {
      text: "\u81F3\u5C11\u9700\u898110 USDM",
      disabled: true,
      check: this.checkLeastUSDMAmount.bind(this),
      event: undefined
    }, {
      text: '余额不足',
      disabled: true,
      check: this.checkGasFee.bind(this),
      event: undefined
    }, {
      text: () => this.anchorPanel.coin + ' ' + "\u4F59\u989D\u4E0D\u8DB3",
      disabled: true,
      check: this.checkAnchorBalance.bind(this),
      event: undefined
    }, {
      text: () => this.quotePanel.coin + ' ' + "\u4F59\u989D\u4E0D\u8DB3",
      disabled: true,
      check: this.checkQuoteBalance.bind(this),
      event: undefined
    }, {
      text: "\u6570\u91CF\u4E0D\u80FD\u4E3A\u96F6",
      disabled: true,
      check: this.checkZero.bind(this),
      event: undefined
    }, {
      text: "\u589E\u52A0\u6D41\u52A8\u6027",
      disabled: false,
      check: () => false,
      event: this.openAddSheet
    }];
    /** 添加流动性提交面板的数据 */
    this.addLiquiditySheet = {
      is_open: false
    };
    /** 选择币种面板 */
    this.selectAssetSheet = {
      isOpen: false,
      data: {
        liquidityPoolAssetsInfo: [],
        selectedAsset: [{
          tokenName: 'USDM',
          chainName: _bnqkl_wallet_base_services__WEBPACK_IMPORTED_MODULE_13__.CHAIN_NAME.PMChain
        }],
        disabledAsset: [{
          tokenName: 'USDM',
          chainName: _bnqkl_wallet_base_services__WEBPACK_IMPORTED_MODULE_13__.CHAIN_NAME.PMChain
        }],
        chainGroupInfo: [],
        noUSDM: false,
        onlyUSDM: true
      }
    };
    /** 报价币主币种 */
    this.anchorMainCoin = '';
    /** 锚定币主币种 */
    this.quoteMainCoin = '';
    /** 报价币矿工费 */
    this.anchorGasFee = '';
    /** 锚定币矿工费 */
    this.quoteGasFee = '';
    /** 高级设置弹窗设置 */
    this.advancedSettingsSheet = {
      is_open: false
    };
    /** 点击max标识 */
    this.maxMode = false;
    /** 代币精确度 */
    this.DECIMALS = 8;
    this.anchorControl = new _angular_forms__WEBPACK_IMPORTED_MODULE_29__.FormControl('', {
      validators: [control => {
        // 矫正输入
        const inputValue = String(control.value);
        const value = (0,_bnqkl_wallet_base_tools__WEBPACK_IMPORTED_MODULE_18__.getValueByDecimalsRange)(inputValue, this.DECIMALS);
        if (value !== inputValue) {
          control.setValue(value);
        }
        return null;
      }]
    });
    this.quoteControl = new _angular_forms__WEBPACK_IMPORTED_MODULE_29__.FormControl('', {
      validators: [control => {
        // 矫正输入
        const inputValue = String(control.value);
        const value = (0,_bnqkl_wallet_base_tools__WEBPACK_IMPORTED_MODULE_18__.getValueByDecimalsRange)(inputValue, this.DECIMALS);
        if (value !== inputValue) {
          control.setValue(value);
        }
        return null;
      }]
    });
  }
  iniParams() {
    const {
      params
    } = this;
    if (params) {
      const {
        anchorCoinName,
        anchorChainName,
        quoteCoinName,
        quoteChainName
      } = params;
      if (anchorCoinName && anchorChainName && quoteCoinName && quoteChainName) {
        const option = {
          quoteChainName: _bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_5__.BNQKL_SWAP_CHAIN_NAME.SWAP,
          quoteCoinsName: _bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_5__.BNQKL_SWAP_COIN_NAME.USDM,
          anchorChainName: anchorChainName,
          anchorCoinsName: anchorCoinName
        };
        const poolIds = this.poolService.getPoolIdBytoken(option);
        if (poolIds.length > 0) {
          this.fromRouter = true;
          this.poolService.startQueryPoolTask([poolIds[0]]);
        }
        this.setCoinData(_services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_4__.NODE_CHAIN_NAME_TRANSFER[anchorChainName], anchorCoinName, _add_liquidity_type__WEBPACK_IMPORTED_MODULE_21__.OPERATE.ANCHOR);
      } else {
        this.initDefaultQuoteCoin();
      }
      this.changeViewBalanceAmount();
    }
  }
  /** 处理路由选中币种 */
  handleRouerSelectCoin(pool) {
    this.fromRouter = false;
    let smallU = undefined;
    pool.quoteAssociatedCoins.forEach(item => {
      if (smallU === undefined) {
        smallU = item;
      } else if (Number(item.amount) > Number(smallU.amount)) {
        smallU = item;
      }
    });
    if (smallU === undefined) {
      throw new Error('没有找到小U');
    }
    const {
      chainName,
      coinName
    } = smallU;
    this.setCoinData(_services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_4__.NODE_CHAIN_NAME_TRANSFER[chainName], coinName, _add_liquidity_type__WEBPACK_IMPORTED_MODULE_21__.OPERATE.QUOTE);
    this.handlePriceCaculate();
  }
  /** 反转价格 */
  handleReversePrice() {
    Object.assign(this.price, (0,_services_liquidity_pool_liquidity_pool_helper__WEBPACK_IMPORTED_MODULE_19__.reversePriceUtil)(this.price));
  }
  /** 打开钱包连接面板 */
  openConnectWalletPanel() {
    var _this = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const {
        selectWalletSheet
      } = _this;
      if (selectWalletSheet.is_open) {
        return;
      }
      _this.selectWalletSheet.presetWallets = yield _this.walletService.getPresetWallet();
      selectWalletSheet.is_open = true;
    })();
  }
  onAddLIquiditySubmited(data) {
    var _this2 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const {
        transactionData
      } = data;
      _this2.loading = true;
      const res = yield _this2.orderService.addLiquidityOrder(transactionData);
      _this2.loading = false;
      _this2.console.log(res);
      if (res) {
        _this2.anchorPanel.amount = '';
        _this2.quotePanel.amount = '';
        _this2.checkEventList();
        _bnqkl_framework_plugins_toast__WEBPACK_IMPORTED_MODULE_8__.Toast.show('增流交易已提交');
        yield (0,_bnqkl_util_web_extends_promise__WEBPACK_IMPORTED_MODULE_16__.sleep)(500);
        _this2.nav.routeTo('/mine/my-record', {
          index: 0
        });
      } else {
        _bnqkl_framework_plugins_toast__WEBPACK_IMPORTED_MODULE_8__.Toast.show('添加流动性失败');
      }
    })();
  }
  /** 池子的工具方法 */
  poolUtil() {
    const {
      anchorPanel,
      quotePanel,
      poolDetail
    } = this;
    const {
      coin: anchorCoin,
      chain: anchorChain,
      amount: anchorAmount
    } = anchorPanel;
    const {
      coin: quoteCoin,
      chain: quoteChain,
      amount: quoteAmount
    } = quotePanel;
    let poolId = [];
    if (quoteChain && anchorChain && quoteCoin && anchorCoin) {
      const option = {
        quoteChainName: _services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_4__.NODE_CHAIN_NAME_TRANSFER_REVERSE[quoteChain],
        quoteCoinsName: quoteCoin,
        anchorChainName: _services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_4__.NODE_CHAIN_NAME_TRANSFER_REVERSE[anchorChain],
        anchorCoinsName: anchorCoin
      };
      const pool = this.poolService.getPoolIdBytoken(option);
      if (pool && pool.length > 0) {
        poolId = pool;
      }
    }
    return {
      anchorAmount,
      quoteAmount,
      anchorCoin,
      quoteCoin,
      anchorChain,
      quoteChain,
      poolDetail,
      poolId
    };
  }
  /** 非零检查 */
  checkZero() {
    const isZero = parseFloat(this.anchorPanel.amount) === 0 || parseFloat(this.quotePanel.amount) === 0;
    return isZero === false;
  }
  /** 至少10USDM检查 */
  checkLeastUSDMAmount() {
    const {
      quoteAmount,
      quoteCoin
    } = this.poolUtil();
    if (quoteAmount && quoteCoin) {
      return new bignumber_js__WEBPACK_IMPORTED_MODULE_17__["default"](quoteAmount).isGreaterThanOrEqualTo(10);
    }
    return true;
  }
  /** 检查是否有池子 */
  checkPool() {
    const {
      anchorChain,
      anchorCoin,
      quoteChain,
      quoteCoin
    } = this.poolUtil();
    const {
      loading
    } = this;
    if (anchorChain && anchorCoin && quoteChain && quoteCoin && loading === false) {
      return this.poolDetail !== undefined;
    }
    return true;
  }
  /** 初始化默认选择卖出币种 */
  initDefaultQuoteCoin() {
    const defaultPool = this.walletService.liquidityPoolAssetsListWithAmount.find(pool => {
      const coin = pool.tokenName === _bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_5__.BNQKL_SWAP_COIN_NAME.USDM;
      const chain = pool.chainName === _bnqkl_wallet_base_services__WEBPACK_IMPORTED_MODULE_13__.CHAIN_NAME.PMChain;
      return coin && chain;
    });
    if (defaultPool) {
      const {
        tokenName,
        chainName
      } = defaultPool;
      this.setCoinData(chainName, tokenName, _add_liquidity_type__WEBPACK_IMPORTED_MODULE_21__.OPERATE.QUOTE);
    }
  }
  /** 打开兑换面板 */
  openAddSheet() {
    var _this3 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      var _this3$connectedWalle, _this3$connectedWalle2;
      const userId = (_this3$connectedWalle = _this3.connectedWallet) === null || _this3$connectedWalle === void 0 ? void 0 : _this3$connectedWalle.pmchainAddress;
      const publicKey = (_this3$connectedWalle2 = _this3.connectedWallet) === null || _this3$connectedWalle2 === void 0 ? void 0 : _this3$connectedWalle2.pmchainPublicKey;
      const {
        poolDetail,
        anchorChain,
        quoteChain,
        anchorAmount,
        quoteAmount,
        anchorCoin,
        quoteCoin
      } = _this3.poolUtil();
      const {
        slippageTolerance,
        expirationTime
      } = _this3.settingsService.getSelectedValue();
      const {
        anchorGasFee,
        quoteGasFee
      } = _this3;
      if (quoteCoin === undefined || anchorCoin === undefined || slippageTolerance === undefined || expirationTime === undefined || poolDetail === undefined || userId === undefined || publicKey === undefined || anchorChain === undefined || quoteChain === undefined) {
        _this3.console.error('增流面板数据出错');
        _bnqkl_framework_plugins_toast__WEBPACK_IMPORTED_MODULE_8__.Toast.show('数据出错');
        throw new Error('增流面板数据出错');
      }
      const {
        anchorCoinsName,
        anchorCoinsChainName,
        poolId,
        anchorCoinsRecipientAddress,
        quoteCoinsRecipientAddress,
        quoteAssociatedCoins
      } = poolDetail;
      const isAnchor = anchorCoinsName === anchorCoin && _services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_4__.NODE_CHAIN_NAME_TRANSFER[anchorCoinsChainName] === anchorChain;
      const startTime = Date.now();
      const {
        showCreatePoolTip
      } = _this3;
      /** 首次添加流动性滑点为100% */
      const slippage = showCreatePoolTip ? '1' : slippageTolerance.value;
      const anchorChainName = _services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_4__.NODE_CHAIN_NAME_TRANSFER_REVERSE[anchorChain];
      const quoteChainName = _services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_4__.NODE_CHAIN_NAME_TRANSFER_REVERSE[quoteChain];
      const preParams = {
        type: _bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_5__.ORDER_RECORD_TYPES.ADD_LIQUIDITY,
        poolId,
        userId,
        slippageTolerance: slippage,
        startTime,
        expirationTime: startTime + Number(expirationTime.value),
        lpCoinsAmount: '0',
        anchorCoinsAmount: new bignumber_js__WEBPACK_IMPORTED_MODULE_17__["default"](anchorAmount).multipliedBy(1e8).toString(),
        quoteCoinsAmount: new bignumber_js__WEBPACK_IMPORTED_MODULE_17__["default"](quoteAmount).multipliedBy(1e8).toString(),
        transaction: {
          anchor: {
            chainName: anchorChainName,
            payload: undefined
          },
          quote: {
            chainName: quoteChainName,
            payload: undefined
          }
        },
        publicKey
      };
      const anchorReceiveAddress = isAnchor ? anchorCoinsRecipientAddress : quoteCoinsRecipientAddress;
      const anchorTransaction = {
        receiveAddress: anchorReceiveAddress,
        assetType: anchorCoin,
        amount: new bignumber_js__WEBPACK_IMPORTED_MODULE_17__["default"](anchorAmount).multipliedBy(1e8).toString(),
        fee: anchorGasFee
      };
      const targetChain = quoteAssociatedCoins.find(item => {
        return item.chainName === quoteChainName;
      });
      if (targetChain === undefined) {
        throw new Error('找不到对应小U');
      }
      const quoteReceiveAddress = targetChain.recipientAddress;
      const quoteTransaction = {
        receiveAddress: quoteReceiveAddress,
        assetType: quoteCoin,
        amount: new bignumber_js__WEBPACK_IMPORTED_MODULE_17__["default"](quoteAmount).multipliedBy(1e8).toString(),
        fee: quoteGasFee
      };
      const transferOption = {
        anchor: anchorTransaction,
        quote: quoteTransaction
      };
      _this3.preParams = preParams;
      _this3.transferOptions = transferOption;
      _this3.addLiquiditySheet.is_open = true;
    })();
  }
  /** 手动获取输入框焦点 */
  onManuallyFocus() {
    const inputList = [this.quoteInputRef, this.anchorInputRef];
    for (const input of inputList) {
      if (input) {
        const inputDom = input.nativeElement;
        if (Boolean(inputDom.value) === false) {
          inputDom.focus();
          break;
        }
      }
    }
  }
  /** 打开钱包连接选择弹窗 */
  openAddLiquiditySheet() {
    var _this4 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const {
        addLiquiditySheet
      } = _this4;
      if (addLiquiditySheet.is_open) {
        return;
      }
      addLiquiditySheet.is_open = true;
    })();
  }
  bindButton() {
    this.checkEventList();
  }
  get gasFeePre() {
    const a = this.gasFeeTipList[0];
    return a ? a : {
      success: false,
      text: ''
    };
  }
  /** 计算主币种信息 */
  calculateMainChainInfo(chain, type) {
    var _this5 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const config = _this5.walletService.CHAIN_CONFIG_MAP;
      const chainMap = config.get(chain);
      if (chainMap) {
        const mainCoin = chainMap.symbol;
        type === _add_liquidity_type__WEBPACK_IMPORTED_MODULE_21__.OPERATE.ANCHOR ? _this5.anchorMainCoin = mainCoin : _this5.quoteMainCoin = mainCoin;
      } else {
        throw new Error('没有找到主币种');
      }
      const gasfee = yield _this5.walletService.getBioforestChainFeeByChainName(chain);
      type === _add_liquidity_type__WEBPACK_IMPORTED_MODULE_21__.OPERATE.ANCHOR ? _this5.anchorGasFee = gasfee : _this5.quoteGasFee = gasfee;
    })();
  }
  /** 打开高级设置弹窗 */
  openAdvancedSettingsSheet() {
    var _this6 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const {
        advancedSettingsSheet
      } = _this6;
      if (advancedSettingsSheet.is_open) {
        return;
      }
      advancedSettingsSheet.is_open = true;
    })();
  }
  /** 高级设置事件 */
  onAdvancedSettinged(data) {
    var _this7 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this7.console.info('submit add liquid', data);
    })();
  }
  /** 当余额是 - - 或者 0 时不显示Max按钮 */
  showMax(operate) {
    const item = operate === _add_liquidity_type__WEBPACK_IMPORTED_MODULE_21__.OPERATE.ANCHOR ? this.anchorPanel : this.quotePanel;
    const balance = parseFloat(item.balance);
    return !Number.isNaN(balance) && balance !== 0;
  }
  /** 打开选择币种面板 */
  openSelectAssetSheet(operate) {
    var _this8 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      if (operate) {
        _this8.selectAssetSheet.data.onlyUSDM = operate === _add_liquidity_type__WEBPACK_IMPORTED_MODULE_21__.OPERATE.QUOTE;
        _this8.selectAssetSheet.data.noUSDM = operate === _add_liquidity_type__WEBPACK_IMPORTED_MODULE_21__.OPERATE.ANCHOR;
        _this8.operate = operate;
      } else {
        _this8.operate = _add_liquidity_type__WEBPACK_IMPORTED_MODULE_21__.OPERATE.ANCHOR;
        _this8.selectAssetSheet.data.noUSDM = true;
        _this8.selectAssetSheet.data.onlyUSDM = false;
      }
      _this8.setSelectAsset();
      _this8.selectAssetSheet.isOpen = true;
    })();
  }
  /** 检查矿工费 */
  checkGasFeeAndBalance(type) {
    var _this9 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      var _this9$connectedWalle;
      const isAnchor = type === _add_liquidity_type__WEBPACK_IMPORTED_MODULE_21__.OPERATE.ANCHOR;
      const {
        anchorMainCoin,
        quoteMainCoin,
        anchorGasFee,
        quoteGasFee
      } = _this9;
      const {
        anchorCoin,
        anchorChain,
        anchorAmount,
        quoteCoin,
        quoteChain,
        quoteAmount
      } = _this9.poolUtil();
      const isSameChain = anchorChain && quoteChain && quoteChain === anchorChain;
      const coin = isAnchor ? anchorCoin : quoteCoin;
      const chain = isAnchor ? anchorChain : quoteChain;
      const amount = isAnchor ? anchorAmount : quoteAmount;
      const mainCoin = isAnchor ? anchorMainCoin : quoteMainCoin;
      let gasFee;
      // 同一条链的要累加手续费
      if (isSameChain) {
        gasFee = new bignumber_js__WEBPACK_IMPORTED_MODULE_17__["default"](anchorGasFee).plus(quoteGasFee).toString();
      } else {
        gasFee = isAnchor ? anchorGasFee : quoteGasFee;
      }
      if (coin === undefined || chain === undefined) {
        throw new Error('未选择币种，无法计算');
      }
      if (Boolean(amount) === false) {
        return true;
      }
      const assetInfoList = (_this9$connectedWalle = _this9.connectedWallet) === null || _this9$connectedWalle === void 0 ? void 0 : _this9$connectedWalle.assetInfoListMap.get(chain);
      const mainAssetInfo = assetInfoList === null || assetInfoList === void 0 ? void 0 : assetInfoList.assets.find(item => item.assetType === mainCoin);
      if (mainAssetInfo === undefined) {
        throw new Error('没有找到主链币种钱包信息');
      }
      const isMainCoin = coin === mainCoin;
      const needAmount = isMainCoin ? new bignumber_js__WEBPACK_IMPORTED_MODULE_17__["default"](amount).multipliedBy(1e8).plus(gasFee).toString() : gasFee;
      const gasFeeisEnough = new bignumber_js__WEBPACK_IMPORTED_MODULE_17__["default"](mainAssetInfo.amount).isGreaterThanOrEqualTo(needAmount);
      _this9.showGasTip = true;
      if (gasFeeisEnough) {
        if (_this9.maxMode) {
          const text = '已为您预留钱包签名手续费';
          _this9.gasFeeTipList.push({
            text,
            success: true
          });
        }
      } else if (isMainCoin) {
        const amount = _bnqkl_framework_pipes__WEBPACK_IMPORTED_MODULE_14__.AmountFixedPipe.transform(gasFee, '8', {
          removeZero: true
        });
        const text = `请预留 ${amount} ${mainCoin}矿工费`;
        _this9.gasFeeTipList.unshift({
          text,
          success: false
        });
        return false;
      } else {
        const text = `当前 ${mainCoin}不足，可能无法签名`;
        _this9.gasFeeTipList.unshift({
          text,
          success: false
        });
      }
      return true;
    })();
  }
  /** 选择币种事件 */
  onSelectToken(data) {
    var _this10 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this10.console.info('submit select token', data);
      const {
        selectedAsset
      } = data;
      const {
        chainName,
        tokenName
      } = selectedAsset;
      _this10.poolDetail = undefined;
      _this10.initGasFeeInfo();
      _this10.setCoinData(chainName, tokenName, _this10.operate);
      _this10.handlePriceCaculate();
    })();
  }
  /** 清空矿工信息 */
  initGasFeeInfo() {
    this.gasFeeTipList = [];
    this.showGasTip = false;
  }
  /** 根据最后一次输入执行计算操作 */
  handleCalculate() {
    this.lastInput && this.lastInput === _add_liquidity_type__WEBPACK_IMPORTED_MODULE_21__.OPERATE.ANCHOR ? this.handleAnchorCalculate() : this.handleQuoteCalculate();
  }
  /** 设置已选中 */
  setSelectAsset() {
    const {
      anchorCoin,
      anchorChain,
      quoteCoin,
      quoteChain
    } = this.poolUtil();
    let list = [];
    if (this.operate === _add_liquidity_type__WEBPACK_IMPORTED_MODULE_21__.OPERATE.ANCHOR) {
      list = this.selectAssetSheet.data.liquidityPoolAssetsInfo.filter(item => {
        return item.tokenName === anchorCoin && item.chainName === anchorChain;
      });
    } else {
      list = this.selectAssetSheet.data.liquidityPoolAssetsInfo.filter(item => {
        return item.tokenName === quoteCoin && item.chainName === quoteChain;
      });
    }
    this.selectAssetSheet.data.disabledAsset = list;
    this.selectAssetSheet.data.selectedAsset = list;
  }
  setCoinData(chainName, coinName, type) {
    const targetAsset = this.walletService.liquidityPoolAssetsListWithAmount.find(pool => {
      return pool.chainName === chainName && pool.tokenName === coinName;
    });
    if (targetAsset) {
      const {
        amount,
        chainName,
        tokenName,
        decimals,
        tokenIcon
      } = targetAsset;
      const {
        anchorPanel,
        quotePanel
      } = this;
      const isAnchor = type === _add_liquidity_type__WEBPACK_IMPORTED_MODULE_21__.OPERATE.ANCHOR;
      const targetPanel = isAnchor ? anchorPanel : quotePanel;
      const otherPanel = isAnchor ? quotePanel : anchorPanel;
      const isNumber = Number.isNaN(parseFloat(amount));
      targetPanel.balance = isNumber ? '- -' : _bnqkl_framework_pipes__WEBPACK_IMPORTED_MODULE_14__.AmountFixedPipe.transform(amount, decimals, {
        removeZero: true
      });
      targetPanel.coin = tokenName;
      targetPanel.chain = chainName;
      targetPanel.chainIcon = (0,_services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_4__.transferToChainIcon)(chainName || 'Default');
      targetPanel.coinIcon = tokenIcon;
      const {
        coin: quoteCoin,
        chain: quoteChain
      } = otherPanel;
      if (quoteCoin === tokenName && quoteChain === chainName) {
        this.initPanel(isAnchor ? _add_liquidity_type__WEBPACK_IMPORTED_MODULE_21__.OPERATE.QUOTE : _add_liquidity_type__WEBPACK_IMPORTED_MODULE_21__.OPERATE.ANCHOR);
      }
      this.calculateMainChainInfo(chainName, type);
      this.getLiquidityPoolDetail();
    }
  }
  /** 清空面板 */
  initPanel(type) {
    const initPanel = {
      poolId: '',
      icon: undefined,
      chain: undefined,
      coin: undefined,
      amount: '',
      balance: '- -'
    };
    const targetPanel = type === _add_liquidity_type__WEBPACK_IMPORTED_MODULE_21__.OPERATE.ANCHOR ? this.anchorPanel : this.quotePanel;
    Object.assign(targetPanel, initPanel);
  }
  /** 初始化按钮状态  */
  checkEventList() {
    var _this11 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const {
        btnObjList
      } = _this11;
      for (let i = 0; i < btnObjList.length; i++) {
        const btn = btnObjList[i];
        const result = btn.check();
        const r = typeof result === 'boolean' ? result : yield result;
        if (r === false) {
          const {
            text,
            disabled,
            event
          } = btn;
          _this11.btnText = typeof text === 'string' ? text : text();
          _this11.btnDisabled = disabled;
          if (event) {
            _this11.btnEvent = event;
          }
          return;
        }
      }
    })();
  }
  /** 计算公式  */
  caculate(amount, coin, chain) {
    const {
      poolDetail
    } = this.poolUtil();
    if (poolDetail) {
      const {
        anchorCoinsAmount,
        anchorCoinsChainName,
        anchorCoinsName,
        quoteCoinsAmount
      } = poolDetail;
      const anchorFlag = coin === anchorCoinsName && chain === _services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_4__.NODE_CHAIN_NAME_TRANSFER[anchorCoinsChainName];
      if (parseFloat(anchorCoinsAmount) > 0 && parseFloat(quoteCoinsAmount) > 0) {
        const ratio = new bignumber_js__WEBPACK_IMPORTED_MODULE_17__["default"](quoteCoinsAmount).div(anchorCoinsAmount);
        const value = anchorFlag ? ratio.multipliedBy(amount) : new bignumber_js__WEBPACK_IMPORTED_MODULE_17__["default"](amount).div(ratio);
        return _pipes_remove_trailing_zeros_remove_trailing_zeros_pipe__WEBPACK_IMPORTED_MODULE_20__.RemoveTrailingZerosPipe.transform(value.toFixed(8, 1));
      }
    }
    return '';
  }
  /** 获取合约池详情 */
  getLiquidityPoolDetail() {
    const {
      anchorCoin,
      poolId,
      quoteCoin
    } = this.poolUtil();
    if (anchorCoin && quoteCoin && poolId.length > 0) {
      this.poolService.startQueryPoolTask([poolId[0]]);
    } else {
      this.checkEventList();
    }
  }
  /** 检查是否连接钱包 */
  checkWallet() {
    return Boolean(this.connectedWallet);
  }
  /** 检查是否选择币种 */
  checkToken() {
    return Boolean(this.anchorPanel.coin);
  }
  /** 检查输入的数量 */
  checkAmount() {
    return Boolean(this.quotePanel.amount) && Boolean(this.anchorPanel.amount);
  }
  /** 检查是否获取数据 */
  checkData() {
    return Boolean(this.quoteTimer) === false;
  }
  /** 检查锚定货币余额 */
  checkAnchorBalance() {
    const {
      coin: anchorCoin,
      amount: anchorAmount,
      balance: anchorBalance
    } = this.anchorPanel;
    if (anchorAmount && anchorBalance && anchorCoin) {
      const anchorCompare = new bignumber_js__WEBPACK_IMPORTED_MODULE_17__["default"](anchorBalance).isGreaterThanOrEqualTo(anchorAmount);
      return anchorCompare;
    }
    return true;
  }
  /** 检查矿工费 */
  checkGasFee() {
    var _this12 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this12.gasFeeTipList = [];
      _this12.showGasTip = false;
      const anchorFee = yield _this12.checkGasFeeAndBalance(_add_liquidity_type__WEBPACK_IMPORTED_MODULE_21__.OPERATE.ANCHOR);
      const quoteFee = yield _this12.checkGasFeeAndBalance(_add_liquidity_type__WEBPACK_IMPORTED_MODULE_21__.OPERATE.QUOTE);
      return anchorFee && quoteFee;
    })();
  }
  /** 检查报价货币余额 */
  checkQuoteBalance() {
    const {
      coin: quoteCoin,
      amount: quoteAmount,
      balance: quoteBalance
    } = this.quotePanel;
    if (quoteAmount && quoteBalance && quoteCoin) {
      const quoteCompare = new bignumber_js__WEBPACK_IMPORTED_MODULE_17__["default"](quoteBalance).isGreaterThanOrEqualTo(quoteAmount);
      return quoteCompare;
    }
    return true;
  }
  /** 检查合约池 */
  checkLiquidityPool() {
    const {
      anchorCoin,
      quoteCoin
    } = this.poolUtil();
    const {
      poolDetail
    } = this;
    const flag = anchorCoin && quoteCoin && Boolean(poolDetail) === false;
    return !flag;
  }
  /** 是否提示没有池子 */
  get showCreatePoolTip() {
    const {
      anchorCoin,
      quoteCoin,
      poolDetail
    } = this.poolUtil();
    if (poolDetail === undefined || anchorCoin === undefined || quoteCoin === undefined) return false;
    const {
      anchorCoinsAmount,
      quoteCoinsAmount
    } = poolDetail;
    const anchorNone = anchorCoinsAmount === '0';
    const quoteNone = quoteCoinsAmount === '0';
    return Boolean(anchorNone) || Boolean(quoteNone);
  }
  /** 是否展示预设价格 */
  get showPreviewPrice() {
    const {
      anchorCoin,
      quoteCoin,
      poolDetail
    } = this.poolUtil();
    if (poolDetail === undefined) return false;
    const {
      anchorCoinsAmount,
      quoteCoinsAmount
    } = poolDetail;
    const anchorNone = anchorCoinsAmount === '0';
    const quoteNone = quoteCoinsAmount === '0';
    if (anchorNone || quoteNone) return false;
    return Boolean(anchorCoin) && Boolean(quoteCoin);
  }
  /** 处理Max按钮事件 */
  handleMaxBtn(operate) {
    this.initGasFeeInfo();
    this.lastInput = operate;
    const isAnchor = operate === _add_liquidity_type__WEBPACK_IMPORTED_MODULE_21__.OPERATE.ANCHOR;
    const panel = isAnchor ? this.anchorPanel : this.quotePanel;
    const mainCoin = isAnchor ? this.anchorMainCoin : this.quoteMainCoin;
    const gasFee = isAnchor ? this.anchorGasFee : this.quoteGasFee;
    const {
      coin
    } = panel;
    const gasFeeAmount = new bignumber_js__WEBPACK_IMPORTED_MODULE_17__["default"](gasFee).dividedBy(1e8).toFixed(8, 1);
    const amount = new bignumber_js__WEBPACK_IMPORTED_MODULE_17__["default"](panel.balance).minus(gasFeeAmount);
    this.maxMode = true;
    if (amount.toNumber() > 0) {
      if (mainCoin === coin) {
        panel.amount = amount.toString();
      } else {
        panel.amount = panel.balance;
      }
      this.handleCalculate();
    } else {
      this.showGasTip = true;
      const text = `请预留 ${gasFeeAmount} ${mainCoin} 矿工费`;
      this.gasFeeTipList = [{
        text,
        success: false
      }];
    }
    this.checkEventList();
  }
  /** 初始化数据 */
  dataInit() {
    var _this13 = this;
    // 监听余额变化
    this.walletAssets$ = this.walletService.curentWalletAssets_subject.subscribe( /*#__PURE__*/function () {
      var _ref = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (assetTaskInfo) {
        if (assetTaskInfo.updating || assetTaskInfo.connectedWallet === undefined) {
          return;
        }
        _this13.connectedWallet = assetTaskInfo.connectedWallet;
        /** 实时变更界面余额(如果余额发生变化的话) */
        _this13.console.info('兑换面板监听到余额变化', _this13.connectedWallet);
        _this13.changeViewBalanceAmount();
        return;
      });
      return function (_x) {
        return _ref.apply(this, arguments);
      };
    }());
    // 监听池子可选币种余额列表变化
    this.poolAssets$ = this.walletService.liquidityPoolAssetsListWithAmout_subject.subscribe( /*#__PURE__*/function () {
      var _ref2 = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (liquidityPoolAssetsListWithAmountInfo) {
        if (liquidityPoolAssetsListWithAmountInfo && liquidityPoolAssetsListWithAmountInfo.updating == false && liquidityPoolAssetsListWithAmountInfo.liquidityPoolAssetsListWithAmount) {
          _this13.console.info('池子币种面板监听到池子币种余额列表更新', liquidityPoolAssetsListWithAmountInfo.liquidityPoolAssetsListWithAmount);
          _this13.poolList = liquidityPoolAssetsListWithAmountInfo.liquidityPoolAssetsListWithAmount;
          _this13._updateSelectAssetSheet(_this13.poolList);
          return;
        }
      });
      return function (_x2) {
        return _ref2.apply(this, arguments);
      };
    }());
    // 监听池子详情变化
    this.poolDetail$ = this.poolService.liquidityPoolDetailQueryTask_subject.subscribe(detail => {
      if (detail == undefined) {
        return;
      }
      this.console.info('增加流动性面板监听到池子详情变化', detail);
      if (detail) {
        const {
          liquidityPoolsdetail,
          updating
        } = detail;
        this.rateAnimationState = updating;
        this.loading = updating;
        if (updating === false && liquidityPoolsdetail) {
          const pool = liquidityPoolsdetail[0];
          this.poolDetail = pool;
          if (this.fromRouter) {
            this.handleRouerSelectCoin(pool);
          }
          if (this.showCreatePoolTip === false) {
            this.handleCalculate();
            this.handlePriceCaculate();
          }
        }
        this.checkEventList();
      }
    });
    // 监听钱包变化
    this.connectWallet$ = this.walletService.wallletConnected_subject.subscribe( /*#__PURE__*/function () {
      var _ref3 = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (data) {
        if (data === undefined) {
          return;
        }
        const {
          wallet
        } = data;
        if (wallet === undefined) {
          // this.initPanel(OPERATE.ANCHOR)
          // this.initPanel(OPERATE.QUOTE)
          _this13.anchorPanel.balance = '- -';
          _this13.quotePanel.balance = '- -';
          _this13.initPoolInfo();
          _this13.initGasFeeInfo();
        }
        _this13.connectedWallet = data.wallet;
        _this13.checkEventList();
        return;
      });
      return function (_x3) {
        return _ref3.apply(this, arguments);
      };
    }());
    // 绑定池子币种选择面板数据
    this._updateSelectAssetSheet(this.walletService.liquidityPoolAssetsListWithAmount);
    this.walletService.allSubscribes.set('add-liquidity', [this.walletAssets$, this.poolAssets$, this.connectWallet$]);
  }
  /** 更新选择资产弹窗的初始数据  */
  _updateSelectAssetSheet(poolAssetTaskInfo) {
    this.selectAssetSheet.data.liquidityPoolAssetsInfo = poolAssetTaskInfo;
    this.selectAssetSheet.data.chainGroupInfo = Array.from(new Set(poolAssetTaskInfo.map(asset => {
      return asset.chainName;
    }))).map(item => {
      return {
        chain: item,
        chainI18nName: item
      };
    });
  }
  /** 初始化池子信息 */
  initPoolInfo() {
    this.poolDetail = undefined;
    this.poolList = [];
  }
  /** 改变界面余额数量 */
  changeViewBalanceAmount() {
    const {
      connectedWallet
    } = this;
    [this.anchorPanel, this.quotePanel].forEach(item => {
      if (connectedWallet) {
        const {
          chain,
          coin,
          balance
        } = item;
        if (chain === undefined || coin === undefined) return;
        const wallet = connectedWallet.assetInfoListMap.get(chain);
        if (wallet === undefined) return;
        const {
          assets
        } = wallet;
        const asset = assets.find(asset => asset.assetType === coin);
        if (asset === undefined) return;
        const isNumber = Number.isNaN(parseFloat(asset.amount));
        const amount = isNumber ? '- -' : _bnqkl_framework_pipes__WEBPACK_IMPORTED_MODULE_14__.AmountFixedPipe.transform(asset.amount, asset.decimals, {
          removeZero: true
        });
        if (amount !== balance) {
          item.balance = amount;
        }
      } else {
        item.balance = '- -';
      }
    });
  }
  /** 初始化输入框输入事件 */
  initInputListenEvent() {
    this.anchorInputRef && this.anchorInputRef.nativeElement.addEventListener('input', this.anchorInputEvent.bind(this));
    this.quoteInputRef && this.quoteInputRef.nativeElement.addEventListener('input', this.quoteInputEvent.bind(this));
  }
  /** 清除订阅监听 */
  unsubscribe() {
    this.walletAssets$ && this.walletAssets$.unsubscribe();
    this.poolAssets$ && this.poolAssets$.unsubscribe();
    this.connectWallet$ && this.connectWallet$.unsubscribe();
    this.poolDetail$ && this.poolDetail$.unsubscribe();
    this.walletService.allSubscribes.delete('add-liquidity');
    this.anchorInputRef && this.anchorInputRef.nativeElement.removeEventListener('input', this.anchorInputEvent.bind(this));
    this.quoteInputRef && this.quoteInputRef.nativeElement.removeEventListener('input', this.quoteInputEvent.bind(this));
    this.poolService.removeQueryPoolTask();
    this.settingsService.reset();
  }
  /** 锚定输入框输入事件 */
  anchorInputEvent() {
    if (this.anchorTimer) {
      clearTimeout(this.anchorTimer);
    }
    this.anchorTimer = setTimeout(() => {
      this.lastInput = _add_liquidity_type__WEBPACK_IMPORTED_MODULE_21__.OPERATE.ANCHOR;
      this.maxMode = false;
      if (this.showCreatePoolTip === false) {
        this.initGasFeeInfo();
        this.handleAnchorCalculate();
      }
      this.checkEventList();
    }, 500);
  }
  /** 报价输入框输入事件 */
  quoteInputEvent() {
    if (this.quoteTimer) {
      clearTimeout(this.quoteTimer);
    }
    this.quoteTimer = setTimeout(() => {
      this.lastInput = _add_liquidity_type__WEBPACK_IMPORTED_MODULE_21__.OPERATE.QUOTE;
      this.maxMode = false;
      if (this.showCreatePoolTip === false) {
        this.initGasFeeInfo();
        this.handleQuoteCalculate();
      }
      this.checkEventList();
    }, 500);
  }
  /** 锚定货币的计算 */
  handleAnchorCalculate() {
    const {
      anchorCoin,
      anchorAmount,
      quoteCoin,
      anchorChain
    } = this.poolUtil();
    if (anchorCoin && quoteCoin && anchorAmount && anchorChain) {
      const amount = this.caculate(anchorAmount, anchorCoin, anchorChain);
      if (amount) {
        this.quotePanel.amount = amount;
      }
    }
  }
  /** 定价货币的计算 */
  handleQuoteCalculate() {
    const {
      anchorCoin,
      quoteAmount,
      quoteCoin,
      poolDetail,
      quoteChain
    } = this.poolUtil();
    if (anchorCoin && quoteCoin && quoteAmount && poolDetail && quoteChain) {
      const amount = this.caculate(quoteAmount, quoteCoin, quoteChain);
      if (amount) {
        this.anchorPanel.amount = amount;
      }
    }
  }
  /** 增流比例计算 */
  handlePriceCaculate() {
    const {
      anchorCoin,
      quoteCoin,
      anchorChain,
      quoteChain
    } = this.poolUtil();
    if (anchorCoin === undefined || quoteCoin === undefined || anchorChain === undefined || quoteChain === undefined) return;
    const anchorPrice = this.caculate('1', anchorCoin, anchorChain);
    const quotePrice = this.caculate('1', quoteCoin, quoteChain);
    if (anchorPrice && quotePrice) {
      this.price.direction = _services_liquidity_pool_liquidity_pool_helper__WEBPACK_IMPORTED_MODULE_19__.PRICE_DIRECTION.FORWARD;
      const option = {
        direction: _services_liquidity_pool_liquidity_pool_helper__WEBPACK_IMPORTED_MODULE_19__.PRICE_DIRECTION.FORWARD,
        format: false
      };
      const generatePrice = (0,_services_liquidity_pool_liquidity_pool_helper__WEBPACK_IMPORTED_MODULE_19__.generatePriceUtil)(quoteCoin, quotePrice, anchorCoin, anchorPrice, option);
      this.price = generatePrice;
    }
  }
  /** 跳转记录页面 */
  jumpRecordPage() {
    if (this.connectedWallet) {
      this.nav.routeTo('/mine/my-record');
    } else {
      _bnqkl_framework_plugins_toast__WEBPACK_IMPORTED_MODULE_8__.Toast.show('请先连接钱包');
    }
  }
}
_class = AddLiquidityPage;
_class.ɵfac = /*@__PURE__*/(() => {
  let ɵAddLiquidityPage_BaseFactory;
  return function AddLiquidityPage_Factory(t) {
    return (ɵAddLiquidityPage_BaseFactory || (ɵAddLiquidityPage_BaseFactory = _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵgetInheritedFactory"](_class)))(t || _class);
  };
})();
_class.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵdefineComponent"]({
  type: _class,
  selectors: [["bs-add-liquidity-page"]],
  viewQuery: function AddLiquidityPage_Query(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵviewQuery"](_c0, 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵviewQuery"](_c1, 5);
    }
    if (rf & 2) {
      let _t;
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵloadQuery"]()) && (ctx.anchorInputRef = _t.first);
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵloadQuery"]()) && (ctx.quoteInputRef = _t.first);
    }
  },
  standalone: true,
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵInheritDefinitionFeature"], _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵStandaloneFeature"]],
  decls: 57,
  vars: 28,
  consts: () => {
    let i18n_2;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_TOKEN$$APPS_BFSWAP_SRC_PAGES_ADD_LIQUIDITY_ADD_LIQUIDITY_COMPONENT_TS_3 = goog.getMsg("Token");
      i18n_2 = MSG_EXTERNAL_TOKEN$$APPS_BFSWAP_SRC_PAGES_ADD_LIQUIDITY_ADD_LIQUIDITY_COMPONENT_TS_3;
    } else {
      i18n_2 = "\u8D44\u4EA7";
    }
    let i18n_4;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_ENTER_QUANTITY$$APPS_BFSWAP_SRC_PAGES_ADD_LIQUIDITY_ADD_LIQUIDITY_COMPONENT_TS_5 = goog.getMsg("Enter");
      i18n_4 = MSG_EXTERNAL_ENTER_QUANTITY$$APPS_BFSWAP_SRC_PAGES_ADD_LIQUIDITY_ADD_LIQUIDITY_COMPONENT_TS_5;
    } else {
      i18n_4 = "\u8F93\u5165\u6570\u91CF";
    }
    let i18n_6;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_TOKEN$$APPS_BFSWAP_SRC_PAGES_ADD_LIQUIDITY_ADD_LIQUIDITY_COMPONENT_TS_7 = goog.getMsg("Token");
      i18n_6 = MSG_EXTERNAL_TOKEN$$APPS_BFSWAP_SRC_PAGES_ADD_LIQUIDITY_ADD_LIQUIDITY_COMPONENT_TS_7;
    } else {
      i18n_6 = "\u8D44\u4EA7";
    }
    let i18n_8;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_ENTER_QUANTITY$$APPS_BFSWAP_SRC_PAGES_ADD_LIQUIDITY_ADD_LIQUIDITY_COMPONENT_TS_9 = goog.getMsg("Enter");
      i18n_8 = MSG_EXTERNAL_ENTER_QUANTITY$$APPS_BFSWAP_SRC_PAGES_ADD_LIQUIDITY_ADD_LIQUIDITY_COMPONENT_TS_9;
    } else {
      i18n_8 = "\u8F93\u5165\u6570\u91CF";
    }
    let i18n_10;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_SELECT_TOKENS$$APPS_BFSWAP_SRC_PAGES_ADD_LIQUIDITY_ADD_LIQUIDITY_COMPONENT_TS__11 = goog.getMsg("Select tokens");
      i18n_10 = MSG_EXTERNAL_SELECT_TOKENS$$APPS_BFSWAP_SRC_PAGES_ADD_LIQUIDITY_ADD_LIQUIDITY_COMPONENT_TS__11;
    } else {
      i18n_10 = "\u9009\u62E9\u8D44\u4EA7";
    }
    let i18n_12;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_2229239702615161749$$APPS_BFSWAP_SRC_PAGES_ADD_LIQUIDITY_ADD_LIQUIDITY_COMPONENT_TS__13 = goog.getMsg(" \u6700\u5927 ");
      i18n_12 = MSG_EXTERNAL_2229239702615161749$$APPS_BFSWAP_SRC_PAGES_ADD_LIQUIDITY_ADD_LIQUIDITY_COMPONENT_TS__13;
    } else {
      i18n_12 = " \u6700\u5927 ";
    }
    let i18n_14;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_SELECT_TOKEN$$APPS_BFSWAP_SRC_PAGES_ADD_LIQUIDITY_ADD_LIQUIDITY_COMPONENT_TS__15 = goog.getMsg("Select token");
      i18n_14 = MSG_EXTERNAL_SELECT_TOKEN$$APPS_BFSWAP_SRC_PAGES_ADD_LIQUIDITY_ADD_LIQUIDITY_COMPONENT_TS__15;
    } else {
      i18n_14 = "\u9009\u62E9\u8D44\u4EA7";
    }
    let i18n_16;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_2229239702615161749$$APPS_BFSWAP_SRC_PAGES_ADD_LIQUIDITY_ADD_LIQUIDITY_COMPONENT_TS__17 = goog.getMsg(" \u6700\u5927 ");
      i18n_16 = MSG_EXTERNAL_2229239702615161749$$APPS_BFSWAP_SRC_PAGES_ADD_LIQUIDITY_ADD_LIQUIDITY_COMPONENT_TS__17;
    } else {
      i18n_16 = " \u6700\u5927 ";
    }
    let i18n_18;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_8888102213954529470$$APPS_BFSWAP_SRC_PAGES_ADD_LIQUIDITY_ADD_LIQUIDITY_COMPONENT_TS__19 = goog.getMsg("{$interpolation}", {
        "interpolation": "\uFFFD0\uFFFD"
      }, {
        original_code: {
          "interpolation": "{{\r\n            gasFeePre.text\r\n          }}"
        }
      });
      i18n_18 = MSG_EXTERNAL_8888102213954529470$$APPS_BFSWAP_SRC_PAGES_ADD_LIQUIDITY_ADD_LIQUIDITY_COMPONENT_TS__19;
    } else {
      i18n_18 = "" + "\uFFFD0\uFFFD" + "";
    }
    let i18n_21;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_THERE_IS_CURRENTLY_NO_TRADING_POOL_THE_FIRST_SCALE_WILL_DETERMINE_THE_INITIAL_PRICE$$APPS_BFSWAP_SRC_PAGES_ADD_LIQUIDITY_ADD_LIQUIDITY_COMPONENT_TS__22 = goog.getMsg(" There is currently no{$interpolation}-{$interpolation_1}trading pool,this ratio will be used as the initial price ", {
        "interpolation": "\uFFFD0\uFFFD",
        "interpolation_1": "\uFFFD1\uFFFD"
      }, {
        original_code: {
          "interpolation": "{{ anchorPanel.coin }}",
          "interpolation_1": "{{ quotePanel.coin }}"
        }
      });
      i18n_21 = MSG_EXTERNAL_THERE_IS_CURRENTLY_NO_TRADING_POOL_THE_FIRST_SCALE_WILL_DETERMINE_THE_INITIAL_PRICE$$APPS_BFSWAP_SRC_PAGES_ADD_LIQUIDITY_ADD_LIQUIDITY_COMPONENT_TS__22;
    } else {
      i18n_21 = "\u5F53\u524D\u6682\u65E0" + "\uFFFD0\uFFFD" + "-" + "\uFFFD1\uFFFD" + "\u4EA4\u6613\u6C60\uFF0C\u9996\u6B21\u6BD4\u4F8B\u5C06\u51B3\u5B9A\u521D\u59CB\u4EF7\u683C ";
    }
    return [[3, "headerBackground", "titleClass"], ["endMenu", "", 1, "flex", "items-center"], [1, "rounded-2.5", "mr-3", "flex", "h-8", "w-8", "items-center", "justify-center", "bg-white", 3, "click"], ["name", "icon-slider", 1, "text-xl"], [1, "rounded-2.5", "flex", "h-8", "w-8", "items-center", "justify-center", "bg-white", 3, "click"], ["name", "icon-history", 1, "text-xl"], [1, "h-75", "bg-linear-page-top", "absolute", "top-0", "w-full"], [1, "pt-2.5"], [1, "rounded-t-5", "relative", "bg-white", "px-4", "pt-8"], [1, "rounded-4", "bg-base-300", "relative", "mb-2", "p-4"], [1, "mb-4", "flex", "items-center"], [1, "text-gray-10", "font-semibold"], i18n_2, ["class", "rounded-1.5 flex flex-shrink-0 items-center bg-white py-1 pl-2 pr-3"], ["type", "text", "placeholder", i18n_4, 1, "text-black-10", "placeholder:text-base-200", "ml-auto", "w-1/2", "border-none", "text-right", "text-2xl", "font-semibold", "outline-none", "placeholder:font-medium", "placeholder:text-2xl", 3, "formControl", "ngModel", "ngModelChange"], ["quoteInputRef", ""], [1, "flex", "items-center", "text-sm"], ["name", "icon-assets-normal", 1, "text-2xl"], [1, "text-gray-10", "mr-1"], ["class", "text-primary bg-bg-button-6 rounded-1 ml-auto px-2 py-1 text-xs"], [1, "rounded-4", "bg-base-300", "relative", "p-4"], [1, "absolute", "-top-6", "right-16", "z-20", "flex", "h-12", "w-12", "items-center", "justify-center", "rounded-full", "bg-white"], ["name", "icon-add", 1, "icon-6"], i18n_6, ["type", "text", "placeholder", i18n_8, 1, "text-black-10", "placeholder:text-base-200", "ml-auto", "w-1/2", "border-none", "text-right", "text-2xl", "font-semibold", "outline-none", "placeholder:font-medium", "placeholder:text-2xl", 3, "formControl", "ngModel", "ngModelChange"], ["anchorInputRef", ""], [1, "flex", "h-12", "items-center", "justify-center"], ["class", "flex items-center justify-center", 4, "ngIf"], ["bnRippleButton", "", 1, "rounded-12", "flex", "w-full", "shrink-0", "items-center", "justify-center", "py-2.5", "text-lg", "font-semibold", "text-white", 3, "disabled", "click"], [1, "relative"], [1, "icon-6", "absolute", "-right-6", "top-0", 3, "loadingTheme", "showLoading"], ["class", "my-6 flex items-center justify-center", 4, "ngIf"], ["class", "text-base-200 mt-4 text-center text-xs", 4, "ngIf"], [3, "isOpen", "isOpenChange"], [3, "isOpen", "panelClass", "isOpenChange"], [1, "rounded-1", "mx-1", "flex", "h-5", "w-5", "items-center", "justify-center", "border", "border-white"], [1, "text-lg", 3, "name"], [1, "text-black-10"], [1, "rounded-1.5", "flex", "flex-shrink-0", "items-center", "bg-white", "py-1", "pl-2", "pr-3", 3, "click"], [1, "text-title-10", "mr-1"], i18n_10, ["name", "icon-home-arrow-token", "bnRippleButton", "", 1, "icon-4", 3, "mode"], [1, "flex", "items-center", 3, "click"], [1, "text-[1.75rem]", 3, "name"], [1, "text-base-content-100", "mx-1", "text-base", "font-semibold"], ["bnRippleButton", "", 1, "icon-4", 3, "mode"], ["name", "icon-home-arrow-token"], [1, "text-primary", "bg-bg-button-6", "rounded-1", "ml-auto", "px-2", "py-1", "text-xs", 3, "click"], i18n_12, i18n_14, [1, "text-[1.75rem]", 3, "defaultName", "name"], i18n_16, [1, "flex", "items-center", "justify-center"], ["src", "./assets/images/icon-right.svg", 4, "ngIf"], ["src", "./assets/images/icon-wrong.svg", 4, "ngIf"], i18n_18, ["src", "./assets/images/icon-right.svg"], ["src", "./assets/images/icon-wrong.svg"], [1, "my-6", "flex", "items-center", "justify-center"], [1, "text-gray-10", "mx-1"], ["name", "icon-home-arrow-exchange-rate", 1, "text-2xl", 3, "ngStyle", "click"], [1, "text-base-200", "mt-4", "text-center", "text-xs"], i18n_21, [3, "poolDetail", "anchorPanel", "quotePanel", "isCreate", "preParams", "transferOptions", "returnValue$"], [3, "showSlippages", "showAddLiquidityRatio", "returnValue$"], [3, "liquidityPoolAssetsInfo", "selectedAsset", "disabledAsset", "chainGroupInfo", "onlyUSDM", "noUSDM", "returnValue$"], [3, "connectType", "presetWallets"]];
  },
  template: function AddLiquidityPage_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](0, "common-page", 0)(1, "div", 1)(2, "div", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵlistener"]("click", function AddLiquidityPage_Template_div_click_2_listener() {
        return ctx.openAdvancedSettingsSheet();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelement"](3, "bs-icon", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](4, "div", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵlistener"]("click", function AddLiquidityPage_Template_div_click_4_listener() {
        return ctx.jumpRecordPage();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelement"](5, "bs-icon", 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelement"](6, "div", 6);
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](7, "div", 7)(8, "div", 8)(9, "div", 9)(10, "div", 10)(11, "div", 11);
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵi18n"](12, 12);
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtemplate"](13, AddLiquidityPage_Conditional_13_Template, 4, 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](14, "div", 10);
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtemplate"](15, AddLiquidityPage_Conditional_15_Template, 4, 1, "div", 13)(16, AddLiquidityPage_Conditional_16_Template, 6, 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](17, "input", 14, 15);
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵlistener"]("ngModelChange", function AddLiquidityPage_Template_input_ngModelChange_17_listener($event) {
        return ctx.quotePanel.amount = $event;
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](19, "div", 16);
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelement"](20, "bs-icon", 17);
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](21, "span", 18);
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtext"](22);
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtemplate"](23, AddLiquidityPage_Conditional_23_Template, 2, 0, "button", 19);
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](24, "div", 20)(25, "div", 21);
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelement"](26, "bs-icon", 22);
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](27, "div", 10)(28, "div", 11);
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵi18n"](29, 23);
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtemplate"](30, AddLiquidityPage_Conditional_30_Template, 4, 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](31, "div", 10);
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtemplate"](32, AddLiquidityPage_Conditional_32_Template, 4, 1, "div", 13)(33, AddLiquidityPage_Conditional_33_Template, 6, 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](34, "input", 24, 25);
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵlistener"]("ngModelChange", function AddLiquidityPage_Template_input_ngModelChange_34_listener($event) {
        return ctx.anchorPanel.amount = $event;
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](36, "div", 16);
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelement"](37, "bs-icon", 17);
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](38, "span", 18);
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtext"](39);
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtemplate"](40, AddLiquidityPage_Conditional_40_Template, 2, 0, "button", 19);
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](41, "div", 26);
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtemplate"](42, AddLiquidityPage_div_42_Template, 5, 6, "div", 27);
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](43, "button", 28);
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵlistener"]("click", function AddLiquidityPage_Template_button_click_43_listener() {
        return ctx.btnEvent();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](44, "div", 29);
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtext"](45);
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelement"](46, "bn-loading-wrapper", 30);
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtemplate"](47, AddLiquidityPage_div_47_Template, 4, 5, "div", 31)(48, AddLiquidityPage_div_48_Template, 2, 2, "div", 32);
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]()()();
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](49, "common-bottom-sheet", 33);
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵlistener"]("isOpenChange", function AddLiquidityPage_Template_common_bottom_sheet_isOpenChange_49_listener($event) {
        return ctx.addLiquiditySheet.is_open = $event;
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtemplate"](50, AddLiquidityPage_ng_template_50_Template, 1, 6, "ng-template");
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](51, "common-bottom-sheet", 33);
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵlistener"]("isOpenChange", function AddLiquidityPage_Template_common_bottom_sheet_isOpenChange_51_listener($event) {
        return ctx.advancedSettingsSheet.is_open = $event;
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtemplate"](52, AddLiquidityPage_ng_template_52_Template, 1, 2, "ng-template");
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](53, "common-bottom-sheet", 34);
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵlistener"]("isOpenChange", function AddLiquidityPage_Template_common_bottom_sheet_isOpenChange_53_listener($event) {
        return ctx.selectAssetSheet.isOpen = $event;
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtemplate"](54, AddLiquidityPage_ng_template_54_Template, 1, 6, "ng-template");
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](55, "common-bottom-sheet", 33);
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵlistener"]("isOpenChange", function AddLiquidityPage_Template_common_bottom_sheet_isOpenChange_55_listener($event) {
        return ctx.selectWalletSheet.is_open = $event;
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtemplate"](56, AddLiquidityPage_ng_template_56_Template, 1, 2, "ng-template");
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("headerBackground", "transparent")("titleClass", "!justify-start font-extrabold !text-title-10 text-xl");
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](13);
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵconditional"](13, ctx.quotePanel.chain ? 13 : -1);
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵconditional"](15, !ctx.quotePanel.coin ? 15 : 16);
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("formControl", ctx.quoteControl)("ngModel", ctx.quotePanel.amount);
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](5);
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtextInterpolate"](ctx.quotePanel.balance);
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵconditional"](23, ctx.showMax(ctx.OPERATE.QUOTE) ? 23 : -1);
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](7);
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵconditional"](30, ctx.anchorPanel.chain ? 30 : -1);
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵconditional"](32, !ctx.anchorPanel.coin ? 32 : 33);
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("formControl", ctx.anchorControl)("ngModel", ctx.anchorPanel.amount);
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](5);
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtextInterpolate"](ctx.anchorPanel.balance);
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵconditional"](40, ctx.showMax(ctx.OPERATE.ANCHOR) ? 40 : -1);
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("ngIf", ctx.gasFeeTipList.length > 0);
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵclassMap"](ctx.btnDisabled ? "bg-base-200" : " bg-primary");
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("disabled", ctx.btnDisabled);
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtextInterpolate1"](" ", ctx.btnText, " ");
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("loadingTheme", "ellipsis")("showLoading", ctx.loading);
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("ngIf", ctx.showPreviewPrice);
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("ngIf", ctx.showCreatePoolTip);
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("isOpen", ctx.addLiquiditySheet.is_open);
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("isOpen", ctx.advancedSettingsSheet.is_open);
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("isOpen", ctx.selectAssetSheet.isOpen)("panelClass", "h-2/3");
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("isOpen", ctx.selectWalletSheet.is_open);
    }
  },
  dependencies: [_components_add_detail_panel_add_detail_panel_component__WEBPACK_IMPORTED_MODULE_1__["default"], _modules_page_module__WEBPACK_IMPORTED_MODULE_2__.CommonPageModule, _libs_bnf_modules_bottom_sheet_components_bottom_sheet_component__WEBPACK_IMPORTED_MODULE_22__.BottomSheetComponent, _libs_bnf_components_ripple_button_ripple_button_directive__WEBPACK_IMPORTED_MODULE_23__.RippleButtonDirective, _libs_bnf_directives_auto_complete_off_directive__WEBPACK_IMPORTED_MODULE_24__.AutoCompleteOffDirective, _angular_common__WEBPACK_IMPORTED_MODULE_30__.NgIf, _angular_common__WEBPACK_IMPORTED_MODULE_30__.NgStyle, _angular_forms__WEBPACK_IMPORTED_MODULE_29__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_29__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_29__.FormControlDirective, _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_25__.CommonPageComponent, _components_icon_icon_component__WEBPACK_IMPORTED_MODULE_26__.IconComponent, _libs_bnf_components_loading_wrapper_loading_wrapper_component__WEBPACK_IMPORTED_MODULE_27__.LoadingWrapperComponent, _angular_common__WEBPACK_IMPORTED_MODULE_30__.CommonModule, _components_order_settings_order_settings_component__WEBPACK_IMPORTED_MODULE_3__.OrderSettingsPage, _components_select_token_panel_select_token_panel_component__WEBPACK_IMPORTED_MODULE_6__["default"], _components_connect_wallet_panel_connect_wallet_penel_component__WEBPACK_IMPORTED_MODULE_12__["default"]],
  styles: ["/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsInNvdXJjZVJvb3QiOiIifQ== */"],
  changeDetection: 0
});
(0,tslib__WEBPACK_IMPORTED_MODULE_31__.__decorate)([AddLiquidityPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_31__.__metadata)("design:type", Object)], AddLiquidityPage.prototype, "OPERATE", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_31__.__decorate)([AddLiquidityPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_31__.__metadata)("design:type", Object)], AddLiquidityPage.prototype, "connectedWallet", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_31__.__decorate)([AddLiquidityPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_31__.__metadata)("design:type", Object)], AddLiquidityPage.prototype, "btnText", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_31__.__decorate)([AddLiquidityPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_31__.__metadata)("design:type", Object)], AddLiquidityPage.prototype, "btnDisabled", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_31__.__decorate)([AddLiquidityPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_31__.__metadata)("design:type", Object)], AddLiquidityPage.prototype, "btnLoading", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_31__.__decorate)([AddLiquidityPage.QueryParams(), (0,tslib__WEBPACK_IMPORTED_MODULE_31__.__metadata)("design:type", Object)], AddLiquidityPage.prototype, "params", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_31__.__decorate)([AddLiquidityPage.OnReady(), (0,tslib__WEBPACK_IMPORTED_MODULE_31__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_31__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_31__.__metadata)("design:returntype", void 0)], AddLiquidityPage.prototype, "iniParams", null);
(0,tslib__WEBPACK_IMPORTED_MODULE_31__.__decorate)([AddLiquidityPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_31__.__metadata)("design:type", Object)], AddLiquidityPage.prototype, "loading", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_31__.__decorate)([AddLiquidityPage.States(), (0,tslib__WEBPACK_IMPORTED_MODULE_31__.__metadata)("design:type", Object)], AddLiquidityPage.prototype, "selectWalletSheet", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_31__.__decorate)([AddLiquidityPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_31__.__metadata)("design:type", Object)], AddLiquidityPage.prototype, "rateAnimationState", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_31__.__decorate)([AddLiquidityPage.States(1), (0,tslib__WEBPACK_IMPORTED_MODULE_31__.__metadata)("design:type", Object)], AddLiquidityPage.prototype, "swapSheet", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_31__.__decorate)([AddLiquidityPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_31__.__metadata)("design:type", Object)], AddLiquidityPage.prototype, "preParams", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_31__.__decorate)([AddLiquidityPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_31__.__metadata)("design:type", Object)], AddLiquidityPage.prototype, "transferOptions", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_31__.__decorate)([AddLiquidityPage.States(1), (0,tslib__WEBPACK_IMPORTED_MODULE_31__.__metadata)("design:type", Object)], AddLiquidityPage.prototype, "anchorPanel", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_31__.__decorate)([AddLiquidityPage.States(1), (0,tslib__WEBPACK_IMPORTED_MODULE_31__.__metadata)("design:type", Object)], AddLiquidityPage.prototype, "quotePanel", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_31__.__decorate)([AddLiquidityPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_31__.__metadata)("design:type", Object)], AddLiquidityPage.prototype, "showGasTip", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_31__.__decorate)([AddLiquidityPage.States(1), (0,tslib__WEBPACK_IMPORTED_MODULE_31__.__metadata)("design:type", Array)], AddLiquidityPage.prototype, "gasFeeTipList", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_31__.__decorate)([AddLiquidityPage.States(1), (0,tslib__WEBPACK_IMPORTED_MODULE_31__.__metadata)("design:type", Object)], AddLiquidityPage.prototype, "addLiquiditySheet", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_31__.__decorate)([AddLiquidityPage.States(1), (0,tslib__WEBPACK_IMPORTED_MODULE_31__.__metadata)("design:type", Object)], AddLiquidityPage.prototype, "selectAssetSheet", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_31__.__decorate)([AddLiquidityPage.OnInit(), (0,tslib__WEBPACK_IMPORTED_MODULE_31__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_31__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_31__.__metadata)("design:returntype", void 0)], AddLiquidityPage.prototype, "bindButton", null);
(0,tslib__WEBPACK_IMPORTED_MODULE_31__.__decorate)([AddLiquidityPage.States(1), (0,tslib__WEBPACK_IMPORTED_MODULE_31__.__metadata)("design:type", Object)], AddLiquidityPage.prototype, "advancedSettingsSheet", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_31__.__decorate)([AddLiquidityPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_31__.__metadata)("design:type", Object)], AddLiquidityPage.prototype, "maxMode", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_31__.__decorate)([AddLiquidityPage.OnReady(), (0,tslib__WEBPACK_IMPORTED_MODULE_31__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_31__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_31__.__metadata)("design:returntype", void 0)], AddLiquidityPage.prototype, "dataInit", null);
(0,tslib__WEBPACK_IMPORTED_MODULE_31__.__decorate)([AddLiquidityPage.AfterViewInit(), (0,tslib__WEBPACK_IMPORTED_MODULE_31__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_31__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_31__.__metadata)("design:returntype", void 0)], AddLiquidityPage.prototype, "initInputListenEvent", null);
(0,tslib__WEBPACK_IMPORTED_MODULE_31__.__decorate)([AddLiquidityPage.OnDestroy(), (0,tslib__WEBPACK_IMPORTED_MODULE_31__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_31__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_31__.__metadata)("design:returntype", void 0)], AddLiquidityPage.prototype, "unsubscribe", null);
(0,tslib__WEBPACK_IMPORTED_MODULE_31__.__decorate)([AddLiquidityPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_31__.__metadata)("design:type", Object)], AddLiquidityPage.prototype, "anchorControl", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_31__.__decorate)([AddLiquidityPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_31__.__metadata)("design:type", Object)], AddLiquidityPage.prototype, "quoteControl", void 0);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (AddLiquidityPage);

/***/ }),

/***/ 97684:
/*!*******************************************************************!*\
  !*** ./apps/bfswap/src/pages/add-liquidity/add-liquidity.type.ts ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   OPERATE: () => (/* binding */ OPERATE)
/* harmony export */ });
/** 操作枚举 */
var OPERATE;
(function (OPERATE) {
  OPERATE["ANCHOR"] = "ANCHOR";
  OPERATE["QUOTE"] = "QUOTE";
})(OPERATE || (OPERATE = {}));

/***/ })

}]);
//# sourceMappingURL=apps_bfswap_src_components_swap-token-chain-icon_swap-token-chain-icon_component_ts-apps_bfsw-e25298.js.map