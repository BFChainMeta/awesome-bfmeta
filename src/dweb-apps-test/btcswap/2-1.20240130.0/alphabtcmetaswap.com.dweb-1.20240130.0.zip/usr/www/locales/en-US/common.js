(self["webpackChunkbfswap"] = self["webpackChunkbfswap"] || []).push([["common"],{

/***/ 84174:
/*!***********************************************************************!*\
  !*** ./apps/bfswap/src/pipes/record-state-bg/record-state-bg.pipe.ts ***!
  \***********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   RecordStateBgPipe: () => (/* binding */ RecordStateBgPipe)
/* harmony export */ });
/* harmony import */ var _services_liquidity_order_lquidity_order_type__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ~services/liquidity-order/lquidity-order.type */ 84601);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 61039);
var _class;



/** 订单状态对应的顶部背景颜色 */
class RecordStateBgPipe {
  constructor() {
    this.transform = RecordStateBgPipe.transform;
  }
  /** 转换函数 */
  static transform(value) {
    if (value === undefined) {
      return 'text-red-10';
    }
    const state = _services_liquidity_order_lquidity_order_type__WEBPACK_IMPORTED_MODULE_0__.ORDER_RECORD_STATE[value];
    const map = {
      [_services_liquidity_order_lquidity_order_type__WEBPACK_IMPORTED_MODULE_0__.$ORDER_STATE.SUCCESS]: 'bg-linear-silvery',
      [_services_liquidity_order_lquidity_order_type__WEBPACK_IMPORTED_MODULE_0__.$ORDER_STATE.ING]: 'bg-linear-primary',
      [_services_liquidity_order_lquidity_order_type__WEBPACK_IMPORTED_MODULE_0__.$ORDER_STATE.FAIL]: 'bg-linear-silvery'
    };
    return map[state];
  }
}
_class = RecordStateBgPipe;
_class.ɵfac = function RecordStateBgPipe_Factory(t) {
  return new (t || _class)();
};
_class.ɵpipe = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefinePipe"]({
  name: "recordStateBg",
  type: _class,
  pure: true,
  standalone: true
});

/***/ }),

/***/ 1256:
/*!*****************************************************************************!*\
  !*** ./apps/bfswap/src/pipes/record-state-color/record-state-color.pipe.ts ***!
  \*****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   RecordStateColorPipe: () => (/* binding */ RecordStateColorPipe)
/* harmony export */ });
/* harmony import */ var _services_liquidity_order_lquidity_order_type__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ~services/liquidity-order/lquidity-order.type */ 84601);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 61039);
var _class;



/** 订单状态对应的颜色 */
class RecordStateColorPipe {
  constructor() {
    this.transform = RecordStateColorPipe.transform;
  }
  /** 转换函数 */
  static transform(value) {
    if (value === undefined) {
      return 'text-red-10';
    }
    const state = _services_liquidity_order_lquidity_order_type__WEBPACK_IMPORTED_MODULE_0__.ORDER_RECORD_STATE[value];
    const map = {
      [_services_liquidity_order_lquidity_order_type__WEBPACK_IMPORTED_MODULE_0__.$ORDER_STATE.SUCCESS]: 'text-green-20',
      [_services_liquidity_order_lquidity_order_type__WEBPACK_IMPORTED_MODULE_0__.$ORDER_STATE.ING]: 'text-primary',
      [_services_liquidity_order_lquidity_order_type__WEBPACK_IMPORTED_MODULE_0__.$ORDER_STATE.FAIL]: 'text-red-10'
    };
    return map[state];
  }
}
_class = RecordStateColorPipe;
_class.ɵfac = function RecordStateColorPipe_Factory(t) {
  return new (t || _class)();
};
_class.ɵpipe = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefinePipe"]({
  name: "recordStateColor",
  type: _class,
  pure: true,
  standalone: true
});

/***/ }),

/***/ 75498:
/*!********************************************************************************************************!*\
  !*** ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/AsyncGenerator.js ***!
  \********************************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var OverloadYield = __webpack_require__(/*! ./OverloadYield.js */ 65646);
function AsyncGenerator(e) {
  var r, t;
  function resume(r, t) {
    try {
      var n = e[r](t),
        o = n.value,
        u = o instanceof OverloadYield;
      Promise.resolve(u ? o.v : o).then(function (t) {
        if (u) {
          var i = "return" === r ? "return" : "next";
          if (!o.k || t.done) return resume(i, t);
          t = e[i](t).value;
        }
        settle(n.done ? "return" : "normal", t);
      }, function (e) {
        resume("throw", e);
      });
    } catch (e) {
      settle("throw", e);
    }
  }
  function settle(e, n) {
    switch (e) {
      case "return":
        r.resolve({
          value: n,
          done: !0
        });
        break;
      case "throw":
        r.reject(n);
        break;
      default:
        r.resolve({
          value: n,
          done: !1
        });
    }
    (r = r.next) ? resume(r.key, r.arg) : t = null;
  }
  this._invoke = function (e, n) {
    return new Promise(function (o, u) {
      var i = {
        key: e,
        arg: n,
        resolve: o,
        reject: u,
        next: null
      };
      t ? t = t.next = i : (r = t = i, resume(e, n));
    });
  }, "function" != typeof e["return"] && (this["return"] = void 0);
}
AsyncGenerator.prototype["function" == typeof Symbol && Symbol.asyncIterator || "@@asyncIterator"] = function () {
  return this;
}, AsyncGenerator.prototype.next = function (e) {
  return this._invoke("next", e);
}, AsyncGenerator.prototype["throw"] = function (e) {
  return this._invoke("throw", e);
}, AsyncGenerator.prototype["return"] = function (e) {
  return this._invoke("return", e);
};
module.exports = AsyncGenerator, module.exports.__esModule = true, module.exports["default"] = module.exports;

/***/ }),

/***/ 65646:
/*!*******************************************************************************************************!*\
  !*** ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/OverloadYield.js ***!
  \*******************************************************************************************************/
/***/ ((module) => {

function _OverloadYield(t, e) {
  this.v = t, this.k = e;
}
module.exports = _OverloadYield, module.exports.__esModule = true, module.exports["default"] = module.exports;

/***/ }),

/***/ 23269:
/*!****************************************************************************************************************!*\
  !*** ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/asyncGeneratorDelegate.js ***!
  \****************************************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var OverloadYield = __webpack_require__(/*! ./OverloadYield.js */ 65646);
function _asyncGeneratorDelegate(t) {
  var e = {},
    n = !1;
  function pump(e, r) {
    return n = !0, r = new Promise(function (n) {
      n(t[e](r));
    }), {
      done: !1,
      value: new OverloadYield(r, 1)
    };
  }
  return e["undefined" != typeof Symbol && Symbol.iterator || "@@iterator"] = function () {
    return this;
  }, e.next = function (t) {
    return n ? (n = !1, t) : pump("next", t);
  }, "function" == typeof t["throw"] && (e["throw"] = function (t) {
    if (n) throw n = !1, t;
    return pump("throw", t);
  }), "function" == typeof t["return"] && (e["return"] = function (t) {
    return n ? (n = !1, t) : pump("return", t);
  }), e;
}
module.exports = _asyncGeneratorDelegate, module.exports.__esModule = true, module.exports["default"] = module.exports;

/***/ }),

/***/ 20278:
/*!*******************************************************************************************************!*\
  !*** ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/asyncIterator.js ***!
  \*******************************************************************************************************/
/***/ ((module) => {

function _asyncIterator(r) {
  var n,
    t,
    o,
    e = 2;
  for ("undefined" != typeof Symbol && (t = Symbol.asyncIterator, o = Symbol.iterator); e--;) {
    if (t && null != (n = r[t])) return n.call(r);
    if (o && null != (n = r[o])) return new AsyncFromSyncIterator(n.call(r));
    t = "@@asyncIterator", o = "@@iterator";
  }
  throw new TypeError("Object is not async iterable");
}
function AsyncFromSyncIterator(r) {
  function AsyncFromSyncIteratorContinuation(r) {
    if (Object(r) !== r) return Promise.reject(new TypeError(r + " is not an object."));
    var n = r.done;
    return Promise.resolve(r.value).then(function (r) {
      return {
        value: r,
        done: n
      };
    });
  }
  return AsyncFromSyncIterator = function AsyncFromSyncIterator(r) {
    this.s = r, this.n = r.next;
  }, AsyncFromSyncIterator.prototype = {
    s: null,
    n: null,
    next: function next() {
      return AsyncFromSyncIteratorContinuation(this.n.apply(this.s, arguments));
    },
    "return": function _return(r) {
      var n = this.s["return"];
      return void 0 === n ? Promise.resolve({
        value: r,
        done: !0
      }) : AsyncFromSyncIteratorContinuation(n.apply(this.s, arguments));
    },
    "throw": function _throw(r) {
      var n = this.s["return"];
      return void 0 === n ? Promise.reject(r) : AsyncFromSyncIteratorContinuation(n.apply(this.s, arguments));
    }
  }, new AsyncFromSyncIterator(r);
}
module.exports = _asyncIterator, module.exports.__esModule = true, module.exports["default"] = module.exports;

/***/ }),

/***/ 32190:
/*!**********************************************************************************************************!*\
  !*** ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/asyncToGenerator.js ***!
  \**********************************************************************************************************/
/***/ ((module) => {

function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) {
  try {
    var info = gen[key](arg);
    var value = info.value;
  } catch (error) {
    reject(error);
    return;
  }
  if (info.done) {
    resolve(value);
  } else {
    Promise.resolve(value).then(_next, _throw);
  }
}
function _asyncToGenerator(fn) {
  return function () {
    var self = this,
      args = arguments;
    return new Promise(function (resolve, reject) {
      var gen = fn.apply(self, args);
      function _next(value) {
        asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value);
      }
      function _throw(err) {
        asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err);
      }
      _next(undefined);
    });
  };
}
module.exports = _asyncToGenerator, module.exports.__esModule = true, module.exports["default"] = module.exports;

/***/ }),

/***/ 62748:
/*!*************************************************************************************************************!*\
  !*** ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/awaitAsyncGenerator.js ***!
  \*************************************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var OverloadYield = __webpack_require__(/*! ./OverloadYield.js */ 65646);
function _awaitAsyncGenerator(e) {
  return new OverloadYield(e, 0);
}
module.exports = _awaitAsyncGenerator, module.exports.__esModule = true, module.exports["default"] = module.exports;

/***/ }),

/***/ 33827:
/*!************************************************************************************************************!*\
  !*** ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/wrapAsyncGenerator.js ***!
  \************************************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var AsyncGenerator = __webpack_require__(/*! ./AsyncGenerator.js */ 75498);
function _wrapAsyncGenerator(fn) {
  return function () {
    return new AsyncGenerator(fn.apply(this, arguments));
  };
}
module.exports = _wrapAsyncGenerator, module.exports.__esModule = true, module.exports["default"] = module.exports;

/***/ }),

/***/ 99941:
/*!****************************************************************!*\
  !*** ./apps/bfswap/src/assets/wallet-util/_setup-5a091007.mjs ***!
  \****************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   p: () => (/* binding */ p)
/* harmony export */ });
/* harmony import */ var D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 52542);
/* harmony import */ var _sha256_d88873b6_mjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./sha256-d88873b6.mjs */ 98080);


const p = /*#__PURE__*/function () {
  var _ref = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
    yield _sha256_d88873b6_mjs__WEBPACK_IMPORTED_MODULE_1__.p.prepare();
  });
  return function p() {
    return _ref.apply(this, arguments);
  };
}();


/***/ }),

/***/ 70842:
/*!****************************************************************!*\
  !*** ./apps/bfswap/src/assets/wallet-util/_setup-a5615467.mjs ***!
  \****************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   prepareTinySecp256k1: () => (/* binding */ i)
/* harmony export */ });
/* harmony import */ var D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 52542);
/* harmony import */ var _index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./index-d96f2042.mjs */ 99449);
/* harmony import */ var _index_cd35f768_mjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./index-cd35f768.mjs */ 8896);



function e() {
  const s = (0,_index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_1__.r)(4);
  return (s[0] << 24) + (s[1] << 16) + (s[2] << 8) + s[3];
}
const i = (0,_index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_1__.a)( /*#__PURE__*/(0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
  (0,_index_cd35f768_mjs__WEBPACK_IMPORTED_MODULE_2__.i)(yield (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
    const a = `${_index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_1__.c.wasmBaseUrl}/tiny-secp256k1/secp256k1.wasm`,
      t = yield _index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_1__.c.wasmLoader(a);
    return (yield WebAssembly.instantiate(t, {
      "./validate_error.mjs": {
        throwError: _index_cd35f768_mjs__WEBPACK_IMPORTED_MODULE_2__.t
      },
      "./rand.mjs": {
        generateInt32: e
      }
    })).instance.exports;
  })());
}));


/***/ }),

/***/ 6821:
/*!*****************************************************************!*\
  !*** ./apps/bfswap/src/assets/wallet-util/address-e9eea1c2.mjs ***!
  \*****************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   fromBase58Check: () => (/* binding */ g),
/* harmony export */   fromBech32: () => (/* binding */ y),
/* harmony export */   fromOutputScript: () => (/* binding */ j),
/* harmony export */   toBase58Check: () => (/* binding */ v),
/* harmony export */   toBech32: () => (/* binding */ E),
/* harmony export */   toOutputScript: () => (/* binding */ b)
/* harmony export */ });
/* harmony import */ var _networks_0de0aba6_mjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./networks-0de0aba6.mjs */ 30274);
/* harmony import */ var _script_c688360e_mjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./script-c688360e.mjs */ 97370);
/* harmony import */ var _p2wsh_046e722b_mjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./p2wsh-046e722b.mjs */ 11051);
/* harmony import */ var _index_4062991a_mjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./index-4062991a.mjs */ 22269);
/* harmony import */ var _index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./index-d96f2042.mjs */ 99449);
/* harmony import */ var _typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./typeforce-a57e57b8.mjs */ 75473);
/* harmony import */ var _crypto_4198e1c6_mjs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./crypto-4198e1c6.mjs */ 99920);
/* harmony import */ var _ripemd160_fdc485e7_mjs__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./ripemd160-fdc485e7.mjs */ 10918);
/* harmony import */ var _WASMInterface_4e8d37b8_mjs__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./WASMInterface-4e8d37b8.mjs */ 18047);
/* harmony import */ var _sha256_d88873b6_mjs__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./sha256-d88873b6.mjs */ 98080);










const {
    typeforce: l
  } = _script_c688360e_mjs__WEBPACK_IMPORTED_MODULE_1__.b,
  m = "WARNING: Sending to a future segwit version address can lead to loss of funds. End users MUST be warned carefully in the GUI and asked if they wish to proceed with caution. Wallets should verify the segwit version from the output of fromBech32, then decide when it is safe to use which version of segwit.";
function g(r) {
  const t = _index_4062991a_mjs__WEBPACK_IMPORTED_MODULE_3__.b.decode(r);
  if (t.length < 21) throw new TypeError(r + " is too short");
  if (t.length > 21) throw new TypeError(r + " is too long");
  return {
    version: t.readUInt8(0),
    hash: t.slice(1)
  };
}
function y(r) {
  let t, e;
  try {
    t = _p2wsh_046e722b_mjs__WEBPACK_IMPORTED_MODULE_2__.b.decode(r);
  } catch (r) {}
  if (t) {
    if (e = t.words[0], 0 !== e) throw new TypeError(r + " uses wrong encoding");
  } else if (t = _p2wsh_046e722b_mjs__WEBPACK_IMPORTED_MODULE_2__.a.decode(r), e = t.words[0], 0 === e) throw new TypeError(r + " uses wrong encoding");
  const o = _p2wsh_046e722b_mjs__WEBPACK_IMPORTED_MODULE_2__.b.fromWords(t.words.slice(1));
  return {
    version: e,
    prefix: t.prefix,
    data: _index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_4__.B.from(o)
  };
}
function v(r, s) {
  l((0,_script_c688360e_mjs__WEBPACK_IMPORTED_MODULE_1__.t)(_script_c688360e_mjs__WEBPACK_IMPORTED_MODULE_1__.H, _script_c688360e_mjs__WEBPACK_IMPORTED_MODULE_1__.U), arguments);
  const n = _index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_4__.B.allocUnsafe(21);
  return n.writeUInt8(s, 0), r.copy(n, 1), _index_4062991a_mjs__WEBPACK_IMPORTED_MODULE_3__.b.encode(n);
}
function E(r, t, e) {
  const o = _p2wsh_046e722b_mjs__WEBPACK_IMPORTED_MODULE_2__.b.toWords(r);
  return o.unshift(t), 0 === t ? _p2wsh_046e722b_mjs__WEBPACK_IMPORTED_MODULE_2__.b.encode(e, o) : _p2wsh_046e722b_mjs__WEBPACK_IMPORTED_MODULE_2__.a.encode(e, o);
}
function j(t, e) {
  e = e || _networks_0de0aba6_mjs__WEBPACK_IMPORTED_MODULE_0__.b;
  try {
    return (0,_p2wsh_046e722b_mjs__WEBPACK_IMPORTED_MODULE_2__.p)({
      output: t,
      network: e
    }).address;
  } catch (r) {}
  try {
    return (0,_p2wsh_046e722b_mjs__WEBPACK_IMPORTED_MODULE_2__.c)({
      output: t,
      network: e
    }).address;
  } catch (r) {}
  try {
    return (0,_p2wsh_046e722b_mjs__WEBPACK_IMPORTED_MODULE_2__.d)({
      output: t,
      network: e
    }).address;
  } catch (r) {}
  try {
    return (0,_p2wsh_046e722b_mjs__WEBPACK_IMPORTED_MODULE_2__.e)({
      output: t,
      network: e
    }).address;
  } catch (r) {}
  try {
    return function (r, t) {
      const e = r.slice(2);
      if (e.length < 2 || e.length > 40) throw new TypeError("Invalid program length for segwit address");
      const o = r[0] - 80;
      if (o < 1 || o > 16) throw new TypeError("Invalid version for segwit address");
      if (r[1] !== e.length) throw new TypeError("Invalid script for segwit address");
      return console.warn(m), E(e, o, t.bech32);
    }(t, e);
  } catch (r) {}
  throw new Error((0,_script_c688360e_mjs__WEBPACK_IMPORTED_MODULE_1__.a)(t) + " has no matching Address");
}
function b(t, e) {
  let o, s;
  e = e || _networks_0de0aba6_mjs__WEBPACK_IMPORTED_MODULE_0__.b;
  try {
    o = g(t);
  } catch (r) {}
  if (o) {
    if (o.version === e.pubKeyHash) return (0,_p2wsh_046e722b_mjs__WEBPACK_IMPORTED_MODULE_2__.p)({
      hash: o.hash
    }).output;
    if (o.version === e.scriptHash) return (0,_p2wsh_046e722b_mjs__WEBPACK_IMPORTED_MODULE_2__.c)({
      hash: o.hash
    }).output;
  } else {
    try {
      s = y(t);
    } catch (r) {}
    if (s) {
      if (s.prefix !== e.bech32) throw new Error(t + " has an invalid prefix");
      if (0 === s.version) {
        if (20 === s.data.length) return (0,_p2wsh_046e722b_mjs__WEBPACK_IMPORTED_MODULE_2__.d)({
          hash: s.data
        }).output;
        if (32 === s.data.length) return (0,_p2wsh_046e722b_mjs__WEBPACK_IMPORTED_MODULE_2__.e)({
          hash: s.data
        }).output;
      } else if (s.version >= 1 && s.version <= 16 && s.data.length >= 2 && s.data.length <= 40) return console.warn(m), (0,_script_c688360e_mjs__WEBPACK_IMPORTED_MODULE_1__.c)([s.version + 80, s.data]);
    }
  }
  throw new Error(t + " has no matching Script");
}


/***/ }),

/***/ 29570:
/*!**************************************************************!*\
  !*** ./apps/bfswap/src/assets/wallet-util/hmac-43177c9b.mjs ***!
  \**************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   a: () => (/* binding */ n),
/* harmony export */   c: () => (/* binding */ r)
/* harmony export */ });
/* harmony import */ var _WASMInterface_4e8d37b8_mjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./WASMInterface-4e8d37b8.mjs */ 18047);

function e(e, n) {
  e.init();
  const {
      blockSize: r
    } = e,
    i = function (e, n) {
      const {
          blockSize: r
        } = e,
        i = (0,_WASMInterface_4e8d37b8_mjs__WEBPACK_IMPORTED_MODULE_0__.g)(n);
      if (i.length > r) {
        e.update(i);
        const t = e.digest("binary");
        return e.init(), t;
      }
      return new Uint8Array(i.buffer, i.byteOffset, i.length);
    }(e, n),
    o = new Uint8Array(r);
  o.set(i);
  const s = new Uint8Array(r);
  for (let t = 0; t < r; t++) {
    const e = o[t];
    s[t] = 92 ^ e, o[t] = 54 ^ e;
  }
  e.update(o);
  const a = {
    init: () => (e.init(), e.update(o), a),
    update: t => (e.update(t), a),
    digest: t => {
      const n = e.digest("binary");
      return e.init(), e.update(s), e.update(n), e.digest(t);
    },
    save: () => {
      throw new Error("save() not supported");
    },
    load: () => {
      throw new Error("load() not supported");
    },
    blockSize: e.blockSize,
    digestSize: e.digestSize
  };
  return a;
}
function n(t, n) {
  if (!t || !t.then) throw new Error('Invalid hash function is provided! Usage: createHMAC(createMD5(), "key").');
  return t.then(t => e(t, n));
}
const r = e;


/***/ }),

/***/ 2465:
/*!***************************************************************!*\
  !*** ./apps/bfswap/src/assets/wallet-util/index-02f15a92.mjs ***!
  \***************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   d: () => (/* binding */ n),
/* harmony export */   e: () => (/* binding */ o)
/* harmony export */ });
/* harmony import */ var _index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./index-d96f2042.mjs */ 99449);
/* harmony import */ var _index_4062991a_mjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./index-4062991a.mjs */ 22269);


function n(r, n) {
  return function (r, e) {
    if (void 0 !== e && r[0] !== e) throw new Error("Invalid network version");
    if (33 === r.length) return {
      version: r[0],
      privateKey: r.slice(1, 33),
      compressed: !1
    };
    if (34 !== r.length) throw new Error("Invalid WIF length");
    if (1 !== r[33]) throw new Error("Invalid compression flag");
    return {
      version: r[0],
      privateKey: r.slice(1, 33),
      compressed: !0
    };
  }(_index_4062991a_mjs__WEBPACK_IMPORTED_MODULE_1__.b.decode(r), n);
}
function o(n, o, i) {
  return _index_4062991a_mjs__WEBPACK_IMPORTED_MODULE_1__.b.encode(function (e, n, o) {
    var i = _index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_0__.B.alloc(o ? 34 : 33);
    return i.writeUInt8(e, 0), n.copy(i, 1), o && (i[33] = 1), i;
  }(n, o, i));
}


/***/ }),

/***/ 8896:
/*!***************************************************************!*\
  !*** ./apps/bfswap/src/assets/wallet-util/index-cd35f768.mjs ***!
  \***************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   a: () => (/* binding */ j),
/* harmony export */   i: () => (/* binding */ X),
/* harmony export */   p: () => (/* binding */ M),
/* harmony export */   t: () => (/* binding */ l)
/* harmony export */ });
/* harmony import */ var _index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./index-d96f2042.mjs */ 99449);
var _globalThis$indexedDB, _globalThis$indexedDB2;

const t = (_globalThis$indexedDB = (_globalThis$indexedDB2 = globalThis.indexedDB) === null || _globalThis$indexedDB2 === void 0 ? void 0 : _globalThis$indexedDB2.cmp) !== null && _globalThis$indexedDB !== void 0 ? _globalThis$indexedDB : function (n, t) {
    const i = Math.min(n.length, t.length);
    for (let l = 0; l < i; ++l) if (n[l] !== t[l]) return n[l] < t[l] ? -1 : 1;
    return n.length === t.length ? 0 : n.length > t.length ? 1 : -1;
  },
  i = {
    [0 .toString()]: "Expected Private",
    [1..toString()]: "Expected Point",
    [2..toString()]: "Expected Tweak",
    [3..toString()]: "Expected Hash",
    [4..toString()]: "Expected Signature",
    [5..toString()]: "Expected Extra Data (32 bytes)",
    [6..toString()]: "Expected Parity (1 | 0)",
    [7..toString()]: "Bad Recovery Id"
  };
function l(n) {
  const t = i[n.toString()] || `Unknow error code: ${n}`;
  throw new TypeError(t);
}
const r = new Uint8Array(32),
  e = new Uint8Array([255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 254, 186, 174, 220, 230, 175, 72, 160, 59, 191, 210, 94, 140, 208, 54, 65, 65]),
  o = new Uint8Array([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 69, 81, 35, 25, 80, 183, 95, 196, 64, 45, 161, 114, 47, 201, 186, 238]);
function u(n) {
  return n instanceof Uint8Array;
}
function f(n, t) {
  for (let i = 0; i < 32; ++i) if (n[i] !== t[i]) return n[i] < t[i] ? -1 : 1;
  return 0;
}
function a(n) {
  return 0 === f(n, r);
}
function s(n) {
  return u(n) && 32 === n.length && f(n, r) > 0 && f(n, e) < 0;
}
function c(n) {
  return u(n) && 32 === n.length;
}
function y(n) {
  s(n) || l(0);
}
function d(n) {
  (function (n) {
    return u(n) && (33 === n.length || 65 === n.length || 32 === n.length);
  })(n) || l(1);
}
function g(n) {
  c(n) || l(1);
}
function v(n) {
  (function (n) {
    return u(n) && 32 === n.length && f(n, e) < 0;
  })(n) || l(2);
}
function h(n) {
  (function (n) {
    return u(n) && 32 === n.length;
  })(n) || l(3);
}
function p(n) {
  (function (n) {
    return void 0 === n || u(n) && 32 === n.length;
  })(n) || l(5);
}
function P(n) {
  (function (n) {
    return u(n) && 64 === n.length && f(n.subarray(0, 32), e) < 0 && f(n.subarray(32, 64), e) < 0;
  })(n) || l(4);
}
function b(n) {
  (function (n) {
    return u(n) && 64 === n.length && f(n.subarray(0, 32), o) < 0;
  })(n) || l(7);
}
let A, S, _, x, T, U, E, I, m, w, N, O, C, k, B, F, L, R, Y, K;
const X = (0,_index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_0__.a)(n => {
  A = n, S = new Uint8Array(A.memory.buffer), _ = A.PRIVATE_INPUT.value, x = A.PUBLIC_KEY_INPUT.value, T = A.PUBLIC_KEY_INPUT2.value, U = A.X_ONLY_PUBLIC_KEY_INPUT.value, E = A.X_ONLY_PUBLIC_KEY_INPUT2.value, I = A.TWEAK_INPUT.value, m = A.HASH_INPUT.value, w = A.EXTRA_DATA_INPUT.value, N = A.SIGNATURE_INPUT.value, O = S.subarray(_, _ + 32), C = S.subarray(x, x + 65), k = S.subarray(T, T + 65), B = S.subarray(U, U + 32), F = S.subarray(E, E + 32), L = S.subarray(I, I + 32), R = S.subarray(m, m + 32), Y = S.subarray(w, w + 32), K = S.subarray(N, N + 64);
});
function z(n, t) {
  return void 0 === n ? void 0 !== t ? t.length : 33 : n ? 33 : 65;
}
function D(n) {
  try {
    return C.set(n), 1 === A.isPoint(n.length);
  } finally {
    C.fill(0);
  }
}
function H(n) {
  return c(n) && D(n);
}
function M(n, t) {
  d(n);
  const i = z(t, n);
  try {
    return C.set(n), A.pointCompress(n.length, i), C.slice(0, i);
  } finally {
    C.fill(0);
  }
}
var j = Object.freeze({
  __proto__: null,
  init: X,
  __initializeContext: function () {
    A.initializeContext();
  },
  isPoint: function (n) {
    return function (n) {
      return u(n) && (33 === n.length || 65 === n.length);
    }(n) && D(n);
  },
  isPointCompressed: function (n) {
    return function (n) {
      return u(n) && 33 === n.length;
    }(n) && D(n);
  },
  isXOnlyPoint: H,
  isPrivate: function (n) {
    return s(n);
  },
  pointAdd: function (n, t, i) {
    d(n), d(t);
    const l = z(i, n);
    try {
      return C.set(n), k.set(t), 1 === A.pointAdd(n.length, t.length, l) ? C.slice(0, l) : null;
    } finally {
      C.fill(0), k.fill(0);
    }
  },
  pointAddScalar: function (n, t, i) {
    d(n), v(t);
    const l = z(i, n);
    try {
      return C.set(n), L.set(t), 1 === A.pointAddScalar(n.length, l) ? C.slice(0, l) : null;
    } finally {
      C.fill(0), L.fill(0);
    }
  },
  pointCompress: M,
  pointFromScalar: function (n, t) {
    y(n);
    const i = z(t);
    try {
      return O.set(n), 1 === A.pointFromScalar(i) ? C.slice(0, i) : null;
    } finally {
      O.fill(0), C.fill(0);
    }
  },
  xOnlyPointFromScalar: function (n) {
    y(n);
    try {
      return O.set(n), A.xOnlyPointFromScalar(), B.slice(0, 32);
    } finally {
      O.fill(0), B.fill(0);
    }
  },
  xOnlyPointFromPoint: function (n) {
    d(n);
    try {
      return C.set(n), A.xOnlyPointFromPoint(n.length), B.slice(0, 32);
    } finally {
      C.fill(0), B.fill(0);
    }
  },
  pointMultiply: function (n, t, i) {
    d(n), v(t);
    const l = z(i, n);
    try {
      return C.set(n), L.set(t), 1 === A.pointMultiply(n.length, l) ? C.slice(0, l) : null;
    } finally {
      C.fill(0), L.fill(0);
    }
  },
  privateAdd: function (n, t) {
    y(n), v(t);
    try {
      return O.set(n), L.set(t), 1 === A.privateAdd() ? O.slice(0, 32) : null;
    } finally {
      O.fill(0), L.fill(0);
    }
  },
  privateSub: function (n, t) {
    if (y(n), v(t), a(t)) return new Uint8Array(n);
    try {
      return O.set(n), L.set(t), 1 === A.privateSub() ? O.slice(0, 32) : null;
    } finally {
      O.fill(0), L.fill(0);
    }
  },
  privateNegate: function (n) {
    y(n);
    try {
      return O.set(n), A.privateNegate(), O.slice(0, 32);
    } finally {
      O.fill(0);
    }
  },
  xOnlyPointAddTweak: function (n, t) {
    g(n), v(t);
    try {
      B.set(n), L.set(t);
      const i = A.xOnlyPointAddTweak();
      return -1 !== i ? {
        parity: i,
        xOnlyPubkey: B.slice(0, 32)
      } : null;
    } finally {
      B.fill(0), L.fill(0);
    }
  },
  xOnlyPointAddTweakCheck: function (n, i, r, e) {
    g(n), g(r), v(i);
    const o = void 0 !== e;
    var u;
    o && 0 !== (u = e) && 1 !== u && l(6);
    try {
      if (B.set(n), F.set(r), L.set(i), o) return 1 === A.xOnlyPointAddTweakCheck(e);
      {
        A.xOnlyPointAddTweak();
        const n = B.slice(0, 32);
        return 0 === t(n, r);
      }
    } finally {
      B.fill(0), F.fill(0), L.fill(0);
    }
  },
  sign: function (n, t, i) {
    h(n), y(t), p(i);
    try {
      return R.set(n), O.set(t), void 0 !== i && Y.set(i), A.sign(void 0 === i ? 0 : 1), K.slice(0, 64);
    } finally {
      R.fill(0), O.fill(0), void 0 !== i && Y.fill(0), K.fill(0);
    }
  },
  signRecoverable: function (n, t, i) {
    h(n), y(t), p(i);
    try {
      R.set(n), O.set(t), void 0 !== i && Y.set(i);
      const l = A.signRecoverable(void 0 === i ? 0 : 1);
      return {
        signature: K.slice(0, 64),
        recoveryId: l
      };
    } finally {
      R.fill(0), O.fill(0), void 0 !== i && Y.fill(0), K.fill(0);
    }
  },
  signSchnorr: function (n, t, i) {
    h(n), y(t), p(i);
    try {
      return R.set(n), O.set(t), void 0 !== i && Y.set(i), A.signSchnorr(void 0 === i ? 0 : 1), K.slice(0, 64);
    } finally {
      R.fill(0), O.fill(0), void 0 !== i && Y.fill(0), K.fill(0);
    }
  },
  verify: function (n, t, i, l = !1) {
    h(n), d(t), P(i);
    try {
      return R.set(n), C.set(t), K.set(i), 1 === A.verify(t.length, !0 === l ? 1 : 0);
    } finally {
      R.fill(0), C.fill(0), K.fill(0);
    }
  },
  recover: function (n, t, i, r = !1) {
    h(n), P(t), function (n) {
      a(n.subarray(0, 32)) && l(4), a(n.subarray(32, 64)) && l(4);
    }(t), 2 & i && b(t), (() => H(t.subarray(0, 32)))() || l(4);
    const e = z(r);
    try {
      return R.set(n), K.set(t), 1 === A.recover(e, i) ? C.slice(0, e) : null;
    } finally {
      R.fill(0), K.fill(0), C.fill(0);
    }
  },
  verifySchnorr: function (n, t, i) {
    h(n), g(t), P(i);
    try {
      return R.set(n), B.set(t), K.set(i), 1 === A.verifySchnorr();
    } finally {
      R.fill(0), B.fill(0), K.fill(0);
    }
  }
});


/***/ }),

/***/ 24645:
/*!****************************************************************!*\
  !*** ./apps/bfswap/src/assets/wallet-util/keccak-1e6b6241.mjs ***!
  \****************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   a: () => (/* binding */ t),
/* harmony export */   c: () => (/* binding */ i),
/* harmony export */   k: () => (/* binding */ s)
/* harmony export */ });
/* harmony import */ var D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 52542);
/* harmony import */ var _sha3_4d44b5a9_mjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./sha3-4d44b5a9.mjs */ 9383);


const s = /*#__PURE__*/function () {
    var _ref = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (_s, t = 512) {
      return (yield (0,_sha3_4d44b5a9_mjs__WEBPACK_IMPORTED_MODULE_1__.g)(t)()).calculate(_s, t, 1);
    });
    return function s(_x) {
      return _ref.apply(this, arguments);
    };
  }(),
  t = /*#__PURE__*/function () {
    var _ref2 = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (s = 512) {
      return i(s, yield (0,_sha3_4d44b5a9_mjs__WEBPACK_IMPORTED_MODULE_1__.g)(s)());
    });
    return function t() {
      return _ref2.apply(this, arguments);
    };
  }(),
  i = (s = 512, t = (0,_sha3_4d44b5a9_mjs__WEBPACK_IMPORTED_MODULE_1__.g)(s).wasm) => {
    const i = s / 8;
    t.init(s);
    const e = {
      init: () => (t.init(s), e),
      update: a => (t.update(a), e),
      digest: a => t.digest(a, 1),
      save: () => t.save(),
      load: a => (t.load(a), e),
      blockSize: 200 - 2 * i,
      digestSize: i
    };
    return e;
  };


/***/ }),

/***/ 51236:
/*!**************************************************************!*\
  !*** ./apps/bfswap/src/assets/wallet-util/p2pk-2e124d52.mjs ***!
  \**************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   a: () => (/* binding */ b),
/* harmony export */   p: () => (/* binding */ f)
/* harmony export */ });
/* harmony import */ var _networks_0de0aba6_mjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./networks-0de0aba6.mjs */ 30274);
/* harmony import */ var _script_c688360e_mjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./script-c688360e.mjs */ 97370);
/* harmony import */ var _p2wsh_046e722b_mjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./p2wsh-046e722b.mjs */ 11051);
/* harmony import */ var _typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./typeforce-a57e57b8.mjs */ 75473);




const a = _script_c688360e_mjs__WEBPACK_IMPORTED_MODULE_1__.O,
  y = a.OP_RESERVED;
function m(t, e) {
  return t.length === e.length && t.every((t, r) => t.equals(e[r]));
}
function f(r, o) {
  if (!(r.input || r.output || r.pubkeys && void 0 !== r.m || r.signatures)) throw new TypeError("Not enough data");
  function f(t) {
    return (0,_script_c688360e_mjs__WEBPACK_IMPORTED_MODULE_1__.d)(t) || void 0 !== (o.allowIncomplete && t === a.OP_0);
  }
  o = Object.assign({
    validate: !0
  }, o || {}), (0,_typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_3__.t)({
    network: _typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_3__.t.maybe(_typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_3__.t.Object),
    m: _typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_3__.t.maybe(_typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_3__.t.Number),
    n: _typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_3__.t.maybe(_typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_3__.t.Number),
    output: _typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_3__.t.maybe(_typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_3__.t.Buffer),
    pubkeys: _typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_3__.t.maybe(_typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_3__.t.arrayOf(_script_c688360e_mjs__WEBPACK_IMPORTED_MODULE_1__.i)),
    signatures: _typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_3__.t.maybe(_typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_3__.t.arrayOf(f)),
    input: _typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_3__.t.maybe(_typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_3__.t.Buffer)
  }, r);
  const w = {
    network: r.network || _networks_0de0aba6_mjs__WEBPACK_IMPORTED_MODULE_0__.b
  };
  let b = [],
    h = !1;
  function g(t) {
    h || (h = !0, b = (0,_script_c688360e_mjs__WEBPACK_IMPORTED_MODULE_1__.e)(t), w.m = b[0] - y, w.n = b[b.length - 2] - y, w.pubkeys = b.slice(1, -2));
  }
  if ((0,_p2wsh_046e722b_mjs__WEBPACK_IMPORTED_MODULE_2__.f)(w, "output", () => {
    if (r.m && w.n && r.pubkeys) return (0,_script_c688360e_mjs__WEBPACK_IMPORTED_MODULE_1__.c)([].concat(y + r.m, r.pubkeys, y + w.n, a.OP_CHECKMULTISIG));
  }), (0,_p2wsh_046e722b_mjs__WEBPACK_IMPORTED_MODULE_2__.f)(w, "m", () => {
    if (w.output) return g(w.output), w.m;
  }), (0,_p2wsh_046e722b_mjs__WEBPACK_IMPORTED_MODULE_2__.f)(w, "n", () => {
    if (w.pubkeys) return w.pubkeys.length;
  }), (0,_p2wsh_046e722b_mjs__WEBPACK_IMPORTED_MODULE_2__.f)(w, "pubkeys", () => {
    if (r.output) return g(r.output), w.pubkeys;
  }), (0,_p2wsh_046e722b_mjs__WEBPACK_IMPORTED_MODULE_2__.f)(w, "signatures", () => {
    if (r.input) return (0,_script_c688360e_mjs__WEBPACK_IMPORTED_MODULE_1__.e)(r.input).slice(1);
  }), (0,_p2wsh_046e722b_mjs__WEBPACK_IMPORTED_MODULE_2__.f)(w, "input", () => {
    if (r.signatures) return (0,_script_c688360e_mjs__WEBPACK_IMPORTED_MODULE_1__.c)([a.OP_0].concat(r.signatures));
  }), (0,_p2wsh_046e722b_mjs__WEBPACK_IMPORTED_MODULE_2__.f)(w, "witness", () => {
    if (w.input) return [];
  }), (0,_p2wsh_046e722b_mjs__WEBPACK_IMPORTED_MODULE_2__.f)(w, "name", () => {
    if (w.m && w.n) return `p2ms(${w.m} of ${w.n})`;
  }), o.validate) {
    if (r.output) {
      if (g(r.output), !_typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_3__.t.Number(b[0])) throw new TypeError("Output is invalid");
      if (!_typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_3__.t.Number(b[b.length - 2])) throw new TypeError("Output is invalid");
      if (b[b.length - 1] !== a.OP_CHECKMULTISIG) throw new TypeError("Output is invalid");
      if (w.m <= 0 || w.n > 16 || w.m > w.n || w.n !== b.length - 3) throw new TypeError("Output is invalid");
      if (!w.pubkeys.every(t => (0,_script_c688360e_mjs__WEBPACK_IMPORTED_MODULE_1__.i)(t))) throw new TypeError("Output is invalid");
      if (void 0 !== r.m && r.m !== w.m) throw new TypeError("m mismatch");
      if (void 0 !== r.n && r.n !== w.n) throw new TypeError("n mismatch");
      if (r.pubkeys && !m(r.pubkeys, w.pubkeys)) throw new TypeError("Pubkeys mismatch");
    }
    if (r.pubkeys) {
      if (void 0 !== r.n && r.n !== r.pubkeys.length) throw new TypeError("Pubkey count mismatch");
      if (w.n = r.pubkeys.length, w.n < w.m) throw new TypeError("Pubkey count cannot be less than m");
    }
    if (r.signatures) {
      if (r.signatures.length < w.m) throw new TypeError("Not enough signatures provided");
      if (r.signatures.length > w.m) throw new TypeError("Too many signatures provided");
    }
    if (r.input) {
      if (r.input[0] !== a.OP_0) throw new TypeError("Input is invalid");
      if (0 === w.signatures.length || !w.signatures.every(f)) throw new TypeError("Input has invalid signature(s)");
      if (r.signatures && !m(r.signatures, w.signatures)) throw new TypeError("Signature mismatch");
      if (void 0 !== r.m && r.m !== r.signatures.length) throw new TypeError("Signature count mismatch");
    }
  }
  return Object.assign(w, r);
}
const w = _script_c688360e_mjs__WEBPACK_IMPORTED_MODULE_1__.O;
function b(r, a) {
  if (!(r.input || r.output || r.pubkey || r.input || r.signature)) throw new TypeError("Not enough data");
  a = Object.assign({
    validate: !0
  }, a || {}), (0,_typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_3__.t)({
    network: _typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_3__.t.maybe(_typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_3__.t.Object),
    output: _typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_3__.t.maybe(_typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_3__.t.Buffer),
    pubkey: _typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_3__.t.maybe(_script_c688360e_mjs__WEBPACK_IMPORTED_MODULE_1__.i),
    signature: _typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_3__.t.maybe(_script_c688360e_mjs__WEBPACK_IMPORTED_MODULE_1__.d),
    input: _typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_3__.t.maybe(_typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_3__.t.Buffer)
  }, r);
  const y = (0,_p2wsh_046e722b_mjs__WEBPACK_IMPORTED_MODULE_2__.v)(() => (0,_script_c688360e_mjs__WEBPACK_IMPORTED_MODULE_1__.e)(r.input)),
    m = {
      name: "p2pk",
      network: r.network || _networks_0de0aba6_mjs__WEBPACK_IMPORTED_MODULE_0__.b
    };
  if ((0,_p2wsh_046e722b_mjs__WEBPACK_IMPORTED_MODULE_2__.f)(m, "output", () => {
    if (r.pubkey) return (0,_script_c688360e_mjs__WEBPACK_IMPORTED_MODULE_1__.c)([r.pubkey, w.OP_CHECKSIG]);
  }), (0,_p2wsh_046e722b_mjs__WEBPACK_IMPORTED_MODULE_2__.f)(m, "pubkey", () => {
    if (r.output) return r.output.slice(1, -1);
  }), (0,_p2wsh_046e722b_mjs__WEBPACK_IMPORTED_MODULE_2__.f)(m, "signature", () => {
    if (r.input) return y()[0];
  }), (0,_p2wsh_046e722b_mjs__WEBPACK_IMPORTED_MODULE_2__.f)(m, "input", () => {
    if (r.signature) return (0,_script_c688360e_mjs__WEBPACK_IMPORTED_MODULE_1__.c)([r.signature]);
  }), (0,_p2wsh_046e722b_mjs__WEBPACK_IMPORTED_MODULE_2__.f)(m, "witness", () => {
    if (m.input) return [];
  }), a.validate) {
    if (r.output) {
      if (r.output[r.output.length - 1] !== w.OP_CHECKSIG) throw new TypeError("Output is invalid");
      if (!(0,_script_c688360e_mjs__WEBPACK_IMPORTED_MODULE_1__.i)(m.pubkey)) throw new TypeError("Output pubkey is invalid");
      if (r.pubkey && !r.pubkey.equals(m.pubkey)) throw new TypeError("Pubkey mismatch");
    }
    if (r.signature && r.input && !r.input.equals(m.input)) throw new TypeError("Signature mismatch");
    if (r.input) {
      if (1 !== y().length) throw new TypeError("Input is invalid");
      if (!(0,_script_c688360e_mjs__WEBPACK_IMPORTED_MODULE_1__.d)(m.signature)) throw new TypeError("Input has invalid signature");
    }
  }
  return Object.assign(m, r);
}


/***/ }),

/***/ 41817:
/*!****************************************************************!*\
  !*** ./apps/bfswap/src/assets/wallet-util/pbkdf2-cdbc1a49.mjs ***!
  \****************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   a: () => (/* binding */ n),
/* harmony export */   p: () => (/* binding */ i)
/* harmony export */ });
/* harmony import */ var D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 52542);
/* harmony import */ var _hmac_43177c9b_mjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./hmac-43177c9b.mjs */ 29570);
/* harmony import */ var _WASMInterface_4e8d37b8_mjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./WASMInterface-4e8d37b8.mjs */ 18047);



const n = /*#__PURE__*/function () {
    var _ref = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (t) {
      const e = yield t.hashFunction;
      if (!e) throw new Error('Invalid hash function is provided! Usage: pbkdf2("password", "salt", 1000, 32, createSHA1()).');
      return i({
        ...t,
        hashFunction: e
      });
    });
    return function n(_x) {
      return _ref.apply(this, arguments);
    };
  }(),
  i = n => {
    if (!n.hashFunction) throw new Error('Invalid hash function is provided! Usage: pbkdf2Sync("password", "salt", 1000, 32, createSHA1Sync()).');
    (t => {
      if (!t || "object" != typeof t) throw new Error("Invalid options parameter. It requires an object.");
      if (!Number.isInteger(t.iterations) || t.iterations < 1) throw new Error("Iterations should be a positive number");
      if (!Number.isInteger(t.hashLength) || t.hashLength < 1) throw new Error("Hash length should be a positive number");
      if (void 0 === t.outputType && (t.outputType = "binary"), !["hex", "binary"].includes(t.outputType)) throw new Error(`Insupported output type ${t.outputType}. Valid values: ['hex', 'binary']`);
    })(n);
    return function (t, n, i, a, s) {
      const o = new Uint8Array(a),
        h = new Uint8Array(n.length + 4),
        u = new DataView(h.buffer),
        p = (0,_WASMInterface_4e8d37b8_mjs__WEBPACK_IMPORTED_MODULE_2__.g)(n),
        c = new Uint8Array(p.buffer, p.byteOffset, p.length);
      h.set(c);
      let f = 0;
      const d = t.digestSize,
        l = Math.ceil(a / d);
      let w, y;
      for (let e = 1; e <= l; e++) {
        u.setUint32(n.length, e), t.init(), t.update(h), w = t.digest("binary"), y = w.slice();
        for (let e = 1; e < i; e++) {
          t.init(), t.update(y), y = t.digest("binary");
          for (let t = 0; t < d; t++) w[t] ^= y[t];
        }
        o.set(w.subarray(0, a - f), f), f += d;
      }
      if ("hex" === s) {
        const t = new Uint8Array(2 * a);
        return (0,_WASMInterface_4e8d37b8_mjs__WEBPACK_IMPORTED_MODULE_2__.a)(t, o, a);
      }
      return o;
    }((0,_hmac_43177c9b_mjs__WEBPACK_IMPORTED_MODULE_1__.c)(n.hashFunction, n.password), n.salt, n.iterations, n.hashLength, n.outputType);
  };


/***/ }),

/***/ 27811:
/*!**************************************************************!*\
  !*** ./apps/bfswap/src/assets/wallet-util/sha1-81fbe1a9.mjs ***!
  \**************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   a: () => (/* binding */ i),
/* harmony export */   c: () => (/* binding */ e),
/* harmony export */   p: () => (/* binding */ s),
/* harmony export */   s: () => (/* binding */ t)
/* harmony export */ });
/* harmony import */ var D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 52542);
/* harmony import */ var _WASMInterface_4e8d37b8_mjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./WASMInterface-4e8d37b8.mjs */ 18047);


const s = (0,_WASMInterface_4e8d37b8_mjs__WEBPACK_IMPORTED_MODULE_1__.c)("sha1", 20),
  t = /*#__PURE__*/function () {
    var _ref = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (a) {
      return (yield s()).calculate(a);
    });
    return function t(_x) {
      return _ref.apply(this, arguments);
    };
  }(),
  e = /*#__PURE__*/function () {
    var _ref2 = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      return i(yield s());
    });
    return function e() {
      return _ref2.apply(this, arguments);
    };
  }(),
  i = (a = s.wasm) => {
    a.init();
    const t = {
      init: () => (a.init(), t),
      update: s => (a.update(s), t),
      digest: s => a.digest(s),
      save: () => a.save(),
      load: s => (a.load(s), t),
      blockSize: 64,
      digestSize: 20
    };
    return t;
  };


/***/ }),

/***/ 9383:
/*!**************************************************************!*\
  !*** ./apps/bfswap/src/assets/wallet-util/sha3-4d44b5a9.mjs ***!
  \**************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   a: () => (/* binding */ n),
/* harmony export */   c: () => (/* binding */ i),
/* harmony export */   g: () => (/* binding */ s),
/* harmony export */   s: () => (/* binding */ e)
/* harmony export */ });
/* harmony import */ var D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 52542);
/* harmony import */ var _WASMInterface_4e8d37b8_mjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./WASMInterface-4e8d37b8.mjs */ 18047);


const t = {
  224: (0,_WASMInterface_4e8d37b8_mjs__WEBPACK_IMPORTED_MODULE_1__.c)("sha3", 28),
  256: (0,_WASMInterface_4e8d37b8_mjs__WEBPACK_IMPORTED_MODULE_1__.c)("sha3", 32),
  384: (0,_WASMInterface_4e8d37b8_mjs__WEBPACK_IMPORTED_MODULE_1__.c)("sha3", 48),
  512: (0,_WASMInterface_4e8d37b8_mjs__WEBPACK_IMPORTED_MODULE_1__.c)("sha3", 64)
};
Object.setPrototypeOf(t, null);
const s = a => {
    if (a in t == !1) throw new Error(`Invalid variant! Valid values: ${Object.keys(t)}`);
    return t[a];
  },
  e = /*#__PURE__*/function () {
    var _ref = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (a, t = 512) {
      return (yield s(t)()).calculate(a, t, 6);
    });
    return function e(_x) {
      return _ref.apply(this, arguments);
    };
  }(),
  i = /*#__PURE__*/function () {
    var _ref2 = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (a = 512) {
      return n(a, yield s(a)());
    });
    return function i() {
      return _ref2.apply(this, arguments);
    };
  }(),
  n = (a = 512, t = s(a).wasm) => {
    const e = a / 8;
    t.init(a);
    const i = {
      init: () => (t.init(a), i),
      update: a => (t.update(a), i),
      digest: a => t.digest(a, 6),
      save: () => t.save(),
      load: a => (t.load(a), i),
      blockSize: 200 - 2 * e,
      digestSize: e
    };
    return i;
  };


/***/ }),

/***/ 15574:
/*!****************************************************************!*\
  !*** ./apps/bfswap/src/assets/wallet-util/sha512-7b87e5c4.mjs ***!
  \****************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   a: () => (/* binding */ e),
/* harmony export */   c: () => (/* binding */ i),
/* harmony export */   p: () => (/* binding */ s),
/* harmony export */   s: () => (/* binding */ t)
/* harmony export */ });
/* harmony import */ var D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 52542);
/* harmony import */ var _WASMInterface_4e8d37b8_mjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./WASMInterface-4e8d37b8.mjs */ 18047);


const s = (0,_WASMInterface_4e8d37b8_mjs__WEBPACK_IMPORTED_MODULE_1__.c)("sha512", 64),
  t = /*#__PURE__*/function () {
    var _ref = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (a) {
      return (yield s()).calculate(a, 512);
    });
    return function t(_x) {
      return _ref.apply(this, arguments);
    };
  }(),
  e = /*#__PURE__*/function () {
    var _ref2 = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      return i(yield s());
    });
    return function e() {
      return _ref2.apply(this, arguments);
    };
  }(),
  i = (a = s.wasm) => {
    a.init(512);
    const t = {
      init: () => (a.init(512), t),
      update: s => (a.update(s), t),
      digest: s => a.digest(s),
      save: () => a.save(),
      load: s => (a.load(s), t),
      blockSize: 128,
      digestSize: 64
    };
    return t;
  };


/***/ }),

/***/ 83330:
/*!*******************************************************************!*\
  !*** ./apps/bfswap/src/assets/wallet-util/wordlists-b107198c.mjs ***!
  \*******************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ALL_LANGUAGE: () => (/* binding */ e),
/* harmony export */   getDefaultWordlist: () => (/* binding */ r),
/* harmony export */   getWordList: () => (/* binding */ t),
/* harmony export */   setDefaultWordlist: () => (/* binding */ s)
/* harmony export */ });
/* harmony import */ var D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 52542);

const e = ["english", "japanese", "chinese_simplified", "chinese_traditional", "czech", "french", "italian", "korean", "portuguese", "spanish"],
  t = /*#__PURE__*/function () {
    var _ref = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (e) {
      switch (e) {
        case "chinese_simplified":
          return (yield __webpack_require__.e(/*! import() */ "apps_bfswap_src_assets_wallet-util_wordlists_chinese_simplified_mjs").then(__webpack_require__.bind(__webpack_require__, /*! ./wordlists/chinese_simplified.mjs */ 92689))).default;
        case "chinese_traditional":
          return (yield __webpack_require__.e(/*! import() */ "apps_bfswap_src_assets_wallet-util_wordlists_chinese_traditional_mjs").then(__webpack_require__.bind(__webpack_require__, /*! ./wordlists/chinese_traditional.mjs */ 88944))).default;
        case "czech":
          return (yield __webpack_require__.e(/*! import() */ "apps_bfswap_src_assets_wallet-util_wordlists_czech_mjs").then(__webpack_require__.bind(__webpack_require__, /*! ./wordlists/czech.mjs */ 67959))).default;
        case "english":
          return (yield __webpack_require__.e(/*! import() */ "apps_bfswap_src_assets_wallet-util_wordlists_english_mjs").then(__webpack_require__.bind(__webpack_require__, /*! ./wordlists/english.mjs */ 72246))).default;
        case "french":
          return (yield __webpack_require__.e(/*! import() */ "apps_bfswap_src_assets_wallet-util_wordlists_french_mjs").then(__webpack_require__.bind(__webpack_require__, /*! ./wordlists/french.mjs */ 74372))).default;
        case "italian":
          return (yield __webpack_require__.e(/*! import() */ "apps_bfswap_src_assets_wallet-util_wordlists_italian_mjs").then(__webpack_require__.bind(__webpack_require__, /*! ./wordlists/italian.mjs */ 41874))).default;
        case "japanese":
          return (yield __webpack_require__.e(/*! import() */ "apps_bfswap_src_assets_wallet-util_wordlists_japanese_mjs").then(__webpack_require__.bind(__webpack_require__, /*! ./wordlists/japanese.mjs */ 60832))).default;
        case "korean":
          return (yield __webpack_require__.e(/*! import() */ "apps_bfswap_src_assets_wallet-util_wordlists_korean_mjs").then(__webpack_require__.bind(__webpack_require__, /*! ./wordlists/korean.mjs */ 58744))).default;
        case "portuguese":
          return (yield __webpack_require__.e(/*! import() */ "apps_bfswap_src_assets_wallet-util_wordlists_portuguese_mjs").then(__webpack_require__.bind(__webpack_require__, /*! ./wordlists/portuguese.mjs */ 77153))).default;
        case "spanish":
          return (yield __webpack_require__.e(/*! import() */ "apps_bfswap_src_assets_wallet-util_wordlists_spanish_mjs").then(__webpack_require__.bind(__webpack_require__, /*! ./wordlists/spanish.mjs */ 86298))).default;
      }
      throw new Error(`unsupport language: ${e}`);
    });
    return function t(_x) {
      return _ref.apply(this, arguments);
    };
  }(),
  a = new Map();
let i;
function s(e, t) {
  if (void 0 === t && (t = a.get(e)), void 0 === t) throw new Error(`need load wordList first, call \`await getWordList('${e}')\`.`);
  i = {
    language: e,
    wordlist: t
  };
}
function r() {
  return i;
}


/***/ })

}]);
//# sourceMappingURL=common.js.map