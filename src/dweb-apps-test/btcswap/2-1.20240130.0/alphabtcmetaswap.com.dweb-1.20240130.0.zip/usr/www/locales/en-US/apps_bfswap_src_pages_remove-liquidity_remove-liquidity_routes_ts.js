"use strict";
(self["webpackChunkbfswap"] = self["webpackChunkbfswap"] || []).push([["apps_bfswap_src_pages_remove-liquidity_remove-liquidity_routes_ts"],{

/***/ 51580:
/*!***************************************************************************!*\
  !*** ./apps/bfswap/src/pages/remove-liquidity/remove-liquidity.routes.ts ***!
  \***************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   routes: () => (/* binding */ routes)
/* harmony export */ });
/**
 * 路由
 */
const routes = [{
  path: '',
  title: "Remove liquidity",
  loadComponent: () => Promise.all(/*! import() */[__webpack_require__.e("default-apps_bfswap_src_components_order-settings_order-settings_component_ts"), __webpack_require__.e("apps_bfswap_src_pages_remove-liquidity_remove-liquidity_component_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./remove-liquidity.component */ 892))
}, {
  path: 'coin-pool-detail',
  title: "Pool Tokens Details",
  loadComponent: () => __webpack_require__.e(/*! import() */ "apps_bfswap_src_pages_remove-liquidity_pages_coin-pool-detail_coin-pool-detail_component_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/coin-pool-detail/coin-pool-detail.component */ 63925))
}];
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (routes);

/***/ })

}]);
//# sourceMappingURL=apps_bfswap_src_pages_remove-liquidity_remove-liquidity_routes_ts.js.map