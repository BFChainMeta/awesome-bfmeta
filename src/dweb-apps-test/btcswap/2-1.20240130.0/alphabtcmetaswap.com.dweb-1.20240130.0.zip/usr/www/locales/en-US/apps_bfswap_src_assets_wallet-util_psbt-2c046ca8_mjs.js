"use strict";
(self["webpackChunkbfswap"] = self["webpackChunkbfswap"] || []).push([["apps_bfswap_src_assets_wallet-util_psbt-2c046ca8_mjs"],{

/***/ 82734:
/*!**************************************************************!*\
  !*** ./apps/bfswap/src/assets/wallet-util/psbt-2c046ca8.mjs ***!
  \**************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Psbt: () => (/* binding */ _n)
/* harmony export */ });
/* harmony import */ var _index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./index-d96f2042.mjs */ 99449);
/* harmony import */ var _address_e9eea1c2_mjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./address-e9eea1c2.mjs */ 6821);
/* harmony import */ var _script_c688360e_mjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./script-c688360e.mjs */ 97370);
/* harmony import */ var _crypto_4198e1c6_mjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./crypto-4198e1c6.mjs */ 99920);
/* harmony import */ var _networks_0de0aba6_mjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./networks-0de0aba6.mjs */ 30274);
/* harmony import */ var _p2wsh_046e722b_mjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./p2wsh-046e722b.mjs */ 11051);
/* harmony import */ var _p2pk_2e124d52_mjs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./p2pk-2e124d52.mjs */ 51236);
/* harmony import */ var _index_4062991a_mjs__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./index-4062991a.mjs */ 22269);
/* harmony import */ var _sha256_d88873b6_mjs__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./sha256-d88873b6.mjs */ 98080);
/* harmony import */ var _WASMInterface_4e8d37b8_mjs__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./WASMInterface-4e8d37b8.mjs */ 18047);
/* harmony import */ var _typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./typeforce-a57e57b8.mjs */ 75473);
/* harmony import */ var _ripemd160_fdc485e7_mjs__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./ripemd160-fdc485e7.mjs */ 10918);












var P,
  U,
  C,
  x,
  H = {
    exports: {}
  },
  B = {},
  L = {},
  R = {},
  V = {},
  K = {},
  D = {};
P = D, Object.defineProperty(P, "__esModule", {
  value: !0
}), (U = P.GlobalTypes || (P.GlobalTypes = {}))[U.UNSIGNED_TX = 0] = "UNSIGNED_TX", U[U.GLOBAL_XPUB = 1] = "GLOBAL_XPUB", P.GLOBAL_TYPE_NAMES = ["unsignedTx", "globalXpub"], (C = P.InputTypes || (P.InputTypes = {}))[C.NON_WITNESS_UTXO = 0] = "NON_WITNESS_UTXO", C[C.WITNESS_UTXO = 1] = "WITNESS_UTXO", C[C.PARTIAL_SIG = 2] = "PARTIAL_SIG", C[C.SIGHASH_TYPE = 3] = "SIGHASH_TYPE", C[C.REDEEM_SCRIPT = 4] = "REDEEM_SCRIPT", C[C.WITNESS_SCRIPT = 5] = "WITNESS_SCRIPT", C[C.BIP32_DERIVATION = 6] = "BIP32_DERIVATION", C[C.FINAL_SCRIPTSIG = 7] = "FINAL_SCRIPTSIG", C[C.FINAL_SCRIPTWITNESS = 8] = "FINAL_SCRIPTWITNESS", C[C.POR_COMMITMENT = 9] = "POR_COMMITMENT", C[C.TAP_KEY_SIG = 19] = "TAP_KEY_SIG", C[C.TAP_SCRIPT_SIG = 20] = "TAP_SCRIPT_SIG", C[C.TAP_LEAF_SCRIPT = 21] = "TAP_LEAF_SCRIPT", C[C.TAP_BIP32_DERIVATION = 22] = "TAP_BIP32_DERIVATION", C[C.TAP_INTERNAL_KEY = 23] = "TAP_INTERNAL_KEY", C[C.TAP_MERKLE_ROOT = 24] = "TAP_MERKLE_ROOT", P.INPUT_TYPE_NAMES = ["nonWitnessUtxo", "witnessUtxo", "partialSig", "sighashType", "redeemScript", "witnessScript", "bip32Derivation", "finalScriptSig", "finalScriptWitness", "porCommitment", "tapKeySig", "tapScriptSig", "tapLeafScript", "tapBip32Derivation", "tapInternalKey", "tapMerkleRoot"], (x = P.OutputTypes || (P.OutputTypes = {}))[x.REDEEM_SCRIPT = 0] = "REDEEM_SCRIPT", x[x.WITNESS_SCRIPT = 1] = "WITNESS_SCRIPT", x[x.BIP32_DERIVATION = 2] = "BIP32_DERIVATION", x[x.TAP_INTERNAL_KEY = 5] = "TAP_INTERNAL_KEY", x[x.TAP_TREE = 6] = "TAP_TREE", x[x.TAP_BIP32_DERIVATION = 7] = "TAP_BIP32_DERIVATION", P.OUTPUT_TYPE_NAMES = ["redeemScript", "witnessScript", "bip32Derivation", "tapInternalKey", "tapTree", "tapBip32Derivation"];
var G = {};
const {
  Buffer: F
} = _index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_0__.b;
Object.defineProperty(G, "__esModule", {
  value: !0
});
const M = D;
G.decode = function (e) {
  if (e.key[0] !== M.GlobalTypes.GLOBAL_XPUB) throw new Error("Decode Error: could not decode globalXpub with key 0x" + e.key.toString("hex"));
  if (79 !== e.key.length || ![2, 3].includes(e.key[46])) throw new Error("Decode Error: globalXpub has invalid extended pubkey in key 0x" + e.key.toString("hex"));
  if (e.value.length / 4 % 1 != 0) throw new Error("Decode Error: Global GLOBAL_XPUB value length should be multiple of 4");
  const t = e.key.slice(1),
    n = {
      masterFingerprint: e.value.slice(0, 4),
      extendedPubkey: t,
      path: "m"
    };
  for (const t of (r = e.value.length / 4 - 1, [...Array(r).keys()])) {
    const r = e.value.readUInt32LE(4 * t + 4),
      i = !!(2147483648 & r),
      s = 2147483647 & r;
    n.path += "/" + s.toString(10) + (i ? "'" : "");
  }
  var r;
  return n;
}, G.encode = function (e) {
  const t = F.from([M.GlobalTypes.GLOBAL_XPUB]),
    n = F.concat([t, e.extendedPubkey]),
    r = e.path.split("/"),
    i = F.allocUnsafe(4 * r.length);
  e.masterFingerprint.copy(i, 0);
  let s = 4;
  return r.slice(1).forEach(e => {
    const t = "'" === e.slice(-1);
    let n = 2147483647 & parseInt(t ? e.slice(0, -1) : e, 10);
    t && (n += 2147483648), i.writeUInt32LE(n, s), s += 4;
  }), {
    key: n,
    value: i
  };
}, G.expected = "{ masterFingerprint: Buffer; extendedPubkey: Buffer; path: string; }", G.check = function (e) {
  const t = e.extendedPubkey,
    n = e.masterFingerprint,
    r = e.path;
  return F.isBuffer(t) && 78 === t.length && [2, 3].indexOf(t[45]) > -1 && F.isBuffer(n) && 4 === n.length && "string" == typeof r && !!r.match(/^m(\/\d+'?)*$/);
}, G.canAddToArray = function (e, t, n) {
  const r = t.extendedPubkey.toString("hex");
  return !n.has(r) && (n.add(r), 0 === e.filter(e => e.extendedPubkey.equals(t.extendedPubkey)).length);
};
var W = {};
const {
  Buffer: X
} = _index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_0__.b;
Object.defineProperty(W, "__esModule", {
  value: !0
});
const j = D;
W.encode = function (e) {
  return {
    key: X.from([j.GlobalTypes.UNSIGNED_TX]),
    value: e.toBuffer()
  };
};
var q = {};
const {
  Buffer: Y
} = _index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_0__.b;
Object.defineProperty(q, "__esModule", {
  value: !0
});
const $ = D;
q.decode = function (e) {
  if (e.key[0] !== $.InputTypes.FINAL_SCRIPTSIG) throw new Error("Decode Error: could not decode finalScriptSig with key 0x" + e.key.toString("hex"));
  return e.value;
}, q.encode = function (e) {
  return {
    key: Y.from([$.InputTypes.FINAL_SCRIPTSIG]),
    value: e
  };
}, q.expected = "Buffer", q.check = function (e) {
  return Y.isBuffer(e);
}, q.canAdd = function (e, t) {
  return !!e && !!t && void 0 === e.finalScriptSig;
};
var z = {};
const {
  Buffer: J
} = _index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_0__.b;
Object.defineProperty(z, "__esModule", {
  value: !0
});
const Q = D;
z.decode = function (e) {
  if (e.key[0] !== Q.InputTypes.FINAL_SCRIPTWITNESS) throw new Error("Decode Error: could not decode finalScriptWitness with key 0x" + e.key.toString("hex"));
  return e.value;
}, z.encode = function (e) {
  return {
    key: J.from([Q.InputTypes.FINAL_SCRIPTWITNESS]),
    value: e
  };
}, z.expected = "Buffer", z.check = function (e) {
  return J.isBuffer(e);
}, z.canAdd = function (e, t) {
  return !!e && !!t && void 0 === e.finalScriptWitness;
};
var Z = {};
const {
  Buffer: ee
} = _index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_0__.b;
Object.defineProperty(Z, "__esModule", {
  value: !0
});
const te = D;
Z.decode = function (e) {
  if (e.key[0] !== te.InputTypes.NON_WITNESS_UTXO) throw new Error("Decode Error: could not decode nonWitnessUtxo with key 0x" + e.key.toString("hex"));
  return e.value;
}, Z.encode = function (e) {
  return {
    key: ee.from([te.InputTypes.NON_WITNESS_UTXO]),
    value: e
  };
}, Z.expected = "Buffer", Z.check = function (e) {
  return ee.isBuffer(e);
}, Z.canAdd = function (e, t) {
  return !!e && !!t && void 0 === e.nonWitnessUtxo;
};
var ne = {};
const {
  Buffer: re
} = _index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_0__.b;
Object.defineProperty(ne, "__esModule", {
  value: !0
});
const ie = D;
ne.decode = function (e) {
  if (e.key[0] !== ie.InputTypes.PARTIAL_SIG) throw new Error("Decode Error: could not decode partialSig with key 0x" + e.key.toString("hex"));
  if (34 !== e.key.length && 66 !== e.key.length || ![2, 3, 4].includes(e.key[1])) throw new Error("Decode Error: partialSig has invalid pubkey in key 0x" + e.key.toString("hex"));
  return {
    pubkey: e.key.slice(1),
    signature: e.value
  };
}, ne.encode = function (e) {
  const t = re.from([ie.InputTypes.PARTIAL_SIG]);
  return {
    key: re.concat([t, e.pubkey]),
    value: e.signature
  };
}, ne.expected = "{ pubkey: Buffer; signature: Buffer; }", ne.check = function (e) {
  return re.isBuffer(e.pubkey) && re.isBuffer(e.signature) && [33, 65].includes(e.pubkey.length) && [2, 3, 4].includes(e.pubkey[0]) && function (e) {
    if (!re.isBuffer(e) || e.length < 9) return !1;
    if (48 !== e[0]) return !1;
    if (e.length !== e[1] + 3) return !1;
    if (2 !== e[2]) return !1;
    const t = e[3];
    if (t > 33 || t < 1) return !1;
    if (2 !== e[3 + t + 1]) return !1;
    const n = e[3 + t + 2];
    return !(n > 33 || n < 1) && e.length === 3 + t + 2 + n + 2;
  }(e.signature);
}, ne.canAddToArray = function (e, t, n) {
  const r = t.pubkey.toString("hex");
  return !n.has(r) && (n.add(r), 0 === e.filter(e => e.pubkey.equals(t.pubkey)).length);
};
var se = {};
const {
  Buffer: oe
} = _index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_0__.b;
Object.defineProperty(se, "__esModule", {
  value: !0
});
const ue = D;
se.decode = function (e) {
  if (e.key[0] !== ue.InputTypes.POR_COMMITMENT) throw new Error("Decode Error: could not decode porCommitment with key 0x" + e.key.toString("hex"));
  return e.value.toString("utf8");
}, se.encode = function (e) {
  return {
    key: oe.from([ue.InputTypes.POR_COMMITMENT]),
    value: oe.from(e, "utf8")
  };
}, se.expected = "string", se.check = function (e) {
  return "string" == typeof e;
}, se.canAdd = function (e, t) {
  return !!e && !!t && void 0 === e.porCommitment;
};
var ae = {};
const {
  Buffer: ce
} = _index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_0__.b;
Object.defineProperty(ae, "__esModule", {
  value: !0
});
const pe = D;
ae.decode = function (e) {
  if (e.key[0] !== pe.InputTypes.SIGHASH_TYPE) throw new Error("Decode Error: could not decode sighashType with key 0x" + e.key.toString("hex"));
  return e.value.readUInt32LE(0);
}, ae.encode = function (e) {
  const t = ce.from([pe.InputTypes.SIGHASH_TYPE]),
    n = ce.allocUnsafe(4);
  return n.writeUInt32LE(e, 0), {
    key: t,
    value: n
  };
}, ae.expected = "number", ae.check = function (e) {
  return "number" == typeof e;
}, ae.canAdd = function (e, t) {
  return !!e && !!t && void 0 === e.sighashType;
};
var fe = {};
const {
  Buffer: he
} = _index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_0__.b;
Object.defineProperty(fe, "__esModule", {
  value: !0
});
const le = D;
function de(e) {
  return he.isBuffer(e) && (64 === e.length || 65 === e.length);
}
fe.decode = function (e) {
  if (e.key[0] !== le.InputTypes.TAP_KEY_SIG || 1 !== e.key.length) throw new Error("Decode Error: could not decode tapKeySig with key 0x" + e.key.toString("hex"));
  if (!de(e.value)) throw new Error("Decode Error: tapKeySig not a valid 64-65-byte BIP340 signature");
  return e.value;
}, fe.encode = function (e) {
  return {
    key: he.from([le.InputTypes.TAP_KEY_SIG]),
    value: e
  };
}, fe.expected = "Buffer", fe.check = de, fe.canAdd = function (e, t) {
  return !!e && !!t && void 0 === e.tapKeySig;
};
var ye = {};
const {
  Buffer: Ee
} = _index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_0__.b;
Object.defineProperty(ye, "__esModule", {
  value: !0
});
const Se = D;
ye.decode = function (e) {
  if (e.key[0] !== Se.InputTypes.TAP_LEAF_SCRIPT) throw new Error("Decode Error: could not decode tapLeafScript with key 0x" + e.key.toString("hex"));
  if ((e.key.length - 2) % 32 != 0) throw new Error("Decode Error: tapLeafScript has invalid control block in key 0x" + e.key.toString("hex"));
  const t = e.value[e.value.length - 1];
  if ((254 & e.key[1]) !== t) throw new Error("Decode Error: tapLeafScript bad leaf version in key 0x" + e.key.toString("hex"));
  const n = e.value.slice(0, -1);
  return {
    controlBlock: e.key.slice(1),
    script: n,
    leafVersion: t
  };
}, ye.encode = function (e) {
  const t = Ee.from([Se.InputTypes.TAP_LEAF_SCRIPT]),
    n = Ee.from([e.leafVersion]);
  return {
    key: Ee.concat([t, e.controlBlock]),
    value: Ee.concat([e.script, n])
  };
}, ye.expected = "{ controlBlock: Buffer; leafVersion: number, script: Buffer; }", ye.check = function (e) {
  return Ee.isBuffer(e.controlBlock) && (e.controlBlock.length - 1) % 32 == 0 && (254 & e.controlBlock[0]) === e.leafVersion && Ee.isBuffer(e.script);
}, ye.canAddToArray = function (e, t, n) {
  const r = t.controlBlock.toString("hex");
  return !n.has(r) && (n.add(r), 0 === e.filter(e => e.controlBlock.equals(t.controlBlock)).length);
};
var _e = {};
const {
  Buffer: we
} = _index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_0__.b;
Object.defineProperty(_e, "__esModule", {
  value: !0
});
const Ie = D;
function ge(e) {
  return we.isBuffer(e) && 32 === e.length;
}
_e.decode = function (e) {
  if (e.key[0] !== Ie.InputTypes.TAP_MERKLE_ROOT || 1 !== e.key.length) throw new Error("Decode Error: could not decode tapMerkleRoot with key 0x" + e.key.toString("hex"));
  if (!ge(e.value)) throw new Error("Decode Error: tapMerkleRoot not a 32-byte hash");
  return e.value;
}, _e.encode = function (e) {
  return {
    key: we.from([Ie.InputTypes.TAP_MERKLE_ROOT]),
    value: e
  };
}, _e.expected = "Buffer", _e.check = ge, _e.canAdd = function (e, t) {
  return !!e && !!t && void 0 === e.tapMerkleRoot;
};
var Te = {};
const {
  Buffer: ke
} = _index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_0__.b;
Object.defineProperty(Te, "__esModule", {
  value: !0
});
const be = D;
Te.decode = function (e) {
  if (e.key[0] !== be.InputTypes.TAP_SCRIPT_SIG) throw new Error("Decode Error: could not decode tapScriptSig with key 0x" + e.key.toString("hex"));
  if (65 !== e.key.length) throw new Error("Decode Error: tapScriptSig has invalid key 0x" + e.key.toString("hex"));
  if (64 !== e.value.length && 65 !== e.value.length) throw new Error("Decode Error: tapScriptSig has invalid signature in key 0x" + e.key.toString("hex"));
  return {
    pubkey: e.key.slice(1, 33),
    leafHash: e.key.slice(33),
    signature: e.value
  };
}, Te.encode = function (e) {
  const t = ke.from([be.InputTypes.TAP_SCRIPT_SIG]);
  return {
    key: ke.concat([t, e.pubkey, e.leafHash]),
    value: e.signature
  };
}, Te.expected = "{ pubkey: Buffer; leafHash: Buffer; signature: Buffer; }", Te.check = function (e) {
  return ke.isBuffer(e.pubkey) && ke.isBuffer(e.leafHash) && ke.isBuffer(e.signature) && 32 === e.pubkey.length && 32 === e.leafHash.length && (64 === e.signature.length || 65 === e.signature.length);
}, Te.canAddToArray = function (e, t, n) {
  const r = t.pubkey.toString("hex") + t.leafHash.toString("hex");
  return !n.has(r) && (n.add(r), 0 === e.filter(e => e.pubkey.equals(t.pubkey) && e.leafHash.equals(t.leafHash)).length);
};
var Ae = {},
  me = {},
  ve = {};
const {
  Buffer: Ne
} = _index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_0__.b;
Object.defineProperty(ve, "__esModule", {
  value: !0
});
function Oe(e) {
  if (e < 0 || e > 9007199254740991 || e % 1 != 0) throw new RangeError("value out of range");
}
function Pe(e) {
  return Oe(e), e < 253 ? 1 : e <= 65535 ? 3 : e <= 4294967295 ? 5 : 9;
}
ve.encode = function e(t, n, r) {
  if (Oe(t), n || (n = Ne.allocUnsafe(Pe(t))), !Ne.isBuffer(n)) throw new TypeError("buffer must be a Buffer instance");
  return r || (r = 0), t < 253 ? (n.writeUInt8(t, r), Object.assign(e, {
    bytes: 1
  })) : t <= 65535 ? (n.writeUInt8(253, r), n.writeUInt16LE(t, r + 1), Object.assign(e, {
    bytes: 3
  })) : t <= 4294967295 ? (n.writeUInt8(254, r), n.writeUInt32LE(t, r + 1), Object.assign(e, {
    bytes: 5
  })) : (n.writeUInt8(255, r), n.writeUInt32LE(t >>> 0, r + 1), n.writeUInt32LE(t / 4294967296 | 0, r + 5), Object.assign(e, {
    bytes: 9
  })), n;
}, ve.decode = function e(t, n) {
  if (!Ne.isBuffer(t)) throw new TypeError("buffer must be a Buffer instance");
  n || (n = 0);
  const r = t.readUInt8(n);
  if (r < 253) return Object.assign(e, {
    bytes: 1
  }), r;
  if (253 === r) return Object.assign(e, {
    bytes: 3
  }), t.readUInt16LE(n + 1);
  if (254 === r) return Object.assign(e, {
    bytes: 5
  }), t.readUInt32LE(n + 1);
  {
    Object.assign(e, {
      bytes: 9
    });
    const r = t.readUInt32LE(n + 1),
      i = 4294967296 * t.readUInt32LE(n + 5) + r;
    return Oe(i), i;
  }
}, ve.encodingLength = Pe;
const {
  Buffer: Ue
} = _index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_0__.b;
Object.defineProperty(me, "__esModule", {
  value: !0
});
const Ce = ve;
function xe(e) {
  const t = e.key.length,
    n = e.value.length,
    r = Ce.encodingLength(t),
    i = Ce.encodingLength(n),
    s = Ue.allocUnsafe(r + t + i + n);
  return Ce.encode(t, s, 0), e.key.copy(s, r), Ce.encode(n, s, r + t), e.value.copy(s, r + t + i), s;
}
function He(e, t) {
  if ("number" != typeof e) throw new Error("cannot write a non-number as a number");
  if (e < 0) throw new Error("specified a negative value for writing an unsigned value");
  if (e > t) throw new Error("RangeError: value out of range");
  if (Math.floor(e) !== e) throw new Error("value has a fractional component");
}
me.range = e => [...Array(e).keys()], me.reverseBuffer = function (e) {
  if (e.length < 1) return e;
  let t = e.length - 1,
    n = 0;
  for (let r = 0; r < e.length / 2; r++) n = e[r], e[r] = e[t], e[t] = n, t--;
  return e;
}, me.keyValsToBuffer = function (e) {
  const t = e.map(xe);
  return t.push(Ue.from([0])), Ue.concat(t);
}, me.keyValToBuffer = xe, me.readUInt64LE = function (e, t) {
  const n = e.readUInt32LE(t);
  let r = e.readUInt32LE(t + 4);
  return r *= 4294967296, He(r + n, 9007199254740991), r + n;
}, me.writeUInt64LE = function (e, t, n) {
  return He(t, 9007199254740991), e.writeInt32LE(-1 & t, n), e.writeUInt32LE(Math.floor(t / 4294967296), n + 4), n + 8;
};
const {
  Buffer: Be
} = _index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_0__.b;
Object.defineProperty(Ae, "__esModule", {
  value: !0
});
const Le = D,
  Re = me,
  Ve = ve;
Ae.decode = function (e) {
  if (e.key[0] !== Le.InputTypes.WITNESS_UTXO) throw new Error("Decode Error: could not decode witnessUtxo with key 0x" + e.key.toString("hex"));
  const t = Re.readUInt64LE(e.value, 0);
  let n = 8;
  const r = Ve.decode(e.value, n);
  n += Ve.encodingLength(r);
  const i = e.value.slice(n);
  if (i.length !== r) throw new Error("Decode Error: WITNESS_UTXO script is not proper length");
  return {
    script: i,
    value: t
  };
}, Ae.encode = function (e) {
  const {
      script: t,
      value: n
    } = e,
    r = Ve.encodingLength(t.length),
    i = Be.allocUnsafe(8 + r + t.length);
  return Re.writeUInt64LE(i, n, 0), Ve.encode(t.length, i, 8), t.copy(i, 8 + r), {
    key: Be.from([Le.InputTypes.WITNESS_UTXO]),
    value: i
  };
}, Ae.expected = "{ script: Buffer; value: number; }", Ae.check = function (e) {
  return Be.isBuffer(e.script) && "number" == typeof e.value;
}, Ae.canAdd = function (e, t) {
  return !!e && !!t && void 0 === e.witnessUtxo;
};
var Ke = {};
const {
  Buffer: De
} = _index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_0__.b;
Object.defineProperty(Ke, "__esModule", {
  value: !0
});
const Ge = D,
  Fe = ve;
Ke.decode = function (e) {
  if (e.key[0] !== Ge.OutputTypes.TAP_TREE || 1 !== e.key.length) throw new Error("Decode Error: could not decode tapTree with key 0x" + e.key.toString("hex"));
  let t = 0;
  const n = [];
  for (; t < e.value.length;) {
    const r = e.value[t++],
      i = e.value[t++],
      s = Fe.decode(e.value, t);
    t += Fe.encodingLength(s), n.push({
      depth: r,
      leafVersion: i,
      script: e.value.slice(t, t + s)
    }), t += s;
  }
  return {
    leaves: n
  };
}, Ke.encode = function (e) {
  const t = De.from([Ge.OutputTypes.TAP_TREE]),
    n = [].concat(...e.leaves.map(e => [De.of(e.depth, e.leafVersion), Fe.encode(e.script.length), e.script]));
  return {
    key: t,
    value: De.concat(n)
  };
}, Ke.expected = "{ leaves: [{ depth: number; leafVersion: number, script: Buffer; }] }", Ke.check = function (e) {
  return Array.isArray(e.leaves) && e.leaves.every(e => e.depth >= 0 && e.depth <= 128 && (254 & e.leafVersion) === e.leafVersion && De.isBuffer(e.script));
}, Ke.canAdd = function (e, t) {
  return !!e && !!t && void 0 === e.tapTree;
};
var Me = {};
const {
  Buffer: We
} = _index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_0__.b;
Object.defineProperty(Me, "__esModule", {
  value: !0
});
const Xe = e => 33 === e.length && [2, 3].includes(e[0]) || 65 === e.length && 4 === e[0];
Me.makeConverter = function (e, t = Xe) {
  return {
    decode: function (n) {
      if (n.key[0] !== e) throw new Error("Decode Error: could not decode bip32Derivation with key 0x" + n.key.toString("hex"));
      const r = n.key.slice(1);
      if (!t(r)) throw new Error("Decode Error: bip32Derivation has invalid pubkey in key 0x" + n.key.toString("hex"));
      if (n.value.length / 4 % 1 != 0) throw new Error("Decode Error: Input BIP32_DERIVATION value length should be multiple of 4");
      const i = {
        masterFingerprint: n.value.slice(0, 4),
        pubkey: r,
        path: "m"
      };
      for (const e of (s = n.value.length / 4 - 1, [...Array(s).keys()])) {
        const t = n.value.readUInt32LE(4 * e + 4),
          r = !!(2147483648 & t),
          s = 2147483647 & t;
        i.path += "/" + s.toString(10) + (r ? "'" : "");
      }
      var s;
      return i;
    },
    encode: function (t) {
      const n = We.from([e]),
        r = We.concat([n, t.pubkey]),
        i = t.path.split("/"),
        s = We.allocUnsafe(4 * i.length);
      t.masterFingerprint.copy(s, 0);
      let o = 4;
      return i.slice(1).forEach(e => {
        const t = "'" === e.slice(-1);
        let n = 2147483647 & parseInt(t ? e.slice(0, -1) : e, 10);
        t && (n += 2147483648), s.writeUInt32LE(n, o), o += 4;
      }), {
        key: r,
        value: s
      };
    },
    check: function (e) {
      return We.isBuffer(e.pubkey) && We.isBuffer(e.masterFingerprint) && "string" == typeof e.path && t(e.pubkey) && 4 === e.masterFingerprint.length;
    },
    expected: "{ masterFingerprint: Buffer; pubkey: Buffer; path: string; }",
    canAddToArray: function (e, t, n) {
      const r = t.pubkey.toString("hex");
      return !n.has(r) && (n.add(r), 0 === e.filter(e => e.pubkey.equals(t.pubkey)).length);
    }
  };
};
var je = {};
Object.defineProperty(je, "__esModule", {
  value: !0
}), je.makeChecker = function (e) {
  return function (t) {
    let n;
    if (e.includes(t.key[0]) && (n = t.key.slice(1), 33 !== n.length && 65 !== n.length || ![2, 3, 4].includes(n[0]))) throw new Error("Format Error: invalid pubkey in key 0x" + t.key.toString("hex"));
    return n;
  };
};
var qe = {};
const {
  Buffer: Ye
} = _index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_0__.b;
Object.defineProperty(qe, "__esModule", {
  value: !0
}), qe.makeConverter = function (e) {
  return {
    decode: function (t) {
      if (t.key[0] !== e) throw new Error("Decode Error: could not decode redeemScript with key 0x" + t.key.toString("hex"));
      return t.value;
    },
    encode: function (t) {
      return {
        key: Ye.from([e]),
        value: t
      };
    },
    check: function (e) {
      return Ye.isBuffer(e);
    },
    expected: "Buffer",
    canAdd: function (e, t) {
      return !!e && !!t && void 0 === e.redeemScript;
    }
  };
};
var $e = {};
const {
  Buffer: ze
} = _index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_0__.b;
Object.defineProperty($e, "__esModule", {
  value: !0
});
const Je = ve,
  Qe = Me,
  Ze = e => 32 === e.length;
$e.makeConverter = function (e) {
  const t = Qe.makeConverter(e, Ze);
  return {
    decode: function (e) {
      const n = Je.decode(e.value),
        r = Je.encodingLength(n),
        i = t.decode({
          key: e.key,
          value: e.value.slice(r + 32 * n)
        }),
        s = new Array(n);
      for (let t = 0, i = r; t < n; t++, i += 32) s[t] = e.value.slice(i, i + 32);
      return Object.assign({}, i, {
        leafHashes: s
      });
    },
    encode: function (e) {
      const n = t.encode(e),
        r = Je.encodingLength(e.leafHashes.length),
        i = ze.allocUnsafe(r);
      Je.encode(e.leafHashes.length, i);
      const s = ze.concat([i, ...e.leafHashes, n.value]);
      return Object.assign({}, n, {
        value: s
      });
    },
    check: function (e) {
      return Array.isArray(e.leafHashes) && e.leafHashes.every(e => ze.isBuffer(e) && 32 === e.length) && t.check(e);
    },
    expected: "{ masterFingerprint: Buffer; pubkey: Buffer; path: string; leafHashes: Buffer[]; }",
    canAddToArray: t.canAddToArray
  };
};
var et = {};
const {
  Buffer: tt
} = _index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_0__.b;
Object.defineProperty(et, "__esModule", {
  value: !0
}), et.makeConverter = function (e) {
  return {
    decode: function (t) {
      if (t.key[0] !== e || 1 !== t.key.length) throw new Error("Decode Error: could not decode tapInternalKey with key 0x" + t.key.toString("hex"));
      if (32 !== t.value.length) throw new Error("Decode Error: tapInternalKey not a 32-byte x-only pubkey");
      return t.value;
    },
    encode: function (t) {
      return {
        key: tt.from([e]),
        value: t
      };
    },
    check: function (e) {
      return tt.isBuffer(e) && 32 === e.length;
    },
    expected: "Buffer",
    canAdd: function (e, t) {
      return !!e && !!t && void 0 === e.tapInternalKey;
    }
  };
};
var nt = {};
const {
  Buffer: rt
} = _index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_0__.b;
Object.defineProperty(nt, "__esModule", {
  value: !0
}), nt.makeConverter = function (e) {
  return {
    decode: function (t) {
      if (t.key[0] !== e) throw new Error("Decode Error: could not decode witnessScript with key 0x" + t.key.toString("hex"));
      return t.value;
    },
    encode: function (t) {
      return {
        key: rt.from([e]),
        value: t
      };
    },
    check: function (e) {
      return rt.isBuffer(e);
    },
    expected: "Buffer",
    canAdd: function (e, t) {
      return !!e && !!t && void 0 === e.witnessScript;
    }
  };
}, Object.defineProperty(K, "__esModule", {
  value: !0
});
const it = D,
  st = q,
  ot = z,
  ut = Z,
  at = ne,
  ct = se,
  pt = ae,
  ft = fe,
  ht = ye,
  lt = _e,
  dt = Te,
  yt = Ae,
  Et = Ke,
  St = Me,
  _t = je,
  wt = qe,
  It = $e,
  gt = et,
  Tt = nt,
  kt = {
    unsignedTx: W,
    globalXpub: G,
    checkPubkey: _t.makeChecker([])
  };
K.globals = kt;
const bt = {
  nonWitnessUtxo: ut,
  partialSig: at,
  sighashType: pt,
  finalScriptSig: st,
  finalScriptWitness: ot,
  porCommitment: ct,
  witnessUtxo: yt,
  bip32Derivation: St.makeConverter(it.InputTypes.BIP32_DERIVATION),
  redeemScript: wt.makeConverter(it.InputTypes.REDEEM_SCRIPT),
  witnessScript: Tt.makeConverter(it.InputTypes.WITNESS_SCRIPT),
  checkPubkey: _t.makeChecker([it.InputTypes.PARTIAL_SIG, it.InputTypes.BIP32_DERIVATION]),
  tapKeySig: ft,
  tapScriptSig: dt,
  tapLeafScript: ht,
  tapBip32Derivation: It.makeConverter(it.InputTypes.TAP_BIP32_DERIVATION),
  tapInternalKey: gt.makeConverter(it.InputTypes.TAP_INTERNAL_KEY),
  tapMerkleRoot: lt
};
K.inputs = bt;
const At = {
  bip32Derivation: St.makeConverter(it.OutputTypes.BIP32_DERIVATION),
  redeemScript: wt.makeConverter(it.OutputTypes.REDEEM_SCRIPT),
  witnessScript: Tt.makeConverter(it.OutputTypes.WITNESS_SCRIPT),
  checkPubkey: _t.makeChecker([it.OutputTypes.BIP32_DERIVATION]),
  tapBip32Derivation: It.makeConverter(it.OutputTypes.TAP_BIP32_DERIVATION),
  tapTree: Et,
  tapInternalKey: gt.makeConverter(it.OutputTypes.TAP_INTERNAL_KEY)
};
K.outputs = At;
const {
  Buffer: mt
} = _index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_0__.b;
Object.defineProperty(V, "__esModule", {
  value: !0
});
const vt = K,
  Nt = me,
  Ot = ve,
  Pt = D;
function Ut(e, t, n) {
  if (!t.equals(mt.from([n]))) throw new Error(`Format Error: Invalid ${e} key: ${t.toString("hex")}`);
}
function Ct(e, {
  globalMapKeyVals: t,
  inputKeyVals: n,
  outputKeyVals: r
}) {
  const i = {
    unsignedTx: e
  };
  let s = 0;
  for (const e of t) switch (e.key[0]) {
    case Pt.GlobalTypes.UNSIGNED_TX:
      if (Ut("global", e.key, Pt.GlobalTypes.UNSIGNED_TX), s > 0) throw new Error("Format Error: GlobalMap has multiple UNSIGNED_TX");
      s++;
      break;
    case Pt.GlobalTypes.GLOBAL_XPUB:
      void 0 === i.globalXpub && (i.globalXpub = []), i.globalXpub.push(vt.globals.globalXpub.decode(e));
      break;
    default:
      i.unknownKeyVals || (i.unknownKeyVals = []), i.unknownKeyVals.push(e);
  }
  const o = n.length,
    u = r.length,
    a = [],
    c = [];
  for (const e of Nt.range(o)) {
    const t = {};
    for (const r of n[e]) switch (vt.inputs.checkPubkey(r), r.key[0]) {
      case Pt.InputTypes.NON_WITNESS_UTXO:
        if (Ut("input", r.key, Pt.InputTypes.NON_WITNESS_UTXO), void 0 !== t.nonWitnessUtxo) throw new Error("Format Error: Input has multiple NON_WITNESS_UTXO");
        t.nonWitnessUtxo = vt.inputs.nonWitnessUtxo.decode(r);
        break;
      case Pt.InputTypes.WITNESS_UTXO:
        if (Ut("input", r.key, Pt.InputTypes.WITNESS_UTXO), void 0 !== t.witnessUtxo) throw new Error("Format Error: Input has multiple WITNESS_UTXO");
        t.witnessUtxo = vt.inputs.witnessUtxo.decode(r);
        break;
      case Pt.InputTypes.PARTIAL_SIG:
        void 0 === t.partialSig && (t.partialSig = []), t.partialSig.push(vt.inputs.partialSig.decode(r));
        break;
      case Pt.InputTypes.SIGHASH_TYPE:
        if (Ut("input", r.key, Pt.InputTypes.SIGHASH_TYPE), void 0 !== t.sighashType) throw new Error("Format Error: Input has multiple SIGHASH_TYPE");
        t.sighashType = vt.inputs.sighashType.decode(r);
        break;
      case Pt.InputTypes.REDEEM_SCRIPT:
        if (Ut("input", r.key, Pt.InputTypes.REDEEM_SCRIPT), void 0 !== t.redeemScript) throw new Error("Format Error: Input has multiple REDEEM_SCRIPT");
        t.redeemScript = vt.inputs.redeemScript.decode(r);
        break;
      case Pt.InputTypes.WITNESS_SCRIPT:
        if (Ut("input", r.key, Pt.InputTypes.WITNESS_SCRIPT), void 0 !== t.witnessScript) throw new Error("Format Error: Input has multiple WITNESS_SCRIPT");
        t.witnessScript = vt.inputs.witnessScript.decode(r);
        break;
      case Pt.InputTypes.BIP32_DERIVATION:
        void 0 === t.bip32Derivation && (t.bip32Derivation = []), t.bip32Derivation.push(vt.inputs.bip32Derivation.decode(r));
        break;
      case Pt.InputTypes.FINAL_SCRIPTSIG:
        Ut("input", r.key, Pt.InputTypes.FINAL_SCRIPTSIG), t.finalScriptSig = vt.inputs.finalScriptSig.decode(r);
        break;
      case Pt.InputTypes.FINAL_SCRIPTWITNESS:
        Ut("input", r.key, Pt.InputTypes.FINAL_SCRIPTWITNESS), t.finalScriptWitness = vt.inputs.finalScriptWitness.decode(r);
        break;
      case Pt.InputTypes.POR_COMMITMENT:
        Ut("input", r.key, Pt.InputTypes.POR_COMMITMENT), t.porCommitment = vt.inputs.porCommitment.decode(r);
        break;
      case Pt.InputTypes.TAP_KEY_SIG:
        Ut("input", r.key, Pt.InputTypes.TAP_KEY_SIG), t.tapKeySig = vt.inputs.tapKeySig.decode(r);
        break;
      case Pt.InputTypes.TAP_SCRIPT_SIG:
        void 0 === t.tapScriptSig && (t.tapScriptSig = []), t.tapScriptSig.push(vt.inputs.tapScriptSig.decode(r));
        break;
      case Pt.InputTypes.TAP_LEAF_SCRIPT:
        void 0 === t.tapLeafScript && (t.tapLeafScript = []), t.tapLeafScript.push(vt.inputs.tapLeafScript.decode(r));
        break;
      case Pt.InputTypes.TAP_BIP32_DERIVATION:
        void 0 === t.tapBip32Derivation && (t.tapBip32Derivation = []), t.tapBip32Derivation.push(vt.inputs.tapBip32Derivation.decode(r));
        break;
      case Pt.InputTypes.TAP_INTERNAL_KEY:
        Ut("input", r.key, Pt.InputTypes.TAP_INTERNAL_KEY), t.tapInternalKey = vt.inputs.tapInternalKey.decode(r);
        break;
      case Pt.InputTypes.TAP_MERKLE_ROOT:
        Ut("input", r.key, Pt.InputTypes.TAP_MERKLE_ROOT), t.tapMerkleRoot = vt.inputs.tapMerkleRoot.decode(r);
        break;
      default:
        t.unknownKeyVals || (t.unknownKeyVals = []), t.unknownKeyVals.push(r);
    }
    a.push(t);
  }
  for (const e of Nt.range(u)) {
    const t = {};
    for (const n of r[e]) switch (vt.outputs.checkPubkey(n), n.key[0]) {
      case Pt.OutputTypes.REDEEM_SCRIPT:
        if (Ut("output", n.key, Pt.OutputTypes.REDEEM_SCRIPT), void 0 !== t.redeemScript) throw new Error("Format Error: Output has multiple REDEEM_SCRIPT");
        t.redeemScript = vt.outputs.redeemScript.decode(n);
        break;
      case Pt.OutputTypes.WITNESS_SCRIPT:
        if (Ut("output", n.key, Pt.OutputTypes.WITNESS_SCRIPT), void 0 !== t.witnessScript) throw new Error("Format Error: Output has multiple WITNESS_SCRIPT");
        t.witnessScript = vt.outputs.witnessScript.decode(n);
        break;
      case Pt.OutputTypes.BIP32_DERIVATION:
        void 0 === t.bip32Derivation && (t.bip32Derivation = []), t.bip32Derivation.push(vt.outputs.bip32Derivation.decode(n));
        break;
      case Pt.OutputTypes.TAP_INTERNAL_KEY:
        Ut("output", n.key, Pt.OutputTypes.TAP_INTERNAL_KEY), t.tapInternalKey = vt.outputs.tapInternalKey.decode(n);
        break;
      case Pt.OutputTypes.TAP_TREE:
        Ut("output", n.key, Pt.OutputTypes.TAP_TREE), t.tapTree = vt.outputs.tapTree.decode(n);
        break;
      case Pt.OutputTypes.TAP_BIP32_DERIVATION:
        void 0 === t.tapBip32Derivation && (t.tapBip32Derivation = []), t.tapBip32Derivation.push(vt.outputs.tapBip32Derivation.decode(n));
        break;
      default:
        t.unknownKeyVals || (t.unknownKeyVals = []), t.unknownKeyVals.push(n);
    }
    c.push(t);
  }
  return {
    globalMap: i,
    inputs: a,
    outputs: c
  };
}
V.psbtFromBuffer = function (e, t) {
  let n = 0;
  function r() {
    const t = Ot.decode(e, n);
    n += Ot.encodingLength(t);
    const r = e.slice(n, n + t);
    return n += t, r;
  }
  function i() {
    return {
      key: r(),
      value: r()
    };
  }
  function s() {
    if (n >= e.length) throw new Error("Format Error: Unexpected End of PSBT");
    const t = 0 === e.readUInt8(n);
    return t && n++, t;
  }
  if (1886610036 !== function () {
    const t = e.readUInt32BE(n);
    return n += 4, t;
  }()) throw new Error("Format Error: Invalid Magic Number");
  if (255 !== function () {
    const t = e.readUInt8(n);
    return n += 1, t;
  }()) throw new Error("Format Error: Magic Number must be followed by 0xff separator");
  const o = [],
    u = {};
  for (; !s();) {
    const e = i(),
      t = e.key.toString("hex");
    if (u[t]) throw new Error("Format Error: Keys must be unique for global keymap: key " + t);
    u[t] = 1, o.push(e);
  }
  const a = o.filter(e => e.key[0] === Pt.GlobalTypes.UNSIGNED_TX);
  if (1 !== a.length) throw new Error("Format Error: Only one UNSIGNED_TX allowed");
  const c = t(a[0].value),
    {
      inputCount: p,
      outputCount: f
    } = c.getInputOutputCounts(),
    h = [],
    l = [];
  for (const e of Nt.range(p)) {
    const t = {},
      n = [];
    for (; !s();) {
      const r = i(),
        s = r.key.toString("hex");
      if (t[s]) throw new Error("Format Error: Keys must be unique for each input: input index " + e + " key " + s);
      t[s] = 1, n.push(r);
    }
    h.push(n);
  }
  for (const e of Nt.range(f)) {
    const t = {},
      n = [];
    for (; !s();) {
      const r = i(),
        s = r.key.toString("hex");
      if (t[s]) throw new Error("Format Error: Keys must be unique for each output: output index " + e + " key " + s);
      t[s] = 1, n.push(r);
    }
    l.push(n);
  }
  return Ct(c, {
    globalMapKeyVals: o,
    inputKeyVals: h,
    outputKeyVals: l
  });
}, V.checkKeyBuffer = Ut, V.psbtFromKeyVals = Ct;
var xt = {};
const {
  Buffer: Ht
} = _index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_0__.b;
Object.defineProperty(xt, "__esModule", {
  value: !0
});
const Bt = K,
  Lt = me;
xt.psbtToBuffer = function ({
  globalMap: e,
  inputs: t,
  outputs: n
}) {
  const {
      globalKeyVals: r,
      inputKeyVals: i,
      outputKeyVals: s
    } = Kt({
      globalMap: e,
      inputs: t,
      outputs: n
    }),
    o = Lt.keyValsToBuffer(r),
    u = e => 0 === e.length ? [Ht.from([0])] : e.map(Lt.keyValsToBuffer),
    a = u(i),
    c = u(s),
    p = Ht.allocUnsafe(5);
  return p.writeUIntBE(482972169471, 0, 5), Ht.concat([p, o].concat(a, c));
};
const Rt = (e, t) => e.key.compare(t.key);
function Vt(e, t) {
  const n = new Set(),
    r = Object.entries(e).reduce((e, [r, i]) => {
      if ("unknownKeyVals" === r) return e;
      const s = t[r];
      if (void 0 === s) return e;
      const o = (Array.isArray(i) ? i : [i]).map(s.encode);
      return o.map(e => e.key.toString("hex")).forEach(e => {
        if (n.has(e)) throw new Error("Serialize Error: Duplicate key: " + e);
        n.add(e);
      }), e.concat(o);
    }, []),
    i = e.unknownKeyVals ? e.unknownKeyVals.filter(e => !n.has(e.key.toString("hex"))) : [];
  return r.concat(i).sort(Rt);
}
function Kt({
  globalMap: e,
  inputs: t,
  outputs: n
}) {
  return {
    globalKeyVals: Vt(e, Bt.globals),
    inputKeyVals: t.map(e => Vt(e, Bt.inputs)),
    outputKeyVals: n.map(e => Vt(e, Bt.outputs))
  };
}
xt.psbtToKeyVals = Kt, function (e) {
  function t(t) {
    for (var n in t) e.hasOwnProperty(n) || (e[n] = t[n]);
  }
  Object.defineProperty(e, "__esModule", {
    value: !0
  }), t(V), t(xt);
}(R), Object.defineProperty(L, "__esModule", {
  value: !0
});
const Dt = R;
function Gt(e, t, n) {
  return r => {
    if (e.has(r)) return;
    const i = n.filter(e => e.key.toString("hex") === r)[0];
    t.push(i), e.add(r);
  };
}
function Ft(e) {
  return e.globalMap.unsignedTx;
}
function Mt(e) {
  const t = new Set();
  return e.forEach(e => {
    const n = e.key.toString("hex");
    if (t.has(n)) throw new Error("Combine: KeyValue Map keys should be unique");
    t.add(n);
  }), t;
}
L.combine = function (e) {
  const t = e[0],
    n = Dt.psbtToKeyVals(t),
    r = e.slice(1);
  if (0 === r.length) throw new Error("Combine: Nothing to combine");
  const i = Ft(t);
  if (void 0 === i) throw new Error("Combine: Self missing transaction");
  const s = Mt(n.globalKeyVals),
    o = n.inputKeyVals.map(Mt),
    u = n.outputKeyVals.map(Mt);
  for (const e of r) {
    const t = Ft(e);
    if (void 0 === t || !t.toBuffer().equals(i.toBuffer())) throw new Error("Combine: One of the Psbts does not have the same transaction.");
    const r = Dt.psbtToKeyVals(e);
    Mt(r.globalKeyVals).forEach(Gt(s, n.globalKeyVals, r.globalKeyVals));
    r.inputKeyVals.map(Mt).forEach((e, t) => e.forEach(Gt(o[t], n.inputKeyVals[t], r.inputKeyVals[t])));
    r.outputKeyVals.map(Mt).forEach((e, t) => e.forEach(Gt(u[t], n.outputKeyVals[t], r.outputKeyVals[t])));
  }
  return Dt.psbtFromKeyVals(i, {
    globalMapKeyVals: n.globalKeyVals,
    inputKeyVals: n.inputKeyVals,
    outputKeyVals: n.outputKeyVals
  });
};
var Wt = {};
!function (t) {
  const {
    Buffer: n
  } = _index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_0__.b;
  Object.defineProperty(t, "__esModule", {
    value: !0
  });
  const r = K;
  function i(e, t) {
    const n = e[t];
    if (void 0 === n) throw new Error(`No input #${t}`);
    return n;
  }
  function s(e, t) {
    const n = e[t];
    if (void 0 === n) throw new Error(`No output #${t}`);
    return n;
  }
  function o(e, t, n, r) {
    throw new Error(`Data for ${e} key ${t} is incorrect: Expected ${n} and got ${JSON.stringify(r)}`);
  }
  function u(e) {
    return (t, n) => {
      for (const i of Object.keys(t)) {
        const s = t[i],
          {
            canAdd: u,
            canAddToArray: a,
            check: c,
            expected: p
          } = r[e + "s"][i] || {},
          f = !!a;
        if (c) if (f) {
          if (!Array.isArray(s) || n[i] && !Array.isArray(n[i])) throw new Error(`Key type ${i} must be an array`);
          s.every(c) || o(e, i, p, s);
          const t = n[i] || [],
            r = new Set();
          if (!s.every(e => a(t, e, r))) throw new Error("Can not add duplicate data to array");
          n[i] = t.concat(s);
        } else {
          if (c(s) || o(e, i, p, s), !u(n, s)) throw new Error(`Can not add duplicate data to ${e}`);
          n[i] = s;
        }
      }
    };
  }
  t.checkForInput = i, t.checkForOutput = s, t.checkHasKey = function (e, t, n) {
    if (e.key[0] < n) throw new Error("Use the method for your specific key instead of addUnknownKeyVal*");
    if (t && 0 !== t.filter(t => t.key.equals(e.key)).length) throw new Error(`Duplicate Key: ${e.key.toString("hex")}`);
  }, t.getEnumLength = function (e) {
    let t = 0;
    return Object.keys(e).forEach(e => {
      Number(isNaN(Number(e))) && t++;
    }), t;
  }, t.inputCheckUncleanFinalized = function (e, t) {
    let n = !1;
    if (t.nonWitnessUtxo || t.witnessUtxo) {
      const e = !!t.redeemScript,
        r = !!t.witnessScript,
        i = !e || !!t.finalScriptSig,
        s = !r || !!t.finalScriptWitness,
        o = !!t.finalScriptSig || !!t.finalScriptWitness;
      n = i && s && o;
    }
    if (!1 === n) throw new Error(`Input #${e} has too much or too little data to clean`);
  }, t.updateGlobal = u("global"), t.updateInput = u("input"), t.updateOutput = u("output"), t.addInputAttributes = function (e, n) {
    const r = i(e, e.length - 1);
    t.updateInput(n, r);
  }, t.addOutputAttributes = function (e, n) {
    const r = s(e, e.length - 1);
    t.updateOutput(n, r);
  }, t.defaultVersionSetter = function (e, t) {
    if (!n.isBuffer(t) || t.length < 4) throw new Error("Set Version: Invalid Transaction");
    return t.writeUInt32LE(e, 0), t;
  }, t.defaultLocktimeSetter = function (e, t) {
    if (!n.isBuffer(t) || t.length < 4) throw new Error("Set Locktime: Invalid Transaction");
    return t.writeUInt32LE(e, t.length - 4), t;
  };
}(Wt);
const {
  Buffer: Xt
} = _index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_0__.b;
Object.defineProperty(B, "__esModule", {
  value: !0
});
const jt = L,
  qt = R,
  Yt = D,
  $t = Wt;
B.Psbt = class {
  constructor(e) {
    this.inputs = [], this.outputs = [], this.globalMap = {
      unsignedTx: e
    };
  }
  static fromBase64(e, t) {
    const n = Xt.from(e, "base64");
    return this.fromBuffer(n, t);
  }
  static fromHex(e, t) {
    const n = Xt.from(e, "hex");
    return this.fromBuffer(n, t);
  }
  static fromBuffer(e, t) {
    const n = qt.psbtFromBuffer(e, t),
      r = new this(n.globalMap.unsignedTx);
    return Object.assign(r, n), r;
  }
  toBase64() {
    return this.toBuffer().toString("base64");
  }
  toHex() {
    return this.toBuffer().toString("hex");
  }
  toBuffer() {
    return qt.psbtToBuffer(this);
  }
  updateGlobal(e) {
    return $t.updateGlobal(e, this.globalMap), this;
  }
  updateInput(e, t) {
    const n = $t.checkForInput(this.inputs, e);
    return $t.updateInput(t, n), this;
  }
  updateOutput(e, t) {
    const n = $t.checkForOutput(this.outputs, e);
    return $t.updateOutput(t, n), this;
  }
  addUnknownKeyValToGlobal(e) {
    return $t.checkHasKey(e, this.globalMap.unknownKeyVals, $t.getEnumLength(Yt.GlobalTypes)), this.globalMap.unknownKeyVals || (this.globalMap.unknownKeyVals = []), this.globalMap.unknownKeyVals.push(e), this;
  }
  addUnknownKeyValToInput(e, t) {
    const n = $t.checkForInput(this.inputs, e);
    return $t.checkHasKey(t, n.unknownKeyVals, $t.getEnumLength(Yt.InputTypes)), n.unknownKeyVals || (n.unknownKeyVals = []), n.unknownKeyVals.push(t), this;
  }
  addUnknownKeyValToOutput(e, t) {
    const n = $t.checkForOutput(this.outputs, e);
    return $t.checkHasKey(t, n.unknownKeyVals, $t.getEnumLength(Yt.OutputTypes)), n.unknownKeyVals || (n.unknownKeyVals = []), n.unknownKeyVals.push(t), this;
  }
  addInput(e) {
    this.globalMap.unsignedTx.addInput(e), this.inputs.push({
      unknownKeyVals: []
    });
    const t = e.unknownKeyVals || [],
      n = this.inputs.length - 1;
    if (!Array.isArray(t)) throw new Error("unknownKeyVals must be an Array");
    return t.forEach(e => this.addUnknownKeyValToInput(n, e)), $t.addInputAttributes(this.inputs, e), this;
  }
  addOutput(e) {
    this.globalMap.unsignedTx.addOutput(e), this.outputs.push({
      unknownKeyVals: []
    });
    const t = e.unknownKeyVals || [],
      n = this.outputs.length - 1;
    if (!Array.isArray(t)) throw new Error("unknownKeyVals must be an Array");
    return t.forEach(e => this.addUnknownKeyValToInput(n, e)), $t.addOutputAttributes(this.outputs, e), this;
  }
  clearFinalizedInput(e) {
    const t = $t.checkForInput(this.inputs, e);
    $t.inputCheckUncleanFinalized(e, t);
    for (const e of Object.keys(t)) ["witnessUtxo", "nonWitnessUtxo", "finalScriptSig", "finalScriptWitness", "unknownKeyVals"].includes(e) || delete t[e];
    return this;
  }
  combine(...e) {
    const t = jt.combine([this].concat(e));
    return Object.assign(this, t), this;
  }
  getTransaction() {
    return this.globalMap.unsignedTx.toBuffer();
  }
}, H.exports = B;
const zt = ve;
var Jt = _index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_0__.b.Buffer;
function Qt(e) {
  if (e < 0 || e > 9007199254740991 || e % 1 != 0) throw new RangeError("value out of range");
}
function Zt(e) {
  return Qt(e), e < 253 ? 1 : e <= 65535 ? 3 : e <= 4294967295 ? 5 : 9;
}
var en = {
  encode: function e(t, n, r) {
    if (Qt(t), n || (n = Jt.allocUnsafe(Zt(t))), !Jt.isBuffer(n)) throw new TypeError("buffer must be a Buffer instance");
    return r || (r = 0), t < 253 ? (n.writeUInt8(t, r), e.bytes = 1) : t <= 65535 ? (n.writeUInt8(253, r), n.writeUInt16LE(t, r + 1), e.bytes = 3) : t <= 4294967295 ? (n.writeUInt8(254, r), n.writeUInt32LE(t, r + 1), e.bytes = 5) : (n.writeUInt8(255, r), n.writeUInt32LE(t >>> 0, r + 1), n.writeUInt32LE(t / 4294967296 | 0, r + 5), e.bytes = 9), n;
  },
  decode: function e(t, n) {
    if (!Jt.isBuffer(t)) throw new TypeError("buffer must be a Buffer instance");
    n || (n = 0);
    var r = t.readUInt8(n);
    if (r < 253) return e.bytes = 1, r;
    if (253 === r) return e.bytes = 3, t.readUInt16LE(n + 1);
    if (254 === r) return e.bytes = 5, t.readUInt32LE(n + 1);
    e.bytes = 9;
    var i = t.readUInt32LE(n + 1),
      s = 4294967296 * t.readUInt32LE(n + 5) + i;
    return Qt(s), s;
  },
  encodingLength: Zt
};
const {
  typeforce: tn
} = _script_c688360e_mjs__WEBPACK_IMPORTED_MODULE_2__.b;
function nn(e, t) {
  if ("number" != typeof e) throw new Error("cannot write a non-number as a number");
  if (e < 0) throw new Error("specified a negative value for writing an unsigned value");
  if (e > t) throw new Error("RangeError: value out of range");
  if (Math.floor(e) !== e) throw new Error("value has a fractional component");
}
function rn(e) {
  if (e.length < 1) return e;
  let t = e.length - 1,
    n = 0;
  for (let r = 0; r < e.length / 2; r++) n = e[r], e[r] = e[t], e[t] = n, t--;
  return e;
}
function sn(e) {
  const n = _index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_0__.B.allocUnsafe(e.length);
  return e.copy(n), n;
}
class on {
  constructor(e, t = 0) {
    this.buffer = e, this.offset = t, tn((0,_script_c688360e_mjs__WEBPACK_IMPORTED_MODULE_2__.t)(_script_c688360e_mjs__WEBPACK_IMPORTED_MODULE_2__.B, _script_c688360e_mjs__WEBPACK_IMPORTED_MODULE_2__.h), [e, t]);
  }
  static withCapacity(e) {
    return new on(_index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_0__.B.alloc(e));
  }
  writeUInt8(e) {
    this.offset = this.buffer.writeUInt8(e, this.offset);
  }
  writeInt32(e) {
    this.offset = this.buffer.writeInt32LE(e, this.offset);
  }
  writeUInt32(e) {
    this.offset = this.buffer.writeUInt32LE(e, this.offset);
  }
  writeUInt64(e) {
    this.offset = function (e, t, n) {
      return nn(t, 9007199254740991), e.writeInt32LE(-1 & t, n), e.writeUInt32LE(Math.floor(t / 4294967296), n + 4), n + 8;
    }(this.buffer, e, this.offset);
  }
  writeVarInt(e) {
    en.encode(e, this.buffer, this.offset), this.offset += en.encode.bytes;
  }
  writeSlice(e) {
    if (this.buffer.length < this.offset + e.length) throw new Error("Cannot write slice out of bounds");
    this.offset += e.copy(this.buffer, this.offset);
  }
  writeVarSlice(e) {
    this.writeVarInt(e.length), this.writeSlice(e);
  }
  writeVector(e) {
    this.writeVarInt(e.length), e.forEach(e => this.writeVarSlice(e));
  }
  end() {
    if (this.buffer.length === this.offset) return this.buffer;
    throw new Error(`buffer size ${this.buffer.length}, offset ${this.offset}`);
  }
}
class un {
  constructor(e, t = 0) {
    this.buffer = e, this.offset = t, tn((0,_script_c688360e_mjs__WEBPACK_IMPORTED_MODULE_2__.t)(_script_c688360e_mjs__WEBPACK_IMPORTED_MODULE_2__.B, _script_c688360e_mjs__WEBPACK_IMPORTED_MODULE_2__.h), [e, t]);
  }
  readUInt8() {
    const e = this.buffer.readUInt8(this.offset);
    return this.offset++, e;
  }
  readInt32() {
    const e = this.buffer.readInt32LE(this.offset);
    return this.offset += 4, e;
  }
  readUInt32() {
    const e = this.buffer.readUInt32LE(this.offset);
    return this.offset += 4, e;
  }
  readUInt64() {
    const e = function (e, t) {
      const n = e.readUInt32LE(t);
      let r = e.readUInt32LE(t + 4);
      return r *= 4294967296, nn(r + n, 9007199254740991), r + n;
    }(this.buffer, this.offset);
    return this.offset += 8, e;
  }
  readVarInt() {
    const e = en.decode(this.buffer, this.offset);
    return this.offset += en.decode.bytes, e;
  }
  readSlice(e) {
    if (this.buffer.length < this.offset + e) throw new Error("Cannot read slice out of bounds");
    const t = this.buffer.slice(this.offset, this.offset + e);
    return this.offset += e, t;
  }
  readVarSlice() {
    return this.readSlice(this.readVarInt());
  }
  readVector() {
    const e = this.readVarInt(),
      t = [];
    for (let n = 0; n < e; n++) t.push(this.readVarSlice());
    return t;
  }
}
const {
  typeforce: an
} = _script_c688360e_mjs__WEBPACK_IMPORTED_MODULE_2__.b;
function cn(e) {
  const t = e.length;
  return en.encodingLength(t) + t;
}
const pn = _index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_0__.B.allocUnsafe(0),
  fn = [],
  hn = _index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_0__.B.from("0000000000000000000000000000000000000000000000000000000000000000", "hex"),
  ln = _index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_0__.B.from("0000000000000000000000000000000000000000000000000000000000000001", "hex"),
  dn = _index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_0__.B.from("ffffffffffffffff", "hex"),
  yn = {
    script: pn,
    valueBuffer: dn
  };
class En {
  constructor() {
    this.version = 1, this.locktime = 0, this.ins = [], this.outs = [];
  }
  static fromBuffer(e, t) {
    const n = new un(e),
      r = new En();
    r.version = n.readInt32();
    const i = n.readUInt8(),
      s = n.readUInt8();
    let o = !1;
    i === En.ADVANCED_TRANSACTION_MARKER && s === En.ADVANCED_TRANSACTION_FLAG ? o = !0 : n.offset -= 2;
    const u = n.readVarInt();
    for (let e = 0; e < u; ++e) r.ins.push({
      hash: n.readSlice(32),
      index: n.readUInt32(),
      script: n.readVarSlice(),
      sequence: n.readUInt32(),
      witness: fn
    });
    const a = n.readVarInt();
    for (let e = 0; e < a; ++e) r.outs.push({
      value: n.readUInt64(),
      script: n.readVarSlice()
    });
    if (o) {
      for (let e = 0; e < u; ++e) r.ins[e].witness = n.readVector();
      if (!r.hasWitnesses()) throw new Error("Transaction has superfluous witness data");
    }
    if (r.locktime = n.readUInt32(), t) return r;
    if (n.offset !== e.length) throw new Error("Transaction has unexpected data");
    return r;
  }
  static fromHex(e) {
    return En.fromBuffer(_index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_0__.B.from(e, "hex"), !1);
  }
  static isCoinbaseHash(e) {
    an(_script_c688360e_mjs__WEBPACK_IMPORTED_MODULE_2__.j, e);
    for (let t = 0; t < 32; ++t) if (0 !== e[t]) return !1;
    return !0;
  }
  isCoinbase() {
    return 1 === this.ins.length && En.isCoinbaseHash(this.ins[0].hash);
  }
  addInput(e, t, n, r) {
    return an((0,_script_c688360e_mjs__WEBPACK_IMPORTED_MODULE_2__.t)(_script_c688360e_mjs__WEBPACK_IMPORTED_MODULE_2__.j, _script_c688360e_mjs__WEBPACK_IMPORTED_MODULE_2__.h, (0,_script_c688360e_mjs__WEBPACK_IMPORTED_MODULE_2__.m)(_script_c688360e_mjs__WEBPACK_IMPORTED_MODULE_2__.h), (0,_script_c688360e_mjs__WEBPACK_IMPORTED_MODULE_2__.m)(_script_c688360e_mjs__WEBPACK_IMPORTED_MODULE_2__.B)), arguments), (0,_script_c688360e_mjs__WEBPACK_IMPORTED_MODULE_2__.N)(n) && (n = En.DEFAULT_SEQUENCE), this.ins.push({
      hash: e,
      index: t,
      script: r || pn,
      sequence: n,
      witness: fn
    }) - 1;
  }
  addOutput(e, t) {
    return an((0,_script_c688360e_mjs__WEBPACK_IMPORTED_MODULE_2__.t)(_script_c688360e_mjs__WEBPACK_IMPORTED_MODULE_2__.B, _script_c688360e_mjs__WEBPACK_IMPORTED_MODULE_2__.S), arguments), this.outs.push({
      script: e,
      value: t
    }) - 1;
  }
  hasWitnesses() {
    return this.ins.some(e => 0 !== e.witness.length);
  }
  weight() {
    return 3 * this.byteLength(!1) + this.byteLength(!0);
  }
  virtualSize() {
    return Math.ceil(this.weight() / 4);
  }
  byteLength(e = !0) {
    const t = e && this.hasWitnesses();
    return (t ? 10 : 8) + en.encodingLength(this.ins.length) + en.encodingLength(this.outs.length) + this.ins.reduce((e, t) => e + 40 + cn(t.script), 0) + this.outs.reduce((e, t) => e + 8 + cn(t.script), 0) + (t ? this.ins.reduce((e, t) => e + function (e) {
      const t = e.length;
      return en.encodingLength(t) + e.reduce((e, t) => e + cn(t), 0);
    }(t.witness), 0) : 0);
  }
  clone() {
    const e = new En();
    return e.version = this.version, e.locktime = this.locktime, e.ins = this.ins.map(e => ({
      hash: e.hash,
      index: e.index,
      script: e.script,
      sequence: e.sequence,
      witness: e.witness
    })), e.outs = this.outs.map(e => ({
      script: e.script,
      value: e.value
    })), e;
  }
  hashForSignature(e, n, r) {
    if (an((0,_script_c688360e_mjs__WEBPACK_IMPORTED_MODULE_2__.t)(_script_c688360e_mjs__WEBPACK_IMPORTED_MODULE_2__.h, _script_c688360e_mjs__WEBPACK_IMPORTED_MODULE_2__.B, _script_c688360e_mjs__WEBPACK_IMPORTED_MODULE_2__.k), arguments), e >= this.ins.length) return ln;
    const u = (0,_script_c688360e_mjs__WEBPACK_IMPORTED_MODULE_2__.c)((0,_script_c688360e_mjs__WEBPACK_IMPORTED_MODULE_2__.e)(n).filter(e => e !== _script_c688360e_mjs__WEBPACK_IMPORTED_MODULE_2__.O.OP_CODESEPARATOR)),
      a = this.clone();
    if ((31 & r) === En.SIGHASH_NONE) a.outs = [], a.ins.forEach((t, n) => {
      n !== e && (t.sequence = 0);
    });else if ((31 & r) === En.SIGHASH_SINGLE) {
      if (e >= this.outs.length) return ln;
      a.outs.length = e + 1;
      for (let t = 0; t < e; t++) a.outs[t] = yn;
      a.ins.forEach((t, n) => {
        n !== e && (t.sequence = 0);
      });
    }
    r & En.SIGHASH_ANYONECANPAY ? (a.ins = [a.ins[e]], a.ins[0].script = u) : (a.ins.forEach(e => {
      e.script = pn;
    }), a.ins[e].script = u);
    const c = _index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_0__.B.allocUnsafe(a.byteLength(!1) + 4);
    return c.writeInt32LE(r, c.length - 4), a.__toBuffer(c, 0, !1), (0,_crypto_4198e1c6_mjs__WEBPACK_IMPORTED_MODULE_3__.a)(c);
  }
  hashForWitnessV1(e, n, r, u, a, c) {
    if (an((0,_script_c688360e_mjs__WEBPACK_IMPORTED_MODULE_2__.t)(_script_c688360e_mjs__WEBPACK_IMPORTED_MODULE_2__.h, an.arrayOf(_script_c688360e_mjs__WEBPACK_IMPORTED_MODULE_2__.B), an.arrayOf(_script_c688360e_mjs__WEBPACK_IMPORTED_MODULE_2__.S), _script_c688360e_mjs__WEBPACK_IMPORTED_MODULE_2__.h), arguments), r.length !== this.ins.length || n.length !== this.ins.length) throw new Error("Must supply prevout script and value for all inputs");
    const p = u === En.SIGHASH_DEFAULT ? En.SIGHASH_ALL : u & En.SIGHASH_OUTPUT_MASK,
      h = (u & En.SIGHASH_INPUT_MASK) === En.SIGHASH_ANYONECANPAY,
      l = p === En.SIGHASH_NONE,
      d = p === En.SIGHASH_SINGLE;
    let y = pn,
      E = pn,
      S = pn,
      _ = pn,
      w = pn;
    if (!h) {
      let e = on.withCapacity(36 * this.ins.length);
      this.ins.forEach(t => {
        e.writeSlice(t.hash), e.writeUInt32(t.index);
      }), y = (0,_crypto_4198e1c6_mjs__WEBPACK_IMPORTED_MODULE_3__.s)(e.end()), e = on.withCapacity(8 * this.ins.length), r.forEach(t => e.writeUInt64(t)), E = (0,_crypto_4198e1c6_mjs__WEBPACK_IMPORTED_MODULE_3__.s)(e.end()), e = on.withCapacity(n.map(cn).reduce((e, t) => e + t)), n.forEach(t => e.writeVarSlice(t)), S = (0,_crypto_4198e1c6_mjs__WEBPACK_IMPORTED_MODULE_3__.s)(e.end()), e = on.withCapacity(4 * this.ins.length), this.ins.forEach(t => e.writeUInt32(t.sequence)), _ = (0,_crypto_4198e1c6_mjs__WEBPACK_IMPORTED_MODULE_3__.s)(e.end());
    }
    if (l || d) {
      if (d && e < this.outs.length) {
        const t = this.outs[e],
          n = on.withCapacity(8 + cn(t.script));
        n.writeUInt64(t.value), n.writeVarSlice(t.script), w = (0,_crypto_4198e1c6_mjs__WEBPACK_IMPORTED_MODULE_3__.s)(n.end());
      }
    } else {
      const e = this.outs.map(e => 8 + cn(e.script)).reduce((e, t) => e + t),
        t = on.withCapacity(e);
      this.outs.forEach(e => {
        t.writeUInt64(e.value), t.writeVarSlice(e.script);
      }), w = (0,_crypto_4198e1c6_mjs__WEBPACK_IMPORTED_MODULE_3__.s)(t.end());
    }
    const T = (a ? 2 : 0) + (c ? 1 : 0),
      k = 174 - (h ? 49 : 0) - (l ? 32 : 0) + (c ? 32 : 0) + (a ? 37 : 0),
      b = on.withCapacity(k);
    if (b.writeUInt8(u), b.writeInt32(this.version), b.writeUInt32(this.locktime), b.writeSlice(y), b.writeSlice(E), b.writeSlice(S), b.writeSlice(_), l || d || b.writeSlice(w), b.writeUInt8(T), h) {
      const t = this.ins[e];
      b.writeSlice(t.hash), b.writeUInt32(t.index), b.writeUInt64(r[e]), b.writeVarSlice(n[e]), b.writeUInt32(t.sequence);
    } else b.writeUInt32(e);
    if (c) {
      const e = on.withCapacity(cn(c));
      e.writeVarSlice(c), b.writeSlice((0,_crypto_4198e1c6_mjs__WEBPACK_IMPORTED_MODULE_3__.s)(e.end()));
    }
    return d && b.writeSlice(w), a && (b.writeSlice(a), b.writeUInt8(0), b.writeUInt32(4294967295)), (0,_crypto_4198e1c6_mjs__WEBPACK_IMPORTED_MODULE_3__.t)("TapSighash", _index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_0__.B.concat([_index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_0__.B.of(0), b.end()]));
  }
  hashForWitnessV0(e, n, r, u) {
    an((0,_script_c688360e_mjs__WEBPACK_IMPORTED_MODULE_2__.t)(_script_c688360e_mjs__WEBPACK_IMPORTED_MODULE_2__.h, _script_c688360e_mjs__WEBPACK_IMPORTED_MODULE_2__.B, _script_c688360e_mjs__WEBPACK_IMPORTED_MODULE_2__.S, _script_c688360e_mjs__WEBPACK_IMPORTED_MODULE_2__.h), arguments);
    let a,
      c = _index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_0__.B.from([]),
      p = hn,
      h = hn,
      l = hn;
    if (u & En.SIGHASH_ANYONECANPAY || (c = _index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_0__.B.allocUnsafe(36 * this.ins.length), a = new on(c, 0), this.ins.forEach(e => {
      a.writeSlice(e.hash), a.writeUInt32(e.index);
    }), h = (0,_crypto_4198e1c6_mjs__WEBPACK_IMPORTED_MODULE_3__.a)(c)), u & En.SIGHASH_ANYONECANPAY || (31 & u) === En.SIGHASH_SINGLE || (31 & u) === En.SIGHASH_NONE || (c = _index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_0__.B.allocUnsafe(4 * this.ins.length), a = new on(c, 0), this.ins.forEach(e => {
      a.writeUInt32(e.sequence);
    }), l = (0,_crypto_4198e1c6_mjs__WEBPACK_IMPORTED_MODULE_3__.a)(c)), (31 & u) !== En.SIGHASH_SINGLE && (31 & u) !== En.SIGHASH_NONE) {
      const e = this.outs.reduce((e, t) => e + 8 + cn(t.script), 0);
      c = _index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_0__.B.allocUnsafe(e), a = new on(c, 0), this.outs.forEach(e => {
        a.writeUInt64(e.value), a.writeVarSlice(e.script);
      }), p = (0,_crypto_4198e1c6_mjs__WEBPACK_IMPORTED_MODULE_3__.a)(c);
    } else if ((31 & u) === En.SIGHASH_SINGLE && e < this.outs.length) {
      const n = this.outs[e];
      c = _index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_0__.B.allocUnsafe(8 + cn(n.script)), a = new on(c, 0), a.writeUInt64(n.value), a.writeVarSlice(n.script), p = (0,_crypto_4198e1c6_mjs__WEBPACK_IMPORTED_MODULE_3__.a)(c);
    }
    c = _index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_0__.B.allocUnsafe(156 + cn(n)), a = new on(c, 0);
    const d = this.ins[e];
    return a.writeInt32(this.version), a.writeSlice(h), a.writeSlice(l), a.writeSlice(d.hash), a.writeUInt32(d.index), a.writeVarSlice(n), a.writeUInt64(r), a.writeUInt32(d.sequence), a.writeSlice(p), a.writeUInt32(this.locktime), a.writeUInt32(u), (0,_crypto_4198e1c6_mjs__WEBPACK_IMPORTED_MODULE_3__.a)(c);
  }
  getHash(e) {
    return e && this.isCoinbase() ? _index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_0__.B.alloc(32, 0) : (0,_crypto_4198e1c6_mjs__WEBPACK_IMPORTED_MODULE_3__.a)(this.__toBuffer(void 0, void 0, e));
  }
  getId() {
    return rn(this.getHash(!1)).toString("hex");
  }
  toBuffer(e, t) {
    return this.__toBuffer(e, t, !0);
  }
  toHex() {
    return this.toBuffer(void 0, void 0).toString("hex");
  }
  setInputScript(e, t) {
    an((0,_script_c688360e_mjs__WEBPACK_IMPORTED_MODULE_2__.t)(_script_c688360e_mjs__WEBPACK_IMPORTED_MODULE_2__.k, _script_c688360e_mjs__WEBPACK_IMPORTED_MODULE_2__.B), arguments), this.ins[e].script = t;
  }
  setWitness(e, t) {
    an((0,_script_c688360e_mjs__WEBPACK_IMPORTED_MODULE_2__.t)(_script_c688360e_mjs__WEBPACK_IMPORTED_MODULE_2__.k, [_script_c688360e_mjs__WEBPACK_IMPORTED_MODULE_2__.B]), arguments), this.ins[e].witness = t;
  }
  __toBuffer(e, n, r = !1) {
    e || (e = _index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_0__.B.allocUnsafe(this.byteLength(r)));
    const i = new on(e, n || 0);
    i.writeInt32(this.version);
    const s = r && this.hasWitnesses();
    return s && (i.writeUInt8(En.ADVANCED_TRANSACTION_MARKER), i.writeUInt8(En.ADVANCED_TRANSACTION_FLAG)), i.writeVarInt(this.ins.length), this.ins.forEach(e => {
      i.writeSlice(e.hash), i.writeUInt32(e.index), i.writeVarSlice(e.script), i.writeUInt32(e.sequence);
    }), i.writeVarInt(this.outs.length), this.outs.forEach(e => {
      void 0 !== e.value ? i.writeUInt64(e.value) : i.writeSlice(e.valueBuffer), i.writeVarSlice(e.script);
    }), s && this.ins.forEach(e => {
      i.writeVector(e.witness);
    }), i.writeUInt32(this.locktime), void 0 !== n ? e.slice(n, i.offset) : e;
  }
}
En.DEFAULT_SEQUENCE = 4294967295, En.SIGHASH_DEFAULT = 0, En.SIGHASH_ALL = 1, En.SIGHASH_NONE = 2, En.SIGHASH_SINGLE = 3, En.SIGHASH_ANYONECANPAY = 128, En.SIGHASH_OUTPUT_MASK = 3, En.SIGHASH_INPUT_MASK = 128, En.ADVANCED_TRANSACTION_MARKER = 0, En.ADVANCED_TRANSACTION_FLAG = 1;
const Sn = {
  network: _networks_0de0aba6_mjs__WEBPACK_IMPORTED_MODULE_4__.b,
  maximumFeeRate: 5e3
};
class _n {
  constructor(e = {}, t = new H.exports.Psbt(new In())) {
    this.data = t, this.opts = Object.assign({}, Sn, e), this.__CACHE = {
      __NON_WITNESS_UTXO_TX_CACHE: [],
      __NON_WITNESS_UTXO_BUF_CACHE: [],
      __TX_IN_CACHE: {},
      __TX: this.data.globalMap.unsignedTx.tx,
      __UNSAFE_SIGN_NONSEGWIT: !1
    }, 0 === this.data.inputs.length && this.setVersion(2);
    const n = (e, t, n, r) => Object.defineProperty(e, t, {
      enumerable: n,
      writable: r
    });
    n(this, "__CACHE", !1, !0), n(this, "opts", !1, !0);
  }
  static fromBase64(e, n = {}) {
    const r = _index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_0__.B.from(e, "base64");
    return this.fromBuffer(r, n);
  }
  static fromHex(e, n = {}) {
    const r = _index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_0__.B.from(e, "hex");
    return this.fromBuffer(r, n);
  }
  static fromBuffer(e, t = {}) {
    const n = H.exports.Psbt.fromBuffer(e, wn),
      r = new _n(t, n);
    var i, s;
    return i = r.__CACHE.__TX, s = r.__CACHE, i.ins.forEach(e => {
      Bn(s, e);
    }), r;
  }
  get inputCount() {
    return this.data.inputs.length;
  }
  get version() {
    return this.__CACHE.__TX.version;
  }
  set version(e) {
    this.setVersion(e);
  }
  get locktime() {
    return this.__CACHE.__TX.locktime;
  }
  set locktime(e) {
    this.setLocktime(e);
  }
  get txInputs() {
    return this.__CACHE.__TX.ins.map(e => ({
      hash: sn(e.hash),
      index: e.index,
      sequence: e.sequence
    }));
  }
  get txOutputs() {
    return this.__CACHE.__TX.outs.map(e => {
      let t;
      try {
        t = (0,_address_e9eea1c2_mjs__WEBPACK_IMPORTED_MODULE_1__.fromOutputScript)(e.script, this.opts.network);
      } catch (e) {}
      return {
        script: sn(e.script),
        value: e.value,
        address: t
      };
    });
  }
  combine(...e) {
    return this.data.combine(...e.map(e => e.data)), this;
  }
  clone() {
    const e = _n.fromBuffer(this.data.toBuffer());
    return e.opts = JSON.parse(JSON.stringify(this.opts)), e;
  }
  setMaximumFeeRate(e) {
    Cn(e), this.opts.maximumFeeRate = e;
  }
  setVersion(e) {
    Cn(e), xn(this.data.inputs, "setVersion");
    const t = this.__CACHE;
    return t.__TX.version = e, t.__EXTRACTED_TX = void 0, this;
  }
  setLocktime(e) {
    Cn(e), xn(this.data.inputs, "setLocktime");
    const t = this.__CACHE;
    return t.__TX.locktime = e, t.__EXTRACTED_TX = void 0, this;
  }
  setInputSequence(e, t) {
    Cn(t), xn(this.data.inputs, "setInputSequence");
    const n = this.__CACHE;
    if (n.__TX.ins.length <= e) throw new Error("Input index too high");
    return n.__TX.ins[e].sequence = t, n.__EXTRACTED_TX = void 0, this;
  }
  addInputs(e) {
    return e.forEach(e => this.addInput(e)), this;
  }
  addInput(e) {
    if (arguments.length > 1 || !e || void 0 === e.hash || void 0 === e.index) throw new Error("Invalid arguments for Psbt.addInput. Requires single object with at least [hash] and [index]");
    xn(this.data.inputs, "addInput"), e.witnessScript && Qn(e.witnessScript);
    const t = this.__CACHE;
    this.data.addInput(e);
    Bn(t, t.__TX.ins[t.__TX.ins.length - 1]);
    const n = this.data.inputs.length - 1,
      r = this.data.inputs[n];
    return r.nonWitnessUtxo && jn(this.__CACHE, r, n), t.__FEE = void 0, t.__FEE_RATE = void 0, t.__EXTRACTED_TX = void 0, this;
  }
  addOutputs(e) {
    return e.forEach(e => this.addOutput(e)), this;
  }
  addOutput(e) {
    if (arguments.length > 1 || !e || void 0 === e.value || void 0 === e.address && void 0 === e.script) throw new Error("Invalid arguments for Psbt.addOutput. Requires single object with at least [script or address] and [value]");
    xn(this.data.inputs, "addOutput");
    const {
      address: t
    } = e;
    if ("string" == typeof t) {
      const {
          network: n
        } = this.opts,
        i = (0,_address_e9eea1c2_mjs__WEBPACK_IMPORTED_MODULE_1__.toOutputScript)(t, n);
      e = Object.assign(e, {
        script: i
      });
    }
    const n = this.__CACHE;
    return this.data.addOutput(e), n.__FEE = void 0, n.__FEE_RATE = void 0, n.__EXTRACTED_TX = void 0, this;
  }
  extractTransaction(e) {
    if (!this.data.inputs.every(kn)) throw new Error("Not finalized");
    const t = this.__CACHE;
    if (e || function (e, t, n) {
      const r = t.__FEE_RATE || e.getFeeRate(),
        i = t.__EXTRACTED_TX.virtualSize(),
        s = r * i;
      if (r >= n.maximumFeeRate) throw new Error(`Warning: You are paying around ${(s / 1e8).toFixed(8)} in fees, which is ${r} satoshi per byte for a transaction with a VSize of ${i} bytes (segwit counted as 0.25 byte per byte). Use setMaximumFeeRate method to raise your threshold, or pass true to the first arg of extractTransaction.`);
    }(this, t, this.opts), t.__EXTRACTED_TX) return t.__EXTRACTED_TX;
    const n = t.__TX.clone();
    return qn(this.data.inputs, n, t, !0), n;
  }
  getFeeRate() {
    return Kn("__FEE_RATE", "fee rate", this.data.inputs, this.__CACHE);
  }
  getFee() {
    return Kn("__FEE", "fee", this.data.inputs, this.__CACHE);
  }
  finalizeAllInputs() {
    return Wt.checkForInput(this.data.inputs, 0), tr(this.data.inputs.length).forEach(e => this.finalizeInput(e)), this;
  }
  finalizeInput(e, t = Dn) {
    const n = Wt.checkForInput(this.data.inputs, e),
      {
        script: r,
        isP2SH: i,
        isP2WSH: s,
        isSegwit: o
      } = function (e, t, n) {
        const r = n.__TX,
          i = {
            script: null,
            isSegwit: !1,
            isP2SH: !1,
            isP2WSH: !1
          };
        if (i.isP2SH = !!t.redeemScript, i.isP2WSH = !!t.witnessScript, t.witnessScript) i.script = t.witnessScript;else if (t.redeemScript) i.script = t.redeemScript;else if (t.nonWitnessUtxo) {
          const s = Yn(n, t, e),
            o = r.ins[e].index;
          i.script = s.outs[o].script;
        } else t.witnessUtxo && (i.script = t.witnessUtxo.script);
        (t.witnessScript || Nn(i.script)) && (i.isSegwit = !0);
        return i;
      }(e, n, this.__CACHE);
    if (!r) throw new Error(`No script found for input #${e}`);
    !function (e) {
      if (!e.sighashType || !e.partialSig) return;
      const {
        partialSig: t,
        sighashType: n
      } = e;
      t.forEach(e => {
        const {
          hashType: t
        } = _script_c688360e_mjs__WEBPACK_IMPORTED_MODULE_2__.s.decode(e.signature);
        if (n !== t) throw new Error("Signature sighash does not match input sighash type");
      });
    }(n);
    const {
      finalScriptSig: u,
      finalScriptWitness: a
    } = t(e, n, r, o, i, s);
    if (u && this.data.updateInput(e, {
      finalScriptSig: u
    }), a && this.data.updateInput(e, {
      finalScriptWitness: a
    }), !u && !a) throw new Error(`Unknown error finalizing input #${e}`);
    return this.data.clearFinalizedInput(e), this;
  }
  getInputType(e) {
    const n = Wt.checkForInput(this.data.inputs, e),
      r = Jn($n(e, n, this.__CACHE), e, "input", n.redeemScript || function (e) {
        if (!e) return;
        const n = (0,_script_c688360e_mjs__WEBPACK_IMPORTED_MODULE_2__.e)(e);
        if (!n) return;
        const r = n[n.length - 1];
        if (!_index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_0__.B.isBuffer(r) || zn(r) || (i = r, (0,_script_c688360e_mjs__WEBPACK_IMPORTED_MODULE_2__.d)(i))) return;
        var i;
        if (!(0,_script_c688360e_mjs__WEBPACK_IMPORTED_MODULE_2__.e)(r)) return;
        return r;
      }(n.finalScriptSig), n.witnessScript || function (e) {
        if (!e) return;
        const t = Wn(e),
          n = t[t.length - 1];
        if (zn(n)) return;
        if (!(0,_script_c688360e_mjs__WEBPACK_IMPORTED_MODULE_2__.e)(n)) return;
        return n;
      }(n.finalScriptWitness));
    return ("raw" === r.type ? "" : r.type + "-") + er(r.meaningfulScript);
  }
  inputHasPubkey(e, t) {
    return function (e, t, n, r) {
      const i = $n(n, t, r),
        {
          meaningfulScript: s
        } = Jn(i, n, "input", t.redeemScript, t.witnessScript);
      return Zn(e, s);
    }(t, Wt.checkForInput(this.data.inputs, e), e, this.__CACHE);
  }
  inputHasHDKey(e, t) {
    const n = Wt.checkForInput(this.data.inputs, e),
      r = Un(t);
    return !!n.bip32Derivation && n.bip32Derivation.some(r);
  }
  outputHasPubkey(e, t) {
    return function (e, t, n, r) {
      const i = r.__TX.outs[n].script,
        {
          meaningfulScript: s
        } = Jn(i, n, "output", t.redeemScript, t.witnessScript);
      return Zn(e, s);
    }(t, Wt.checkForOutput(this.data.outputs, e), e, this.__CACHE);
  }
  outputHasHDKey(e, t) {
    const n = Wt.checkForOutput(this.data.outputs, e),
      r = Un(t);
    return !!n.bip32Derivation && n.bip32Derivation.some(r);
  }
  validateSignaturesOfAllInputs(e) {
    Wt.checkForInput(this.data.inputs, 0);
    return tr(this.data.inputs.length).map(t => this.validateSignaturesOfInput(t, e)).reduce((e, t) => !0 === t && e, !0);
  }
  validateSignaturesOfInput(e, t, n) {
    const r = this.data.inputs[e],
      i = (r || {}).partialSig;
    if (!r || !i || i.length < 1) throw new Error("No signatures to validate");
    if ("function" != typeof t) throw new Error("Need validator function to validate signatures");
    const s = n ? i.filter(e => e.pubkey.equals(n)) : i;
    if (s.length < 1) throw new Error("No signatures for this pubkey");
    const o = [];
    let u, a, c;
    for (const n of s) {
      const i = _script_c688360e_mjs__WEBPACK_IMPORTED_MODULE_2__.s.decode(n.signature),
        {
          hash: s,
          script: p
        } = c !== i.hashType ? Fn(e, Object.assign({}, r, {
          sighashType: i.hashType
        }), this.__CACHE, !0) : {
          hash: u,
          script: a
        };
      c = i.hashType, u = s, a = p, Hn(n.pubkey, p, "verify"), o.push(t(n.pubkey, s, i.signature));
    }
    return o.every(e => !0 === e);
  }
  signAllInputsHD(e, t = [En.SIGHASH_ALL]) {
    if (!e || !e.publicKey || !e.fingerprint) throw new Error("Need HDSigner to sign input");
    const n = [];
    for (const r of tr(this.data.inputs.length)) try {
      this.signInputHD(r, e, t), n.push(!0);
    } catch (e) {
      n.push(!1);
    }
    if (n.every(e => !1 === e)) throw new Error("No inputs were signed");
    return this;
  }
  signAllInputsHDAsync(e, t = [En.SIGHASH_ALL]) {
    return new Promise((n, r) => {
      if (!e || !e.publicKey || !e.fingerprint) return r(new Error("Need HDSigner to sign input"));
      const i = [],
        s = [];
      for (const n of tr(this.data.inputs.length)) s.push(this.signInputHDAsync(n, e, t).then(() => {
        i.push(!0);
      }, () => {
        i.push(!1);
      }));
      return Promise.all(s).then(() => {
        if (i.every(e => !1 === e)) return r(new Error("No inputs were signed"));
        n();
      });
    });
  }
  signInputHD(e, t, n = [En.SIGHASH_ALL]) {
    if (!t || !t.publicKey || !t.fingerprint) throw new Error("Need HDSigner to sign input");
    return Mn(e, this.data.inputs, t).forEach(t => this.signInput(e, t, n)), this;
  }
  signInputHDAsync(e, t, n = [En.SIGHASH_ALL]) {
    return new Promise((r, i) => {
      if (!t || !t.publicKey || !t.fingerprint) return i(new Error("Need HDSigner to sign input"));
      const s = Mn(e, this.data.inputs, t).map(t => this.signInputAsync(e, t, n));
      return Promise.all(s).then(() => {
        r();
      }).catch(i);
    });
  }
  signAllInputs(e, t = [En.SIGHASH_ALL]) {
    if (!e || !e.publicKey) throw new Error("Need Signer to sign input");
    const n = [];
    for (const r of tr(this.data.inputs.length)) try {
      this.signInput(r, e, t), n.push(!0);
    } catch (e) {
      n.push(!1);
    }
    if (n.every(e => !1 === e)) throw new Error("No inputs were signed");
    return this;
  }
  signAllInputsAsync(e, t = [En.SIGHASH_ALL]) {
    return new Promise((n, r) => {
      if (!e || !e.publicKey) return r(new Error("Need Signer to sign input"));
      const i = [],
        s = [];
      for (const [n] of this.data.inputs.entries()) s.push(this.signInputAsync(n, e, t).then(() => {
        i.push(!0);
      }, () => {
        i.push(!1);
      }));
      return Promise.all(s).then(() => {
        if (i.every(e => !1 === e)) return r(new Error("No inputs were signed"));
        n();
      });
    });
  }
  signInput(e, t, n = [En.SIGHASH_ALL]) {
    if (!t || !t.publicKey) throw new Error("Need Signer to sign input");
    const {
        hash: r,
        sighashType: i
      } = Gn(this.data.inputs, e, t.publicKey, this.__CACHE, n),
      s = [{
        pubkey: t.publicKey,
        signature: _script_c688360e_mjs__WEBPACK_IMPORTED_MODULE_2__.s.encode(t.sign(r), i)
      }];
    return this.data.updateInput(e, {
      partialSig: s
    }), this;
  }
  signInputAsync(e, t, n = [En.SIGHASH_ALL]) {
    return Promise.resolve().then(() => {
      if (!t || !t.publicKey) throw new Error("Need Signer to sign input");
      const {
        hash: r,
        sighashType: i
      } = Gn(this.data.inputs, e, t.publicKey, this.__CACHE, n);
      return Promise.resolve(t.sign(r)).then(n => {
        const r = [{
          pubkey: t.publicKey,
          signature: _script_c688360e_mjs__WEBPACK_IMPORTED_MODULE_2__.s.encode(n, i)
        }];
        this.data.updateInput(e, {
          partialSig: r
        });
      });
    });
  }
  toBuffer() {
    return gn(this.__CACHE), this.data.toBuffer();
  }
  toHex() {
    return gn(this.__CACHE), this.data.toHex();
  }
  toBase64() {
    return gn(this.__CACHE), this.data.toBase64();
  }
  updateGlobal(e) {
    return this.data.updateGlobal(e), this;
  }
  updateInput(e, t) {
    return t.witnessScript && Qn(t.witnessScript), this.data.updateInput(e, t), t.nonWitnessUtxo && jn(this.__CACHE, this.data.inputs[e], e), this;
  }
  updateOutput(e, t) {
    return this.data.updateOutput(e, t), this;
  }
  addUnknownKeyValToGlobal(e) {
    return this.data.addUnknownKeyValToGlobal(e), this;
  }
  addUnknownKeyValToInput(e, t) {
    return this.data.addUnknownKeyValToInput(e, t), this;
  }
  addUnknownKeyValToOutput(e, t) {
    return this.data.addUnknownKeyValToOutput(e, t), this;
  }
  clearFinalizedInput(e) {
    return this.data.clearFinalizedInput(e), this;
  }
}
const wn = e => new In(e);
class In {
  constructor(e = _index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_0__.B.from([2, 0, 0, 0, 0, 0, 0, 0, 0, 0])) {
    this.tx = En.fromBuffer(e), function (e) {
      if (!e.ins.every(e => e.script && 0 === e.script.length && e.witness && 0 === e.witness.length)) throw new Error("Format Error: Transaction ScriptSigs are not empty");
    }(this.tx), Object.defineProperty(this, "tx", {
      enumerable: !1,
      writable: !0
    });
  }
  getInputOutputCounts() {
    return {
      inputCount: this.tx.ins.length,
      outputCount: this.tx.outs.length
    };
  }
  addInput(e) {
    if (void 0 === e.hash || void 0 === e.index || !_index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_0__.B.isBuffer(e.hash) && "string" != typeof e.hash || "number" != typeof e.index) throw new Error("Error adding input.");
    const n = "string" == typeof e.hash ? rn(_index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_0__.B.from(e.hash, "hex")) : e.hash;
    this.tx.addInput(n, e.index, e.sequence);
  }
  addOutput(e) {
    if (void 0 === e.script || void 0 === e.value || !_index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_0__.B.isBuffer(e.script) || "number" != typeof e.value) throw new Error("Error adding output.");
    this.tx.addOutput(e.script, e.value);
  }
  toBuffer() {
    return this.tx.toBuffer();
  }
}
function gn(e) {
  if (!1 !== e.__UNSAFE_SIGN_NONSEGWIT) throw new Error("Not BIP174 compliant, can not export");
}
function Tn(e, t, n) {
  if (!t) return !1;
  let r;
  if (r = n ? n.map(e => {
    const n = function (e) {
      if (65 === e.length) {
        const t = 1 & e[64],
          n = e.slice(0, 33);
        return n[0] = 2 | t, n;
      }
      return e.slice();
    }(e);
    return t.find(e => e.pubkey.equals(n));
  }).filter(e => !!e) : t, r.length > e) throw new Error("Too many signatures");
  return r.length === e;
}
function kn(e) {
  return !!e.finalScriptSig || !!e.finalScriptWitness;
}
function bn(e) {
  return t => {
    try {
      return e({
        output: t
      }), !0;
    } catch (e) {
      return !1;
    }
  };
}
const An = bn(_p2pk_2e124d52_mjs__WEBPACK_IMPORTED_MODULE_6__.p),
  mn = bn(_p2pk_2e124d52_mjs__WEBPACK_IMPORTED_MODULE_6__.a),
  vn = bn(_p2wsh_046e722b_mjs__WEBPACK_IMPORTED_MODULE_5__.p),
  Nn = bn(_p2wsh_046e722b_mjs__WEBPACK_IMPORTED_MODULE_5__.d),
  On = bn(_p2wsh_046e722b_mjs__WEBPACK_IMPORTED_MODULE_5__.e),
  Pn = bn(_p2wsh_046e722b_mjs__WEBPACK_IMPORTED_MODULE_5__.c);
function Un(e) {
  return t => !!t.masterFingerprint.equals(e.fingerprint) && !!e.derivePath(t.path).publicKey.equals(t.pubkey);
}
function Cn(e) {
  if ("number" != typeof e || e !== Math.floor(e) || e > 4294967295 || e < 0) throw new Error("Invalid 32 bit integer");
}
function xn(e, n) {
  e.forEach(e => {
    let r = !1,
      i = [];
    if (0 === (e.partialSig || []).length) {
      if (!e.finalScriptSig && !e.finalScriptWitness) return;
      i = function (e) {
        const n = e.finalScriptSig && (0,_script_c688360e_mjs__WEBPACK_IMPORTED_MODULE_2__.e)(e.finalScriptSig) || [],
          r = e.finalScriptWitness && (0,_script_c688360e_mjs__WEBPACK_IMPORTED_MODULE_2__.e)(e.finalScriptWitness) || [];
        return n.concat(r).filter(e => _index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_0__.B.isBuffer(e) && (0,_script_c688360e_mjs__WEBPACK_IMPORTED_MODULE_2__.d)(e)).map(e => ({
          signature: e
        }));
      }(e);
    } else i = e.partialSig;
    if (i.forEach(e => {
      const {
          hashType: t
        } = _script_c688360e_mjs__WEBPACK_IMPORTED_MODULE_2__.s.decode(e.signature),
        i = [];
      t & En.SIGHASH_ANYONECANPAY && i.push("addInput");
      switch (31 & t) {
        case En.SIGHASH_ALL:
          break;
        case En.SIGHASH_SINGLE:
        case En.SIGHASH_NONE:
          i.push("addOutput"), i.push("setInputSequence");
      }
      -1 === i.indexOf(n) && (r = !0);
    }), r) throw new Error("Can not modify transaction, signatures exist.");
  });
}
function Hn(e, t, n) {
  if (!Zn(e, t)) throw new Error(`Can not ${n} for this input with the key ${e.toString("hex")}`);
}
function Bn(e, n) {
  const r = rn(_index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_0__.B.from(n.hash)).toString("hex") + ":" + n.index;
  if (e.__TX_IN_CACHE[r]) throw new Error("Duplicate input detected.");
  e.__TX_IN_CACHE[r] = 1;
}
function Ln(e, t) {
  return (n, r, i, s) => {
    const o = e({
      redeem: {
        output: i
      }
    }).output;
    if (!r.equals(o)) throw new Error(`${t} for ${s} #${n} doesn't match the scriptPubKey in the prevout`);
  };
}
const Rn = Ln(_p2wsh_046e722b_mjs__WEBPACK_IMPORTED_MODULE_5__.c, "Redeem script"),
  Vn = Ln(_p2wsh_046e722b_mjs__WEBPACK_IMPORTED_MODULE_5__.e, "Witness script");
function Kn(e, t, n, r) {
  if (!n.every(kn)) throw new Error(`PSBT must be finalized to calculate ${t}`);
  if ("__FEE_RATE" === e && r.__FEE_RATE) return r.__FEE_RATE;
  if ("__FEE" === e && r.__FEE) return r.__FEE;
  let i,
    s = !0;
  return r.__EXTRACTED_TX ? (i = r.__EXTRACTED_TX, s = !1) : i = r.__TX.clone(), qn(n, i, r, s), "__FEE_RATE" === e ? r.__FEE_RATE : "__FEE" === e ? r.__FEE : void 0;
}
function Dn(e, t, n, r, i, s) {
  const o = er(n);
  if (!function (e, t, n) {
    switch (n) {
      case "pubkey":
      case "pubkeyhash":
      case "witnesspubkeyhash":
        return Tn(1, e.partialSig);
      case "multisig":
        const n = (0,_p2pk_2e124d52_mjs__WEBPACK_IMPORTED_MODULE_6__.p)({
          output: t
        });
        return Tn(n.m, e.partialSig, n.pubkeys);
      default:
        return !1;
    }
  }(t, n, o)) throw new Error(`Can not finalize input #${e}`);
  return function (e, t, n, r, i, s) {
    let o, u;
    const a = function (e, t, n) {
        let r;
        switch (t) {
          case "multisig":
            const t = function (e, t) {
              return (0,_p2pk_2e124d52_mjs__WEBPACK_IMPORTED_MODULE_6__.p)({
                output: e
              }).pubkeys.map(e => (t.filter(t => t.pubkey.equals(e))[0] || {}).signature).filter(e => !!e);
            }(e, n);
            r = (0,_p2pk_2e124d52_mjs__WEBPACK_IMPORTED_MODULE_6__.p)({
              output: e,
              signatures: t
            });
            break;
          case "pubkey":
            r = (0,_p2pk_2e124d52_mjs__WEBPACK_IMPORTED_MODULE_6__.a)({
              output: e,
              signature: n[0].signature
            });
            break;
          case "pubkeyhash":
            r = (0,_p2wsh_046e722b_mjs__WEBPACK_IMPORTED_MODULE_5__.p)({
              output: e,
              pubkey: n[0].pubkey,
              signature: n[0].signature
            });
            break;
          case "witnesspubkeyhash":
            r = (0,_p2wsh_046e722b_mjs__WEBPACK_IMPORTED_MODULE_5__.d)({
              output: e,
              pubkey: n[0].pubkey,
              signature: n[0].signature
            });
        }
        return r;
      }(e, t, n),
      c = s ? (0,_p2wsh_046e722b_mjs__WEBPACK_IMPORTED_MODULE_5__.e)({
        redeem: a
      }) : null,
      p = i ? (0,_p2wsh_046e722b_mjs__WEBPACK_IMPORTED_MODULE_5__.c)({
        redeem: c || a
      }) : null;
    r ? (u = Xn(c ? c.witness : a.witness), p && (o = p.input)) : o = p ? p.input : a.input;
    return {
      finalScriptSig: o,
      finalScriptWitness: u
    };
  }(n, o, t.partialSig, r, i, s);
}
function Gn(e, t, n, r, i) {
  const s = Wt.checkForInput(e, t),
    {
      hash: o,
      sighashType: u,
      script: a
    } = Fn(t, s, r, !1, i);
  return Hn(n, a, "sign"), {
    hash: o,
    sighashType: u
  };
}
function Fn(e, t, n, r, i) {
  const s = n.__TX,
    o = t.sighashType || En.SIGHASH_ALL;
  if (i && i.indexOf(o) < 0) {
    const e = function (e) {
      let t = e & En.SIGHASH_ANYONECANPAY ? "SIGHASH_ANYONECANPAY | " : "";
      switch (31 & e) {
        case En.SIGHASH_ALL:
          t += "SIGHASH_ALL";
          break;
        case En.SIGHASH_SINGLE:
          t += "SIGHASH_SINGLE";
          break;
        case En.SIGHASH_NONE:
          t += "SIGHASH_NONE";
      }
      return t;
    }(o);
    throw new Error(`Sighash type is not allowed. Retry the sign method passing the sighashTypes array of whitelisted types. Sighash type: ${e}`);
  }
  let u, a;
  if (t.nonWitnessUtxo) {
    const r = Yn(n, t, e),
      i = s.ins[e].hash,
      o = r.getHash();
    if (!i.equals(o)) throw new Error(`Non-witness UTXO hash for input #${e} doesn't match the hash specified in the prevout`);
    const u = s.ins[e].index;
    a = r.outs[u];
  } else {
    if (!t.witnessUtxo) throw new Error("Need a Utxo input item for signing");
    a = t.witnessUtxo;
  }
  const {
    meaningfulScript: c,
    type: p
  } = Jn(a.script, e, "input", t.redeemScript, t.witnessScript);
  if (["p2sh-p2wsh", "p2wsh"].indexOf(p) >= 0) u = s.hashForWitnessV0(e, c, a.value, o);else if (Nn(c)) {
    const t = (0,_p2wsh_046e722b_mjs__WEBPACK_IMPORTED_MODULE_5__.p)({
      hash: c.slice(2)
    }).output;
    u = s.hashForWitnessV0(e, t, a.value, o);
  } else {
    if (void 0 === t.nonWitnessUtxo && !1 === n.__UNSAFE_SIGN_NONSEGWIT) throw new Error(`Input #${e} has witnessUtxo but non-segwit script: ${c.toString("hex")}`);
    r || !1 === n.__UNSAFE_SIGN_NONSEGWIT || console.warn("Warning: Signing non-segwit inputs without the full parent transaction means there is a chance that a miner could feed you incorrect information to trick you into paying large fees. This behavior is the same as Psbt's predecesor (TransactionBuilder - now removed) when signing non-segwit scripts. You are not able to export this Psbt with toBuffer|toBase64|toHex since it is not BIP174 compliant.\n*********************\nPROCEED WITH CAUTION!\n*********************"), u = s.hashForSignature(e, c, o);
  }
  return {
    script: c,
    sighashType: o,
    hash: u
  };
}
function Mn(e, t, n) {
  const r = Wt.checkForInput(t, e);
  if (!r.bip32Derivation || 0 === r.bip32Derivation.length) throw new Error("Need bip32Derivation to sign with HD");
  const i = r.bip32Derivation.map(e => e.masterFingerprint.equals(n.fingerprint) ? e : void 0).filter(e => !!e);
  if (0 === i.length) throw new Error("Need one bip32Derivation masterFingerprint to match the HDSigner fingerprint");
  return i.map(e => {
    const t = n.derivePath(e.path);
    if (!e.pubkey.equals(t.publicKey)) throw new Error("pubkey did not match bip32Derivation");
    return t;
  });
}
function Wn(e) {
  let t = 0;
  function n() {
    const n = zt.decode(e, t);
    return t += zt.decode.bytes, n;
  }
  function r() {
    return r = n(), t += r, e.slice(t - r, t);
    var r;
  }
  return function () {
    const e = n(),
      t = [];
    for (let n = 0; n < e; n++) t.push(r());
    return t;
  }();
}
function Xn(e) {
  let n = _index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_0__.B.allocUnsafe(0);
  function r(e) {
    const r = n.length,
      i = zt.encodingLength(e);
    n = _index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_0__.B.concat([n, _index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_0__.B.allocUnsafe(i)]), zt.encode(e, n, r);
  }
  function i(e) {
    r(e.length), function (e) {
      n = _index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_0__.B.concat([n, _index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_0__.B.from(e)]);
    }(e);
  }
  var s;
  return r((s = e).length), s.forEach(i), n;
}
function jn(e, t, n) {
  e.__NON_WITNESS_UTXO_BUF_CACHE[n] = t.nonWitnessUtxo;
  const r = En.fromBuffer(t.nonWitnessUtxo);
  e.__NON_WITNESS_UTXO_TX_CACHE[n] = r;
  const i = e,
    s = n;
  delete t.nonWitnessUtxo, Object.defineProperty(t, "nonWitnessUtxo", {
    enumerable: !0,
    get() {
      const e = i.__NON_WITNESS_UTXO_BUF_CACHE[s],
        t = i.__NON_WITNESS_UTXO_TX_CACHE[s];
      if (void 0 !== e) return e;
      {
        const e = t.toBuffer();
        return i.__NON_WITNESS_UTXO_BUF_CACHE[s] = e, e;
      }
    },
    set(e) {
      i.__NON_WITNESS_UTXO_BUF_CACHE[s] = e;
    }
  });
}
function qn(e, t, n, r) {
  let i = 0;
  e.forEach((e, s) => {
    if (r && e.finalScriptSig && (t.ins[s].script = e.finalScriptSig), r && e.finalScriptWitness && (t.ins[s].witness = Wn(e.finalScriptWitness)), e.witnessUtxo) i += e.witnessUtxo.value;else if (e.nonWitnessUtxo) {
      const r = Yn(n, e, s),
        o = t.ins[s].index,
        u = r.outs[o];
      i += u.value;
    }
  });
  const s = t.outs.reduce((e, t) => e + t.value, 0),
    o = i - s;
  if (o < 0) throw new Error("Outputs are spending more than Inputs");
  const u = t.virtualSize();
  n.__FEE = o, n.__EXTRACTED_TX = t, n.__FEE_RATE = Math.floor(o / u);
}
function Yn(e, t, n) {
  const r = e.__NON_WITNESS_UTXO_TX_CACHE;
  return r[n] || jn(e, t, n), r[n];
}
function $n(e, t, n) {
  if (void 0 !== t.witnessUtxo) return t.witnessUtxo.script;
  if (void 0 !== t.nonWitnessUtxo) {
    return Yn(n, t, e).outs[n.__TX.ins[e].index].script;
  }
  throw new Error("Can't find pubkey in input without Utxo data");
}
function zn(e) {
  return 33 === e.length && (0,_script_c688360e_mjs__WEBPACK_IMPORTED_MODULE_2__.l)(e);
}
function Jn(e, t, n, r, i) {
  const s = Pn(e),
    o = s && r && On(r),
    u = On(e);
  if (s && void 0 === r) throw new Error("scriptPubkey is P2SH but redeemScript missing");
  if ((u || o) && void 0 === i) throw new Error("scriptPubkey or redeemScript is P2WSH but witnessScript missing");
  let a;
  return o ? (a = i, Rn(t, e, r, n), Vn(t, r, i, n), Qn(a)) : u ? (a = i, Vn(t, e, i, n), Qn(a)) : s ? (a = r, Rn(t, e, r, n)) : a = e, {
    meaningfulScript: a,
    type: o ? "p2sh-p2wsh" : s ? "p2sh" : u ? "p2wsh" : "raw"
  };
}
function Qn(e) {
  if (Nn(e) || Pn(e)) throw new Error("P2WPKH or P2SH can not be contained within P2WSH");
}
function Zn(e, t) {
  const n = (0,_crypto_4198e1c6_mjs__WEBPACK_IMPORTED_MODULE_3__.h)(e),
    r = (0,_script_c688360e_mjs__WEBPACK_IMPORTED_MODULE_2__.e)(t);
  if (null === r) throw new Error("Unknown script error");
  return r.some(t => "number" != typeof t && (t.equals(e) || t.equals(n)));
}
function er(e) {
  return Nn(e) ? "witnesspubkeyhash" : vn(e) ? "pubkeyhash" : An(e) ? "multisig" : mn(e) ? "pubkey" : "nonstandard";
}
function tr(e) {
  return [...Array(e).keys()];
}


/***/ })

}]);
//# sourceMappingURL=apps_bfswap_src_assets_wallet-util_psbt-2c046ca8_mjs.js.map