"use strict";
(self["webpackChunkbfswap"] = self["webpackChunkbfswap"] || []).push([["default-apps_bfswap_src_components_select-token-panel_select-token-panel_component_ts"],{

/***/ 87002:
/*!***************************************************************************************!*\
  !*** ./apps/bfswap/src/components/select-token-panel/select-token-panel.component.ts ***!
  \***************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   SelectTokenPanelPage: () => (/* binding */ SelectTokenPanelPage),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 52542);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! tslib */ 90505);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/core */ 61039);
/* harmony import */ var _components_token_with_chain_icon_token_with_chain_icon_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ~components/token-with-chain-icon/token-with-chain-icon.component */ 11342);
/* harmony import */ var _modules_page_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ~modules/page.module */ 16381);
/* harmony import */ var _services_wallet_wallet_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ~services/wallet/wallet.service */ 54275);
/* harmony import */ var _select_token_panel_type__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./select-token-panel.type */ 47082);
/* harmony import */ var _select_token_panel_helper__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./select-token-panel.helper */ 16963);
/* harmony import */ var _bnqkl_framework_animations__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @bnqkl/framework/animations */ 43127);
/* harmony import */ var _services_liquidity_pool_liquidity_pool_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ~services/liquidity-pool/liquidity-pool.service */ 20213);
/* harmony import */ var _bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @bnqkl/bnqkl-swap-core */ 70195);
/* harmony import */ var _bnqkl_framework_plugins__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @bnqkl/framework/plugins */ 43990);
/* harmony import */ var _components_swap_token_chain_icon_swap_token_chain_icon_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ~components/swap-token-chain-icon/swap-token-chain-icon.component */ 26193);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @angular/common */ 6729);
/* harmony import */ var _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../../../../libs/bnf/modules/page/common-page/common-page.component */ 62052);
/* harmony import */ var _icon_icon_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../icon/icon.component */ 18840);
/* harmony import */ var _libs_bnf_pipes_amountFixed_amount_fixed_pipe__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../../../../../libs/bnf/pipes/amountFixed/amount-fixed.pipe */ 44070);

var _class;

















function SelectTokenPanelPage_button_12_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](0, "div", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelement"](1, "bs-swap-token-chain-icon", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const chain_r7 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("swapChainName", chain_r7.chain)("iconSize", "icon-6");
  }
}
function SelectTokenPanelPage_button_12_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](0, "div", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵi18n"](1, 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
  }
}
function SelectTokenPanelPage_button_12_Template(rf, ctx) {
  if (rf & 1) {
    const _r12 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](0, "button", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵlistener"]("click", function SelectTokenPanelPage_button_12_Template_button_click_0_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵrestoreView"](_r12);
      const chain_r7 = restoredCtx.$implicit;
      const ctx_r11 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵresetView"](ctx_r11.selectChain(chain_r7.chain));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtemplate"](1, SelectTokenPanelPage_button_12_Conditional_1_Template, 2, 2, "div", 19)(2, SelectTokenPanelPage_button_12_Conditional_2_Template, 2, 0);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const chain_r7 = ctx.$implicit;
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵclassMap"](chain_r7.chain === ctx_r0.selectedChainName ? "border-primary border-[2px]" : "border-border-10 border-[1px]");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵconditional"](1, chain_r7.chain !== "*" ? 1 : 2);
  }
}
function SelectTokenPanelPage_Conditional_13_Template(rf, ctx) {
  if (rf & 1) {
    const _r14 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](0, "div", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵlistener"]("click", function SelectTokenPanelPage_Conditional_13_Template_div_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵrestoreView"](_r14);
      const ctx_r13 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵresetView"](ctx_r13.foldChain = !ctx_r13.foldChain);
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelement"](1, "bs-icon", 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("name", ctx_r1.foldChain ? "icon-unflod-less" : "icon-unflod-more");
  }
}
const _c10 = () => ({
  removeZero: true
});
function SelectTokenPanelPage_ng_container_16_li_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r18 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](0, "li")(1, "button", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵlistener"]("click", function SelectTokenPanelPage_ng_container_16_li_2_Template_button_click_1_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵrestoreView"](_r18);
      const asset_r16 = restoredCtx.$implicit;
      const ctx_r17 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵresetView"](ctx_r17.selectAsset(asset_r16));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelement"](2, "bs-token-with-chain-icon", 29);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](3, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](5, "span", 30);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipe"](7, "amountFixed");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const asset_r16 = ctx.$implicit;
    const ctx_r15 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵclassMap"](ctx_r15.isSelectedAsset(asset_r16) ? "bg-base-300 " : "");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵclassMap"](ctx_r15.isSelectedAsset(asset_r16) ? " opacity-50" : "");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("disabled", ctx_r15.isDisabledAsset(asset_r16));
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("tokenName", asset_r16.tokenIcon)("chainName", asset_r16.chainIcon);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtextInterpolate1"](" ", asset_r16.tokenName, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipeBind3"](7, 9, asset_r16.amount, 8, _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpureFunction0"](13, _c10)), " ");
  }
}
function SelectTokenPanelPage_ng_container_16_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](1, "ul", 26);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtemplate"](2, SelectTokenPanelPage_ng_container_16_li_2_Template, 8, 14, "li", 27);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("@listFadeInRight", ctx_r2.listFadeInRightState);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("ngForOf", ctx_r2.showAssetList)("ngForTrackBy", ctx_r2.trackByKey("tokenName", "chainName"));
  }
}
function SelectTokenPanelPage_ng_template_17_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelement"](1, "span", 32);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementContainerEnd"]();
  }
}
const _c11 = () => ({
  height: "calc(100% - 3rem)"
});
function SelectTokenPanelPage_ng_template_17_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](0, "div", 31);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtemplate"](1, SelectTokenPanelPage_ng_template_17_ng_container_1_Template, 2, 0, "ng-container", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnextContext"]();
    const _r6 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵreference"](20);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("ngStyle", _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpureFunction0"](3, _c11));
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("ngIf", ctx_r3.updating)("ngIfElse", _r6);
  }
}
function SelectTokenPanelPage_ng_template_19_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelement"](0, "img", 33);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](1, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵi18n"](2, 34);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
  }
}
/**
 * 选择币种弹窗
 */
class SelectTokenPanelPage extends _modules_page_module__WEBPACK_IMPORTED_MODULE_2__.CommonPageBase {
  constructor() {
    var _this$poolService$upd;
    super(...arguments);
    this.walletService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_14__.inject)(_services_wallet_wallet_service__WEBPACK_IMPORTED_MODULE_3__.WalletService);
    this.poolService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_14__.inject)(_services_liquidity_pool_liquidity_pool_service__WEBPACK_IMPORTED_MODULE_7__.LiquidityPoolService);
    /** 返回类型 */
    this.returnValue$ = new _modules_page_module__WEBPACK_IMPORTED_MODULE_2__.PageReturnValue();
    /** 池子的资产列表（包含资产余额） */
    this.liquidityPoolAssetsInfo = [];
    /** 正在更新池子配置 */
    this.updating = (_this$poolService$upd = this.poolService.updateLiquidityPoolConfig_subject.value) === null || _this$poolService$upd === void 0 ? void 0 : _this$poolService$upd.updating;
    /** 当前选中的资产 */
    this.selectedAsset = [];
    /** 只显示U资产 */
    this.onlyUSDM = false;
    /** 不显示U资产 */
    this.noUSDM = false;
    /** 不可选中的的资产 */
    this.disabledAsset = [];
    /** 链分组信息 */
    this.chainGroupInfo = [];
    /** 选中的链分组名称 */
    this.selectedChainName = '*';
    /** 折叠链 */
    this.foldChain = true;
  }
  /** 监听数据 */
  initData() {
    var _this = this;
    // 监听池子币种余额列表
    this.poolAssets$ = this.walletService.liquidityPoolAssetsListWithAmout_subject.subscribe( /*#__PURE__*/function () {
      var _ref = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (liquidityPoolAssetsListWithAmountInfo) {
        // 初始值
        if (liquidityPoolAssetsListWithAmountInfo === undefined) {
          return;
        }
        // 当前值
        if (liquidityPoolAssetsListWithAmountInfo.liquidityPoolAssetsListWithAmount) {
          _this.console.info('订阅到池子币种余额列表更新', liquidityPoolAssetsListWithAmountInfo.liquidityPoolAssetsListWithAmount);
          _this.liquidityPoolAssetsInfo = liquidityPoolAssetsListWithAmountInfo.liquidityPoolAssetsListWithAmount;
        }
        return;
      });
      return function (_x) {
        return _ref.apply(this, arguments);
      };
    }());
    this.poolConfig$ = this.poolService.updateLiquidityPoolConfig_subject.subscribe( /*#__PURE__*/function () {
      var _ref2 = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (configTaskInfo) {
        // 初始值
        if (configTaskInfo == undefined || configTaskInfo.liquidityPoolsConfigs === undefined) {
          return;
        }
        if (configTaskInfo.updating && _this.liquidityPoolAssetsInfo.length <= 0) {
          _this.updating = configTaskInfo.updating;
        } else {
          _this.updating = false;
        }
      });
      return function (_x2) {
        return _ref2.apply(this, arguments);
      };
    }());
    this.walletService.allSubscribes.set('SelectTokenPanelPage', [this.poolAssets$, this.poolConfig$]);
  }
  /** 清除订阅监听 */
  unsubscribe() {
    this.console.log('清除 订阅');
    this.poolAssets$ && this.poolAssets$.unsubscribe();
    this.poolConfig$ && this.poolConfig$.unsubscribe();
    this.walletService.allSubscribes.delete('SelectTokenPanelPage');
  }
  /** 展示折叠按钮 */
  get showFoldBtn() {
    return this.showChainList.length > 7;
  }
  /** 确认是否为选中资产 */
  isSelectedAsset(asset) {
    const {
      tokenName,
      chainName
    } = asset;
    const result = this.selectedAsset.find(item => {
      return item.chainName === chainName && item.tokenName === tokenName;
    });
    return Boolean(result);
  }
  /** 确认是否为不可选中资产 */
  isDisabledAsset(asset) {
    const {
      tokenName,
      chainName
    } = asset;
    const result = this.disabledAsset.find(item => {
      return item.chainName === chainName && item.tokenName === tokenName;
    });
    return Boolean(result);
  }
  /** 要展示的资产列表 */
  get showAssetList() {
    const list = this.liquidityPoolAssetsInfo;
    const {
      selectedChainName
    } = this;
    return (0,_select_token_panel_helper__WEBPACK_IMPORTED_MODULE_5__.assetListFilter)(list, {
      chain: selectedChainName === '*' ? undefined : selectedChainName,
      tokenName: this.onlyUSDM ? _bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_8__.BNQKL_SWAP_COIN_NAME.USDM : undefined
    }, {
      tokenName: this.noUSDM ? _bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_8__.BNQKL_SWAP_COIN_NAME.USDM : undefined
    });
  }
  /** 要展示的链列表 */
  get showChainList() {
    return [{
      chain: '*',
      chainI18nName: "\u5168\u90E8"
    }, ...this.chainGroupInfo
    // ...[
    //   {
    //     chain: 'BFMeta',
    //     chainI18nName: 'BFMeta',
    //   },
    //   {
    //     chain: 'BFChainV2',
    //     chainI18nName: 'BFChainV2',
    //   },
    //   {
    //     chain: 'BTCMeta',
    //     chainI18nName: 'BTCMeta',
    //   },
    //   {
    //     chain: 'BFMeta',
    //     chainI18nName: 'BFMeta',
    //   },
    //   {
    //     chain: 'BFChainV2',
    //     chainI18nName: 'BFChainV2',
    //   },
    //   {
    //     chain: 'BTCMeta',
    //     chainI18nName: 'BTCMeta',
    //   },
    // ],
    // ...[
    //   {
    //     chain: 'BFMeta',
    //     chainI18nName: 'BFMeta',
    //   },
    //   {
    //     chain: 'BFChainV2',
    //     chainI18nName: 'BFChainV2',
    //   },
    //   {
    //     chain: 'BTCMeta',
    //     chainI18nName: 'BTCMeta',
    //   },
    //   {
    //     chain: 'ETHMeta',
    //     chainI18nName: 'ETHMeta',
    //   },
    //   {
    //     chain: 'Pay Meta Chain',
    //     chainI18nName: 'Pay Meta Chain',
    //   },
    //     {
    //     chain: 'BFChainV2',
    //     chainI18nName: 'BFChainV2',
    //   },
    //   {
    //     chain: 'BTCMeta',
    //     chainI18nName: 'BTCMeta',
    //   },
    // ],
    ];
  }
  /** 选择链分组 */
  selectChain(chainName) {
    this.selectedChainName = chainName;
  }
  /** 提交 */
  selectAsset(asset) {
    var _this2 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      // 已连接钱包且未授权
      if (asset.unAuth && _this2.walletService.connectedWallet) {
        _this2.console.info('该币种所在的链未授权');
        return _bnqkl_framework_plugins__WEBPACK_IMPORTED_MODULE_9__.Toast.show('请先授权该地址后重试');
      } else {
        _this2.returnValue$.return({
          selectedAsset: asset
        });
        return _this2.nav.back();
      }
    })();
  }
  /** 动画的状态机 */
  get listFadeInRightState() {
    return this.selectedChainName + ':' + this.showAssetList.length;
  }
}
_class = SelectTokenPanelPage;
_class.ɵfac = /*@__PURE__*/(() => {
  let ɵSelectTokenPanelPage_BaseFactory;
  return function SelectTokenPanelPage_Factory(t) {
    return (ɵSelectTokenPanelPage_BaseFactory || (ɵSelectTokenPanelPage_BaseFactory = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵgetInheritedFactory"](_class)))(t || _class);
  };
})();
_class.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵdefineComponent"]({
  type: _class,
  selectors: [["bs-select-token-panel-page"]],
  inputs: {
    liquidityPoolAssetsInfo: "liquidityPoolAssetsInfo",
    selectedAsset: "selectedAsset",
    onlyUSDM: "onlyUSDM",
    noUSDM: "noUSDM",
    disabledAsset: "disabledAsset",
    chainGroupInfo: "chainGroupInfo"
  },
  outputs: {
    returnValue$: "returnValue$"
  },
  standalone: true,
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵInheritDefinitionFeature"], _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵStandaloneFeature"]],
  decls: 21,
  vars: 12,
  consts: () => {
    let i18n_0;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_Select_Token_PANEL$$APPS_BFSWAP_SRC_COMPONENTS_SELECT_TOKEN_PANEL_SELECT_TOKEN_PANEL_COMPONENT_TS_1 = goog.getMsg("Select Token Panel");
      i18n_0 = MSG_EXTERNAL_Select_Token_PANEL$$APPS_BFSWAP_SRC_COMPONENTS_SELECT_TOKEN_PANEL_SELECT_TOKEN_PANEL_COMPONENT_TS_1;
    } else {
      i18n_0 = "\u9009\u62E9\u5E01\u79CD";
    }
    let i18n_2;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_7457676959720689020$$APPS_BFSWAP_SRC_COMPONENTS_SELECT_TOKEN_PANEL_SELECT_TOKEN_PANEL_COMPONENT_TS_3 = goog.getMsg("\u9009\u62E9\u7F51\u7EDC\uFF1A");
      i18n_2 = MSG_EXTERNAL_7457676959720689020$$APPS_BFSWAP_SRC_COMPONENTS_SELECT_TOKEN_PANEL_SELECT_TOKEN_PANEL_COMPONENT_TS_3;
    } else {
      i18n_2 = "\u9009\u62E9\u7F51\u7EDC\uFF1A";
    }
    let i18n_4;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_7476430538868386147$$APPS_BFSWAP_SRC_COMPONENTS_SELECT_TOKEN_PANEL_SELECT_TOKEN_PANEL_COMPONENT_TS_5 = goog.getMsg("\u5168\u90E8\u7F51\u7EDC");
      i18n_4 = MSG_EXTERNAL_7476430538868386147$$APPS_BFSWAP_SRC_COMPONENTS_SELECT_TOKEN_PANEL_SELECT_TOKEN_PANEL_COMPONENT_TS_5;
    } else {
      i18n_4 = "\u5168\u90E8\u7F51\u7EDC";
    }
    let i18n_6;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_9083624195241845502$$APPS_BFSWAP_SRC_COMPONENTS_SELECT_TOKEN_PANEL_SELECT_TOKEN_PANEL_COMPONENT_TS_7 = goog.getMsg("\u9009\u62E9\u5E01\u79CD");
      i18n_6 = MSG_EXTERNAL_9083624195241845502$$APPS_BFSWAP_SRC_COMPONENTS_SELECT_TOKEN_PANEL_SELECT_TOKEN_PANEL_COMPONENT_TS_7;
    } else {
      i18n_6 = "\u9009\u62E9\u5E01\u79CD";
    }
    let i18n_8;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_6313993506672907169$$APPS_BFSWAP_SRC_COMPONENTS_SELECT_TOKEN_PANEL_SELECT_TOKEN_PANEL_COMPONENT_TS___9 = goog.getMsg("\u5168\u90E8");
      i18n_8 = MSG_EXTERNAL_6313993506672907169$$APPS_BFSWAP_SRC_COMPONENTS_SELECT_TOKEN_PANEL_SELECT_TOKEN_PANEL_COMPONENT_TS___9;
    } else {
      i18n_8 = "\u5168\u90E8";
    }
    let i18n_12;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_THERE_IS_CURRENTLY_NO_LIQUIDITY_POOL_CONFIGURATION$$APPS_BFSWAP_SRC_COMPONENTS_SELECT_TOKEN_PANEL_SELECT_TOKEN_PANEL_COMPONENT_TS__13 = goog.getMsg(" There is currently no liquidity pool configuration ");
      i18n_12 = MSG_EXTERNAL_THERE_IS_CURRENTLY_NO_LIQUIDITY_POOL_CONFIGURATION$$APPS_BFSWAP_SRC_COMPONENTS_SELECT_TOKEN_PANEL_SELECT_TOKEN_PANEL_COMPONENT_TS__13;
    } else {
      i18n_12 = "\u76EE\u524D\u6CA1\u6709\u6D41\u52A8\u6027\u6C60\u914D\u7F6E";
    }
    return [["headerTitle", i18n_0, 3, "hideBackButton", "contentClass", "contentBackground", "titleClass", "headerClass", "contentSafeArea"], ["endMenu", "", 3, "click"], ["name", "icon-popup-close", 1, "icon-7"], [1, "flex", "h-full", "flex-col"], [1, "mb-2", "flex", "items-center", "pl-4", "text-xs"], [1, "text-gray-10"], i18n_2, [1, "text-title-10", "ml-1", "font-medium"], i18n_4, [1, "mb-4", "flex", "w-full", "justify-start", "px-4"], [1, "flex", "w-full", "flex-wrap"], ["class", "rounded-3 mb-2 mr-2 flex h-10 w-10 shrink-0 items-center justify-center", 3, "class", "click", 4, "ngFor", "ngForOf"], ["class", "bg-base-300 rounded-3 flex h-10 w-10 shrink-0 items-center justify-center"], [1, "text-gray-10", "ml-1", "text-xs"], i18n_6, [4, "ngIf", "ngIfElse"], ["noAssetData", ""], ["noUpdating", ""], [1, "rounded-3", "mb-2", "mr-2", "flex", "h-10", "w-10", "shrink-0", "items-center", "justify-center", 3, "click"], ["class", "rounded-1.5 bg-blue-10 h-6 w-6"], [1, "rounded-1.5", "bg-blue-10", "h-6", "w-6"], [3, "swapChainName", "iconSize"], [1, "text-title-10", "font-medium"], i18n_8, [1, "bg-base-300", "rounded-3", "flex", "h-10", "w-10", "shrink-0", "items-center", "justify-center", 3, "click"], [1, "icon-5", 3, "name"], [1, "overflow-x-hidden", "overflow-y-scroll"], [3, "class", 4, "ngFor", "ngForOf", "ngForTrackBy"], [1, "text-title-10", "flex", "w-full", "items-center", "px-4", "py-3", "text-base", "font-bold", 3, "disabled", "click"], [1, "mr-2", 3, "tokenName", "chainName"], [1, "ml-auto"], [1, "text-base-gray", "flex", "flex-col", "items-center", "justify-center", "text-sm", 3, "ngStyle"], [1, "duibs-loading", "duibs-loading-infinity", "duibs-loading-lg", "text-primary"], ["src", "./assets/images/placeholder-1.png", 1, "w-[14.6875rem]"], i18n_12];
  },
  template: function SelectTokenPanelPage_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](0, "common-page", 0)(1, "button", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵlistener"]("click", function SelectTokenPanelPage_Template_button_click_1_listener() {
        return ctx.nav.back();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelement"](2, "bs-icon", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](3, "div", 3)(4, "div")(5, "div", 4)(6, "div", 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵi18n"](7, 6);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](8, "div", 7);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵi18n"](9, 8);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](10, "div", 9)(11, "div", 10);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtemplate"](12, SelectTokenPanelPage_button_12_Template, 3, 3, "button", 11);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtemplate"](13, SelectTokenPanelPage_Conditional_13_Template, 2, 1, "div", 12);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](14, "div", 13);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵi18n"](15, 14);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtemplate"](16, SelectTokenPanelPage_ng_container_16_Template, 3, 3, "ng-container", 15);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtemplate"](17, SelectTokenPanelPage_ng_template_17_Template, 2, 4, "ng-template", null, 16, _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtemplateRefExtractor"])(19, SelectTokenPanelPage_ng_template_19_Template, 3, 0, "ng-template", null, 17, _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtemplateRefExtractor"]);
    }
    if (rf & 2) {
      const _r4 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵreference"](18);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("hideBackButton", true)("contentClass", "!px-0")("contentBackground", "white")("titleClass", "!text-title-10")("headerClass", "pt-2.5 text-lg font-extrabold")("contentSafeArea", true);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](11);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵclassMap"](ctx.foldChain ? "h-11 overflow-hidden" : "");
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("ngForOf", ctx.showChainList);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵconditional"](13, ctx.showFoldBtn ? 13 : -1);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("ngIf", ctx.showAssetList.length)("ngIfElse", _r4);
    }
  },
  dependencies: [_components_swap_token_chain_icon_swap_token_chain_icon_component__WEBPACK_IMPORTED_MODULE_10__.SwapTokenChainIconComponent, _modules_page_module__WEBPACK_IMPORTED_MODULE_2__.CommonPageModule, _angular_common__WEBPACK_IMPORTED_MODULE_15__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_15__.NgIf, _angular_common__WEBPACK_IMPORTED_MODULE_15__.NgStyle, _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_11__.CommonPageComponent, _icon_icon_component__WEBPACK_IMPORTED_MODULE_12__.IconComponent, _libs_bnf_pipes_amountFixed_amount_fixed_pipe__WEBPACK_IMPORTED_MODULE_13__.AmountFixedPipe, _components_token_with_chain_icon_token_with_chain_icon_component__WEBPACK_IMPORTED_MODULE_1__.TokenWithnChainIconComponent],
  styles: ["/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsInNvdXJjZVJvb3QiOiIifQ== */"],
  data: {
    animation: [_bnqkl_framework_animations__WEBPACK_IMPORTED_MODULE_6__.listFadeRightTrigger, _bnqkl_framework_animations__WEBPACK_IMPORTED_MODULE_6__.listFadeInRightTrigger, _bnqkl_framework_animations__WEBPACK_IMPORTED_MODULE_6__.listFadeOutLeftTrigger, _bnqkl_framework_animations__WEBPACK_IMPORTED_MODULE_6__.fadeInLeftTrigger]
  },
  changeDetection: 0
});
(0,tslib__WEBPACK_IMPORTED_MODULE_16__.__decorate)([SelectTokenPanelPage.OnReady(), (0,tslib__WEBPACK_IMPORTED_MODULE_16__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_16__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_16__.__metadata)("design:returntype", void 0)], SelectTokenPanelPage.prototype, "initData", null);
(0,tslib__WEBPACK_IMPORTED_MODULE_16__.__decorate)([SelectTokenPanelPage.OnDestroy(), (0,tslib__WEBPACK_IMPORTED_MODULE_16__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_16__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_16__.__metadata)("design:returntype", void 0)], SelectTokenPanelPage.prototype, "unsubscribe", null);
(0,tslib__WEBPACK_IMPORTED_MODULE_16__.__decorate)([SelectTokenPanelPage.States(1), (0,tslib__WEBPACK_IMPORTED_MODULE_16__.__metadata)("design:type", Array)], SelectTokenPanelPage.prototype, "liquidityPoolAssetsInfo", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_16__.__decorate)([SelectTokenPanelPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_16__.__metadata)("design:type", Object)], SelectTokenPanelPage.prototype, "updating", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_16__.__decorate)([SelectTokenPanelPage.States(1), (0,tslib__WEBPACK_IMPORTED_MODULE_16__.__metadata)("design:type", Array)], SelectTokenPanelPage.prototype, "chainGroupInfo", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_16__.__decorate)([SelectTokenPanelPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_16__.__metadata)("design:type", String)], SelectTokenPanelPage.prototype, "selectedChainName", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_16__.__decorate)([SelectTokenPanelPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_16__.__metadata)("design:type", Object)], SelectTokenPanelPage.prototype, "foldChain", void 0);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SelectTokenPanelPage);

/***/ }),

/***/ 16963:
/*!************************************************************************************!*\
  !*** ./apps/bfswap/src/components/select-token-panel/select-token-panel.helper.ts ***!
  \************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   assetListFilter: () => (/* binding */ assetListFilter)
/* harmony export */ });
/* harmony import */ var _bnqkl_framework_helpers__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @bnqkl/framework/helpers */ 12169);

/**
 * 列表计算缓存器
 * 因为要根据不同的条件对列表进行过筛，所以这里提供了一套基于元数据与条件信息的缓存
 */
const assetListFilter = (0,_bnqkl_framework_helpers__WEBPACK_IMPORTED_MODULE_0__.$memoize)((assetList, includeOptions, excludeOptions) => assetList.filter(item => {
  return hasIncludeOptions(item, includeOptions) && hasExcludeOptions(item, excludeOptions);
}), (assetList, chain) => (0,_bnqkl_framework_helpers__WEBPACK_IMPORTED_MODULE_0__.$tuple)([assetList.valueOf(), chain]));
assetListFilter.cache = new WeakMap();
/** 过滤include */
const hasIncludeOptions = (item, includeOptions) => {
  if (includeOptions.chain) {
    if (includeOptions.tokenName) {
      return item.chainName === includeOptions.chain && item.tokenName === includeOptions.tokenName;
    } else {
      return item.chainName === includeOptions.chain;
    }
  } else {
    if (includeOptions.tokenName) {
      return item.tokenName === includeOptions.tokenName;
    } else {
      return true;
    }
  }
};
/** 过滤exclude */
const hasExcludeOptions = (item, excludeOptions) => {
  if (excludeOptions.chain) {
    if (excludeOptions.tokenName) {
      return item.chainName !== excludeOptions.chain && item.tokenName !== excludeOptions.tokenName;
    } else {
      return item.chainName !== excludeOptions.chain;
    }
  } else {
    if (excludeOptions.tokenName) {
      return item.tokenName !== excludeOptions.tokenName;
    } else {
      return true;
    }
  }
};

/***/ }),

/***/ 47082:
/*!**********************************************************************************!*\
  !*** ./apps/bfswap/src/components/select-token-panel/select-token-panel.type.ts ***!
  \**********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);


/***/ })

}]);
//# sourceMappingURL=default-apps_bfswap_src_components_select-token-panel_select-token-panel_component_ts.js.map