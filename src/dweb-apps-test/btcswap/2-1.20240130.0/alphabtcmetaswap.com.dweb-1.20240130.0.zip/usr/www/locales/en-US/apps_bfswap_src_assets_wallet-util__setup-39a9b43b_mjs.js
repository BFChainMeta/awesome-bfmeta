"use strict";
(self["webpackChunkbfswap"] = self["webpackChunkbfswap"] || []).push([["apps_bfswap_src_assets_wallet-util__setup-39a9b43b_mjs"],{

/***/ 78225:
/*!****************************************************************!*\
  !*** ./apps/bfswap/src/assets/wallet-util/_setup-39a9b43b.mjs ***!
  \****************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   prepareBip32: () => (/* binding */ m)
/* harmony export */ });
/* harmony import */ var D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 52542);
/* harmony import */ var _ripemd160_fdc485e7_mjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./ripemd160-fdc485e7.mjs */ 10918);
/* harmony import */ var _sha256_d88873b6_mjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./sha256-d88873b6.mjs */ 98080);
/* harmony import */ var _sha512_7b87e5c4_mjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./sha512-7b87e5c4.mjs */ 15574);
/* harmony import */ var _WASMInterface_4e8d37b8_mjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./WASMInterface-4e8d37b8.mjs */ 18047);
/* harmony import */ var _index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./index-d96f2042.mjs */ 99449);






const m = /*#__PURE__*/function () {
  var _ref = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
    yield _ripemd160_fdc485e7_mjs__WEBPACK_IMPORTED_MODULE_1__.p.prepare(), yield _sha256_d88873b6_mjs__WEBPACK_IMPORTED_MODULE_2__.p.prepare(), yield _sha512_7b87e5c4_mjs__WEBPACK_IMPORTED_MODULE_3__.p.prepare();
  });
  return function m() {
    return _ref.apply(this, arguments);
  };
}();


/***/ })

}]);
//# sourceMappingURL=apps_bfswap_src_assets_wallet-util__setup-39a9b43b_mjs.js.map