"use strict";
(self["webpackChunkbfswap"] = self["webpackChunkbfswap"] || []).push([["apps_bfswap_src_components_token-with-chain-icon_token-with-chain-icon_component_ts-apps_bfsw-a24061"],{

/***/ 11342:
/*!*********************************************************************************************!*\
  !*** ./apps/bfswap/src/components/token-with-chain-icon/token-with-chain-icon.component.ts ***!
  \*********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   TokenWithnChainIconComponent: () => (/* binding */ TokenWithnChainIconComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! tslib */ 90505);
/* harmony import */ var _bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @bnqkl/bnqkl-swap-core */ 70195);
/* harmony import */ var _services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ~services/wallet/wallet.helper */ 84813);
/* harmony import */ var _modules_comp_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ~modules/comp.module */ 58281);
/* harmony import */ var _modules_page_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ~modules/page.module */ 16381);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 61039);
/* harmony import */ var _icon_icon_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../icon/icon.component */ 18840);
var _class;







function TokenWithnChainIconComponent_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](1, "bs-icon", 1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵstyleMap"](ctx_r0.sizeClass.chainTranslate);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵstyleMap"](ctx_r0.sizeClass.chainSize);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("name", ctx_r0.chainName);
  }
}
/** Token和chain组合图标 */
class TokenWithnChainIconComponent extends _modules_comp_module__WEBPACK_IMPORTED_MODULE_2__.CommonCompBase {
  constructor() {
    super(...arguments);
    /** token的大小 */
    this.tokenSize = 'icon-8';
    /** chain的大小 */
    this.chainSize = 'icon-4';
    /** 尺寸默认32 */
    this.size = 0;
    /** 尺寸样式 */
    this.sizeClass = {
      chainSize: 'font-size:1rem',
      coinSize: 'font-size:2rem',
      chainTranslate: 'transform: translate(6px,8px)'
    };
  }
  /** 初始化参数 */
  init() {
    this.handleIcon();
    this.handleSize();
  }
  /** 处理尺寸 */
  handleSize() {
    const {
      size
    } = this;
    if (size > 0) {
      const CHAINSIZE = 16;
      const COINSIZE = 32;
      const TRANSLATEX = 6;
      const TRANSLATEY = 8;
      const times = size / COINSIZE;
      this.sizeClass.chainSize = `font-size:${CHAINSIZE * times}px`;
      this.sizeClass.coinSize = `font-size:${COINSIZE * times}px`;
      this.sizeClass.chainTranslate = `transform: translate(${TRANSLATEX * times}px,${TRANSLATEY * times}px)`;
    }
  }
  /** 处理图标名称 */
  handleIcon() {
    const {
      swapChainName,
      swapCoinName
    } = this;
    if (swapChainName) {
      const chainName = swapChainName in _bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_0__.BNQKL_SWAP_CHAIN_NAME ? _services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_1__.NODE_CHAIN_NAME_TRANSFER[swapChainName] : swapChainName;
      const chainIcon = (0,_services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_1__.transferToChainIcon)(chainName);
      this.chainName = chainIcon;
      if (swapCoinName) {
        const coinIcon = (0,_services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_1__.transferToTokenIconBychainName)(chainName, swapCoinName);
        this.tokenName = coinIcon;
      }
    }
  }
}
_class = TokenWithnChainIconComponent;
_class.ɵfac = /*@__PURE__*/(() => {
  let ɵTokenWithnChainIconComponent_BaseFactory;
  return function TokenWithnChainIconComponent_Factory(t) {
    return (ɵTokenWithnChainIconComponent_BaseFactory || (ɵTokenWithnChainIconComponent_BaseFactory = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵgetInheritedFactory"](_class)))(t || _class);
  };
})();
_class.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineComponent"]({
  type: _class,
  selectors: [["bs-token-with-chain-icon"]],
  inputs: {
    tokenSize: "tokenSize",
    tokenName: "tokenName",
    chainSize: "chainSize",
    chainName: "chainName",
    size: "size",
    swapChainName: "swapChainName",
    swapCoinName: "swapCoinName"
  },
  standalone: true,
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵInheritDefinitionFeature"], _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵStandaloneFeature"]],
  decls: 3,
  vars: 4,
  consts: [[1, "relative", "flex", "items-center", "justify-center"], [3, "name"], ["class", "bg-blue-10 rounded-1 absolute bottom-0 right-0 flex  items-center justify-center border-[2px] border-white", 3, "style"], [1, "bg-blue-10", "rounded-1", "absolute", "bottom-0", "right-0", "flex", "items-center", "justify-center", "border-[2px]", "border-white"]],
  template: function TokenWithnChainIconComponent_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 0);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](1, "bs-icon", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](2, TokenWithnChainIconComponent_Conditional_2_Template, 2, 5, "div", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵstyleMap"](ctx.sizeClass.coinSize);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("name", ctx.tokenName);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵconditional"](2, ctx.chainName ? 2 : -1);
    }
  },
  dependencies: [_modules_page_module__WEBPACK_IMPORTED_MODULE_3__.CommonPageModule, _icon_icon_component__WEBPACK_IMPORTED_MODULE_4__.IconComponent],
  encapsulation: 2,
  changeDetection: 0
});
(0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([TokenWithnChainIconComponent.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__metadata)("design:type", Object)], TokenWithnChainIconComponent.prototype, "sizeClass", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([TokenWithnChainIconComponent.OnChanges(), (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__metadata)("design:returntype", void 0)], TokenWithnChainIconComponent.prototype, "init", null);

/***/ }),

/***/ 64875:
/*!******************************************************************!*\
  !*** ./apps/bfswap/src/pages/home/pages/market/market.helper.ts ***!
  \******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   transferPoolItemToMaketItem: () => (/* binding */ transferPoolItemToMaketItem),
/* harmony export */   transferPoolListToMaketList: () => (/* binding */ transferPoolListToMaketList)
/* harmony export */ });
/* harmony import */ var _services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ~services/wallet/wallet.helper */ 84813);
/* harmony import */ var bignumber_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! bignumber.js */ 61994);
/* harmony import */ var _bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @bnqkl/bnqkl-swap-core */ 70195);




/** pool list 转 market list */
const transferPoolListToMaketList = poolList => {
  const result = [];
  poolList.forEach(poolItem => {
    const item = transferPoolItemToMaketItem(poolItem);
    if (item) {
      result.push(item);
    } else {
      return;
    }
  });
  return result;
};
/** pool item => market item */
const transferPoolItemToMaketItem = poolItem => {
  if (new bignumber_js__WEBPACK_IMPORTED_MODULE_1__["default"](poolItem.anchorCoinsAmount).comparedTo(0) && new bignumber_js__WEBPACK_IMPORTED_MODULE_1__["default"](poolItem.quoteCoinsAmount).comparedTo(0)) {
    var _fluctuationBN, _fluctuationBN2;
    // 两个都是U的池子排除
    if (poolItem.anchorCoinsName === _bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_2__.BNQKL_SWAP_COIN_NAME.USDM && poolItem.quoteCoinsName === _bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_2__.BNQKL_SWAP_COIN_NAME.USDM) {
      return;
    }
    let fluctuationBN;
    if (poolItem.fluctuationRange !== '--') {
      fluctuationBN = new bignumber_js__WEBPACK_IMPORTED_MODULE_1__["default"](poolItem.fluctuationRange || '0').multipliedBy(100);
    }
    let fluctuation;
    if (fluctuationBN) {
      if (fluctuationBN.comparedTo('0.01') === 1) {
        // 截取
        fluctuation = fluctuationBN.toFixed(2, bignumber_js__WEBPACK_IMPORTED_MODULE_1__["default"].ROUND_DOWN);
      } else {
        // 四舍五入
        fluctuation = fluctuationBN.toFixed(2);
      }
    } else {
      fluctuation = '--';
    }
    // 修正截取后0的负数情况
    if (fluctuation === '-0.00') {
      fluctuation = '0.00';
    }
    return {
      poolId: poolItem.poolId,
      coinName: poolItem.anchorCoinsName,
      chainName: _services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_0__.NODE_CHAIN_NAME_TRANSFER[poolItem.anchorCoinsChainName],
      amount: poolItem.anchorCoinsAmount,
      /** 报价货币 */
      quoteCoinName: poolItem.quoteCoinsName,
      /** 报价所属链 */
      quotechainName: _services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_0__.NODE_CHAIN_NAME_TRANSFER[poolItem.quoteCoinsChainName],
      quoteAmount: poolItem.quoteCoinsAmount,
      // 如果fluctuationRange == '--',说明是从数据库中获取的数据或者是从其他页面进来的没有此字段的数据，为初始数据
      price: poolItem.fluctuationRange === '--' ? '--' : new bignumber_js__WEBPACK_IMPORTED_MODULE_1__["default"](poolItem.quoteCoinsAmount).div(new bignumber_js__WEBPACK_IMPORTED_MODULE_1__["default"](poolItem.anchorCoinsAmount)).toFixed(8, bignumber_js__WEBPACK_IMPORTED_MODULE_1__["default"].ROUND_DOWN),
      fluctuation,
      fluctuationNumber: ((_fluctuationBN = fluctuationBN) === null || _fluctuationBN === void 0 ? void 0 : _fluctuationBN.toNumber()) === undefined ? NaN : (_fluctuationBN2 = fluctuationBN) === null || _fluctuationBN2 === void 0 ? void 0 : _fluctuationBN2.toNumber(),
      quoteSymbol: poolItem.quoteCoinsName.slice(0, 1).toUpperCase(),
      updateTime: poolItem.updatedTime,
      tokenIcon: (0,_services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_0__.transferToTokenIcon)(poolItem.anchorCoinsChainName, poolItem.anchorCoinsName),
      chainIcon: (0,_services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_0__.transferToChainIcon)(_services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_0__.NODE_CHAIN_NAME_TRANSFER[poolItem.anchorCoinsChainName] || 'Default'),
      quoteTokenIcon: (0,_services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_0__.transferToTokenIcon)(poolItem.quoteCoinsChainName, poolItem.quoteCoinsName),
      quoteChainIcon: (0,_services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_0__.transferToChainIcon)(_services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_0__.NODE_CHAIN_NAME_TRANSFER[poolItem.quoteCoinsChainName] || 'Default'),
      anchorVolume: poolItem.anchorVolume,
      quoteVolume: poolItem.quoteVolume
    };
  } else {
    return;
  }
};

/***/ }),

/***/ 30063:
/*!******************************************************!*\
  !*** ./apps/bfswap/src/pages/mine/mine.component.ts ***!
  \******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   MinePage: () => (/* binding */ MinePage),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 52542);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! tslib */ 90505);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/common */ 6729);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/core */ 61039);
/* harmony import */ var _modules_page_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ~modules/page.module */ 16381);
/* harmony import */ var _services_wallet_wallet_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ~services/wallet/wallet.service */ 54275);
/* harmony import */ var _bnqkl_framework_directives__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @bnqkl/framework/directives */ 11100);
/* harmony import */ var _bnqkl_framework_helpers__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @bnqkl/framework/helpers */ 12169);
/* harmony import */ var _bnqkl_framework_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @bnqkl/framework/core */ 63563);
/* harmony import */ var _pages_my_assets_my_assets_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./pages/my-assets/my-assets.component */ 59920);
/* harmony import */ var _pages_my_liquidity_holdings_my_liquidity_holdings_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./pages/my-liquidity-holdings/my-liquidity-holdings.component */ 23627);
/* harmony import */ var _libs_bnf_directives_ob_size_directive__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../../../libs/bnf/directives/ob-size.directive */ 46501);
/* harmony import */ var _libs_bnf_directives_tab_directive__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../../../../libs/bnf/directives/tab.directive */ 384);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/router */ 56776);
/* harmony import */ var _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../../../../libs/bnf/modules/page/common-page/common-page.component */ 62052);
/* harmony import */ var _components_icon_icon_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../components/icon/icon.component */ 18840);

var _class;

















const _c0 = ["navSize"];
const _c1 = ["panel"];
const _c2 = ["linkContainer"];
function MinePage_ng_container_12_Template(rf, ctx) {
  if (rf & 1) {
    const _r7 = _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](1, "button", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵlistener"]("click", function MinePage_ng_container_12_Template_button_click_1_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵrestoreView"](_r7);
      const i_r5 = restoredCtx.index;
      const ctx_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵresetView"](ctx_r6.selectTab(i_r5));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](2, "span", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const link_r4 = ctx.$implicit;
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("ngClass", ((ctx_r1.currLink == null ? null : ctx_r1.currLink.index) || 0) === link_r4.index ? "text-primary" : "text-base-200");
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtextInterpolate"](link_r4.label_text);
  }
}
function MinePage_div_17_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelement"](0, "div", 17, 18);
  }
}
const _c5 = a0 => ({
  "--index": a0
});
const _c6 = a0 => ({
  "--page-safe-area-inset-top": a0,
  "--page-safe-area-inset-bottom": 0
});
/** 我的页面 */
class MinePage extends (0,_bnqkl_framework_core__WEBPACK_IMPORTED_MODULE_5__.MixinBrowser)(_modules_page_module__WEBPACK_IMPORTED_MODULE_1__.CommonPageBase) {
  constructor() {
    super(...arguments);
    /** 减少日志, 如果需要, 补充 logger+=`w-tabs=enable`  */
    this.__console_internal_config__ = {
      default: 'warn',
      matchMode: 'strict'
    };
    /** 已连接的钱包服务 */
    this.walletService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_12__.inject)(_services_wallet_wallet_service__WEBPACK_IMPORTED_MODULE_2__.WalletService);
    /** 导航栏的高度 */
    this.navHeight = '0px';
    /** 底部导航栏的高度 */
    this.bottomNavHeight = '0px';
    /** 所有的 tab 链接 */
    this.links = [{
      index: 0,
      href: 'assets',
      icon: 'assets',
      label_text: "Assets",
      component: _pages_my_assets_my_assets_component__WEBPACK_IMPORTED_MODULE_6__["default"],
      ref: undefined
    }, {
      index: 1,
      href: 'holdings',
      icon: 'holdings',
      label_text: "Positions",
      component: _pages_my_liquidity_holdings_my_liquidity_holdings_component__WEBPACK_IMPORTED_MODULE_7__["default"],
      ref: undefined
    }];
  }
  /** 监听导航栏的大小 */
  set navSize(obSize) {
    this.takeUntilDestroy(obSize.resized$).subscribe(size => {
      this.navHeight = size.borderHeight + 'px';
    });
  }
  initLink() {
    var _this = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      /// @TODO 根据URL来变更
      _this.currLink = _this.selectTab(0);
      /// 在有空的时候把各个页面初始化出来
      for (const link of _this.links) {
        yield (0,_bnqkl_framework_helpers__WEBPACK_IMPORTED_MODULE_4__.$requestIdleCallback)();
        _this._initLinkRef(link);
      }
    })();
  }
  /**
   * 切换 tab
   */
  selectTab(index) {
    var _this2 = this;
    const linkContainer = this.linkContainerList.get(index);
    if (linkContainer === undefined) {
      return;
    }
    const link = this.links[index];
    if (this.currLink !== link) {
      this.prevLink = this.currLink;
      this.currLink = link;
      this._initLinkRef(link, linkContainer);
      (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
        _this2.panelAnimationsStart();
        yield (0,_bnqkl_framework_helpers__WEBPACK_IMPORTED_MODULE_4__.$requestAnimationFrame)();
        _this2.panelAnimationsDone();
      })();
    }
    return link;
  }
  /** 初始化页面实例 */
  _initLinkRef(link, linkContainer = this.linkContainerList.get(this.links.indexOf(link))) {
    if (link.ref === undefined && link.component !== undefined) {
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      link.ref = this._panelVcRef.createComponent(link.component);
      if (link.ref.instance instanceof _pages_my_assets_my_assets_component__WEBPACK_IMPORTED_MODULE_6__["default"]) {
        link.ref.instance.supportChainList = this.resolveData.supportChainList;
      }
      this.renderer2.appendChild(linkContainer === null || linkContainer === void 0 ? void 0 : linkContainer.nativeElement, link.ref.location.nativeElement);
      link.ref.instance.requestUpdate();
      this.cdRef.detectChanges();
    }
  }
  /** 监听tab-panel动画开始 */
  panelAnimationsStart() {
    var _this$currLink;
    this.console.info('animation start');
    const page = (_this$currLink = this.currLink) === null || _this$currLink === void 0 || (_this$currLink = _this$currLink.ref) === null || _this$currLink === void 0 ? void 0 : _this$currLink.instance;
    // const prePage = this.prevLink?.ref?.instance;
    // page?.ngPageWillEnter();
    page === null || page === void 0 || page.ngOnResume('mine-tab');
    // prePage?.ngPageWillLeave();
  }
  /** 监听tab-panel动画结束 */
  panelAnimationsDone() {
    var _this$currLink2, _page$pageTheme$, _this$prevLink;
    this.console.info('animation done');
    /// 跟随子页面的风格
    const page = (_this$currLink2 = this.currLink) === null || _this$currLink2 === void 0 || (_this$currLink2 = _this$currLink2.ref) === null || _this$currLink2 === void 0 ? void 0 : _this$currLink2.instance;
    const pageTheme = page === null || page === void 0 || (_page$pageTheme$ = page.pageTheme$) === null || _page$pageTheme$ === void 0 ? void 0 : _page$pageTheme$.value;
    if (pageTheme !== undefined) {
      var _this$pageTheme$;
      (_this$pageTheme$ = this.pageTheme$) === null || _this$pageTheme$ === void 0 || _this$pageTheme$.next(pageTheme);
    }
    // page?.ngPageDidEnter();
    const prePage = (_this$prevLink = this.prevLink) === null || _this$prevLink === void 0 || (_this$prevLink = _this$prevLink.ref) === null || _this$prevLink === void 0 ? void 0 : _this$prevLink.instance;
    // prePage?.ngPageDidLeave();
    prePage === null || prePage === void 0 || prePage.ngOnPause('mine-tab');
  }
  /** 将页面的生命周期向内传递给tab-panel的页面 */
  ngOnPause(reason) {
    var _this$currLink3;
    super.ngOnPause(reason);
    (_this$currLink3 = this.currLink) === null || _this$currLink3 === void 0 || (_this$currLink3 = _this$currLink3.ref) === null || _this$currLink3 === void 0 || (_this$currLink3 = _this$currLink3.instance) === null || _this$currLink3 === void 0 || _this$currLink3.ngOnPause(reason);
  }
  /** 将页面的生命周期向内传递给tab-panel的页面 */
  ngOnResume(reason) {
    var _this$currLink4;
    super.ngOnResume(reason);
    (_this$currLink4 = this.currLink) === null || _this$currLink4 === void 0 || (_this$currLink4 = _this$currLink4.ref) === null || _this$currLink4 === void 0 || (_this$currLink4 = _this$currLink4.instance) === null || _this$currLink4 === void 0 || _this$currLink4.ngOnResume(reason);
  }
  /** 初始化钱包 */
  dataInit() {
    var _this$walletService$c;
    this.connectedWalletName = (_this$walletService$c = this.walletService.connectedWallet) === null || _this$walletService$c === void 0 ? void 0 : _this$walletService$c.walletName;
  }
}
_class = MinePage;
_class.ɵfac = /*@__PURE__*/(() => {
  let ɵMinePage_BaseFactory;
  return function MinePage_Factory(t) {
    return (ɵMinePage_BaseFactory || (ɵMinePage_BaseFactory = _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵgetInheritedFactory"](_class)))(t || _class);
  };
})();
_class.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵdefineComponent"]({
  type: _class,
  selectors: [["bs-mine-page"]],
  viewQuery: function MinePage_Query(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵviewQuery"](_c0, 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵviewQuery"](_c1, 5, _angular_core__WEBPACK_IMPORTED_MODULE_12__.ViewContainerRef);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵviewQuery"](_c2, 5, _angular_core__WEBPACK_IMPORTED_MODULE_12__.ElementRef);
    }
    if (rf & 2) {
      let _t;
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵloadQuery"]()) && (ctx.navSize = _t.first);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵloadQuery"]()) && (ctx._panelVcRef = _t.first);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵloadQuery"]()) && (ctx.linkContainerList = _t);
    }
  },
  standalone: true,
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵInheritDefinitionFeature"], _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵStandaloneFeature"]],
  decls: 18,
  vars: 11,
  consts: () => {
    let i18n_3;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_RECORD$$APPS_BFSWAP_SRC_PAGES_MINE_MINE_COMPONENT_TS_4 = goog.getMsg("{$startTagBsIcon}{$closeTagBsIcon} Record ", {
        "closeTagBsIcon": "\uFFFD/#3\uFFFD",
        "startTagBsIcon": "\uFFFD#3\uFFFD"
      }, {
        original_code: {
          "closeTagBsIcon": "</bs-icon>",
          "startTagBsIcon": "<bs-icon class=\"mr-1 text-2xl\" name=\"icon-navigation-bar-history\">"
        }
      });
      i18n_3 = MSG_EXTERNAL_RECORD$$APPS_BFSWAP_SRC_PAGES_MINE_MINE_COMPONENT_TS_4;
    } else {
      i18n_3 = "" + "\uFFFD#3\uFFFD" + "" + "\uFFFD/#3\uFFFD" + " Record ";
    }
    return [["endMenu", "", 1, "duibs-btn", "duibs-btn-ghost", "border-1", "duibs-btn-xs", "border-base-600", "text-base-600", "absolute", "right-0", "!flex", "h-8", "!flex-nowrap", "whitespace-nowrap", "rounded-full", "border-solid", "text-sm", "normal-case", 3, "routerLink"], i18n_3, ["name", "icon-navigation-bar-history", 1, "mr-1", "text-2xl"], ["headerTitle", "", 3, "click"], [1, "duibs-avatar"], ["name", "icon-wallet-user", 1, "text-4xl"], [1, "duibs-avatar", "z-10", "h-5"], ["name", "icon-record-details-arrow-exchangerate", 1, "absolute", "-bottom-1", "-right-1", "text-xl"], ["wObSize", "", 1, "grid-in-[tabs]", "relative", "z-[2]", "flex", "items-center", "justify-between", "bg-white"], ["navSize", "obSize"], [4, "ngFor", "ngForOf"], [1, "_subscript", 3, "ngStyle"], ["wTabGroup", "", 1, "grid-in-[tabs/tabs/panel/panel]", "z-[1]", "grid", "flex-grow", "grid-flow-col", "overflow-x-hidden", 3, "ngStyle", "selectedIndex", "scrollSmooth", "selectedIndexChange$"], ["panel", ""], ["class", "w-cqw-100 block h-full overflow-hidden", "wTab", "", 4, "ngFor", "ngForOf"], [1, "duibs-btn", "duibs-btn-link", "flex", "w-1/2", "flex-col", "items-center", "justify-center", "!no-underline", 3, "click"], [1, "text-sm", "normal-case", 3, "ngClass"], ["wTab", "", 1, "w-cqw-100", "block", "h-full", "overflow-hidden"], ["linkContainer", ""]];
  },
  template: function MinePage_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](0, "common-page")(1, "button", 0);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵi18nStart"](2, 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelement"](3, "bs-icon", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵi18nEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](4, "div", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵlistener"]("click", function MinePage_Template_div_click_4_listener() {
        return ctx.nav.routeTo("mine/my-wallet-settings");
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](5, "div", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelement"](6, "bs-icon", 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](7, "div", 6);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelement"](8, "bs-icon", 7);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](9, "section")(10, "nav", 8, 9);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtemplate"](12, MinePage_ng_container_12_Template, 4, 2, "ng-container", 10);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelement"](13, "div", 11);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](14, "main", 12);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵlistener"]("selectedIndexChange$", function MinePage_Template_main_selectedIndexChange__14_listener($event) {
        return ctx.selectTab($event);
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementContainer"](15, null, 13);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtemplate"](17, MinePage_div_17_Template, 2, 0, "div", 14);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]()()();
    }
    if (rf & 2) {
      let tmp_4_0;
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("routerLink", "/mine/my-record");
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](11);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("ngForOf", ctx.links);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("ngStyle", _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵpureFunction1"](7, _c5, (ctx.currLink == null ? null : ctx.currLink.index) || 0));
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("ngStyle", _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵpureFunction1"](9, _c6, ctx.navHeight))("selectedIndex", (tmp_4_0 = ctx.currLink == null ? null : ctx.currLink.index) !== null && tmp_4_0 !== undefined ? tmp_4_0 : 0)("scrollSmooth", true);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("ngForOf", ctx.links);
    }
  },
  dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_13__.CommonModule, _angular_common__WEBPACK_IMPORTED_MODULE_13__.NgClass, _angular_common__WEBPACK_IMPORTED_MODULE_13__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_13__.NgStyle, _modules_page_module__WEBPACK_IMPORTED_MODULE_1__.CommonPageModule, _libs_bnf_directives_ob_size_directive__WEBPACK_IMPORTED_MODULE_8__.ObSizeDirective, _libs_bnf_directives_tab_directive__WEBPACK_IMPORTED_MODULE_9__.TabGroupDirective, _libs_bnf_directives_tab_directive__WEBPACK_IMPORTED_MODULE_9__.TabDirective, _angular_router__WEBPACK_IMPORTED_MODULE_14__.RouterLink, _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_10__.CommonPageComponent, _components_icon_icon_component__WEBPACK_IMPORTED_MODULE_11__.IconComponent],
  styles: ["@charset \"UTF-8\";\n[_nghost-%COMP%]   ._subscript[_ngcontent-%COMP%]{\n  position: absolute;\n  --tw-bg-opacity: 1;\n  background-color: rgb(100 15 243 / var(--tw-bg-opacity));\n  height: 2px;\n  width: 1.25rem;\n  border-radius: 1px;\n  bottom: 0.5rem;\n  --index: 0;\n  left: calc(var(--index) * 50% + 25% - 0.625rem);\n  transition-duration: 200ms;\n  transition-timing-function: ease-out;\n}\n[_nghost-%COMP%]   section[_ngcontent-%COMP%] {\n  width: 100%;\n  height: 100%;\n  display: grid;\n  \n\n\n\n\n  grid: auto 1fr/1fr;\n  grid-template-areas: \"tabs\" \"panel\";\n}\n[_nghost-%COMP%]   section[_ngcontent-%COMP%]   ._active-border[_ngcontent-%COMP%]{\n  position: absolute;\n  left: 50%;\n  top: 50%;\n  height: 3rem;\n  width: 3rem;\n  transform-origin: center;\n  border-radius: 9999px;\n  border-width: 1px;\n  border-style: solid;\n  border-color: rgb(255 255 255 / 0.5);\n  transform: translate(-50%, -50%);\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL2FwcHMvYmZzd2FwL3NyYy9wYWdlcy9taW5lL21pbmUuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsZ0JBQWdCO0FBRVo7RUFBQSxrQkFBQTtFQUFBLGtCQUFBO0VBQUEsd0RBQUE7RUFDQSxXQUFBO0VBQ0EsY0FBQTtFQUNBLGtCQUFBO0VBQ0EsY0FBQTtFQUNBLFVBQUE7RUFDQSwrQ0FBQTtFQUNBLDBCQUFBO0VBQ0E7QUFSQTtBQVdGO0VBQ0UsV0FBQTtFQUNBLFlBQUE7RUFDQSxhQUFBO0VBQ0E7OztRQUFBO0VBSUEsa0JBQUE7RUFDQSxtQ0FBQTtBQUFKO0FBR007RUFBQSxrQkFBQTtFQUFBLFNBQUE7RUFBQSxRQUFBO0VBQUEsWUFBQTtFQUFBLFdBQUE7RUFBQSx3QkFBQTtFQUFBLHFCQUFBO0VBQUEsaUJBQUE7RUFBQSxtQkFBQTtFQUFBLG9DQUFBO0VBQ0E7QUFEQSIsInNvdXJjZXNDb250ZW50IjpbIjpob3N0IHtcclxuICAuX3N1YnNjcmlwdCB7XHJcbiAgICBAYXBwbHkgYmctcHJpbWFyeSBhYnNvbHV0ZTtcclxuICAgIGhlaWdodDogMnB4O1xyXG4gICAgd2lkdGg6IDEuMjVyZW07XHJcbiAgICBib3JkZXItcmFkaXVzOiAxcHg7XHJcbiAgICBib3R0b206IDAuNXJlbTtcclxuICAgIC0taW5kZXg6IDA7XHJcbiAgICBsZWZ0OiBjYWxjKHZhcigtLWluZGV4KSAqIDUwJSArIDI1JSAtIDAuNjI1cmVtKTtcclxuICAgIHRyYW5zaXRpb24tZHVyYXRpb246IDIwMG1zO1xyXG4gICAgdHJhbnNpdGlvbi10aW1pbmctZnVuY3Rpb246IGVhc2Utb3V0O1xyXG4gIH1cclxuXHJcbiAgc2VjdGlvbiB7XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICAgIGhlaWdodDogMTAwJTtcclxuICAgIGRpc3BsYXk6IGdyaWQ7XHJcbiAgICAvKipcclxuICAgICAgICAgKiByb3dzIMOowqHCjMOpwqvCmCDDpsKcwonDpMK4wonDpMK4wqrDpcKMwrrDpcKfwp8gYXV0byAxZnJcclxuICAgICAgICAgKiBjb2x1bW5zIMOlwojCl8Olwq7CvSDDpsKcwonDpMK4woDDpMK4wqrDpcKMwrrDpcKfwp8gMWZyXHJcbiAgICAgICAgICovXHJcbiAgICBncmlkOiBhdXRvIDFmci8gMWZyO1xyXG4gICAgZ3JpZC10ZW1wbGF0ZS1hcmVhczogJ3RhYnMnICdwYW5lbCc7XHJcblxyXG4gICAgLl9hY3RpdmUtYm9yZGVyIHtcclxuICAgICAgQGFwcGx5IGFic29sdXRlIGxlZnQtMS8yIHRvcC0xLzIgaC0xMiB3LTEyIG9yaWdpbi1jZW50ZXIgcm91bmRlZC1mdWxsIGJvcmRlciBib3JkZXItc29saWQgYm9yZGVyLXdoaXRlLzUwO1xyXG4gICAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZSgtNTAlLCAtNTAlKTtcclxuICAgIH1cclxuICB9XHJcbn1cclxuIl0sInNvdXJjZVJvb3QiOiIifQ== */"],
  changeDetection: 0
});
(0,tslib__WEBPACK_IMPORTED_MODULE_15__.__decorate)([MinePage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_15__.__metadata)("design:type", Object)], MinePage.prototype, "navHeight", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_15__.__decorate)([MinePage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_15__.__metadata)("design:type", Object)], MinePage.prototype, "bottomNavHeight", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_15__.__decorate)([MinePage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_15__.__metadata)("design:type", Object)], MinePage.prototype, "currLink", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_15__.__decorate)([MinePage.AfterViewInit(), (0,tslib__WEBPACK_IMPORTED_MODULE_15__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_15__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_15__.__metadata)("design:returntype", Promise)], MinePage.prototype, "initLink", null);
(0,tslib__WEBPACK_IMPORTED_MODULE_15__.__decorate)([MinePage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_15__.__metadata)("design:type", Object)], MinePage.prototype, "connectedWalletName", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_15__.__decorate)([MinePage.OnReady(), (0,tslib__WEBPACK_IMPORTED_MODULE_15__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_15__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_15__.__metadata)("design:returntype", void 0)], MinePage.prototype, "dataInit", null);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MinePage);

/***/ })

}]);
//# sourceMappingURL=apps_bfswap_src_components_token-with-chain-icon_token-with-chain-icon_component_ts-apps_bfsw-a24061.js.map