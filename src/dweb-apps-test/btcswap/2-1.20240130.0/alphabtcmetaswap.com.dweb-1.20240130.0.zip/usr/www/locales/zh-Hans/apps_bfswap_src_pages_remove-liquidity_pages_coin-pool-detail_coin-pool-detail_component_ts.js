"use strict";
(self["webpackChunkbfswap"] = self["webpackChunkbfswap"] || []).push([["apps_bfswap_src_pages_remove-liquidity_pages_coin-pool-detail_coin-pool-detail_component_ts"],{

/***/ 11342:
/*!*********************************************************************************************!*\
  !*** ./apps/bfswap/src/components/token-with-chain-icon/token-with-chain-icon.component.ts ***!
  \*********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   TokenWithnChainIconComponent: () => (/* binding */ TokenWithnChainIconComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! tslib */ 90505);
/* harmony import */ var _bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @bnqkl/bnqkl-swap-core */ 70195);
/* harmony import */ var _services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ~services/wallet/wallet.helper */ 84813);
/* harmony import */ var _modules_comp_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ~modules/comp.module */ 58281);
/* harmony import */ var _modules_page_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ~modules/page.module */ 16381);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 61039);
/* harmony import */ var _icon_icon_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../icon/icon.component */ 18840);
var _class;







function TokenWithnChainIconComponent_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](1, "bs-icon", 1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵstyleMap"](ctx_r0.sizeClass.chainTranslate);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵstyleMap"](ctx_r0.sizeClass.chainSize);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("name", ctx_r0.chainName);
  }
}
/** Token和chain组合图标 */
class TokenWithnChainIconComponent extends _modules_comp_module__WEBPACK_IMPORTED_MODULE_2__.CommonCompBase {
  constructor() {
    super(...arguments);
    /** token的大小 */
    this.tokenSize = 'icon-8';
    /** chain的大小 */
    this.chainSize = 'icon-4';
    /** 尺寸默认32 */
    this.size = 0;
    /** 尺寸样式 */
    this.sizeClass = {
      chainSize: 'font-size:1rem',
      coinSize: 'font-size:2rem',
      chainTranslate: 'transform: translate(6px,8px)'
    };
  }
  /** 初始化参数 */
  init() {
    this.handleIcon();
    this.handleSize();
  }
  /** 处理尺寸 */
  handleSize() {
    const {
      size
    } = this;
    if (size > 0) {
      const CHAINSIZE = 16;
      const COINSIZE = 32;
      const TRANSLATEX = 6;
      const TRANSLATEY = 8;
      const times = size / COINSIZE;
      this.sizeClass.chainSize = `font-size:${CHAINSIZE * times}px`;
      this.sizeClass.coinSize = `font-size:${COINSIZE * times}px`;
      this.sizeClass.chainTranslate = `transform: translate(${TRANSLATEX * times}px,${TRANSLATEY * times}px)`;
    }
  }
  /** 处理图标名称 */
  handleIcon() {
    const {
      swapChainName,
      swapCoinName
    } = this;
    if (swapChainName) {
      const chainName = swapChainName in _bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_0__.BNQKL_SWAP_CHAIN_NAME ? _services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_1__.NODE_CHAIN_NAME_TRANSFER[swapChainName] : swapChainName;
      const chainIcon = (0,_services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_1__.transferToChainIcon)(chainName);
      this.chainName = chainIcon;
      if (swapCoinName) {
        const coinIcon = (0,_services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_1__.transferToTokenIconBychainName)(chainName, swapCoinName);
        this.tokenName = coinIcon;
      }
    }
  }
}
_class = TokenWithnChainIconComponent;
_class.ɵfac = /*@__PURE__*/(() => {
  let ɵTokenWithnChainIconComponent_BaseFactory;
  return function TokenWithnChainIconComponent_Factory(t) {
    return (ɵTokenWithnChainIconComponent_BaseFactory || (ɵTokenWithnChainIconComponent_BaseFactory = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵgetInheritedFactory"](_class)))(t || _class);
  };
})();
_class.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineComponent"]({
  type: _class,
  selectors: [["bs-token-with-chain-icon"]],
  inputs: {
    tokenSize: "tokenSize",
    tokenName: "tokenName",
    chainSize: "chainSize",
    chainName: "chainName",
    size: "size",
    swapChainName: "swapChainName",
    swapCoinName: "swapCoinName"
  },
  standalone: true,
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵInheritDefinitionFeature"], _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵStandaloneFeature"]],
  decls: 3,
  vars: 4,
  consts: [[1, "relative", "flex", "items-center", "justify-center"], [3, "name"], ["class", "bg-blue-10 rounded-1 absolute bottom-0 right-0 flex  items-center justify-center border-[2px] border-white", 3, "style"], [1, "bg-blue-10", "rounded-1", "absolute", "bottom-0", "right-0", "flex", "items-center", "justify-center", "border-[2px]", "border-white"]],
  template: function TokenWithnChainIconComponent_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 0);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](1, "bs-icon", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](2, TokenWithnChainIconComponent_Conditional_2_Template, 2, 5, "div", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵstyleMap"](ctx.sizeClass.coinSize);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("name", ctx.tokenName);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵconditional"](2, ctx.chainName ? 2 : -1);
    }
  },
  dependencies: [_modules_page_module__WEBPACK_IMPORTED_MODULE_3__.CommonPageModule, _icon_icon_component__WEBPACK_IMPORTED_MODULE_4__.IconComponent],
  encapsulation: 2,
  changeDetection: 0
});
(0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([TokenWithnChainIconComponent.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__metadata)("design:type", Object)], TokenWithnChainIconComponent.prototype, "sizeClass", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([TokenWithnChainIconComponent.OnChanges(), (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__metadata)("design:returntype", void 0)], TokenWithnChainIconComponent.prototype, "init", null);

/***/ }),

/***/ 63925:
/*!*****************************************************************************************************!*\
  !*** ./apps/bfswap/src/pages/remove-liquidity/pages/coin-pool-detail/coin-pool-detail.component.ts ***!
  \*****************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   CoinPoolDetailPage: () => (/* binding */ CoinPoolDetailPage),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 52542);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! tslib */ 90505);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @angular/common */ 6729);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/core */ 61039);
/* harmony import */ var _modules_page_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ~modules/page.module */ 16381);
/* harmony import */ var _services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ~services/wallet/wallet.helper */ 84813);
/* harmony import */ var _components_token_with_chain_icon_token_with_chain_icon_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ~components/token-with-chain-icon/token-with-chain-icon.component */ 11342);
/* harmony import */ var _services_wallet_wallet_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ~services/wallet/wallet.service */ 54275);
/* harmony import */ var _bnqkl_framework_pipes__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @bnqkl/framework/pipes */ 80909);
/* harmony import */ var _services_liquidity_pool_liquidity_pool_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ~services/liquidity-pool/liquidity-pool.service */ 20213);
/* harmony import */ var _coin_pool_detail_type__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./coin-pool-detail.type */ 13178);
/* harmony import */ var _services_liquidity_user_liquidity_user_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ~services/liquidity-user/liquidity-user.service */ 34913);
/* harmony import */ var _libs_bnf_components_pull_to_refresh_pull_to_refresh_directive__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../../../../../../libs/bnf/components/pull-to-refresh/pull-to-refresh.directive */ 97063);
/* harmony import */ var _libs_bnf_components_pull_to_refresh_pull_to_refresh_spinner_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../../../../../../libs/bnf/components/pull-to-refresh/pull-to-refresh-spinner.component */ 75387);
/* harmony import */ var _libs_bnf_components_infinite_scroll_infinite_scroll_directive__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../../../../../../libs/bnf/components/infinite-scroll/infinite-scroll.directive */ 10320);
/* harmony import */ var _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../../../../../../libs/bnf/modules/page/common-page/common-page.component */ 62052);
/* harmony import */ var _components_icon_icon_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../../../../components/icon/icon.component */ 18840);

var _class;


















function CoinPoolDetailPage_Conditional_37_For_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](0, "div", 28)(1, "div", 29);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵi18n"](2, 30);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](3, "div", 22)(4, "div", 31);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](6, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](7);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](8, "div", 32);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelement"](9, "bs-icon", 33);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](10, "div", 34);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](11);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipe"](12, "date");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipe"](13, "date");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const item_r3 = ctx.$implicit;
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtextInterpolate"](item_r3.lpCoinsAmount);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵclassMapInterpolate1"]("rounded-1 ", ctx_r2.lockStateStyle(item_r3.lockedStatus), " px-1.5 text-xs h-5 leading-5");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtextInterpolate1"](" ", ctx_r2.lockStatusText(item_r3.lockedStatus), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtextInterpolate2"](" ", item_r3.createdTime ? _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipeBind2"](12, 7, item_r3.createdTime, "yyyy.MM.dd HH:mm") : "- -", " - ", item_r3.unforzenTime ? _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipeBind2"](13, 10, item_r3.unforzenTime, "yyyy.MM.dd HH:mm") : "- -", " ");
  }
}
function CoinPoolDetailPage_Conditional_37_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵrepeaterCreate"](0, CoinPoolDetailPage_Conditional_37_For_1_Template, 14, 13, "div", 35, _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵrepeaterTrackByIdentity"]);
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵrepeater"](ctx_r0.addLiquidityRecordList.dataList);
  }
}
function CoinPoolDetailPage_Conditional_38_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](0, "div", 36);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelement"](1, "img", 37);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](2, "span", 38);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵi18n"](3, 39);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]()();
  }
}
/** 用户协议 */
class CoinPoolDetailPage extends _modules_page_module__WEBPACK_IMPORTED_MODULE_1__.CommonPageBase {
  constructor() {
    super(...arguments);
    /** 代币精确度 */
    this.DECIMALS = 8;
    /** 钱包服务 */
    this.walletService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_14__.inject)(_services_wallet_wallet_service__WEBPACK_IMPORTED_MODULE_4__.WalletService);
    /** 用户服务 */
    this.userService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_14__.inject)(_services_liquidity_user_liquidity_user_service__WEBPACK_IMPORTED_MODULE_8__.LiquidityUserService);
    /** 连接的钱包 */
    this.connectedWallet = this.walletService.connectedWallet;
    /** 锚定链名称 */
    this.anchorChainName = undefined;
    /** 报价链名称 */
    this.quoteChainName = undefined;
    /** 合约池服务 */
    this.poolService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_14__.inject)(_services_liquidity_pool_liquidity_pool_service__WEBPACK_IMPORTED_MODULE_6__.LiquidityPoolService);
    /** 固定增流记录 */
    // addLiquidityRecordList: BnqklSwap.User.UserLockedPositionDetails[] = [];
    this.addLiquidityRecordList = {
      dataList: [],
      maxIndex: 10000000000,
      minIndex: 0,
      pageSize: 5,
      hasMore: false,
      init: false
    };
    /** 当前登录的钱包用户地址 */
    this.userWalletAdress = undefined;
    /** 持有lp总量 */
    this.holdLpCoins = '0';
    /** 锁仓量 */
    this.lockedCoins = '0';
  }
  /** 初始化 */
  iniParams() {
    var _this = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const {
        params
      } = _this;
      if (params) {
        const {
          hold
        } = params;
        if (hold) {
          var _this$connectedWallet;
          const holdLiquidity = JSON.parse(hold);
          _this.console.info('持有合约池', holdLiquidity);
          _this.anchorTokenIcon = (0,_services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_2__.transferToTokenIcon)(holdLiquidity.anchorCoinsChainName, holdLiquidity.anchorCoinsName);
          _this.anchorChainIcon = (0,_services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_2__.transferToChainIcon)(_services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_2__.NODE_CHAIN_NAME_TRANSFER[holdLiquidity.anchorCoinsChainName] || 'Default');
          _this.quoteTokenIcon = (0,_services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_2__.transferToTokenIcon)(holdLiquidity.quoteCoinsChainName, holdLiquidity.quoteCoinsName);
          _this.quoteChainIcon = (0,_services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_2__.transferToChainIcon)(_services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_2__.NODE_CHAIN_NAME_TRANSFER[holdLiquidity.quoteCoinsChainName] || 'Default');
          _this.holdLiquidity = holdLiquidity;
          _this.anchorChainName = _services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_2__.NODE_CHAIN_NAME_TRANSFER[_this.holdLiquidity.anchorCoinsChainName];
          _this.quoteChainName = _services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_2__.NODE_CHAIN_NAME_TRANSFER[_this.holdLiquidity.quoteCoinsChainName];
          if ((_this$connectedWallet = _this.connectedWallet) !== null && _this$connectedWallet !== void 0 && _this$connectedWallet.pmchainAddress) {
            var _this$connectedWallet2;
            _this.userWalletAdress = (_this$connectedWallet2 = _this.connectedWallet) === null || _this$connectedWallet2 === void 0 ? void 0 : _this$connectedWallet2.pmchainAddress;
          }
          _this.getLockedList();
          // 获取锁定的coins
          yield _this.getLockedQuantity();
          // 获取用户持有总量
          yield _this.getUserHoldCoinAmount();
          // this.holdLpCoins = AmountFixedPipe.transform(<string>holdLiquidity.userLPCoinsAmount, this.DECIMALS);
        }
      }
    })();
  }
  /** 获取用户持有总量 */
  getUserHoldCoinAmount() {
    var _this2 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const {
        userWalletAdress,
        holdLiquidity
      } = _this2;
      if (userWalletAdress === undefined || holdLiquidity.poolId === undefined) {
        _this2.console.info('获取用户可用数量,无法获取参数', userWalletAdress, holdLiquidity.poolId);
        return;
      }
      const list = yield _this2.userService.getUserLiquidityHolding({
        userId: userWalletAdress
      });
      if (list) {
        const findItem = list.find(item => item.poolId === holdLiquidity.poolId);
        if (findItem) {
          _this2.console.log('获取用户可用数量', findItem.userLPCoinsAmount);
          _this2.holdLpCoins = _bnqkl_framework_pipes__WEBPACK_IMPORTED_MODULE_5__.AmountFixedPipe.transform(String(BigInt(findItem.userLPCoinsAmount)), _this2.DECIMALS);
        }
      }
    })();
  }
  /** 获取锁仓量 */
  getLockedQuantity() {
    var _this3 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const {
        userWalletAdress,
        holdLiquidity
      } = _this3;
      if (userWalletAdress === undefined || holdLiquidity.poolId === undefined) {
        _this3.console.info('获取锁仓量,无法获取参数', userWalletAdress, holdLiquidity.poolId);
        return;
      }
      const res = yield _this3.userService.getUserLiquidityLocked({
        poolId: holdLiquidity.poolId,
        userId: userWalletAdress
      });
      if (res) {
        const {
          frozenLpCoinsAmount
        } = res;
        _this3.console.info('持有锁仓量', frozenLpCoinsAmount);
        _this3.lockedCoins = _bnqkl_framework_pipes__WEBPACK_IMPORTED_MODULE_5__.AmountFixedPipe.transform(String(BigInt(frozenLpCoinsAmount)), _this3.DECIMALS);
        return frozenLpCoinsAmount;
      }
    })();
  }
  /** 获取锁仓量列表详情 UserLockedPositionDetails */
  getLockedList(loadMore = false) {
    var _this4 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const {
        userWalletAdress,
        holdLiquidity
      } = _this4;
      if (userWalletAdress === undefined || holdLiquidity.poolId === undefined) {
        return;
      }
      let maxIndex = _this4.addLiquidityRecordList.maxIndex;
      let minIndex = _this4.addLiquidityRecordList.minIndex;
      if (_this4.addLiquidityRecordList.init === true && _this4.addLiquidityRecordList.dataList.length) {
        const maxIndexObj = _this4.addLiquidityRecordList.dataList.reduce((min, obj) => obj.index < min.index ? obj : min);
        const minIndexObj = _this4.addLiquidityRecordList.dataList.reduce((max, obj) => obj.index > max.index ? obj : max);
        maxIndex = maxIndexObj.index - 1;
        minIndex = minIndexObj.index + 1;
      }
      const params = {
        poolId: holdLiquidity.poolId,
        userId: userWalletAdress,
        maxIndex: loadMore ? maxIndex : 10000000000,
        minIndex: loadMore ? 0 : minIndex,
        size: _this4.addLiquidityRecordList.pageSize
      };
      _this4.console.info('params', params);
      const res = yield _this4.userService.getUserLiquidityLockedList(params);
      if (res) {
        const {
          list
        } = res;
        const data = list.map(item => {
          return {
            ...item,
            lockedStatus: _this4.getLockStatus(item.createdTime, item.unforzenTime),
            lpCoinsAmount: _bnqkl_framework_pipes__WEBPACK_IMPORTED_MODULE_5__.AmountFixedPipe.transform(item.lpCoinsAmount, _this4.DECIMALS)
          };
        });
        _this4.addLiquidityRecordList.minIndex += 1;
        if (loadMore) {
          _this4.addLiquidityRecordList.dataList.push(...data);
        } else {
          _this4.addLiquidityRecordList.dataList.unshift(...data);
          // 重新计算是否锁定
          _this4.addLiquidityRecordList.dataList.forEach(item => {
            item.lockedStatus = _this4.getLockStatus(item.createdTime, item.unforzenTime);
          });
        }
        _this4.addLiquidityRecordList.hasMore = data.length === _this4.addLiquidityRecordList.pageSize;
        // this.addLiquidityRecordList.dataList.sort((a, b) => b.unforzenTime - a.unforzenTime);
        // 排序
        const currentTime = Date.now();
        const lessThenCurentTime = _this4.addLiquidityRecordList.dataList.filter(item => item.unforzenTime < currentTime);
        const greaterThanCurrentTime = _this4.addLiquidityRecordList.dataList.filter(item => item.unforzenTime >= currentTime);
        greaterThanCurrentTime.sort((a, b) => Math.abs(currentTime - a.unforzenTime) - Math.abs(currentTime - b.unforzenTime));
        _this4.addLiquidityRecordList.dataList = greaterThanCurrentTime.concat(lessThenCurentTime);
        _this4.addLiquidityRecordList.init = true;
        _this4.console.info('获取锁仓量列表', res, _this4.addLiquidityRecordList.hasMore);
      }
    })();
  }
  /** 获取锁定状态 */
  getLockStatus(createdTime, unforzenTime) {
    const currentTime = Date.now();
    if (currentTime > unforzenTime) {
      return _coin_pool_detail_type__WEBPACK_IMPORTED_MODULE_7__.$LOCKEDSTATUS.UNLOCKED;
    } else if (currentTime >= createdTime && currentTime <= unforzenTime) {
      const remainingTime = unforzenTime - currentTime;
      const daysRemaining = Math.ceil(remainingTime / (1000 * 60 * 60 * 24));
      if (daysRemaining <= 3) {
        return _coin_pool_detail_type__WEBPACK_IMPORTED_MODULE_7__.$LOCKEDSTATUS.LOCKING;
      } else {
        return _coin_pool_detail_type__WEBPACK_IMPORTED_MODULE_7__.$LOCKEDSTATUS.TO_UNLOCK;
      }
    } else {
      return undefined;
    }
  }
  lockStateStyle(lockedStatus) {
    if (lockedStatus === _coin_pool_detail_type__WEBPACK_IMPORTED_MODULE_7__.$LOCKEDSTATUS.UNLOCKED) {
      return 'text-subtitle bg-border-10';
    } else if (lockedStatus === _coin_pool_detail_type__WEBPACK_IMPORTED_MODULE_7__.$LOCKEDSTATUS.TO_UNLOCK) {
      return 'text-primary bg-bg-tip-6';
    } else if (lockedStatus === _coin_pool_detail_type__WEBPACK_IMPORTED_MODULE_7__.$LOCKEDSTATUS.LOCKING) {
      return 'text-green-20 bg-bg-tip-green-6';
    } else {
      return 'hidden';
    }
  }
  /** 获取锁定的文字 */
  lockStatusText(lockedStatus) {
    if (lockedStatus === _coin_pool_detail_type__WEBPACK_IMPORTED_MODULE_7__.$LOCKEDSTATUS.UNLOCKED) {
      return "\u5DF2\u89E3\u9501";
    } else if (lockedStatus === _coin_pool_detail_type__WEBPACK_IMPORTED_MODULE_7__.$LOCKEDSTATUS.TO_UNLOCK) {
      return "\u9501\u5B9A\u4E2D";
    } else if (lockedStatus === _coin_pool_detail_type__WEBPACK_IMPORTED_MODULE_7__.$LOCKEDSTATUS.LOCKING) {
      return "\u5373\u5C06\u89E3\u9501";
    } else {
      return '';
    }
  }
  /** 获得资产提示 */
  showAcceptedAddressTip() {
    var _this5 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      yield _this5.alert({
        headerTitle: '固定增流规则',
        segmentBodyMessage: ['【固定增流】：用户兑换成功时，将向交易池中增加一定比例流动性，并获得相关合约池权益，同时此增流部分将锁定一个月后方可移除。', '【固定增流比例】：当A兑换U，固定增流5%时，将使用5%A以及对应量的U用于增加流动性，所需的U从兑得量中扣除。'],
        buttonText: '好的'
      });
    })();
  }
  /** 下拉页面 */
  refreshList() {
    var _this6 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      // await new Promise(resolve => setTimeout(resolve, 3000))
      yield _this6.getLockedList();
      // 获取锁定的coins
      yield _this6.getLockedQuantity();
      // 获取用户可用数量 = 获取真实数据 - 冻结数量
      yield _this6.getUserHoldCoinAmount();
    })();
  }
  /** 加载更多 */
  loadMoreList() {
    var _this7 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      if (_this7.addLiquidityRecordList.init === false) {
        return;
      }
      _this7.console.info('加载更多');
      // await new Promise(resolve => setTimeout(resolve, 3000))
      // this.addLiquidityRecordList.hasMore = false
      yield _this7.getLockedList(true);
    })();
  }
}
_class = CoinPoolDetailPage;
_class.ɵfac = /*@__PURE__*/(() => {
  let ɵCoinPoolDetailPage_BaseFactory;
  return function CoinPoolDetailPage_Factory(t) {
    return (ɵCoinPoolDetailPage_BaseFactory || (ɵCoinPoolDetailPage_BaseFactory = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵgetInheritedFactory"](_class)))(t || _class);
  };
})();
_class.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵdefineComponent"]({
  type: _class,
  selectors: [["bs-coin-pool-detail"]],
  standalone: true,
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵInheritDefinitionFeature"], _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵStandaloneFeature"]],
  decls: 39,
  vars: 16,
  consts: () => {
    let i18n_0;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_TOTAL_AMOUNT_HELD$$APPS_BFSWAP_SRC_PAGES_REMOVE_LIQUIDITY_PAGES_COIN_POOL_DETAIL_COIN_POOL_DETAIL_COMPONENT_TS_1 = goog.getMsg("Total amount held");
      i18n_0 = MSG_EXTERNAL_TOTAL_AMOUNT_HELD$$APPS_BFSWAP_SRC_PAGES_REMOVE_LIQUIDITY_PAGES_COIN_POOL_DETAIL_COIN_POOL_DETAIL_COMPONENT_TS_1;
    } else {
      i18n_0 = "\u6301\u6709\u603B\u91CF";
    }
    let i18n_2;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_LOCKING_CAPACITY$$APPS_BFSWAP_SRC_PAGES_REMOVE_LIQUIDITY_PAGES_COIN_POOL_DETAIL_COIN_POOL_DETAIL_COMPONENT_TS_3 = goog.getMsg("locking capacity");
      i18n_2 = MSG_EXTERNAL_LOCKING_CAPACITY$$APPS_BFSWAP_SRC_PAGES_REMOVE_LIQUIDITY_PAGES_COIN_POOL_DETAIL_COIN_POOL_DETAIL_COMPONENT_TS_3;
    } else {
      i18n_2 = "\u9501\u4ED3\u91CF";
    }
    let i18n_4;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_FIXED_FLOW_INCREASE_RERCORD$$APPS_BFSWAP_SRC_PAGES_REMOVE_LIQUIDITY_PAGES_COIN_POOL_DETAIL_COIN_POOL_DETAIL_COMPONENT_TS_5 = goog.getMsg("Fixed flow increase rercord");
      i18n_4 = MSG_EXTERNAL_FIXED_FLOW_INCREASE_RERCORD$$APPS_BFSWAP_SRC_PAGES_REMOVE_LIQUIDITY_PAGES_COIN_POOL_DETAIL_COIN_POOL_DETAIL_COMPONENT_TS_5;
    } else {
      i18n_4 = "\u56FA\u5B9A\u589E\u6D41\u8BB0\u5F55";
    }
    let i18n_6;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_LOCKED_QUANTITY$$APPS_BFSWAP_SRC_PAGES_REMOVE_LIQUIDITY_PAGES_COIN_POOL_DETAIL_COIN_POOL_DETAIL_COMPONENT_TS___7 = goog.getMsg("locked quantity");
      i18n_6 = MSG_EXTERNAL_LOCKED_QUANTITY$$APPS_BFSWAP_SRC_PAGES_REMOVE_LIQUIDITY_PAGES_COIN_POOL_DETAIL_COIN_POOL_DETAIL_COMPONENT_TS___7;
    } else {
      i18n_6 = "\u9501\u5B9A\u6570\u91CF";
    }
    let i18n_8;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_NO_RECORDS$$APPS_BFSWAP_SRC_PAGES_REMOVE_LIQUIDITY_PAGES_COIN_POOL_DETAIL_COIN_POOL_DETAIL_COMPONENT_TS__9 = goog.getMsg("No records");
      i18n_8 = MSG_EXTERNAL_NO_RECORDS$$APPS_BFSWAP_SRC_PAGES_REMOVE_LIQUIDITY_PAGES_COIN_POOL_DETAIL_COIN_POOL_DETAIL_COMPONENT_TS__9;
    } else {
      i18n_8 = "\u6CA1\u8BB0\u5F55";
    }
    return [[3, "contentBackground", "headerBackground", "titleClass"], [1, "bginner", "h-100", "absolute", "-top-12", "left-0", "w-full"], [1, "relative", "h-full", "overflow-hidden"], ["wPullToRefresh", "", "wInfiniteScroll", "", 1, "relative", "z-10", "h-full", "overflow-y-scroll", 3, "hasMore", "emitDistance", "maxDistance", "pulled$", "infinited$"], [1, "text-subtext"], [1, "h-18", "px-13", "flex", "items-center", "justify-start"], [1, "flex", "items-center", "justify-start"], [1, "mr-1.5", 3, "tokenName", "chainName"], [1, "text-left"], [1, "text-tital-10", "text-base", "font-semibold"], [1, "text-base-200", "text-xs"], [1, "bg-text-input", "mx-3", "h-8", "w-[1px]"], [1, "mr-2", "text-3xl", 3, "name"], [1, "text-title-10", "text-base", "font-semibold"], [1, "rounded-4", "mx-3", "mb-4", "bg-white", "px-4", "py-6"], [1, "rounded-2", "bg-base-300", "mb-4", "flex", "items-center", "justify-start", "p-2"], ["name", "icon-assets-normal", 1, "text-2xl"], [1, "text-title-10", "ml-1", "text-xs"], [1, "mb-1", "flex", "justify-between"], [1, "text-subtitle-2", "text-sm"], i18n_0, [1, "text-title-10", "ml-1", "text-base", "font-extrabold"], [1, "flex", "justify-between"], i18n_2, [1, "mb-2", "ml-7", "flex", "items-center"], [1, "text-title-10", "font-extrabold", "text-base"], i18n_4, ["name", "icon-info", 1, "text-subtitle-2", "m-2", "text-base", 3, "click"], [1, "rounded-4", "mx-3", "mb-2", "bg-white", "px-4", "py-3"], [1, "text-subtitle-2", "h-4.5", "text-xs"], i18n_6, [1, "text-title-10", "text-base"], [1, "mt-2", "flex", "items-center", "justify-start"], ["name", "icon-lock", 1, "text-subtitle-2", "text-sm"], [1, "text-subtitle-2", "ml-1", "text-xs"], ["class", "rounded-4 mx-3 mb-2 bg-white px-4 py-3"], [1, "mt-20", "flex", "w-full", "flex-col", "items-center", "justify-center"], ["src", "./assets/images/placeholder-3.png"], [1, "text-line", "text-sm", "text-gray-400"], i18n_8];
  },
  template: function CoinPoolDetailPage_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](0, "common-page", 0);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelement"](1, "div", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](2, "div", 2)(3, "div", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵlistener"]("pulled$", function CoinPoolDetailPage_Template_div_pulled__3_listener($event) {
        return $event.waitFor(ctx.refreshList());
      })("infinited$", function CoinPoolDetailPage_Template_div_infinited__3_listener($event) {
        return $event.waitFor(ctx.loadMoreList());
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelement"](4, "bn-pull-to-refresh-spinner", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](5, "div", 5)(6, "div", 6);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelement"](7, "bs-token-with-chain-icon", 7);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](8, "div", 8)(9, "div", 9);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](10);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](11, "div", 10);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](12);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]()()();
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelement"](13, "div", 11);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](14, "div", 6);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelement"](15, "bs-icon", 12);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](16, "div", 13);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](17);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]()()();
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](18, "div", 14)(19, "div", 15);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelement"](20, "bs-icon", 16);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](21, "div", 17);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](22);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](23, "div", 18)(24, "div", 19);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵi18n"](25, 20);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](26, "div", 21);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](27);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](28, "div", 22)(29, "div", 19);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵi18n"](30, 23);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](31, "div", 21);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](32);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]()()();
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](33, "div", 24)(34, "span", 25);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵi18n"](35, 26);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](36, "bs-icon", 27);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵlistener"]("click", function CoinPoolDetailPage_Template_bs_icon_click_36_listener() {
        return ctx.showAcceptedAddressTip();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtemplate"](37, CoinPoolDetailPage_Conditional_37_Template, 2, 0)(38, CoinPoolDetailPage_Conditional_38_Template, 4, 0);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]()()();
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("contentBackground", "#f6f7fc")("headerBackground", "transparent")("titleClass", "!justify-start text-xl font-extrabold !text-title-10");
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("hasMore", ctx.addLiquidityRecordList.hasMore)("emitDistance", 158)("maxDistance", 200);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](4);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("tokenName", ctx.anchorTokenIcon)("chainName", ctx.anchorChainIcon);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtextInterpolate1"](" ", ctx.holdLiquidity.anchorCoinsName, " ");
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtextInterpolate1"](" ", ctx.anchorChainName, " ");
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("name", ctx.quoteTokenIcon);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtextInterpolate1"](" ", ctx.holdLiquidity.quoteCoinsName, " ");
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](5);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtextInterpolate"](ctx.userWalletAdress);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](5);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtextInterpolate"](ctx.holdLpCoins);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](5);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtextInterpolate"](ctx.lockedCoins);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](5);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵconditional"](37, ctx.addLiquidityRecordList && ctx.addLiquidityRecordList.dataList.length ? 37 : 38);
    }
  },
  dependencies: [_modules_page_module__WEBPACK_IMPORTED_MODULE_1__.CommonPageModule, _libs_bnf_components_pull_to_refresh_pull_to_refresh_directive__WEBPACK_IMPORTED_MODULE_9__.PullToRefreshDirective, _libs_bnf_components_pull_to_refresh_pull_to_refresh_spinner_component__WEBPACK_IMPORTED_MODULE_10__.PullToRefreshSpinnerComponent, _libs_bnf_components_infinite_scroll_infinite_scroll_directive__WEBPACK_IMPORTED_MODULE_11__.InfiniteScrollDirective, _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_12__.CommonPageComponent, _components_icon_icon_component__WEBPACK_IMPORTED_MODULE_13__.IconComponent, _angular_common__WEBPACK_IMPORTED_MODULE_15__.DatePipe, _angular_common__WEBPACK_IMPORTED_MODULE_15__.CommonModule, _components_token_with_chain_icon_token_with_chain_icon_component__WEBPACK_IMPORTED_MODULE_3__.TokenWithnChainIconComponent],
  styles: [".bginner[_ngcontent-%COMP%] {\n  background: linear-gradient(180deg, #e3e0f8 0%, #e6e0f8 15%, #faf3f7 65%, #f6f7fc 100%);\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL2FwcHMvYmZzd2FwL3NyYy9wYWdlcy9yZW1vdmUtbGlxdWlkaXR5L3BhZ2VzL2NvaW4tcG9vbC1kZXRhaWwvY29pbi1wb29sLWRldGFpbC5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLHVGQUFBO0FBQ0YiLCJzb3VyY2VzQ29udGVudCI6WyIuYmdpbm5lciB7XHJcbiAgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDE4MGRlZywgI2UzZTBmOCAwJSwgI2U2ZTBmOCAxNSUsICNmYWYzZjcgNjUlLCAjZjZmN2ZjIDEwMCUpO1xyXG59XHJcbiJdLCJzb3VyY2VSb290IjoiIn0= */"],
  changeDetection: 0
});
(0,tslib__WEBPACK_IMPORTED_MODULE_16__.__decorate)([CoinPoolDetailPage.QueryParams(), (0,tslib__WEBPACK_IMPORTED_MODULE_16__.__metadata)("design:type", Object)], CoinPoolDetailPage.prototype, "params", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_16__.__decorate)([CoinPoolDetailPage.States(1), (0,tslib__WEBPACK_IMPORTED_MODULE_16__.__metadata)("design:type", Object)], CoinPoolDetailPage.prototype, "detail", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_16__.__decorate)([CoinPoolDetailPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_16__.__metadata)("design:type", String)], CoinPoolDetailPage.prototype, "anchorTokenIcon", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_16__.__decorate)([CoinPoolDetailPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_16__.__metadata)("design:type", String)], CoinPoolDetailPage.prototype, "anchorChainIcon", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_16__.__decorate)([CoinPoolDetailPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_16__.__metadata)("design:type", String)], CoinPoolDetailPage.prototype, "quoteTokenIcon", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_16__.__decorate)([CoinPoolDetailPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_16__.__metadata)("design:type", String)], CoinPoolDetailPage.prototype, "quoteChainIcon", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_16__.__decorate)([CoinPoolDetailPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_16__.__metadata)("design:type", Object)], CoinPoolDetailPage.prototype, "anchorChainName", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_16__.__decorate)([CoinPoolDetailPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_16__.__metadata)("design:type", Object)], CoinPoolDetailPage.prototype, "quoteChainName", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_16__.__decorate)([CoinPoolDetailPage.States(1), (0,tslib__WEBPACK_IMPORTED_MODULE_16__.__metadata)("design:type", Object)], CoinPoolDetailPage.prototype, "holdLiquidity", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_16__.__decorate)([CoinPoolDetailPage.States(), (0,tslib__WEBPACK_IMPORTED_MODULE_16__.__metadata)("design:type", Object)], CoinPoolDetailPage.prototype, "addLiquidityRecordList", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_16__.__decorate)([CoinPoolDetailPage.States(), (0,tslib__WEBPACK_IMPORTED_MODULE_16__.__metadata)("design:type", String)], CoinPoolDetailPage.prototype, "holdLpCoins", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_16__.__decorate)([CoinPoolDetailPage.States(), (0,tslib__WEBPACK_IMPORTED_MODULE_16__.__metadata)("design:type", String)], CoinPoolDetailPage.prototype, "lockedCoins", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_16__.__decorate)([CoinPoolDetailPage.OnInit(), (0,tslib__WEBPACK_IMPORTED_MODULE_16__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_16__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_16__.__metadata)("design:returntype", Promise)], CoinPoolDetailPage.prototype, "iniParams", null);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CoinPoolDetailPage);

/***/ }),

/***/ 13178:
/*!************************************************************************************************!*\
  !*** ./apps/bfswap/src/pages/remove-liquidity/pages/coin-pool-detail/coin-pool-detail.type.ts ***!
  \************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   $LOCKEDSTATUS: () => (/* binding */ $LOCKEDSTATUS)
/* harmony export */ });
var $LOCKEDSTATUS;
(function ($LOCKEDSTATUS) {
  $LOCKEDSTATUS[$LOCKEDSTATUS["UNLOCKED"] = 1] = "UNLOCKED";
  $LOCKEDSTATUS[$LOCKEDSTATUS["TO_UNLOCK"] = 2] = "TO_UNLOCK";
  $LOCKEDSTATUS[$LOCKEDSTATUS["LOCKING"] = 3] = "LOCKING";
})($LOCKEDSTATUS || ($LOCKEDSTATUS = {}));

/***/ }),

/***/ 34913:
/*!***************************************************************************!*\
  !*** ./apps/bfswap/src/services/liquidity-user/liquidity-user.service.ts ***!
  \***************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   LiquidityUserService: () => (/* binding */ LiquidityUserService)
/* harmony export */ });
/* harmony import */ var D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 52542);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 61039);
/* harmony import */ var _services_bs_fetch_bs_fetch_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ~services/bs-fetch/bs-fetch.service */ 92925);
/* harmony import */ var _bnqkl_framework_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @bnqkl/framework/core */ 63563);

var _class;




/** 池子相关接口 */
class LiquidityUserService {
  constructor() {
    /** 日志 */
    this.console = (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.inject)(_bnqkl_framework_core__WEBPACK_IMPORTED_MODULE_2__.LoggerService).createLoggerForService(this, 'liquidity-user-service');
    /** fetch服务 */
    this.fetch = (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.inject)(_services_bs_fetch_bs_fetch_service__WEBPACK_IMPORTED_MODULE_1__.SwapFetch);
    /** 后端接口 */
    this.SERVER_API = {
      /** 获取用户持仓列表 POST */
      getLiquidityUserPositionList: this.fetch.APP_URL('/bnqklswap/liquidity/user/position/list'),
      /** 获取用户资产列表 POST */
      getLiquidityUserAssetsList: this.fetch.APP_URL('/bnqklswap/liquidity/user/assets/list'),
      /** 获取用户流动性持仓 */
      getUserLiquidityHolding: this.fetch.APP_URL('/bnqklswap/liquidity/user/position/list'),
      /** 获取用户持仓详情 */
      getUserPositionDetail: this.fetch.APP_URL('/bnqklswap/liquidity/user/position/details'),
      /** 获取用户持仓比例 */
      getUserPositionPercent: this.fetch.APP_URL('/bnqklswap/liquidity/user/position/percent'),
      /** 获取用户流动性持仓冻结数量 */
      getUserLiquidityLocked: this.fetch.APP_URL('/bnqklswap/liquidity/user/position/locked'),
      /** 获取用户流动性持仓冻结列表 */
      getUserLiquidityLockedList: this.fetch.APP_URL('/bnqklswap/liquidity/user/position/locked/list')
    };
  }
  /** 获取用户锁仓量列表 */
  getUserLiquidityLockedList(options) {
    var _this = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      try {
        return _this.fetch.post(_this.SERVER_API.getUserLiquidityLockedList, options);
        // 默认数据
      } catch (error) {
        _this.console.log('getUserLiquidityLockedList', error);
        return;
      }
    })();
  }
  /** 获取用户持仓详情 */
  getUserPositionDetail(options) {
    try {
      return this.fetch.post(this.SERVER_API.getUserPositionDetail, options);
      // 默认数据
    } catch (error) {
      this.console.log('getUserPositionDetail', error);
      return;
    }
  }
  /** 获取用户锁仓量 */
  getUserLiquidityLocked(options) {
    var _this2 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      try {
        return _this2.fetch.post(_this2.SERVER_API.getUserLiquidityLocked, options);
        // 默认数据
      } catch (error) {
        _this2.console.log('getUserLiquidityLocked', error);
        return;
      }
    })();
  }
  /** 获取用户持仓比例 */
  getUserPositionPercent(options) {
    try {
      return this.fetch.post(this.SERVER_API.getUserPositionPercent, options);
      // 默认数据
    } catch (error) {
      this.console.log('getUserPositionPercent', error);
      return;
    }
  }
  /** 获取用户持仓列表 */
  getLiquidityUserPostionList(options) {
    try {
      return this.fetch.post(this.SERVER_API.getLiquidityUserPositionList, options);
      // 默认数据
    } catch (error) {
      this.console.log('getLiquidityUserPostionList', error);
      return;
    }
  }
  /** 获取用户资产列表 */
  getLiquidityUserAssetsList(options) {
    try {
      return this.fetch.post(this.SERVER_API.getLiquidityUserAssetsList, options);
      // 默认数据
    } catch (error) {
      this.console.log('getLiquidityUserPostionList', error);
      return;
    }
  }
  /** 获取用户流动性持仓 */
  getUserLiquidityHolding(options) {
    var _this3 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      try {
        return _this3.fetch.post(_this3.SERVER_API.getUserLiquidityHolding, options);
        // 默认数据
      } catch (error) {
        _this3.console.log('getUserLiquidityHolding', error);
        return;
      }
    })();
  }
}
_class = LiquidityUserService;
_class.ɵfac = function LiquidityUserService_Factory(t) {
  return new (t || _class)();
};
_class.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineInjectable"]({
  token: _class,
  factory: _class.ɵfac,
  providedIn: 'root'
});

/***/ })

}]);
//# sourceMappingURL=apps_bfswap_src_pages_remove-liquidity_pages_coin-pool-detail_coin-pool-detail_component_ts.js.map