"use strict";
(self["webpackChunkbfswap"] = self["webpackChunkbfswap"] || []).push([["apps_bfswap_src_pages_mine_pages_my-asset-allocation_my-asset-allocation_component_ts"],{

/***/ 59895:
/*!***********************************************************************************************!*\
  !*** ./apps/bfswap/src/pages/mine/pages/my-asset-allocation/my-asset-allocation.component.ts ***!
  \***********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   MyAssetAllocationPage: () => (/* binding */ MyAssetAllocationPage),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 52542);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! tslib */ 90505);
/* harmony import */ var _modules_page_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ~modules/page.module */ 16381);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/common */ 6729);
/* harmony import */ var echarts__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! echarts */ 23557);
/* harmony import */ var _pipes_percentage_transfer_percentage_transfer_pipe__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ~pipes/percentage-transfer/percentage-transfer.pipe */ 1726);
/* harmony import */ var _pipes_amount_format_amount_format_pipe__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ~pipes/amount-format/amount-format.pipe */ 23377);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 61039);
/* harmony import */ var _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../../../../../libs/bnf/modules/page/common-page/common-page.component */ 62052);
/* harmony import */ var _components_icon_icon_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../../components/icon/icon.component */ 18840);
/* harmony import */ var _libs_bnf_pipes_amountFixed_amount_fixed_pipe__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../../../../../libs/bnf/pipes/amountFixed/amount-fixed.pipe */ 44070);

var _class;











const _c0 = ["ratioChart"];
function MyAssetAllocationPage_For_15_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](0, "div", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](1, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](3, "div", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpipe"](5, "percentageTransfer");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const item_r2 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵstyleMap"](item_r2.style);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtextInterpolate"](item_r2.name);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpipeBind1"](5, 4, item_r2.value));
  }
}
const _c3 = () => ({
  removeZero: true
});
/** 资产分配页面 */
class MyAssetAllocationPage extends _modules_page_module__WEBPACK_IMPORTED_MODULE_1__.CommonPageBase {
  constructor() {
    super(...arguments);
    /** 列表数据 */
    this.dataList = [];
    /** 饼图数据 */
    this.pieData = [];
    /** 总资产 */
    this.totalUAmount = 0;
    /** 颜色数组 */
    this.colorList = ['#4743ff', '#a484ee', '#b24dff', '#90D161', '#f7931a', '#cd2d71', '#fdd566', '#e3d3ff', '#7228c8', '#43a76b', '#f06821', '#6c92f9', '#70c3ed'];
    /** 权益图下方数据 */
    this.ratioDataList = [];
  }
  /** 初始化 */
  initData() {
    const {
      queryParams,
      colorList
    } = this;
    if (queryParams) {
      const pieChartData = JSON.parse(queryParams.pieChartData);
      const {
        totalAmount,
        list
      } = pieChartData;
      this.totalUAmount = totalAmount;
      const pieData = [];
      const dataList = [];
      list.forEach((item, index) => {
        var _colorList$index;
        const color = (_colorList$index = colorList[index]) !== null && _colorList$index !== void 0 ? _colorList$index : this.getRandomColor();
        pieData.push({
          name: item.name,
          value: item.amount,
          itemStyle: {
            color: color
          }
        });
        dataList.push({
          name: item.name,
          value: item.amount,
          style: `backgroundColor:${color}`
        });
      });
      this.pieData = pieData;
      this.dataList = dataList;
    }
  }
  /** 获取随机颜色 */
  getRandomColor() {
    const red = Math.floor(Math.random() * 256);
    const green = Math.floor(Math.random() * 256);
    const blue = Math.floor(Math.random() * 256);
    return `rgb(${red},${green},${blue})`;
  }
  /** 初始化图表 */
  initEcharts() {
    var _this = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      var _this$ratioChart;
      const ratioDOM = (_this$ratioChart = _this.ratioChart) === null || _this$ratioChart === void 0 ? void 0 : _this$ratioChart.nativeElement;
      _this.ratioInstance = echarts__WEBPACK_IMPORTED_MODULE_2__.init(ratioDOM);
      const option = _this.getRatioOption();
      _this.ratioInstance.setOption(option);
    })();
  }
  /** 获取占比配置 */
  getRatioOption() {
    return {
      series: [{
        type: 'pie',
        radius: ['0', '65%'],
        center: ['50%', '50%'],
        data: this.pieData
      }]
    };
  }
  /** 打开提示窗口 */
  openTip() {
    var _this2 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      yield _this2.alert({
        headerTitle: `总资产`,
        bodyMessage: '总资产仅根据钱包授权的，且在BTCSwap中支持兑换的权益（即：BFT，PMC，ETHM，BTCM，KPM，FTC，USDM）换算成USDM计算，范围包括地址中的权益，以及各流动池权益。',
        buttonText: '好的'
      });
    })();
  }
}
_class = MyAssetAllocationPage;
_class.ɵfac = /*@__PURE__*/(() => {
  let ɵMyAssetAllocationPage_BaseFactory;
  return function MyAssetAllocationPage_Factory(t) {
    return (ɵMyAssetAllocationPage_BaseFactory || (ɵMyAssetAllocationPage_BaseFactory = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵgetInheritedFactory"](_class)))(t || _class);
  };
})();
_class.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdefineComponent"]({
  type: _class,
  selectors: [["bs-my-asset-allocation"]],
  viewQuery: function MyAssetAllocationPage_Query(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵviewQuery"](_c0, 5);
    }
    if (rf & 2) {
      let _t;
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵloadQuery"]()) && (ctx.ratioChart = _t.first);
    }
  },
  standalone: true,
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵInheritDefinitionFeature"], _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵStandaloneFeature"]],
  decls: 16,
  vars: 11,
  consts: () => {
    let i18n_1;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_USDM$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_ASSET_ALLOCATION_MY_ASSET_ALLOCATION_COMPONENT_TS_2 = goog.getMsg("\u603B\u8D44\u4EA7(USDM)");
      i18n_1 = MSG_EXTERNAL_USDM$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_ASSET_ALLOCATION_MY_ASSET_ALLOCATION_COMPONENT_TS_2;
    } else {
      i18n_1 = "\u603B\u8D44\u4EA7(USDM)";
    }
    return [[3, "headerBackground", "contentClass", "titleClass"], [1, "h-full", "pt-2.5"], [1, "rounded-t-5", "min-h-full", "bg-white", "py-6"], [1, "flex", "items-center", "mb-2", "px-8"], [1, "text-xs", "text-base-gray"], i18n_1, ["name", "icon-info", 1, "icon-4", "ml-1", 3, "click"], [1, "text-title-10", "text-2xl", "font-extrabold", "px-8"], [1, "h-70", "w-full"], ["ratioChart", ""], [1, "grid", "grid-cols-[1rem,1fr,3rem]", "text-xs", "gap-x-2", "gap-y-2", "font-medium", "w-3/5", "mx-auto", "items-center"], [1, "w-4", "h-2"], [1, "text-right"]];
  },
  template: function MyAssetAllocationPage_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](0, "common-page", 0)(1, "div", 1)(2, "div", 2)(3, "div", 3)(4, "div", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵi18n"](5, 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](6, "bs-icon", 6);
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵlistener"]("click", function MyAssetAllocationPage_Template_bs_icon_click_6_listener() {
        return ctx.openTip();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](7, "div", 7);
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](8);
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpipe"](9, "amountFormat");
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpipe"](10, "amountFixed");
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](11, "div", 8, 9);
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](13, "div", 10);
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵrepeaterCreate"](14, MyAssetAllocationPage_For_15_Template, 6, 6, null, null, _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵrepeaterTrackByIndex"]);
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]()()()();
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("headerBackground", "transparent")("contentClass", "bg-linear-page-top")("titleClass", "text-xl !text-title-10 font-extrabold");
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](8);
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpipeBind1"](9, 4, _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpipeBind3"](10, 6, ctx.totalUAmount, 8, _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpureFunction0"](10, _c3))), " ");
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](6);
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵrepeater"](ctx.dataList);
    }
  },
  dependencies: [_pipes_amount_format_amount_format_pipe__WEBPACK_IMPORTED_MODULE_4__.AmountFormatPipe, _pipes_percentage_transfer_percentage_transfer_pipe__WEBPACK_IMPORTED_MODULE_3__.PercentageTransferPipe, _modules_page_module__WEBPACK_IMPORTED_MODULE_1__.CommonPageModule, _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_5__.CommonPageComponent, _components_icon_icon_component__WEBPACK_IMPORTED_MODULE_6__.IconComponent, _libs_bnf_pipes_amountFixed_amount_fixed_pipe__WEBPACK_IMPORTED_MODULE_7__.AmountFixedPipe, _angular_common__WEBPACK_IMPORTED_MODULE_9__.CommonModule],
  styles: ["/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsInNvdXJjZVJvb3QiOiIifQ== */"],
  changeDetection: 0
});
(0,tslib__WEBPACK_IMPORTED_MODULE_10__.__decorate)([MyAssetAllocationPage.QueryParams(), (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__metadata)("design:type", Object)], MyAssetAllocationPage.prototype, "queryParams", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_10__.__decorate)([MyAssetAllocationPage.OnInit(), (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__metadata)("design:returntype", void 0)], MyAssetAllocationPage.prototype, "initData", null);
(0,tslib__WEBPACK_IMPORTED_MODULE_10__.__decorate)([MyAssetAllocationPage.OnReady(), (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__metadata)("design:returntype", Promise)], MyAssetAllocationPage.prototype, "initEcharts", null);
(0,tslib__WEBPACK_IMPORTED_MODULE_10__.__decorate)([MyAssetAllocationPage.States(1), (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__metadata)("design:type", Array)], MyAssetAllocationPage.prototype, "ratioDataList", void 0);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MyAssetAllocationPage);

/***/ })

}]);
//# sourceMappingURL=apps_bfswap_src_pages_mine_pages_my-asset-allocation_my-asset-allocation_component_ts.js.map