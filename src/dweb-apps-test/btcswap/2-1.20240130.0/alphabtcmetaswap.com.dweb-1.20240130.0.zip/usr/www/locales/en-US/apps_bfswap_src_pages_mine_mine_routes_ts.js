"use strict";
(self["webpackChunkbfswap"] = self["webpackChunkbfswap"] || []).push([["apps_bfswap_src_pages_mine_mine_routes_ts"],{

/***/ 27032:
/*!****************************************************!*\
  !*** ./apps/bfswap/src/pages/mine/mine.resolve.ts ***!
  \****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   mineResolver: () => (/* binding */ mineResolver),
/* harmony export */   supportChainListResolverFn: () => (/* binding */ supportChainListResolverFn)
/* harmony export */ });
/* harmony import */ var D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 52542);
/* harmony import */ var _services_wallet_wallet_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ~services/wallet/wallet.service */ 54275);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 61039);



/** supportChainListResolverFn */
const supportChainListResolverFn = /*#__PURE__*/function () {
  var _ref = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
    const walletService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.inject)(_services_wallet_wallet_service__WEBPACK_IMPORTED_MODULE_1__.WalletService);
    const chainList = yield walletService.supportChainList();
    return chainList.map(item => {
      return {
        ...item,
        activeIcon: `chain-${item.chain}`,
        unactiveIcon: `chain-${item.chain}-s`,
        active: false
      };
    });
  });
  return function supportChainListResolverFn() {
    return _ref.apply(this, arguments);
  };
}();
/** mineResolver */
const mineResolver = {
  supportChainList: supportChainListResolverFn
};

/***/ }),

/***/ 58881:
/*!***************************************************!*\
  !*** ./apps/bfswap/src/pages/mine/mine.routes.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   routes: () => (/* binding */ routes)
/* harmony export */ });
/* harmony import */ var _mine_resolve__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./mine.resolve */ 27032);

/**
 * 路由
 */
const routes = [{
  path: '',
  loadComponent: () => Promise.all(/*! import() */[__webpack_require__.e("default-apps_bfswap_src_pages_mine_pages_my-assets_my-assets_component_ts-apps_bfswap_src_pag-1528df"), __webpack_require__.e("apps_bfswap_src_components_token-with-chain-icon_token-with-chain-icon_component_ts-apps_bfsw-a24061")]).then(__webpack_require__.bind(__webpack_require__, /*! ./mine.component */ 30063)),
  resolve: _mine_resolve__WEBPACK_IMPORTED_MODULE_0__.mineResolver
}, {
  path: 'my-record',
  title: '历史记录',
  loadComponent: () => Promise.all(/*! import() */[__webpack_require__.e("common"), __webpack_require__.e("apps_bfswap_src_pages_mine_pages_my-record_my-record_component_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./pages/my-record/my-record.component */ 21441))
}, {
  path: 'my-asset-allocation',
  title: '资产分配',
  loadComponent: () => Promise.all(/*! import() */[__webpack_require__.e("default-apps_bfswap_src_pipes_amount-format_amount-format_pipe_ts-apps_bfswap_src_pipes_perce-a837d4"), __webpack_require__.e("apps_bfswap_src_pages_mine_pages_my-asset-allocation_my-asset-allocation_component_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./pages/my-asset-allocation/my-asset-allocation.component */ 59895))
}, {
  path: 'my-wallet-settings',
  title: "Wallet connection",
  loadComponent: () => Promise.all(/*! import() */[__webpack_require__.e("default-apps_bfswap_src_components_connect-wallet-panel_connect-wallet-penel_component_ts"), __webpack_require__.e("apps_bfswap_src_pages_mine_pages_my-wallet-settings_my-wallet-settings_component_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./pages/my-wallet-settings/my-wallet-settings.component */ 85080))
}, {
  path: 'my-record-swap-detail',
  loadComponent: () => Promise.all(/*! import() */[__webpack_require__.e("default-apps_bfswap_src_components_related-events_related-events_component_ts-apps_bfswap_src-4c6996"), __webpack_require__.e("apps_bfswap_src_pages_mine_pages_my-record-swap-detail_my-record-swap-detail_component_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./pages/my-record-swap-detail/my-record-swap-detail.component */ 53505))
}, {
  path: 'my-holdings-detail',
  title: '持仓详情',
  loadComponent: () => __webpack_require__.e(/*! import() */ "apps_bfswap_src_pages_mine_pages_my-holdings-detail_my-holdings-detail_component_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/my-holdings-detail/my-holdings-detail.component */ 59817))
}, {
  path: 'add-liquidity-record',
  title: '固定增流记录',
  loadComponent: () => __webpack_require__.e(/*! import() */ "apps_bfswap_src_pages_mine_pages_add-liquidity-record_add-liquidity-record_component_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/add-liquidity-record/add-liquidity-record.component */ 97322))
}, {
  path: 'my-record-add-liquidity-detail',
  loadComponent: () => Promise.all(/*! import() */[__webpack_require__.e("default-apps_bfswap_src_components_related-events_related-events_component_ts-apps_bfswap_src-4c6996"), __webpack_require__.e("apps_bfswap_src_pages_mine_pages_my-record-add-liquidity-detail_my-record-add-liquidity-detai-20a872")]).then(__webpack_require__.bind(__webpack_require__, /*! ./pages/my-record-add-liquidity-detail/my-record-add-liquidity-detail.component */ 55866))
}, {
  path: 'my-record-swap',
  title: '兑换记录',
  loadComponent: () => Promise.all(/*! import() */[__webpack_require__.e("common"), __webpack_require__.e("apps_bfswap_src_pages_mine_pages_my-record-swap_my-record-swap_component_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./pages/my-record-swap/my-record-swap.component */ 69407))
}, {
  path: 'my-record-remove-liquidity-detail',
  loadComponent: () => Promise.all(/*! import() */[__webpack_require__.e("default-apps_bfswap_src_components_related-events_related-events_component_ts-apps_bfswap_src-4c6996"), __webpack_require__.e("apps_bfswap_src_pages_mine_pages_my-record-remove-liquidity-detail_my-record-remove-liquidity-7a4ec3")]).then(__webpack_require__.bind(__webpack_require__, /*! ./pages/my-record-remove-liquidity-detail/my-record-remove-liquidity-detail.component */ 95921))
}, {
  path: 'user-agreement',
  title: "user agreement",
  loadComponent: () => __webpack_require__.e(/*! import() */ "apps_bfswap_src_pages_mine_pages_user-agreement_user-agreement_component_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/user-agreement/user-agreement.component */ 20070))
}];
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (routes);

/***/ })

}]);
//# sourceMappingURL=apps_bfswap_src_pages_mine_mine_routes_ts.js.map