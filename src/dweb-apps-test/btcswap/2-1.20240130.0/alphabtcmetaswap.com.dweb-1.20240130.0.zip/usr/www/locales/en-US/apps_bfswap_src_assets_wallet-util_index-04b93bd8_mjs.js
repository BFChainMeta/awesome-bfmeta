"use strict";
(self["webpackChunkbfswap"] = self["webpackChunkbfswap"] || []).push([["apps_bfswap_src_assets_wallet-util_index-04b93bd8_mjs"],{

/***/ 30932:
/*!***************************************************************!*\
  !*** ./apps/bfswap/src/assets/wallet-util/index-04b93bd8.mjs ***!
  \***************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   adler32: () => (/* binding */ z),
/* harmony export */   argon2Verify: () => (/* binding */ q),
/* harmony export */   argon2d: () => (/* binding */ V),
/* harmony export */   argon2i: () => (/* binding */ N),
/* harmony export */   argon2id: () => (/* binding */ D),
/* harmony export */   bcrypt: () => (/* binding */ K),
/* harmony export */   bcryptVerify: () => (/* binding */ Z),
/* harmony export */   blake2b: () => (/* binding */ T),
/* harmony export */   blake2s: () => (/* binding */ G),
/* harmony export */   blake3: () => (/* binding */ te),
/* harmony export */   crc32: () => (/* binding */ ie),
/* harmony export */   crc32c: () => (/* binding */ ce),
/* harmony export */   createAdler32: () => (/* binding */ M),
/* harmony export */   createAdler32Sync: () => (/* binding */ E),
/* harmony export */   createBLAKE2b: () => (/* binding */ $),
/* harmony export */   createBLAKE2bSync: () => (/* binding */ j),
/* harmony export */   createBLAKE2s: () => (/* binding */ J),
/* harmony export */   createBLAKE2sSync: () => (/* binding */ Q),
/* harmony export */   createBLAKE3: () => (/* binding */ ae),
/* harmony export */   createBLAKE3Sync: () => (/* binding */ re),
/* harmony export */   createCRC32: () => (/* binding */ ne),
/* harmony export */   createCRC32C: () => (/* binding */ ue),
/* harmony export */   createCRC32CSync: () => (/* binding */ de),
/* harmony export */   createCRC32Sync: () => (/* binding */ oe),
/* harmony export */   createHMAC: () => (/* reexport safe */ _hmac_43177c9b_mjs__WEBPACK_IMPORTED_MODULE_2__.a),
/* harmony export */   createHMACSync: () => (/* reexport safe */ _hmac_43177c9b_mjs__WEBPACK_IMPORTED_MODULE_2__.c),
/* harmony export */   createKeccak: () => (/* reexport safe */ _keccak_1e6b6241_mjs__WEBPACK_IMPORTED_MODULE_3__.a),
/* harmony export */   createKeccakSync: () => (/* reexport safe */ _keccak_1e6b6241_mjs__WEBPACK_IMPORTED_MODULE_3__.c),
/* harmony export */   createMD4: () => (/* binding */ pe),
/* harmony export */   createMD4Sync: () => (/* binding */ ye),
/* harmony export */   createMD5: () => (/* binding */ fe),
/* harmony export */   createMD5Sync: () => (/* binding */ ge),
/* harmony export */   createRIPEMD160: () => (/* reexport safe */ _ripemd160_fdc485e7_mjs__WEBPACK_IMPORTED_MODULE_5__.a),
/* harmony export */   createRIPEMD160Sync: () => (/* reexport safe */ _ripemd160_fdc485e7_mjs__WEBPACK_IMPORTED_MODULE_5__.c),
/* harmony export */   createSHA1: () => (/* reexport safe */ _sha1_81fbe1a9_mjs__WEBPACK_IMPORTED_MODULE_7__.c),
/* harmony export */   createSHA1Sync: () => (/* reexport safe */ _sha1_81fbe1a9_mjs__WEBPACK_IMPORTED_MODULE_7__.a),
/* harmony export */   createSHA224: () => (/* binding */ Ie),
/* harmony export */   createSHA224Sync: () => (/* binding */ xe),
/* harmony export */   createSHA256: () => (/* reexport safe */ _sha256_d88873b6_mjs__WEBPACK_IMPORTED_MODULE_6__.a),
/* harmony export */   createSHA256Sync: () => (/* reexport safe */ _sha256_d88873b6_mjs__WEBPACK_IMPORTED_MODULE_6__.c),
/* harmony export */   createSHA3: () => (/* reexport safe */ _sha3_4d44b5a9_mjs__WEBPACK_IMPORTED_MODULE_8__.c),
/* harmony export */   createSHA384: () => (/* binding */ $e),
/* harmony export */   createSHA384Sync: () => (/* binding */ je),
/* harmony export */   createSHA3Sync: () => (/* reexport safe */ _sha3_4d44b5a9_mjs__WEBPACK_IMPORTED_MODULE_8__.a),
/* harmony export */   createSHA512: () => (/* reexport safe */ _sha512_7b87e5c4_mjs__WEBPACK_IMPORTED_MODULE_9__.a),
/* harmony export */   createSHA512Sync: () => (/* reexport safe */ _sha512_7b87e5c4_mjs__WEBPACK_IMPORTED_MODULE_9__.c),
/* harmony export */   createSM3: () => (/* binding */ He),
/* harmony export */   createSM3Sync: () => (/* binding */ Be),
/* harmony export */   createWhirlpool: () => (/* binding */ Ne),
/* harmony export */   createWhirlpoolSync: () => (/* binding */ De),
/* harmony export */   createXXHash128: () => (/* binding */ Oe),
/* harmony export */   createXXHash128Sync: () => (/* binding */ We),
/* harmony export */   createXXHash3: () => (/* binding */ et),
/* harmony export */   createXXHash32: () => (/* binding */ st),
/* harmony export */   createXXHash32Sync: () => (/* binding */ it),
/* harmony export */   createXXHash3Sync: () => (/* binding */ tt),
/* harmony export */   createXXHash64: () => (/* binding */ wt),
/* harmony export */   createXXHash64Sync: () => (/* binding */ pt),
/* harmony export */   getBLAKE2bPreparer: () => (/* binding */ x),
/* harmony export */   getBLAKE2sPreparer: () => (/* binding */ W),
/* harmony export */   getBLAKE3Preparer: () => (/* binding */ Y),
/* harmony export */   getSha3Preparer: () => (/* reexport safe */ _sha3_4d44b5a9_mjs__WEBPACK_IMPORTED_MODULE_8__.g),
/* harmony export */   keccak: () => (/* reexport safe */ _keccak_1e6b6241_mjs__WEBPACK_IMPORTED_MODULE_3__.k),
/* harmony export */   md4: () => (/* binding */ we),
/* harmony export */   md5: () => (/* binding */ me),
/* harmony export */   pbkdf2: () => (/* reexport safe */ _pbkdf2_cdbc1a49_mjs__WEBPACK_IMPORTED_MODULE_4__.a),
/* harmony export */   pbkdf2Sync: () => (/* reexport safe */ _pbkdf2_cdbc1a49_mjs__WEBPACK_IMPORTED_MODULE_4__.p),
/* harmony export */   prepareAdler32: () => (/* binding */ v),
/* harmony export */   prepareArgon2: () => (/* binding */ P),
/* harmony export */   prepareBcrypt: () => (/* binding */ C),
/* harmony export */   prepareCRC32: () => (/* binding */ se),
/* harmony export */   prepareMD4: () => (/* binding */ le),
/* harmony export */   prepareMD5: () => (/* binding */ he),
/* harmony export */   prepareRIPEMD160: () => (/* reexport safe */ _ripemd160_fdc485e7_mjs__WEBPACK_IMPORTED_MODULE_5__.p),
/* harmony export */   prepareSHA1: () => (/* reexport safe */ _sha1_81fbe1a9_mjs__WEBPACK_IMPORTED_MODULE_7__.p),
/* harmony export */   prepareSHA224: () => (/* binding */ Me),
/* harmony export */   prepareSHA256: () => (/* reexport safe */ _sha256_d88873b6_mjs__WEBPACK_IMPORTED_MODULE_6__.p),
/* harmony export */   prepareSHA384: () => (/* binding */ Ae),
/* harmony export */   prepareSHA512: () => (/* reexport safe */ _sha512_7b87e5c4_mjs__WEBPACK_IMPORTED_MODULE_9__.p),
/* harmony export */   prepareSM3: () => (/* binding */ Pe),
/* harmony export */   prepareScrypt: () => (/* binding */ be),
/* harmony export */   prepareWhirlpool: () => (/* binding */ Fe),
/* harmony export */   prepareXXHash128: () => (/* binding */ Ve),
/* harmony export */   prepareXXHash3: () => (/* binding */ _e),
/* harmony export */   prepareXXHash32: () => (/* binding */ at),
/* harmony export */   prepareXXHash64: () => (/* binding */ nt),
/* harmony export */   ripemd160: () => (/* reexport safe */ _ripemd160_fdc485e7_mjs__WEBPACK_IMPORTED_MODULE_5__.r),
/* harmony export */   scrypt: () => (/* binding */ ze),
/* harmony export */   scryptSync: () => (/* binding */ ke),
/* harmony export */   sha1: () => (/* reexport safe */ _sha1_81fbe1a9_mjs__WEBPACK_IMPORTED_MODULE_7__.s),
/* harmony export */   sha224: () => (/* binding */ Ee),
/* harmony export */   sha256: () => (/* reexport safe */ _sha256_d88873b6_mjs__WEBPACK_IMPORTED_MODULE_6__.s),
/* harmony export */   sha3: () => (/* reexport safe */ _sha3_4d44b5a9_mjs__WEBPACK_IMPORTED_MODULE_8__.s),
/* harmony export */   sha384: () => (/* binding */ Te),
/* harmony export */   sha512: () => (/* reexport safe */ _sha512_7b87e5c4_mjs__WEBPACK_IMPORTED_MODULE_9__.s),
/* harmony export */   sm3: () => (/* binding */ Ue),
/* harmony export */   whirlpool: () => (/* binding */ Le),
/* harmony export */   xxhash128: () => (/* binding */ Ze),
/* harmony export */   xxhash3: () => (/* binding */ Ye),
/* harmony export */   xxhash32: () => (/* binding */ rt),
/* harmony export */   xxhash64: () => (/* binding */ lt)
/* harmony export */ });
/* harmony import */ var D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 52542);
/* harmony import */ var _WASMInterface_4e8d37b8_mjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./WASMInterface-4e8d37b8.mjs */ 18047);
/* harmony import */ var _hmac_43177c9b_mjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./hmac-43177c9b.mjs */ 29570);
/* harmony import */ var _keccak_1e6b6241_mjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./keccak-1e6b6241.mjs */ 24645);
/* harmony import */ var _pbkdf2_cdbc1a49_mjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./pbkdf2-cdbc1a49.mjs */ 41817);
/* harmony import */ var _ripemd160_fdc485e7_mjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./ripemd160-fdc485e7.mjs */ 10918);
/* harmony import */ var _sha256_d88873b6_mjs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./sha256-d88873b6.mjs */ 98080);
/* harmony import */ var _sha1_81fbe1a9_mjs__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./sha1-81fbe1a9.mjs */ 27811);
/* harmony import */ var _sha3_4d44b5a9_mjs__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./sha3-4d44b5a9.mjs */ 9383);
/* harmony import */ var _sha512_7b87e5c4_mjs__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./sha512-7b87e5c4.mjs */ 15574);
/* harmony import */ var _index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./index-d96f2042.mjs */ 99449);













const v = (0,_WASMInterface_4e8d37b8_mjs__WEBPACK_IMPORTED_MODULE_1__.c)("adler32", 4),
  z = /*#__PURE__*/function () {
    var _ref = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (e) {
      return (yield v()).calculate(e);
    });
    return function z(_x) {
      return _ref.apply(this, arguments);
    };
  }(),
  M = /*#__PURE__*/function () {
    var _ref2 = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      return E(yield v());
    });
    return function M() {
      return _ref2.apply(this, arguments);
    };
  }(),
  E = (e = v.wasm) => {
    e.init();
    const t = {
      init: () => (e.init(), t),
      update: a => (e.update(a), t),
      digest: t => e.digest(t),
      save: () => e.save(),
      load: a => (e.load(a), t),
      blockSize: 4,
      digestSize: 4
    };
    return t;
  },
  I = new Map(),
  x = a => {
    (0,_WASMInterface_4e8d37b8_mjs__WEBPACK_IMPORTED_MODULE_1__.v)(a, 512);
    const r = a / 8;
    let s = I.get(r);
    return void 0 === s && (s = (0,_WASMInterface_4e8d37b8_mjs__WEBPACK_IMPORTED_MODULE_1__.c)("blake2b", r), I.set(r, s)), s;
  },
  A = (e, t) => {
    let a,
      r = e;
    if (void 0 !== t) {
      if (a = (0,_WASMInterface_4e8d37b8_mjs__WEBPACK_IMPORTED_MODULE_1__.g)(t), a.length > 64) throw new Error("Max key length is 64 bytes");
      r = (0,_WASMInterface_4e8d37b8_mjs__WEBPACK_IMPORTED_MODULE_1__.b)(e, a.length);
    }
    return {
      keyBuffer: a,
      initParam: r
    };
  },
  T = /*#__PURE__*/function () {
    var _ref3 = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (e, t = 512, a) {
      const r = yield x(t)(),
        {
          keyBuffer: s,
          initParam: i
        } = A(t, a);
      return i > 512 && r.writeMemory(s), r.calculate(e, i);
    });
    return function T(_x2) {
      return _ref3.apply(this, arguments);
    };
  }(),
  $ = /*#__PURE__*/function () {
    var _ref4 = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (e = 512, t) {
      return j(e, t, yield x(e)());
    });
    return function $() {
      return _ref4.apply(this, arguments);
    };
  }(),
  j = (e = 512, t, a = x(e).wasm) => {
    const {
        keyBuffer: r,
        initParam: s
      } = A(e, t),
      i = e / 8;
    s > 512 && a.writeMemory(r), a.init(s);
    const n = {
      init: s > 512 ? () => (a.writeMemory(r), a.init(s), n) : () => (a.init(s), n),
      update: e => (a.update(e), n),
      digest: e => a.digest(e),
      save: () => a.save(),
      load: e => (a.load(e), n),
      blockSize: 128,
      digestSize: i
    };
    return n;
  },
  P = (0,_WASMInterface_4e8d37b8_mjs__WEBPACK_IMPORTED_MODULE_1__.c)("argon2", 1024);
const U = new DataView(new ArrayBuffer(4));
function H(e) {
  return U.setInt32(0, e, !0), new Uint8Array(U.buffer);
}
function B(_x3, _x4, _x5) {
  return _B.apply(this, arguments);
}
function _B() {
  _B = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (e, t, a) {
    if (a <= 64) {
      const e = yield $(8 * a);
      return e.update(H(a)), e.update(t), e.digest("binary");
    }
    const r = Math.ceil(a / 32) - 2,
      s = new Uint8Array(a);
    e.init(), e.update(H(a)), e.update(t);
    let i = e.digest("binary");
    s.set(i.subarray(0, 32), 0);
    for (let t = 1; t < r; t++) e.init(), e.update(i), i = e.digest("binary"), s.set(i.subarray(0, 32), 32 * t);
    const n = a - 32 * r;
    let o;
    return 64 === n ? (o = e, o.init()) : o = yield $(8 * n), o.update(i), i = o.digest("binary"), s.set(i.subarray(0, n), 32 * r), s;
  });
  return _B.apply(this, arguments);
}
function F(_x6) {
  return _F.apply(this, arguments);
}
function _F() {
  _F = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (e) {
    const {
        parallelism: t,
        iterations: a,
        hashLength: r
      } = e,
      s = (0,_WASMInterface_4e8d37b8_mjs__WEBPACK_IMPORTED_MODULE_1__.g)(e.password),
      n = (0,_WASMInterface_4e8d37b8_mjs__WEBPACK_IMPORTED_MODULE_1__.g)(e.salt),
      c = function (e) {
        switch (e) {
          case "d":
            return 0;
          case "i":
            return 1;
          default:
            return 2;
        }
      }(e.hashType),
      {
        memorySize: d
      } = e,
      [l, p] = yield Promise.all([yield P(), $(512)]);
    l.setMemorySize(1024 * d + 1024);
    const y = new Uint8Array(24),
      h = new DataView(y.buffer);
    h.setInt32(0, t, !0), h.setInt32(4, r, !0), h.setInt32(8, d, !0), h.setInt32(12, a, !0), h.setInt32(16, 19, !0), h.setInt32(20, c, !0), l.writeMemory(y, 1024 * d), p.init(), p.update(y), p.update(H(s.length)), p.update(s), p.update(H(n.length)), p.update(n), p.update(H(0)), p.update(H(0));
    const m = 4 * Math.floor(d / (4 * t)),
      f = new Uint8Array(72),
      g = p.digest("binary");
    f.set(g);
    for (let e = 0; e < t; e++) {
      f.set(H(0), 64), f.set(H(e), 68);
      let t = e * m,
        a = yield B(p, f, 1024);
      l.writeMemory(a, 1024 * t), t += 1, f.set(H(1), 64), a = yield B(p, f, 1024), l.writeMemory(a, 1024 * t);
    }
    const b = new Uint8Array(1024);
    (0,_WASMInterface_4e8d37b8_mjs__WEBPACK_IMPORTED_MODULE_1__.w)(b, l.calculate(new Uint8Array([]), d));
    const S = yield B(p, b, r);
    if ("hex" === e.outputType) {
      const e = new Uint8Array(2 * r);
      return (0,_WASMInterface_4e8d37b8_mjs__WEBPACK_IMPORTED_MODULE_1__.a)(e, S, r);
    }
    return "encoded" === e.outputType ? function (e, t, a) {
      const r = [`m=${t.memorySize}`, `t=${t.iterations}`, `p=${t.parallelism}`].join(",");
      return `$argon2${t.hashType}$v=19$${r}$${(0,_WASMInterface_4e8d37b8_mjs__WEBPACK_IMPORTED_MODULE_1__.f)(e, !1)}$${(0,_WASMInterface_4e8d37b8_mjs__WEBPACK_IMPORTED_MODULE_1__.f)(a, !1)}`;
    }(n, e, S) : S;
  });
  return _F.apply(this, arguments);
}
const L = e => {
  if (!e || "object" != typeof e) throw new Error("Invalid options parameter. It requires an object.");
  if (!e.password) throw new Error("Password must be specified");
  if (e.password = (0,_WASMInterface_4e8d37b8_mjs__WEBPACK_IMPORTED_MODULE_1__.g)(e.password), e.password.length < 1) throw new Error("Password must be specified");
  if (!e.salt) throw new Error("Salt must be specified");
  if (e.salt = (0,_WASMInterface_4e8d37b8_mjs__WEBPACK_IMPORTED_MODULE_1__.g)(e.salt), e.salt.length < 8) throw new Error("Salt should be at least 8 bytes long");
  if (!Number.isInteger(e.iterations) || e.iterations < 1) throw new Error("Iterations should be a positive number");
  if (!Number.isInteger(e.parallelism) || e.parallelism < 1) throw new Error("Parallelism should be a positive number");
  if (!Number.isInteger(e.hashLength) || e.hashLength < 4) throw new Error("Hash length should be at least 4 bytes.");
  if (!Number.isInteger(e.memorySize)) throw new Error("Memory size should be specified.");
  if (e.memorySize < 8 * e.parallelism) throw new Error("Memory size should be at least 8 * parallelism.");
  if (void 0 === e.outputType && (e.outputType = "hex"), !["hex", "binary", "encoded"].includes(e.outputType)) throw new Error(`Insupported output type ${e.outputType}. Valid values: ['hex', 'binary', 'encoded']`);
};
function N(_x7) {
  return _N.apply(this, arguments);
}
function _N() {
  _N = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (e) {
    return L(e), F({
      ...e,
      hashType: "i"
    });
  });
  return _N.apply(this, arguments);
}
function D(_x8) {
  return _D.apply(this, arguments);
}
function _D() {
  _D = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (e) {
    return L(e), F({
      ...e,
      hashType: "id"
    });
  });
  return _D.apply(this, arguments);
}
function V(_x9) {
  return _V.apply(this, arguments);
}
function _V() {
  _V = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (e) {
    return L(e), F({
      ...e,
      hashType: "d"
    });
  });
  return _V.apply(this, arguments);
}
function q(_x10) {
  return _q.apply(this, arguments);
}
function _q() {
  _q = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (e) {
    (e => {
      if (!e || "object" != typeof e) throw new Error("Invalid options parameter. It requires an object.");
      if (void 0 === e.hash || "string" != typeof e.hash) throw new Error("Hash should be specified");
    })(e);
    const t = ((e, t) => {
      const a = t.match(/^\$argon2(id|i|d)\$v=([0-9]+)\$((?:[mtp]=[0-9]+,){2}[mtp]=[0-9]+)\$([A-Za-z0-9+/]+)\$([A-Za-z0-9+/]+)$/);
      if (!a) throw new Error("Invalid hash");
      const [, r, s, i, n, o] = a;
      if ("19" !== s) throw new Error(`Unsupported version: ${s}`);
      const c = {},
        u = {
          m: "memorySize",
          p: "parallelism",
          t: "iterations"
        };
      return i.split(",").forEach(e => {
        const [t, a] = e.split("=");
        c[u[t]] = parseInt(a, 10);
      }), {
        ...c,
        password: e,
        hashType: r,
        salt: (0,_WASMInterface_4e8d37b8_mjs__WEBPACK_IMPORTED_MODULE_1__.d)(n),
        hashLength: (0,_WASMInterface_4e8d37b8_mjs__WEBPACK_IMPORTED_MODULE_1__.e)(o),
        outputType: "encoded"
      };
    })(e.password, e.hash);
    L(t);
    const a = e.hash.lastIndexOf("$") + 1;
    return (yield F(t)).substring(a) === e.hash.substring(a);
  });
  return _q.apply(this, arguments);
}
const C = (0,_WASMInterface_4e8d37b8_mjs__WEBPACK_IMPORTED_MODULE_1__.c)("bcrypt", 0);
function K(_x11) {
  return _K.apply(this, arguments);
}
function _K() {
  _K = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (e) {
    return (e => {
      if (!e || "object" != typeof e) throw new Error("Invalid options parameter. It requires an object.");
      if (!Number.isInteger(e.costFactor) || e.costFactor < 4 || e.costFactor > 31) throw new Error("Cost factor should be a number between 4 and 31");
      if (e.password = (0,_WASMInterface_4e8d37b8_mjs__WEBPACK_IMPORTED_MODULE_1__.g)(e.password), e.password.length < 1) throw new Error("Password should be at least 1 byte long");
      if (e.password.length > 72) throw new Error("Password should be at most 72 bytes long");
      if (e.salt = (0,_WASMInterface_4e8d37b8_mjs__WEBPACK_IMPORTED_MODULE_1__.g)(e.salt), 16 !== e.salt.length) throw new Error("Salt should be 16 bytes long");
      if (void 0 === e.outputType && (e.outputType = "encoded"), !["hex", "binary", "encoded"].includes(e.outputType)) throw new Error(`Insupported output type ${e.outputType}. Valid values: ['hex', 'binary', 'encoded']`);
    })(e), function () {
      var _ref34 = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (e) {
        const {
            costFactor: t,
            password: a,
            salt: r
          } = e,
          s = yield C();
        s.writeMemory((0,_WASMInterface_4e8d37b8_mjs__WEBPACK_IMPORTED_MODULE_1__.g)(r), 0);
        const n = (0,_WASMInterface_4e8d37b8_mjs__WEBPACK_IMPORTED_MODULE_1__.g)(a);
        s.writeMemory(n, 16);
        const o = "encoded" === e.outputType ? 1 : 0;
        s.getExports().bcrypt(n.length, t, o);
        const c = s.getMemory();
        if ("encoded" === e.outputType) return (0,_WASMInterface_4e8d37b8_mjs__WEBPACK_IMPORTED_MODULE_1__.i)(c, 60);
        if ("hex" === e.outputType) {
          const e = new Uint8Array(48);
          return (0,_WASMInterface_4e8d37b8_mjs__WEBPACK_IMPORTED_MODULE_1__.a)(e, c, 24);
        }
        return c.slice(0, 24);
      });
      return function (_x28) {
        return _ref34.apply(this, arguments);
      };
    }()(e);
  });
  return _K.apply(this, arguments);
}
const R = e => {
  if (!e || "object" != typeof e) throw new Error("Invalid options parameter. It requires an object.");
  if (void 0 === e.hash || "string" != typeof e.hash) throw new Error("Hash should be specified");
  if (60 !== e.hash.length) throw new Error("Hash should be 60 bytes long");
  if (t = e.hash, !/^\$2[axyb]\$[0-3][0-9]\$[./A-Za-z0-9]{53}$/.test(t) || "0" === t[4] && parseInt(t[5], 10) < 4 || "3" === t[4] && parseInt(t[5], 10) > 1) throw new Error("Invalid hash");
  var t;
  if (e.password = (0,_WASMInterface_4e8d37b8_mjs__WEBPACK_IMPORTED_MODULE_1__.g)(e.password), e.password.length < 1) throw new Error("Password should be at least 1 byte long");
  if (e.password.length > 72) throw new Error("Password should be at most 72 bytes long");
};
function Z(_x12) {
  return _Z.apply(this, arguments);
}
function _Z() {
  _Z = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (e) {
    R(e);
    const {
        hash: t,
        password: a
      } = e,
      r = yield C();
    r.writeMemory((0,_WASMInterface_4e8d37b8_mjs__WEBPACK_IMPORTED_MODULE_1__.g)(t), 0);
    const s = (0,_WASMInterface_4e8d37b8_mjs__WEBPACK_IMPORTED_MODULE_1__.g)(a);
    return r.writeMemory(s, 60), !!r.getExports().bcrypt_verify(s.length);
  });
  return _Z.apply(this, arguments);
}
const O = new Map(),
  W = a => {
    (0,_WASMInterface_4e8d37b8_mjs__WEBPACK_IMPORTED_MODULE_1__.v)(a, 256);
    const r = a / 8;
    let s = O.get(r);
    return void 0 === s && (s = (0,_WASMInterface_4e8d37b8_mjs__WEBPACK_IMPORTED_MODULE_1__.c)("blake2s", r), O.set(r, s)), s;
  },
  _ = (e, t) => {
    let a,
      r = e;
    if (void 0 !== t) {
      if (a = (0,_WASMInterface_4e8d37b8_mjs__WEBPACK_IMPORTED_MODULE_1__.g)(t), a.length > 32) throw new Error("Max key length is 32 bytes");
      r = (0,_WASMInterface_4e8d37b8_mjs__WEBPACK_IMPORTED_MODULE_1__.b)(e, a.length);
    }
    return {
      keyBuffer: a,
      initParam: r
    };
  },
  G = /*#__PURE__*/function () {
    var _ref5 = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (e, t = 256, a) {
      const r = yield W(t)(),
        {
          keyBuffer: s,
          initParam: i
        } = _(t, a);
      return i > 512 && r.writeMemory(s), r.calculate(e, i);
    });
    return function G(_x13) {
      return _ref5.apply(this, arguments);
    };
  }(),
  J = /*#__PURE__*/function () {
    var _ref6 = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (e = 256, t) {
      return Q(e, t, yield W(e)());
    });
    return function J() {
      return _ref6.apply(this, arguments);
    };
  }(),
  Q = (e = 256, t, a = W(e).wasm) => {
    const {
        keyBuffer: r,
        initParam: s
      } = _(e, t),
      i = e / 8;
    s > 512 && a.writeMemory(r), a.init(s);
    const n = {
      init: s > 512 ? () => (a.writeMemory(r), a.init(s), n) : () => (a.init(s), n),
      update: e => (a.update(e), n),
      digest: e => a.digest(e),
      save: () => a.save(),
      load: e => (a.load(e), n),
      blockSize: 64,
      digestSize: i
    };
    return n;
  },
  X = new Map(),
  Y = a => {
    (0,_WASMInterface_4e8d37b8_mjs__WEBPACK_IMPORTED_MODULE_1__.v)(a, 1 / 0);
    const r = a / 8;
    let s = X.get(r);
    return void 0 === s && (s = (0,_WASMInterface_4e8d37b8_mjs__WEBPACK_IMPORTED_MODULE_1__.c)("blake3", r), X.set(r, s)), s;
  },
  ee = e => {
    let t,
      a = 0;
    if (void 0 !== e) {
      if (t = (0,_WASMInterface_4e8d37b8_mjs__WEBPACK_IMPORTED_MODULE_1__.g)(e), 32 !== t.length) throw new Error("Key length must be exactly 32 bytes");
      a = 32;
    }
    return {
      keyBuffer: t,
      initParam: a
    };
  },
  te = /*#__PURE__*/function () {
    var _ref7 = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (e, t = 256, a) {
      const r = yield Y(t)(),
        {
          keyBuffer: s,
          initParam: i
        } = ee(a);
      return 32 === i && r.writeMemory(s), r.calculate(e, i, t / 8);
    });
    return function te(_x14) {
      return _ref7.apply(this, arguments);
    };
  }(),
  ae = /*#__PURE__*/function () {
    var _ref8 = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (e = 256, t) {
      return re(e, t, yield Y(e)());
    });
    return function ae() {
      return _ref8.apply(this, arguments);
    };
  }(),
  re = (e = 256, t, a = Y(e).wasm) => {
    const {
        keyBuffer: r,
        initParam: s
      } = ee(t),
      i = e / 8;
    32 === s && a.writeMemory(r), a.init(s);
    const n = {
      init: 32 === s ? () => (a.writeMemory(r), a.init(s), n) : () => (a.init(s), n),
      update: e => (a.update(e), n),
      digest: e => a.digest(e, i),
      save: () => a.save(),
      load: e => (a.load(e), n),
      blockSize: 64,
      digestSize: i
    };
    return n;
  },
  se = (0,_WASMInterface_4e8d37b8_mjs__WEBPACK_IMPORTED_MODULE_1__.c)("crc32", 4),
  ie = /*#__PURE__*/function () {
    var _ref9 = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (e) {
      return (yield se()).calculate(e, 3988292384);
    });
    return function ie(_x15) {
      return _ref9.apply(this, arguments);
    };
  }(),
  ne = /*#__PURE__*/function () {
    var _ref10 = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      return oe(yield se());
    });
    return function ne() {
      return _ref10.apply(this, arguments);
    };
  }(),
  oe = (e = se.wasm) => {
    e.init(3988292384);
    const t = {
      init: () => (e.init(3988292384), t),
      update: a => (e.update(a), t),
      digest: t => e.digest(t),
      save: () => e.save(),
      load: a => (e.load(a), t),
      blockSize: 4,
      digestSize: 4
    };
    return t;
  },
  ce = /*#__PURE__*/function () {
    var _ref11 = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (e) {
      return (yield se()).calculate(e, 2197175160);
    });
    return function ce(_x16) {
      return _ref11.apply(this, arguments);
    };
  }(),
  ue = /*#__PURE__*/function () {
    var _ref12 = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      return de(yield se());
    });
    return function ue() {
      return _ref12.apply(this, arguments);
    };
  }(),
  de = (e = se.wasm) => {
    e.init(2197175160);
    const t = {
      init: () => (e.init(2197175160), t),
      update: a => (e.update(a), t),
      digest: t => e.digest(t),
      save: () => e.save(),
      load: a => (e.load(a), t),
      blockSize: 4,
      digestSize: 4
    };
    return t;
  },
  le = (0,_WASMInterface_4e8d37b8_mjs__WEBPACK_IMPORTED_MODULE_1__.c)("md4", 16),
  we = /*#__PURE__*/function () {
    var _ref13 = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (e) {
      return (yield le()).calculate(e);
    });
    return function we(_x17) {
      return _ref13.apply(this, arguments);
    };
  }(),
  pe = /*#__PURE__*/function () {
    var _ref14 = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      return ye(yield le());
    });
    return function pe() {
      return _ref14.apply(this, arguments);
    };
  }(),
  ye = (e = le.wasm) => {
    e.init();
    const t = {
      init: () => (e.init(), t),
      update: a => (e.update(a), t),
      digest: t => e.digest(t),
      save: () => e.save(),
      load: a => (e.load(a), t),
      blockSize: 64,
      digestSize: 16
    };
    return t;
  },
  he = (0,_WASMInterface_4e8d37b8_mjs__WEBPACK_IMPORTED_MODULE_1__.c)("md5", 16),
  me = /*#__PURE__*/function () {
    var _ref15 = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (e) {
      return (yield he()).calculate(e);
    });
    return function me(_x18) {
      return _ref15.apply(this, arguments);
    };
  }(),
  fe = /*#__PURE__*/function () {
    var _ref16 = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      return ge(yield he());
    });
    return function fe() {
      return _ref16.apply(this, arguments);
    };
  }(),
  ge = (e = he.wasm) => {
    e.init();
    const t = {
      init: () => (e.init(), t),
      update: a => (e.update(a), t),
      digest: t => e.digest(t),
      save: () => e.save(),
      load: a => (e.load(a), t),
      blockSize: 64,
      digestSize: 16
    };
    return t;
  },
  be = (0,_WASMInterface_4e8d37b8_mjs__WEBPACK_IMPORTED_MODULE_1__.c)("scrypt", 0),
  Se = (e, t, a = be.wasm) => {
    const {
        costFactor: r,
        blockSize: s,
        parallelism: i,
        hashLength: n
      } = e,
      o = (0,_pbkdf2_cdbc1a49_mjs__WEBPACK_IMPORTED_MODULE_4__.p)({
        password: e.password,
        salt: e.salt,
        iterations: 1,
        hashLength: 128 * s * i,
        hashFunction: t,
        outputType: "binary"
      }),
      c = 128 * s * r,
      d = 256 * s;
    a.setMemorySize(o.length + c + d), a.writeMemory(o, 0), a.getExports().scrypt(s, r, i);
    const l = a.getMemory().subarray(0, 128 * s * i),
      w = (0,_pbkdf2_cdbc1a49_mjs__WEBPACK_IMPORTED_MODULE_4__.p)({
        password: e.password,
        salt: l,
        iterations: 1,
        hashLength: n,
        hashFunction: t,
        outputType: "binary"
      });
    if ("hex" === e.outputType) {
      const e = new Uint8Array(2 * n);
      return (0,_WASMInterface_4e8d37b8_mjs__WEBPACK_IMPORTED_MODULE_1__.a)(e, w, n);
    }
    return w;
  },
  ve = e => {
    if (!e || "object" != typeof e) throw new Error("Invalid options parameter. It requires an object.");
    if (!Number.isInteger(e.blockSize) || e.blockSize < 1) throw new Error("Block size should be a positive number");
    if (!Number.isInteger(e.costFactor) || e.costFactor < 2 || !(t = e.costFactor) || t & t - 1) throw new Error("Cost factor should be a power of 2, greater than 1");
    var t;
    if (!Number.isInteger(e.parallelism) || e.parallelism < 1) throw new Error("Parallelism should be a positive number");
    if (!Number.isInteger(e.hashLength) || e.hashLength < 1) throw new Error("Hash length should be a positive number.");
    if (void 0 === e.outputType && (e.outputType = "hex"), !["hex", "binary"].includes(e.outputType)) throw new Error(`Insupported output type ${e.outputType}. Valid values: ['hex', 'binary']`);
  },
  ze = /*#__PURE__*/function () {
    var _ref17 = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (e) {
      return ve(e), Se(e, yield (0,_sha256_d88873b6_mjs__WEBPACK_IMPORTED_MODULE_6__.a)(), yield be());
    });
    return function ze(_x19) {
      return _ref17.apply(this, arguments);
    };
  }(),
  ke = e => (ve(e), Se(e, (0,_sha256_d88873b6_mjs__WEBPACK_IMPORTED_MODULE_6__.c)(), be.wasm)),
  Me = (0,_WASMInterface_4e8d37b8_mjs__WEBPACK_IMPORTED_MODULE_1__.c)("sha256", 28),
  Ee = /*#__PURE__*/function () {
    var _ref18 = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (e) {
      return (yield Me()).calculate(e, 224);
    });
    return function Ee(_x20) {
      return _ref18.apply(this, arguments);
    };
  }(),
  Ie = /*#__PURE__*/function () {
    var _ref19 = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      return xe(yield Me());
    });
    return function Ie() {
      return _ref19.apply(this, arguments);
    };
  }(),
  xe = (e = Me.wasm) => {
    e.init(224);
    const t = {
      init: () => (e.init(224), t),
      update: a => (e.update(a), t),
      digest: t => e.digest(t),
      save: () => e.save(),
      load: a => (e.load(a), t),
      blockSize: 64,
      digestSize: 28
    };
    return t;
  },
  Ae = (0,_WASMInterface_4e8d37b8_mjs__WEBPACK_IMPORTED_MODULE_1__.c)("sha512", 48),
  Te = /*#__PURE__*/function () {
    var _ref20 = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (e) {
      return (yield Ae()).calculate(e, 384);
    });
    return function Te(_x21) {
      return _ref20.apply(this, arguments);
    };
  }(),
  $e = /*#__PURE__*/function () {
    var _ref21 = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      return je(yield Ae());
    });
    return function $e() {
      return _ref21.apply(this, arguments);
    };
  }(),
  je = (e = Ae.wasm) => {
    e.init(384);
    const t = {
      init: () => (e.init(384), t),
      update: a => (e.update(a), t),
      digest: t => e.digest(t),
      save: () => e.save(),
      load: a => (e.load(a), t),
      blockSize: 128,
      digestSize: 48
    };
    return t;
  },
  Pe = (0,_WASMInterface_4e8d37b8_mjs__WEBPACK_IMPORTED_MODULE_1__.c)("sm3", 32),
  Ue = /*#__PURE__*/function () {
    var _ref22 = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (e) {
      return (yield Pe()).calculate(e);
    });
    return function Ue(_x22) {
      return _ref22.apply(this, arguments);
    };
  }(),
  He = /*#__PURE__*/function () {
    var _ref23 = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      return Be(yield Pe());
    });
    return function He() {
      return _ref23.apply(this, arguments);
    };
  }(),
  Be = (e = Pe.wasm) => {
    e.init();
    const t = {
      init: () => (e.init(), t),
      update: a => (e.update(a), t),
      digest: t => e.digest(t),
      save: () => e.save(),
      load: a => (e.load(a), t),
      blockSize: 64,
      digestSize: 32
    };
    return t;
  },
  Fe = (0,_WASMInterface_4e8d37b8_mjs__WEBPACK_IMPORTED_MODULE_1__.c)("whirlpool", 64),
  Le = /*#__PURE__*/function () {
    var _ref24 = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (e) {
      return (yield Fe()).calculate(e);
    });
    return function Le(_x23) {
      return _ref24.apply(this, arguments);
    };
  }(),
  Ne = /*#__PURE__*/function () {
    var _ref25 = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      return De(yield Fe());
    });
    return function Ne() {
      return _ref25.apply(this, arguments);
    };
  }(),
  De = (e = Fe.wasm) => {
    e.init();
    const t = {
      init: () => (e.init(), t),
      update: a => (e.update(a), t),
      digest: t => e.digest(t),
      save: () => e.save(),
      load: a => (e.load(a), t),
      blockSize: 64,
      digestSize: 64
    };
    return t;
  },
  Ve = (0,_WASMInterface_4e8d37b8_mjs__WEBPACK_IMPORTED_MODULE_1__.c)("xxhash128", 4),
  qe = new ArrayBuffer(8),
  Ce = new Uint8Array(qe),
  Ke = new DataView(qe);
function Re(e, t) {
  Ke.setUint32(0, e, !0), Ke.setUint32(4, t, !0);
}
const Ze = /*#__PURE__*/function () {
    var _ref26 = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (e, t = 0, a = 0) {
      (0,_WASMInterface_4e8d37b8_mjs__WEBPACK_IMPORTED_MODULE_1__.h)(t, a), Re(t, a);
      const r = yield Ve();
      return r.writeMemory(Ce), r.calculate(e);
    });
    return function Ze(_x24) {
      return _ref26.apply(this, arguments);
    };
  }(),
  Oe = /*#__PURE__*/function () {
    var _ref27 = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (e = 0, t = 0) {
      return We(e, t, yield Ve());
    });
    return function Oe() {
      return _ref27.apply(this, arguments);
    };
  }(),
  We = (e = 0, t = 0, a = Ve.wasm) => {
    (0,_WASMInterface_4e8d37b8_mjs__WEBPACK_IMPORTED_MODULE_1__.h)(e, t), Re(e, t);
    const r = new Uint8Array(qe);
    a.writeMemory(r), a.init();
    const s = {
      init: () => (a.writeMemory(r), a.init(), s),
      update: e => (a.update(e), s),
      digest: e => a.digest(e),
      save: () => a.save(),
      load: e => (a.load(e), s),
      blockSize: 512,
      digestSize: 16
    };
    return s;
  },
  _e = (0,_WASMInterface_4e8d37b8_mjs__WEBPACK_IMPORTED_MODULE_1__.c)("xxhash3", 8),
  Ge = new ArrayBuffer(8),
  Je = new Uint8Array(Ge),
  Qe = new DataView(Ge);
function Xe(e, t) {
  Qe.setUint32(0, e, !0), Qe.setUint32(4, t, !0);
}
const Ye = /*#__PURE__*/function () {
    var _ref28 = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (e, t = 0, a = 0) {
      (0,_WASMInterface_4e8d37b8_mjs__WEBPACK_IMPORTED_MODULE_1__.h)(t, a), Xe(t, a);
      const r = yield _e();
      return r.writeMemory(Je), r.calculate(e);
    });
    return function Ye(_x25) {
      return _ref28.apply(this, arguments);
    };
  }(),
  et = /*#__PURE__*/function () {
    var _ref29 = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (e = 0, t = 0) {
      return tt(e, t, yield _e());
    });
    return function et() {
      return _ref29.apply(this, arguments);
    };
  }(),
  tt = (e = 0, t = 0, a = _e.wasm) => {
    (0,_WASMInterface_4e8d37b8_mjs__WEBPACK_IMPORTED_MODULE_1__.h)(e, t), Xe(e, t);
    const r = new Uint8Array(Ge);
    a.writeMemory(r), a.init();
    const s = {
      init: () => (a.writeMemory(r), a.init(), s),
      update: e => (a.update(e), s),
      digest: e => a.digest(e),
      save: () => a.save(),
      load: e => (a.load(e), s),
      blockSize: 512,
      digestSize: 8
    };
    return s;
  },
  at = (0,_WASMInterface_4e8d37b8_mjs__WEBPACK_IMPORTED_MODULE_1__.c)("xxhash32", 4),
  rt = /*#__PURE__*/function () {
    var _ref30 = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (e, t = 0) {
      return (0,_WASMInterface_4e8d37b8_mjs__WEBPACK_IMPORTED_MODULE_1__.j)(t), (yield at()).calculate(e, t);
    });
    return function rt(_x26) {
      return _ref30.apply(this, arguments);
    };
  }(),
  st = /*#__PURE__*/function () {
    var _ref31 = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (e = 0) {
      return it(e, yield at());
    });
    return function st() {
      return _ref31.apply(this, arguments);
    };
  }(),
  it = (e = 0, t = at.wasm) => {
    (0,_WASMInterface_4e8d37b8_mjs__WEBPACK_IMPORTED_MODULE_1__.j)(e), t.init(e);
    const a = {
      init: () => (t.init(e), a),
      update: e => (t.update(e), a),
      digest: e => t.digest(e),
      save: () => t.save(),
      load: e => (t.load(e), a),
      blockSize: 16,
      digestSize: 4
    };
    return a;
  },
  nt = (0,_WASMInterface_4e8d37b8_mjs__WEBPACK_IMPORTED_MODULE_1__.c)("xxhash64", 4),
  ot = new ArrayBuffer(8),
  ct = new Uint8Array(ot),
  ut = new DataView(ot);
function dt(e, t) {
  ut.setUint32(0, e, !0), ut.setUint32(4, t, !0);
}
const lt = /*#__PURE__*/function () {
    var _ref32 = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (e, t = 0, a = 0) {
      (0,_WASMInterface_4e8d37b8_mjs__WEBPACK_IMPORTED_MODULE_1__.h)(t, a), dt(t, a);
      const r = yield nt();
      return r.writeMemory(ct), r.calculate(e);
    });
    return function lt(_x27) {
      return _ref32.apply(this, arguments);
    };
  }(),
  wt = /*#__PURE__*/function () {
    var _ref33 = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (e = 0, t = 0) {
      return pt(e, t, yield nt());
    });
    return function wt() {
      return _ref33.apply(this, arguments);
    };
  }(),
  pt = (e = 0, t = 0, a = nt.wasm) => {
    (0,_WASMInterface_4e8d37b8_mjs__WEBPACK_IMPORTED_MODULE_1__.h)(e, t), dt(e, t);
    const r = new Uint8Array(ot);
    a.writeMemory(r), a.init();
    const s = {
      init: () => (a.writeMemory(r), a.init(), s),
      update: e => (a.update(e), s),
      digest: e => a.digest(e),
      save: () => a.save(),
      load: e => (a.load(e), s),
      blockSize: 32,
      digestSize: 8
    };
    return s;
  };


/***/ })

}]);
//# sourceMappingURL=apps_bfswap_src_assets_wallet-util_index-04b93bd8_mjs.js.map