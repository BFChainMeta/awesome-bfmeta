"use strict";
(self["webpackChunkbfswap"] = self["webpackChunkbfswap"] || []).push([["default-apps_bfswap_src_assets_wallet-util_p2wsh-046e722b_mjs"],{

/***/ 99920:
/*!****************************************************************!*\
  !*** ./apps/bfswap/src/assets/wallet-util/crypto-4198e1c6.mjs ***!
  \****************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   a: () => (/* binding */ o),
/* harmony export */   h: () => (/* binding */ e),
/* harmony export */   s: () => (/* binding */ a),
/* harmony export */   t: () => (/* binding */ s)
/* harmony export */ });
/* harmony import */ var _index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./index-d96f2042.mjs */ 99449);
/* harmony import */ var _ripemd160_fdc485e7_mjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./ripemd160-fdc485e7.mjs */ 10918);
/* harmony import */ var _sha256_d88873b6_mjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./sha256-d88873b6.mjs */ 98080);



function a(n) {
  return _index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_0__.B.from((0,_sha256_d88873b6_mjs__WEBPACK_IMPORTED_MODULE_2__.c)().update(n).digest());
}
function e(r) {
  return function (r) {
    return _index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_0__.B.from((0,_ripemd160_fdc485e7_mjs__WEBPACK_IMPORTED_MODULE_1__.c)().update(r).digest());
  }(a(r));
}
function o(t) {
  return a(a(t));
}
const c = Object.fromEntries(["BIP0340/challenge", "BIP0340/aux", "BIP0340/nonce", "TapLeaf", "TapBranch", "TapSighash", "TapTweak", "KeyAgg list", "KeyAgg coefficient"].map(n => {
  const r = a(_index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_0__.B.from(n));
  return [n, _index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_0__.B.concat([r, r])];
}));
function s(n, r) {
  return a(_index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_0__.B.concat([c[n], r]));
}


/***/ }),

/***/ 30274:
/*!******************************************************************!*\
  !*** ./apps/bfswap/src/assets/wallet-util/networks-0de0aba6.mjs ***!
  \******************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   b: () => (/* binding */ e),
/* harmony export */   r: () => (/* binding */ i),
/* harmony export */   t: () => (/* binding */ s)
/* harmony export */ });
const e = {
    messagePrefix: "Bitcoin Signed Message:\n",
    bech32: "bc",
    bip32: {
      public: 76067358,
      private: 76066276
    },
    pubKeyHash: 0,
    scriptHash: 5,
    wif: 128
  },
  i = {
    messagePrefix: "Bitcoin Signed Message:\n",
    bech32: "bcrt",
    bip32: {
      public: 70617039,
      private: 70615956
    },
    pubKeyHash: 111,
    scriptHash: 196,
    wif: 239
  },
  s = {
    messagePrefix: "Bitcoin Signed Message:\n",
    bech32: "tb",
    bip32: {
      public: 70617039,
      private: 70615956
    },
    pubKeyHash: 111,
    scriptHash: 196,
    wif: 239
  };


/***/ }),

/***/ 11051:
/*!***************************************************************!*\
  !*** ./apps/bfswap/src/assets/wallet-util/p2wsh-046e722b.mjs ***!
  \***************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   a: () => (/* binding */ B),
/* harmony export */   b: () => (/* binding */ N),
/* harmony export */   c: () => (/* binding */ b),
/* harmony export */   d: () => (/* binding */ A),
/* harmony export */   e: () => (/* binding */ W),
/* harmony export */   f: () => (/* binding */ w),
/* harmony export */   p: () => (/* binding */ l),
/* harmony export */   v: () => (/* binding */ m)
/* harmony export */ });
/* harmony import */ var _index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./index-d96f2042.mjs */ 99449);
/* harmony import */ var _index_4062991a_mjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./index-4062991a.mjs */ 22269);
/* harmony import */ var _crypto_4198e1c6_mjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./crypto-4198e1c6.mjs */ 99920);
/* harmony import */ var _networks_0de0aba6_mjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./networks-0de0aba6.mjs */ 30274);
/* harmony import */ var _script_c688360e_mjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./script-c688360e.mjs */ 97370);
/* harmony import */ var _typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./typeforce-a57e57b8.mjs */ 75473);






function w(e, t, r) {
  Object.defineProperty(e, t, {
    configurable: !0,
    enumerable: !0,
    get() {
      const e = r.call(this);
      return this[t] = e, e;
    },
    set(e) {
      Object.defineProperty(this, t, {
        configurable: !0,
        enumerable: !0,
        value: e,
        writable: !0
      });
    }
  });
}
function m(e) {
  let t;
  return () => (void 0 !== t || (t = e()), t);
}
const c = _script_c688360e_mjs__WEBPACK_IMPORTED_MODULE_4__.O;
function l(n, u) {
  if (!(n.address || n.hash || n.output || n.pubkey || n.input)) throw new TypeError("Not enough data");
  u = Object.assign({
    validate: !0
  }, u || {}), (0,_typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_5__.t)({
    network: _typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_5__.t.maybe(_typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_5__.t.Object),
    address: _typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_5__.t.maybe(_typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_5__.t.String),
    hash: _typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_5__.t.maybe(_typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_5__.t.BufferN(20)),
    output: _typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_5__.t.maybe(_typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_5__.t.BufferN(25)),
    pubkey: _typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_5__.t.maybe(_script_c688360e_mjs__WEBPACK_IMPORTED_MODULE_4__.i),
    signature: _typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_5__.t.maybe(_script_c688360e_mjs__WEBPACK_IMPORTED_MODULE_4__.d),
    input: _typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_5__.t.maybe(_typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_5__.t.Buffer)
  }, n);
  const p = m(() => {
      const e = _index_4062991a_mjs__WEBPACK_IMPORTED_MODULE_1__.b.decode(n.address);
      return {
        version: e.readUInt8(0),
        hash: e.slice(1)
      };
    }),
    f = m(() => (0,_script_c688360e_mjs__WEBPACK_IMPORTED_MODULE_4__.e)(n.input)),
    l = n.network || _networks_0de0aba6_mjs__WEBPACK_IMPORTED_MODULE_3__.b,
    y = {
      name: "p2pkh",
      network: l
    };
  if (w(y, "address", () => {
    if (!y.hash) return;
    const r = _index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_0__.B.allocUnsafe(21);
    return r.writeUInt8(l.pubKeyHash, 0), y.hash.copy(r, 1), _index_4062991a_mjs__WEBPACK_IMPORTED_MODULE_1__.b.encode(r);
  }), w(y, "hash", () => n.output ? n.output.slice(3, 23) : n.address ? p().hash : n.pubkey || y.pubkey ? (0,_crypto_4198e1c6_mjs__WEBPACK_IMPORTED_MODULE_2__.h)(n.pubkey || y.pubkey) : void 0), w(y, "output", () => {
    if (y.hash) return (0,_script_c688360e_mjs__WEBPACK_IMPORTED_MODULE_4__.c)([c.OP_DUP, c.OP_HASH160, y.hash, c.OP_EQUALVERIFY, c.OP_CHECKSIG]);
  }), w(y, "pubkey", () => {
    if (n.input) return f()[1];
  }), w(y, "signature", () => {
    if (n.input) return f()[0];
  }), w(y, "input", () => {
    if (n.pubkey && n.signature) return (0,_script_c688360e_mjs__WEBPACK_IMPORTED_MODULE_4__.c)([n.signature, n.pubkey]);
  }), w(y, "witness", () => {
    if (y.input) return [];
  }), u.validate) {
    let t = _index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_0__.B.from([]);
    if (n.address) {
      if (p().version !== l.pubKeyHash) throw new TypeError("Invalid version or Network mismatch");
      if (20 !== p().hash.length) throw new TypeError("Invalid address");
      t = p().hash;
    }
    if (n.hash) {
      if (t.length > 0 && !t.equals(n.hash)) throw new TypeError("Hash mismatch");
      t = n.hash;
    }
    if (n.output) {
      if (25 !== n.output.length || n.output[0] !== c.OP_DUP || n.output[1] !== c.OP_HASH160 || 20 !== n.output[2] || n.output[23] !== c.OP_EQUALVERIFY || n.output[24] !== c.OP_CHECKSIG) throw new TypeError("Output is invalid");
      const e = n.output.slice(3, 23);
      if (t.length > 0 && !t.equals(e)) throw new TypeError("Hash mismatch");
      t = e;
    }
    if (n.pubkey) {
      const e = (0,_crypto_4198e1c6_mjs__WEBPACK_IMPORTED_MODULE_2__.h)(n.pubkey);
      if (t.length > 0 && !t.equals(e)) throw new TypeError("Hash mismatch");
      t = e;
    }
    if (n.input) {
      const e = f();
      if (2 !== e.length) throw new TypeError("Input is invalid");
      if (!(0,_script_c688360e_mjs__WEBPACK_IMPORTED_MODULE_4__.d)(e[0])) throw new TypeError("Input has invalid signature");
      if (!(0,_script_c688360e_mjs__WEBPACK_IMPORTED_MODULE_4__.i)(e[1])) throw new TypeError("Input has invalid pubkey");
      if (n.signature && !n.signature.equals(e[0])) throw new TypeError("Signature mismatch");
      if (n.pubkey && !n.pubkey.equals(e[1])) throw new TypeError("Pubkey mismatch");
      const s = (0,_crypto_4198e1c6_mjs__WEBPACK_IMPORTED_MODULE_2__.h)(e[1]);
      if (t.length > 0 && !t.equals(s)) throw new TypeError("Hash mismatch");
    }
  }
  return Object.assign(y, n);
}
const y = _script_c688360e_mjs__WEBPACK_IMPORTED_MODULE_4__.O;
function b(n, o) {
  if (!(n.address || n.hash || n.output || n.redeem || n.input)) throw new TypeError("Not enough data");
  o = Object.assign({
    validate: !0
  }, o || {}), (0,_typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_5__.t)({
    network: _typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_5__.t.maybe(_typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_5__.t.Object),
    address: _typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_5__.t.maybe(_typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_5__.t.String),
    hash: _typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_5__.t.maybe(_typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_5__.t.BufferN(20)),
    output: _typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_5__.t.maybe(_typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_5__.t.BufferN(23)),
    redeem: _typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_5__.t.maybe({
      network: _typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_5__.t.maybe(_typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_5__.t.Object),
      output: _typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_5__.t.maybe(_typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_5__.t.Buffer),
      input: _typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_5__.t.maybe(_typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_5__.t.Buffer),
      witness: _typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_5__.t.maybe(_typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_5__.t.arrayOf(_typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_5__.t.Buffer))
    }),
    input: _typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_5__.t.maybe(_typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_5__.t.Buffer),
    witness: _typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_5__.t.maybe(_typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_5__.t.arrayOf(_typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_5__.t.Buffer))
  }, n);
  let i = n.network;
  i || (i = n.redeem && n.redeem.network || _networks_0de0aba6_mjs__WEBPACK_IMPORTED_MODULE_3__.b);
  const u = {
      network: i
    },
    f = m(() => {
      const e = _index_4062991a_mjs__WEBPACK_IMPORTED_MODULE_1__.b.decode(n.address);
      return {
        version: e.readUInt8(0),
        hash: e.slice(1)
      };
    }),
    c = m(() => (0,_script_c688360e_mjs__WEBPACK_IMPORTED_MODULE_4__.e)(n.input)),
    l = m(() => {
      const t = c(),
        r = t[t.length - 1];
      return {
        network: i,
        output: r === y.OP_FALSE ? _index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_0__.B.from([]) : r,
        input: (0,_script_c688360e_mjs__WEBPACK_IMPORTED_MODULE_4__.c)(t.slice(0, -1)),
        witness: n.witness || []
      };
    });
  if (w(u, "address", () => {
    if (!u.hash) return;
    const r = _index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_0__.B.allocUnsafe(21);
    return r.writeUInt8(u.network.scriptHash, 0), u.hash.copy(r, 1), _index_4062991a_mjs__WEBPACK_IMPORTED_MODULE_1__.b.encode(r);
  }), w(u, "hash", () => n.output ? n.output.slice(2, 22) : n.address ? f().hash : u.redeem && u.redeem.output ? (0,_crypto_4198e1c6_mjs__WEBPACK_IMPORTED_MODULE_2__.h)(u.redeem.output) : void 0), w(u, "output", () => {
    if (u.hash) return (0,_script_c688360e_mjs__WEBPACK_IMPORTED_MODULE_4__.c)([y.OP_HASH160, u.hash, y.OP_EQUAL]);
  }), w(u, "redeem", () => {
    if (n.input) return l();
  }), w(u, "input", () => {
    if (n.redeem && n.redeem.input && n.redeem.output) return (0,_script_c688360e_mjs__WEBPACK_IMPORTED_MODULE_4__.c)([].concat((0,_script_c688360e_mjs__WEBPACK_IMPORTED_MODULE_4__.e)(n.redeem.input), n.redeem.output));
  }), w(u, "witness", () => u.redeem && u.redeem.witness ? u.redeem.witness : u.input ? [] : void 0), w(u, "name", () => {
    const e = ["p2sh"];
    return void 0 !== u.redeem && void 0 !== u.redeem.name && e.push(u.redeem.name), e.join("-");
  }), o.validate) {
    let t = _index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_0__.B.from([]);
    if (n.address) {
      if (f().version !== i.scriptHash) throw new TypeError("Invalid version or Network mismatch");
      if (20 !== f().hash.length) throw new TypeError("Invalid address");
      t = f().hash;
    }
    if (n.hash) {
      if (t.length > 0 && !t.equals(n.hash)) throw new TypeError("Hash mismatch");
      t = n.hash;
    }
    if (n.output) {
      if (23 !== n.output.length || n.output[0] !== y.OP_HASH160 || 20 !== n.output[1] || n.output[22] !== y.OP_EQUAL) throw new TypeError("Output is invalid");
      const e = n.output.slice(2, 22);
      if (t.length > 0 && !t.equals(e)) throw new TypeError("Hash mismatch");
      t = e;
    }
    const s = e => {
      if (e.output) {
        const n = (0,_script_c688360e_mjs__WEBPACK_IMPORTED_MODULE_4__.e)(e.output);
        if (!n || n.length < 1) throw new TypeError("Redeem.output too short");
        const s = (0,_crypto_4198e1c6_mjs__WEBPACK_IMPORTED_MODULE_2__.h)(e.output);
        if (t.length > 0 && !t.equals(s)) throw new TypeError("Hash mismatch");
        t = s;
      }
      if (e.input) {
        const t = e.input.length > 0,
          r = e.witness && e.witness.length > 0;
        if (!t && !r) throw new TypeError("Empty input");
        if (t && r) throw new TypeError("Input and witness provided");
        if (t) {
          const t = (0,_script_c688360e_mjs__WEBPACK_IMPORTED_MODULE_4__.e)(e.input);
          if (!(0,_script_c688360e_mjs__WEBPACK_IMPORTED_MODULE_4__.f)(t)) throw new TypeError("Non push-only scriptSig");
        }
      }
    };
    if (n.input) {
      const t = c();
      if (!t || t.length < 1) throw new TypeError("Input too short");
      if (!_index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_0__.B.isBuffer(l().output)) throw new TypeError("Input is invalid");
      s(l());
    }
    if (n.redeem) {
      if (n.redeem.network && n.redeem.network !== i) throw new TypeError("Network mismatch");
      if (n.input) {
        const e = l();
        if (n.redeem.output && !n.redeem.output.equals(e.output)) throw new TypeError("Redeem.output mismatch");
        if (n.redeem.input && !n.redeem.input.equals(e.input)) throw new TypeError("Redeem.input mismatch");
      }
      s(n.redeem);
    }
    if (n.witness && n.redeem && n.redeem.witness && !function (e, t) {
      return e.length === t.length && e.every((e, r) => e.equals(t[r]));
    }(n.redeem.witness, n.witness)) throw new TypeError("Witness and redeem.witness mismatch");
  }
  return Object.assign(u, n);
}
var g = {};
Object.defineProperty(g, "__esModule", {
  value: !0
}), g.bech32m = g.bech32 = void 0;
const E = "qpzry9x8gf2tvdw0s3jn54khce6mua7l",
  k = {};
for (let e = 0; e < E.length; e++) {
  const t = E.charAt(e);
  k[t] = e;
}
function v(e) {
  const t = e >> 25;
  return (33554431 & e) << 5 ^ 996825010 & -(t >> 0 & 1) ^ 642813549 & -(t >> 1 & 1) ^ 513874426 & -(t >> 2 & 1) ^ 1027748829 & -(t >> 3 & 1) ^ 705979059 & -(t >> 4 & 1);
}
function T(e) {
  let t = 1;
  for (let r = 0; r < e.length; ++r) {
    const n = e.charCodeAt(r);
    if (n < 33 || n > 126) return "Invalid prefix (" + e + ")";
    t = v(t) ^ n >> 5;
  }
  t = v(t);
  for (let r = 0; r < e.length; ++r) {
    const n = e.charCodeAt(r);
    t = v(t) ^ 31 & n;
  }
  return t;
}
function O(e, t, r, n) {
  let s = 0,
    o = 0;
  const i = (1 << r) - 1,
    u = [];
  for (let n = 0; n < e.length; ++n) for (s = s << t | e[n], o += t; o >= r;) o -= r, u.push(s >> o & i);
  if (n) o > 0 && u.push(s << r - o & i);else {
    if (o >= t) return "Excess padding";
    if (s << r - o & i) return "Non-zero padding";
  }
  return u;
}
function j(e) {
  return O(e, 8, 5, !0);
}
function H(e) {
  const t = O(e, 5, 8, !1);
  if (Array.isArray(t)) return t;
}
function I(e) {
  const t = O(e, 5, 8, !1);
  if (Array.isArray(t)) return t;
  throw new Error(t);
}
function q(e) {
  let t;
  function r(e, r) {
    if (r = r || 90, e.length < 8) return e + " too short";
    if (e.length > r) return "Exceeds length limit";
    const n = e.toLowerCase(),
      s = e.toUpperCase();
    if (e !== n && e !== s) return "Mixed-case string " + e;
    const o = (e = n).lastIndexOf("1");
    if (-1 === o) return "No separator character for " + e;
    if (0 === o) return "Missing prefix for " + e;
    const i = e.slice(0, o),
      u = e.slice(o + 1);
    if (u.length < 6) return "Data too short";
    let a = T(i);
    if ("string" == typeof a) return a;
    const h = [];
    for (let e = 0; e < u.length; ++e) {
      const t = u.charAt(e),
        r = k[t];
      if (void 0 === r) return "Unknown character " + t;
      a = v(a) ^ r, e + 6 >= u.length || h.push(r);
    }
    return a !== t ? "Invalid checksum for " + e : {
      prefix: i,
      words: h
    };
  }
  return t = "bech32" === e ? 1 : 734539939, {
    decodeUnsafe: function (e, t) {
      const n = r(e, t);
      if ("object" == typeof n) return n;
    },
    decode: function (e, t) {
      const n = r(e, t);
      if ("object" == typeof n) return n;
      throw new Error(n);
    },
    encode: function (e, r, n) {
      if (n = n || 90, e.length + 7 + r.length > n) throw new TypeError("Exceeds length limit");
      let s = T(e = e.toLowerCase());
      if ("string" == typeof s) throw new Error(s);
      let o = e + "1";
      for (let e = 0; e < r.length; ++e) {
        const t = r[e];
        if (t >> 5 != 0) throw new Error("Non 5-bit word");
        s = v(s) ^ t, o += E.charAt(t);
      }
      for (let e = 0; e < 6; ++e) s = v(s);
      s ^= t;
      for (let e = 0; e < 6; ++e) {
        o += E.charAt(s >> 5 * (5 - e) & 31);
      }
      return o;
    },
    toWords: j,
    fromWordsUnsafe: H,
    fromWords: I
  };
}
g.bech32 = q("bech32"), g.bech32m = q("bech32m");
const N = g.bech32,
  B = g.bech32m,
  P = _script_c688360e_mjs__WEBPACK_IMPORTED_MODULE_4__.O,
  x = _index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_0__.B.alloc(0);
function A(t, n) {
  if (!(t.address || t.hash || t.output || t.pubkey || t.witness)) throw new TypeError("Not enough data");
  n = Object.assign({
    validate: !0
  }, n || {}), (0,_typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_5__.t)({
    address: _typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_5__.t.maybe(_typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_5__.t.String),
    hash: _typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_5__.t.maybe(_typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_5__.t.BufferN(20)),
    input: _typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_5__.t.maybe(_typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_5__.t.BufferN(0)),
    network: _typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_5__.t.maybe(_typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_5__.t.Object),
    output: _typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_5__.t.maybe(_typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_5__.t.BufferN(22)),
    pubkey: _typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_5__.t.maybe(_script_c688360e_mjs__WEBPACK_IMPORTED_MODULE_4__.i),
    signature: _typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_5__.t.maybe(_script_c688360e_mjs__WEBPACK_IMPORTED_MODULE_4__.d),
    witness: _typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_5__.t.maybe(_typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_5__.t.arrayOf(_typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_5__.t.Buffer))
  }, t);
  const u = m(() => {
      const r = N.decode(t.address),
        n = r.words.shift(),
        s = N.fromWords(r.words);
      return {
        version: n,
        prefix: r.prefix,
        data: _index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_0__.B.from(s)
      };
    }),
    h = t.network || _networks_0de0aba6_mjs__WEBPACK_IMPORTED_MODULE_3__.b,
    p = {
      name: "p2wpkh",
      network: h
    };
  if (w(p, "address", () => {
    if (!p.hash) return;
    const e = N.toWords(p.hash);
    return e.unshift(0), N.encode(h.bech32, e);
  }), w(p, "hash", () => t.output ? t.output.slice(2, 22) : t.address ? u().data : t.pubkey || p.pubkey ? (0,_crypto_4198e1c6_mjs__WEBPACK_IMPORTED_MODULE_2__.h)(t.pubkey || p.pubkey) : void 0), w(p, "output", () => {
    if (p.hash) return (0,_script_c688360e_mjs__WEBPACK_IMPORTED_MODULE_4__.c)([P.OP_0, p.hash]);
  }), w(p, "pubkey", () => t.pubkey ? t.pubkey : t.witness ? t.witness[1] : void 0), w(p, "signature", () => {
    if (t.witness) return t.witness[0];
  }), w(p, "input", () => {
    if (p.witness) return x;
  }), w(p, "witness", () => {
    if (t.pubkey && t.signature) return [t.signature, t.pubkey];
  }), n.validate) {
    let n = _index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_0__.B.from([]);
    if (t.address) {
      if (h && h.bech32 !== u().prefix) throw new TypeError("Invalid prefix or Network mismatch");
      if (0 !== u().version) throw new TypeError("Invalid address version");
      if (20 !== u().data.length) throw new TypeError("Invalid address data");
      n = u().data;
    }
    if (t.hash) {
      if (n.length > 0 && !n.equals(t.hash)) throw new TypeError("Hash mismatch");
      n = t.hash;
    }
    if (t.output) {
      if (22 !== t.output.length || t.output[0] !== P.OP_0 || 20 !== t.output[1]) throw new TypeError("Output is invalid");
      if (n.length > 0 && !n.equals(t.output.slice(2))) throw new TypeError("Hash mismatch");
      n = t.output.slice(2);
    }
    if (t.pubkey) {
      const e = (0,_crypto_4198e1c6_mjs__WEBPACK_IMPORTED_MODULE_2__.h)(t.pubkey);
      if (n.length > 0 && !n.equals(e)) throw new TypeError("Hash mismatch");
      if (n = e, !(0,_script_c688360e_mjs__WEBPACK_IMPORTED_MODULE_4__.i)(t.pubkey) || 33 !== t.pubkey.length) throw new TypeError("Invalid pubkey for p2wpkh");
    }
    if (t.witness) {
      if (2 !== t.witness.length) throw new TypeError("Witness is invalid");
      if (!(0,_script_c688360e_mjs__WEBPACK_IMPORTED_MODULE_4__.d)(t.witness[0])) throw new TypeError("Witness has invalid signature");
      if (!(0,_script_c688360e_mjs__WEBPACK_IMPORTED_MODULE_4__.i)(t.witness[1]) || 33 !== t.witness[1].length) throw new TypeError("Witness has invalid pubkey");
      if (t.signature && !t.signature.equals(t.witness[0])) throw new TypeError("Signature mismatch");
      if (t.pubkey && !t.pubkey.equals(t.witness[1])) throw new TypeError("Pubkey mismatch");
      const e = (0,_crypto_4198e1c6_mjs__WEBPACK_IMPORTED_MODULE_2__.h)(t.witness[1]);
      if (n.length > 0 && !n.equals(e)) throw new TypeError("Hash mismatch");
    }
  }
  return Object.assign(p, t);
}
const _ = _script_c688360e_mjs__WEBPACK_IMPORTED_MODULE_4__.O,
  U = _index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_0__.B.alloc(0);
function S(t) {
  return !(!_index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_0__.B.isBuffer(t) || 65 !== t.length || 4 !== t[0] || !(0,_script_c688360e_mjs__WEBPACK_IMPORTED_MODULE_4__.i)(t));
}
function W(t, r) {
  if (!(t.address || t.hash || t.output || t.redeem || t.witness)) throw new TypeError("Not enough data");
  r = Object.assign({
    validate: !0
  }, r || {}), (0,_typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_5__.t)({
    network: _typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_5__.t.maybe(_typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_5__.t.Object),
    address: _typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_5__.t.maybe(_typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_5__.t.String),
    hash: _typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_5__.t.maybe(_typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_5__.t.BufferN(32)),
    output: _typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_5__.t.maybe(_typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_5__.t.BufferN(34)),
    redeem: _typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_5__.t.maybe({
      input: _typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_5__.t.maybe(_typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_5__.t.Buffer),
      network: _typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_5__.t.maybe(_typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_5__.t.Object),
      output: _typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_5__.t.maybe(_typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_5__.t.Buffer),
      witness: _typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_5__.t.maybe(_typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_5__.t.arrayOf(_typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_5__.t.Buffer))
    }),
    input: _typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_5__.t.maybe(_typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_5__.t.BufferN(0)),
    witness: _typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_5__.t.maybe(_typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_5__.t.arrayOf(_typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_5__.t.Buffer))
  }, t);
  const o = m(() => {
      const r = N.decode(t.address),
        n = r.words.shift(),
        s = N.fromWords(r.words);
      return {
        version: n,
        prefix: r.prefix,
        data: _index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_0__.B.from(s)
      };
    }),
    i = m(() => (0,_script_c688360e_mjs__WEBPACK_IMPORTED_MODULE_4__.e)(t.redeem.input));
  let u = t.network;
  u || (u = t.redeem && t.redeem.network || _networks_0de0aba6_mjs__WEBPACK_IMPORTED_MODULE_3__.b);
  const c = {
    network: u
  };
  if (w(c, "address", () => {
    if (!c.hash) return;
    const e = N.toWords(c.hash);
    return e.unshift(0), N.encode(u.bech32, e);
  }), w(c, "hash", () => t.output ? t.output.slice(2) : t.address ? o().data : c.redeem && c.redeem.output ? (0,_crypto_4198e1c6_mjs__WEBPACK_IMPORTED_MODULE_2__.s)(c.redeem.output) : void 0), w(c, "output", () => {
    if (c.hash) return (0,_script_c688360e_mjs__WEBPACK_IMPORTED_MODULE_4__.c)([_.OP_0, c.hash]);
  }), w(c, "redeem", () => {
    if (t.witness) return {
      output: t.witness[t.witness.length - 1],
      input: U,
      witness: t.witness.slice(0, -1)
    };
  }), w(c, "input", () => {
    if (c.witness) return U;
  }), w(c, "witness", () => {
    if (t.redeem && t.redeem.input && t.redeem.input.length > 0 && t.redeem.output && t.redeem.output.length > 0) {
      const e = (0,_script_c688360e_mjs__WEBPACK_IMPORTED_MODULE_4__.g)(i());
      return c.redeem = Object.assign({
        witness: e
      }, t.redeem), c.redeem.input = U, [].concat(e, t.redeem.output);
    }
    if (t.redeem && t.redeem.output && t.redeem.witness) return [].concat(t.redeem.witness, t.redeem.output);
  }), w(c, "name", () => {
    const e = ["p2wsh"];
    return void 0 !== c.redeem && void 0 !== c.redeem.name && e.push(c.redeem.name), e.join("-");
  }), r.validate) {
    let r = _index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_0__.B.from([]);
    if (t.address) {
      if (o().prefix !== u.bech32) throw new TypeError("Invalid prefix or Network mismatch");
      if (0 !== o().version) throw new TypeError("Invalid address version");
      if (32 !== o().data.length) throw new TypeError("Invalid address data");
      r = o().data;
    }
    if (t.hash) {
      if (r.length > 0 && !r.equals(t.hash)) throw new TypeError("Hash mismatch");
      r = t.hash;
    }
    if (t.output) {
      if (34 !== t.output.length || t.output[0] !== _.OP_0 || 32 !== t.output[1]) throw new TypeError("Output is invalid");
      const e = t.output.slice(2);
      if (r.length > 0 && !r.equals(e)) throw new TypeError("Hash mismatch");
      r = e;
    }
    if (t.redeem) {
      if (t.redeem.network && t.redeem.network !== u) throw new TypeError("Network mismatch");
      if (t.redeem.input && t.redeem.input.length > 0 && t.redeem.witness && t.redeem.witness.length > 0) throw new TypeError("Ambiguous witness source");
      if (t.redeem.output) {
        if (0 === (0,_script_c688360e_mjs__WEBPACK_IMPORTED_MODULE_4__.e)(t.redeem.output).length) throw new TypeError("Redeem.output is invalid");
        const e = (0,_crypto_4198e1c6_mjs__WEBPACK_IMPORTED_MODULE_2__.s)(t.redeem.output);
        if (r.length > 0 && !r.equals(e)) throw new TypeError("Hash mismatch");
        r = e;
      }
      if (t.redeem.input && !(0,_script_c688360e_mjs__WEBPACK_IMPORTED_MODULE_4__.f)(i())) throw new TypeError("Non push-only scriptSig");
      if (t.witness && t.redeem.witness && !function (e, t) {
        return e.length === t.length && e.every((e, r) => e.equals(t[r]));
      }(t.witness, t.redeem.witness)) throw new TypeError("Witness and redeem.witness mismatch");
      if (t.redeem.input && i().some(S) || t.redeem.output && ((0,_script_c688360e_mjs__WEBPACK_IMPORTED_MODULE_4__.e)(t.redeem.output) || []).some(S)) throw new TypeError("redeem.input or redeem.output contains uncompressed pubkey");
    }
    if (t.witness && t.witness.length > 0) {
      const e = t.witness[t.witness.length - 1];
      if (t.redeem && t.redeem.output && !t.redeem.output.equals(e)) throw new TypeError("Witness and redeem.output mismatch");
      if (t.witness.some(S) || ((0,_script_c688360e_mjs__WEBPACK_IMPORTED_MODULE_4__.e)(e) || []).some(S)) throw new TypeError("Witness contains uncompressed pubkey");
    }
  }
  return Object.assign(c, t);
}


/***/ })

}]);
//# sourceMappingURL=default-apps_bfswap_src_assets_wallet-util_p2wsh-046e722b_mjs.js.map