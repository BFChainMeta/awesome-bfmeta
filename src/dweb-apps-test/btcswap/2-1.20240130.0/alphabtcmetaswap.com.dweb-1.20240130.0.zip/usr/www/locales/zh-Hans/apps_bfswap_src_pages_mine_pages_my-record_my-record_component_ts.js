"use strict";
(self["webpackChunkbfswap"] = self["webpackChunkbfswap"] || []).push([["apps_bfswap_src_pages_mine_pages_my-record_my-record_component_ts"],{

/***/ 26193:
/*!*********************************************************************************************!*\
  !*** ./apps/bfswap/src/components/swap-token-chain-icon/swap-token-chain-icon.component.ts ***!
  \*********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   SwapTokenChainIconComponent: () => (/* binding */ SwapTokenChainIconComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! tslib */ 90505);
/* harmony import */ var _bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @bnqkl/bnqkl-swap-core */ 70195);
/* harmony import */ var _services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ~services/wallet/wallet.helper */ 84813);
/* harmony import */ var _modules_comp_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ~modules/comp.module */ 58281);
/* harmony import */ var _modules_page_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ~modules/page.module */ 16381);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 61039);
/* harmony import */ var _icon_icon_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../icon/icon.component */ 18840);
var _class;







/** 封装一层的链和币种图标组件 直接传链名和币种即可 */
class SwapTokenChainIconComponent extends _modules_comp_module__WEBPACK_IMPORTED_MODULE_2__.CommonCompBase {
  constructor() {
    super(...arguments);
    /** 图标的大小 */
    this.iconSize = 'icon-4';
    /** 图标名称 */
    this.iconName = 'token-Default';
  }
  init() {
    const {
      swapChainName,
      swapCoinName
    } = this;
    if (swapChainName) {
      let iconName = 'token-Default';
      const chainName = swapChainName in _bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_0__.BNQKL_SWAP_CHAIN_NAME ? _services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_1__.NODE_CHAIN_NAME_TRANSFER[swapChainName] : swapChainName;
      const chainIcon = (0,_services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_1__.transferToChainIcon)(chainName);
      iconName = chainIcon;
      if (swapCoinName) {
        const coinIcon = (0,_services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_1__.transferToTokenIconBychainName)(chainName, swapCoinName);
        iconName = coinIcon;
      }
      this.iconName = iconName;
    }
  }
}
_class = SwapTokenChainIconComponent;
_class.ɵfac = /*@__PURE__*/(() => {
  let ɵSwapTokenChainIconComponent_BaseFactory;
  return function SwapTokenChainIconComponent_Factory(t) {
    return (ɵSwapTokenChainIconComponent_BaseFactory || (ɵSwapTokenChainIconComponent_BaseFactory = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵgetInheritedFactory"](_class)))(t || _class);
  };
})();
_class.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineComponent"]({
  type: _class,
  selectors: [["bs-swap-token-chain-icon"]],
  inputs: {
    iconSize: "iconSize",
    swapChainName: "swapChainName",
    swapCoinName: "swapCoinName"
  },
  standalone: true,
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵInheritDefinitionFeature"], _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵStandaloneFeature"]],
  decls: 1,
  vars: 3,
  consts: [[3, "name"]],
  template: function SwapTokenChainIconComponent_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](0, "bs-icon", 0);
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵclassMap"](ctx.iconSize);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("name", ctx.iconName);
    }
  },
  dependencies: [_modules_page_module__WEBPACK_IMPORTED_MODULE_3__.CommonPageModule, _icon_icon_component__WEBPACK_IMPORTED_MODULE_4__.IconComponent],
  styles: ["[_nghost-%COMP%] {\n  display: flex;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL2FwcHMvYmZzd2FwL3NyYy9jb21wb25lbnRzL3N3YXAtdG9rZW4tY2hhaW4taWNvbi9zd2FwLXRva2VuLWNoYWluLWljb24uY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxhQUFBO0FBQ0oiLCJzb3VyY2VzQ29udGVudCI6WyI6aG9zdHtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbn0iXSwic291cmNlUm9vdCI6IiJ9 */"],
  changeDetection: 0
});
(0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([SwapTokenChainIconComponent.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__metadata)("design:type", String)], SwapTokenChainIconComponent.prototype, "iconName", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([SwapTokenChainIconComponent.OnChanges(), (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__metadata)("design:returntype", void 0)], SwapTokenChainIconComponent.prototype, "init", null);

/***/ }),

/***/ 11342:
/*!*********************************************************************************************!*\
  !*** ./apps/bfswap/src/components/token-with-chain-icon/token-with-chain-icon.component.ts ***!
  \*********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   TokenWithnChainIconComponent: () => (/* binding */ TokenWithnChainIconComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! tslib */ 90505);
/* harmony import */ var _bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @bnqkl/bnqkl-swap-core */ 70195);
/* harmony import */ var _services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ~services/wallet/wallet.helper */ 84813);
/* harmony import */ var _modules_comp_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ~modules/comp.module */ 58281);
/* harmony import */ var _modules_page_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ~modules/page.module */ 16381);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 61039);
/* harmony import */ var _icon_icon_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../icon/icon.component */ 18840);
var _class;







function TokenWithnChainIconComponent_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](1, "bs-icon", 1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵstyleMap"](ctx_r0.sizeClass.chainTranslate);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵstyleMap"](ctx_r0.sizeClass.chainSize);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("name", ctx_r0.chainName);
  }
}
/** Token和chain组合图标 */
class TokenWithnChainIconComponent extends _modules_comp_module__WEBPACK_IMPORTED_MODULE_2__.CommonCompBase {
  constructor() {
    super(...arguments);
    /** token的大小 */
    this.tokenSize = 'icon-8';
    /** chain的大小 */
    this.chainSize = 'icon-4';
    /** 尺寸默认32 */
    this.size = 0;
    /** 尺寸样式 */
    this.sizeClass = {
      chainSize: 'font-size:1rem',
      coinSize: 'font-size:2rem',
      chainTranslate: 'transform: translate(6px,8px)'
    };
  }
  /** 初始化参数 */
  init() {
    this.handleIcon();
    this.handleSize();
  }
  /** 处理尺寸 */
  handleSize() {
    const {
      size
    } = this;
    if (size > 0) {
      const CHAINSIZE = 16;
      const COINSIZE = 32;
      const TRANSLATEX = 6;
      const TRANSLATEY = 8;
      const times = size / COINSIZE;
      this.sizeClass.chainSize = `font-size:${CHAINSIZE * times}px`;
      this.sizeClass.coinSize = `font-size:${COINSIZE * times}px`;
      this.sizeClass.chainTranslate = `transform: translate(${TRANSLATEX * times}px,${TRANSLATEY * times}px)`;
    }
  }
  /** 处理图标名称 */
  handleIcon() {
    const {
      swapChainName,
      swapCoinName
    } = this;
    if (swapChainName) {
      const chainName = swapChainName in _bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_0__.BNQKL_SWAP_CHAIN_NAME ? _services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_1__.NODE_CHAIN_NAME_TRANSFER[swapChainName] : swapChainName;
      const chainIcon = (0,_services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_1__.transferToChainIcon)(chainName);
      this.chainName = chainIcon;
      if (swapCoinName) {
        const coinIcon = (0,_services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_1__.transferToTokenIconBychainName)(chainName, swapCoinName);
        this.tokenName = coinIcon;
      }
    }
  }
}
_class = TokenWithnChainIconComponent;
_class.ɵfac = /*@__PURE__*/(() => {
  let ɵTokenWithnChainIconComponent_BaseFactory;
  return function TokenWithnChainIconComponent_Factory(t) {
    return (ɵTokenWithnChainIconComponent_BaseFactory || (ɵTokenWithnChainIconComponent_BaseFactory = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵgetInheritedFactory"](_class)))(t || _class);
  };
})();
_class.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineComponent"]({
  type: _class,
  selectors: [["bs-token-with-chain-icon"]],
  inputs: {
    tokenSize: "tokenSize",
    tokenName: "tokenName",
    chainSize: "chainSize",
    chainName: "chainName",
    size: "size",
    swapChainName: "swapChainName",
    swapCoinName: "swapCoinName"
  },
  standalone: true,
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵInheritDefinitionFeature"], _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵStandaloneFeature"]],
  decls: 3,
  vars: 4,
  consts: [[1, "relative", "flex", "items-center", "justify-center"], [3, "name"], ["class", "bg-blue-10 rounded-1 absolute bottom-0 right-0 flex  items-center justify-center border-[2px] border-white", 3, "style"], [1, "bg-blue-10", "rounded-1", "absolute", "bottom-0", "right-0", "flex", "items-center", "justify-center", "border-[2px]", "border-white"]],
  template: function TokenWithnChainIconComponent_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 0);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](1, "bs-icon", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](2, TokenWithnChainIconComponent_Conditional_2_Template, 2, 5, "div", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵstyleMap"](ctx.sizeClass.coinSize);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("name", ctx.tokenName);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵconditional"](2, ctx.chainName ? 2 : -1);
    }
  },
  dependencies: [_modules_page_module__WEBPACK_IMPORTED_MODULE_3__.CommonPageModule, _icon_icon_component__WEBPACK_IMPORTED_MODULE_4__.IconComponent],
  encapsulation: 2,
  changeDetection: 0
});
(0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([TokenWithnChainIconComponent.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__metadata)("design:type", Object)], TokenWithnChainIconComponent.prototype, "sizeClass", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([TokenWithnChainIconComponent.OnChanges(), (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__metadata)("design:returntype", void 0)], TokenWithnChainIconComponent.prototype, "init", null);

/***/ }),

/***/ 62284:
/*!***********************************************************************************!*\
  !*** ./apps/bfswap/src/pages/mine/pages/my-record-add/my-record-add.component.ts ***!
  \***********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   MyRecordAddComponent: () => (/* binding */ MyRecordAddComponent)
/* harmony export */ });
/* harmony import */ var D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 52542);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! tslib */ 90505);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! @angular/common */ 6729);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! @angular/core */ 61039);
/* harmony import */ var _bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @bnqkl/bnqkl-swap-core */ 70195);
/* harmony import */ var _components_token_with_chain_icon_token_with_chain_icon_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ~components/token-with-chain-icon/token-with-chain-icon.component */ 11342);
/* harmony import */ var _modules_page_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ~modules/page.module */ 16381);
/* harmony import */ var _services_liquidity_order_liquidity_order_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ~services/liquidity-order/liquidity-order.service */ 84435);
/* harmony import */ var _services_wallet_wallet_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ~services/wallet/wallet.service */ 54275);
/* harmony import */ var _pipes_record_state_color_record_state_color_pipe__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ~pipes/record-state-color/record-state-color.pipe */ 1256);
/* harmony import */ var _pipes_record_state_record_state_pipe__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ~pipes/record-state/record-state.pipe */ 7372);
/* harmony import */ var _services_liquidity_order_lquidity_order_type__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ~services/liquidity-order/lquidity-order.type */ 84601);
/* harmony import */ var _pipes_record_state_bg_record_state_bg_pipe__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ~pipes/record-state-bg/record-state-bg.pipe */ 84174);
/* harmony import */ var _components_swap_token_chain_icon_swap_token_chain_icon_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ~components/swap-token-chain-icon/swap-token-chain-icon.component */ 26193);
/* harmony import */ var _libs_bnf_components_pull_to_refresh_pull_to_refresh_directive__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../../../../../../libs/bnf/components/pull-to-refresh/pull-to-refresh.directive */ 97063);
/* harmony import */ var _libs_bnf_components_pull_to_refresh_pull_to_refresh_spinner_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../../../../../../libs/bnf/components/pull-to-refresh/pull-to-refresh-spinner.component */ 75387);
/* harmony import */ var _libs_bnf_components_infinite_scroll_infinite_scroll_spinner_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../../../../../../../libs/bnf/components/infinite-scroll/infinite-scroll-spinner.component */ 66560);
/* harmony import */ var _libs_bnf_components_infinite_scroll_infinite_scroll_directive__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../../../../../../../libs/bnf/components/infinite-scroll/infinite-scroll.directive */ 10320);
/* harmony import */ var _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ../../../../../../../libs/bnf/modules/page/common-page/common-page.component */ 62052);
/* harmony import */ var _components_icon_icon_component__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ../../../../components/icon/icon.component */ 18840);
/* harmony import */ var _pipes_color_color_pipe__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ../../../../pipes/color/color.pipe */ 67481);
/* harmony import */ var _libs_bnf_pipes_amountFixed_amount_fixed_pipe__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ../../../../../../../libs/bnf/pipes/amountFixed/amount-fixed.pipe */ 44070);

var _class;























const _c6 = a0 => ({
  color: a0
});
function MyRecordAddComponent_Conditional_2_Conditional_2_For_1_Case_30_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelement"](0, "bs-icon", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipe"](1, "color");
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpureFunction1"](4, _c6, _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipeBind1"](1, 2, "green-20")));
  }
}
function MyRecordAddComponent_Conditional_2_Conditional_2_For_1_Case_31_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelement"](0, "bs-icon", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipe"](1, "color");
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpureFunction1"](4, _c6, _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipeBind1"](1, 2, "fail")));
  }
}
function MyRecordAddComponent_Conditional_2_Conditional_2_For_1_Case_32_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelement"](0, "bs-icon", 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipe"](1, "color");
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpureFunction1"](4, _c6, _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipeBind1"](1, 2, "subtitle-2")));
  }
}
const _c7 = () => ({
  removeZero: true
});
function MyRecordAddComponent_Conditional_2_Conditional_2_For_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r15 = _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementStart"](0, "div", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵlistener"]("click", function MyRecordAddComponent_Conditional_2_Conditional_2_For_1_Template_div_click_0_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵrestoreView"](_r15);
      const item_r6 = restoredCtx.$implicit;
      const ctx_r14 = _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵnextContext"](3);
      return _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵresetView"](ctx_r14.jumpLiquidityDetail(item_r6.orderId));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementStart"](1, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipe"](2, "recordStateBg");
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelement"](3, "bs-token-with-chain-icon", 6)(4, "bs-token-with-chain-icon", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementStart"](5, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵi18n"](6, 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipe"](7, "recordStateColor");
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipe"](8, "recordState");
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelement"](9, "bs-icon", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementStart"](10, "div", 10)(11, "div", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵi18n"](12, 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementStart"](13, "div", 13)(14, "div", 14)(15, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtext"](16);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipe"](17, "amountFixed");
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelement"](18, "bs-swap-token-chain-icon", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementStart"](19, "div", 16)(20, "div", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtext"](21);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipe"](22, "amountFixed");
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelement"](23, "bs-swap-token-chain-icon", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementEnd"]()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementStart"](24, "div", 19)(25, "div", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵi18n"](26, 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementStart"](27, "div", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtext"](28);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipe"](29, "amountFixed");
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtemplate"](30, MyRecordAddComponent_Conditional_2_Conditional_2_For_1_Case_30_Template, 2, 6)(31, MyRecordAddComponent_Conditional_2_Conditional_2_For_1_Case_31_Template, 2, 6)(32, MyRecordAddComponent_Conditional_2_Conditional_2_For_1_Case_32_Template, 2, 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementStart"](33, "div", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtext"](34);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipe"](35, "date");
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const item_r6 = ctx.$implicit;
    const ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵnextContext"](3);
    let MyRecordAddComponent_Conditional_2_Conditional_2_For_1_contFlowTmp;
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵclassMapInterpolate1"]("flex items-center p-4  rounded-4 mb-3 ", _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipeBind1"](2, 20, item_r6.state), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵproperty"]("swapChainName", item_r6.anchorTran == null ? null : item_r6.anchorTran.chainName)("swapCoinName", item_r6.anchorTran == null ? null : item_r6.anchorTran.coinName);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵproperty"]("swapChainName", item_r6.quoteTran == null ? null : item_r6.quoteTran.chainName)("swapCoinName", item_r6.quoteTran == null ? null : item_r6.quoteTran.coinName);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵclassMapInterpolate1"]("mr-1 ml-auto text-[1rem] leading-4 ", _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipeBind1"](7, 22, item_r6.state), "");
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵi18nExp"](_angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipeBind2"](8, 24, item_r6.state, ctx_r5.RECORDTYPE));
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵi18nApply"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"](8);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipeBind3"](17, 27, item_r6.anchorTran == null ? null : item_r6.anchorTran.amount, 8, _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpureFunction0"](42, _c7)), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵproperty"]("swapCoinName", item_r6.anchorTran == null ? null : item_r6.anchorTran.coinName)("swapChainName", item_r6.anchorTran == null ? null : item_r6.anchorTran.chainName);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipeBind3"](22, 31, item_r6.quoteTran == null ? null : item_r6.quoteTran.amount, 8, _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpureFunction0"](43, _c7)), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵproperty"]("swapCoinName", item_r6.quoteTran == null ? null : item_r6.quoteTran.coinName)("swapChainName", item_r6.quoteTran == null ? null : item_r6.quoteTran.chainName);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtextInterpolate1"](" + ", _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipeBind3"](29, 35, item_r6.lpCoinsAmount, 8, _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpureFunction0"](44, _c7)), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵconditional"](30, (MyRecordAddComponent_Conditional_2_Conditional_2_For_1_contFlowTmp = item_r6.state) === ctx_r5.ORDERSTATE.SUCCESS ? 30 : MyRecordAddComponent_Conditional_2_Conditional_2_For_1_contFlowTmp === ctx_r5.ORDERSTATE.RETURN_COMPLETE ? 31 : 32);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtextInterpolate1"](" ", item_r6.startTime ? _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipeBind2"](35, 39, item_r6.startTime, "yyyy.MM.dd HH:mm") : "- -", " ");
  }
}
function MyRecordAddComponent_Conditional_2_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵrepeaterCreate"](0, MyRecordAddComponent_Conditional_2_Conditional_2_For_1_Template, 36, 45, "div", 26, _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵrepeaterTrackByIndex"]);
  }
  if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵrepeater"](ctx_r2.dataList);
  }
}
function MyRecordAddComponent_Conditional_2_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementStart"](0, "div", 27);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelement"](1, "img", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementStart"](2, "span", 29);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵi18n"](3, 30);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementEnd"]()();
  }
}
function MyRecordAddComponent_Conditional_2_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementStart"](0, "bn-infinite-scroll-spinner")(1, "span", 31);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵi18n"](2, 32);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementEnd"]()();
  }
}
function MyRecordAddComponent_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r17 = _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementStart"](0, "div", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵlistener"]("infinited$", function MyRecordAddComponent_Conditional_2_Template_div_infinited__0_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵrestoreView"](_r17);
      const ctx_r16 = _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵresetView"]($event.waitFor(ctx_r16.loadMore()));
    })("pulled$", function MyRecordAddComponent_Conditional_2_Template_div_pulled__0_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵrestoreView"](_r17);
      const ctx_r18 = _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵresetView"]($event.waitFor(ctx_r18.refresh()));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelement"](1, "bn-pull-to-refresh-spinner", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtemplate"](2, MyRecordAddComponent_Conditional_2_Conditional_2_Template, 2, 0)(3, MyRecordAddComponent_Conditional_2_Conditional_3_Template, 4, 0)(4, MyRecordAddComponent_Conditional_2_Conditional_4_Template, 3, 0, "bn-infinite-scroll-spinner");
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵproperty"]("hasMore", ctx_r0.hasMore)("emitDistance", 158)("maxDistance", 200);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵconditional"](2, ctx_r0.dataList.length ? 2 : 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵconditional"](4, ctx_r0.loading ? 4 : -1);
  }
}
function MyRecordAddComponent_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementStart"](0, "div", 33);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelement"](1, "img", 34);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementStart"](2, "div", 35);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵi18n"](3, 36);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementEnd"]()();
  }
}
/** 记录增加流动性组件 */
class MyRecordAddComponent extends _modules_page_module__WEBPACK_IMPORTED_MODULE_3__.CommonPageBase {
  constructor() {
    super(...arguments);
    this.DIRECTION = _services_liquidity_order_lquidity_order_type__WEBPACK_IMPORTED_MODULE_8__.$DIRECTION;
    /** 订单状态 */
    this.ORDERSTATE = {
      /** 成功 */
      SUCCESS: _bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_1__.ORDER_RECORD_STATUS.SUCCESS,
      /** 退款完成 */
      RETURN_COMPLETE: _bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_1__.ORDER_RECORD_STATUS.RETURN_COMPLETE
    };
    /** 记录的类型 */
    this.RECORDTYPE = _bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_1__.ORDER_RECORD_TYPES.ADD_LIQUIDITY;
    /** 钱包服务 */
    this.walletService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_19__.inject)(_services_wallet_wallet_service__WEBPACK_IMPORTED_MODULE_5__.WalletService);
    /** 订单服务 */
    this.orderService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_19__.inject)(_services_liquidity_order_liquidity_order_service__WEBPACK_IMPORTED_MODULE_4__.LiquidityOrderService);
    /** 已连接钱包 */
    this.connectedWallet = this.walletService.connectedWallet;
    /** loading */
    this.loading = false;
    /** 页数 */
    this.newestMaxIndex = 10000000000;
    /** 数据列表 */
    this.dataList = [];
    /** 页码 */
    this.pageSize = 10;
    /** 是否初始化 */
    this.init = false;
    /** 是否还有 */
    this.hasMore = true;
  }
  /** 跳转流动性详情页面 */
  jumpLiquidityDetail(orderId) {
    this.nav.routeTo('/mine/my-record-add-liquidity-detail', {
      orderId
    });
  }
  /** 加载更多 */
  loadMore() {
    return this.getList();
  }
  /** 下拉刷新 */
  refresh() {
    var _this = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this.init = false;
      _this.newestMaxIndex = 10000000000;
      _this.hasMore = true;
      _this.loading = false;
      _this.dataList = [];
      _this.getList();
    })();
  }
  /** 获取数据 */
  getList() {
    var _this2 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      var _this2$connectedWalle;
      const userId = (_this2$connectedWalle = _this2.connectedWallet) === null || _this2$connectedWalle === void 0 ? void 0 : _this2$connectedWalle.pmchainAddress;
      if (userId === undefined) {
        return;
      }
      const params = {
        userId,
        type: _bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_1__.ORDER_RECORD_TYPES.ADD_LIQUIDITY,
        maxIndex: _this2.newestMaxIndex,
        minIndex: 0,
        size: _this2.pageSize
      };
      if (_this2.hasMore === false) return;
      _this2.loading = true;
      const res = yield _this2.orderService.getPoolOrderHistoryListByUserId(params);
      if (res) {
        const {
          dataList,
          hasMore,
          maxIndex
        } = res;
        const list = dataList.map(data => {
          const extra = _this2.handleTran(data);
          return {
            ...data,
            ...extra
          };
        });
        _this2.loading = false;
        _this2.newestMaxIndex = maxIndex;
        _this2.hasMore = hasMore;
        _this2.dataList = [..._this2.dataList, ...list];
        _this2.init = true;
        _this2.cdRef.detectChanges();
      }
    })();
  }
  /** 处理交易的数据 */
  handleTran(data) {
    const {
      orderTransactionList,
      anchorTxId,
      quoteTxId
    } = data;
    const anchorTran = orderTransactionList.find(order => {
      return order.transactionId === anchorTxId;
    });
    const quoteTran = orderTransactionList.find(order => {
      return order.transactionId === quoteTxId;
    });
    let lpState;
    if (anchorTran && quoteTran) {
      lpState = this.handleLPState(anchorTran, quoteTran);
    }
    return {
      anchorTran,
      quoteTran,
      lpState
    };
  }
  /** 处理LPcoin获取状态 */
  handleLPState(anchorTran, quoteTran) {
    const {
      state: anchorState
    } = anchorTran;
    const {
      state: quoteState
    } = quoteTran;
    const success = anchorState === _bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_1__.TRANSACTION_STATUS.SUCCESS && quoteState === _bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_1__.TRANSACTION_STATUS.SUCCESS;
    return success ? "\u5DF2\u6536\u5230" : "\u672A\u83B7\u5F97";
  }
}
_class = MyRecordAddComponent;
_class.ɵfac = /*@__PURE__*/(() => {
  let ɵMyRecordAddComponent_BaseFactory;
  return function MyRecordAddComponent_Factory(t) {
    return (ɵMyRecordAddComponent_BaseFactory || (ɵMyRecordAddComponent_BaseFactory = _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵgetInheritedFactory"](_class)))(t || _class);
  };
})();
_class.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵdefineComponent"]({
  type: _class,
  selectors: [["bs-my-record-add"]],
  standalone: true,
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵInheritDefinitionFeature"], _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵStandaloneFeature"]],
  decls: 4,
  vars: 3,
  consts: () => {
    let i18n_0;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_7089857848655717121$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_RECORD_ADD_MY_RECORD_ADD_COMPONENT_TS____1 = goog.getMsg(" {$interpolation} ", {
        "interpolation": "\uFFFD0\uFFFD"
      }, {
        original_code: {
          "interpolation": "{{ item.state | recordState : RECORDTYPE }}"
        }
      });
      i18n_0 = MSG_EXTERNAL_7089857848655717121$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_RECORD_ADD_MY_RECORD_ADD_COMPONENT_TS____1;
    } else {
      i18n_0 = " " + "\uFFFD0\uFFFD" + " ";
    }
    let i18n_2;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_606155174839163394$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_RECORD_ADD_MY_RECORD_ADD_COMPONENT_TS____3 = goog.getMsg("\u589E\u52A0\u6570\u91CF");
      i18n_2 = MSG_EXTERNAL_606155174839163394$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_RECORD_ADD_MY_RECORD_ADD_COMPONENT_TS____3;
    } else {
      i18n_2 = "\u589E\u52A0\u6570\u91CF";
    }
    let i18n_4;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_2160098162517155843$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_RECORD_ADD_MY_RECORD_ADD_COMPONENT_TS____5 = goog.getMsg("\u5408\u7EA6\u6C60\u6743\u76CA");
      i18n_4 = MSG_EXTERNAL_2160098162517155843$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_RECORD_ADD_MY_RECORD_ADD_COMPONENT_TS____5;
    } else {
      i18n_4 = "\u5408\u7EA6\u6C60\u6743\u76CA";
    }
    let i18n_8;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_NO_RECORDS$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_RECORD_ADD_MY_RECORD_ADD_COMPONENT_TS___9 = goog.getMsg("No records");
      i18n_8 = MSG_EXTERNAL_NO_RECORDS$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_RECORD_ADD_MY_RECORD_ADD_COMPONENT_TS___9;
    } else {
      i18n_8 = "\u6CA1\u8BB0\u5F55";
    }
    let i18n_10;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_LOADING$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_RECORD_ADD_MY_RECORD_ADD_COMPONENT_TS___11 = goog.getMsg("Loading");
      i18n_10 = MSG_EXTERNAL_LOADING$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_RECORD_ADD_MY_RECORD_ADD_COMPONENT_TS___11;
    } else {
      i18n_10 = "\u52A0\u8F7D\u4E2D";
    }
    let i18n_12;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_7825757923954104189$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_RECORD_ADD_MY_RECORD_ADD_COMPONENT_TS__13 = goog.getMsg("\u83B7\u53D6\u6570\u636E\u4E2D");
      i18n_12 = MSG_EXTERNAL_7825757923954104189$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_RECORD_ADD_MY_RECORD_ADD_COMPONENT_TS__13;
    } else {
      i18n_12 = "\u83B7\u53D6\u6570\u636E\u4E2D";
    }
    return [[3, "hideHeader", "contentBackground"], [1, "h-full"], ["wPullToRefresh", "", "wInfiniteScroll", "", "class", "h-full overflow-y-scroll px-4 pt-2.5", 3, "hasMore", "emitDistance", "maxDistance"], ["wPullToRefresh", "", "wInfiniteScroll", "", 1, "h-full", "overflow-y-scroll", "px-4", "pt-2.5", 3, "hasMore", "emitDistance", "maxDistance", "infinited$", "pulled$"], [1, "text-title"], [1, "rounded-4", "mb-2", "bg-white", "px-0.5", "pb-4", "pt-0.5", 3, "click"], [3, "swapChainName", "swapCoinName"], [1, "ml-2", 3, "swapChainName", "swapCoinName"], i18n_0, ["name", "icon-chevron-right", 1, "text-subtitle-2", "text-xl"], [1, "mb-2", "flex", "items-center", "justify-between", "px-4"], [1, "text-subtitle-2", "text-xs"], i18n_2, [1, "text-title-10", "flex", "flex-col", "text-right", "font-semibold"], [1, "mb-1", "flex", "items-center", "justify-end"], [1, "ml-1", 3, "swapCoinName", "swapChainName"], [1, "flex", "items-center", "justify-end"], [1, "mr-1"], [3, "swapCoinName", "swapChainName"], [1, "mb-2", "flex", "items-center", "px-4"], i18n_4, [1, "text-title-10", "ml-auto", "mr-1", "font-semibold"], [1, "text-subtitle-2", "px-4", "text-xs"], ["name", "icon-check-circle-fill", 1, "text-lg"], ["name", "icon-waring-fill", 1, "text-lg"], ["name", "icon-timeclock-fill", 1, "text-lg"], ["class", "rounded-4 mb-2 bg-white px-0.5 pb-4 pt-0.5"], [1, "flex", "h-full", "w-full", "flex-col", "items-center", "justify-center"], ["src", "./assets/images/placeholder-3.png"], [1, "text-line", "text-sm", "text-gray-400"], i18n_8, [1, "text-sm"], i18n_10, [1, "absolute", "top-1/2", "flex", "w-full", "-translate-y-1/2", "flex-col", "items-center", "justify-center"], ["src", "./assets/images/order-ing.png", 1, "h-45", "w-60"], [1, "text-base-200"], i18n_12];
  },
  template: function MyRecordAddComponent_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementStart"](0, "common-page", 0)(1, "div", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtemplate"](2, MyRecordAddComponent_Conditional_2_Template, 5, 5, "div", 2)(3, MyRecordAddComponent_Conditional_3_Template, 4, 0);
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementEnd"]()();
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵproperty"]("hideHeader", true)("contentBackground", "#f6f7fc");
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵconditional"](2, ctx.init ? 2 : 3);
    }
  },
  dependencies: [_components_swap_token_chain_icon_swap_token_chain_icon_component__WEBPACK_IMPORTED_MODULE_10__.SwapTokenChainIconComponent, _pipes_record_state_color_record_state_color_pipe__WEBPACK_IMPORTED_MODULE_6__.RecordStateColorPipe, _pipes_record_state_bg_record_state_bg_pipe__WEBPACK_IMPORTED_MODULE_9__.RecordStateBgPipe, _pipes_record_state_record_state_pipe__WEBPACK_IMPORTED_MODULE_7__.RecordStatePipe, _modules_page_module__WEBPACK_IMPORTED_MODULE_3__.CommonPageModule, _libs_bnf_components_pull_to_refresh_pull_to_refresh_directive__WEBPACK_IMPORTED_MODULE_11__.PullToRefreshDirective, _libs_bnf_components_pull_to_refresh_pull_to_refresh_spinner_component__WEBPACK_IMPORTED_MODULE_12__.PullToRefreshSpinnerComponent, _libs_bnf_components_infinite_scroll_infinite_scroll_spinner_component__WEBPACK_IMPORTED_MODULE_13__.InfiniteScrollSpinnerComponent, _libs_bnf_components_infinite_scroll_infinite_scroll_directive__WEBPACK_IMPORTED_MODULE_14__.InfiniteScrollDirective, _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_15__.CommonPageComponent, _components_icon_icon_component__WEBPACK_IMPORTED_MODULE_16__.IconComponent, _angular_common__WEBPACK_IMPORTED_MODULE_20__.DatePipe, _pipes_color_color_pipe__WEBPACK_IMPORTED_MODULE_17__.ColorPipe, _libs_bnf_pipes_amountFixed_amount_fixed_pipe__WEBPACK_IMPORTED_MODULE_18__.AmountFixedPipe, _angular_common__WEBPACK_IMPORTED_MODULE_20__.CommonModule, _components_token_with_chain_icon_token_with_chain_icon_component__WEBPACK_IMPORTED_MODULE_2__.TokenWithnChainIconComponent],
  encapsulation: 2,
  changeDetection: 0
});
(0,tslib__WEBPACK_IMPORTED_MODULE_21__.__decorate)([MyRecordAddComponent.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_21__.__metadata)("design:type", Object)], MyRecordAddComponent.prototype, "connectedWallet", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_21__.__decorate)([MyRecordAddComponent.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_21__.__metadata)("design:type", Object)], MyRecordAddComponent.prototype, "loading", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_21__.__decorate)([MyRecordAddComponent.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_21__.__metadata)("design:type", Object)], MyRecordAddComponent.prototype, "newestMaxIndex", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_21__.__decorate)([MyRecordAddComponent.States(1), (0,tslib__WEBPACK_IMPORTED_MODULE_21__.__metadata)("design:type", Array)], MyRecordAddComponent.prototype, "dataList", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_21__.__decorate)([MyRecordAddComponent.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_21__.__metadata)("design:type", Object)], MyRecordAddComponent.prototype, "pageSize", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_21__.__decorate)([MyRecordAddComponent.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_21__.__metadata)("design:type", Object)], MyRecordAddComponent.prototype, "init", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_21__.__decorate)([MyRecordAddComponent.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_21__.__metadata)("design:type", Object)], MyRecordAddComponent.prototype, "hasMore", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_21__.__decorate)([MyRecordAddComponent.AfterViewInit(), (0,tslib__WEBPACK_IMPORTED_MODULE_21__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_21__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_21__.__metadata)("design:returntype", Promise)], MyRecordAddComponent.prototype, "getList", null);

/***/ }),

/***/ 30371:
/*!*****************************************************************************************!*\
  !*** ./apps/bfswap/src/pages/mine/pages/my-record-remove/my-record-remove.component.ts ***!
  \*****************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   MyRecordRemoveComponent: () => (/* binding */ MyRecordRemoveComponent)
/* harmony export */ });
/* harmony import */ var D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 52542);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! tslib */ 90505);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! @angular/common */ 6729);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! @angular/core */ 61039);
/* harmony import */ var _bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @bnqkl/bnqkl-swap-core */ 70195);
/* harmony import */ var _components_token_with_chain_icon_token_with_chain_icon_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ~components/token-with-chain-icon/token-with-chain-icon.component */ 11342);
/* harmony import */ var _modules_page_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ~modules/page.module */ 16381);
/* harmony import */ var _services_liquidity_order_liquidity_order_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ~services/liquidity-order/liquidity-order.service */ 84435);
/* harmony import */ var _services_wallet_wallet_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ~services/wallet/wallet.service */ 54275);
/* harmony import */ var _pipes_record_state_color_record_state_color_pipe__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ~pipes/record-state-color/record-state-color.pipe */ 1256);
/* harmony import */ var _pipes_record_state_record_state_pipe__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ~pipes/record-state/record-state.pipe */ 7372);
/* harmony import */ var _services_liquidity_order_lquidity_order_type__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ~services/liquidity-order/lquidity-order.type */ 84601);
/* harmony import */ var _pipes_record_state_bg_record_state_bg_pipe__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ~pipes/record-state-bg/record-state-bg.pipe */ 84174);
/* harmony import */ var _components_swap_token_chain_icon_swap_token_chain_icon_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ~components/swap-token-chain-icon/swap-token-chain-icon.component */ 26193);
/* harmony import */ var _libs_bnf_components_pull_to_refresh_pull_to_refresh_directive__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../../../../../../libs/bnf/components/pull-to-refresh/pull-to-refresh.directive */ 97063);
/* harmony import */ var _libs_bnf_components_pull_to_refresh_pull_to_refresh_spinner_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../../../../../../libs/bnf/components/pull-to-refresh/pull-to-refresh-spinner.component */ 75387);
/* harmony import */ var _libs_bnf_components_infinite_scroll_infinite_scroll_spinner_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../../../../../../../libs/bnf/components/infinite-scroll/infinite-scroll-spinner.component */ 66560);
/* harmony import */ var _libs_bnf_components_infinite_scroll_infinite_scroll_directive__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../../../../../../../libs/bnf/components/infinite-scroll/infinite-scroll.directive */ 10320);
/* harmony import */ var _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ../../../../../../../libs/bnf/modules/page/common-page/common-page.component */ 62052);
/* harmony import */ var _components_icon_icon_component__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ../../../../components/icon/icon.component */ 18840);
/* harmony import */ var _pipes_color_color_pipe__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ../../../../pipes/color/color.pipe */ 67481);
/* harmony import */ var _libs_bnf_pipes_amountFixed_amount_fixed_pipe__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ../../../../../../../libs/bnf/pipes/amountFixed/amount-fixed.pipe */ 44070);

var _class;























const _c6 = a0 => ({
  color: a0
});
function MyRecordRemoveComponent_Conditional_2_Conditional_2_For_1_Case_30_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelement"](0, "bs-icon", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipe"](1, "color");
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpureFunction1"](4, _c6, _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipeBind1"](1, 2, "green-20")));
  }
}
function MyRecordRemoveComponent_Conditional_2_Conditional_2_For_1_Case_31_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelement"](0, "bs-icon", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipe"](1, "color");
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpureFunction1"](4, _c6, _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipeBind1"](1, 2, "fail")));
  }
}
function MyRecordRemoveComponent_Conditional_2_Conditional_2_For_1_Case_32_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelement"](0, "bs-icon", 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipe"](1, "color");
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpureFunction1"](4, _c6, _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipeBind1"](1, 2, "subtitle-2")));
  }
}
const _c7 = () => ({
  removeZero: true
});
function MyRecordRemoveComponent_Conditional_2_Conditional_2_For_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r15 = _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementStart"](0, "div", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵlistener"]("click", function MyRecordRemoveComponent_Conditional_2_Conditional_2_For_1_Template_div_click_0_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵrestoreView"](_r15);
      const item_r6 = restoredCtx.$implicit;
      const ctx_r14 = _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵnextContext"](3);
      return _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵresetView"](ctx_r14.jumpLiquidityDetail(item_r6.orderId));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementStart"](1, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipe"](2, "recordStateBg");
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelement"](3, "bs-token-with-chain-icon", 6)(4, "bs-token-with-chain-icon", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementStart"](5, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵi18n"](6, 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipe"](7, "recordStateColor");
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipe"](8, "recordState");
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelement"](9, "bs-icon", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementStart"](10, "div", 10)(11, "div", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵi18n"](12, 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementStart"](13, "div", 13)(14, "div", 14)(15, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtext"](16);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipe"](17, "amountFixed");
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelement"](18, "bs-swap-token-chain-icon", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementStart"](19, "div", 16)(20, "div", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtext"](21);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipe"](22, "amountFixed");
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelement"](23, "bs-swap-token-chain-icon", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementEnd"]()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementStart"](24, "div", 19)(25, "div", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵi18n"](26, 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementStart"](27, "div", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtext"](28);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipe"](29, "amountFixed");
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtemplate"](30, MyRecordRemoveComponent_Conditional_2_Conditional_2_For_1_Case_30_Template, 2, 6)(31, MyRecordRemoveComponent_Conditional_2_Conditional_2_For_1_Case_31_Template, 2, 6)(32, MyRecordRemoveComponent_Conditional_2_Conditional_2_For_1_Case_32_Template, 2, 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementStart"](33, "div", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtext"](34);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipe"](35, "date");
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const item_r6 = ctx.$implicit;
    const ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵnextContext"](3);
    let MyRecordRemoveComponent_Conditional_2_Conditional_2_For_1_contFlowTmp;
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵclassMapInterpolate1"]("flex items-center p-4  rounded-4 mb-3 ", _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipeBind1"](2, 20, item_r6.state), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵproperty"]("swapChainName", item_r6.anchorTran == null ? null : item_r6.anchorTran.chainName)("swapCoinName", item_r6.anchorTran == null ? null : item_r6.anchorTran.coinName);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵproperty"]("swapChainName", item_r6.quoteTran == null ? null : item_r6.quoteTran.chainName)("swapCoinName", item_r6.quoteTran == null ? null : item_r6.quoteTran.coinName);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵclassMapInterpolate1"]("mr-1 ml-auto ", _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipeBind1"](7, 22, item_r6.state), "");
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵi18nExp"](_angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipeBind2"](8, 24, item_r6.state, ctx_r5.RECORDTYPE));
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵi18nApply"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"](8);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipeBind3"](17, 27, item_r6.anchorTran == null ? null : item_r6.anchorTran.amount, 8, _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpureFunction0"](42, _c7)), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵproperty"]("swapCoinName", item_r6.anchorTran == null ? null : item_r6.anchorTran.coinName)("swapChainName", item_r6.anchorTran == null ? null : item_r6.anchorTran.chainName);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipeBind3"](22, 31, item_r6.quoteTran == null ? null : item_r6.quoteTran.amount, 8, _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpureFunction0"](43, _c7)), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵproperty"]("swapCoinName", item_r6.quoteTran == null ? null : item_r6.quoteTran.coinName)("swapChainName", item_r6.quoteTran == null ? null : item_r6.quoteTran.chainName);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtextInterpolate1"](" - ", _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipeBind3"](29, 35, item_r6.lpCoinsAmount, 8, _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpureFunction0"](44, _c7)), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵconditional"](30, (MyRecordRemoveComponent_Conditional_2_Conditional_2_For_1_contFlowTmp = item_r6.state) === ctx_r5.ORDERSTATE.SUCCESS ? 30 : MyRecordRemoveComponent_Conditional_2_Conditional_2_For_1_contFlowTmp === ctx_r5.ORDERSTATE.RETURN_COMPLETE ? 31 : 32);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtextInterpolate1"](" ", item_r6.startTime ? _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipeBind2"](35, 39, item_r6.startTime, "yyyy.MM.dd HH:mm") : "- -", " ");
  }
}
function MyRecordRemoveComponent_Conditional_2_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵrepeaterCreate"](0, MyRecordRemoveComponent_Conditional_2_Conditional_2_For_1_Template, 36, 45, "div", 26, _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵrepeaterTrackByIndex"]);
  }
  if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵrepeater"](ctx_r2.dataList);
  }
}
function MyRecordRemoveComponent_Conditional_2_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementStart"](0, "div", 27);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelement"](1, "img", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementStart"](2, "span", 29);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵi18n"](3, 30);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementEnd"]()();
  }
}
function MyRecordRemoveComponent_Conditional_2_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementStart"](0, "bn-infinite-scroll-spinner")(1, "span", 31);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵi18n"](2, 32);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementEnd"]()();
  }
}
function MyRecordRemoveComponent_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r17 = _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementStart"](0, "div", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵlistener"]("infinited$", function MyRecordRemoveComponent_Conditional_2_Template_div_infinited__0_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵrestoreView"](_r17);
      const ctx_r16 = _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵresetView"]($event.waitFor(ctx_r16.loadMore()));
    })("pulled$", function MyRecordRemoveComponent_Conditional_2_Template_div_pulled__0_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵrestoreView"](_r17);
      const ctx_r18 = _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵresetView"]($event.waitFor(ctx_r18.refresh()));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelement"](1, "bn-pull-to-refresh-spinner", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtemplate"](2, MyRecordRemoveComponent_Conditional_2_Conditional_2_Template, 2, 0)(3, MyRecordRemoveComponent_Conditional_2_Conditional_3_Template, 4, 0)(4, MyRecordRemoveComponent_Conditional_2_Conditional_4_Template, 3, 0, "bn-infinite-scroll-spinner");
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵproperty"]("hasMore", ctx_r0.hasMore)("emitDistance", 158)("maxDistance", 200);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵconditional"](2, ctx_r0.dataList.length ? 2 : 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵconditional"](4, ctx_r0.loading ? 4 : -1);
  }
}
function MyRecordRemoveComponent_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementStart"](0, "div", 33);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelement"](1, "img", 34);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementStart"](2, "div", 35);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵi18n"](3, 36);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementEnd"]()();
  }
}
/** 记录移除流动性组件 */
class MyRecordRemoveComponent extends _modules_page_module__WEBPACK_IMPORTED_MODULE_3__.CommonPageBase {
  constructor() {
    super(...arguments);
    /** 记录的类型 */
    this.RECORDTYPE = _bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_1__.ORDER_RECORD_TYPES.REMOVE_LIQUIDITY;
    this.DIRECTION = _services_liquidity_order_lquidity_order_type__WEBPACK_IMPORTED_MODULE_8__.$DIRECTION;
    /** 订单状态 */
    this.ORDERSTATE = {
      /** 成功 */
      SUCCESS: _bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_1__.ORDER_RECORD_STATUS.SUCCESS,
      /** 退款完成 */
      RETURN_COMPLETE: _bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_1__.ORDER_RECORD_STATUS.RETURN_COMPLETE
    };
    /** 钱包服务 */
    this.walletService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_19__.inject)(_services_wallet_wallet_service__WEBPACK_IMPORTED_MODULE_5__.WalletService);
    /** 订单服务 */
    this.orderService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_19__.inject)(_services_liquidity_order_liquidity_order_service__WEBPACK_IMPORTED_MODULE_4__.LiquidityOrderService);
    /** 已连接钱包 */
    this.connectedWallet = this.walletService.connectedWallet;
    /** loading */
    this.loading = false;
    /** 页数 */
    this.newestMaxIndex = 10000000000;
    /** 数据列表 */
    this.dataList = [];
    /** 页码 */
    this.pageSize = 10;
    /** 是否初始化 */
    this.init = false;
    /** 是否还有 */
    this.hasMore = true;
  }
  /** 跳转流动性详情页面 */
  jumpLiquidityDetail(orderId) {
    this.nav.routeTo('/mine/my-record-remove-liquidity-detail', {
      orderId
    });
  }
  /** 加载更多 */
  loadMore() {
    return this.getList();
  }
  /** 下拉刷新 */
  refresh() {
    var _this = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this.init = false;
      _this.newestMaxIndex = 10000000000;
      _this.hasMore = true;
      _this.loading = false;
      _this.dataList = [];
      _this.getList();
    })();
  }
  /** 获取数据 */
  getList() {
    var _this2 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      var _this2$connectedWalle;
      const userId = (_this2$connectedWalle = _this2.connectedWallet) === null || _this2$connectedWalle === void 0 ? void 0 : _this2$connectedWalle.pmchainAddress;
      if (userId === undefined) {
        return;
      }
      const params = {
        userId,
        type: _bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_1__.ORDER_RECORD_TYPES.REMOVE_LIQUIDITY,
        maxIndex: _this2.newestMaxIndex,
        minIndex: 0,
        size: _this2.pageSize
      };
      if (_this2.hasMore === false) return;
      _this2.loading = true;
      const res = yield _this2.orderService.getPoolOrderHistoryListByUserId(params);
      if (res) {
        const {
          dataList,
          hasMore,
          maxIndex
        } = res;
        const list = dataList.map(data => {
          const extra = _this2.handleTran(data);
          return {
            ...extra,
            ...data
          };
        });
        _this2.loading = false;
        _this2.newestMaxIndex = maxIndex;
        _this2.hasMore = hasMore;
        _this2.dataList = [..._this2.dataList, ...list];
        _this2.init = true;
        _this2.cdRef.detectChanges();
      }
    })();
  }
  /** 处理交易的数据 */
  handleTran(data) {
    const {
      orderTransactionList,
      anchorTxId,
      quoteTxId
    } = data;
    const anchorTran = orderTransactionList.find(order => {
      return order.transactionId === anchorTxId;
    });
    const quoteTran = orderTransactionList.find(order => {
      return order.transactionId === quoteTxId;
    });
    let lpState;
    if (anchorTran && quoteTran) {
      lpState = this.handleLPState(anchorTran, quoteTran);
    }
    return {
      anchorTran,
      quoteTran,
      lpState
    };
  }
  /** 处理LPcoin获取状态 */
  handleLPState(anchorTran, quoteTran) {
    const {
      state: anchorState
    } = anchorTran;
    const {
      state: quoteState
    } = quoteTran;
    const success = anchorState === _bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_1__.TRANSACTION_STATUS.SUCCESS && quoteState === _bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_1__.TRANSACTION_STATUS.SUCCESS;
    return success ? "\u5DF2\u6263\u9664" : "\u672A\u6263\u9664";
  }
}
_class = MyRecordRemoveComponent;
_class.ɵfac = /*@__PURE__*/(() => {
  let ɵMyRecordRemoveComponent_BaseFactory;
  return function MyRecordRemoveComponent_Factory(t) {
    return (ɵMyRecordRemoveComponent_BaseFactory || (ɵMyRecordRemoveComponent_BaseFactory = _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵgetInheritedFactory"](_class)))(t || _class);
  };
})();
_class.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵdefineComponent"]({
  type: _class,
  selectors: [["bs-my-record-remove"]],
  standalone: true,
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵInheritDefinitionFeature"], _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵStandaloneFeature"]],
  decls: 4,
  vars: 3,
  consts: () => {
    let i18n_0;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_7089857848655717121$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_RECORD_REMOVE_MY_RECORD_REMOVE_COMPONENT_TS____1 = goog.getMsg(" {$interpolation} ", {
        "interpolation": "\uFFFD0\uFFFD"
      }, {
        original_code: {
          "interpolation": "{{ item.state | recordState : RECORDTYPE }}"
        }
      });
      i18n_0 = MSG_EXTERNAL_7089857848655717121$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_RECORD_REMOVE_MY_RECORD_REMOVE_COMPONENT_TS____1;
    } else {
      i18n_0 = " " + "\uFFFD0\uFFFD" + " ";
    }
    let i18n_2;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_2550414492302136981$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_RECORD_REMOVE_MY_RECORD_REMOVE_COMPONENT_TS____3 = goog.getMsg("\u79FB\u9664\u6570\u91CF");
      i18n_2 = MSG_EXTERNAL_2550414492302136981$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_RECORD_REMOVE_MY_RECORD_REMOVE_COMPONENT_TS____3;
    } else {
      i18n_2 = "\u79FB\u9664\u6570\u91CF";
    }
    let i18n_4;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_2160098162517155843$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_RECORD_REMOVE_MY_RECORD_REMOVE_COMPONENT_TS____5 = goog.getMsg("\u5408\u7EA6\u6C60\u6743\u76CA");
      i18n_4 = MSG_EXTERNAL_2160098162517155843$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_RECORD_REMOVE_MY_RECORD_REMOVE_COMPONENT_TS____5;
    } else {
      i18n_4 = "\u5408\u7EA6\u6C60\u6743\u76CA";
    }
    let i18n_8;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_NO_RECORDS$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_RECORD_REMOVE_MY_RECORD_REMOVE_COMPONENT_TS___9 = goog.getMsg("No records");
      i18n_8 = MSG_EXTERNAL_NO_RECORDS$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_RECORD_REMOVE_MY_RECORD_REMOVE_COMPONENT_TS___9;
    } else {
      i18n_8 = "\u6CA1\u8BB0\u5F55";
    }
    let i18n_10;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_LOADING$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_RECORD_REMOVE_MY_RECORD_REMOVE_COMPONENT_TS___11 = goog.getMsg("Loading");
      i18n_10 = MSG_EXTERNAL_LOADING$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_RECORD_REMOVE_MY_RECORD_REMOVE_COMPONENT_TS___11;
    } else {
      i18n_10 = "\u52A0\u8F7D\u4E2D";
    }
    let i18n_12;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_7825757923954104189$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_RECORD_REMOVE_MY_RECORD_REMOVE_COMPONENT_TS__13 = goog.getMsg("\u83B7\u53D6\u6570\u636E\u4E2D");
      i18n_12 = MSG_EXTERNAL_7825757923954104189$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_RECORD_REMOVE_MY_RECORD_REMOVE_COMPONENT_TS__13;
    } else {
      i18n_12 = "\u83B7\u53D6\u6570\u636E\u4E2D";
    }
    return [[3, "hideHeader", "contentBackground"], [1, "h-full"], ["wPullToRefresh", "", "wInfiniteScroll", "", "class", "h-full overflow-y-scroll px-4 pt-2.5", 3, "hasMore", "emitDistance", "maxDistance"], ["wPullToRefresh", "", "wInfiniteScroll", "", 1, "h-full", "overflow-y-scroll", "px-4", "pt-2.5", 3, "hasMore", "emitDistance", "maxDistance", "infinited$", "pulled$"], [1, "text-title"], [1, "rounded-4", "mb-2", "bg-white", "px-0.5", "pb-4", "pt-0.5", 3, "click"], [3, "swapChainName", "swapCoinName"], [1, "ml-2", 3, "swapChainName", "swapCoinName"], i18n_0, ["name", "icon-chevron-right", 1, "text-subtitle-2", "text-xl"], [1, "mb-2", "flex", "items-center", "justify-between", "px-4"], [1, "text-subtitle-2", "text-xs"], i18n_2, [1, "text-title-10", "flex", "flex-col", "text-right", "font-semibold"], [1, "mb-1", "flex", "items-center", "justify-end"], [1, "ml-1", 3, "swapCoinName", "swapChainName"], [1, "flex", "items-center", "justify-end"], [1, "mr-1"], [3, "swapCoinName", "swapChainName"], [1, "mb-2", "flex", "items-center", "px-4"], i18n_4, [1, "text-title-10", "ml-auto", "mr-1", "font-semibold"], [1, "text-subtitle-2", "px-4", "text-xs"], ["name", "icon-check-circle-fill", 1, "text-lg"], ["name", "icon-waring-fill", 1, "text-lg"], ["name", "icon-timeclock-fill", 1, "text-lg"], ["class", "rounded-4 mb-2 bg-white px-0.5 pb-4 pt-0.5"], [1, "flex", "h-full", "w-full", "flex-col", "items-center", "justify-center"], ["src", "./assets/images/placeholder-3.png"], [1, "text-line", "text-sm", "text-gray-400"], i18n_8, [1, "text-sm"], i18n_10, [1, "absolute", "top-1/2", "flex", "w-full", "-translate-y-1/2", "flex-col", "items-center", "justify-center"], ["src", "./assets/images/order-ing.png", 1, "h-45", "w-60"], [1, "text-base-200"], i18n_12];
  },
  template: function MyRecordRemoveComponent_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementStart"](0, "common-page", 0)(1, "div", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtemplate"](2, MyRecordRemoveComponent_Conditional_2_Template, 5, 5, "div", 2)(3, MyRecordRemoveComponent_Conditional_3_Template, 4, 0);
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementEnd"]()();
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵproperty"]("hideHeader", true)("contentBackground", "#f6f7fc");
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵconditional"](2, ctx.init ? 2 : 3);
    }
  },
  dependencies: [_components_swap_token_chain_icon_swap_token_chain_icon_component__WEBPACK_IMPORTED_MODULE_10__.SwapTokenChainIconComponent, _pipes_record_state_color_record_state_color_pipe__WEBPACK_IMPORTED_MODULE_6__.RecordStateColorPipe, _pipes_record_state_record_state_pipe__WEBPACK_IMPORTED_MODULE_7__.RecordStatePipe, _pipes_record_state_bg_record_state_bg_pipe__WEBPACK_IMPORTED_MODULE_9__.RecordStateBgPipe, _modules_page_module__WEBPACK_IMPORTED_MODULE_3__.CommonPageModule, _libs_bnf_components_pull_to_refresh_pull_to_refresh_directive__WEBPACK_IMPORTED_MODULE_11__.PullToRefreshDirective, _libs_bnf_components_pull_to_refresh_pull_to_refresh_spinner_component__WEBPACK_IMPORTED_MODULE_12__.PullToRefreshSpinnerComponent, _libs_bnf_components_infinite_scroll_infinite_scroll_spinner_component__WEBPACK_IMPORTED_MODULE_13__.InfiniteScrollSpinnerComponent, _libs_bnf_components_infinite_scroll_infinite_scroll_directive__WEBPACK_IMPORTED_MODULE_14__.InfiniteScrollDirective, _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_15__.CommonPageComponent, _components_icon_icon_component__WEBPACK_IMPORTED_MODULE_16__.IconComponent, _angular_common__WEBPACK_IMPORTED_MODULE_20__.DatePipe, _pipes_color_color_pipe__WEBPACK_IMPORTED_MODULE_17__.ColorPipe, _libs_bnf_pipes_amountFixed_amount_fixed_pipe__WEBPACK_IMPORTED_MODULE_18__.AmountFixedPipe, _angular_common__WEBPACK_IMPORTED_MODULE_20__.CommonModule, _components_token_with_chain_icon_token_with_chain_icon_component__WEBPACK_IMPORTED_MODULE_2__.TokenWithnChainIconComponent],
  encapsulation: 2,
  changeDetection: 0
});
(0,tslib__WEBPACK_IMPORTED_MODULE_21__.__decorate)([MyRecordRemoveComponent.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_21__.__metadata)("design:type", Object)], MyRecordRemoveComponent.prototype, "connectedWallet", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_21__.__decorate)([MyRecordRemoveComponent.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_21__.__metadata)("design:type", Object)], MyRecordRemoveComponent.prototype, "loading", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_21__.__decorate)([MyRecordRemoveComponent.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_21__.__metadata)("design:type", Object)], MyRecordRemoveComponent.prototype, "newestMaxIndex", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_21__.__decorate)([MyRecordRemoveComponent.States(1), (0,tslib__WEBPACK_IMPORTED_MODULE_21__.__metadata)("design:type", Array)], MyRecordRemoveComponent.prototype, "dataList", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_21__.__decorate)([MyRecordRemoveComponent.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_21__.__metadata)("design:type", Object)], MyRecordRemoveComponent.prototype, "pageSize", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_21__.__decorate)([MyRecordRemoveComponent.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_21__.__metadata)("design:type", Object)], MyRecordRemoveComponent.prototype, "init", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_21__.__decorate)([MyRecordRemoveComponent.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_21__.__metadata)("design:type", Object)], MyRecordRemoveComponent.prototype, "hasMore", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_21__.__decorate)([MyRecordRemoveComponent.AfterViewInit(), (0,tslib__WEBPACK_IMPORTED_MODULE_21__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_21__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_21__.__metadata)("design:returntype", Promise)], MyRecordRemoveComponent.prototype, "getList", null);

/***/ }),

/***/ 21441:
/*!***************************************************************************!*\
  !*** ./apps/bfswap/src/pages/mine/pages/my-record/my-record.component.ts ***!
  \***************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   MyRecordPage: () => (/* binding */ MyRecordPage),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 52542);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! tslib */ 90505);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/common */ 6729);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/core */ 61039);
/* harmony import */ var _modules_page_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ~modules/page.module */ 16381);
/* harmony import */ var _my_record_remove_my_record_remove_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../my-record-remove/my-record-remove.component */ 30371);
/* harmony import */ var _bnqkl_framework_directives__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @bnqkl/framework/directives */ 11100);
/* harmony import */ var _bnqkl_framework_helpers__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @bnqkl/framework/helpers */ 12169);
/* harmony import */ var _bnqkl_framework_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @bnqkl/framework/core */ 63563);
/* harmony import */ var _my_record_add_my_record_add_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../my-record-add/my-record-add.component */ 62284);
/* harmony import */ var _libs_bnf_directives_ob_size_directive__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../../../../../libs/bnf/directives/ob-size.directive */ 46501);
/* harmony import */ var _libs_bnf_directives_tab_directive__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../../../../../libs/bnf/directives/tab.directive */ 384);
/* harmony import */ var _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../../../../../../libs/bnf/modules/page/common-page/common-page.component */ 62052);

var _class;














const _c0 = ["navSize"];
const _c1 = ["panel"];
const _c2 = ["linkContainer"];
function MyRecordPage_For_6_Template(rf, ctx) {
  if (rf & 1) {
    const _r10 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "button", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("click", function MyRecordPage_For_6_Template_button_click_0_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵrestoreView"](_r10);
      const index_r5 = restoredCtx.$index;
      const ctx_r9 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵresetView"](ctx_r9.selectTab(index_r5));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const item_r4 = ctx.$implicit;
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngClass", ((ctx_r1.currLink == null ? null : ctx_r1.currLink.index) || 0) === item_r4.index ? "text-title-10" : "text-subtitle-2");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtextInterpolate1"](" ", item_r4.label_text, " ");
  }
}
function MyRecordPage_div_11_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](0, "div", 9, 10);
  }
}
const _c3 = a0 => ({
  "--index": a0
});
const _c4 = a0 => ({
  "--page-safe-area-inset-top": a0,
  "--page-safe-area-inset-bottom": 0
});
/** 记录页面 */
class MyRecordPage extends (0,_bnqkl_framework_core__WEBPACK_IMPORTED_MODULE_5__.MixinBrowser)(_modules_page_module__WEBPACK_IMPORTED_MODULE_1__.CommonPageBase) {
  constructor() {
    super(...arguments);
    /** 记录列表 */
    this.recordList = [{
      type: 'ing'
    }, {
      type: 'success'
    }, {
      type: 'fail'
    }];
    /** 导航栏的高度 */
    this.navHeight = '0px';
    /** 底部导航栏的高度 */
    this.bottomNavHeight = '0px';
    /** 所有的 tab 链接 */
    this.links = [{
      index: 0,
      label_text: '增加流动性',
      component: _my_record_add_my_record_add_component__WEBPACK_IMPORTED_MODULE_6__.MyRecordAddComponent,
      ref: undefined
    }, {
      index: 1,
      label_text: '移除流动性',
      component: _my_record_remove_my_record_remove_component__WEBPACK_IMPORTED_MODULE_2__.MyRecordRemoveComponent,
      ref: undefined
    }];
  }
  /** 跳转兑换详情页面 */
  jumpSwapDetail() {
    this.nav.routeTo('/mine/swap-detail');
  }
  /** 监听导航栏的大小 */
  set navSize(obSize) {
    this.takeUntilDestroy(obSize.resized$).subscribe(size => {
      this.navHeight = size.borderHeight + 'px';
    });
  }
  initLink() {
    var _this = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      /// @TODO 根据URL来变更
      const queryParams = _this.nav.getQueryParams();
      const tabIndex = queryParams['index'];
      _this.currLink = tabIndex ? _this.selectTab(Number(tabIndex)) : _this.selectTab(0);
      /// 在有空的时候把各个页面初始化出来
      for (const link of _this.links) {
        yield (0,_bnqkl_framework_helpers__WEBPACK_IMPORTED_MODULE_4__.$requestIdleCallback)();
        _this._initLinkRef(link);
      }
    })();
  }
  /**
   * 切换 tab
   */
  selectTab(index) {
    var _this2 = this;
    const linkContainer = this.linkContainerList.get(index);
    if (linkContainer === undefined) {
      return;
    }
    const link = this.links[index];
    if (this.currLink !== link) {
      this.prevLink = this.currLink;
      this.currLink = link;
      this._initLinkRef(link, linkContainer);
      (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
        _this2.panelAnimationsStart();
        yield (0,_bnqkl_framework_helpers__WEBPACK_IMPORTED_MODULE_4__.$requestAnimationFrame)();
        _this2.panelAnimationsDone();
      })();
    }
    return link;
  }
  /** 初始化页面实例 */
  _initLinkRef(link, linkContainer = this.linkContainerList.get(this.links.indexOf(link))) {
    if (link.ref === undefined && link.component !== undefined) {
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      link.ref = this._panelVcRef.createComponent(link.component);
      this.renderer2.appendChild(linkContainer === null || linkContainer === void 0 ? void 0 : linkContainer.nativeElement, link.ref.location.nativeElement);
      link.ref.instance.requestUpdate();
      this.cdRef.detectChanges();
    }
  }
  /** 监听tab-panel动画开始 */
  panelAnimationsStart() {
    var _this$currLink;
    this.console.info('animation start');
    const page = (_this$currLink = this.currLink) === null || _this$currLink === void 0 || (_this$currLink = _this$currLink.ref) === null || _this$currLink === void 0 ? void 0 : _this$currLink.instance;
    // const prePage = this.prevLink?.ref?.instance;
    // page?.ngPageWillEnter();
    page === null || page === void 0 || page.ngOnResume('tab');
    // prePage?.ngPageWillLeave();
  }
  /** 监听tab-panel动画结束 */
  panelAnimationsDone() {
    var _this$currLink2, _page$pageTheme$, _this$prevLink;
    this.console.info('animation done');
    /// 跟随子页面的风格
    const page = (_this$currLink2 = this.currLink) === null || _this$currLink2 === void 0 || (_this$currLink2 = _this$currLink2.ref) === null || _this$currLink2 === void 0 ? void 0 : _this$currLink2.instance;
    const pageTheme = page === null || page === void 0 || (_page$pageTheme$ = page.pageTheme$) === null || _page$pageTheme$ === void 0 ? void 0 : _page$pageTheme$.value;
    if (pageTheme !== undefined) {
      var _this$pageTheme$;
      (_this$pageTheme$ = this.pageTheme$) === null || _this$pageTheme$ === void 0 || _this$pageTheme$.next(pageTheme);
    }
    // page?.ngPageDidEnter();
    const prePage = (_this$prevLink = this.prevLink) === null || _this$prevLink === void 0 || (_this$prevLink = _this$prevLink.ref) === null || _this$prevLink === void 0 ? void 0 : _this$prevLink.instance;
    // prePage?.ngPageDidLeave();
    prePage === null || prePage === void 0 || prePage.ngOnPause('tab');
  }
  /** 将页面的生命周期向内传递给tab-panel的页面 */
  ngOnPause(reason) {
    var _this$currLink3;
    super.ngOnPause(reason);
    (_this$currLink3 = this.currLink) === null || _this$currLink3 === void 0 || (_this$currLink3 = _this$currLink3.ref) === null || _this$currLink3 === void 0 || (_this$currLink3 = _this$currLink3.instance) === null || _this$currLink3 === void 0 || _this$currLink3.ngOnPause(reason);
  }
  /** 将页面的生命周期向内传递给tab-panel的页面 */
  ngOnResume(reason) {
    var _this$currLink4;
    super.ngOnResume(reason);
    (_this$currLink4 = this.currLink) === null || _this$currLink4 === void 0 || (_this$currLink4 = _this$currLink4.ref) === null || _this$currLink4 === void 0 || (_this$currLink4 = _this$currLink4.instance) === null || _this$currLink4 === void 0 || _this$currLink4.ngOnResume(reason);
  }
}
_class = MyRecordPage;
_class.ɵfac = /*@__PURE__*/(() => {
  let ɵMyRecordPage_BaseFactory;
  return function MyRecordPage_Factory(t) {
    return (ɵMyRecordPage_BaseFactory || (ɵMyRecordPage_BaseFactory = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵgetInheritedFactory"](_class)))(t || _class);
  };
})();
_class.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵdefineComponent"]({
  type: _class,
  selectors: [["bs-my-record"]],
  viewQuery: function MyRecordPage_Query(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵviewQuery"](_c0, 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵviewQuery"](_c1, 5, _angular_core__WEBPACK_IMPORTED_MODULE_10__.ViewContainerRef);
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵviewQuery"](_c2, 5, _angular_core__WEBPACK_IMPORTED_MODULE_10__.ElementRef);
    }
    if (rf & 2) {
      let _t;
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵloadQuery"]()) && (ctx.navSize = _t.first);
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵloadQuery"]()) && (ctx._panelVcRef = _t.first);
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵloadQuery"]()) && (ctx.linkContainerList = _t);
    }
  },
  standalone: true,
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵInheritDefinitionFeature"], _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵStandaloneFeature"]],
  decls: 12,
  vars: 12,
  consts: [[3, "headerBackground", "contentBackground", "titleClass"], ["wObSize", "", 1, "grid-in-[tabs]", "border-border-10", "bg-base-300", "relative", "z-[2]", "flex", "border-b"], ["navSize", "obSize"], [1, "grid", "grid-cols-[auto,auto]", "justify-items-center"], [1, "_subscript", 3, "ngStyle"], ["wTabGroup", "", 1, "grid-in-[tabs/tabs/panel/panel]", "z-[1]", "grid", "flex-grow", "grid-flow-col", "overflow-x-hidden", 3, "ngStyle", "selectedIndex", "scrollSmooth", "selectedIndexChange$"], ["panel", ""], ["class", "w-cqw-100 block h-full overflow-hidden", "wTab", "", 4, "ngFor", "ngForOf"], [1, "duibs-btn", "duibs-btn-link", "flex", "items-center", "justify-center", "text-base", 3, "ngClass", "click"], ["wTab", "", 1, "w-cqw-100", "block", "h-full", "overflow-hidden"], ["linkContainer", ""], ["class", "duibs-btn duibs-btn-link flex items-center justify-center text-base", 3, "ngClass"]],
  template: function MyRecordPage_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "common-page", 0)(1, "section")(2, "nav", 1, 2)(4, "div", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵrepeaterCreate"](5, MyRecordPage_For_6_Template, 2, 2, "button", 11, _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵrepeaterTrackByIndex"]);
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](7, "div", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](8, "main", 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("selectedIndexChange$", function MyRecordPage_Template_main_selectedIndexChange__8_listener($event) {
        return ctx.selectTab($event);
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementContainer"](9, null, 6);
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](11, MyRecordPage_div_11_Template, 2, 0, "div", 7);
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()()();
    }
    if (rf & 2) {
      let tmp_6_0;
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("headerBackground", "#f6f7fc")("contentBackground", "#f6f7fc")("titleClass", "text-xl");
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](5);
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵrepeater"](ctx.links);
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngStyle", _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpureFunction1"](8, _c3, (ctx.currLink == null ? null : ctx.currLink.index) || 0));
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngStyle", _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpureFunction1"](10, _c4, ctx.navHeight))("selectedIndex", (tmp_6_0 = ctx.currLink == null ? null : ctx.currLink.index) !== null && tmp_6_0 !== undefined ? tmp_6_0 : 0)("scrollSmooth", true);
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngForOf", ctx.links);
    }
  },
  dependencies: [_modules_page_module__WEBPACK_IMPORTED_MODULE_1__.CommonPageModule, _libs_bnf_directives_ob_size_directive__WEBPACK_IMPORTED_MODULE_7__.ObSizeDirective, _libs_bnf_directives_tab_directive__WEBPACK_IMPORTED_MODULE_8__.TabGroupDirective, _libs_bnf_directives_tab_directive__WEBPACK_IMPORTED_MODULE_8__.TabDirective, _angular_common__WEBPACK_IMPORTED_MODULE_11__.NgClass, _angular_common__WEBPACK_IMPORTED_MODULE_11__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_11__.NgStyle, _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_9__.CommonPageComponent, _angular_common__WEBPACK_IMPORTED_MODULE_11__.CommonModule],
  styles: ["[_nghost-%COMP%]   ._subscript[_ngcontent-%COMP%] {\n  --tw-bg-opacity: 1;\n  background-color: rgb(100 15 243 / var(--tw-bg-opacity));\n  height: 2px;\n  width: 1.25rem;\n  border-radius: 1px;\n  margin-top: -3px;\n  grid-column-start: calc(var(--index) * 2);\n  transition-duration: 200ms;\n  transition-property: grid-column-start;\n  transition-timing-function: ease-out;\n}\n[_nghost-%COMP%]   section[_ngcontent-%COMP%] {\n  width: 100%;\n  height: 100%;\n  display: grid;\n  grid-template-rows: 3rem auto;\n  grid-template-areas: \"tabs\" \"panel\";\n}\n[_nghost-%COMP%]   section[_ngcontent-%COMP%]   ._active-border[_ngcontent-%COMP%] {\n  position: absolute;\n  left: 50%;\n  top: 50%;\n  height: 3rem;\n  width: 3rem;\n  transform-origin: center;\n  border-radius: 9999px;\n  border-width: 1px;\n  border-style: solid;\n  border-color: rgb(255 255 255 / 0.5);\n  transform: translate(-50%, -50%);\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL2FwcHMvYmZzd2FwL3NyYy9wYWdlcy9taW5lL3BhZ2VzL215LXJlY29yZC9teS1yZWNvcmQuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBR0k7RUFBQSxrQkFBQTtFQUFBLHdEQUFBO0VBQ0EsV0FBQTtFQUNBLGNBQUE7RUFDQSxrQkFBQTtFQUNBLGdCQUFBO0VBSUEseUNBQUE7RUFDQSwwQkFBQTtFQUNBLHNDQUFBO0VBQ0E7QUFYQTtBQWNGO0VBQ0UsV0FBQTtFQUNBLFlBQUE7RUFDQSxhQUFBO0VBQ0EsNkJBQUE7RUFDQSxtQ0FBQTtBQUxKO0FBUU07RUFBQSxrQkFBQTtFQUFBLFNBQUE7RUFBQSxRQUFBO0VBQUEsWUFBQTtFQUFBLFdBQUE7RUFBQSx3QkFBQTtFQUFBLHFCQUFBO0VBQUEsaUJBQUE7RUFBQSxtQkFBQTtFQUFBLG9DQUFBO0VBQ0E7QUFEQSIsInNvdXJjZXNDb250ZW50IjpbIjpob3N0IHtcclxuICAuX3N1YnNjcmlwdCB7XHJcbiAgICAvLyBAYXBwbHkgYmctcHJpbWFyeSBhYnNvbHV0ZTtcclxuICAgIEBhcHBseSBiZy1wcmltYXJ5O1xyXG4gICAgaGVpZ2h0OiAycHg7XHJcbiAgICB3aWR0aDogMS4yNXJlbTtcclxuICAgIGJvcmRlci1yYWRpdXM6IDFweDtcclxuICAgIG1hcmdpbi10b3A6IC0zcHg7XHJcbiAgICAvLyBib3R0b206IDRweDtcclxuICAgIC8vIC0taW5kZXg6IDA7XHJcbiAgICAvLyBsZWZ0OiBjYWxjKHZhcigtLWluZGV4KSAqIDMzLjMzMzMlICsgMTYuNjY2NyUgLSAwLjYyNXJlbSk7XHJcbiAgICBncmlkLWNvbHVtbi1zdGFydDogY2FsYyh2YXIoLS1pbmRleCkgKiAyKTtcclxuICAgIHRyYW5zaXRpb24tZHVyYXRpb246IDIwMG1zO1xyXG4gICAgdHJhbnNpdGlvbi1wcm9wZXJ0eTogZ3JpZC1jb2x1bW4tc3RhcnQ7XHJcbiAgICB0cmFuc2l0aW9uLXRpbWluZy1mdW5jdGlvbjogZWFzZS1vdXQ7XHJcbiAgfVxyXG5cclxuICBzZWN0aW9uIHtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgaGVpZ2h0OiAxMDAlO1xyXG4gICAgZGlzcGxheTogZ3JpZDtcclxuICAgIGdyaWQtdGVtcGxhdGUtcm93czogM3JlbSBhdXRvO1xyXG4gICAgZ3JpZC10ZW1wbGF0ZS1hcmVhczogJ3RhYnMnICdwYW5lbCc7XHJcblxyXG4gICAgLl9hY3RpdmUtYm9yZGVyIHtcclxuICAgICAgQGFwcGx5IGFic29sdXRlIGxlZnQtMS8yIHRvcC0xLzIgaC0xMiB3LTEyIG9yaWdpbi1jZW50ZXIgcm91bmRlZC1mdWxsIGJvcmRlciBib3JkZXItc29saWQgYm9yZGVyLXdoaXRlLzUwO1xyXG4gICAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZSgtNTAlLCAtNTAlKTtcclxuICAgIH1cclxuICB9XHJcbn0iXSwic291cmNlUm9vdCI6IiJ9 */"],
  changeDetection: 0
});
(0,tslib__WEBPACK_IMPORTED_MODULE_12__.__decorate)([MyRecordPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_12__.__metadata)("design:type", Object)], MyRecordPage.prototype, "recordList", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_12__.__decorate)([MyRecordPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_12__.__metadata)("design:type", Object)], MyRecordPage.prototype, "navHeight", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_12__.__decorate)([MyRecordPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_12__.__metadata)("design:type", Object)], MyRecordPage.prototype, "bottomNavHeight", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_12__.__decorate)([MyRecordPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_12__.__metadata)("design:type", Object)], MyRecordPage.prototype, "currLink", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_12__.__decorate)([MyRecordPage.AfterViewInit(), (0,tslib__WEBPACK_IMPORTED_MODULE_12__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_12__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_12__.__metadata)("design:returntype", Promise)], MyRecordPage.prototype, "initLink", null);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MyRecordPage);

/***/ }),

/***/ 7372:
/*!*****************************************************************!*\
  !*** ./apps/bfswap/src/pipes/record-state/record-state.pipe.ts ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   RecordStatePipe: () => (/* binding */ RecordStatePipe)
/* harmony export */ });
/* harmony import */ var _bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @bnqkl/bnqkl-swap-core */ 70195);
/* harmony import */ var _services_liquidity_order_lquidity_order_type__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ~services/liquidity-order/lquidity-order.type */ 84601);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 61039);
var _class;



/** 订单状态管道 */
class RecordStatePipe {
  constructor() {
    this.transform = RecordStatePipe.transform;
  }
  /** 转换函数 */
  static transform(state, type) {
    if (state === undefined) {
      return '- -';
    }
    const swapOrder = {
      [_services_liquidity_order_lquidity_order_type__WEBPACK_IMPORTED_MODULE_1__.$ORDER_STATE.SUCCESS]: '兑换成功',
      [_services_liquidity_order_lquidity_order_type__WEBPACK_IMPORTED_MODULE_1__.$ORDER_STATE.FAIL]: '兑换失败',
      [_services_liquidity_order_lquidity_order_type__WEBPACK_IMPORTED_MODULE_1__.$ORDER_STATE.ING]: '兑换中' // '交易中',
    };

    const addOrder = {
      [_services_liquidity_order_lquidity_order_type__WEBPACK_IMPORTED_MODULE_1__.$ORDER_STATE.SUCCESS]: "\u589E\u52A0\u6210\u529F",
      [_services_liquidity_order_lquidity_order_type__WEBPACK_IMPORTED_MODULE_1__.$ORDER_STATE.FAIL]: "\u589E\u52A0\u5931\u8D25",
      [_services_liquidity_order_lquidity_order_type__WEBPACK_IMPORTED_MODULE_1__.$ORDER_STATE.ING]: "\u589E\u52A0\u4E2D" // '增加中',
    };

    const removeOrder = {
      [_services_liquidity_order_lquidity_order_type__WEBPACK_IMPORTED_MODULE_1__.$ORDER_STATE.SUCCESS]: "\u79FB\u9664\u6210\u529F",
      [_services_liquidity_order_lquidity_order_type__WEBPACK_IMPORTED_MODULE_1__.$ORDER_STATE.FAIL]: "\u79FB\u9664\u5931\u8D25",
      [_services_liquidity_order_lquidity_order_type__WEBPACK_IMPORTED_MODULE_1__.$ORDER_STATE.ING]: "\u79FB\u9664\u4E2D" // '移除中',
    };

    const order = {
      [_bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_0__.ORDER_RECORD_TYPES.EXCHANGE_COINS]: swapOrder,
      [_bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_0__.ORDER_RECORD_TYPES.ADD_LIQUIDITY]: addOrder,
      [_bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_0__.ORDER_RECORD_TYPES.REMOVE_LIQUIDITY]: removeOrder
    };
    return order[type][_services_liquidity_order_lquidity_order_type__WEBPACK_IMPORTED_MODULE_1__.ORDER_RECORD_STATE[state]];
  }
}
_class = RecordStatePipe;
_class.ɵfac = function RecordStatePipe_Factory(t) {
  return new (t || _class)();
};
_class.ɵpipe = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefinePipe"]({
  name: "recordState",
  type: _class,
  pure: true,
  standalone: true
});

/***/ }),

/***/ 84601:
/*!*************************************************************************!*\
  !*** ./apps/bfswap/src/services/liquidity-order/lquidity-order.type.ts ***!
  \*************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   $DIRECTION: () => (/* binding */ $DIRECTION),
/* harmony export */   $ORDER_STATE: () => (/* binding */ $ORDER_STATE),
/* harmony export */   $PRICE_TYPE: () => (/* binding */ $PRICE_TYPE),
/* harmony export */   ORDER_RECORD_STATE: () => (/* binding */ ORDER_RECORD_STATE)
/* harmony export */ });
/* harmony import */ var _bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @bnqkl/bnqkl-swap-core */ 70195);

/** 订单的状态 */
var $ORDER_STATE;
(function ($ORDER_STATE) {
  $ORDER_STATE["SUCCESS"] = "SUCESS";
  $ORDER_STATE["FAIL"] = "FAIL";
  $ORDER_STATE["ING"] = "ING";
})($ORDER_STATE || ($ORDER_STATE = {}));
/** 价格类型 */
var $PRICE_TYPE;
(function ($PRICE_TYPE) {
  $PRICE_TYPE["EXPECT"] = "EXPECT";
  $PRICE_TYPE["ACTUAL"] = "ACTUAL";
})($PRICE_TYPE || ($PRICE_TYPE = {}));
/** 方向 */
var $DIRECTION;
(function ($DIRECTION) {
  $DIRECTION["ANCHOR"] = "ANCHOR";
  $DIRECTION["QUOTE"] = "QUOTE";
})($DIRECTION || ($DIRECTION = {}));
/** 订单记录状态 */
const ORDER_RECORD_STATE = {
  [_bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_0__.ORDER_RECORD_STATUS.SUCCESS]: $ORDER_STATE.SUCCESS,
  [_bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_0__.ORDER_RECORD_STATUS.INIT]: $ORDER_STATE.ING,
  [_bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_0__.ORDER_RECORD_STATUS.PAY_TX_ON_CHAIN_FAILURE]: $ORDER_STATE.ING,
  [_bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_0__.ORDER_RECORD_STATUS.PAY_TX_WAIT_ON_CHAIN]: $ORDER_STATE.ING,
  [_bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_0__.ORDER_RECORD_STATUS.RETURN_COMPLETE]: $ORDER_STATE.FAIL,
  [_bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_0__.ORDER_RECORD_STATUS.RETURN_TX_ON_CHAIN_FAILURE]: $ORDER_STATE.ING,
  [_bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_0__.ORDER_RECORD_STATUS.RETURN_TX_WAIT_ON_CHAIN]: $ORDER_STATE.ING,
  [_bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_0__.ORDER_RECORD_STATUS.TX_ON_CHAIN_FAILURE]: $ORDER_STATE.ING,
  [_bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_0__.ORDER_RECORD_STATUS.TX_WAIT_ON_CHAIN]: $ORDER_STATE.ING,
  [_bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_0__.ORDER_RECORD_STATUS.TX_WAIT_CHANGE_LIQUIDITY]: $ORDER_STATE.ING
};

/***/ })

}]);
//# sourceMappingURL=apps_bfswap_src_pages_mine_pages_my-record_my-record_component_ts.js.map