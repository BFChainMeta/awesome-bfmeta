"use strict";
(self["webpackChunkbfswap"] = self["webpackChunkbfswap"] || []).push([["apps_bfswap_src_assets_wallet-util_ecpair-d70f6d1c_mjs"],{

/***/ 18047:
/*!***********************************************************************!*\
  !*** ./apps/bfswap/src/assets/wallet-util/WASMInterface-4e8d37b8.mjs ***!
  \***********************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   a: () => (/* binding */ c),
/* harmony export */   b: () => (/* binding */ b),
/* harmony export */   c: () => (/* binding */ C),
/* harmony export */   d: () => (/* binding */ d),
/* harmony export */   e: () => (/* binding */ y),
/* harmony export */   f: () => (/* binding */ w),
/* harmony export */   g: () => (/* binding */ f),
/* harmony export */   h: () => (/* binding */ p),
/* harmony export */   i: () => (/* binding */ s),
/* harmony export */   j: () => (/* binding */ A),
/* harmony export */   v: () => (/* binding */ g),
/* harmony export */   w: () => (/* binding */ o)
/* harmony export */ });
/* harmony import */ var D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 52542);
/* harmony import */ var _index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./index-d96f2042.mjs */ 99449);

var _r$Buffer;

var t = class {
  constructor() {
    this.mutex = Promise.resolve();
  }
  lock() {
    let e = () => {};
    return this.mutex = this.mutex.then(() => new Promise(e)), new Promise(t => {
      e = t;
    });
  }
  dispatch(e) {
    var _this = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const t = yield _this.lock();
      try {
        return yield e();
      } finally {
        t();
      }
    })();
  }
};
const r = "undefined" != typeof globalThis ? globalThis : "undefined" != typeof self ? self : "undefined" != typeof window ? window : global,
  n = (_r$Buffer = r.Buffer) !== null && _r$Buffer !== void 0 ? _r$Buffer : null,
  a = r.TextEncoder ? new r.TextEncoder() : null;
function s(e, t) {
  return String.fromCharCode(...e.subarray(0, t));
}
function o(e, t) {
  const r = t.length >> 1;
  for (let s = 0; s < r; s++) {
    const r = s << 1;
    e[s] = (n = t.charCodeAt(r), a = t.charCodeAt(r + 1), (15 & n) + (n >> 6 | n >> 3 & 8) << 4 | (15 & a) + (a >> 6 | a >> 3 & 8));
  }
  var n, a;
}
const i = "a".charCodeAt(0) - 10,
  h = "0".charCodeAt(0);
function c(e, t, r) {
  let n = 0;
  for (let a = 0; a < r; a++) {
    let r = t[a] >>> 4;
    e[n++] = r > 9 ? r + i : r + h, r = 15 & t[a], e[n++] = r > 9 ? r + i : r + h;
  }
  return String.fromCharCode.apply(null, e);
}
const f = null !== n ? e => {
    if ("string" == typeof e) {
      const t = n.from(e, "utf8");
      return new Uint8Array(t.buffer, t.byteOffset, t.length);
    }
    if (n.isBuffer(e)) return new Uint8Array(e.buffer, e.byteOffset, e.length);
    if (ArrayBuffer.isView(e)) return new Uint8Array(e.buffer, e.byteOffset, e.byteLength);
    throw new Error("Invalid data type!");
  } : e => {
    if ("string" == typeof e) return a.encode(e);
    if (ArrayBuffer.isView(e)) return new Uint8Array(e.buffer, e.byteOffset, e.byteLength);
    throw new Error("Invalid data type!");
  },
  l = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/",
  u = new Uint8Array(256);
for (let e = 0; e < l.length; e++) u[l.charCodeAt(e)] = e;
function w(e, t = !0) {
  const r = e.length,
    n = r % 3,
    a = [],
    s = r - n;
  for (let t = 0; t < s; t += 3) {
    const r = (e[t] << 16 & 16711680) + (e[t + 1] << 8 & 65280) + (255 & e[t + 2]),
      n = l.charAt(r >> 18 & 63) + l.charAt(r >> 12 & 63) + l.charAt(r >> 6 & 63) + l.charAt(63 & r);
    a.push(n);
  }
  if (1 === n) {
    const n = e[r - 1],
      s = l.charAt(n >> 2),
      o = l.charAt(n << 4 & 63);
    a.push(`${s}${o}`), t && a.push("==");
  } else if (2 === n) {
    const n = (e[r - 2] << 8) + e[r - 1],
      s = l.charAt(n >> 10),
      o = l.charAt(n >> 4 & 63),
      i = l.charAt(n << 2 & 63);
    a.push(`${s}${o}${i}`), t && a.push("=");
  }
  return a.join("");
}
function y(e) {
  let t = Math.floor(.75 * e.length);
  const r = e.length;
  return "=" === e[r - 1] && (t -= 1, "=" === e[r - 2] && (t -= 1)), t;
}
function d(e) {
  const t = y(e),
    r = e.length,
    n = new Uint8Array(t);
  let a = 0;
  for (let t = 0; t < r; t += 4) {
    const r = u[e.charCodeAt(t)],
      s = u[e.charCodeAt(t + 1)],
      o = u[e.charCodeAt(t + 2)],
      i = u[e.charCodeAt(t + 3)];
    n[a] = r << 2 | s >> 4, a += 1, n[a] = (15 & s) << 4 | o >> 2, a += 1, n[a] = (3 & o) << 6 | 63 & i, a += 1;
  }
  return n;
}
function g(e, t) {
  if (!Number.isInteger(e) || e < 8 || e > t || e % 8 != 0) throw `Invalid variant! Valid values: 8, 16, ..., ${t}`;
}
function b(e, t) {
  return e | t << 16;
}
const m = e => !Number.isInteger(e) || e < 0 || e > 4294967295,
  A = e => {
    if (m(e)) throw new Error("Seed must be a valid 32-bit long unsigned integer.");
  },
  p = (e, t) => {
    if (m(e) || m(t)) throw new Error("Seed must be given as two valid 32-bit long unsigned integers (lo + high).");
  };
const x = new t(),
  v = new Map(),
  U = /*#__PURE__*/function () {
    var _ref = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (t) {
      let r = v.get(t);
      return void 0 === r && (r = x.dispatch(() => function () {
        var _ref2 = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (t) {
          const r = `${_index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_1__.c.wasmBaseUrl}/hash-wasm/${t}.wasm`,
            n = yield _index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_1__.c.wasmLoader(r);
          return {
            data: n,
            sha1: yield crypto.subtle.digest("SHA-1", n)
          };
        });
        return function (_x2) {
          return _ref2.apply(this, arguments);
        };
      }()(t).then( /*#__PURE__*/function () {
        var _ref3 = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (e) {
          const r = new Uint8Array(e.sha1.slice(0, 4)),
            n = yield WebAssembly.compile(e.data),
            a = {
              hash: r,
              module: n,
              instance: yield WebAssembly.instantiate(n, {})
            };
          return v.set(t, a), a;
        });
        return function (_x3) {
          return _ref3.apply(this, arguments);
        };
      }())), v.set(t, r)), yield r;
    });
    return function U(_x) {
      return _ref.apply(this, arguments);
    };
  }(),
  E = (e, t, r) => {
    const {
        instance: n,
        hash: a
      } = e,
      s = n.exports;
    let o = new Uint8Array(s.memory.buffer, s.Hash_GetBuffer(), 16384),
      i = !1;
    const h = () => o,
      l = () => new DataView(s.memory.buffer).getUint32(s.STATE_SIZE, !0),
      u = e => {
        i = !0, s.Hash_Init(e);
      },
      w = e => {
        if (!i) throw new Error("update() called before init()");
        (e => {
          let t = 0;
          for (; t < e.length;) {
            const r = e.subarray(t, t + 16384);
            t += r.length, h().set(r), s.Hash_Update(r.length);
          }
        })(f(e));
      },
      y = new Uint8Array(2 * r),
      d = (e = "binary", t) => {
        if (!i) throw new Error("digest() called before init()");
        return i = !1, s.Hash_Final(t), "hex" === e ? c(y, h(), r) : h().slice(0, r);
      },
      g = e => "string" == typeof e ? e.length < 4096 : e.byteLength < 16384;
    let b = g;
    switch (t) {
      case "argon2":
      case "scrypt":
        b = () => !0;
        break;
      case "blake2b":
      case "blake2s":
        b = (e, t) => "number" == typeof t && t <= 512 && g(e);
        break;
      case "blake3":
        b = (e, t) => 0 === t && g(e);
        break;
      case "xxhash64":
      case "xxhash3":
      case "xxhash128":
        b = () => !1;
    }
    return {
      getMemory: h,
      writeMemory: (e, t = 0) => {
        h().set(e, t);
      },
      getExports: () => s,
      setMemorySize: e => {
        s.Hash_SetMemorySize(e), o = new Uint8Array(s.memory.buffer, s.Hash_GetBuffer(), e);
      },
      init: u,
      update: w,
      digest: d,
      save: () => {
        if (!i) throw new Error("save() can only be called after init() and before digest()");
        const e = s.Hash_GetState(),
          t = l(),
          r = s.memory.buffer,
          n = new Uint8Array(r, e, t),
          o = new Uint8Array(4 + t);
        return o.set(a, 0), o.set(n, 4), o;
      },
      load: e => {
        if (!(e instanceof Uint8Array)) throw new Error("load() expects an Uint8Array generated by save()");
        const t = s.Hash_GetState(),
          r = l(),
          n = 4 + r,
          o = s.memory.buffer;
        if (e.length !== n) throw new Error(`Bad state length (expected ${n} bytes, got ${e.length})`);
        if (!function (e, t) {
          if (e.length !== t.length) return !1;
          for (let r = 0; r < e.length; r++) if (e[r] !== t[r]) return !1;
          return !0;
        }(a, e.subarray(0, 4))) throw new Error("This state was written by an incompatible hash implementation");
        const h = e.subarray(4);
        new Uint8Array(o, t, r).set(h), i = !0;
      },
      calculate: (e, t, n) => {
        if (!b(e, t)) return u(t), w(e), d("hex", n);
        const a = f(e);
        return h().set(a), s.Hash_Calculate(a.length, t, n), c(y, h(), r);
      },
      hashLength: r
    };
  },
  C = (e, t) => {
    const r = () => function () {
      var _ref4 = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (e, t) {
        return E(yield U(e), e, t);
      });
      return function (_x4, _x5) {
        return _ref4.apply(this, arguments);
      };
    }()(e, t);
    return Object.defineProperties(r, {
      wasm: {
        get() {
          const r = v.get(e);
          if (void 0 === r || r instanceof Promise) throw new Error(`wasm instance ${e} is not yet ready.`);
          return E(r, e, t);
        }
      },
      prepare: {
        value: function () {
          var _ref5 = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
            yield U(e);
          });
          return function value() {
            return _ref5.apply(this, arguments);
          };
        }()
      }
    }), r;
  };


/***/ }),

/***/ 56042:
/*!****************************************************************!*\
  !*** ./apps/bfswap/src/assets/wallet-util/ecpair-d70f6d1c.mjs ***!
  \****************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ECPairFactory: () => (/* binding */ w),
/* harmony export */   networks: () => (/* binding */ n)
/* harmony export */ });
/* harmony import */ var _index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./index-d96f2042.mjs */ 99449);
/* harmony import */ var _index_02f15a92_mjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./index-02f15a92.mjs */ 2465);
/* harmony import */ var _typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./typeforce-a57e57b8.mjs */ 75473);
/* harmony import */ var _index_4062991a_mjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./index-4062991a.mjs */ 22269);
/* harmony import */ var _sha256_d88873b6_mjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./sha256-d88873b6.mjs */ 98080);
/* harmony import */ var _WASMInterface_4e8d37b8_mjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./WASMInterface-4e8d37b8.mjs */ 18047);






const s = {
  messagePrefix: "Bitcoin Signed Message:\n",
  bech32: "bc",
  bip32: {
    public: 76067358,
    private: 76066276
  },
  pubKeyHash: 0,
  scriptHash: 5,
  wif: 128
};
var n = Object.freeze({
  __proto__: null,
  bitcoin: s,
  testnet: {
    messagePrefix: "Bitcoin Signed Message:\n",
    bech32: "tb",
    bip32: {
      public: 70617039,
      private: 70615956
    },
    pubKeyHash: 111,
    scriptHash: 196,
    wif: 239
  }
});
const c = _typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_2__.t.compile({
    messagePrefix: _typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_2__.t.anyOf(_typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_2__.t.Buffer, _typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_2__.t.String),
    bip32: {
      public: _typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_2__.t.UInt32,
      private: _typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_2__.t.UInt32
    },
    pubKeyHash: _typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_2__.t.UInt8,
    scriptHash: _typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_2__.t.UInt8,
    wif: _typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_2__.t.UInt8
  }),
  a = _typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_2__.t.BufferN(32),
  p = _typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_2__.t.Array,
  h = _typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_2__.t.Boolean,
  f = _typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_2__.t.maybe,
  m = _typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_2__.t.maybe(_typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_2__.t.compile({
    compressed: f(h),
    network: f(c)
  }));
function w(n) {
  function c(r, e) {
    if ((0,_typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_2__.t)(a, r), !n.isPrivate(r)) throw new TypeError("Private key not in range [1, n)");
    return (0,_typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_2__.t)(m, e), new f(r, void 0, e);
  }
  function h(r, e) {
    return (0,_typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_2__.t)(n.isPoint, r), (0,_typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_2__.t)(m, e), new f(void 0, r, e);
  }
  class f {
    constructor(e, i, t) {
      this.__D = e, this.__Q = i, this.lowR = !1, void 0 === t && (t = {}), this.compressed = void 0 === t.compressed || t.compressed, this.network = t.network || s, void 0 !== i && (this.__Q = _index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_0__.B.from(n.pointCompress(i, this.compressed)));
    }
    get privateKey() {
      return this.__D;
    }
    get publicKey() {
      if (!this.__Q) {
        const e = n.pointFromScalar(this.__D, this.compressed);
        this.__Q = _index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_0__.B.from(e);
      }
      return this.__Q;
    }
    toWIF() {
      if (!this.__D) throw new Error("Missing private key");
      return (0,_index_02f15a92_mjs__WEBPACK_IMPORTED_MODULE_1__.e)(this.network.wif, this.__D, this.compressed);
    }
    tweak(r) {
      return this.privateKey ? this.tweakFromPrivateKey(r) : this.tweakFromPublicKey(r);
    }
    sign(e, i) {
      if (!this.__D) throw new Error("Missing private key");
      if (void 0 === i && (i = this.lowR), !1 === i) return _index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_0__.B.from(n.sign(e, this.__D));
      {
        let i = n.sign(e, this.__D);
        const t = _index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_0__.B.alloc(32, 0);
        let o = 0;
        for (; i[0] > 127;) o++, t.writeUIntLE(o, 0, 6), i = n.sign(e, this.__D, t);
        return _index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_0__.B.from(i);
      }
    }
    signSchnorr(e) {
      if (!this.privateKey) throw new Error("Missing private key");
      if (!n.signSchnorr) throw new Error("signSchnorr not supported by ecc library");
      return _index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_0__.B.from(n.signSchnorr(e, this.privateKey));
    }
    verify(r, e) {
      return n.verify(r, this.publicKey, e);
    }
    verifySchnorr(r, e) {
      if (!n.verifySchnorr) throw new Error("verifySchnorr not supported by ecc library");
      return n.verifySchnorr(r, this.publicKey.subarray(1, 33), e);
    }
    tweakFromPublicKey(e) {
      const i = 32 === (t = this.publicKey).length ? t : t.slice(1, 33);
      var t;
      const o = n.xOnlyPointAddTweak(i, e);
      if (!o || null === o.xOnlyPubkey) throw new Error("Cannot tweak public key!");
      const s = _index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_0__.B.from([0 === o.parity ? 2 : 3]);
      return h(_index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_0__.B.concat([s, o.xOnlyPubkey]), {
        network: this.network,
        compressed: this.compressed
      });
    }
    tweakFromPrivateKey(e) {
      const i = 3 === this.publicKey[0] || 4 === this.publicKey[0] && 1 == (1 & this.publicKey[64]) ? n.privateNegate(this.privateKey) : this.privateKey,
        t = n.privateAdd(i, e);
      if (!t) throw new Error("Invalid tweaked private key!");
      return c(_index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_0__.B.from(t), {
        network: this.network,
        compressed: this.compressed
      });
    }
  }
  return {
    isPoint: function (r) {
      return n.isPoint(r);
    },
    fromPrivateKey: c,
    fromPublicKey: h,
    fromWIF: function (r, e) {
      const t = (0,_index_02f15a92_mjs__WEBPACK_IMPORTED_MODULE_1__.d)(r),
        o = t.version;
      if (p(e)) {
        if (!(e = e.filter(r => o === r.wif).pop())) throw new Error("Unknown network version");
      } else if (o !== (e = e || s).wif) throw new Error("Invalid network version");
      return c(t.privateKey, {
        compressed: t.compressed,
        network: e
      });
    },
    makeRandom: function (i) {
      (0,_typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_2__.t)(m, i), void 0 === i && (i = {});
      const t = i.rng || _index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_0__.r;
      let s;
      do {
        s = _index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_0__.B.from(t(32)), (0,_typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_2__.t)(a, s);
      } while (!n.isPrivate(s));
      return c(s, i);
    }
  };
}


/***/ }),

/***/ 98080:
/*!****************************************************************!*\
  !*** ./apps/bfswap/src/assets/wallet-util/sha256-d88873b6.mjs ***!
  \****************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   a: () => (/* binding */ e),
/* harmony export */   c: () => (/* binding */ i),
/* harmony export */   p: () => (/* binding */ s),
/* harmony export */   s: () => (/* binding */ t)
/* harmony export */ });
/* harmony import */ var D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 52542);
/* harmony import */ var _WASMInterface_4e8d37b8_mjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./WASMInterface-4e8d37b8.mjs */ 18047);


const s = (0,_WASMInterface_4e8d37b8_mjs__WEBPACK_IMPORTED_MODULE_1__.c)("sha256", 32),
  t = /*#__PURE__*/function () {
    var _ref = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (a) {
      return (yield s()).calculate(a, 256);
    });
    return function t(_x) {
      return _ref.apply(this, arguments);
    };
  }(),
  e = /*#__PURE__*/function () {
    var _ref2 = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      return i(yield s());
    });
    return function e() {
      return _ref2.apply(this, arguments);
    };
  }(),
  i = (a = s.wasm) => {
    a.init(256);
    const t = {
      init: () => (a.init(256), t),
      update: s => (a.update(s), t),
      digest: s => a.digest(s),
      save: () => a.save(),
      load: s => (a.load(s), t),
      blockSize: 64,
      digestSize: 32
    };
    return t;
  };


/***/ })

}]);
//# sourceMappingURL=apps_bfswap_src_assets_wallet-util_ecpair-d70f6d1c_mjs.js.map