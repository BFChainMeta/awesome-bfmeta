"use strict";
(self["webpackChunkbfswap"] = self["webpackChunkbfswap"] || []).push([["apps_bfswap_src_assets_wallet-util_index-e04e1a4c_mjs"],{

/***/ 41449:
/*!***************************************************************!*\
  !*** ./apps/bfswap/src/assets/wallet-util/index-e04e1a4c.mjs ***!
  \***************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   closest: () => (/* binding */ o),
/* harmony export */   distance: () => (/* binding */ e)
/* harmony export */ });
const t = new Uint32Array(65536),
  e = (e, o) => {
    if (e.length < o.length) {
      const t = o;
      o = e, e = t;
    }
    return 0 === o.length ? e.length : e.length <= 32 ? ((e, o) => {
      const r = e.length,
        l = o.length,
        n = 1 << r - 1;
      let h = -1,
        c = 0,
        a = r,
        f = r;
      for (; f--;) t[e.charCodeAt(f)] |= 1 << f;
      for (f = 0; f < l; f++) {
        let e = t[o.charCodeAt(f)];
        const r = e | c;
        e |= (e & h) + h ^ h, c |= ~(e | h), h &= e, c & n && a++, h & n && a--, c = c << 1 | 1, h = h << 1 | ~(r | c), c &= r;
      }
      for (f = r; f--;) t[e.charCodeAt(f)] = 0;
      return a;
    })(e, o) : ((e, o) => {
      const r = o.length,
        l = e.length,
        n = [],
        h = [],
        c = Math.ceil(r / 32),
        a = Math.ceil(l / 32);
      for (let t = 0; t < c; t++) h[t] = -1, n[t] = 0;
      let f = 0;
      for (; f < a - 1; f++) {
        let c = 0,
          a = -1;
        const g = 32 * f,
          s = Math.min(32, l) + g;
        for (let o = g; o < s; o++) t[e.charCodeAt(o)] |= 1 << o;
        for (let e = 0; e < r; e++) {
          const r = t[o.charCodeAt(e)],
            l = h[e / 32 | 0] >>> e & 1,
            f = n[e / 32 | 0] >>> e & 1,
            g = r | c,
            s = ((r | f) & a) + a ^ a | r | f;
          let A = c | ~(s | a),
            d = a & s;
          A >>> 31 ^ l && (h[e / 32 | 0] ^= 1 << e), d >>> 31 ^ f && (n[e / 32 | 0] ^= 1 << e), A = A << 1 | l, d = d << 1 | f, a = d | ~(g | A), c = A & g;
        }
        for (let o = g; o < s; o++) t[e.charCodeAt(o)] = 0;
      }
      let g = 0,
        s = -1;
      const A = 32 * f,
        d = Math.min(32, l - A) + A;
      for (let o = A; o < d; o++) t[e.charCodeAt(o)] |= 1 << o;
      let C = l;
      for (let e = 0; e < r; e++) {
        const r = t[o.charCodeAt(e)],
          c = h[e / 32 | 0] >>> e & 1,
          a = n[e / 32 | 0] >>> e & 1,
          f = r | g,
          A = ((r | a) & s) + s ^ s | r | a;
        let d = g | ~(A | s),
          i = s & A;
        C += d >>> l - 1 & 1, C -= i >>> l - 1 & 1, d >>> 31 ^ c && (h[e / 32 | 0] ^= 1 << e), i >>> 31 ^ a && (n[e / 32 | 0] ^= 1 << e), d = d << 1 | c, i = i << 1 | a, s = i | ~(f | d), g = d & f;
      }
      for (let o = A; o < d; o++) t[e.charCodeAt(o)] = 0;
      return C;
    })(e, o);
  },
  o = (t, o) => {
    let r = 1 / 0,
      l = 0;
    for (let n = 0; n < o.length; n++) {
      const h = e(t, o[n]);
      h < r && (r = h, l = n);
    }
    return o[l];
  };


/***/ })

}]);
//# sourceMappingURL=apps_bfswap_src_assets_wallet-util_index-e04e1a4c_mjs.js.map