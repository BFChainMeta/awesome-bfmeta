"use strict";
(self["webpackChunkbfswap"] = self["webpackChunkbfswap"] || []).push([["apps_bfswap_src_pages_remove-liquidity_remove-liquidity_component_ts"],{

/***/ 26708:
/*!*****************************************************************************************!*\
  !*** ./apps/bfswap/src/components/remove-detail-panel/remove-detail-panel.component.ts ***!
  \*****************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   RemoveDetailPanelPage: () => (/* binding */ RemoveDetailPanelPage),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 52542);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! tslib */ 90505);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/core */ 61039);
/* harmony import */ var _components_token_with_chain_icon_token_with_chain_icon_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ~components/token-with-chain-icon/token-with-chain-icon.component */ 11342);
/* harmony import */ var _modules_page_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ~modules/page.module */ 16381);
/* harmony import */ var _pipes_amount_format_amount_format_pipe__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ~pipes/amount-format/amount-format.pipe */ 23377);
/* harmony import */ var _services_transaction_settings_transaction_settings_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ~services/transaction-settings/transaction-settings.service */ 80348);
/* harmony import */ var _services_wallet_wallet_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ~services/wallet/wallet.service */ 54275);
/* harmony import */ var _bnqkl_framework_plugins_toast__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @bnqkl/framework/plugins/toast */ 18030);
/* harmony import */ var _environments_index__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ~environments/index */ 11295);
/* harmony import */ var _plaoc_plugins__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @plaoc/plugins */ 53396);
/* harmony import */ var _libs_bnf_components_ripple_button_ripple_button_directive__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../../../../libs/bnf/components/ripple-button/ripple-button.directive */ 16505);
/* harmony import */ var _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../../../../libs/bnf/modules/page/common-page/common-page.component */ 62052);
/* harmony import */ var _icon_icon_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../icon/icon.component */ 18840);
/* harmony import */ var _libs_bnf_components_loading_wrapper_loading_wrapper_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../../../../libs/bnf/components/loading-wrapper/loading-wrapper.component */ 51263);
/* harmony import */ var _libs_bnf_pipes_amountFixed_amount_fixed_pipe__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../../../../../libs/bnf/pipes/amountFixed/amount-fixed.pipe */ 44070);

var _class;
















const _c12 = () => ({
  removeZero: true
});
/**
 * 移除流动性详情弹窗
 */
class RemoveDetailPanelPage extends _modules_page_module__WEBPACK_IMPORTED_MODULE_2__.CommonPageBase {
  constructor() {
    super(...arguments);
    /** 高级选项服务 */
    this.service = (0,_angular_core__WEBPACK_IMPORTED_MODULE_14__.inject)(_services_transaction_settings_transaction_settings_service__WEBPACK_IMPORTED_MODULE_4__.TransactionSettingsService);
    /** TODO 返回类型 */
    this.returnValue$ = new _modules_page_module__WEBPACK_IMPORTED_MODULE_2__.PageReturnValue();
    /** 获得的锚定币数量 */
    this.gainAnchorCoin = '';
    /** 获得的报价币数量 */
    this.gainQuoteCoin = '';
    /** 滑点 */
    this.slippageTolerance = '';
    /** 过期时间 */
    this.expirationTime = '';
    /** 按钮文本 */
    this.btnText = "\u786E\u8BA4\u79FB\u9664";
    /** loading */
    this.loading = false;
    /** disabled */
    this.disabled = false;
    /** 钱包服务 */
    this.walletService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_14__.inject)(_services_wallet_wallet_service__WEBPACK_IMPORTED_MODULE_5__.WalletService);
    /** 移除的LP数量 */
    this.lpAmount = '';
    this.preParams = undefined;
  }
  /** 初始化数据 */
  init() {
    var _slippageTolerance$la, _expirationTime$label;
    const {
      slippageTolerance,
      expirationTime
    } = this.service.getSelectedValue();
    if (slippageTolerance === undefined || expirationTime === undefined) return;
    this.slippageTolerance = (_slippageTolerance$la = slippageTolerance === null || slippageTolerance === void 0 ? void 0 : slippageTolerance.label) !== null && _slippageTolerance$la !== void 0 ? _slippageTolerance$la : '';
    this.expirationTime = (_expirationTime$label = expirationTime === null || expirationTime === void 0 ? void 0 : expirationTime.label) !== null && _expirationTime$label !== void 0 ? _expirationTime$label : '';
  }
  /** 提交 */
  submit() {
    var _this = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const {
        preParams
      } = _this;
      if (preParams === undefined) {
        _this.console.error('移除面板数据出错：');
        _bnqkl_framework_plugins_toast__WEBPACK_IMPORTED_MODULE_6__.Toast.show('数据出错');
        return;
      }
      _this.btnText = "\u7B7E\u540D\u8BF7\u6C42\u4E2D";
      _this.loading = true;
      _this.disabled = true;
      const params = yield _this.walletService.getRemoveLiquidityOrderInfoWithSignature(preParams, _this.chainName);
      if (_this.loading && params) {
        if (_environments_index__WEBPACK_IMPORTED_MODULE_7__.environment.DWEB_APP) {
          _plaoc_plugins__WEBPACK_IMPORTED_MODULE_8__.windowPlugin.focusWindow();
        }
        _this.returnValue$.return({
          signature: params
        });
        _this.nav.back();
      } else {
        if (params === undefined) {
          _bnqkl_framework_plugins_toast__WEBPACK_IMPORTED_MODULE_6__.Toast.show('无钱包连接');
        } else if (params === null) {
          if (_environments_index__WEBPACK_IMPORTED_MODULE_7__.environment.DWEB_APP) {
            _plaoc_plugins__WEBPACK_IMPORTED_MODULE_8__.windowPlugin.focusWindow();
          }
          _bnqkl_framework_plugins_toast__WEBPACK_IMPORTED_MODULE_6__.Toast.show('签名被拒绝');
        } else {
          _bnqkl_framework_plugins_toast__WEBPACK_IMPORTED_MODULE_6__.Toast.show('签名出错');
        }
        _this.btnText = "\u786E\u8BA4\u79FB\u9664";
        _this.console.error('签名出错:sinature:', params);
      }
      _this.disabled = false;
      _this.loading = false;
    })();
  }
  handleClose() {
    this.disabled = false;
    this.loading = false;
    _bnqkl_framework_plugins_toast__WEBPACK_IMPORTED_MODULE_6__.Toast.show('交易取消');
    this.nav.back();
  }
}
_class = RemoveDetailPanelPage;
_class.ɵfac = /*@__PURE__*/(() => {
  let ɵRemoveDetailPanelPage_BaseFactory;
  return function RemoveDetailPanelPage_Factory(t) {
    return (ɵRemoveDetailPanelPage_BaseFactory || (ɵRemoveDetailPanelPage_BaseFactory = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵgetInheritedFactory"](_class)))(t || _class);
  };
})();
_class.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵdefineComponent"]({
  type: _class,
  selectors: [["bs-remove-detail-panel-page"]],
  inputs: {
    gainAnchorCoin: "gainAnchorCoin",
    gainQuoteCoin: "gainQuoteCoin",
    holdLiquidity: "holdLiquidity",
    lpAmount: "lpAmount",
    anchorTokenIcon: "anchorTokenIcon",
    anchorChainIcon: "anchorChainIcon",
    quoteTokenIcon: "quoteTokenIcon",
    quoteChainIcon: "quoteChainIcon",
    preParams: "preParams",
    chainName: "chainName"
  },
  outputs: {
    returnValue$: "returnValue$"
  },
  standalone: true,
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵInheritDefinitionFeature"], _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵStandaloneFeature"]],
  decls: 45,
  vars: 36,
  consts: () => {
    let i18n_0;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_4013246282088622929$$APPS_BFSWAP_SRC_COMPONENTS_REMOVE_DETAIL_PANEL_REMOVE_DETAIL_PANEL_COMPONENT_TS_1 = goog.getMsg("\u79FB\u9664\u6D41\u52A8\u6027\u8BE6\u60C5");
      i18n_0 = MSG_EXTERNAL_4013246282088622929$$APPS_BFSWAP_SRC_COMPONENTS_REMOVE_DETAIL_PANEL_REMOVE_DETAIL_PANEL_COMPONENT_TS_1;
    } else {
      i18n_0 = "\u79FB\u9664\u6D41\u52A8\u6027\u8BE6\u60C5";
    }
    let i18n_2;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_YOU_WILL_GET$$APPS_BFSWAP_SRC_COMPONENTS_REMOVE_DETAIL_PANEL_REMOVE_DETAIL_PANEL_COMPONENT_TS_3 = goog.getMsg("You will get");
      i18n_2 = MSG_EXTERNAL_YOU_WILL_GET$$APPS_BFSWAP_SRC_COMPONENTS_REMOVE_DETAIL_PANEL_REMOVE_DETAIL_PANEL_COMPONENT_TS_3;
    } else {
      i18n_2 = "\u60A8\u5C06\u83B7\u5F97";
    }
    let i18n_4;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_NUMBER_OF_POOL_TOKENS$$APPS_BFSWAP_SRC_COMPONENTS_REMOVE_DETAIL_PANEL_REMOVE_DETAIL_PANEL_COMPONENT_TS_5 = goog.getMsg(" {$interpolation}-{$interpolation_1} Number of pool tokens ", {
        "interpolation": "\uFFFD0\uFFFD",
        "interpolation_1": "\uFFFD1\uFFFD"
      }, {
        original_code: {
          "interpolation": "{{ holdLiquidity.anchorCoinsName }}",
          "interpolation_1": "{{ holdLiquidity.quoteCoinsName }}"
        }
      });
      i18n_4 = MSG_EXTERNAL_NUMBER_OF_POOL_TOKENS$$APPS_BFSWAP_SRC_COMPONENTS_REMOVE_DETAIL_PANEL_REMOVE_DETAIL_PANEL_COMPONENT_TS_5;
    } else {
      i18n_4 = "" + "\uFFFD0\uFFFD" + "-" + "\uFFFD1\uFFFD" + " \u5408\u7EA6\u6C60\u6743\u76CA\u9500\u6BC1 ";
    }
    let i18n_6;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_IF_THE_PRICE_CHANGES_BY_MORE_THAN_YOUR_TRANSACTION_WILL_BE_BOUNCED$$APPS_BFSWAP_SRC_COMPONENTS_REMOVE_DETAIL_PANEL_REMOVE_DETAIL_PANEL_COMPONENT_TS_7 = goog.getMsg(" If the price changes by more than {$interpolation},your transaction will be bounced ", {
        "interpolation": "\uFFFD0\uFFFD"
      }, {
        original_code: {
          "interpolation": "{{ slippageTolerance }}"
        }
      });
      i18n_6 = MSG_EXTERNAL_IF_THE_PRICE_CHANGES_BY_MORE_THAN_YOUR_TRANSACTION_WILL_BE_BOUNCED$$APPS_BFSWAP_SRC_COMPONENTS_REMOVE_DETAIL_PANEL_REMOVE_DETAIL_PANEL_COMPONENT_TS_7;
    } else {
      i18n_6 = "\u5982\u679C\u4EF7\u683C\u53D8\u5316\u8D85\u8FC7" + "\uFFFD0\uFFFD" + "\uFF0C\u60A8\u7684\u4EA4\u6613\u5C06\u88AB\u56DE\u9000\u3002 ";
    }
    let i18n_8;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_SLIPPAGE_TOLERANCE$$APPS_BFSWAP_SRC_COMPONENTS_REMOVE_DETAIL_PANEL_REMOVE_DETAIL_PANEL_COMPONENT_TS_9 = goog.getMsg("Slippage Tolerance");
      i18n_8 = MSG_EXTERNAL_SLIPPAGE_TOLERANCE$$APPS_BFSWAP_SRC_COMPONENTS_REMOVE_DETAIL_PANEL_REMOVE_DETAIL_PANEL_COMPONENT_TS_9;
    } else {
      i18n_8 = "\u6ED1\u70B9\u5BB9\u5FCD\u5EA6";
    }
    let i18n_10;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_DEADLINE$$APPS_BFSWAP_SRC_COMPONENTS_REMOVE_DETAIL_PANEL_REMOVE_DETAIL_PANEL_COMPONENT_TS_11 = goog.getMsg("DeadLine");
      i18n_10 = MSG_EXTERNAL_DEADLINE$$APPS_BFSWAP_SRC_COMPONENTS_REMOVE_DETAIL_PANEL_REMOVE_DETAIL_PANEL_COMPONENT_TS_11;
    } else {
      i18n_10 = "\u622A\u6B62\u65F6\u95F4";
    }
    return [["headerTitle", i18n_0, 3, "titleClass", "headerClass", "hideBackButton", "contentBackground", "contentClass", "contentSafeArea"], ["endMenu", "", "bnRippleButton", "", 1, "icon-7", 3, "mode", "click"], ["name", "icon-popup-close"], [1, "rounded-4", "bg-base-300", "mb-6", "mt-2.5", "p-4"], [1, "text-base-200", "mb-2", "text-sm"], i18n_2, [1, "mb-4", "grid", "grid-cols-2", "grid-rows-[2.5rem,2.5rem]", "items-center"], [1, "flex", "items-center", "justify-start", "justify-items-center"], [1, "mr-2.5", 3, "tokenName", "chainName"], [1, "text-title-10", "text-center", "text-base", "font-semibold"], [1, "text-title-10", "flex", "items-center", "justify-end", "text-base", "font-semibold"], [1, "flex", "items-center", "justify-start"], [1, "icon-7", "mr-2.5", 3, "name"], [1, "text-subtitle", "flex", "items-center", "justify-center", "text-center", "text-xs"], i18n_4, [1, "text-green-20", "font-bold"], [1, "text-subtitle", "text-center", "text-xs"], i18n_6, [1, "mb-4", "grid", "grid-cols-2", "items-center", "gap-y-1", "text-xs"], [1, "text-subtitle-2"], i18n_8, [1, "text-title-10", "text-right"], i18n_10, ["bnRippleButton", "", 1, "bg-primary", "rounded-12", "mb-6", "mt-6", "flex", "h-12", "w-full", "items-center", "justify-center", "text-lg", "font-semibold", "text-white", 3, "disabled", "click"], [1, "relative"], [1, "icon-6", "absolute", "-right-6", "top-0", 3, "loadingTheme", "showLoading"]];
  },
  template: function RemoveDetailPanelPage_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](0, "common-page", 0)(1, "button", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵlistener"]("click", function RemoveDetailPanelPage_Template_button_click_1_listener() {
        return ctx.nav.back();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelement"](2, "bs-icon", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](3, "div", 3)(4, "div", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵi18n"](5, 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](6, "div", 6)(7, "div", 7);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelement"](8, "bs-token-with-chain-icon", 8);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](9, "div", 9);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](10);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](11, "div", 10);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](12);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipe"](13, "amountFixed");
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](14, "div", 11);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelement"](15, "bs-icon", 12);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](16, "div", 9);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](17);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](18, "div", 10);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](19);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipe"](20, "amountFixed");
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](21, "div", 13)(22, "div");
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵi18n"](23, 14);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](24, "div", 15);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](25);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipe"](26, "amountFormat");
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](27, "div");
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](28, "\u3002");
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](29, "div", 16);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵi18n"](30, 17);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](31, "div", 18)(32, "div", 19);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵi18n"](33, 20);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](34, "div", 21);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](35);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](36, "div", 19);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵi18n"](37, 22);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](38, "div", 21);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](39);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](40, "section")(41, "button", 23);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵlistener"]("click", function RemoveDetailPanelPage_Template_button_click_41_listener() {
        return ctx.submit();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](42, "div", 24);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](43);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelement"](44, "bn-loading-wrapper", 25);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]()()()();
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("titleClass", "!text-title-10")("headerClass", "pt-2.5 text-lg")("hideBackButton", true)("contentBackground", "white")("contentClass", "px-4")("contentSafeArea", true);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("mode", "icon");
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](7);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("tokenName", ctx.anchorTokenIcon)("chainName", ctx.anchorChainIcon);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtextInterpolate"](ctx.holdLiquidity.anchorCoinsName);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipeBind3"](13, 24, ctx.gainAnchorCoin, 8, _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpureFunction0"](34, _c12)), " ");
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("name", ctx.quoteTokenIcon);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtextInterpolate"](ctx.holdLiquidity.quoteCoinsName);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipeBind3"](20, 28, ctx.gainQuoteCoin, 8, _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpureFunction0"](35, _c12)), " ");
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](4);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵi18nExp"](ctx.holdLiquidity.anchorCoinsName)(ctx.holdLiquidity.quoteCoinsName);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵi18nApply"](23);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipeBind1"](26, 32, ctx.lpAmount));
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](5);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵi18nExp"](ctx.slippageTolerance);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵi18nApply"](30);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](5);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtextInterpolate"](ctx.slippageTolerance);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](4);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtextInterpolate"](ctx.expirationTime);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("disabled", ctx.disabled);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtextInterpolate1"](" ", ctx.btnText, " ");
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("loadingTheme", "ellipsis")("showLoading", ctx.loading);
    }
  },
  dependencies: [_pipes_amount_format_amount_format_pipe__WEBPACK_IMPORTED_MODULE_3__.AmountFormatPipe, _modules_page_module__WEBPACK_IMPORTED_MODULE_2__.CommonPageModule, _libs_bnf_components_ripple_button_ripple_button_directive__WEBPACK_IMPORTED_MODULE_9__.RippleButtonDirective, _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_10__.CommonPageComponent, _icon_icon_component__WEBPACK_IMPORTED_MODULE_11__.IconComponent, _libs_bnf_components_loading_wrapper_loading_wrapper_component__WEBPACK_IMPORTED_MODULE_12__.LoadingWrapperComponent, _libs_bnf_pipes_amountFixed_amount_fixed_pipe__WEBPACK_IMPORTED_MODULE_13__.AmountFixedPipe, _components_token_with_chain_icon_token_with_chain_icon_component__WEBPACK_IMPORTED_MODULE_1__.TokenWithnChainIconComponent],
  encapsulation: 2,
  changeDetection: 0
});
(0,tslib__WEBPACK_IMPORTED_MODULE_15__.__decorate)([RemoveDetailPanelPage.OnInit(), (0,tslib__WEBPACK_IMPORTED_MODULE_15__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_15__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_15__.__metadata)("design:returntype", void 0)], RemoveDetailPanelPage.prototype, "init", null);
(0,tslib__WEBPACK_IMPORTED_MODULE_15__.__decorate)([RemoveDetailPanelPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_15__.__metadata)("design:type", Object)], RemoveDetailPanelPage.prototype, "slippageTolerance", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_15__.__decorate)([RemoveDetailPanelPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_15__.__metadata)("design:type", Object)], RemoveDetailPanelPage.prototype, "expirationTime", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_15__.__decorate)([RemoveDetailPanelPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_15__.__metadata)("design:type", Object)], RemoveDetailPanelPage.prototype, "btnText", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_15__.__decorate)([RemoveDetailPanelPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_15__.__metadata)("design:type", Object)], RemoveDetailPanelPage.prototype, "loading", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_15__.__decorate)([RemoveDetailPanelPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_15__.__metadata)("design:type", Object)], RemoveDetailPanelPage.prototype, "disabled", void 0);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (RemoveDetailPanelPage);

/***/ }),

/***/ 67946:
/*!***************************************************************************************!*\
  !*** ./apps/bfswap/src/components/select-chain-panel/select-chain-panel.component.ts ***!
  \***************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   SelectChainPanelPage: () => (/* binding */ SelectChainPanelPage),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! tslib */ 90505);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 61039);
/* harmony import */ var _modules_page_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ~modules/page.module */ 16381);
/* harmony import */ var _services_wallet_wallet_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ~services/wallet/wallet.service */ 54275);
/* harmony import */ var _bnqkl_framework_animations__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @bnqkl/framework/animations */ 43127);
/* harmony import */ var _services_liquidity_pool_liquidity_pool_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ~services/liquidity-pool/liquidity-pool.service */ 20213);
/* harmony import */ var _libs_bnf_components_ripple_button_ripple_button_directive__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../../../libs/bnf/components/ripple-button/ripple-button.directive */ 16505);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/common */ 6729);
/* harmony import */ var _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../../../libs/bnf/modules/page/common-page/common-page.component */ 62052);
/* harmony import */ var _icon_icon_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../icon/icon.component */ 18840);
/* harmony import */ var _libs_bnf_pipes_amountFixed_amount_fixed_pipe__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../../../libs/bnf/pipes/amountFixed/amount-fixed.pipe */ 44070);
var _class;












const _forTrack4 = ($index, $item) => $item.chain;
function SelectChainPanelPage_ng_container_3_For_8_Template(rf, ctx) {
  if (rf & 1) {
    const _r12 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](0, "div", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵlistener"]("click", function SelectChainPanelPage_ng_container_3_For_8_Template_div_click_0_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵrestoreView"](_r12);
      const item_r6 = restoredCtx.$implicit;
      const ctx_r11 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵresetView"](ctx_r11.selectChain(item_r6));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](1, "div", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](2, "bs-icon", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](4, "div", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpipe"](6, "amountFixed");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const item_r6 = ctx.$implicit;
    const ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵclassMapInterpolate1"]("flex h-14 items-center px-4 justify-between ", ctx_r5.selectedPoolChain && ctx_r5.selectedPoolChain.chain === item_r6.chain ? "base-300" : "", "");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("name", item_r6.icon);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtextInterpolate1"](" ", item_r6.chain, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpipeBind2"](6, 6, item_r6.amount, 8));
  }
}
function SelectChainPanelPage_ng_container_3_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](1, "div", 6)(2, "div", 7)(3, "div", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵi18n"](4, 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](5, "div", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵi18n"](6, 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵrepeaterCreate"](7, SelectChainPanelPage_ng_container_3_For_8_Template, 7, 9, "div", 16, _forTrack4);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵi18nExp"](ctx_r0.selectedToken);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵi18nApply"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵrepeater"](ctx_r0.chainList);
  }
}
function SelectChainPanelPage_ng_template_4_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](1, "span", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementContainerEnd"]();
  }
}
const _c5 = () => ({
  height: "calc(100% - 3rem)"
});
function SelectChainPanelPage_ng_template_4_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](0, "div", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtemplate"](1, SelectChainPanelPage_ng_template_4_ng_container_1_Template, 2, 0, "ng-container", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵnextContext"]();
    const _r4 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵreference"](7);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("ngStyle", _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpureFunction0"](3, _c5));
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("ngIf", ctx_r1.updating)("ngIfElse", _r4);
  }
}
function SelectChainPanelPage_ng_template_6_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](0, "img", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](1, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵi18n"](2, 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
  }
}
/**
 * 选择币种弹窗
 */
class SelectChainPanelPage extends _modules_page_module__WEBPACK_IMPORTED_MODULE_0__.CommonPageBase {
  constructor() {
    var _this$poolService$upd;
    super(...arguments);
    this.walletService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_8__.inject)(_services_wallet_wallet_service__WEBPACK_IMPORTED_MODULE_1__.WalletService);
    this.poolService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_8__.inject)(_services_liquidity_pool_liquidity_pool_service__WEBPACK_IMPORTED_MODULE_3__.LiquidityPoolService);
    /** 当前选中的链 */
    this.selectedPoolChain = undefined;
    /** 链列表 */
    this.chainList = [];
    /** 当前选中的币种 */
    this.selectedToken = 'USDM';
    // /** 正在更新池子配置 */
    this.updating = (_this$poolService$upd = this.poolService.updateLiquidityPoolConfig_subject.value) === null || _this$poolService$upd === void 0 ? void 0 : _this$poolService$upd.updating;
    /** 返回类型 */
    this.returnValue$ = new _modules_page_module__WEBPACK_IMPORTED_MODULE_0__.PageReturnValue();
  }
  /** 监听数据 */
  initData() {
    // this.console.info('我打开了panel', this.selectedChain)
  }
  selectChain(item) {
    this.returnValue$.return(item);
  }
  /** 获取panel标题 */
  get chainPanelTitle() {
    return "\u9009\u62E9" + this.selectedToken + " \u94FE\u7C7B\u578B";
  }
}
_class = SelectChainPanelPage;
_class.ɵfac = /*@__PURE__*/(() => {
  let ɵSelectChainPanelPage_BaseFactory;
  return function SelectChainPanelPage_Factory(t) {
    return (ɵSelectChainPanelPage_BaseFactory || (ɵSelectChainPanelPage_BaseFactory = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵgetInheritedFactory"](_class)))(t || _class);
  };
})();
_class.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdefineComponent"]({
  type: _class,
  selectors: [["bs-select-chain-panel-page"]],
  inputs: {
    selectedPoolChain: "selectedPoolChain",
    chainList: "chainList",
    selectedToken: "selectedToken"
  },
  outputs: {
    returnValue$: "returnValue$"
  },
  standalone: true,
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵInheritDefinitionFeature"], _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵStandaloneFeature"]],
  decls: 8,
  vars: 10,
  consts: () => {
    let i18n_0;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_CHAIN$$APPS_BFSWAP_SRC_COMPONENTS_SELECT_CHAIN_PANEL_SELECT_CHAIN_PANEL_COMPONENT_TS__1 = goog.getMsg("chain");
      i18n_0 = MSG_EXTERNAL_CHAIN$$APPS_BFSWAP_SRC_COMPONENTS_SELECT_CHAIN_PANEL_SELECT_CHAIN_PANEL_COMPONENT_TS__1;
    } else {
      i18n_0 = "\u7C7B\u578B";
    }
    let i18n_2;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_REMAINNING_IN_THE_POOL$$APPS_BFSWAP_SRC_COMPONENTS_SELECT_CHAIN_PANEL_SELECT_CHAIN_PANEL_COMPONENT_TS__3 = goog.getMsg(" remainning in the pool {$interpolation} ", {
        "interpolation": "\uFFFD0\uFFFD"
      }, {
        original_code: {
          "interpolation": "{{ selectedToken }}"
        }
      });
      i18n_2 = MSG_EXTERNAL_REMAINNING_IN_THE_POOL$$APPS_BFSWAP_SRC_COMPONENTS_SELECT_CHAIN_PANEL_SELECT_CHAIN_PANEL_COMPONENT_TS__3;
    } else {
      i18n_2 = "\u6C60\u4E2D\u5269\u4F59 " + "\uFFFD0\uFFFD" + " ";
    }
    let i18n_6;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_THERE_IS_CURRENTLY_NO_LIQUIDITY_POOL_CONFIGURATION$$APPS_BFSWAP_SRC_COMPONENTS_SELECT_CHAIN_PANEL_SELECT_CHAIN_PANEL_COMPONENT_TS__7 = goog.getMsg(" There is currently no liquidity pool configuration ");
      i18n_6 = MSG_EXTERNAL_THERE_IS_CURRENTLY_NO_LIQUIDITY_POOL_CONFIGURATION$$APPS_BFSWAP_SRC_COMPONENTS_SELECT_CHAIN_PANEL_SELECT_CHAIN_PANEL_COMPONENT_TS__7;
    } else {
      i18n_6 = "\u76EE\u524D\u6CA1\u6709\u6D41\u52A8\u6027\u6C60\u914D\u7F6E";
    }
    return [[3, "headerTitle", "hideBackButton", "headerClass", "titleClass", "contentClass", "contentBackground", "contentSafeArea"], ["endMenu", "", "bnRippleButton", "", 1, "icon-7", 3, "mode", "click"], ["name", "icon-popup-close"], [4, "ngIf", "ngIfElse"], ["noAssetData", ""], ["noUpdating", ""], [1, "my-6"], [1, "mx-4", "flex", "justify-between"], [1, "text-subtitle-2", "ml-10", "text-xs"], i18n_0, [1, "text-subtitle-2", "text-xs"], i18n_2, [3, "click"], [1, "text-title-10", "flex", "items-center", "justify-end", "text-sm"], [1, "bg-base-100", "rounded-1.5", "ml-1", "mr-2", "border-[2px]", "border-white", "text-2xl", 3, "name"], [1, "text-title-10", "text-base", "font-bold"], [3, "class"], [1, "text-base-gray", "flex", "flex-col", "items-center", "justify-center", "text-sm", 3, "ngStyle"], [1, "duibs-loading", "duibs-loading-infinity", "duibs-loading-lg", "text-primary"], ["src", "./assets/images/placeholder-1.png", 1, "w-[14.6875rem]"], i18n_6];
  },
  template: function SelectChainPanelPage_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](0, "common-page", 0)(1, "button", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵlistener"]("click", function SelectChainPanelPage_Template_button_click_1_listener() {
        return ctx.nav.back();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](2, "bs-icon", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtemplate"](3, SelectChainPanelPage_ng_container_3_Template, 9, 1, "ng-container", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtemplate"](4, SelectChainPanelPage_ng_template_4_Template, 2, 4, "ng-template", null, 4, _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtemplateRefExtractor"])(6, SelectChainPanelPage_ng_template_6_Template, 3, 0, "ng-template", null, 5, _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtemplateRefExtractor"]);
    }
    if (rf & 2) {
      const _r2 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵreference"](5);
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("headerTitle", ctx.chainPanelTitle)("hideBackButton", true)("headerClass", "pt-2.5 text-lg")("titleClass", "!text-title-10")("contentClass", "!px-0")("contentBackground", "white")("contentSafeArea", true);
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("mode", "icon");
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("ngIf", ctx.chainList.length)("ngIfElse", _r2);
    }
  },
  dependencies: [_modules_page_module__WEBPACK_IMPORTED_MODULE_0__.CommonPageModule, _libs_bnf_components_ripple_button_ripple_button_directive__WEBPACK_IMPORTED_MODULE_4__.RippleButtonDirective, _angular_common__WEBPACK_IMPORTED_MODULE_9__.NgIf, _angular_common__WEBPACK_IMPORTED_MODULE_9__.NgStyle, _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_5__.CommonPageComponent, _icon_icon_component__WEBPACK_IMPORTED_MODULE_6__.IconComponent, _libs_bnf_pipes_amountFixed_amount_fixed_pipe__WEBPACK_IMPORTED_MODULE_7__.AmountFixedPipe],
  styles: [".panel-height[_ngcontent-%COMP%] {\n  height: calc(100% - 3rem);\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL2FwcHMvYmZzd2FwL3NyYy9jb21wb25lbnRzL3NlbGVjdC1jaGFpbi1wYW5lbC9zZWxlY3QtY2hhaW4tcGFuZWwuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBTUE7RUFDRSx5QkFBQTtBQUxGIiwic291cmNlc0NvbnRlbnQiOlsiLy8gOmhvc3Qge1xyXG4vLyAgIHNlY3Rpb24ge1xyXG4vLyAgICAgb3ZlcmZsb3c6IGhpZGRlbjtcclxuLy8gICB9XHJcbi8vIH1cclxuXHJcbi5wYW5lbC1oZWlnaHQge1xyXG4gIGhlaWdodDogY2FsYygxMDAlIC0gM3JlbSk7XHJcbn1cclxuIl0sInNvdXJjZVJvb3QiOiIifQ== */"],
  data: {
    animation: [_bnqkl_framework_animations__WEBPACK_IMPORTED_MODULE_2__.listFadeRightTrigger, _bnqkl_framework_animations__WEBPACK_IMPORTED_MODULE_2__.listFadeInRightTrigger, _bnqkl_framework_animations__WEBPACK_IMPORTED_MODULE_2__.listFadeOutLeftTrigger, _bnqkl_framework_animations__WEBPACK_IMPORTED_MODULE_2__.fadeInLeftTrigger]
  },
  changeDetection: 0
});
(0,tslib__WEBPACK_IMPORTED_MODULE_10__.__decorate)([SelectChainPanelPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__metadata)("design:type", Object)], SelectChainPanelPage.prototype, "selectedPoolChain", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_10__.__decorate)([SelectChainPanelPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__metadata)("design:type", Array)], SelectChainPanelPage.prototype, "chainList", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_10__.__decorate)([SelectChainPanelPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__metadata)("design:type", Object)], SelectChainPanelPage.prototype, "selectedToken", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_10__.__decorate)([SelectChainPanelPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__metadata)("design:type", Object)], SelectChainPanelPage.prototype, "updating", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_10__.__decorate)([SelectChainPanelPage.OnReady(), (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__metadata)("design:returntype", void 0)], SelectChainPanelPage.prototype, "initData", null);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SelectChainPanelPage);

/***/ }),

/***/ 11342:
/*!*********************************************************************************************!*\
  !*** ./apps/bfswap/src/components/token-with-chain-icon/token-with-chain-icon.component.ts ***!
  \*********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   TokenWithnChainIconComponent: () => (/* binding */ TokenWithnChainIconComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! tslib */ 90505);
/* harmony import */ var _bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @bnqkl/bnqkl-swap-core */ 70195);
/* harmony import */ var _services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ~services/wallet/wallet.helper */ 84813);
/* harmony import */ var _modules_comp_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ~modules/comp.module */ 58281);
/* harmony import */ var _modules_page_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ~modules/page.module */ 16381);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 61039);
/* harmony import */ var _icon_icon_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../icon/icon.component */ 18840);
var _class;







function TokenWithnChainIconComponent_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](1, "bs-icon", 1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵstyleMap"](ctx_r0.sizeClass.chainTranslate);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵstyleMap"](ctx_r0.sizeClass.chainSize);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("name", ctx_r0.chainName);
  }
}
/** Token和chain组合图标 */
class TokenWithnChainIconComponent extends _modules_comp_module__WEBPACK_IMPORTED_MODULE_2__.CommonCompBase {
  constructor() {
    super(...arguments);
    /** token的大小 */
    this.tokenSize = 'icon-8';
    /** chain的大小 */
    this.chainSize = 'icon-4';
    /** 尺寸默认32 */
    this.size = 0;
    /** 尺寸样式 */
    this.sizeClass = {
      chainSize: 'font-size:1rem',
      coinSize: 'font-size:2rem',
      chainTranslate: 'transform: translate(6px,8px)'
    };
  }
  /** 初始化参数 */
  init() {
    this.handleIcon();
    this.handleSize();
  }
  /** 处理尺寸 */
  handleSize() {
    const {
      size
    } = this;
    if (size > 0) {
      const CHAINSIZE = 16;
      const COINSIZE = 32;
      const TRANSLATEX = 6;
      const TRANSLATEY = 8;
      const times = size / COINSIZE;
      this.sizeClass.chainSize = `font-size:${CHAINSIZE * times}px`;
      this.sizeClass.coinSize = `font-size:${COINSIZE * times}px`;
      this.sizeClass.chainTranslate = `transform: translate(${TRANSLATEX * times}px,${TRANSLATEY * times}px)`;
    }
  }
  /** 处理图标名称 */
  handleIcon() {
    const {
      swapChainName,
      swapCoinName
    } = this;
    if (swapChainName) {
      const chainName = swapChainName in _bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_0__.BNQKL_SWAP_CHAIN_NAME ? _services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_1__.NODE_CHAIN_NAME_TRANSFER[swapChainName] : swapChainName;
      const chainIcon = (0,_services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_1__.transferToChainIcon)(chainName);
      this.chainName = chainIcon;
      if (swapCoinName) {
        const coinIcon = (0,_services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_1__.transferToTokenIconBychainName)(chainName, swapCoinName);
        this.tokenName = coinIcon;
      }
    }
  }
}
_class = TokenWithnChainIconComponent;
_class.ɵfac = /*@__PURE__*/(() => {
  let ɵTokenWithnChainIconComponent_BaseFactory;
  return function TokenWithnChainIconComponent_Factory(t) {
    return (ɵTokenWithnChainIconComponent_BaseFactory || (ɵTokenWithnChainIconComponent_BaseFactory = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵgetInheritedFactory"](_class)))(t || _class);
  };
})();
_class.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineComponent"]({
  type: _class,
  selectors: [["bs-token-with-chain-icon"]],
  inputs: {
    tokenSize: "tokenSize",
    tokenName: "tokenName",
    chainSize: "chainSize",
    chainName: "chainName",
    size: "size",
    swapChainName: "swapChainName",
    swapCoinName: "swapCoinName"
  },
  standalone: true,
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵInheritDefinitionFeature"], _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵStandaloneFeature"]],
  decls: 3,
  vars: 4,
  consts: [[1, "relative", "flex", "items-center", "justify-center"], [3, "name"], ["class", "bg-blue-10 rounded-1 absolute bottom-0 right-0 flex  items-center justify-center border-[2px] border-white", 3, "style"], [1, "bg-blue-10", "rounded-1", "absolute", "bottom-0", "right-0", "flex", "items-center", "justify-center", "border-[2px]", "border-white"]],
  template: function TokenWithnChainIconComponent_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 0);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](1, "bs-icon", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](2, TokenWithnChainIconComponent_Conditional_2_Template, 2, 5, "div", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵstyleMap"](ctx.sizeClass.coinSize);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("name", ctx.tokenName);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵconditional"](2, ctx.chainName ? 2 : -1);
    }
  },
  dependencies: [_modules_page_module__WEBPACK_IMPORTED_MODULE_3__.CommonPageModule, _icon_icon_component__WEBPACK_IMPORTED_MODULE_4__.IconComponent],
  encapsulation: 2,
  changeDetection: 0
});
(0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([TokenWithnChainIconComponent.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__metadata)("design:type", Object)], TokenWithnChainIconComponent.prototype, "sizeClass", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([TokenWithnChainIconComponent.OnChanges(), (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__metadata)("design:returntype", void 0)], TokenWithnChainIconComponent.prototype, "init", null);

/***/ }),

/***/ 892:
/*!******************************************************************************!*\
  !*** ./apps/bfswap/src/pages/remove-liquidity/remove-liquidity.component.ts ***!
  \******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   RemoveLiquidityPage: () => (/* binding */ RemoveLiquidityPage),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 52542);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! tslib */ 90505);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! @angular/common */ 6729);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! @angular/core */ 61039);
/* harmony import */ var _components_remove_detail_panel_remove_detail_panel_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ~components/remove-detail-panel/remove-detail-panel.component */ 26708);
/* harmony import */ var _components_token_with_chain_icon_token_with_chain_icon_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ~components/token-with-chain-icon/token-with-chain-icon.component */ 11342);
/* harmony import */ var _modules_page_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ~modules/page.module */ 16381);
/* harmony import */ var _components_order_settings_order_settings_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ~components/order-settings/order-settings.component */ 67877);
/* harmony import */ var _services_transaction_settings_transaction_settings_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ~services/transaction-settings/transaction-settings.service */ 80348);
/* harmony import */ var _bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @bnqkl/bnqkl-swap-core */ 70195);
/* harmony import */ var _services_liquidity_order_liquidity_order_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ~services/liquidity-order/liquidity-order.service */ 84435);
/* harmony import */ var _services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ~services/wallet/wallet.helper */ 84813);
/* harmony import */ var bignumber_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! bignumber.js */ 61994);
/* harmony import */ var _services_wallet_wallet_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ~services/wallet/wallet.service */ 54275);
/* harmony import */ var _bnqkl_framework_plugins_toast__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @bnqkl/framework/plugins/toast */ 18030);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! @angular/forms */ 7820);
/* harmony import */ var _bnqkl_wallet_base_tools__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @bnqkl/wallet-base/tools */ 38881);
/* harmony import */ var _bnqkl_framework_pipes__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @bnqkl/framework/pipes */ 80909);
/* harmony import */ var _services_liquidity_pool_liquidity_pool_service__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ~services/liquidity-pool/liquidity-pool.service */ 20213);
/* harmony import */ var _bnqkl_util_web_extends_promise__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @bnqkl/util-web/extends-promise */ 87778);
/* harmony import */ var _components_select_chain_panel_select_chain_panel_component__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ~components/select-chain-panel/select-chain-panel.component */ 67946);
/* harmony import */ var _services_liquidity_user_liquidity_user_service__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ~services/liquidity-user/liquidity-user.service */ 34913);
/* harmony import */ var _libs_bnf_modules_bottom_sheet_components_bottom_sheet_component__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ../../../../../libs/bnf/modules/bottom-sheet/components/bottom-sheet.component */ 94072);
/* harmony import */ var _libs_bnf_components_ripple_button_ripple_button_directive__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ../../../../../libs/bnf/components/ripple-button/ripple-button.directive */ 16505);
/* harmony import */ var _libs_bnf_directives_auto_complete_off_directive__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ../../../../../libs/bnf/directives/auto-complete-off.directive */ 66722);
/* harmony import */ var _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! ../../../../../libs/bnf/modules/page/common-page/common-page.component */ 62052);
/* harmony import */ var _components_icon_icon_component__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! ../../components/icon/icon.component */ 18840);
/* harmony import */ var _libs_bnf_components_loading_wrapper_loading_wrapper_component__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! ../../../../../libs/bnf/components/loading-wrapper/loading-wrapper.component */ 51263);
/* harmony import */ var _libs_bnf_pipes_amountFixed_amount_fixed_pipe__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! ../../../../../libs/bnf/pipes/amountFixed/amount-fixed.pipe */ 44070);

var _class;































const _c0 = ["inputRef"];
function RemoveLiquidityPage_Conditional_23_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵelement"](0, "bn-loading-wrapper", 60);
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵproperty"]("loadingTheme", "ellipsis")("showLoading", true);
  }
}
function RemoveLiquidityPage_Conditional_24_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵelementStart"](0, "div", 61);
    _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵi18nStart"](1, 62);
    _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵelement"](2, "bs-icon", 63)(3, "bs-icon", 64);
    _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵi18nEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵproperty"]("name", ctx_r1.selectHoldChainInfo.icon);
    _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵi18nExp"](ctx_r1.selectHoldChainInfo.chain);
    _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵi18nApply"](1);
  }
}
function RemoveLiquidityPage_Conditional_25_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵelementStart"](0, "div", 65);
    _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵi18nStart"](1, 66);
    _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵelement"](2, "bs-icon", 67);
    _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵi18nEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵelementEnd"]();
  }
}
const _c25 = () => ({
  removeZero: true
});
function RemoveLiquidityPage_Conditional_26_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵelementStart"](0, "div", 68);
    _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵelement"](1, "bs-icon", 69);
    _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵelementStart"](2, "div", 70);
    _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵi18n"](3, 71);
    _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵpipe"](5, "amountFixed");
    _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵpipeBind3"](5, 1, ctx_r3.selectHoldChainInfo.amount, 8, _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵpureFunction0"](5, _c25)), " ");
  }
}
function RemoveLiquidityPage_div_66_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵelementStart"](0, "div", 45);
    _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵi18nStart"](1, 72);
    _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵelement"](2, "bs-icon", 73)(3, "div", 74);
    _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵi18nEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵproperty"]("name", ctx_r5.selectHoldChainInfo.icon);
    _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵi18nExp"](ctx_r5.selectHoldChainInfo.chain);
    _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵi18nApply"](1);
  }
}
function RemoveLiquidityPage_ng_template_77_Template(rf, ctx) {
  if (rf & 1) {
    const _r10 = _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵelementStart"](0, "bs-select-chain-panel-page", 75);
    _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵlistener"]("returnValue$", function RemoveLiquidityPage_ng_template_77_Template_bs_select_chain_panel_page_returnValue__0_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵrestoreView"](_r10);
      const ctx_r9 = _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵresetView"](ctx_r9.onSelectChain($event));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵproperty"]("selectedToken", ctx_r6.holdLiquidity.quoteCoinsName)("chainList", ctx_r6.poolChainBalanceList)("selectedPoolChain", ctx_r6.selectHoldChainInfo);
  }
}
function RemoveLiquidityPage_ng_template_79_Template(rf, ctx) {
  if (rf & 1) {
    const _r12 = _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵelementStart"](0, "bs-remove-detail-panel-page", 76);
    _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵlistener"]("returnValue$", function RemoveLiquidityPage_ng_template_79_Template_bs_remove_detail_panel_page_returnValue__0_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵrestoreView"](_r12);
      const ctx_r11 = _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵresetView"](ctx_r11.onRemoveLIquiditySubmited($event));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r7 = _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵproperty"]("anchorTokenIcon", ctx_r7.anchorTokenIcon)("anchorChainIcon", ctx_r7.anchorChainIcon)("quoteTokenIcon", ctx_r7.quoteTokenIcon)("quoteChainIcon", ctx_r7.quoteChainIcon)("lpAmount", ctx_r7.lpCoinAmunt)("holdLiquidity", ctx_r7.holdLiquidity)("gainAnchorCoin", ctx_r7.gainAnchorCoin)("gainQuoteCoin", ctx_r7.gainQuoteCoin)("chainName", ctx_r7.selectHoldChainInfo.chain)("preParams", ctx_r7.preParams);
  }
}
function RemoveLiquidityPage_ng_template_81_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵelement"](0, "bs-order-settings-page", 77);
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵproperty"]("showAddLiquidityRatio", false);
  }
}
const _c28 = (a0, a1) => ({
  "bg-primary text-white": a0,
  "bg-blue-10 text-primary": a1
});
/** 移除流动性 */
class RemoveLiquidityPage extends _modules_page_module__WEBPACK_IMPORTED_MODULE_3__.CommonPageBase {
  constructor() {
    super(...arguments);
    /** 代币精确度 */
    this.DECIMALS = 8;
    /** 订单服务 */
    this.orderService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_25__.inject)(_services_liquidity_order_liquidity_order_service__WEBPACK_IMPORTED_MODULE_7__.LiquidityOrderService);
    /** 用户服务 */
    this.userService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_25__.inject)(_services_liquidity_user_liquidity_user_service__WEBPACK_IMPORTED_MODULE_17__.LiquidityUserService);
    /** 获得的锚定币数量 */
    this.gainAnchorCoin = '';
    /** 获得的报价币数量 */
    this.gainQuoteCoin = '';
    /** 高级设置服务 */
    this.settingsService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_25__.inject)(_services_transaction_settings_transaction_settings_service__WEBPACK_IMPORTED_MODULE_5__.TransactionSettingsService);
    /** 滑点容忍度 */
    this.slippageTolerance = '';
    /** 过期时间 */
    this.expirationTime = 0;
    /** lpCoin数量 */
    this.lpCoinAmunt = '';
    /** 持有数量 */
    this.holdCoinAmount = '0';
    /** 合约池服务 */
    this.poolService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_25__.inject)(_services_liquidity_pool_liquidity_pool_service__WEBPACK_IMPORTED_MODULE_14__.LiquidityPoolService);
    /** 池子详情 */
    this.poolDetail = undefined;
    /** 选择的链 */
    this.selectHoldChainInfo = undefined;
    /** 池子中的链 */
    this.poolChainBalanceList = [];
    /** 按钮loading */
    this.loading = false;
    /** 更新数据 */
    this.updating = false;
    /** 移除流动性提交面板的数据 */
    this.removeLiquiditySheet = {
      is_open: false
    };
    /** 按钮的文字 */
    this.btnText = "\u79FB\u9664"; // '移除';
    /** 按钮是否禁用 */
    this.btnDisabled = true;
    /** 钱包服务 */
    this.walletService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_25__.inject)(_services_wallet_wallet_service__WEBPACK_IMPORTED_MODULE_10__.WalletService);
    /** 连接的钱包 */
    this.connectedWallet = this.walletService.connectedWallet;
    /** 高级设置弹窗设置 */
    this.advancedSettingsSheet = {
      is_open: false
    };
    this.preParams = undefined;
    /** 锚定链名称 */
    this.anchorChainName = undefined;
    /** 报价链名称 */
    this.quoteChainName = undefined;
    /** 输入表单控制 */
    this.inputControl = new _angular_forms__WEBPACK_IMPORTED_MODULE_26__.FormControl('', {
      validators: [control => {
        // 矫正输入
        const inputValue = String(control.value);
        const {
          holdCoinAmount,
          DECIMALS
        } = this;
        const adjustValue = (0,_bnqkl_wallet_base_tools__WEBPACK_IMPORTED_MODULE_12__.getValueByDecimalsRange)(inputValue, DECIMALS);
        const over = new bignumber_js__WEBPACK_IMPORTED_MODULE_9__["default"](inputValue).isGreaterThan(holdCoinAmount);
        let value = '';
        if (adjustValue !== inputValue) {
          value = over ? holdCoinAmount : adjustValue;
        } else if (over) {
          value = this.holdCoinAmount;
        }
        if (value) {
          control.setValue(value);
        }
        return null;
      }]
    });
    /** 选择币种面板 */
    this.selectChainSheet = {
      isOpen: false
      // data: {
      //   liquidityPoolAssetsInfo: [] as $LiquidityPoolAssetInfoWithAmount[],
      //   selectedAsset: [{ tokenName: 'USDM', chainName: CHAIN_NAME.PMChain }] as $SelectAssetItem[],
      //   disabledAsset: [] as $SelectAssetItem[],
      //   noUSDM: false,
      //   chainGroupInfo: [] as $ChainItemInfo[],
      // },
    };
  }
  /** 初始化输入框输入事件 */
  initInputListenEvent() {
    this.inputRef && this.inputRef.nativeElement.addEventListener('input', this.inputEvent.bind(this));
  }
  /** 输入框输入事件 */
  inputEvent() {
    if (this.timer) {
      clearTimeout(this.timer);
    }
    this.timer = setTimeout(() => {
      this.handleCaculate();
      this.checkAmount();
      this.checkZero();
    }, 500);
  }
  /** 执行计算 */
  handleCaculate() {
    const {
      lpCoinAmunt,
      poolDetail,
      holdLiquidity
    } = this;
    if (Number.isNaN(parseInt(lpCoinAmunt))) {
      this.gainAnchorCoin = '';
      this.gainQuoteCoin = '';
      return;
    }
    const pool = poolDetail !== null && poolDetail !== void 0 ? poolDetail : holdLiquidity;
    const amount = new bignumber_js__WEBPACK_IMPORTED_MODULE_9__["default"](lpCoinAmunt).multipliedBy(1e8).toString();
    const {
      gainAnchorCoin,
      gainQuoteCoin
    } = _bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_6__.calculateHelper.calculateGainCoinByRemove(amount, pool);
    this.gainAnchorCoin = String(gainAnchorCoin);
    this.gainQuoteCoin = String(gainQuoteCoin);
  }
  /** 初始化数据 */
  dataInit() {
    var _this = this;
    // 监听池子详情变化
    this.poolDetail$ = this.poolService.liquidityPoolDetailQueryTask_subject.subscribe( /*#__PURE__*/function () {
      var _ref = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (detail) {
        if (detail == undefined) {
          return;
        }
        _this.console.info('移除流动性面板监听到池子详情变化', detail);
        if (detail) {
          const {
            liquidityPoolsdetail,
            updating
          } = detail;
          _this.loading = updating;
          if (updating) {
            _this.btnText = '正在获取数据';
            _this.btnDisabled = true;
          } else if (updating === false && liquidityPoolsdetail) {
            _this.poolDetail = liquidityPoolsdetail[0];
            _this.btnText = "\u79FB\u9664"; // 移除;
            _this.checkAmount();
            _this.checkZero();
            _this.poolDetail && _this.updateRemoveInfo(_this.poolDetail.quoteAssociatedCoins);
          }
        }
      });
      return function (_x) {
        return _ref.apply(this, arguments);
      };
    }());
  }
  removeSub() {
    var _this$poolDetail$;
    (_this$poolDetail$ = this.poolDetail$) === null || _this$poolDetail$ === void 0 || _this$poolDetail$.unsubscribe();
  }
  /** 更新移除信息 */
  updateRemoveInfo(coins) {
    /// 筛选本链的信息
    const chainUSDMInfo = {};
    coins.forEach(item => {
      if (item.coinName === this.holdLiquidity.quoteCoinsName) {
        const oldAmount = chainUSDMInfo[item.chainName] || '0';
        chainUSDMInfo[item.chainName] = String(BigInt(oldAmount) + BigInt(item.amount));
      }
    });
    const poolChainBalanceList = [];
    for (const key of Object.keys(chainUSDMInfo)) {
      const amount = chainUSDMInfo[key];
      poolChainBalanceList.push({
        tokenName: this.holdLiquidity.quoteCoinsName,
        chain: _services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_8__.NODE_CHAIN_NAME_TRANSFER[key],
        amount,
        icon: (0,_services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_8__.transferToChainIcon)(_services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_8__.NODE_CHAIN_NAME_TRANSFER[key])
      });
    }
    poolChainBalanceList.sort(item => item.chain > item.chain ? 1 : -1);
    this.poolChainBalanceList = poolChainBalanceList;
    if (this.selectHoldChainInfo) {
      const findItem = this.poolChainBalanceList.find(item => item.chain === this.selectHoldChainInfo.chain);
      findItem && (this.selectHoldChainInfo.amount = findItem.amount);
    }
    this.cdRef.detectChanges();
  }
  /** 打开移除流动性面板 */
  openRemoveLiquiditySheet() {
    var _this2 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      var _this2$connectedWalle, _this2$connectedWalle2;
      const {
        lpCoinAmunt,
        gainAnchorCoin,
        gainQuoteCoin
      } = _this2;
      const {
        slippageTolerance,
        expirationTime
      } = _this2.settingsService.getSelectedValue();
      const userId = (_this2$connectedWalle = _this2.connectedWallet) === null || _this2$connectedWalle === void 0 ? void 0 : _this2$connectedWalle.pmchainAddress;
      const publicKey = (_this2$connectedWalle2 = _this2.connectedWallet) === null || _this2$connectedWalle2 === void 0 ? void 0 : _this2$connectedWalle2.pmchainPublicKey;
      const {
        anchorCoinsName,
        anchorCoinsChainName,
        anchorCoinsAmount,
        quoteCoinsAmount,
        quoteCoinsChainName,
        quoteCoinsName,
        poolId
      } = _this2.holdLiquidity;
      if (userId === undefined || publicKey === undefined || slippageTolerance === undefined || expirationTime === undefined) {
        _this2.console.error('移除数据出错：');
        _bnqkl_framework_plugins_toast__WEBPACK_IMPORTED_MODULE_11__.Toast.show('数据出错');
        throw new Error('移除数据出错');
      }
      /// 判断是否足够支持移除
      /// 得到的数量
      if (BigInt(gainQuoteCoin) > BigInt(_this2.selectHoldChainInfo.amount)) {
        _bnqkl_framework_plugins_toast__WEBPACK_IMPORTED_MODULE_11__.Toast.show("\u5F53\u524D\u94FE\u4E2D\u7684 " + _this2.holdLiquidity.quoteCoinsName + " \u4E0D\u8DB3\uFF0C\u65E0\u6CD5\u63D0\u4EA4");
        return;
      }
      const anchor = {
        chainName: anchorCoinsChainName,
        coinName: anchorCoinsName,
        amount: gainAnchorCoin
      };
      const quote = {
        chainName: _services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_8__.NODE_CHAIN_NAME_TRANSFER_REVERSE[_this2.selectHoldChainInfo.chain],
        coinName: quoteCoinsName,
        amount: gainQuoteCoin
      };
      const startTime = Date.now();
      const params = {
        type: _bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_6__.ORDER_RECORD_TYPES.REMOVE_LIQUIDITY,
        poolId,
        userId,
        anchorCoinsRecipientAddress: userId,
        quoteCoinsRecipientAddress: userId,
        slippageTolerance: slippageTolerance.value,
        startTime: startTime,
        expirationTime: new bignumber_js__WEBPACK_IMPORTED_MODULE_9__["default"](startTime).plus(expirationTime.value).toNumber(),
        lpCoinsAmount: new bignumber_js__WEBPACK_IMPORTED_MODULE_9__["default"](lpCoinAmunt).multipliedBy(1e8).toString(),
        removeInfo: {
          anchor,
          quote
        },
        anchorCoinsAmount: anchorCoinsAmount,
        quoteCoinsAmount: quoteCoinsAmount,
        publicKey
      };
      _this2.preParams = params;
      const {
        removeLiquiditySheet
      } = _this2;
      if (removeLiquiditySheet.is_open) {
        return;
      }
      removeLiquiditySheet.is_open = true;
    })();
  }
  /** 检查是否输入数量 */
  checkAmount() {
    this.btnDisabled = Boolean(this.lpCoinAmunt) === false || Number(this.lpCoinAmunt) === 0;
  }
  /** 检查数量是否为零 */
  checkZero() {
    const {
      gainQuoteCoin,
      gainAnchorCoin
    } = this;
    this.btnDisabled = Number(gainAnchorCoin) <= 0 || Number(gainQuoteCoin) <= 0;
  }
  /** 初始化参数 */
  iniParams() {
    var _this3 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const {
        params
      } = _this3;
      if (params) {
        const {
          hold
        } = params;
        if (hold) {
          const holdLiquidity = JSON.parse(hold);
          _this3.anchorTokenIcon = (0,_services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_8__.transferToTokenIcon)(holdLiquidity.anchorCoinsChainName, holdLiquidity.anchorCoinsName);
          _this3.anchorChainIcon = (0,_services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_8__.transferToChainIcon)(_services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_8__.NODE_CHAIN_NAME_TRANSFER[holdLiquidity.anchorCoinsChainName] || 'Default');
          _this3.quoteTokenIcon = (0,_services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_8__.transferToTokenIcon)(holdLiquidity.quoteCoinsChainName, holdLiquidity.quoteCoinsName);
          _this3.quoteChainIcon = (0,_services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_8__.transferToChainIcon)(_services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_8__.NODE_CHAIN_NAME_TRANSFER[holdLiquidity.quoteCoinsChainName] || 'Default');
          _this3.holdLiquidity = JSON.parse(hold);
          _this3.anchorChainName = _services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_8__.NODE_CHAIN_NAME_TRANSFER[_this3.holdLiquidity.anchorCoinsChainName];
          _this3.quoteChainName = _services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_8__.NODE_CHAIN_NAME_TRANSFER[_this3.holdLiquidity.quoteCoinsChainName];
          _this3.holdCoinAmount = _bnqkl_framework_pipes__WEBPACK_IMPORTED_MODULE_13__.AmountFixedPipe.transform(holdLiquidity.userLPCoinsAmount, _this3.DECIMALS);
          _this3.poolService.startQueryPoolTask([holdLiquidity.poolId]);
          /// 获取真实数据 - 冻结数量
          _this3.getUserHoldCoinAmount(holdLiquidity.poolId);
        }
      }
    })();
  }
  /** 获取用户可用数量 */
  getUserHoldCoinAmount(poolId) {
    var _this4 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      var _this4$connectedWalle;
      /// 获取冻结数量
      const userId = (_this4$connectedWalle = _this4.connectedWallet) === null || _this4$connectedWalle === void 0 ? void 0 : _this4$connectedWalle.pmchainAddress;
      _this4.holdCoinAmount = '0';
      if (userId) {
        let locked = '0';
        try {
          const res = yield _this4.userService.getUserLiquidityLocked({
            poolId: poolId,
            userId
          });
          if (res) {
            const {
              frozenLpCoinsAmount
            } = res;
            locked = frozenLpCoinsAmount;
          }
        } catch (err) {
          _this4.console.error(err);
        }
        /// 获取全部数量
        const list = yield _this4.userService.getUserLiquidityHolding({
          userId
        });
        if (list) {
          const findItem = list.find(item => item.poolId === poolId);
          if (findItem) {
            _this4.holdCoinAmount = _bnqkl_framework_pipes__WEBPACK_IMPORTED_MODULE_13__.AmountFixedPipe.transform(String(BigInt(findItem.userLPCoinsAmount) - BigInt(locked)), _this4.DECIMALS);
          }
        }
      }
    })();
  }
  /** 提交移除流动性事件 */
  onRemoveLIquiditySubmited(data) {
    var _this5 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const {
        signature
      } = data;
      _this5.loading = true;
      const result = yield _this5.orderService.removeLiquidityOrder(signature);
      _this5.loading = false;
      _this5.console.log(result);
      if (result) {
        const {
          userInfo
        } = result;
        _this5.getUserHoldCoinAmount(userInfo.poolId);
        _this5.lpCoinAmunt = '';
        _this5.gainAnchorCoin = '';
        _this5.gainQuoteCoin = '';
        _this5.btnDisabled = true;
        _bnqkl_framework_plugins_toast__WEBPACK_IMPORTED_MODULE_11__.Toast.show('移流交易已提交');
        yield (0,_bnqkl_util_web_extends_promise__WEBPACK_IMPORTED_MODULE_15__.sleep)(500);
        _this5.nav.routeTo('/mine/my-record', {
          index: 1
        });
      } else {
        _bnqkl_framework_plugins_toast__WEBPACK_IMPORTED_MODULE_11__.Toast.show('移除失败');
      }
    })();
  }
  /** 打开选择链弹窗 */
  openSelectChainSheet() {
    var _this6 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const {
        selectChainSheet
      } = _this6;
      if (selectChainSheet.isOpen) {
        return;
      }
      selectChainSheet.isOpen = true;
    })();
  }
  /** 选择链 */
  onSelectChain(item) {
    var _this7 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this7.selectHoldChainInfo = item;
    })();
  }
  /** 打开高级设置弹窗 */
  openAdvancedSettingsSheet() {
    var _this8 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const {
        advancedSettingsSheet
      } = _this8;
      if (advancedSettingsSheet.is_open) {
        return;
      }
      advancedSettingsSheet.is_open = true;
    })();
  }
  /** Max按钮事件 */
  handleMaxBtn() {
    /// 有选择链才执行
    if (this.selectHoldChainInfo) {
      /// 谁小取谁
      let pLcoin = this.selectHoldChainInfo.amount;
      if (BigInt(pLcoin || 0) > BigInt(0)) {
        var _this$poolDetail;
        const pool = (_this$poolDetail = this.poolDetail) !== null && _this$poolDetail !== void 0 ? _this$poolDetail : this.holdLiquidity;
        pLcoin = String(_bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_6__.calculateHelper.calculateNeedLPCoinAmountByRemove(_services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_8__.NODE_CHAIN_NAME_TRANSFER_REVERSE[this.selectHoldChainInfo.chain], this.holdLiquidity.quoteCoinsName, pLcoin, pool));
      }
      const holdCoinAmount = new bignumber_js__WEBPACK_IMPORTED_MODULE_9__["default"](this.holdCoinAmount).multipliedBy(1e8).toString();
      this.lpCoinAmunt = BigInt(pLcoin) > BigInt(holdCoinAmount) ? this.holdCoinAmount : _bnqkl_framework_pipes__WEBPACK_IMPORTED_MODULE_13__.AmountFixedPipe.transform(pLcoin, this.DECIMALS);
      this.handleCaculate();
      this.checkAmount();
      this.checkZero();
    }
  }
  /** 清除订阅监听 */
  unsubscribe() {
    this.poolService.removeQueryPoolTask();
    this.inputRef && this.inputRef.nativeElement.removeEventListener('input', this.inputEvent.bind(this));
    this.settingsService.reset();
  }
  /** 获得资产提示 */
  showAcceptedAddressTip() {
    var _this9 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      yield _this9.alert({
        headerTitle: '预计获得资产',
        bodyMessage: '预计获得资产的接收地址为当前钱包地址',
        buttonText: '好的'
      });
    })();
  }
  /** 查看详情 */
  goToDetails() {
    const {
      holdLiquidity
    } = this;
    this.nav.routeTo('remove-liquidity/coin-pool-detail', {
      hold: JSON.stringify(holdLiquidity)
    });
  }
}
_class = RemoveLiquidityPage;
_class.ɵfac = /*@__PURE__*/(() => {
  let ɵRemoveLiquidityPage_BaseFactory;
  return function RemoveLiquidityPage_Factory(t) {
    return (ɵRemoveLiquidityPage_BaseFactory || (ɵRemoveLiquidityPage_BaseFactory = _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵgetInheritedFactory"](_class)))(t || _class);
  };
})();
_class.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵdefineComponent"]({
  type: _class,
  selectors: [["bs-remove-liquidity-page"]],
  viewQuery: function RemoveLiquidityPage_Query(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵviewQuery"](_c0, 5);
    }
    if (rf & 2) {
      let _t;
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵloadQuery"]()) && (ctx.inputRef = _t.first);
    }
  },
  standalone: true,
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵInheritDefinitionFeature"], _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵStandaloneFeature"]],
  decls: 82,
  vars: 50,
  consts: () => {
    let i18n_1;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_SELECT_THE_CHAIN_WHERE__QUOTECOINSNAME__IS_LOCATED$$APPS_BFSWAP_SRC_PAGES_REMOVE_LIQUIDITY_REMOVE_LIQUIDITY_COMPONENT_TS_2 = goog.getMsg(" Select the chain where {$interpolation} is located ", {
        "interpolation": "\uFFFD0\uFFFD"
      }, {
        original_code: {
          "interpolation": "{{ holdLiquidity.quoteCoinsName }}"
        }
      });
      i18n_1 = MSG_EXTERNAL_SELECT_THE_CHAIN_WHERE__QUOTECOINSNAME__IS_LOCATED$$APPS_BFSWAP_SRC_PAGES_REMOVE_LIQUIDITY_REMOVE_LIQUIDITY_COMPONENT_TS_2;
    } else {
      i18n_1 = "\u9009\u62E9 " + "\uFFFD0\uFFFD" + " \u6240\u5728\u7684\u94FE ";
    }
    let i18n_3;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_YOU_WILL_REMOVE$$APPS_BFSWAP_SRC_PAGES_REMOVE_LIQUIDITY_REMOVE_LIQUIDITY_COMPONENT_TS_4 = goog.getMsg("You will remove");
      i18n_3 = MSG_EXTERNAL_YOU_WILL_REMOVE$$APPS_BFSWAP_SRC_PAGES_REMOVE_LIQUIDITY_REMOVE_LIQUIDITY_COMPONENT_TS_4;
    } else {
      i18n_3 = "\u60A8\u5C06\u79FB\u9664";
    }
    let i18n_5;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_PLEASE_ENTER_THE_NUMBER_OF_LIQUIDITY_POOL_TOKENS$$APPS_BFSWAP_SRC_PAGES_REMOVE_LIQUIDITY_REMOVE_LIQUIDITY_COMPONENT_TS_6 = goog.getMsg("Please enter the number of liquidity pool tokens");
      i18n_5 = MSG_EXTERNAL_PLEASE_ENTER_THE_NUMBER_OF_LIQUIDITY_POOL_TOKENS$$APPS_BFSWAP_SRC_PAGES_REMOVE_LIQUIDITY_REMOVE_LIQUIDITY_COMPONENT_TS_6;
    } else {
      i18n_5 = "\u8F93\u5165\u79FB\u9664\u6570\u91CF";
    }
    let i18n_7;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_4966031860444584211$$APPS_BFSWAP_SRC_PAGES_REMOVE_LIQUIDITY_REMOVE_LIQUIDITY_COMPONENT_TS_8 = goog.getMsg(" \u6700\u5927 ");
      i18n_7 = MSG_EXTERNAL_4966031860444584211$$APPS_BFSWAP_SRC_PAGES_REMOVE_LIQUIDITY_REMOVE_LIQUIDITY_COMPONENT_TS_8;
    } else {
      i18n_7 = " \u6700\u5927 ";
    }
    let i18n_9;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_REMOVABLE_QUANTITY$$APPS_BFSWAP_SRC_PAGES_REMOVE_LIQUIDITY_REMOVE_LIQUIDITY_COMPONENT_TS_10 = goog.getMsg("Removable quantity: ");
      i18n_9 = MSG_EXTERNAL_REMOVABLE_QUANTITY$$APPS_BFSWAP_SRC_PAGES_REMOVE_LIQUIDITY_REMOVE_LIQUIDITY_COMPONENT_TS_10;
    } else {
      i18n_9 = "\u53EF\u79FB\u5408\u7EA6\u6C60\u6743\u76CA:";
    }
    let i18n_11;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_VIEW_DETAILS$$APPS_BFSWAP_SRC_PAGES_REMOVE_LIQUIDITY_REMOVE_LIQUIDITY_COMPONENT_TS_12 = goog.getMsg("Details");
      i18n_11 = MSG_EXTERNAL_VIEW_DETAILS$$APPS_BFSWAP_SRC_PAGES_REMOVE_LIQUIDITY_REMOVE_LIQUIDITY_COMPONENT_TS_12;
    } else {
      i18n_11 = "\u67E5\u770B\u8BE6\u60C5";
    }
    let i18n_13;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_EXPECTED_TO_ACQUIRE_ASSETS$$APPS_BFSWAP_SRC_PAGES_REMOVE_LIQUIDITY_REMOVE_LIQUIDITY_COMPONENT_TS_14 = goog.getMsg("Expected to acquire assets ");
      i18n_13 = MSG_EXTERNAL_EXPECTED_TO_ACQUIRE_ASSETS$$APPS_BFSWAP_SRC_PAGES_REMOVE_LIQUIDITY_REMOVE_LIQUIDITY_COMPONENT_TS_14;
    } else {
      i18n_13 = "\u9884\u8BA1\u83B7\u5F97\u8D44\u4EA7";
    }
    let i18n_15;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_REMOVE_LIQUIDITY_SELECTION_CHAIN$$APPS_BFSWAP_SRC_PAGES_REMOVE_LIQUIDITY_REMOVE_LIQUIDITY_COMPONENT_TS_16 = goog.getMsg("{$startTagBsIcon}{$closeTagBsIcon}{$startTagDiv} {$interpolation} {$closeTagDiv}", {
        "closeTagBsIcon": "\uFFFD/#57\uFFFD",
        "closeTagDiv": "\uFFFD/#58\uFFFD",
        "interpolation": "\uFFFD0\uFFFD",
        "startTagBsIcon": "\uFFFD#57\uFFFD",
        "startTagDiv": "\uFFFD#58\uFFFD"
      }, {
        original_code: {
          "closeTagBsIcon": "</bs-icon>",
          "closeTagDiv": "</div>",
          "interpolation": "{{ anchorChainName }}",
          "startTagBsIcon": "<bs-icon [name]=\"anchorChainIcon\" class=\"rounded-2 icon-4\">",
          "startTagDiv": "<div class=\"text-xxxs text-primary\">"
        }
      });
      i18n_15 = MSG_EXTERNAL_REMOVE_LIQUIDITY_SELECTION_CHAIN$$APPS_BFSWAP_SRC_PAGES_REMOVE_LIQUIDITY_REMOVE_LIQUIDITY_COMPONENT_TS_16;
    } else {
      i18n_15 = "" + "\uFFFD#57\uFFFD" + "" + "\uFFFD/#57\uFFFD" + "" + "\uFFFD#58\uFFFD" + " " + "\uFFFD0\uFFFD" + " " + "\uFFFD/#58\uFFFD" + "";
    }
    let i18n_17;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_REMOVE$$APPS_BFSWAP_SRC_PAGES_REMOVE_LIQUIDITY_REMOVE_LIQUIDITY_COMPONENT_TS_18 = goog.getMsg("{$startTagDiv} {$interpolation} {$startTagBnLoadingWrapper}{$closeTagBnLoadingWrapper}{$closeTagDiv}", {
        "closeTagBnLoadingWrapper": "\uFFFD/#75\uFFFD",
        "closeTagDiv": "\uFFFD/#74\uFFFD",
        "interpolation": "\uFFFD0\uFFFD",
        "startTagBnLoadingWrapper": "\uFFFD#75\uFFFD",
        "startTagDiv": "\uFFFD#74\uFFFD"
      }, {
        original_code: {
          "closeTagBnLoadingWrapper": "</bn-loading-wrapper>",
          "closeTagDiv": "</div>",
          "interpolation": "{{ btnText }}",
          "startTagBnLoadingWrapper": "<bn-loading-wrapper\r\n            class=\"icon-6 absolute -right-6 top-0\"\r\n            [loadingTheme]=\"'ellipsis'\"\r\n            [showLoading]=\"loading\"\r\n          >",
          "startTagDiv": "<div class=\"relative\">"
        }
      });
      i18n_17 = MSG_EXTERNAL_REMOVE$$APPS_BFSWAP_SRC_PAGES_REMOVE_LIQUIDITY_REMOVE_LIQUIDITY_COMPONENT_TS_18;
    } else {
      i18n_17 = "\u79FB\u9664";
    }
    let i18n_19;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_REMOVE_LIQUIDITY_SELECTION_CHAIN$$APPS_BFSWAP_SRC_PAGES_REMOVE_LIQUIDITY_REMOVE_LIQUIDITY_COMPONENT_TS__20 = goog.getMsg("{$startTagBsIcon}{$closeTagBsIcon} {$interpolation} {$startTagBsIcon_1}{$closeTagBsIcon}", {
        "closeTagBsIcon": "[\uFFFD/#2\uFFFD|\uFFFD/#3\uFFFD]",
        "interpolation": "\uFFFD0\uFFFD",
        "startTagBsIcon": "\uFFFD#2\uFFFD",
        "startTagBsIcon_1": "\uFFFD#3\uFFFD"
      }, {
        original_code: {
          "closeTagBsIcon": "</bs-icon>",
          "interpolation": "{{ selectHoldChainInfo.chain }}",
          "startTagBsIcon": "<bs-icon\r\n              [name]=\"selectHoldChainInfo.icon\"\r\n              class=\"rounded-2 mr-1 border-[2px] border-white text-2xl\"\r\n            >",
          "startTagBsIcon_1": "<bs-icon name=\"icon-chevron-down-small\" class=\"text-subtitle ml-1 text-xl\">"
        }
      });
      i18n_19 = MSG_EXTERNAL_REMOVE_LIQUIDITY_SELECTION_CHAIN$$APPS_BFSWAP_SRC_PAGES_REMOVE_LIQUIDITY_REMOVE_LIQUIDITY_COMPONENT_TS__20;
    } else {
      i18n_19 = "" + "\uFFFD#2\uFFFD" + "" + "[\uFFFD/#2\uFFFD|\uFFFD/#3\uFFFD]" + " " + "\uFFFD0\uFFFD" + " " + "\uFFFD#3\uFFFD" + "" + "[\uFFFD/#2\uFFFD|\uFFFD/#3\uFFFD]" + "";
    }
    i18n_19 = _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵi18nPostprocess"](i18n_19);
    let i18n_21;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_REMOVE_LIQUIDITY_SELECTION_CHAIN$$APPS_BFSWAP_SRC_PAGES_REMOVE_LIQUIDITY_REMOVE_LIQUIDITY_COMPONENT_TS__22 = goog.getMsg(" \u9009\u62E9\u94FE {$startTagBsIcon}{$closeTagBsIcon}", {
        "closeTagBsIcon": "\uFFFD/#2\uFFFD",
        "startTagBsIcon": "\uFFFD#2\uFFFD"
      }, {
        original_code: {
          "closeTagBsIcon": "</bs-icon>",
          "startTagBsIcon": "<bs-icon name=\"icon-chevron-down-small\" class=\"ml-1 text-xl\">"
        }
      });
      i18n_21 = MSG_EXTERNAL_REMOVE_LIQUIDITY_SELECTION_CHAIN$$APPS_BFSWAP_SRC_PAGES_REMOVE_LIQUIDITY_REMOVE_LIQUIDITY_COMPONENT_TS__22;
    } else {
      i18n_21 = " \u9009\u62E9\u94FE " + "\uFFFD#2\uFFFD" + "" + "\uFFFD/#2\uFFFD" + "";
    }
    let i18n_23;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_THE_CHAIN_REMAINING_IN_THE_POOL$$APPS_BFSWAP_SRC_PAGES_REMOVE_LIQUIDITY_REMOVE_LIQUIDITY_COMPONENT_TS__24 = goog.getMsg(" The Chain remaining in the pool: ");
      i18n_23 = MSG_EXTERNAL_THE_CHAIN_REMAINING_IN_THE_POOL$$APPS_BFSWAP_SRC_PAGES_REMOVE_LIQUIDITY_REMOVE_LIQUIDITY_COMPONENT_TS__24;
    } else {
      i18n_23 = "\u6C60\u4E2D\u8BE5\u94FE\u5269\u4F59:";
    }
    let i18n_26;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_REMOVE_LIQUIDITY_SELECTION_CHAIN$$APPS_BFSWAP_SRC_PAGES_REMOVE_LIQUIDITY_REMOVE_LIQUIDITY_COMPONENT_TS__27 = goog.getMsg("{$startTagBsIcon}{$closeTagBsIcon}{$startTagDiv} {$interpolation} {$closeTagDiv}", {
        "closeTagBsIcon": "\uFFFD/#2\uFFFD",
        "closeTagDiv": "\uFFFD/#3\uFFFD",
        "interpolation": "\uFFFD0\uFFFD",
        "startTagBsIcon": "\uFFFD#2\uFFFD",
        "startTagDiv": "\uFFFD#3\uFFFD"
      }, {
        original_code: {
          "closeTagBsIcon": "</bs-icon>",
          "closeTagDiv": "</div>",
          "interpolation": "{{ selectHoldChainInfo.chain }}",
          "startTagBsIcon": "<bs-icon [name]=\"selectHoldChainInfo.icon\" class=\"rounded-2 icon-4 mr-1\">",
          "startTagDiv": "<div class=\"text-primary text-xxxs\">"
        }
      });
      i18n_26 = MSG_EXTERNAL_REMOVE_LIQUIDITY_SELECTION_CHAIN$$APPS_BFSWAP_SRC_PAGES_REMOVE_LIQUIDITY_REMOVE_LIQUIDITY_COMPONENT_TS__27;
    } else {
      i18n_26 = "" + "\uFFFD#2\uFFFD" + "" + "\uFFFD/#2\uFFFD" + "" + "\uFFFD#3\uFFFD" + " " + "\uFFFD0\uFFFD" + " " + "\uFFFD/#3\uFFFD" + "";
    }
    return [[3, "contentBackground", "titleClass", "footerSafeArea", "headerBackground"], [1, "bginner", "h-100", "absolute", "left-0", "top-0", "-z-10", "w-full"], ["endMenu", "", "bnRippleButton", "", 1, "rounded-2.5", "!flex", "h-[2rem]", "w-[2rem]", "items-center", "justify-center", "bg-white", 3, "click"], ["name", "icon-remove-sliding-point-setting", 1, "icon-5"], [1, "mt-4.5", "px-13", "mb-4", "flex", "items-center", "justify-start"], [1, "flex", "items-center", "justify-start"], [1, "mr-1.5", 3, "tokenName", "chainName"], [1, "text-left"], [1, "text-title-10", "text-base", "font-semibold"], [1, "text-base-200", "text-xs"], [1, "bg-text-input", "mx-3", "h-8", "w-[1px]"], [1, "mr-2", "text-3xl", 3, "name"], [1, "rounded-4", "bg-white", "px-4", "pt-6"], [1, "rounded-4", "flex", "flex-col", "bg-white"], [1, "text-title-10", "mb-2", "text-sm", "font-semibold"], i18n_1, [1, "relative", "flex", "w-full", "flex-col"], ["bnRippleButton", "", 1, "h-11.5", "rounded-3", "mx-8", "flex", "shrink-0", "items-center", "justify-center", "text-center", 3, "disabled", "ngClass", "click"], ["class", "icon-6", 3, "loadingTheme", "showLoading"], ["class", "text-base-content-100 absolute -bottom-6 left-1/2 flex -translate-x-1/2 transform items-center justify-center text-center text-xs"], [1, "text-title-10", "mb-3", "mt-9", "text-sm", "font-semibold"], i18n_3, [1, "bg-base-300", "rounded-4", "flex", "items-center", "justify-between", "px-4"], ["type", "text", "placeholder", i18n_5, 1, "placeholder:text-base-200", "text-title-10", "h-20", "w-full", "text-2xl", "font-bold", "placeholder:text-2xl", "placeholder:font-medium", 3, "formControl", "ngModel", "ngModelChange"], ["inputRef", ""], [1, "bg-primary/10", "text-primary", "rounded-1", "ml-4", "shrink-0", "px-2", "py-1", "text-xs", 3, "click"], i18n_7, [1, "mt-3", "flex", "items-start", "justify-between", "text-xs"], [1, "flex", "items-center", "justify-between"], ["name", "icon-remove-amount", 1, "icon-5"], [1, "text-gray-10", "mr-1"], i18n_9, [1, "text-gray-10"], [1, "text-text-router", "flex", "items-center", "justify-center", 3, "click"], [1, "mb-[2px]"], i18n_11, ["name", "icon-chevron-right-small", 1, "text-text-router", "text-xl"], ["name", "icon-arrow-down", 1, "icon-5", "text-title-10", "mx-auto", "my-3"], [1, "mb-2", "flex", "items-center", "justify-start"], [1, "text-base-500", "text-sm", "font-semibold"], i18n_13, ["name", "icon-info", 1, "text-gray-10", "ml-1", "text-base", 3, "click"], [1, "mb-1", "flex", "items-center", "justify-between"], [1, "base-content-100", "flex", "items-center", "justify-start", "text-xs"], [1, "mr-1.5", "text-base", 3, "name"], [1, "bg-blue-10", "rounded-1", "ml-1", "flex", "items-center", "justify-center", "pr-1"], i18n_15, [1, "rounded-2", "icon-4", 3, "name"], [1, "text-xxxs", "text-primary"], [1, "text-title-10"], [1, "mb-3", "flex", "items-center", "justify-between"], ["class", "bg-blue-10  rounded-1 ml-1 flex items-center justify-center pr-1  ", 4, "ngIf"], [1, "mt-10.5", "w-full", "bg-white"], [1, "px-4"], ["bnRippleButton", "", 1, "border-base-200", "rounded-12", "flex", "h-12", "w-full", "items-center", "justify-center", "border", "text-lg", "font-semibold", "text-white", 3, "disabled", "click"], i18n_17, [1, "relative"], [1, "icon-6", "absolute", "-right-6", "top-0", 3, "loadingTheme", "showLoading"], [3, "isOpen", "panelClass", "isOpenChange"], [3, "isOpen", "isOpenChange"], [1, "icon-6", 3, "loadingTheme", "showLoading"], [1, "flex", "items-center", "justify-center"], i18n_19, [1, "rounded-2", "mr-1", "border-[2px]", "border-white", "text-2xl", 3, "name"], ["name", "icon-chevron-down-small", 1, "text-subtitle", "ml-1", "text-xl"], [1, "flex", "items-center", "justify-center", "text-lg", "font-extrabold"], i18n_21, ["name", "icon-chevron-down-small", 1, "ml-1", "text-xl"], [1, "text-base-content-100", "absolute", "-bottom-6", "left-1/2", "flex", "-translate-x-1/2", "transform", "items-center", "justify-center", "text-center", "text-xs"], ["name", "icon-pool-amount", 1, "icon-5"], [1, "text-gray-10", "mr-1", "shrink-0"], i18n_23, i18n_26, [1, "rounded-2", "icon-4", "mr-1", 3, "name"], [1, "text-primary", "text-xxxs"], [3, "selectedToken", "chainList", "selectedPoolChain", "returnValue$"], [3, "anchorTokenIcon", "anchorChainIcon", "quoteTokenIcon", "quoteChainIcon", "lpAmount", "holdLiquidity", "gainAnchorCoin", "gainQuoteCoin", "chainName", "preParams", "returnValue$"], [3, "showAddLiquidityRatio"]];
  },
  template: function RemoveLiquidityPage_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵelementStart"](0, "common-page", 0);
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵelement"](1, "div", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵelementStart"](2, "button", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵlistener"]("click", function RemoveLiquidityPage_Template_button_click_2_listener() {
        return ctx.openAdvancedSettingsSheet();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵelement"](3, "bs-icon", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵelementStart"](4, "div", 4)(5, "div", 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵelement"](6, "bs-token-with-chain-icon", 6);
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵelementStart"](7, "div", 7)(8, "div", 8);
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵtext"](9);
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵelementStart"](10, "div", 9);
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵtext"](11);
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵelementEnd"]()()();
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵelement"](12, "div", 10);
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵelementStart"](13, "div", 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵelement"](14, "bs-icon", 11);
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵelementStart"](15, "div", 8);
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵtext"](16);
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵelementEnd"]()()();
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵelementStart"](17, "div", 12)(18, "div", 13)(19, "div", 14);
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵi18n"](20, 15);
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵelementStart"](21, "div", 16)(22, "button", 17);
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵlistener"]("click", function RemoveLiquidityPage_Template_button_click_22_listener() {
        return ctx.openSelectChainSheet();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵtemplate"](23, RemoveLiquidityPage_Conditional_23_Template, 1, 2, "bn-loading-wrapper", 18)(24, RemoveLiquidityPage_Conditional_24_Template, 4, 2)(25, RemoveLiquidityPage_Conditional_25_Template, 3, 0);
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵtemplate"](26, RemoveLiquidityPage_Conditional_26_Template, 6, 6, "div", 19);
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵelementStart"](27, "div", 20);
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵi18n"](28, 21);
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵelementStart"](29, "div", 22)(30, "input", 23, 24);
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵlistener"]("ngModelChange", function RemoveLiquidityPage_Template_input_ngModelChange_30_listener($event) {
        return ctx.lpCoinAmunt = $event;
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵelementStart"](32, "div", 25);
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵlistener"]("click", function RemoveLiquidityPage_Template_div_click_32_listener() {
        return ctx.handleMaxBtn();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵi18n"](33, 26);
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵelementStart"](34, "div", 27)(35, "div", 28);
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵelement"](36, "bs-icon", 29);
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵelementStart"](37, "span", 30);
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵi18n"](38, 31);
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵelementStart"](39, "div", 32);
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵtext"](40);
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵelementStart"](41, "div")(42, "button", 33);
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵlistener"]("click", function RemoveLiquidityPage_Template_button_click_42_listener() {
        return ctx.goToDetails();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵelementStart"](43, "span", 34);
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵi18n"](44, 35);
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵelement"](45, "bs-icon", 36);
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵelementEnd"]()()();
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵelement"](46, "bs-icon", 37);
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵelementStart"](47, "div", 38)(48, "span", 39);
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵi18n"](49, 40);
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵelementStart"](50, "bs-icon", 41);
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵlistener"]("click", function RemoveLiquidityPage_Template_bs_icon_click_50_listener() {
        return ctx.showAcceptedAddressTip();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵelementStart"](51, "div", 42)(52, "div", 43);
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵelement"](53, "bs-icon", 44);
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵtext"](54);
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵelementStart"](55, "span", 45);
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵi18nStart"](56, 46);
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵelement"](57, "bs-icon", 47)(58, "div", 48);
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵi18nEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵelementStart"](59, "div", 49);
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵtext"](60);
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵpipe"](61, "amountFixed");
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵelementStart"](62, "div", 50)(63, "div", 43);
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵelement"](64, "bs-icon", 44);
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵtext"](65);
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵtemplate"](66, RemoveLiquidityPage_div_66_Template, 4, 2, "div", 51);
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵelementStart"](67, "div", 49);
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵtext"](68);
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵpipe"](69, "amountFixed");
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵelementEnd"]()()()();
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵelementStart"](70, "div", 52)(71, "div", 53)(72, "button", 54);
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵlistener"]("click", function RemoveLiquidityPage_Template_button_click_72_listener() {
        return ctx.openRemoveLiquiditySheet();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵi18nStart"](73, 55);
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵelementStart"](74, "div", 56);
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵelement"](75, "bn-loading-wrapper", 57);
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵi18nEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵelementEnd"]()()()();
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵelementStart"](76, "common-bottom-sheet", 58);
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵlistener"]("isOpenChange", function RemoveLiquidityPage_Template_common_bottom_sheet_isOpenChange_76_listener($event) {
        return ctx.selectChainSheet.isOpen = $event;
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵtemplate"](77, RemoveLiquidityPage_ng_template_77_Template, 1, 3, "ng-template");
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵelementStart"](78, "common-bottom-sheet", 59);
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵlistener"]("isOpenChange", function RemoveLiquidityPage_Template_common_bottom_sheet_isOpenChange_78_listener($event) {
        return ctx.removeLiquiditySheet.is_open = $event;
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵtemplate"](79, RemoveLiquidityPage_ng_template_79_Template, 1, 10, "ng-template");
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵelementStart"](80, "common-bottom-sheet", 59);
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵlistener"]("isOpenChange", function RemoveLiquidityPage_Template_common_bottom_sheet_isOpenChange_80_listener($event) {
        return ctx.advancedSettingsSheet.is_open = $event;
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵtemplate"](81, RemoveLiquidityPage_ng_template_81_Template, 1, 1, "ng-template");
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵelementEnd"]();
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵproperty"]("contentBackground", "white")("titleClass", "!justify-start text-xl font-extrabold !text-title-10")("footerSafeArea", false)("headerBackground", "transparent");
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵadvance"](6);
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵproperty"]("tokenName", ctx.anchorTokenIcon)("chainName", ctx.anchorChainIcon);
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵtextInterpolate1"](" ", ctx.holdLiquidity.anchorCoinsName, " ");
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵtextInterpolate1"](" ", ctx.anchorChainName, " ");
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵproperty"]("name", ctx.quoteTokenIcon);
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵtextInterpolate1"](" ", ctx.holdLiquidity.quoteCoinsName, " ");
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵadvance"](4);
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵi18nExp"](ctx.holdLiquidity.quoteCoinsName);
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵi18nApply"](20);
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵproperty"]("disabled", ctx.loading)("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵpureFunction2"](45, _c28, !ctx.selectHoldChainInfo, !!ctx.selectHoldChainInfo));
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵconditional"](23, ctx.loading ? 23 : !!ctx.selectHoldChainInfo ? 24 : 25);
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵconditional"](26, !!ctx.selectHoldChainInfo ? 26 : -1);
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵadvance"](4);
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵproperty"]("formControl", ctx.inputControl)("ngModel", ctx.lpCoinAmunt);
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵadvance"](10);
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵtextInterpolate"](ctx.holdCoinAmount);
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵadvance"](13);
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵproperty"]("name", ctx.anchorTokenIcon);
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵtextInterpolate1"](" ", ctx.holdLiquidity.anchorCoinsName, " ");
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵproperty"]("name", ctx.anchorChainIcon);
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵi18nExp"](ctx.anchorChainName);
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵi18nApply"](56);
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵtextInterpolate1"](" ", ctx.gainAnchorCoin && ctx.selectHoldChainInfo ? "+" + _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵpipeBind3"](61, 37, ctx.gainAnchorCoin, 8, _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵpureFunction0"](48, _c25)) : "--", " ");
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵadvance"](4);
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵproperty"]("name", ctx.quoteTokenIcon);
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵtextInterpolate1"](" ", ctx.holdLiquidity.quoteCoinsName, " ");
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵproperty"]("ngIf", !!ctx.selectHoldChainInfo);
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵtextInterpolate1"](" ", ctx.gainQuoteCoin && ctx.selectHoldChainInfo ? "+" + _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵpipeBind3"](69, 41, ctx.gainQuoteCoin, 8, _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵpureFunction0"](49, _c25)) : "--", " ");
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵadvance"](4);
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵclassMap"](ctx.btnDisabled || !ctx.selectHoldChainInfo ? "bg-base-200" : " bg-primary");
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵproperty"]("disabled", !ctx.selectHoldChainInfo || ctx.btnDisabled);
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵproperty"]("loadingTheme", "ellipsis")("showLoading", ctx.loading);
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵi18nExp"](ctx.btnText);
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵi18nApply"](73);
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵproperty"]("isOpen", ctx.selectChainSheet.isOpen)("panelClass", "h-2/5");
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵproperty"]("isOpen", ctx.removeLiquiditySheet.is_open);
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_25__["ɵɵproperty"]("isOpen", ctx.advancedSettingsSheet.is_open);
    }
  },
  dependencies: [_modules_page_module__WEBPACK_IMPORTED_MODULE_3__.CommonPageModule, _libs_bnf_modules_bottom_sheet_components_bottom_sheet_component__WEBPACK_IMPORTED_MODULE_18__.BottomSheetComponent, _libs_bnf_components_ripple_button_ripple_button_directive__WEBPACK_IMPORTED_MODULE_19__.RippleButtonDirective, _libs_bnf_directives_auto_complete_off_directive__WEBPACK_IMPORTED_MODULE_20__.AutoCompleteOffDirective, _angular_common__WEBPACK_IMPORTED_MODULE_27__.NgClass, _angular_common__WEBPACK_IMPORTED_MODULE_27__.NgIf, _angular_forms__WEBPACK_IMPORTED_MODULE_26__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_26__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_26__.FormControlDirective, _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_21__.CommonPageComponent, _components_icon_icon_component__WEBPACK_IMPORTED_MODULE_22__.IconComponent, _libs_bnf_components_loading_wrapper_loading_wrapper_component__WEBPACK_IMPORTED_MODULE_23__.LoadingWrapperComponent, _libs_bnf_pipes_amountFixed_amount_fixed_pipe__WEBPACK_IMPORTED_MODULE_24__.AmountFixedPipe, _angular_common__WEBPACK_IMPORTED_MODULE_27__.CommonModule, _components_order_settings_order_settings_component__WEBPACK_IMPORTED_MODULE_4__.OrderSettingsPage, _components_remove_detail_panel_remove_detail_panel_component__WEBPACK_IMPORTED_MODULE_1__["default"], _components_token_with_chain_icon_token_with_chain_icon_component__WEBPACK_IMPORTED_MODULE_2__.TokenWithnChainIconComponent, _components_select_chain_panel_select_chain_panel_component__WEBPACK_IMPORTED_MODULE_16__["default"]],
  styles: ["[_nghost-%COMP%]   .bginner[_ngcontent-%COMP%] {\n  background: linear-gradient(180deg, #e3e0f8 0%, #e6e0f8 15%, #faf3f7 45%, #f6f7fc 100%);\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL2FwcHMvYmZzd2FwL3NyYy9wYWdlcy9yZW1vdmUtbGlxdWlkaXR5L3JlbW92ZS1saXF1aWRpdHkuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQ0U7RUFDRSx1RkFBQTtBQUFKIiwic291cmNlc0NvbnRlbnQiOlsiOmhvc3Qge1xyXG4gIC5iZ2lubmVyIHtcclxuICAgIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCgxODBkZWcsICNlM2UwZjggMCUsICNlNmUwZjggMTUlLCAjZmFmM2Y3IDQ1JSwgI2Y2ZjdmYyAxMDAlKTtcclxuICAgIC8vIGJnLVtsaW5lYXItZ3JhZGllbnQoMTgwZGVnLCBfI0UzRTBGOF8wJSwgXyNFNkUwRjhfMTUlLCBfI0ZBRjNGN180NSUsIF8jRjZGN0ZDXzEwMCUpXVxyXG4gIH1cclxufVxyXG4iXSwic291cmNlUm9vdCI6IiJ9 */"],
  changeDetection: 0
});
(0,tslib__WEBPACK_IMPORTED_MODULE_28__.__decorate)([RemoveLiquidityPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_28__.__metadata)("design:type", Object)], RemoveLiquidityPage.prototype, "gainAnchorCoin", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_28__.__decorate)([RemoveLiquidityPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_28__.__metadata)("design:type", Object)], RemoveLiquidityPage.prototype, "gainQuoteCoin", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_28__.__decorate)([RemoveLiquidityPage.QueryParams(), (0,tslib__WEBPACK_IMPORTED_MODULE_28__.__metadata)("design:type", Object)], RemoveLiquidityPage.prototype, "params", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_28__.__decorate)([RemoveLiquidityPage.States(1), (0,tslib__WEBPACK_IMPORTED_MODULE_28__.__metadata)("design:type", Object)], RemoveLiquidityPage.prototype, "holdLiquidity", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_28__.__decorate)([RemoveLiquidityPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_28__.__metadata)("design:type", Object)], RemoveLiquidityPage.prototype, "selectHoldChainInfo", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_28__.__decorate)([RemoveLiquidityPage.States(), (0,tslib__WEBPACK_IMPORTED_MODULE_28__.__metadata)("design:type", Object)], RemoveLiquidityPage.prototype, "poolChainBalanceList", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_28__.__decorate)([RemoveLiquidityPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_28__.__metadata)("design:type", Object)], RemoveLiquidityPage.prototype, "loading", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_28__.__decorate)([RemoveLiquidityPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_28__.__metadata)("design:type", Object)], RemoveLiquidityPage.prototype, "updating", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_28__.__decorate)([RemoveLiquidityPage.States(1), (0,tslib__WEBPACK_IMPORTED_MODULE_28__.__metadata)("design:type", Object)], RemoveLiquidityPage.prototype, "removeLiquiditySheet", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_28__.__decorate)([RemoveLiquidityPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_28__.__metadata)("design:type", Object)], RemoveLiquidityPage.prototype, "btnText", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_28__.__decorate)([RemoveLiquidityPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_28__.__metadata)("design:type", Object)], RemoveLiquidityPage.prototype, "btnDisabled", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_28__.__decorate)([RemoveLiquidityPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_28__.__metadata)("design:type", String)], RemoveLiquidityPage.prototype, "anchorTokenIcon", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_28__.__decorate)([RemoveLiquidityPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_28__.__metadata)("design:type", String)], RemoveLiquidityPage.prototype, "anchorChainIcon", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_28__.__decorate)([RemoveLiquidityPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_28__.__metadata)("design:type", String)], RemoveLiquidityPage.prototype, "quoteTokenIcon", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_28__.__decorate)([RemoveLiquidityPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_28__.__metadata)("design:type", String)], RemoveLiquidityPage.prototype, "quoteChainIcon", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_28__.__decorate)([RemoveLiquidityPage.States(1), (0,tslib__WEBPACK_IMPORTED_MODULE_28__.__metadata)("design:type", Object)], RemoveLiquidityPage.prototype, "advancedSettingsSheet", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_28__.__decorate)([RemoveLiquidityPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_28__.__metadata)("design:type", Object)], RemoveLiquidityPage.prototype, "preParams", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_28__.__decorate)([RemoveLiquidityPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_28__.__metadata)("design:type", Object)], RemoveLiquidityPage.prototype, "anchorChainName", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_28__.__decorate)([RemoveLiquidityPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_28__.__metadata)("design:type", Object)], RemoveLiquidityPage.prototype, "quoteChainName", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_28__.__decorate)([RemoveLiquidityPage.AfterViewInit(), (0,tslib__WEBPACK_IMPORTED_MODULE_28__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_28__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_28__.__metadata)("design:returntype", void 0)], RemoveLiquidityPage.prototype, "initInputListenEvent", null);
(0,tslib__WEBPACK_IMPORTED_MODULE_28__.__decorate)([RemoveLiquidityPage.OnReady(), (0,tslib__WEBPACK_IMPORTED_MODULE_28__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_28__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_28__.__metadata)("design:returntype", void 0)], RemoveLiquidityPage.prototype, "dataInit", null);
(0,tslib__WEBPACK_IMPORTED_MODULE_28__.__decorate)([RemoveLiquidityPage.OnDestroy(), (0,tslib__WEBPACK_IMPORTED_MODULE_28__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_28__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_28__.__metadata)("design:returntype", void 0)], RemoveLiquidityPage.prototype, "removeSub", null);
(0,tslib__WEBPACK_IMPORTED_MODULE_28__.__decorate)([RemoveLiquidityPage.OnInit(), (0,tslib__WEBPACK_IMPORTED_MODULE_28__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_28__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_28__.__metadata)("design:returntype", Promise)], RemoveLiquidityPage.prototype, "iniParams", null);
(0,tslib__WEBPACK_IMPORTED_MODULE_28__.__decorate)([RemoveLiquidityPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_28__.__metadata)("design:type", Object)], RemoveLiquidityPage.prototype, "inputControl", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_28__.__decorate)([RemoveLiquidityPage.States(), (0,tslib__WEBPACK_IMPORTED_MODULE_28__.__metadata)("design:type", Object)], RemoveLiquidityPage.prototype, "selectChainSheet", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_28__.__decorate)([RemoveLiquidityPage.OnDestroy(), (0,tslib__WEBPACK_IMPORTED_MODULE_28__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_28__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_28__.__metadata)("design:returntype", void 0)], RemoveLiquidityPage.prototype, "unsubscribe", null);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (RemoveLiquidityPage);

/***/ }),

/***/ 23377:
/*!*******************************************************************!*\
  !*** ./apps/bfswap/src/pipes/amount-format/amount-format.pipe.ts ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AmountFormatPipe: () => (/* binding */ AmountFormatPipe)
/* harmony export */ });
/* harmony import */ var bignumber_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! bignumber.js */ 61994);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 61039);
var _class;


/** 数值转换小数 */
class AmountFormatPipe {
  constructor() {
    this.transform = AmountFormatPipe.transform;
  }
  /** 转换函数 */
  static transform(value) {
    if (value === undefined) {
      return 0;
    }
    const v = new bignumber_js__WEBPACK_IMPORTED_MODULE_0__["default"](value).toFormat();
    return v;
  }
}
_class = AmountFormatPipe;
_class.ɵfac = function AmountFormatPipe_Factory(t) {
  return new (t || _class)();
};
_class.ɵpipe = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefinePipe"]({
  name: "amountFormat",
  type: _class,
  pure: true,
  standalone: true
});

/***/ }),

/***/ 34913:
/*!***************************************************************************!*\
  !*** ./apps/bfswap/src/services/liquidity-user/liquidity-user.service.ts ***!
  \***************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   LiquidityUserService: () => (/* binding */ LiquidityUserService)
/* harmony export */ });
/* harmony import */ var D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 52542);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 61039);
/* harmony import */ var _services_bs_fetch_bs_fetch_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ~services/bs-fetch/bs-fetch.service */ 92925);
/* harmony import */ var _bnqkl_framework_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @bnqkl/framework/core */ 63563);

var _class;




/** 池子相关接口 */
class LiquidityUserService {
  constructor() {
    /** 日志 */
    this.console = (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.inject)(_bnqkl_framework_core__WEBPACK_IMPORTED_MODULE_2__.LoggerService).createLoggerForService(this, 'liquidity-user-service');
    /** fetch服务 */
    this.fetch = (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.inject)(_services_bs_fetch_bs_fetch_service__WEBPACK_IMPORTED_MODULE_1__.SwapFetch);
    /** 后端接口 */
    this.SERVER_API = {
      /** 获取用户持仓列表 POST */
      getLiquidityUserPositionList: this.fetch.APP_URL('/bnqklswap/liquidity/user/position/list'),
      /** 获取用户资产列表 POST */
      getLiquidityUserAssetsList: this.fetch.APP_URL('/bnqklswap/liquidity/user/assets/list'),
      /** 获取用户流动性持仓 */
      getUserLiquidityHolding: this.fetch.APP_URL('/bnqklswap/liquidity/user/position/list'),
      /** 获取用户持仓详情 */
      getUserPositionDetail: this.fetch.APP_URL('/bnqklswap/liquidity/user/position/details'),
      /** 获取用户持仓比例 */
      getUserPositionPercent: this.fetch.APP_URL('/bnqklswap/liquidity/user/position/percent'),
      /** 获取用户流动性持仓冻结数量 */
      getUserLiquidityLocked: this.fetch.APP_URL('/bnqklswap/liquidity/user/position/locked'),
      /** 获取用户流动性持仓冻结列表 */
      getUserLiquidityLockedList: this.fetch.APP_URL('/bnqklswap/liquidity/user/position/locked/list')
    };
  }
  /** 获取用户锁仓量列表 */
  getUserLiquidityLockedList(options) {
    var _this = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      try {
        return _this.fetch.post(_this.SERVER_API.getUserLiquidityLockedList, options);
        // 默认数据
      } catch (error) {
        _this.console.log('getUserLiquidityLockedList', error);
        return;
      }
    })();
  }
  /** 获取用户持仓详情 */
  getUserPositionDetail(options) {
    try {
      return this.fetch.post(this.SERVER_API.getUserPositionDetail, options);
      // 默认数据
    } catch (error) {
      this.console.log('getUserPositionDetail', error);
      return;
    }
  }
  /** 获取用户锁仓量 */
  getUserLiquidityLocked(options) {
    var _this2 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      try {
        return _this2.fetch.post(_this2.SERVER_API.getUserLiquidityLocked, options);
        // 默认数据
      } catch (error) {
        _this2.console.log('getUserLiquidityLocked', error);
        return;
      }
    })();
  }
  /** 获取用户持仓比例 */
  getUserPositionPercent(options) {
    try {
      return this.fetch.post(this.SERVER_API.getUserPositionPercent, options);
      // 默认数据
    } catch (error) {
      this.console.log('getUserPositionPercent', error);
      return;
    }
  }
  /** 获取用户持仓列表 */
  getLiquidityUserPostionList(options) {
    try {
      return this.fetch.post(this.SERVER_API.getLiquidityUserPositionList, options);
      // 默认数据
    } catch (error) {
      this.console.log('getLiquidityUserPostionList', error);
      return;
    }
  }
  /** 获取用户资产列表 */
  getLiquidityUserAssetsList(options) {
    try {
      return this.fetch.post(this.SERVER_API.getLiquidityUserAssetsList, options);
      // 默认数据
    } catch (error) {
      this.console.log('getLiquidityUserPostionList', error);
      return;
    }
  }
  /** 获取用户流动性持仓 */
  getUserLiquidityHolding(options) {
    var _this3 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      try {
        return _this3.fetch.post(_this3.SERVER_API.getUserLiquidityHolding, options);
        // 默认数据
      } catch (error) {
        _this3.console.log('getUserLiquidityHolding', error);
        return;
      }
    })();
  }
}
_class = LiquidityUserService;
_class.ɵfac = function LiquidityUserService_Factory(t) {
  return new (t || _class)();
};
_class.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineInjectable"]({
  token: _class,
  factory: _class.ɵfac,
  providedIn: 'root'
});

/***/ })

}]);
//# sourceMappingURL=apps_bfswap_src_pages_remove-liquidity_remove-liquidity_component_ts.js.map