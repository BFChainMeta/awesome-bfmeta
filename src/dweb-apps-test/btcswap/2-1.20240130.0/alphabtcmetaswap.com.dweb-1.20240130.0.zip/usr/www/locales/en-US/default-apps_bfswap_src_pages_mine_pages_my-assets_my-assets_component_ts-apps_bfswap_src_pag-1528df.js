"use strict";
(self["webpackChunkbfswap"] = self["webpackChunkbfswap"] || []).push([["default-apps_bfswap_src_pages_mine_pages_my-assets_my-assets_component_ts-apps_bfswap_src_pag-1528df"],{

/***/ 26193:
/*!*********************************************************************************************!*\
  !*** ./apps/bfswap/src/components/swap-token-chain-icon/swap-token-chain-icon.component.ts ***!
  \*********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   SwapTokenChainIconComponent: () => (/* binding */ SwapTokenChainIconComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! tslib */ 90505);
/* harmony import */ var _bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @bnqkl/bnqkl-swap-core */ 70195);
/* harmony import */ var _services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ~services/wallet/wallet.helper */ 84813);
/* harmony import */ var _modules_comp_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ~modules/comp.module */ 58281);
/* harmony import */ var _modules_page_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ~modules/page.module */ 16381);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 61039);
/* harmony import */ var _icon_icon_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../icon/icon.component */ 18840);
var _class;







/** 封装一层的链和币种图标组件 直接传链名和币种即可 */
class SwapTokenChainIconComponent extends _modules_comp_module__WEBPACK_IMPORTED_MODULE_2__.CommonCompBase {
  constructor() {
    super(...arguments);
    /** 图标的大小 */
    this.iconSize = 'icon-4';
    /** 图标名称 */
    this.iconName = 'token-Default';
  }
  init() {
    const {
      swapChainName,
      swapCoinName
    } = this;
    if (swapChainName) {
      let iconName = 'token-Default';
      const chainName = swapChainName in _bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_0__.BNQKL_SWAP_CHAIN_NAME ? _services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_1__.NODE_CHAIN_NAME_TRANSFER[swapChainName] : swapChainName;
      const chainIcon = (0,_services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_1__.transferToChainIcon)(chainName);
      iconName = chainIcon;
      if (swapCoinName) {
        const coinIcon = (0,_services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_1__.transferToTokenIconBychainName)(chainName, swapCoinName);
        iconName = coinIcon;
      }
      this.iconName = iconName;
    }
  }
}
_class = SwapTokenChainIconComponent;
_class.ɵfac = /*@__PURE__*/(() => {
  let ɵSwapTokenChainIconComponent_BaseFactory;
  return function SwapTokenChainIconComponent_Factory(t) {
    return (ɵSwapTokenChainIconComponent_BaseFactory || (ɵSwapTokenChainIconComponent_BaseFactory = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵgetInheritedFactory"](_class)))(t || _class);
  };
})();
_class.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineComponent"]({
  type: _class,
  selectors: [["bs-swap-token-chain-icon"]],
  inputs: {
    iconSize: "iconSize",
    swapChainName: "swapChainName",
    swapCoinName: "swapCoinName"
  },
  standalone: true,
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵInheritDefinitionFeature"], _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵStandaloneFeature"]],
  decls: 1,
  vars: 3,
  consts: [[3, "name"]],
  template: function SwapTokenChainIconComponent_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](0, "bs-icon", 0);
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵclassMap"](ctx.iconSize);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("name", ctx.iconName);
    }
  },
  dependencies: [_modules_page_module__WEBPACK_IMPORTED_MODULE_3__.CommonPageModule, _icon_icon_component__WEBPACK_IMPORTED_MODULE_4__.IconComponent],
  styles: ["[_nghost-%COMP%] {\n  display: flex;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL2FwcHMvYmZzd2FwL3NyYy9jb21wb25lbnRzL3N3YXAtdG9rZW4tY2hhaW4taWNvbi9zd2FwLXRva2VuLWNoYWluLWljb24uY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxhQUFBO0FBQ0oiLCJzb3VyY2VzQ29udGVudCI6WyI6aG9zdHtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbn0iXSwic291cmNlUm9vdCI6IiJ9 */"],
  changeDetection: 0
});
(0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([SwapTokenChainIconComponent.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__metadata)("design:type", String)], SwapTokenChainIconComponent.prototype, "iconName", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([SwapTokenChainIconComponent.OnChanges(), (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__metadata)("design:returntype", void 0)], SwapTokenChainIconComponent.prototype, "init", null);

/***/ }),

/***/ 59920:
/*!***************************************************************************!*\
  !*** ./apps/bfswap/src/pages/mine/pages/my-assets/my-assets.component.ts ***!
  \***************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   MyAssetsPage: () => (/* binding */ MyAssetsPage),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 52542);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! tslib */ 90505);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! @angular/common */ 6729);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @angular/core */ 61039);
/* harmony import */ var _bnqkl_framework_animations__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @bnqkl/framework/animations */ 43127);
/* harmony import */ var bignumber_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! bignumber.js */ 61994);
/* harmony import */ var _bnqkl_wallet_base_services__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @bnqkl/wallet-base/services */ 62479);
/* harmony import */ var _modules_page_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ~modules/page.module */ 16381);
/* harmony import */ var _services_wallet_wallet_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ~services/wallet/wallet.service */ 54275);
/* harmony import */ var _bnqkl_framework_pipes__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @bnqkl/framework/pipes */ 80909);
/* harmony import */ var _services_liquidity_user_liquidity_user_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ~services/liquidity-user/liquidity-user.service */ 34913);
/* harmony import */ var _bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @bnqkl/bnqkl-swap-core */ 70195);
/* harmony import */ var _services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ~services/wallet/wallet.helper */ 84813);
/* harmony import */ var _pipes_amount_format_amount_format_pipe__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ~pipes/amount-format/amount-format.pipe */ 23377);
/* harmony import */ var _libs_bnf_components_pull_to_refresh_pull_to_refresh_directive__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../../../../../../libs/bnf/components/pull-to-refresh/pull-to-refresh.directive */ 97063);
/* harmony import */ var _libs_bnf_components_pull_to_refresh_pull_to_refresh_spinner_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../../../../../../libs/bnf/components/pull-to-refresh/pull-to-refresh-spinner.component */ 75387);
/* harmony import */ var _libs_bnf_directives_click_to_copy_directive__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../../../../../../../libs/bnf/directives/click-to-copy.directive */ 46413);
/* harmony import */ var _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../../../../../../../libs/bnf/modules/page/common-page/common-page.component */ 62052);
/* harmony import */ var _components_icon_icon_component__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ../../../../components/icon/icon.component */ 18840);
/* harmony import */ var _pipes_color_color_pipe__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ../../../../pipes/color/color.pipe */ 67481);
/* harmony import */ var _libs_bnf_pipes_amountFixed_amount_fixed_pipe__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ../../../../../../../libs/bnf/pipes/amountFixed/amount-fixed.pipe */ 44070);

var _class;






















function MyAssetsPage_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    const _r9 = _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵi18nStart"](0, 3, 1);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](1, "div", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵlistener"]("click", function MyAssetsPage_Conditional_4_Template_div_click_1_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵrestoreView"](_r9);
      const ctx_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵresetView"](ctx_r8.jumpAssetAllocation());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelement"](2, "bs-icon", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵi18nEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵproperty"]("name", "icon-chart");
  }
}
const _c4 = () => ({
  removeZero: true
});
function MyAssetsPage_Conditional_12_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](0, "div", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵpipe"](2, "amountFormat");
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵpipe"](3, "amountFixed");
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelement"](4, "bs-icon", 21);
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵpipeBind1"](2, 1, _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵpipeBind3"](3, 3, ctx_r1.totalUAmount, 8, _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵpureFunction0"](7, _c4))), " ");
  }
}
function MyAssetsPage_Conditional_13_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](0, "div", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵtext"](1, "****");
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelement"](2, "bs-icon", 22);
  }
}
function MyAssetsPage_li_16_div_4_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](0, "div", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelement"](1, "div", 29);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r11 = _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵproperty"]("@fadeInLeft", undefined);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵstyleProp"]("background-color", ctx_r11.showChainInfo.bgColor);
  }
}
function MyAssetsPage_li_16_Template(rf, ctx) {
  if (rf & 1) {
    const _r13 = _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](0, "li", 23)(1, "button", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵlistener"]("click", function MyAssetsPage_li_16_Template_button_click_1_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵrestoreView"](_r13);
      const item_r10 = restoredCtx.$implicit;
      const ctx_r12 = _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵresetView"](ctx_r12.selectChain(item_r10));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelement"](2, "bs-icon", 25)(3, "bs-icon", 26);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵtemplate"](4, MyAssetsPage_li_16_div_4_Template, 2, 3, "div", 27);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const item_r10 = ctx.$implicit;
    const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵproperty"]("defaultName", "chain-Default")("name", item_r10.activeIcon)("ngClass", ctx_r3.isSelectedChain(item_r10) ? "opacity-100" : "opacity-0");
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵproperty"]("defaultName", "chain-Default-s")("name", item_r10.unactiveIcon);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵproperty"]("ngIf", ctx_r3.isSelectedChain(item_r10));
  }
}
const _c5 = a0 => ({
  "--color-1": a0
});
function MyAssetsPage_div_18_div_4_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](0, "div", 34)(1, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵpipe"](3, "addressHidden");
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelement"](4, "bs-icon", 35);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵpipe"](5, "color");
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r14 = _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵpipeBind1"](3, 4, ctx_r14.showChainInfo.address));
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵpureFunction1"](8, _c5, _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵpipeBind1"](5, 6, "base-400")));
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵproperty"]("wClickToCopy", ctx_r14.showChainInfo.address);
  }
}
function MyAssetsPage_div_18_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](0, "div", 30)(1, "div")(2, "div", 31);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵtemplate"](4, MyAssetsPage_div_18_div_4_Template, 6, 10, "div", 32);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelement"](5, "img", 33);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵnextContext"]();
    const _r7 = _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵreference"](21);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵstyleProp"]("background-color", ctx_r4.showChainInfo.bgColor);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵproperty"]("@fadeInRight", undefined);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵtextInterpolate"](ctx_r4.showChainInfo.chainName);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵproperty"]("ngIf", ctx_r4.showChainInfo.address)("ngIfElse", _r7);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵproperty"]("src", ctx_r4.showChainInfo.bgIconUrl, _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵsanitizeUrl"]);
  }
}
function MyAssetsPage_ul_19_ng_container_2_ng_container_3_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelement"](1, "img", 46);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const item_r16 = _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵproperty"]("src", item_r16.iconUrl, _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵsanitizeUrl"]);
  }
}
function MyAssetsPage_ul_19_ng_container_2_ng_template_4_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelement"](0, "bs-icon", 47);
  }
  if (rf & 2) {
    const item_r16 = _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵproperty"]("defaultName", "token-Default")("name", item_r16.localTokenIcon);
  }
}
function MyAssetsPage_ul_19_ng_container_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](1, "li", 39)(2, "div", 40);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵtemplate"](3, MyAssetsPage_ul_19_ng_container_2_ng_container_3_Template, 2, 1, "ng-container", 41)(4, MyAssetsPage_ul_19_ng_container_2_ng_template_4_Template, 1, 2, "ng-template", null, 42, _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵtemplateRefExtractor"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](6, "span", 43);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵtext"](7);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](8, "div", 44)(9, "span", 45);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵtext"](10);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵpipe"](11, "amountFixed");
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const item_r16 = ctx.$implicit;
    const _r20 = _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵreference"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵproperty"]("ngIf", item_r16.iconUrl)("ngIfElse", _r20);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵtextInterpolate"](item_r16.assetType);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵpipeBind3"](11, 4, item_r16.amount, 8, _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵpureFunction0"](8, _c4)), " ");
  }
}
const _c6 = () => ({
  height: "calc(100% - 6.75rem)"
});
function MyAssetsPage_ul_19_Template(rf, ctx) {
  if (rf & 1) {
    const _r24 = _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](0, "ul", 36);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵlistener"]("pulled$", function MyAssetsPage_ul_19_Template_ul_pulled__0_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵrestoreView"](_r24);
      const ctx_r23 = _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵresetView"]($event.waitFor(ctx_r23.reGetAsset()));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelement"](1, "bn-pull-to-refresh-spinner", 37);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵtemplate"](2, MyAssetsPage_ul_19_ng_container_2_Template, 12, 9, "ng-container", 38);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵpureFunction0"](7, _c6));
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵproperty"]("emitDistance", 158)("maxDistance", 200)("@listFadeInRight", ctx_r5.listFadeInRightState);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵproperty"]("ngForOf", ctx_r5.showChainInfo.assets)("ngForTrackBy", ctx_r5.trackByKey("assetType"));
  }
}
function MyAssetsPage_ng_template_20_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](0, "div", 48);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵi18n"](1, 49);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
  }
}
const _c9 = () => ({
  "--page-safe-area-inset-top": 0
});
/** 资产页 */
class MyAssetsPage extends _modules_page_module__WEBPACK_IMPORTED_MODULE_4__.CommonPageBase {
  constructor() {
    var _this;
    /** 钱包服务 */
    super(...arguments);
    _this = this;
    this.walletService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_18__.inject)(_services_wallet_wallet_service__WEBPACK_IMPORTED_MODULE_5__.WalletService);
    /** 用户服务 */
    this.userService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_18__.inject)(_services_liquidity_user_liquidity_user_service__WEBPACK_IMPORTED_MODULE_7__.LiquidityUserService);
    /** 各个链的链信息详情 */
    this.chainListDetail = [];
    /** 可支持的链列表  */
    this.supportChainList = [];
    /** 已连接的钱包 */
    this.connectedWallet = this.walletService.connectedWallet;
    /** 用户总资产 */
    this.totalUAmount = 0;
    /** 余额的显示与隐藏 */
    this.showMyAsset = false;
    /** 监听余额 */
    this.walletAssets$ = this.walletService.curentWalletAssets_subject.subscribe( /*#__PURE__*/function () {
      var _ref = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (assetTaskInfo) {
        if (assetTaskInfo.updating || assetTaskInfo.connectedWallet === undefined) {
          return;
        }
        if (_this.connectedWallet === undefined || _this.connectedWallet.pmchainAddress !== assetTaskInfo.connectedWallet.pmchainAddress) {
          return;
        }
        _this.console.info('更新资产页余额');
        _this.connectedWallet = assetTaskInfo.connectedWallet;
        return;
      });
      return function (_x) {
        return _ref.apply(this, arguments);
      };
    }());
    /** 链卡片信息 */
    this.CHAIN_CARD_INFO = new Map([[_bnqkl_wallet_base_services__WEBPACK_IMPORTED_MODULE_3__.CHAIN_NAME.BFChainV2, {
      bgColor: '#A484EE',
      bgIconUrl: './assets/images/chain-BFChainV2-w.png'
    }], [_bnqkl_wallet_base_services__WEBPACK_IMPORTED_MODULE_3__.CHAIN_NAME.BFMeta, {
      bgColor: '#7D65F7',
      bgIconUrl: './assets/images/chain-BFMeta-w.png'
    }], [_bnqkl_wallet_base_services__WEBPACK_IMPORTED_MODULE_3__.CHAIN_NAME.BTCMeta, {
      bgColor: '#F7931A',
      bgIconUrl: './assets/images/chain-BTCMeta-w.png'
    }], [_bnqkl_wallet_base_services__WEBPACK_IMPORTED_MODULE_3__.CHAIN_NAME.ETHMeta, {
      bgColor: '#1829F5',
      bgIconUrl: './assets/images/chain-ETHMeta-w.png'
    }], [_bnqkl_wallet_base_services__WEBPACK_IMPORTED_MODULE_3__.CHAIN_NAME.PMChain, {
      bgColor: '#8265F9',
      bgIconUrl: './assets/images/chain-Pay-Meta-Chain-w.png'
    }]]);
    /** 默认卡片信息 */
    this.CHAIN_CARD_DEFAULT_INFO = {
      bgColor: '#A484EE',
      bgIconUrl: './assets/images/chain-normal-w.png'
    };
    /** 链名 */
    this.CHAIN_NAME = _bnqkl_wallet_base_services__WEBPACK_IMPORTED_MODULE_3__.CHAIN_NAME;
    /** 传递给饼图的数据 */
    this.pieChartData = {
      totalAmount: 0,
      list: []
    };
  }
  /** 打开提示窗口 */
  openTip() {
    var _this2 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      yield _this2.alert({
        headerTitle: `总资产`,
        bodyMessage: '总资产仅根据钱包授权的，且在BTCSwap中支持兑换的权益（即：BFT，PMC，ETHM，BTCM，KPM，FTC，USDM）换算成USDM计算，范围包括地址中的权益，以及各流动池权益。',
        buttonText: '好的'
      });
    })();
  }
  /** 要展示的链信息（资产列表） */
  get showChainInfo() {
    const chainCardInfo = this.CHAIN_CARD_INFO.get(this.activeChainName);
    if (this.activeChainName && this.connectedWallet) {
      const assetsList = this.connectedWallet.assetInfoListMap.get(this.activeChainName);
      if (assetsList) {
        return {
          bgIconUrl: (chainCardInfo === null || chainCardInfo === void 0 ? void 0 : chainCardInfo.bgIconUrl) || this.CHAIN_CARD_DEFAULT_INFO.bgIconUrl,
          bgColor: (chainCardInfo === null || chainCardInfo === void 0 ? void 0 : chainCardInfo.bgColor) || this.CHAIN_CARD_DEFAULT_INFO.bgColor,
          ...assetsList
        };
      }
    }
    return {
      bgIconUrl: (chainCardInfo === null || chainCardInfo === void 0 ? void 0 : chainCardInfo.bgIconUrl) || this.CHAIN_CARD_DEFAULT_INFO.bgIconUrl,
      bgColor: (chainCardInfo === null || chainCardInfo === void 0 ? void 0 : chainCardInfo.bgColor) || this.CHAIN_CARD_DEFAULT_INFO.bgColor,
      chainName: this.activeChainName,
      assets: [],
      address: ''
    };
  }
  /** 是否是选中的链 */
  isSelectedChain(chain) {
    return chain.chain === this.activeChainName;
  }
  /** 刷新资产 */
  reGetAsset() {
    var _this3 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      yield _this3.walletService.updateAsset();
    })();
  }
  /** 清除订阅监听 */
  unsubscribe() {
    this.console.log('清除 订阅 walletAssets$');
    this.walletAssets$.unsubscribe();
    this.walletService.allSubscribes.delete('MyAssetsPage');
  }
  /** 默认选中第一条 */
  selectDefaultChain() {
    var _this4 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this4.activeChainName = _this4.supportChainList[0].chain;
      _this4.walletService.allSubscribes.set('MyAssetsPage', [_this4.walletAssets$]);
    })();
  }
  /** 选中链 */
  selectChain(chain) {
    this.activeChainName = chain.chain;
  }
  /** 动画的状态机 */
  get listFadeInRightState() {
    return this.activeChainName + ':' + this.showChainInfo.assets.length;
  }
  /** 动画状态机 */
  get chianNameFadeInRightState() {
    return this.activeChainName;
  }
  walletInit() {
    var _this5 = this;
    // 监听钱包变化
    this.connectWallet$ = this.walletService.wallletConnected_subject.subscribe( /*#__PURE__*/function () {
      var _ref2 = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (data) {
        if (data === undefined) {
          return;
        }
        _this5.connectedWallet = data.wallet;
        _this5.getUserPositonList();
        return;
      });
      return function (_x2) {
        return _ref2.apply(this, arguments);
      };
    }());
    // 监听余额变化
    this.walletAssets$ = this.walletService.curentWalletAssets_subject.subscribe( /*#__PURE__*/function () {
      var _ref3 = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (assetTaskInfo) {
        if (assetTaskInfo.updating || assetTaskInfo.connectedWallet === undefined) {
          return;
        }
        _this5.connectedWallet = assetTaskInfo.connectedWallet;
        _this5.getUserPositonList();
        /** 实时变更界面余额(如果余额发生变化的话) */
        _this5.console.info('兑换面板监听到余额变化', _this5.connectedWallet);
        return;
      });
      return function (_x3) {
        return _ref3.apply(this, arguments);
      };
    }());
  }
  /** 跳转个人资产页面 */
  jumpAssetAllocation() {
    this.nav.routeTo('/mine/my-asset-allocation', {
      pieChartData: JSON.stringify(this.pieChartData)
    });
  }
  /** 获取用户持仓 */
  getUserPositonList() {
    var _this6 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const {
        connectedWallet
      } = _this6;
      if (connectedWallet) {
        const userId = connectedWallet.pmchainAddress;
        const result = yield _this6.userService.getLiquidityUserAssetsList({
          userId
        });
        if (result) {
          const walletAssets = connectedWallet.assetInfoListMap;
          const positionAsset = _this6.handlerPositionAssetGenMap(result);
          const walletAsset = _this6.handleWalletAsset(walletAssets, positionAsset);
          const walletTotalU = _this6.calculateWalletTotalU(walletAsset);
          const positonTotalU = _this6.calculatePostitonTotalU(result);
          const totalU = walletTotalU + positonTotalU;
          _this6.totalUAmount = Number(totalU);
          _this6.handlePieChartData(walletAsset, result);
        }
      } else {
        _this6.totalUAmount = 0;
      }
    })();
  }
  /** 处理饼图需要的的数据  免去再次查询 */
  handlePieChartData(walletAsset, postionAsset) {
    const {
      totalUAmount
    } = this;
    const list = [];
    walletAsset.forEach(item => {
      const ratio = new bignumber_js__WEBPACK_IMPORTED_MODULE_2__["default"](item.amount).div(totalUAmount);
      list.push({
        name: item.coin,
        amount: Number(ratio)
      });
    });
    postionAsset.forEach(item => {
      const {
        quoteCoinsAmount
      } = item;
      if (Number(quoteCoinsAmount) > 0) {
        const amount = new bignumber_js__WEBPACK_IMPORTED_MODULE_2__["default"](quoteCoinsAmount).multipliedBy(2);
        const ratio = amount.div(totalUAmount);
        list.push({
          name: `池${item.anchorCoinsName}-${item.quoteCoinsName}`,
          amount: Number(ratio)
        });
      }
    });
    this.pieChartData.totalAmount = totalUAmount;
    this.pieChartData.list = list;
  }
  /** 计算持仓全部的U  */
  calculatePostitonTotalU(assetList) {
    let totalU = 0n;
    assetList.forEach(asset => {
      totalU += BigInt(asset.userRedeemableQuoteCoinsAmount) * 2n;
    });
    return totalU;
  }
  /** 计算钱包全部的U */
  calculateWalletTotalU(assetList) {
    let totalU = 0n;
    assetList.forEach(asset => {
      totalU += BigInt(asset.amount);
    });
    return totalU;
  }
  /** 处理持仓资产生成Map方便获取 */
  handlerPositionAssetGenMap(assetList) {
    const assetMap = new Map();
    assetList.forEach(asset => {
      const anchorCoinName = asset.anchorCoinsName;
      const anchorChainName = asset.anchorCoinsChainName;
      const key = `${anchorCoinName}-${_services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_9__.NODE_CHAIN_NAME_TRANSFER[anchorChainName]}`;
      assetMap.set(key, asset);
    });
    return assetMap;
  }
  /** 处理钱包的资产 */
  handleWalletAsset(walletAssets, positionAssets) {
    let walletUAmount = 0;
    const assetList = [];
    for (const [chainName, value] of walletAssets) {
      value.assets.forEach(element => {
        const {
          assetType: coinName,
          amount: coinAmount
        } = element;
        if (Number(coinAmount) > 0) {
          // 如果是U 不需要换算 不是U 要根据池子中币的数量 等比换算成U
          if (coinName === _bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_8__.BNQKL_SWAP_COIN_NAME.USDM) {
            walletUAmount += Number(coinAmount);
          } else {
            const key = `${coinName}-${chainName}`;
            const positionAsset = positionAssets.get(key);
            if (positionAsset) {
              const {
                price
              } = positionAsset;
              const equivalenceU = parseInt(new bignumber_js__WEBPACK_IMPORTED_MODULE_2__["default"](price).multipliedBy(coinAmount).toString());
              assetList.push({
                coin: coinName,
                amount: equivalenceU
              });
            }
          }
        }
      });
    }
    if (walletUAmount > 0) {
      assetList.unshift({
        coin: _bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_8__.BNQKL_SWAP_COIN_NAME.USDM,
        amount: walletUAmount
      });
    }
    return assetList;
  }
}
_class = MyAssetsPage;
_class.ɵfac = /*@__PURE__*/(() => {
  let ɵMyAssetsPage_BaseFactory;
  return function MyAssetsPage_Factory(t) {
    return (ɵMyAssetsPage_BaseFactory || (ɵMyAssetsPage_BaseFactory = _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵgetInheritedFactory"](_class)))(t || _class);
  };
})();
_class.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵdefineComponent"]({
  type: _class,
  selectors: [["bs-mine-my-assets"]],
  standalone: true,
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵInheritDefinitionFeature"], _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵStandaloneFeature"]],
  decls: 22,
  vars: 10,
  consts: () => {
    let i18n_1;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_USDM$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_ASSETS_MY_ASSETS_COMPONENT_TS_2 = goog.getMsg("\u603B\u8D44\u4EA7(USDM)");
      i18n_1 = MSG_EXTERNAL_USDM$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_ASSETS_MY_ASSETS_COMPONENT_TS_2;
    } else {
      i18n_1 = "\u603B\u8D44\u4EA7(USDM)";
    }
    let i18n_0;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_826708420723205868$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_ASSETS_MY_ASSETS_COMPONENT_TS__3 = goog.getMsg(" \u94B1\u5305 {$startBlockIf}{$startTagDiv}{$startTagBsIcon}{$closeTagBsIcon}{$closeTagDiv}{$closeBlockIf}", {
        "closeBlockIf": "\uFFFD/*4:1\uFFFD",
        "closeTagBsIcon": "\uFFFD/#2:1\uFFFD",
        "closeTagDiv": "\uFFFD/#1:1\uFFFD",
        "startBlockIf": "\uFFFD*4:1\uFFFD",
        "startTagBsIcon": "\uFFFD#2:1\uFFFD",
        "startTagDiv": "\uFFFD#1:1\uFFFD"
      }, {
        original_code: {
          "closeBlockIf": "}",
          "closeTagBsIcon": "</bs-icon>",
          "closeTagDiv": "</div>",
          "startBlockIf": "@if (totalUAmount>0) {",
          "startTagBsIcon": "<bs-icon [name]=\"'icon-chart'\" class=\"icon-4.5\">",
          "startTagDiv": "<div\r\n        (click)=\"jumpAssetAllocation()\"\r\n        class=\"rounded-2.5 bg-base-300 ml-auto flex h-8 w-8 items-center justify-center\"\r\n      >"
        }
      });
      i18n_0 = MSG_EXTERNAL_826708420723205868$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_ASSETS_MY_ASSETS_COMPONENT_TS__3;
    } else {
      i18n_0 = " \u94B1\u5305 " + "\uFFFD*4:1\uFFFD" + "" + "\uFFFD#1:1\uFFFD" + "" + "\uFFFD#2:1\uFFFD" + "" + "\uFFFD/#2:1\uFFFD" + "" + "\uFFFD/#1:1\uFFFD" + "" + "\uFFFD/*4:1\uFFFD" + "";
    }
    let i18n_7;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_UNAUTHORIZED_ADDRESS$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_ASSETS_MY_ASSETS_COMPONENT_TS__8 = goog.getMsg("unauthorized address");
      i18n_7 = MSG_EXTERNAL_UNAUTHORIZED_ADDRESS$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_ASSETS_MY_ASSETS_COMPONENT_TS__8;
    } else {
      i18n_7 = "unauthorized address";
    }
    return [[3, "hideHeader", "contentBackground", "ngStyle"], [1, "flex", "h-full", "flex-col", "pt-4"], [1, "text-title-10", "mb-4", "flex", "h-10", "items-center", "px-4", "text-[2rem]", "font-semibold"], i18n_0, ["class", "rounded-2.5 bg-base-300 ml-auto flex h-8 w-8 items-center justify-center"], [1, "mb-6", "px-4", "text-white"], [1, "h-29", "_bg-asset", "p-4"], [1, "mb-4", "flex", "items-center", "text-xs"], i18n_1, ["name", "icon-info", 1, "icon-4", "ml-1", 3, "click"], [1, "flex", "items-center", 3, "click"], [1, "flex", "flex-row", "border-t", 2, "height", "calc(100% - 13.25rem)"], [1, "mt-6", "grid", "h-min", "w-16", "grid-flow-row", "gap-4", "overflow-y-auto", "overflow-x-hidden", "pl-4"], ["class", "flex items-center", 4, "ngFor", "ngForOf", "ngForTrackBy"], [1, "h-full", "flex-grow", "overflow-hidden", "border-l", "bg-white"], ["class", "rounded-4 ml-2 mr-4 mt-6 flex w-auto items-center justify-between text-white", 3, "backgroundColor", 4, "ngIf"], ["wPullToRefresh", "", "class", "overflow-x-hidden overflow-y-scroll pl-1.5 pr-5 pt-1.5", 3, "emitDistance", "maxDistance", "style", "pulled$", 4, "ngIf"], ["unconnectedChain", ""], [1, "rounded-2.5", "bg-base-300", "ml-auto", "flex", "h-8", "w-8", "items-center", "justify-center", 3, "click"], [1, "icon-4.5", 3, "name"], [1, "text-2xl", "font-extrabold"], ["name", "icon-eye", 1, "icon-5", "ml-2"], ["name", "icon-eye-off", 1, "icon-5", "ml-2"], [1, "flex", "items-center"], [1, "grid-areas-[icon]", "rounded-1", "bg-base-300", "grid", 3, "click"], [1, "icon-8", "duration-ios", "ease-ios-out", "grid-in-[icon]", "z-[2]", 3, "defaultName", "name", "ngClass"], [1, "icon-8", "grid-in-[icon]", "z-[1]", 3, "defaultName", "name"], ["class", "pl-3", 4, "ngIf"], [1, "pl-3"], [1, "h-4.5", "w-1", "rounded-lg"], [1, "rounded-4", "ml-2", "mr-4", "mt-6", "flex", "w-auto", "items-center", "justify-between", "text-white"], [1, "ml-3", "mt-3", "font-semibold"], ["class", "text-base-400 mb-3 ml-3 flex items-center text-xs font-normal", 4, "ngIf", "ngIfElse"], [1, "mr-2", "h-16", "w-16", 3, "src"], [1, "text-base-400", "mb-3", "ml-3", "flex", "items-center", "text-xs", "font-normal"], ["name", "icon-copy1", 1, "icon-7", "grid-in-[icon]", "z-[1]", 3, "wClickToCopy"], ["wPullToRefresh", "", 1, "overflow-x-hidden", "overflow-y-scroll", "pl-1.5", "pr-5", "pt-1.5", 3, "emitDistance", "maxDistance", "pulled$"], [1, "text-subtext"], [4, "ngFor", "ngForOf", "ngForTrackBy"], [1, "rounded-4", "h-13", "text-base-content-100", "flex", "items-center", "justify-between", "bg-white", "text-sm", "font-semibold"], [1, "flex", "w-1/3", "items-center"], [4, "ngIf", "ngIfElse"], ["localIcon", ""], [1, "ml-2"], [1, "flex", "w-2/3", "justify-end"], [1, "no-scrollbar", "overflow-scroll"], ["alt", "", 1, "h-8", "w-8", 3, "src"], [1, "icon-7", 3, "defaultName", "name"], [1, "text-normal", "text-base-400", "my-4", "ml-3", "text-sm"], i18n_7];
  },
  template: function MyAssetsPage_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](0, "common-page", 0)(1, "div", 1)(2, "div", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵi18nStart"](3, 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵtemplate"](4, MyAssetsPage_Conditional_4_Template, 3, 1, "div", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵi18nEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](5, "div", 5)(6, "div", 6)(7, "div", 7)(8, "span");
      _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵi18n"](9, 8);
      _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](10, "bs-icon", 9);
      _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵlistener"]("click", function MyAssetsPage_Template_bs_icon_click_10_listener() {
        return ctx.openTip();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](11, "div", 10);
      _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵlistener"]("click", function MyAssetsPage_Template_div_click_11_listener() {
        return ctx.showMyAsset = !ctx.showMyAsset;
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵtemplate"](12, MyAssetsPage_Conditional_12_Template, 5, 8)(13, MyAssetsPage_Conditional_13_Template, 3, 0);
      _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]()()();
      _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](14, "main", 11)(15, "ul", 12);
      _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵtemplate"](16, MyAssetsPage_li_16_Template, 5, 6, "li", 13);
      _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](17, "div", 14);
      _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵtemplate"](18, MyAssetsPage_div_18_Template, 6, 7, "div", 15)(19, MyAssetsPage_ul_19_Template, 3, 8, "ul", 16);
      _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]()()()();
      _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵtemplate"](20, MyAssetsPage_ng_template_20_Template, 2, 0, "ng-template", null, 17, _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵtemplateRefExtractor"]);
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵproperty"]("hideHeader", true)("contentBackground", "white")("ngStyle", _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵpureFunction0"](9, _c9));
      _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵadvance"](4);
      _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵconditional"](4, ctx.totalUAmount > 0 ? 4 : -1);
      _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵadvance"](8);
      _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵconditional"](12, ctx.showMyAsset ? 12 : 13);
      _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵadvance"](4);
      _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵproperty"]("ngForOf", ctx.supportChainList)("ngForTrackBy", ctx.trackByKey("chain"));
      _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵproperty"]("ngIf", ctx.activeChainName);
      _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵproperty"]("ngIf", ctx.activeChainName);
    }
  },
  dependencies: [_pipes_amount_format_amount_format_pipe__WEBPACK_IMPORTED_MODULE_10__.AmountFormatPipe, _bnqkl_framework_pipes__WEBPACK_IMPORTED_MODULE_6__.AddressHiddenPipe, _modules_page_module__WEBPACK_IMPORTED_MODULE_4__.CommonPageModule, _libs_bnf_components_pull_to_refresh_pull_to_refresh_directive__WEBPACK_IMPORTED_MODULE_11__.PullToRefreshDirective, _libs_bnf_components_pull_to_refresh_pull_to_refresh_spinner_component__WEBPACK_IMPORTED_MODULE_12__.PullToRefreshSpinnerComponent, _libs_bnf_directives_click_to_copy_directive__WEBPACK_IMPORTED_MODULE_13__.ClickToCopyDirective, _angular_common__WEBPACK_IMPORTED_MODULE_19__.NgClass, _angular_common__WEBPACK_IMPORTED_MODULE_19__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_19__.NgIf, _angular_common__WEBPACK_IMPORTED_MODULE_19__.NgStyle, _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_14__.CommonPageComponent, _components_icon_icon_component__WEBPACK_IMPORTED_MODULE_15__.IconComponent, _pipes_color_color_pipe__WEBPACK_IMPORTED_MODULE_16__.ColorPipe, _libs_bnf_pipes_amountFixed_amount_fixed_pipe__WEBPACK_IMPORTED_MODULE_17__.AmountFixedPipe, _angular_common__WEBPACK_IMPORTED_MODULE_19__.CommonModule],
  styles: ["[_nghost-%COMP%]   ._bg-asset[_ngcontent-%COMP%] {\n  background-image: url('asset-allocation-bg.png');\n  background-size: 100% 100%;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL2FwcHMvYmZzd2FwL3NyYy9wYWdlcy9taW5lL3BhZ2VzL215LWFzc2V0cy9teS1hc3NldHMuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQ0k7RUFDSSxnREFBQTtFQUNBLDBCQUFBO0FBQVIiLCJzb3VyY2VzQ29udGVudCI6WyI6aG9zdHtcclxuICAgIC5fYmctYXNzZXR7XHJcbiAgICAgICAgYmFja2dyb3VuZC1pbWFnZTogdXJsKCcuL2Fzc2V0cy9pbWFnZXMvYXNzZXQtYWxsb2NhdGlvbi1iZy5wbmcnKTtcclxuICAgICAgICBiYWNrZ3JvdW5kLXNpemU6IDEwMCUgMTAwJTtcclxuICAgIH1cclxufSJdLCJzb3VyY2VSb290IjoiIn0= */"],
  data: {
    animation: [_bnqkl_framework_animations__WEBPACK_IMPORTED_MODULE_1__.listFadeRightTrigger, _bnqkl_framework_animations__WEBPACK_IMPORTED_MODULE_1__.listFadeInRightTrigger, _bnqkl_framework_animations__WEBPACK_IMPORTED_MODULE_1__.listFadeOutLeftTrigger, _bnqkl_framework_animations__WEBPACK_IMPORTED_MODULE_1__.fadeInLeftTrigger, _bnqkl_framework_animations__WEBPACK_IMPORTED_MODULE_1__.fadeInRightTrigger]
  },
  changeDetection: 0
});
(0,tslib__WEBPACK_IMPORTED_MODULE_20__.__decorate)([MyAssetsPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_20__.__metadata)("design:type", Array)], MyAssetsPage.prototype, "supportChainList", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_20__.__decorate)([MyAssetsPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_20__.__metadata)("design:type", Object)], MyAssetsPage.prototype, "activeChainName", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_20__.__decorate)([MyAssetsPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_20__.__metadata)("design:type", Object)], MyAssetsPage.prototype, "connectedWallet", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_20__.__decorate)([MyAssetsPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_20__.__metadata)("design:type", Object)], MyAssetsPage.prototype, "totalUAmount", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_20__.__decorate)([MyAssetsPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_20__.__metadata)("design:type", Object)], MyAssetsPage.prototype, "showMyAsset", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_20__.__decorate)([MyAssetsPage.OnDestroy(), (0,tslib__WEBPACK_IMPORTED_MODULE_20__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_20__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_20__.__metadata)("design:returntype", void 0)], MyAssetsPage.prototype, "unsubscribe", null);
(0,tslib__WEBPACK_IMPORTED_MODULE_20__.__decorate)([MyAssetsPage.OnReady(), (0,tslib__WEBPACK_IMPORTED_MODULE_20__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_20__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_20__.__metadata)("design:returntype", Promise)], MyAssetsPage.prototype, "selectDefaultChain", null);
(0,tslib__WEBPACK_IMPORTED_MODULE_20__.__decorate)([MyAssetsPage.OnInit(), (0,tslib__WEBPACK_IMPORTED_MODULE_20__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_20__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_20__.__metadata)("design:returntype", void 0)], MyAssetsPage.prototype, "walletInit", null);
(0,tslib__WEBPACK_IMPORTED_MODULE_20__.__decorate)([MyAssetsPage.AfterViewInit(), (0,tslib__WEBPACK_IMPORTED_MODULE_20__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_20__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_20__.__metadata)("design:returntype", Promise)], MyAssetsPage.prototype, "getUserPositonList", null);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MyAssetsPage);

/***/ }),

/***/ 23627:
/*!***************************************************************************************************!*\
  !*** ./apps/bfswap/src/pages/mine/pages/my-liquidity-holdings/my-liquidity-holdings.component.ts ***!
  \***************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   MyLiquidityHoldingsPage: () => (/* binding */ MyLiquidityHoldingsPage),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 52542);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! tslib */ 90505);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @angular/common */ 6729);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @angular/core */ 61039);
/* harmony import */ var _bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @bnqkl/bnqkl-swap-core */ 70195);
/* harmony import */ var _components_token_with_chain_icon_token_with_chain_icon_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ~components/token-with-chain-icon/token-with-chain-icon.component */ 11342);
/* harmony import */ var _modules_page_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ~modules/page.module */ 16381);
/* harmony import */ var _pipes_chain_name_transfer_chain_name_transfer_pipe__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ~pipes/chain-name-transfer/chain-name-transfer.pipe */ 37514);
/* harmony import */ var _pages_home_pages_market_market_helper__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ~pages/home/pages/market/market.helper */ 64875);
/* harmony import */ var _services_liquidity_pool_liquidity_pool_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ~services/liquidity-pool/liquidity-pool.service */ 20213);
/* harmony import */ var _services_wallet_wallet_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ~services/wallet/wallet.service */ 54275);
/* harmony import */ var _bnqkl_framework_plugins_toast__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @bnqkl/framework/plugins/toast */ 18030);
/* harmony import */ var _components_swap_token_chain_icon_swap_token_chain_icon_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ~components/swap-token-chain-icon/swap-token-chain-icon.component */ 26193);
/* harmony import */ var _services_liquidity_user_liquidity_user_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ~services/liquidity-user/liquidity-user.service */ 34913);
/* harmony import */ var _libs_bnf_components_pull_to_refresh_pull_to_refresh_directive__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../../../../../../libs/bnf/components/pull-to-refresh/pull-to-refresh.directive */ 97063);
/* harmony import */ var _libs_bnf_components_pull_to_refresh_pull_to_refresh_spinner_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../../../../../../libs/bnf/components/pull-to-refresh/pull-to-refresh-spinner.component */ 75387);
/* harmony import */ var _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../../../../../../../libs/bnf/modules/page/common-page/common-page.component */ 62052);
/* harmony import */ var _components_icon_icon_component__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../../../../components/icon/icon.component */ 18840);
/* harmony import */ var _libs_bnf_components_loading_wrapper_loading_wrapper_component__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ../../../../../../../libs/bnf/components/loading-wrapper/loading-wrapper.component */ 51263);
/* harmony import */ var _libs_bnf_pipes_amountFixed_amount_fixed_pipe__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ../../../../../../../libs/bnf/pipes/amountFixed/amount-fixed.pipe */ 44070);

var _class;





















function MyLiquidityHoldingsPage_Conditional_13_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](0, "div", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelement"](1, "img", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](2, "div", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵi18n"](3, 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]()();
  }
}
function MyLiquidityHoldingsPage_Conditional_14_Conditional_0_For_3_Conditional_14_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](0, "div", 26);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵpipe"](2, "chainNameTransfer");
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const item_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵpipeBind1"](2, 1, item_r6.quoteCoinsChainName), " ");
  }
}
const _c10 = () => ({
  removeZero: true
});
function MyLiquidityHoldingsPage_Conditional_14_Conditional_0_For_3_Template(rf, ctx) {
  if (rf & 1) {
    const _r14 = _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](0, "div", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵlistener"]("click", function MyLiquidityHoldingsPage_Conditional_14_Conditional_0_For_3_Template_div_click_0_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵrestoreView"](_r14);
      const item_r6 = restoredCtx.$implicit;
      const ctx_r13 = _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵnextContext"](3);
      return _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵresetView"](ctx_r13.jumpDetail(item_r6.poolId));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](1, "div", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelement"](2, "bs-token-with-chain-icon", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](3, "div", 24)(4, "div", 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtext"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](6, "div", 26);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtext"](7);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵpipe"](8, "chainNameTransfer");
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelement"](9, "div", 27)(10, "bs-swap-token-chain-icon", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](11, "div", 24)(12, "div", 29);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtext"](13);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtemplate"](14, MyLiquidityHoldingsPage_Conditional_14_Conditional_0_For_3_Conditional_14_Template, 3, 3, "div", 30);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelement"](15, "bs-icon", 31);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](16, "div", 32)(17, "div", 33);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵi18n"](18, 34);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](19, "div", 35)(20, "div", 36);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtext"](21);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵpipe"](22, "amountFixed");
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelement"](23, "bs-swap-token-chain-icon", 37);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](24, "div", 36);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtext"](25);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵpipe"](26, "amountFixed");
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelement"](27, "bs-swap-token-chain-icon", 37);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const item_r6 = ctx.$implicit;
    const ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵproperty"]("swapChainName", item_r6.anchorCoinsChainName)("swapCoinName", item_r6.anchorCoinsName);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtextInterpolate"](item_r6.anchorCoinsName);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵpipeBind1"](8, 15, item_r6.anchorCoinsChainName), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵproperty"]("iconSize", "icon-8")("swapChainName", item_r6.quoteCoinsChainName)("swapCoinName", item_r6.quoteCoinsName);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtextInterpolate"](item_r6.quoteCoinsName);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵconditional"](14, ctx_r5.noBigU(item_r6.quoteCoinsChainName, item_r6.quoteCoinsName) ? 14 : -1);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](7);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵpipeBind3"](22, 17, item_r6.userRedeemableAnchorCoinsAmount, 8, _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵpureFunction0"](25, _c10)), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵproperty"]("swapCoinName", item_r6.anchorCoinsName)("swapChainName", item_r6.anchorCoinsChainName);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵpipeBind3"](26, 21, item_r6.userRedeemableQuoteCoinsAmount, 8, _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵpureFunction0"](26, _c10)), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵproperty"]("swapCoinName", item_r6.quoteCoinsName)("swapChainName", item_r6.quoteCoinsChainName);
  }
}
function MyLiquidityHoldingsPage_Conditional_14_Conditional_0_Template(rf, ctx) {
  if (rf & 1) {
    const _r16 = _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](0, "div", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵlistener"]("pulled$", function MyLiquidityHoldingsPage_Conditional_14_Conditional_0_Template_div_pulled__0_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵrestoreView"](_r16);
      const ctx_r15 = _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵresetView"]($event.waitFor(ctx_r15.refresh()));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelement"](1, "bn-pull-to-refresh-spinner", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵrepeaterCreate"](2, MyLiquidityHoldingsPage_Conditional_14_Conditional_0_For_3_Template, 28, 27, "div", 38, _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵrepeaterTrackByIndex"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵproperty"]("emitDistance", 158)("maxDistance", 200);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵrepeater"](ctx_r3.dataList);
  }
}
function MyLiquidityHoldingsPage_Conditional_14_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](0, "div", 39);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelement"](1, "img", 40);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](2, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵi18n"](3, 41);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]()();
  }
}
function MyLiquidityHoldingsPage_Conditional_14_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtemplate"](0, MyLiquidityHoldingsPage_Conditional_14_Conditional_0_Template, 4, 2, "div", 18)(1, MyLiquidityHoldingsPage_Conditional_14_Conditional_1_Template, 4, 0);
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵconditional"](0, ctx_r1.dataList.length > 0 ? 0 : 1);
  }
}
function MyLiquidityHoldingsPage_Conditional_15_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](0, "div", 42);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelement"](1, "bn-loading-wrapper", 43);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](2, "p", 44);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵi18n"](3, 45);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵproperty"]("showLoading", true);
  }
}
const _c15 = () => ({
  "--page-safe-area-inset-top": 0
});
/** 我的流动性持仓 */
class MyLiquidityHoldingsPage extends _modules_page_module__WEBPACK_IMPORTED_MODULE_3__.CommonPageBase {
  constructor() {
    super(...arguments);
    /** 合约池服务 */
    this.poolService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_17__.inject)(_services_liquidity_pool_liquidity_pool_service__WEBPACK_IMPORTED_MODULE_6__.LiquidityPoolService);
    /** 用户服务 */
    this.userService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_17__.inject)(_services_liquidity_user_liquidity_user_service__WEBPACK_IMPORTED_MODULE_10__.LiquidityUserService);
    /** 钱包服务 */
    this.walletService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_17__.inject)(_services_wallet_wallet_service__WEBPACK_IMPORTED_MODULE_7__.WalletService);
    /** 连接的钱包 */
    this.connectedWallet = this.walletService.connectedWallet;
    /** 搜索关键字 */
    this.searchkey = '';
    /** 是否初始化 */
    this.init = false;
    /** 数据列表 */
    this.dataList = [];
  }
  /** 跳转详情页面 */
  jumpDetail(poolId) {
    var _this$connectedWallet;
    const userId = (_this$connectedWallet = this.connectedWallet) === null || _this$connectedWallet === void 0 ? void 0 : _this$connectedWallet.pmchainAddress;
    if (userId) {
      this.nav.routeTo('/mine/my-holdings-detail', {
        userId,
        poolId
      });
    }
  }
  onresume() {
    this.console.log('onresume MyLiquidityHoldingsPage');
  }
  walletInit() {
    var _this = this;
    // 监听钱包变化
    this.connectWallet$ = this.walletService.wallletConnected_subject.subscribe( /*#__PURE__*/function () {
      var _ref = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (data) {
        if (data === undefined) {
          return;
        }
        const {
          wallet
        } = data;
        _this.connectedWallet = wallet;
        if (wallet) {
          _this.getDataList();
        } else {
          _this.dataList = [];
          _this.init = false;
        }
      });
      return function (_x) {
        return _ref.apply(this, arguments);
      };
    }());
  }
  /** 跳转添加流动性页面 */
  jumpAddLiquidity() {
    if (this.connectedWallet) {
      this.nav.routeTo('/add-liquidity');
    } else {
      _bnqkl_framework_plugins_toast__WEBPACK_IMPORTED_MODULE_8__.Toast.show('请先连接钱包');
    }
  }
  /** 跳转记录页面 */
  jumpRecordPage() {
    if (this.connectedWallet) {
      this.nav.routeTo('/mine/my-record');
    } else {
      _bnqkl_framework_plugins_toast__WEBPACK_IMPORTED_MODULE_8__.Toast.show('请先连接钱包');
    }
  }
  /** 下拉刷新 */
  refresh() {
    var _this2 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this2.getDataList();
    })();
  }
  /** 跳转移除流动性页面 */
  jumpRemovePage(hold) {
    this.nav.routeTo('/remove-liquidity', {
      hold: JSON.stringify(hold)
    });
  }
  /** 跳转添加流动性页面 */
  jumpAddPage(data) {
    const {
      anchorCoinsName,
      anchorCoinsChainName,
      quoteCoinsName,
      quoteCoinsChainName
    } = data;
    this.nav.routeTo('/add-liquidity', {
      anchorCoinName: anchorCoinsName,
      anchorChainName: anchorCoinsChainName,
      quoteCoinName: quoteCoinsName,
      quoteChainName: quoteCoinsChainName
    });
  }
  /** 跳转合约池页面 */
  jumpPoolPage(ownnerLiquidityPools) {
    const poolDetail = {
      fluctuationRange: '--',
      quoteCoinsTotalFee: '0',
      anchorCoinsTotalFee: '0',
      ...ownnerLiquidityPools,
      anchorCoinsReceivedProfits: '',
      quoteCoinsReceivedProfits: '',
      createdTime: 0,
      updatedTime: 0,
      anchorAssociatedCoins: [],
      quoteAssociatedCoins: [],
      anchorCoinsRecipientAddress: '',
      quoteCoinsRecipientAddress: '',
      feeRatio: '',
      anchorCoinsTotalProfits: '',
      quoteCoinsTotalProfits: '',
      totalValue: '',
      totalExchangesTimes: ''
    };
    const marketItem = (0,_pages_home_pages_market_market_helper__WEBPACK_IMPORTED_MODULE_5__.transferPoolItemToMaketItem)(poolDetail);
    if (marketItem) {
      this.nav.routeTo('/liquidity-detail', {
        poolDetailstring: JSON.stringify(marketItem)
      });
    } else {
      this.console.error('池子流动性为0');
    }
  }
  /** 判断是不是USDM SWAP链 */
  noBigU(chainName, tokenName) {
    return chainName !== _bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_1__.BNQKL_SWAP_CHAIN_NAME.SWAP || tokenName !== _bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_1__.BNQKL_SWAP_COIN_NAME.USDM;
  }
  /** 获取数据列表 */
  getDataList() {
    var _this3 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      var _this3$connectedWalle;
      const userId = (_this3$connectedWalle = _this3.connectedWallet) === null || _this3$connectedWalle === void 0 ? void 0 : _this3$connectedWalle.pmchainAddress;
      if (userId) {
        const result = yield _this3.userService.getUserLiquidityHolding({
          userId
        });
        if (result) {
          _this3.init = true;
          _this3.dataList = result;
        }
      }
    })();
  }
}
_class = MyLiquidityHoldingsPage;
_class.ɵfac = /*@__PURE__*/(() => {
  let ɵMyLiquidityHoldingsPage_BaseFactory;
  return function MyLiquidityHoldingsPage_Factory(t) {
    return (ɵMyLiquidityHoldingsPage_BaseFactory || (ɵMyLiquidityHoldingsPage_BaseFactory = _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵgetInheritedFactory"](_class)))(t || _class);
  };
})();
_class.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵdefineComponent"]({
  type: _class,
  selectors: [["bs-mine-my-liquidity-holdings"]],
  standalone: true,
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵInheritDefinitionFeature"], _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵStandaloneFeature"]],
  decls: 16,
  vars: 5,
  consts: () => {
    let i18n_0;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_5147646579214356822$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_LIQUIDITY_HOLDINGS_MY_LIQUIDITY_HOLDINGS_COMPONENT_TS_1 = goog.getMsg("\u5408\u7EA6\u6C60");
      i18n_0 = MSG_EXTERNAL_5147646579214356822$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_LIQUIDITY_HOLDINGS_MY_LIQUIDITY_HOLDINGS_COMPONENT_TS_1;
    } else {
      i18n_0 = "\u5408\u7EA6\u6C60";
    }
    let i18n_2;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_5823493453897646112$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_LIQUIDITY_HOLDINGS_MY_LIQUIDITY_HOLDINGS_COMPONENT_TS_3 = goog.getMsg("\u589E\u52A0\u6D41\u52A8\u6027");
      i18n_2 = MSG_EXTERNAL_5823493453897646112$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_LIQUIDITY_HOLDINGS_MY_LIQUIDITY_HOLDINGS_COMPONENT_TS_3;
    } else {
      i18n_2 = "\u589E\u52A0\u6D41\u52A8\u6027";
    }
    let i18n_4;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_2505460508015915263$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_LIQUIDITY_HOLDINGS_MY_LIQUIDITY_HOLDINGS_COMPONENT_TS_5 = goog.getMsg("\u6211\u7684\u6D41\u52A8\u6027\u6301\u4ED3");
      i18n_4 = MSG_EXTERNAL_2505460508015915263$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_LIQUIDITY_HOLDINGS_MY_LIQUIDITY_HOLDINGS_COMPONENT_TS_5;
    } else {
      i18n_4 = "\u6211\u7684\u6D41\u52A8\u6027\u6301\u4ED3";
    }
    let i18n_6;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_5446222978884148459$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_LIQUIDITY_HOLDINGS_MY_LIQUIDITY_HOLDINGS_COMPONENT_TS__7 = goog.getMsg("\u8BF7\u5148\u8FDE\u63A5\u94B1\u5305");
      i18n_6 = MSG_EXTERNAL_5446222978884148459$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_LIQUIDITY_HOLDINGS_MY_LIQUIDITY_HOLDINGS_COMPONENT_TS__7;
    } else {
      i18n_6 = "\u8BF7\u5148\u8FDE\u63A5\u94B1\u5305";
    }
    let i18n_8;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_7548953486615782691$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_LIQUIDITY_HOLDINGS_MY_LIQUIDITY_HOLDINGS_COMPONENT_TS____9 = goog.getMsg("\u6301\u6709:");
      i18n_8 = MSG_EXTERNAL_7548953486615782691$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_LIQUIDITY_HOLDINGS_MY_LIQUIDITY_HOLDINGS_COMPONENT_TS____9;
    } else {
      i18n_8 = "\u6301\u6709:";
    }
    let i18n_11;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_CURRENTLY_THERE_ARE_NO_LIQUIDITY_POSITIONS$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_LIQUIDITY_HOLDINGS_MY_LIQUIDITY_HOLDINGS_COMPONENT_TS___12 = goog.getMsg("Currently there are no liquidity positions");
      i18n_11 = MSG_EXTERNAL_CURRENTLY_THERE_ARE_NO_LIQUIDITY_POSITIONS$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_LIQUIDITY_HOLDINGS_MY_LIQUIDITY_HOLDINGS_COMPONENT_TS___12;
    } else {
      i18n_11 = "Currently there are no liquidity positions";
    }
    let i18n_13;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_LOADING$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_LIQUIDITY_HOLDINGS_MY_LIQUIDITY_HOLDINGS_COMPONENT_TS__14 = goog.getMsg("Loading");
      i18n_13 = MSG_EXTERNAL_LOADING$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_LIQUIDITY_HOLDINGS_MY_LIQUIDITY_HOLDINGS_COMPONENT_TS__14;
    } else {
      i18n_13 = "Loading";
    }
    return [[3, "hideHeader", "contentBackground", "ngStyle"], [1, "min-h-full", "px-4", "pt-4"], [1, "mb-6", "flex", "h-10", "items-center"], [1, "text-title-10", "text-[2rem]", "font-semibold"], i18n_0, [1, "bg-base-300", "rounded-2.5", "ml-auto", "flex", "h-8", "w-8", "items-center", "justify-center"], ["name", "icon-history", 1, "icon-5", "text-black-10", 3, "click"], [1, "bg-primary", "bnRippleButton", "mx-auto", "flex", "h-12", "w-56", "items-center", "justify-center", "rounded-full", 3, "click"], ["name", "icon-add", 1, "mr-2", "text-xl", "text-white"], [1, "text-lg", "text-white"], i18n_2, [1, "text-title-10", "mb-4", "mt-4", "text-base", "font-semibold"], i18n_4, ["class", "flex flex-col items-center justify-center"], [1, "flex", "flex-col", "items-center", "justify-center"], ["src", "./assets/images/connect-wallet.png", 1, "h-45", "w-60"], [1, "text-base-200"], i18n_6, ["wPullToRefresh", "", 3, "emitDistance", "maxDistance"], ["wPullToRefresh", "", 3, "emitDistance", "maxDistance", "pulled$"], [1, "text-title"], [1, "rounded-4", "_item-bg", "mb-4", "p-4", 3, "click"], [1, "flex", "items-center"], [3, "swapChainName", "swapCoinName"], [1, "ml-2"], [1, "text-black-10", "text-[1rem]", "font-semibold"], [1, "text-subtitle-2", "text-xs", "leading-3"], [1, "bg-text-input", "mx-4", "h-8", "w-[1px]"], [3, "iconSize", "swapChainName", "swapCoinName"], [1, "text-black-10", "text-base", "font-semibold", "leading-4"], ["class", "text-subtitle-2 text-xs leading-3"], ["name", "icon-chevron-right", 1, "text-primary", "ml-auto", "text-xl"], [1, "mt-4", "flex", "items-center"], [1, "text-subtitle", "text-sm"], i18n_8, [1, "ml-auto", "grid", "grid-cols-[auto,1fr]", "grid-rows-2", "items-center", "gap-x-1"], [1, "text-title-10", "text-right", "text-sm", "font-medium"], [3, "swapCoinName", "swapChainName"], ["class", "rounded-4 _item-bg mb-4 p-4"], [1, "text-base-gray", "absolute", "left-1/2", "top-1/2", "-translate-x-1/2", "-translate-y-1/2", "text-center", "text-sm"], ["src", "./assets/images/placeholder-1.png", 1, "w-[14.6875rem]"], i18n_11, [1, "absolute", "left-1/2", "top-1/2", "-translate-x-1/2", "-translate-y-1/2"], [1, "icon-6", 3, "showLoading"], [1, "text-sm"], i18n_13];
  },
  template: function MyLiquidityHoldingsPage_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](0, "common-page", 0)(1, "div", 1)(2, "div", 2)(3, "div", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵi18n"](4, 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](5, "button", 5)(6, "bs-icon", 6);
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵlistener"]("click", function MyLiquidityHoldingsPage_Template_bs_icon_click_6_listener() {
        return ctx.jumpRecordPage();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]()()();
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](7, "button", 7);
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵlistener"]("click", function MyLiquidityHoldingsPage_Template_button_click_7_listener() {
        return ctx.jumpAddLiquidity();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelement"](8, "bs-icon", 8);
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](9, "div", 9);
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵi18n"](10, 10);
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementStart"](11, "div", 11);
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵi18n"](12, 12);
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵtemplate"](13, MyLiquidityHoldingsPage_Conditional_13_Template, 4, 0, "div", 13)(14, MyLiquidityHoldingsPage_Conditional_14_Template, 2, 1)(15, MyLiquidityHoldingsPage_Conditional_15_Template, 4, 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵelementEnd"]()();
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵproperty"]("hideHeader", true)("contentBackground", "#fff")("ngStyle", _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵpureFunction0"](4, _c15));
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵadvance"](13);
      _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵconditional"](13, !ctx.connectedWallet ? 13 : ctx.init ? 14 : 15);
    }
  },
  dependencies: [_components_swap_token_chain_icon_swap_token_chain_icon_component__WEBPACK_IMPORTED_MODULE_9__.SwapTokenChainIconComponent, _pipes_chain_name_transfer_chain_name_transfer_pipe__WEBPACK_IMPORTED_MODULE_4__.ChainNameTransferPipe, _modules_page_module__WEBPACK_IMPORTED_MODULE_3__.CommonPageModule, _libs_bnf_components_pull_to_refresh_pull_to_refresh_directive__WEBPACK_IMPORTED_MODULE_11__.PullToRefreshDirective, _libs_bnf_components_pull_to_refresh_pull_to_refresh_spinner_component__WEBPACK_IMPORTED_MODULE_12__.PullToRefreshSpinnerComponent, _angular_common__WEBPACK_IMPORTED_MODULE_18__.NgStyle, _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_13__.CommonPageComponent, _components_icon_icon_component__WEBPACK_IMPORTED_MODULE_14__.IconComponent, _libs_bnf_components_loading_wrapper_loading_wrapper_component__WEBPACK_IMPORTED_MODULE_15__.LoadingWrapperComponent, _libs_bnf_pipes_amountFixed_amount_fixed_pipe__WEBPACK_IMPORTED_MODULE_16__.AmountFixedPipe, _angular_common__WEBPACK_IMPORTED_MODULE_18__.CommonModule, _components_token_with_chain_icon_token_with_chain_icon_component__WEBPACK_IMPORTED_MODULE_2__.TokenWithnChainIconComponent],
  styles: ["[_nghost-%COMP%]   ._item-bg[_ngcontent-%COMP%] {\n  background: linear-gradient(208deg, #ccadff 2%, #FAF1F6 22%, #ffffff 56%);\n  border-width: 1px;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL2FwcHMvYmZzd2FwL3NyYy9wYWdlcy9taW5lL3BhZ2VzL215LWxpcXVpZGl0eS1ob2xkaW5ncy9teS1saXF1aWRpdHktaG9sZGluZ3MuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQ0U7RUFDRSx5RUFBQTtFQUVBLGlCQUFBO0FBREoiLCJzb3VyY2VzQ29udGVudCI6WyI6aG9zdCB7XHJcbiAgLl9pdGVtLWJnIHtcclxuICAgIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCgyMDhkZWcsICNjY2FkZmYgMiUsICNGQUYxRjYgMjIlLCAjZmZmZmZmIDU2JSk7XHJcblxyXG4gICAgYm9yZGVyLXdpZHRoOiAxcHg7XHJcbiAgfVxyXG59XHJcbiJdLCJzb3VyY2VSb290IjoiIn0= */"],
  changeDetection: 0
});
(0,tslib__WEBPACK_IMPORTED_MODULE_19__.__decorate)([MyLiquidityHoldingsPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_19__.__metadata)("design:type", Object)], MyLiquidityHoldingsPage.prototype, "connectedWallet", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_19__.__decorate)([MyLiquidityHoldingsPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_19__.__metadata)("design:type", Object)], MyLiquidityHoldingsPage.prototype, "init", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_19__.__decorate)([MyLiquidityHoldingsPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_19__.__metadata)("design:type", Array)], MyLiquidityHoldingsPage.prototype, "dataList", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_19__.__decorate)([MyLiquidityHoldingsPage.OnResume(), (0,tslib__WEBPACK_IMPORTED_MODULE_19__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_19__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_19__.__metadata)("design:returntype", void 0)], MyLiquidityHoldingsPage.prototype, "onresume", null);
(0,tslib__WEBPACK_IMPORTED_MODULE_19__.__decorate)([MyLiquidityHoldingsPage.OnInit(), (0,tslib__WEBPACK_IMPORTED_MODULE_19__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_19__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_19__.__metadata)("design:returntype", void 0)], MyLiquidityHoldingsPage.prototype, "walletInit", null);
(0,tslib__WEBPACK_IMPORTED_MODULE_19__.__decorate)([MyLiquidityHoldingsPage.OnInit(), (0,tslib__WEBPACK_IMPORTED_MODULE_19__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_19__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_19__.__metadata)("design:returntype", Promise)], MyLiquidityHoldingsPage.prototype, "getDataList", null);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MyLiquidityHoldingsPage);

/***/ }),

/***/ 23377:
/*!*******************************************************************!*\
  !*** ./apps/bfswap/src/pipes/amount-format/amount-format.pipe.ts ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AmountFormatPipe: () => (/* binding */ AmountFormatPipe)
/* harmony export */ });
/* harmony import */ var bignumber_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! bignumber.js */ 61994);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 61039);
var _class;


/** 数值转换小数 */
class AmountFormatPipe {
  constructor() {
    this.transform = AmountFormatPipe.transform;
  }
  /** 转换函数 */
  static transform(value) {
    if (value === undefined) {
      return 0;
    }
    const v = new bignumber_js__WEBPACK_IMPORTED_MODULE_0__["default"](value).toFormat();
    return v;
  }
}
_class = AmountFormatPipe;
_class.ɵfac = function AmountFormatPipe_Factory(t) {
  return new (t || _class)();
};
_class.ɵpipe = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefinePipe"]({
  name: "amountFormat",
  type: _class,
  pure: true,
  standalone: true
});

/***/ }),

/***/ 37514:
/*!*******************************************************************************!*\
  !*** ./apps/bfswap/src/pipes/chain-name-transfer/chain-name-transfer.pipe.ts ***!
  \*******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ChainNameTransferPipe: () => (/* binding */ ChainNameTransferPipe)
/* harmony export */ });
/* harmony import */ var _services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ~services/wallet/wallet.helper */ 84813);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 61039);
var _class;


/** 链名换小写 */
class ChainNameTransferPipe {
  constructor() {
    this.transform = ChainNameTransferPipe.transform;
  }
  /** 转换函数 */
  static transform(chainName) {
    if (chainName === undefined) return '';
    return _services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_0__.NODE_CHAIN_NAME_TRANSFER[chainName];
  }
}
_class = ChainNameTransferPipe;
_class.ɵfac = function ChainNameTransferPipe_Factory(t) {
  return new (t || _class)();
};
_class.ɵpipe = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefinePipe"]({
  name: "chainNameTransfer",
  type: _class,
  pure: true,
  standalone: true
});

/***/ }),

/***/ 34913:
/*!***************************************************************************!*\
  !*** ./apps/bfswap/src/services/liquidity-user/liquidity-user.service.ts ***!
  \***************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   LiquidityUserService: () => (/* binding */ LiquidityUserService)
/* harmony export */ });
/* harmony import */ var D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 52542);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 61039);
/* harmony import */ var _services_bs_fetch_bs_fetch_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ~services/bs-fetch/bs-fetch.service */ 92925);
/* harmony import */ var _bnqkl_framework_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @bnqkl/framework/core */ 63563);

var _class;




/** 池子相关接口 */
class LiquidityUserService {
  constructor() {
    /** 日志 */
    this.console = (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.inject)(_bnqkl_framework_core__WEBPACK_IMPORTED_MODULE_2__.LoggerService).createLoggerForService(this, 'liquidity-user-service');
    /** fetch服务 */
    this.fetch = (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.inject)(_services_bs_fetch_bs_fetch_service__WEBPACK_IMPORTED_MODULE_1__.SwapFetch);
    /** 后端接口 */
    this.SERVER_API = {
      /** 获取用户持仓列表 POST */
      getLiquidityUserPositionList: this.fetch.APP_URL('/bnqklswap/liquidity/user/position/list'),
      /** 获取用户资产列表 POST */
      getLiquidityUserAssetsList: this.fetch.APP_URL('/bnqklswap/liquidity/user/assets/list'),
      /** 获取用户流动性持仓 */
      getUserLiquidityHolding: this.fetch.APP_URL('/bnqklswap/liquidity/user/position/list'),
      /** 获取用户持仓详情 */
      getUserPositionDetail: this.fetch.APP_URL('/bnqklswap/liquidity/user/position/details'),
      /** 获取用户持仓比例 */
      getUserPositionPercent: this.fetch.APP_URL('/bnqklswap/liquidity/user/position/percent'),
      /** 获取用户流动性持仓冻结数量 */
      getUserLiquidityLocked: this.fetch.APP_URL('/bnqklswap/liquidity/user/position/locked'),
      /** 获取用户流动性持仓冻结列表 */
      getUserLiquidityLockedList: this.fetch.APP_URL('/bnqklswap/liquidity/user/position/locked/list')
    };
  }
  /** 获取用户锁仓量列表 */
  getUserLiquidityLockedList(options) {
    var _this = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      try {
        return _this.fetch.post(_this.SERVER_API.getUserLiquidityLockedList, options);
        // 默认数据
      } catch (error) {
        _this.console.log('getUserLiquidityLockedList', error);
        return;
      }
    })();
  }
  /** 获取用户持仓详情 */
  getUserPositionDetail(options) {
    try {
      return this.fetch.post(this.SERVER_API.getUserPositionDetail, options);
      // 默认数据
    } catch (error) {
      this.console.log('getUserPositionDetail', error);
      return;
    }
  }
  /** 获取用户锁仓量 */
  getUserLiquidityLocked(options) {
    var _this2 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      try {
        return _this2.fetch.post(_this2.SERVER_API.getUserLiquidityLocked, options);
        // 默认数据
      } catch (error) {
        _this2.console.log('getUserLiquidityLocked', error);
        return;
      }
    })();
  }
  /** 获取用户持仓比例 */
  getUserPositionPercent(options) {
    try {
      return this.fetch.post(this.SERVER_API.getUserPositionPercent, options);
      // 默认数据
    } catch (error) {
      this.console.log('getUserPositionPercent', error);
      return;
    }
  }
  /** 获取用户持仓列表 */
  getLiquidityUserPostionList(options) {
    try {
      return this.fetch.post(this.SERVER_API.getLiquidityUserPositionList, options);
      // 默认数据
    } catch (error) {
      this.console.log('getLiquidityUserPostionList', error);
      return;
    }
  }
  /** 获取用户资产列表 */
  getLiquidityUserAssetsList(options) {
    try {
      return this.fetch.post(this.SERVER_API.getLiquidityUserAssetsList, options);
      // 默认数据
    } catch (error) {
      this.console.log('getLiquidityUserPostionList', error);
      return;
    }
  }
  /** 获取用户流动性持仓 */
  getUserLiquidityHolding(options) {
    var _this3 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      try {
        return _this3.fetch.post(_this3.SERVER_API.getUserLiquidityHolding, options);
        // 默认数据
      } catch (error) {
        _this3.console.log('getUserLiquidityHolding', error);
        return;
      }
    })();
  }
}
_class = LiquidityUserService;
_class.ɵfac = function LiquidityUserService_Factory(t) {
  return new (t || _class)();
};
_class.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineInjectable"]({
  token: _class,
  factory: _class.ɵfac,
  providedIn: 'root'
});

/***/ })

}]);
//# sourceMappingURL=default-apps_bfswap_src_pages_mine_pages_my-assets_my-assets_component_ts-apps_bfswap_src_pag-1528df.js.map