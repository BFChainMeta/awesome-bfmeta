"use strict";
(self["webpackChunkbfswap"] = self["webpackChunkbfswap"] || []).push([["default-apps_bfswap_src_components_connect-wallet-panel_connect-wallet-penel_component_ts"],{

/***/ 9218:
/*!**************************************************************************************!*\
  !*** ./apps/bfswap/src/components/connect-wallet-panel/connect-wallet-panel.type.ts ***!
  \**************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   CONNECT_TYPE: () => (/* binding */ CONNECT_TYPE)
/* harmony export */ });
var CONNECT_TYPE;
(function (CONNECT_TYPE) {
  CONNECT_TYPE[CONNECT_TYPE["SWITCH_WALLET"] = 0] = "SWITCH_WALLET";
  CONNECT_TYPE[CONNECT_TYPE["CONNECT_WALLET"] = 1] = "CONNECT_WALLET";
})(CONNECT_TYPE || (CONNECT_TYPE = {}));

/***/ }),

/***/ 43551:
/*!*******************************************************************************************!*\
  !*** ./apps/bfswap/src/components/connect-wallet-panel/connect-wallet-penel.component.ts ***!
  \*******************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ConnectWalletPanelPage: () => (/* binding */ ConnectWalletPanelPage),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 52542);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! tslib */ 90505);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/core */ 61039);
/* harmony import */ var _modules_page_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ~modules/page.module */ 16381);
/* harmony import */ var _connect_wallet_panel_type__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./connect-wallet-panel.type */ 9218);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/common */ 6729);
/* harmony import */ var _services_wallet_wallet_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ~services/wallet/wallet.service */ 54275);
/* harmony import */ var _services_wallet_wallet_type__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ~services/wallet/wallet.type */ 19348);
/* harmony import */ var _bnqkl_framework_plugins__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @bnqkl/framework/plugins */ 43990);
/* harmony import */ var _environments_index__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ~environments/index */ 11295);
/* harmony import */ var _plaoc_plugins__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @plaoc/plugins */ 53396);
/* harmony import */ var _bnqkl_util_web_extends_promise__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @bnqkl/util-web/extends-promise */ 87778);
/* harmony import */ var _plaoc_is_dweb__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @plaoc/is-dweb */ 94035);
/* harmony import */ var _libs_bnf_components_ripple_button_ripple_button_directive__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../../../../libs/bnf/components/ripple-button/ripple-button.directive */ 16505);
/* harmony import */ var _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../../../../libs/bnf/modules/page/common-page/common-page.component */ 62052);
/* harmony import */ var _icon_icon_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../icon/icon.component */ 18840);

var _class;

















function ConnectWalletPanelPage_ng_container_3_button_7_Template(rf, ctx) {
  if (rf & 1) {
    const _r8 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "button", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("click", function ConnectWalletPanelPage_ng_container_3_button_7_Template_button_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r8);
      const wallet_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"]().$implicit;
      const ctx_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵresetView"](ctx_r6.connectWallet(wallet_r1));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵi18n"](1, 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
  }
}
function ConnectWalletPanelPage_ng_container_3_button_8_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "button", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵi18n"](1, 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
  }
}
function ConnectWalletPanelPage_ng_container_3_button_9_Template(rf, ctx) {
  if (rf & 1) {
    const _r11 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "button", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("click", function ConnectWalletPanelPage_ng_container_3_button_9_Template_button_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r11);
      const wallet_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"]().$implicit;
      const ctx_r9 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵresetView"](ctx_r9.gotoDownLoad(wallet_r1));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵi18n"](1, 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
  }
}
function ConnectWalletPanelPage_ng_container_3_span_10_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](0, "span", 22);
  }
}
function ConnectWalletPanelPage_ng_container_3_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](1, "div", 7)(2, "div", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](3, "bs-icon", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](4, "span", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](6, "div", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](7, ConnectWalletPanelPage_ng_container_3_button_7_Template, 2, 0, "button", 12)(8, ConnectWalletPanelPage_ng_container_3_button_8_Template, 2, 0, "button", 13)(9, ConnectWalletPanelPage_ng_container_3_button_9_Template, 2, 0, "button", 14)(10, ConnectWalletPanelPage_ng_container_3_span_10_Template, 1, 0, "span", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const wallet_r1 = ctx.$implicit;
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("name", wallet_r1.iconName);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtextInterpolate"](wallet_r1.name);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", wallet_r1.status === ctx_r0.PRESET_WALLET_STATUS.UNCONNECTED || wallet_r1.status === ctx_r0.PRESET_WALLET_STATUS.CONNECTED);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", wallet_r1.status === ctx_r0.PRESET_WALLET_STATUS.CONNECTING);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", wallet_r1.status === ctx_r0.PRESET_WALLET_STATUS.UNDOWNLOAD);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", wallet_r1.status === ctx_r0.PRESET_WALLET_STATUS.LOADING);
  }
}
/**
 * 连接钱包的页面
 */
class ConnectWalletPanelPage extends _modules_page_module__WEBPACK_IMPORTED_MODULE_1__.CommonPageBase {
  constructor() {
    super(...arguments);
    /** 钱包服务 */
    this.walletService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_13__.inject)(_services_wallet_wallet_service__WEBPACK_IMPORTED_MODULE_3__.WalletService);
    /** 返回类型 */
    this.returnValue$ = new _modules_page_module__WEBPACK_IMPORTED_MODULE_1__.PageReturnValue();
    /** 类型 */
    this.CONNECT_TYPE = _connect_wallet_panel_type__WEBPACK_IMPORTED_MODULE_2__.CONNECT_TYPE;
    /** 可连接的钱包状态 */
    this.PRESET_WALLET_STATUS = _services_wallet_wallet_type__WEBPACK_IMPORTED_MODULE_4__.PRESET_WALLET_STATUS;
    /** 可连接的钱包状态 */
    this.presetWallets = [];
    /** 标题 */
    this.title = '';
    /** 关闭面板promise */
    this.closePannelPromise = new _bnqkl_util_web_extends_promise__WEBPACK_IMPORTED_MODULE_8__.PromiseOut();
  }
  /** 初始化 */
  dataInit() {
    if (this.connectType === _connect_wallet_panel_type__WEBPACK_IMPORTED_MODULE_2__.CONNECT_TYPE.SWITCH_WALLET) {
      this.title = "Switch wallet";
    } else if (this.connectType === _connect_wallet_panel_type__WEBPACK_IMPORTED_MODULE_2__.CONNECT_TYPE.CONNECT_WALLET) {
      this.title = "Connect wallet";
    }
  }
  /** 初始化 */
  destroy() {
    this.closePannelPromise.resolve({
      abort: true
    });
  }
  /** 连接/切换钱包 */
  connectWallet(wallet) {
    var _this = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      wallet.status = _services_wallet_wallet_type__WEBPACK_IMPORTED_MODULE_4__.PRESET_WALLET_STATUS.CONNECTING;
      const closePromise = _this.closePannelPromise.promise;
      const connectedWalletResult = yield _this.walletService.connectWallet(wallet, closePromise);
      if (connectedWalletResult) {
        if (connectedWalletResult.abort) {
          _bnqkl_framework_plugins__WEBPACK_IMPORTED_MODULE_5__.Toast.show('连接已取消');
          return;
        } else {
          if (_environments_index__WEBPACK_IMPORTED_MODULE_6__.environment.DWEB_APP) {
            _plaoc_plugins__WEBPACK_IMPORTED_MODULE_7__.windowPlugin.focusWindow();
          }
          _this.returnValue$.return(connectedWalletResult);
        }
        _bnqkl_framework_plugins__WEBPACK_IMPORTED_MODULE_5__.Toast.show('连接成功');
      } else {
        if (_environments_index__WEBPACK_IMPORTED_MODULE_6__.environment.DWEB_APP) {
          _plaoc_plugins__WEBPACK_IMPORTED_MODULE_7__.windowPlugin.focusWindow();
        }
        _bnqkl_framework_plugins__WEBPACK_IMPORTED_MODULE_5__.Toast.show('连接失败');
      }
      yield (0,_bnqkl_util_web_extends_promise__WEBPACK_IMPORTED_MODULE_8__.sleep)(300);
      _this.nav.back();
    })();
  }
  /** 关闭弹窗 */
  closePannel() {
    this.nav.back();
  }
  /** 前往dweb下应用商城下载应用 */
  // gotoDownLoad = $singleton(async () => {
  //   window.open(environment.production ? 'https://dwebdapp.com' : 'https://test.dwebdapp.com', '_blank');
  //   return;
  // });
  gotoDownLoad(wallet) {
    var _this2 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      /** 下载连接已变更，暂时不使用连接直接安装而是跳转到应用下载 */
      wallet.status = _services_wallet_wallet_type__WEBPACK_IMPORTED_MODULE_4__.PRESET_WALLET_STATUS.LOADING;
      const url = new URL(_environments_index__WEBPACK_IMPORTED_MODULE_6__.environment.DWEB_APP_LIST);
      url.searchParams.append('time', String(Date.now()));
      const result = yield fetch(url.toString()).then(res => res.json()).catch(err => {
        _this2.console.log('获取applist', err);
        return;
      });
      if (result) {
        const baseUrl = result.base_config.base_url + result.base_config.app_path;
        const walletName = wallet.name.toLowerCase();
        const targetPath = result.applist[walletName][`dwebTarget${(0,_plaoc_is_dweb__WEBPACK_IMPORTED_MODULE_9__.dwebTarget)()}`];
        const downloadUrl = `${baseUrl}/${walletName}/${targetPath}/metadata.json`;
        _plaoc_plugins__WEBPACK_IMPORTED_MODULE_7__.updateControllerPlugin.download(downloadUrl);
      } else {
        _bnqkl_framework_plugins__WEBPACK_IMPORTED_MODULE_5__.Browser.open({
          url: _environments_index__WEBPACK_IMPORTED_MODULE_6__.environment.production ? 'https://dwebdapp.com' : 'https://test.dwebdapp.com'
        });
      }
      wallet.status = _services_wallet_wallet_type__WEBPACK_IMPORTED_MODULE_4__.PRESET_WALLET_STATUS.UNDOWNLOAD;
      return _this2.nav.back();
    })();
  }
}
_class = ConnectWalletPanelPage;
_class.ɵfac = /*@__PURE__*/(() => {
  let ɵConnectWalletPanelPage_BaseFactory;
  return function ConnectWalletPanelPage_Factory(t) {
    return (ɵConnectWalletPanelPage_BaseFactory || (ɵConnectWalletPanelPage_BaseFactory = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵgetInheritedFactory"](_class)))(t || _class);
  };
})();
_class.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdefineComponent"]({
  type: _class,
  selectors: [["bs-connect-wallet-panel-page"]],
  inputs: {
    connectType: "connectType",
    presetWallets: "presetWallets"
  },
  outputs: {
    returnValue$: "returnValue$"
  },
  standalone: true,
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵInheritDefinitionFeature"], _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵStandaloneFeature"]],
  decls: 7,
  vars: 9,
  consts: () => {
    let i18n_0;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_YOU_SHOULD_AGREE_IF_YOU_CONNECT_WALLET$$APPS_BFSWAP_SRC_COMPONENTS_CONNECT_WALLET_PANEL_CONNECT_WALLET_PENEL_COMPONENT_TS_1 = goog.getMsg("If you connect to the wallet, you have agreed to the {$startTagSpan}BTCSwap user agreement{$closeTagSpan}", {
        "closeTagSpan": "\uFFFD/#6\uFFFD",
        "startTagSpan": "\uFFFD#6\uFFFD"
      }, {
        original_code: {
          "closeTagSpan": "</span>",
          "startTagSpan": "<span (click)=\"nav.routeTo('/mine/user-agreement')\" class=\"text-primary-2 ml-1\">"
        }
      });
      i18n_0 = MSG_EXTERNAL_YOU_SHOULD_AGREE_IF_YOU_CONNECT_WALLET$$APPS_BFSWAP_SRC_COMPONENTS_CONNECT_WALLET_PANEL_CONNECT_WALLET_PENEL_COMPONENT_TS_1;
    } else {
      i18n_0 = "If you connect to the wallet, you have agreed to the user agreement";
    }
    let i18n_2;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_CONNECT$$APPS_BFSWAP_SRC_COMPONENTS_CONNECT_WALLET_PANEL_CONNECT_WALLET_PENEL_COMPONENT_TS___3 = goog.getMsg(" Connect ");
      i18n_2 = MSG_EXTERNAL_CONNECT$$APPS_BFSWAP_SRC_COMPONENTS_CONNECT_WALLET_PANEL_CONNECT_WALLET_PENEL_COMPONENT_TS___3;
    } else {
      i18n_2 = " Connect ";
    }
    let i18n_4;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_CONNECTING$$APPS_BFSWAP_SRC_COMPONENTS_CONNECT_WALLET_PANEL_CONNECT_WALLET_PENEL_COMPONENT_TS___5 = goog.getMsg(" Connecting ");
      i18n_4 = MSG_EXTERNAL_CONNECTING$$APPS_BFSWAP_SRC_COMPONENTS_CONNECT_WALLET_PANEL_CONNECT_WALLET_PENEL_COMPONENT_TS___5;
    } else {
      i18n_4 = " Connecting ";
    }
    let i18n_6;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_DOWNLOAD$$APPS_BFSWAP_SRC_COMPONENTS_CONNECT_WALLET_PANEL_CONNECT_WALLET_PENEL_COMPONENT_TS___7 = goog.getMsg(" Go to download ");
      i18n_6 = MSG_EXTERNAL_DOWNLOAD$$APPS_BFSWAP_SRC_COMPONENTS_CONNECT_WALLET_PANEL_CONNECT_WALLET_PENEL_COMPONENT_TS___7;
    } else {
      i18n_6 = " Go to download ";
    }
    return [[3, "headerTitle", "hideBackButton", "contentBackground", "contentSafeArea", "titleClass", "contentClass", "headerClass"], ["endMenu", "", "bnRippleButton", "", 1, "icon-8", 3, "mode", "click"], ["name", "icon-popup-close", 1, "text-[1.75rem]"], [4, "ngFor", "ngForOf"], [1, "text-base-200", "mx-auto", "block", "text-center", "my-4"], i18n_0, [1, "text-primary-2", "ml-1", 3, "click"], [1, "rounded-4", "w-full", "bg-base-300", "my-2", "flex", "h-[4.375rem]", "items-center", "justify-between", "px-4"], [1, "flex", "h-9", "items-center"], [1, "text-4xl", 3, "name"], [1, "mx-1", "text-base", "font-semibold"], [1, "w-26"], ["class", "duibs-btn duibs-btn-primary min-h-9 w-26 h-9 rounded-full text-base font-semibold normal-case text-white", 3, "click", 4, "ngIf"], ["class", "bg-base-200 min-h-9 w-26 h-9 rounded-full text-center text-base font-semibold normal-case text-white", 4, "ngIf"], ["class", "duibs-btn duibs-btn-primary duibs-btn-outline min-h-9 w-26 h-9 rounded-full text-base font-semibold normal-case text-white", 3, "click", 4, "ngIf"], ["class", "duibs-loading duibs-loading-dots duibs-loading-md text-primary mx-auto block", 4, "ngIf"], [1, "duibs-btn", "duibs-btn-primary", "min-h-9", "w-26", "h-9", "rounded-full", "text-base", "font-semibold", "normal-case", "text-white", 3, "click"], i18n_2, [1, "bg-base-200", "min-h-9", "w-26", "h-9", "rounded-full", "text-center", "text-base", "font-semibold", "normal-case", "text-white"], i18n_4, [1, "duibs-btn", "duibs-btn-primary", "duibs-btn-outline", "min-h-9", "w-26", "h-9", "rounded-full", "text-base", "font-semibold", "normal-case", "text-white", 3, "click"], i18n_6, [1, "duibs-loading", "duibs-loading-dots", "duibs-loading-md", "text-primary", "mx-auto", "block"]];
  },
  template: function ConnectWalletPanelPage_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "common-page", 0)(1, "button", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("click", function ConnectWalletPanelPage_Template_button_click_1_listener() {
        return ctx.closePannel();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](2, "bs-icon", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](3, ConnectWalletPanelPage_ng_container_3_Template, 11, 6, "ng-container", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](4, "span", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵi18nStart"](5, 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](6, "span", 6);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("click", function ConnectWalletPanelPage_Template_span_click_6_listener() {
        return ctx.nav.routeTo("/mine/user-agreement");
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵi18nEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("headerTitle", ctx.title)("hideBackButton", true)("contentBackground", "white")("contentSafeArea", true)("titleClass", "text-lg")("contentClass", "px-4")("headerClass", "pt-3 pb-3");
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("mode", "icon");
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngForOf", ctx.presetWallets);
    }
  },
  dependencies: [_modules_page_module__WEBPACK_IMPORTED_MODULE_1__.CommonPageModule, _libs_bnf_components_ripple_button_ripple_button_directive__WEBPACK_IMPORTED_MODULE_10__.RippleButtonDirective, _angular_common__WEBPACK_IMPORTED_MODULE_14__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_14__.NgIf, _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_11__.CommonPageComponent, _icon_icon_component__WEBPACK_IMPORTED_MODULE_12__.IconComponent, _angular_common__WEBPACK_IMPORTED_MODULE_14__.CommonModule],
  styles: [".mat-bottom-sheet-container {\n  border-top-left-radius: 1.25rem !important;\n  border-top-right-radius: 1.25rem !important;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL2FwcHMvYmZzd2FwL3NyYy9jb21wb25lbnRzL2Nvbm5lY3Qtd2FsbGV0LXBhbmVsL2Nvbm5lY3Qtd2FsbGV0LXBhbmVsLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksMENBQUE7RUFDQSwyQ0FBQTtBQUNKIiwic291cmNlc0NvbnRlbnQiOlsiOjpuZy1kZWVwIC5tYXQtYm90dG9tLXNoZWV0LWNvbnRhaW5lciB7XHJcbiAgICBib3JkZXItdG9wLWxlZnQtcmFkaXVzOiAxLjI1cmVtICFpbXBvcnRhbnQ7XHJcbiAgICBib3JkZXItdG9wLXJpZ2h0LXJhZGl1czogMS4yNXJlbSAhaW1wb3J0YW50O1xyXG59Il0sInNvdXJjZVJvb3QiOiIifQ== */"],
  changeDetection: 0
});
(0,tslib__WEBPACK_IMPORTED_MODULE_15__.__decorate)([ConnectWalletPanelPage.States(1), (0,tslib__WEBPACK_IMPORTED_MODULE_15__.__metadata)("design:type", Array)], ConnectWalletPanelPage.prototype, "presetWallets", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_15__.__decorate)([ConnectWalletPanelPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_15__.__metadata)("design:type", Object)], ConnectWalletPanelPage.prototype, "title", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_15__.__decorate)([ConnectWalletPanelPage.OnInit(), (0,tslib__WEBPACK_IMPORTED_MODULE_15__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_15__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_15__.__metadata)("design:returntype", void 0)], ConnectWalletPanelPage.prototype, "dataInit", null);
(0,tslib__WEBPACK_IMPORTED_MODULE_15__.__decorate)([ConnectWalletPanelPage.OnDestroy(), (0,tslib__WEBPACK_IMPORTED_MODULE_15__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_15__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_15__.__metadata)("design:returntype", void 0)], ConnectWalletPanelPage.prototype, "destroy", null);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ConnectWalletPanelPage);

/***/ }),

/***/ 94035:
/*!*****************************************************************************************!*\
  !*** ./node_modules/.pnpm/@plaoc+is-dweb@0.0.8/node_modules/@plaoc/is-dweb/esm/main.js ***!
  \*****************************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   dwebTarget: () => (/* binding */ dwebTarget),
/* harmony export */   isDweb: () => (/* binding */ isDweb)
/* harmony export */ });
const isDweb = () => {
  const isDweb = self.navigator.userAgent.includes("Dweb");
  // @ts-ignore
  const isPlaoc = self.__native_close_watcher_kit__ !== void 0;
  if (isDweb || isPlaoc) {
    return true;
  }
  const userAgentData = self.navigator.userAgentData;
  if (!userAgentData) {
    return false;
  }
  const brands = userAgentData.brands.filter(value => {
    return value.brand === "DwebBrowser";
  });
  return Array.isArray(brands) && brands.length > 0;
};
const dwebTarget = () => {
  if (isDweb()) {
    const userAgentData = self.navigator.userAgentData;
    if (!userAgentData) {
      return 1.0;
    }
    const brands = userAgentData.brands.filter(value => {
      return value.brand === "jmm.browser.dweb";
    });
    if (Array.isArray(brands) && brands.length > 0) {
      return parseFloat(brands[0].version);
    }
  }
  return 1.0;
};

/***/ })

}]);
//# sourceMappingURL=default-apps_bfswap_src_components_connect-wallet-panel_connect-wallet-penel_component_ts.js.map