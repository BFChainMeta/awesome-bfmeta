"use strict";
(self["webpackChunkbfswap"] = self["webpackChunkbfswap"] || []).push([["apps_bfswap_src_assets_wallet-util_bip32-8a479812_mjs"],{

/***/ 82485:
/*!***************************************************************!*\
  !*** ./apps/bfswap/src/assets/wallet-util/bip32-8a479812.mjs ***!
  \***************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   BIP32Factory: () => (/* binding */ p)
/* harmony export */ });
/* harmony import */ var _index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./index-d96f2042.mjs */ 99449);
/* harmony import */ var _sha512_7b87e5c4_mjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./sha512-7b87e5c4.mjs */ 15574);
/* harmony import */ var _hmac_43177c9b_mjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./hmac-43177c9b.mjs */ 29570);
/* harmony import */ var _index_4062991a_mjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./index-4062991a.mjs */ 22269);
/* harmony import */ var _typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./typeforce-a57e57b8.mjs */ 75473);
/* harmony import */ var _index_02f15a92_mjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./index-02f15a92.mjs */ 2465);
/* harmony import */ var _crypto_4198e1c6_mjs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./crypto-4198e1c6.mjs */ 99920);
/* harmony import */ var _WASMInterface_4e8d37b8_mjs__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./WASMInterface-4e8d37b8.mjs */ 18047);
/* harmony import */ var _sha256_d88873b6_mjs__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./sha256-d88873b6.mjs */ 98080);
/* harmony import */ var _ripemd160_fdc485e7_mjs__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./ripemd160-fdc485e7.mjs */ 10918);










function h(i, n) {
  return _index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_0__.B.from((0,_hmac_43177c9b_mjs__WEBPACK_IMPORTED_MODULE_2__.c)((0,_sha512_7b87e5c4_mjs__WEBPACK_IMPORTED_MODULE_1__.c)(), i).update(n).digest());
}
function p(r) {
  const t = _typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_4__.t.BufferN(32),
    p = _typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_4__.t.compile({
      wif: _typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_4__.t.UInt8,
      bip32: {
        public: _typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_4__.t.UInt32,
        private: _typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_4__.t.UInt32
      }
    }),
    a = {
      messagePrefix: "Bitcoin Signed Message:\n",
      bech32: "bc",
      bip32: {
        public: 76067358,
        private: 76066276
      },
      pubKeyHash: 0,
      scriptHash: 5,
      wif: 128
    },
    c = 2147483648,
    u = Math.pow(2, 31) - 1;
  function d(e) {
    return _typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_4__.t.String(e) && null !== e.match(/^(m\/)?(\d+'?\/)*\d+'?$/);
  }
  function f(e) {
    return _typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_4__.t.UInt32(e) && e <= u;
  }
  class l {
    constructor(e, r) {
      this.__D = e, this.__Q = r, this.lowR = !1;
    }
    get publicKey() {
      return void 0 === this.__Q && (this.__Q = _index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_0__.B.from(r.pointFromScalar(this.__D, !0))), this.__Q;
    }
    get privateKey() {
      return this.__D;
    }
    sign(t, i) {
      if (!this.privateKey) throw new Error("Missing private key");
      if (void 0 === i && (i = this.lowR), !1 === i) return _index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_0__.B.from(r.sign(t, this.privateKey));
      {
        let i = _index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_0__.B.from(r.sign(t, this.privateKey));
        const n = _index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_0__.B.alloc(32, 0);
        let s = 0;
        for (; i[0] > 127;) s++, n.writeUIntLE(s, 0, 6), i = _index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_0__.B.from(r.sign(t, this.privateKey, n));
        return i;
      }
    }
    signSchnorr(t) {
      if (!this.privateKey) throw new Error("Missing private key");
      if (!r.signSchnorr) throw new Error("signSchnorr not supported by ecc library");
      return _index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_0__.B.from(r.signSchnorr(t, this.privateKey));
    }
    verify(e, t) {
      return r.verify(e, this.publicKey, t);
    }
    verifySchnorr(e, t) {
      if (!r.verifySchnorr) throw new Error("verifySchnorr not supported by ecc library");
      return r.verifySchnorr(e, this.publicKey.subarray(1, 33), t);
    }
  }
  class y extends l {
    constructor(e, r, t, i, s = 0, o = 0, h = 0) {
      super(e, r), this.chainCode = t, this.network = i, this.__DEPTH = s, this.__INDEX = o, this.__PARENT_FINGERPRINT = h, (0,_typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_4__.t)(p, i);
    }
    get depth() {
      return this.__DEPTH;
    }
    get index() {
      return this.__INDEX;
    }
    get parentFingerprint() {
      return this.__PARENT_FINGERPRINT;
    }
    get identifier() {
      return (0,_crypto_4198e1c6_mjs__WEBPACK_IMPORTED_MODULE_6__.h)(this.publicKey);
    }
    get fingerprint() {
      return this.identifier.slice(0, 4);
    }
    get compressed() {
      return !0;
    }
    isNeutered() {
      return void 0 === this.__D;
    }
    neutered() {
      return m(this.publicKey, this.chainCode, this.network, this.depth, this.index, this.parentFingerprint);
    }
    toBase58() {
      const r = this.network,
        t = this.isNeutered() ? r.bip32.public : r.bip32.private,
        n = _index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_0__.B.allocUnsafe(78);
      return n.writeUInt32BE(t, 0), n.writeUInt8(this.depth, 4), n.writeUInt32BE(this.parentFingerprint, 5), n.writeUInt32BE(this.index, 9), this.chainCode.copy(n, 13), this.isNeutered() ? this.publicKey.copy(n, 45) : (n.writeUInt8(0, 45), this.privateKey.copy(n, 46)), _index_4062991a_mjs__WEBPACK_IMPORTED_MODULE_3__.b.encode(n);
    }
    toWIF() {
      if (!this.privateKey) throw new TypeError("Missing private key");
      return (0,_index_02f15a92_mjs__WEBPACK_IMPORTED_MODULE_5__.e)(this.network.wif, this.privateKey, !0);
    }
    derive(t) {
      (0,_typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_4__.t)(_typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_4__.t.UInt32, t);
      const i = t >= c,
        s = _index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_0__.B.allocUnsafe(37);
      if (i) {
        if (this.isNeutered()) throw new TypeError("Missing private key for hardened child key");
        s[0] = 0, this.privateKey.copy(s, 1), s.writeUInt32BE(t, 33);
      } else this.publicKey.copy(s, 0), s.writeUInt32BE(t, 33);
      const o = h(this.chainCode, s),
        p = o.slice(0, 32),
        a = o.slice(32);
      if (!r.isPrivate(p)) return this.derive(t + 1);
      let u;
      if (this.isNeutered()) {
        const i = _index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_0__.B.from(r.pointAddScalar(this.publicKey, p, !0));
        if (null === i) return this.derive(t + 1);
        u = m(i, a, this.network, this.depth + 1, t, this.fingerprint.readUInt32BE(0));
      } else {
        const i = _index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_0__.B.from(r.privateAdd(this.privateKey, p));
        if (null == i) return this.derive(t + 1);
        u = v(i, a, this.network, this.depth + 1, t, this.fingerprint.readUInt32BE(0));
      }
      return u;
    }
    deriveHardened(e) {
      return (0,_typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_4__.t)(f, e), this.derive(e + c);
    }
    derivePath(e) {
      (0,_typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_4__.t)(d, e);
      let r = e.split("/");
      if ("m" === r[0]) {
        if (this.parentFingerprint) throw new TypeError("Expected master, got child");
        r = r.slice(1);
      }
      return r.reduce((e, r) => {
        let t;
        return "'" === r.slice(-1) ? (t = parseInt(r.slice(0, -1), 10), e.deriveHardened(t)) : (t = parseInt(r, 10), e.derive(t));
      }, this);
    }
    tweak(e) {
      return this.privateKey ? this.tweakFromPrivateKey(e) : this.tweakFromPublicKey(e);
    }
    tweakFromPublicKey(t) {
      const i = 32 === (n = this.publicKey).length ? n : n.slice(1, 33);
      var n;
      const s = r.xOnlyPointAddTweak(i, t);
      if (!s || null === s.xOnlyPubkey) throw new Error("Cannot tweak public key!");
      const o = _index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_0__.B.from([0 === s.parity ? 2 : 3]),
        h = _index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_0__.B.concat([o, s.xOnlyPubkey]);
      return new l(void 0, h);
    }
    tweakFromPrivateKey(t) {
      const i = 3 === this.publicKey[0] || 4 === this.publicKey[0] && 1 == (1 & this.publicKey[64]) ? r.privateNegate(this.privateKey) : this.privateKey,
        n = r.privateAdd(i, t);
      if (!n) throw new Error("Invalid tweaked private key!");
      return new l(_index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_0__.B.from(n), void 0);
    }
  }
  function w(e, r, t) {
    return v(e, r, t);
  }
  function v(e, i, s, o, h, p) {
    if ((0,_typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_4__.t)({
      privateKey: t,
      chainCode: t
    }, {
      privateKey: e,
      chainCode: i
    }), s = s || a, !r.isPrivate(e)) throw new TypeError("Private key not in range [1, n)");
    return new y(e, void 0, i, s, o, h, p);
  }
  function m(e, i, s, o, h, p) {
    if ((0,_typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_4__.t)({
      publicKey: _typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_4__.t.BufferN(33),
      chainCode: t
    }, {
      publicKey: e,
      chainCode: i
    }), s = s || a, !r.isPoint(e)) throw new TypeError("Point is not on the curve");
    return new y(void 0, e, i, s, o, h, p);
  }
  return {
    fromSeed: function (r, t) {
      if ((0,_typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_4__.t)(_typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_4__.t.Buffer, r), r.length < 16) throw new TypeError("Seed should be at least 128 bits");
      if (r.length > 64) throw new TypeError("Seed should be at most 512 bits");
      t = t || a;
      const i = h(_index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_0__.B.from("Bitcoin seed", "utf8"), r);
      return w(i.slice(0, 32), i.slice(32), t);
    },
    fromBase58: function (e, r) {
      const t = _index_4062991a_mjs__WEBPACK_IMPORTED_MODULE_3__.b.decode(e);
      if (78 !== t.length) throw new TypeError("Invalid buffer length");
      r = r || a;
      const n = t.readUInt32BE(0);
      if (n !== r.bip32.private && n !== r.bip32.public) throw new TypeError("Invalid network version");
      const s = t[4],
        o = t.readUInt32BE(5);
      if (0 === s && 0 !== o) throw new TypeError("Invalid parent fingerprint");
      const h = t.readUInt32BE(9);
      if (0 === s && 0 !== h) throw new TypeError("Invalid index");
      const p = t.slice(13, 45);
      let c;
      if (n === r.bip32.private) {
        if (0 !== t.readUInt8(45)) throw new TypeError("Invalid private key");
        c = v(t.slice(46, 78), p, r, s, h, o);
      } else {
        c = m(t.slice(45, 78), p, r, s, h, o);
      }
      return c;
    },
    fromPublicKey: function (e, r, t) {
      return m(e, r, t);
    },
    fromPrivateKey: w
  };
}


/***/ }),

/***/ 99920:
/*!****************************************************************!*\
  !*** ./apps/bfswap/src/assets/wallet-util/crypto-4198e1c6.mjs ***!
  \****************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   a: () => (/* binding */ o),
/* harmony export */   h: () => (/* binding */ e),
/* harmony export */   s: () => (/* binding */ a),
/* harmony export */   t: () => (/* binding */ s)
/* harmony export */ });
/* harmony import */ var _index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./index-d96f2042.mjs */ 99449);
/* harmony import */ var _ripemd160_fdc485e7_mjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./ripemd160-fdc485e7.mjs */ 10918);
/* harmony import */ var _sha256_d88873b6_mjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./sha256-d88873b6.mjs */ 98080);



function a(n) {
  return _index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_0__.B.from((0,_sha256_d88873b6_mjs__WEBPACK_IMPORTED_MODULE_2__.c)().update(n).digest());
}
function e(r) {
  return function (r) {
    return _index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_0__.B.from((0,_ripemd160_fdc485e7_mjs__WEBPACK_IMPORTED_MODULE_1__.c)().update(r).digest());
  }(a(r));
}
function o(t) {
  return a(a(t));
}
const c = Object.fromEntries(["BIP0340/challenge", "BIP0340/aux", "BIP0340/nonce", "TapLeaf", "TapBranch", "TapSighash", "TapTweak", "KeyAgg list", "KeyAgg coefficient"].map(n => {
  const r = a(_index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_0__.B.from(n));
  return [n, _index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_0__.B.concat([r, r])];
}));
function s(n, r) {
  return a(_index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_0__.B.concat([c[n], r]));
}


/***/ })

}]);
//# sourceMappingURL=apps_bfswap_src_assets_wallet-util_bip32-8a479812_mjs.js.map