"use strict";
(self["webpackChunkbfswap"] = self["webpackChunkbfswap"] || []).push([["apps_bfswap_src_pages_mine_pages_add-liquidity-record_add-liquidity-record_component_ts"],{

/***/ 97322:
/*!*************************************************************************************************!*\
  !*** ./apps/bfswap/src/pages/mine/pages/add-liquidity-record/add-liquidity-record.component.ts ***!
  \*************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AddLiquidityRecordPage: () => (/* binding */ AddLiquidityRecordPage),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 52542);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! tslib */ 90505);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/core */ 61039);
/* harmony import */ var _modules_page_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ~modules/page.module */ 16381);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/common */ 6729);
/* harmony import */ var _services_liquidity_pool_liquidity_pool_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ~services/liquidity-pool/liquidity-pool.service */ 20213);
/* harmony import */ var _pipes_amount_format_amount_format_pipe__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ~pipes/amount-format/amount-format.pipe */ 23377);
/* harmony import */ var _bnqkl_framework_pipes__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @bnqkl/framework/pipes */ 80909);
/* harmony import */ var _services_liquidity_user_liquidity_user_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ~services/liquidity-user/liquidity-user.service */ 34913);
/* harmony import */ var _libs_bnf_components_ripple_button_ripple_button_directive__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../../../../../libs/bnf/components/ripple-button/ripple-button.directive */ 16505);
/* harmony import */ var _libs_bnf_components_pull_to_refresh_pull_to_refresh_directive__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../../../../../libs/bnf/components/pull-to-refresh/pull-to-refresh.directive */ 97063);
/* harmony import */ var _libs_bnf_components_pull_to_refresh_pull_to_refresh_spinner_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../../../../../libs/bnf/components/pull-to-refresh/pull-to-refresh-spinner.component */ 75387);
/* harmony import */ var _libs_bnf_components_infinite_scroll_infinite_scroll_spinner_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../../../../../../libs/bnf/components/infinite-scroll/infinite-scroll-spinner.component */ 66560);
/* harmony import */ var _libs_bnf_components_infinite_scroll_infinite_scroll_directive__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../../../../../../libs/bnf/components/infinite-scroll/infinite-scroll.directive */ 10320);
/* harmony import */ var _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../../../../../../libs/bnf/modules/page/common-page/common-page.component */ 62052);
/* harmony import */ var _components_icon_icon_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../../../components/icon/icon.component */ 18840);

var _class;

















const _c4 = (a0, a1) => [a0, a1];
function AddLiquidityRecordPage_Conditional_4_Conditional_2_For_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div", 7)(1, "div", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵi18n"](2, 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](3, "div", 10)(4, "div", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipe"](6, "amountFormat");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipe"](7, "amountFixed");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](8, "div", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵi18n"](9, 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](10, "div", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](11, "bs-icon", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](12, "div", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](13);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipe"](14, "date");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipe"](15, "date");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const item_r6 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipeBind1"](6, 5, _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipeBind2"](7, 7, item_r6.lpCoinsAmount, 8)), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpureFunction2"](16, _c4, item_r6.stateBgColor, item_r6.stateColor));
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵi18nExp"](item_r6.stateText);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵi18nApply"](9);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtextInterpolate2"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipeBind2"](14, 10, item_r6.createdTime, "yyyy.MM.dd HH:mm"), " - ", _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipeBind2"](15, 13, item_r6.unforzenTime, "yyyy.MM.dd HH:mm"), " ");
  }
}
function AddLiquidityRecordPage_Conditional_4_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrepeaterCreate"](0, AddLiquidityRecordPage_Conditional_4_Conditional_2_For_1_Template, 16, 19, "div", 16, _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrepeaterTrackByIndex"]);
  }
  if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrepeater"](ctx_r2.dataList);
  }
}
function AddLiquidityRecordPage_Conditional_4_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](1, "img", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](2, "span", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵi18n"](3, 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
  }
}
function AddLiquidityRecordPage_Conditional_4_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "bn-infinite-scroll-spinner")(1, "span", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵi18n"](2, 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
  }
}
function AddLiquidityRecordPage_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    const _r12 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("infinited$", function AddLiquidityRecordPage_Conditional_4_Template_div_infinited__0_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r12);
      const ctx_r11 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵresetView"]($event.waitFor(ctx_r11.loadMore()));
    })("pulled$", function AddLiquidityRecordPage_Conditional_4_Template_div_pulled__0_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r12);
      const ctx_r13 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵresetView"]($event.waitFor(ctx_r13.refresh()));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](1, "bn-pull-to-refresh-spinner", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](2, AddLiquidityRecordPage_Conditional_4_Conditional_2_Template, 2, 0)(3, AddLiquidityRecordPage_Conditional_4_Conditional_3_Template, 4, 0)(4, AddLiquidityRecordPage_Conditional_4_Conditional_4_Template, 3, 0, "bn-infinite-scroll-spinner");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("hasMore", ctx_r0.hasMore)("emitDistance", 158)("maxDistance", 200);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵconditional"](2, ctx_r0.dataList.length ? 2 : 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵconditional"](4, ctx_r0.loading ? 4 : -1);
  }
}
function AddLiquidityRecordPage_Conditional_5_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](1, "img", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](2, "div", 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵi18n"](3, 26);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
  }
}
/** 固定增流记录 */
class AddLiquidityRecordPage extends _modules_page_module__WEBPACK_IMPORTED_MODULE_1__.CommonPageBase {
  constructor() {
    super(...arguments);
    /** 合约池服务 */
    this.poolService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_13__.inject)(_services_liquidity_pool_liquidity_pool_service__WEBPACK_IMPORTED_MODULE_2__.LiquidityPoolService);
    /** 用户服务 */
    this.userService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_13__.inject)(_services_liquidity_user_liquidity_user_service__WEBPACK_IMPORTED_MODULE_5__.LiquidityUserService);
    /** loading */
    this.loading = false;
    /** 页数 */
    this.newestMaxIndex = 10000000000;
    /** 数据列表 */
    this.dataList = [];
    /** 页码 */
    this.pageSize = 10;
    /** 是否初始化 */
    this.init = false;
    /** 是否还有 */
    this.hasMore = true;
  }
  /** 加载更多 */
  loadMore() {
    return this.getList();
  }
  /** 展示提示框 */
  openDialog() {
    var _this = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      yield _this.alert({
        headerTitle: `固定增流规则`,
        bodyMessage: '用户兑换成功时，将向交易池中增加一定比例流动性，并获得相关合约池权益，同时此增流部分将锁定一个月后方可移除。',
        buttonText: '好的',
        bodyAlign: 'left'
      });
    })();
  }
  /** 下拉刷新 */
  refresh() {
    var _this2 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this2.init = false;
      _this2.newestMaxIndex = 10000000000;
      _this2.hasMore = true;
      _this2.loading = false;
      _this2.dataList = [];
      _this2.getList();
    })();
  }
  /** 处理状态按钮的样式和文本 */
  handleRecordState(nowTime, unfreezeTime) {
    if (nowTime > unfreezeTime) {
      return {
        stateBgColor: 'bg-border-10',
        stateColor: 'text-base-gray',
        stateText: '已解锁'
      };
    } else if (BigInt(24 * 60 * 60 * 1000) + nowTime > unfreezeTime) {
      return {
        stateBgColor: 'bg-bg-tip-6',
        stateColor: 'text-primary',
        stateText: '即将解锁'
      };
    } else {
      return {
        stateBgColor: 'bg-bg-tip-green-6',
        stateColor: 'text-green-20',
        stateText: '锁定中'
      };
    }
  }
  /** 获取数据 */
  getList() {
    var _this3 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const {
        params
      } = _this3;
      if (params && params.poolId && params.userId) {
        const {
          userId,
          poolId
        } = params;
        const queryParams = {
          userId,
          poolId,
          maxIndex: _this3.newestMaxIndex,
          minIndex: 0,
          size: _this3.pageSize
        };
        if (_this3.hasMore === false) return;
        _this3.loading = true;
        const res = yield _this3.userService.getUserLiquidityLockedList(queryParams);
        if (res) {
          const {
            list,
            hasMore
          } = res;
          const nowTime = Date.now();
          const dlist = list.map(data => {
            const extra = _this3.handleRecordState(BigInt(nowTime), BigInt(data.unforzenTime));
            return {
              ...extra,
              ...data
            };
          });
          _this3.loading = false;
          if (list.length > 0) {
            _this3.newestMaxIndex = list[list.length - 1].index;
          }
          _this3.hasMore = hasMore;
          _this3.dataList = [..._this3.dataList, ...dlist];
          _this3.init = true;
          _this3.cdRef.detectChanges();
        }
      }
    })();
  }
}
_class = AddLiquidityRecordPage;
_class.ɵfac = /*@__PURE__*/(() => {
  let ɵAddLiquidityRecordPage_BaseFactory;
  return function AddLiquidityRecordPage_Factory(t) {
    return (ɵAddLiquidityRecordPage_BaseFactory || (ɵAddLiquidityRecordPage_BaseFactory = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵgetInheritedFactory"](_class)))(t || _class);
  };
})();
_class.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdefineComponent"]({
  type: _class,
  selectors: [["bs-mine-add-liquidity-record"]],
  standalone: true,
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵInheritDefinitionFeature"], _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵStandaloneFeature"]],
  decls: 6,
  vars: 5,
  consts: () => {
    let i18n_0;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_7724775078417564847$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_ADD_LIQUIDITY_RECORD_ADD_LIQUIDITY_RECORD_COMPONENT_TS____1 = goog.getMsg("\u9501\u5B9A\u6570\u91CF");
      i18n_0 = MSG_EXTERNAL_7724775078417564847$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_ADD_LIQUIDITY_RECORD_ADD_LIQUIDITY_RECORD_COMPONENT_TS____1;
    } else {
      i18n_0 = "\u9501\u5B9A\u6570\u91CF";
    }
    let i18n_2;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_1809140819841127921$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_ADD_LIQUIDITY_RECORD_ADD_LIQUIDITY_RECORD_COMPONENT_TS____3 = goog.getMsg(" {$interpolation} ", {
        "interpolation": "\uFFFD0\uFFFD"
      }, {
        original_code: {
          "interpolation": "{{ item.stateText }}"
        }
      });
      i18n_2 = MSG_EXTERNAL_1809140819841127921$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_ADD_LIQUIDITY_RECORD_ADD_LIQUIDITY_RECORD_COMPONENT_TS____3;
    } else {
      i18n_2 = " " + "\uFFFD0\uFFFD" + " ";
    }
    let i18n_5;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_NO_RECORDS$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_ADD_LIQUIDITY_RECORD_ADD_LIQUIDITY_RECORD_COMPONENT_TS___6 = goog.getMsg("No records");
      i18n_5 = MSG_EXTERNAL_NO_RECORDS$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_ADD_LIQUIDITY_RECORD_ADD_LIQUIDITY_RECORD_COMPONENT_TS___6;
    } else {
      i18n_5 = "No records";
    }
    let i18n_7;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_LOADING$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_ADD_LIQUIDITY_RECORD_ADD_LIQUIDITY_RECORD_COMPONENT_TS___8 = goog.getMsg("Loading");
      i18n_7 = MSG_EXTERNAL_LOADING$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_ADD_LIQUIDITY_RECORD_ADD_LIQUIDITY_RECORD_COMPONENT_TS___8;
    } else {
      i18n_7 = "Loading";
    }
    let i18n_9;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_7825757923954104189$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_ADD_LIQUIDITY_RECORD_ADD_LIQUIDITY_RECORD_COMPONENT_TS__10 = goog.getMsg("\u83B7\u53D6\u6570\u636E\u4E2D");
      i18n_9 = MSG_EXTERNAL_7825757923954104189$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_ADD_LIQUIDITY_RECORD_ADD_LIQUIDITY_RECORD_COMPONENT_TS__10;
    } else {
      i18n_9 = "\u83B7\u53D6\u6570\u636E\u4E2D";
    }
    return [[3, "contentBackground", "titleClass", "headerBackground"], ["endMenu", "", "bnRippleButton", "", 1, "icon-4.5", 3, "mode", "click"], ["name", "icon-info"], [1, "h-full"], ["wPullToRefresh", "", "wInfiniteScroll", "", "class", "h-full overflow-y-scroll px-3 pt-2.5", 3, "hasMore", "emitDistance", "maxDistance"], ["wPullToRefresh", "", "wInfiniteScroll", "", 1, "h-full", "overflow-y-scroll", "px-3", "pt-2.5", 3, "hasMore", "emitDistance", "maxDistance", "infinited$", "pulled$"], [1, "text-title"], [1, "rounded-4", "mb-2", "bg-white", "px-4", "py-3"], [1, "text-subtitle-2", "text-xs"], i18n_0, [1, "mt-1", "flex", "items-center"], [1, "text-title-10", "text-base", "font-medium"], [1, "rounded-1", "ml-auto", "px-2", "py-1", "text-xs", 3, "ngClass"], i18n_2, [1, "mt-2", "flex", "items-center"], ["name", "icon-lock", 1, "text-subtitle-2", "mr-2", "text-base"], ["class", "rounded-4 mb-2 bg-white px-4 py-3"], [1, "flex", "h-full", "w-full", "flex-col", "items-center", "justify-center"], ["src", "./assets/images/placeholder-1.png"], [1, "text-line", "text-sm", "text-gray-400"], i18n_5, [1, "text-sm"], i18n_7, [1, "absolute", "left-1/2", "top-1/2", "flex", "w-full", "-translate-x-1/2", "-translate-y-1/2", "flex-col", "items-center", "justify-center"], ["src", "./assets/images/order-ing.png", 1, "h-45", "w-60"], [1, "text-base-200"], i18n_9];
  },
  template: function AddLiquidityRecordPage_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "common-page", 0)(1, "button", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("click", function AddLiquidityRecordPage_Template_button_click_1_listener() {
        return ctx.openDialog();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](2, "bs-icon", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](3, "div", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](4, AddLiquidityRecordPage_Conditional_4_Template, 5, 5, "div", 4)(5, AddLiquidityRecordPage_Conditional_5_Template, 4, 0);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("contentBackground", "#f6f7fc")("titleClass", "text-xl !text-title-10 font-extrabold")("headerBackground", "#f6f7fc");
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("mode", "icon");
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵconditional"](4, ctx.init ? 4 : 5);
    }
  },
  dependencies: [_bnqkl_framework_pipes__WEBPACK_IMPORTED_MODULE_4__.AmountFixedPipe, _pipes_amount_format_amount_format_pipe__WEBPACK_IMPORTED_MODULE_3__.AmountFormatPipe, _modules_page_module__WEBPACK_IMPORTED_MODULE_1__.CommonPageModule, _libs_bnf_components_ripple_button_ripple_button_directive__WEBPACK_IMPORTED_MODULE_6__.RippleButtonDirective, _libs_bnf_components_pull_to_refresh_pull_to_refresh_directive__WEBPACK_IMPORTED_MODULE_7__.PullToRefreshDirective, _libs_bnf_components_pull_to_refresh_pull_to_refresh_spinner_component__WEBPACK_IMPORTED_MODULE_8__.PullToRefreshSpinnerComponent, _libs_bnf_components_infinite_scroll_infinite_scroll_spinner_component__WEBPACK_IMPORTED_MODULE_9__.InfiniteScrollSpinnerComponent, _libs_bnf_components_infinite_scroll_infinite_scroll_directive__WEBPACK_IMPORTED_MODULE_10__.InfiniteScrollDirective, _angular_common__WEBPACK_IMPORTED_MODULE_14__.NgClass, _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_11__.CommonPageComponent, _components_icon_icon_component__WEBPACK_IMPORTED_MODULE_12__.IconComponent, _angular_common__WEBPACK_IMPORTED_MODULE_14__.DatePipe, _angular_common__WEBPACK_IMPORTED_MODULE_14__.CommonModule],
  styles: ["/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsInNvdXJjZVJvb3QiOiIifQ== */"],
  changeDetection: 0
});
(0,tslib__WEBPACK_IMPORTED_MODULE_15__.__decorate)([AddLiquidityRecordPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_15__.__metadata)("design:type", Object)], AddLiquidityRecordPage.prototype, "loading", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_15__.__decorate)([AddLiquidityRecordPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_15__.__metadata)("design:type", Object)], AddLiquidityRecordPage.prototype, "newestMaxIndex", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_15__.__decorate)([AddLiquidityRecordPage.States(1), (0,tslib__WEBPACK_IMPORTED_MODULE_15__.__metadata)("design:type", Array)], AddLiquidityRecordPage.prototype, "dataList", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_15__.__decorate)([AddLiquidityRecordPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_15__.__metadata)("design:type", Object)], AddLiquidityRecordPage.prototype, "pageSize", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_15__.__decorate)([AddLiquidityRecordPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_15__.__metadata)("design:type", Object)], AddLiquidityRecordPage.prototype, "init", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_15__.__decorate)([AddLiquidityRecordPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_15__.__metadata)("design:type", Object)], AddLiquidityRecordPage.prototype, "hasMore", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_15__.__decorate)([AddLiquidityRecordPage.QueryParams(), (0,tslib__WEBPACK_IMPORTED_MODULE_15__.__metadata)("design:type", Object)], AddLiquidityRecordPage.prototype, "params", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_15__.__decorate)([AddLiquidityRecordPage.AfterViewInit(), (0,tslib__WEBPACK_IMPORTED_MODULE_15__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_15__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_15__.__metadata)("design:returntype", Promise)], AddLiquidityRecordPage.prototype, "getList", null);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (AddLiquidityRecordPage);

/***/ }),

/***/ 23377:
/*!*******************************************************************!*\
  !*** ./apps/bfswap/src/pipes/amount-format/amount-format.pipe.ts ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AmountFormatPipe: () => (/* binding */ AmountFormatPipe)
/* harmony export */ });
/* harmony import */ var bignumber_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! bignumber.js */ 61994);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 61039);
var _class;


/** 数值转换小数 */
class AmountFormatPipe {
  constructor() {
    this.transform = AmountFormatPipe.transform;
  }
  /** 转换函数 */
  static transform(value) {
    if (value === undefined) {
      return 0;
    }
    const v = new bignumber_js__WEBPACK_IMPORTED_MODULE_0__["default"](value).toFormat();
    return v;
  }
}
_class = AmountFormatPipe;
_class.ɵfac = function AmountFormatPipe_Factory(t) {
  return new (t || _class)();
};
_class.ɵpipe = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefinePipe"]({
  name: "amountFormat",
  type: _class,
  pure: true,
  standalone: true
});

/***/ }),

/***/ 34913:
/*!***************************************************************************!*\
  !*** ./apps/bfswap/src/services/liquidity-user/liquidity-user.service.ts ***!
  \***************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   LiquidityUserService: () => (/* binding */ LiquidityUserService)
/* harmony export */ });
/* harmony import */ var D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 52542);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 61039);
/* harmony import */ var _services_bs_fetch_bs_fetch_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ~services/bs-fetch/bs-fetch.service */ 92925);
/* harmony import */ var _bnqkl_framework_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @bnqkl/framework/core */ 63563);

var _class;




/** 池子相关接口 */
class LiquidityUserService {
  constructor() {
    /** 日志 */
    this.console = (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.inject)(_bnqkl_framework_core__WEBPACK_IMPORTED_MODULE_2__.LoggerService).createLoggerForService(this, 'liquidity-user-service');
    /** fetch服务 */
    this.fetch = (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.inject)(_services_bs_fetch_bs_fetch_service__WEBPACK_IMPORTED_MODULE_1__.SwapFetch);
    /** 后端接口 */
    this.SERVER_API = {
      /** 获取用户持仓列表 POST */
      getLiquidityUserPositionList: this.fetch.APP_URL('/bnqklswap/liquidity/user/position/list'),
      /** 获取用户资产列表 POST */
      getLiquidityUserAssetsList: this.fetch.APP_URL('/bnqklswap/liquidity/user/assets/list'),
      /** 获取用户流动性持仓 */
      getUserLiquidityHolding: this.fetch.APP_URL('/bnqklswap/liquidity/user/position/list'),
      /** 获取用户持仓详情 */
      getUserPositionDetail: this.fetch.APP_URL('/bnqklswap/liquidity/user/position/details'),
      /** 获取用户持仓比例 */
      getUserPositionPercent: this.fetch.APP_URL('/bnqklswap/liquidity/user/position/percent'),
      /** 获取用户流动性持仓冻结数量 */
      getUserLiquidityLocked: this.fetch.APP_URL('/bnqklswap/liquidity/user/position/locked'),
      /** 获取用户流动性持仓冻结列表 */
      getUserLiquidityLockedList: this.fetch.APP_URL('/bnqklswap/liquidity/user/position/locked/list')
    };
  }
  /** 获取用户锁仓量列表 */
  getUserLiquidityLockedList(options) {
    var _this = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      try {
        return _this.fetch.post(_this.SERVER_API.getUserLiquidityLockedList, options);
        // 默认数据
      } catch (error) {
        _this.console.log('getUserLiquidityLockedList', error);
        return;
      }
    })();
  }
  /** 获取用户持仓详情 */
  getUserPositionDetail(options) {
    try {
      return this.fetch.post(this.SERVER_API.getUserPositionDetail, options);
      // 默认数据
    } catch (error) {
      this.console.log('getUserPositionDetail', error);
      return;
    }
  }
  /** 获取用户锁仓量 */
  getUserLiquidityLocked(options) {
    var _this2 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      try {
        return _this2.fetch.post(_this2.SERVER_API.getUserLiquidityLocked, options);
        // 默认数据
      } catch (error) {
        _this2.console.log('getUserLiquidityLocked', error);
        return;
      }
    })();
  }
  /** 获取用户持仓比例 */
  getUserPositionPercent(options) {
    try {
      return this.fetch.post(this.SERVER_API.getUserPositionPercent, options);
      // 默认数据
    } catch (error) {
      this.console.log('getUserPositionPercent', error);
      return;
    }
  }
  /** 获取用户持仓列表 */
  getLiquidityUserPostionList(options) {
    try {
      return this.fetch.post(this.SERVER_API.getLiquidityUserPositionList, options);
      // 默认数据
    } catch (error) {
      this.console.log('getLiquidityUserPostionList', error);
      return;
    }
  }
  /** 获取用户资产列表 */
  getLiquidityUserAssetsList(options) {
    try {
      return this.fetch.post(this.SERVER_API.getLiquidityUserAssetsList, options);
      // 默认数据
    } catch (error) {
      this.console.log('getLiquidityUserPostionList', error);
      return;
    }
  }
  /** 获取用户流动性持仓 */
  getUserLiquidityHolding(options) {
    var _this3 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      try {
        return _this3.fetch.post(_this3.SERVER_API.getUserLiquidityHolding, options);
        // 默认数据
      } catch (error) {
        _this3.console.log('getUserLiquidityHolding', error);
        return;
      }
    })();
  }
}
_class = LiquidityUserService;
_class.ɵfac = function LiquidityUserService_Factory(t) {
  return new (t || _class)();
};
_class.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineInjectable"]({
  token: _class,
  factory: _class.ɵfac,
  providedIn: 'root'
});

/***/ })

}]);
//# sourceMappingURL=apps_bfswap_src_pages_mine_pages_add-liquidity-record_add-liquidity-record_component_ts.js.map