"use strict";
(self["webpackChunkbfswap"] = self["webpackChunkbfswap"] || []).push([["default-apps_bfswap_src_components_related-events_related-events_component_ts-apps_bfswap_src-4c6996"],{

/***/ 40941:
/*!*******************************************************************************!*\
  !*** ./apps/bfswap/src/components/related-events/related-events.component.ts ***!
  \*******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   RelatedEventsComponent: () => (/* binding */ RelatedEventsComponent),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! tslib */ 90505);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/core */ 61039);
/* harmony import */ var _bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @bnqkl/bnqkl-swap-core */ 70195);
/* harmony import */ var _modules_page_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ~modules/page.module */ 16381);
/* harmony import */ var _pipes_event_state_event_state_icon_pipe__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ~pipes/event-state/event-state-icon.pipe */ 2642);
/* harmony import */ var _pipes_event_state_event_state_color_pipe__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ~pipes/event-state/event-state-color.pipe */ 63636);
/* harmony import */ var _bnqkl_framework_plugins_browser__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @bnqkl/framework/plugins/browser */ 93173);
/* harmony import */ var _bnqkl_wallet_base_services_wallet_chain__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @bnqkl/wallet-base/services/wallet/chain */ 27434);
/* harmony import */ var _services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ~services/wallet/wallet.helper */ 84813);
/* harmony import */ var _bnqkl_framework_pipes__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @bnqkl/framework/pipes */ 80909);
/* harmony import */ var _libs_bnf_directives_click_to_copy_directive__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../../../libs/bnf/directives/click-to-copy.directive */ 46413);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/common */ 6729);
/* harmony import */ var _icon_icon_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../icon/icon.component */ 18840);
var _class;














function RelatedEventsComponent_div_1_div_8_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "div", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵi18n"](1, 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
  }
}
function RelatedEventsComponent_div_1_div_9_Template(rf, ctx) {
  if (rf & 1) {
    const _r6 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "div", 11)(1, "div", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("click", function RelatedEventsComponent_div_1_div_9_Template_div_click_1_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵrestoreView"](_r6);
      const event_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"]().$implicit;
      const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵresetView"](ctx_r4.goBrowser(event_r1));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpipe"](3, "addressHidden");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](4, "bs-icon", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpipe"](5, "eventStateColor");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](6, "bs-icon", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const event_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"]().$implicit;
    const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpipeBind1"](3, 6, event_r1.txHash), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵclassMapInterpolate1"]("ml-1  icon-4 ", _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpipeBind1"](5, 8, ctx_r3.testStatus), "");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("name", ctx_r3.getEventStateIcon(ctx_r3.testStatus));
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("wClickToCopy", event_r1.txHash);
  }
}
function RelatedEventsComponent_div_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "div", 2)(1, "div", 3)(2, "div", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](4, "bs-icon", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](5, "div", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](7, "div", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](8, RelatedEventsComponent_div_1_div_8_Template, 2, 0, "div", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](9, RelatedEventsComponent_div_1_div_9_Template, 7, 10, "div", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const event_r1 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtextInterpolate"](event_r1.leftName);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtextInterpolate"](event_r1.rightName);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", event_r1.isRetrun);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", event_r1.txHash);
  }
}
/**
 * 详情页面相关事件组件
 */
class RelatedEventsComponent extends _modules_page_module__WEBPACK_IMPORTED_MODULE_1__.CommonPageBase {
  constructor() {
    super(...arguments);
    /** 事件列表 */
    this.eventList = [];
    /** 链服务 */
    this._chainService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_10__.inject)(_bnqkl_wallet_base_services_wallet_chain__WEBPACK_IMPORTED_MODULE_5__.ChainService);
    this.testStatus = _bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_0__.TRANSACTION_STATUS.SUCCESS;
  }
  /** 跳转到区块链浏览器 */
  goBrowser(event) {
    const {
      txHash,
      chainName
    } = event;
    if (txHash) {
      _bnqkl_framework_plugins_browser__WEBPACK_IMPORTED_MODULE_4__.Browser.open({
        url: this._chainService.getChainScanTransactionByIdURL(_services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_6__.NODE_CHAIN_NAME_TRANSFER[chainName], txHash)
      });
    }
  }
  /** 获取事件状态的icon */
  getEventStateIcon(state) {
    if (state) {
      return _pipes_event_state_event_state_icon_pipe__WEBPACK_IMPORTED_MODULE_2__.EventStateIconPipe.transform(state);
    } else {
      return '';
    }
  }
}
_class = RelatedEventsComponent;
_class.ɵfac = /*@__PURE__*/(() => {
  let ɵRelatedEventsComponent_BaseFactory;
  return function RelatedEventsComponent_Factory(t) {
    return (ɵRelatedEventsComponent_BaseFactory || (ɵRelatedEventsComponent_BaseFactory = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵgetInheritedFactory"](_class)))(t || _class);
  };
})();
_class.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵdefineComponent"]({
  type: _class,
  selectors: [["bs-related-events-component"]],
  inputs: {
    eventList: "eventList"
  },
  standalone: true,
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵInheritDefinitionFeature"], _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵStandaloneFeature"]],
  decls: 2,
  vars: 1,
  consts: () => {
    let i18n_0;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_REFUNDED_TRANSACTIONS$$APPS_BFSWAP_SRC_COMPONENTS_RELATED_EVENTS_RELATED_EVENTS_COMPONENT_TS___1 = goog.getMsg("( refunded transactions )");
      i18n_0 = MSG_EXTERNAL_REFUNDED_TRANSACTIONS$$APPS_BFSWAP_SRC_COMPONENTS_RELATED_EVENTS_RELATED_EVENTS_COMPONENT_TS___1;
    } else {
      i18n_0 = "( refunded transactions )";
    }
    return [[1, "grid", "grid-cols-1", "gap-y-2"], ["class", "rounded-2 bg-base-300  px-3 py-2 text-xs", 4, "ngFor", "ngForOf"], [1, "rounded-2", "bg-base-300", "px-3", "py-2", "text-xs"], [1, "mb-1", "flex", "items-start"], [1, "text-subtitle-2"], ["name", "icon-arrow-right", 1, "icon-4", "text-subtitle-2", "mx-1"], [1, "text-gray-10", "ml-auto", "text-xs"], ["class", "text-right", 4, "ngIf"], ["class", "flex  items-center ", 4, "ngIf"], [1, "text-right"], i18n_0, [1, "flex", "items-center"], [1, "text-text-router", "text-xs", "leading-4", 3, "click"], [3, "name"], ["name", "icon-copy", 1, "ml-auto", "icon-4", 3, "wClickToCopy"]];
  },
  template: function RelatedEventsComponent_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "div", 0);
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](1, RelatedEventsComponent_div_1_Template, 10, 4, "div", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngForOf", ctx.eventList);
    }
  },
  dependencies: [_modules_page_module__WEBPACK_IMPORTED_MODULE_1__.CommonPageModule, _libs_bnf_directives_click_to_copy_directive__WEBPACK_IMPORTED_MODULE_8__.ClickToCopyDirective, _angular_common__WEBPACK_IMPORTED_MODULE_11__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_11__.NgIf, _icon_icon_component__WEBPACK_IMPORTED_MODULE_9__.IconComponent, _bnqkl_framework_pipes__WEBPACK_IMPORTED_MODULE_7__.AddressHiddenPipe, _pipes_event_state_event_state_color_pipe__WEBPACK_IMPORTED_MODULE_3__.EventStateColorPipe],
  encapsulation: 2,
  changeDetection: 0
});
(0,tslib__WEBPACK_IMPORTED_MODULE_12__.__decorate)([RelatedEventsComponent.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_12__.__metadata)("design:type", Object)], RelatedEventsComponent.prototype, "testStatus", void 0);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (RelatedEventsComponent);

/***/ }),

/***/ 26193:
/*!*********************************************************************************************!*\
  !*** ./apps/bfswap/src/components/swap-token-chain-icon/swap-token-chain-icon.component.ts ***!
  \*********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   SwapTokenChainIconComponent: () => (/* binding */ SwapTokenChainIconComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! tslib */ 90505);
/* harmony import */ var _bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @bnqkl/bnqkl-swap-core */ 70195);
/* harmony import */ var _services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ~services/wallet/wallet.helper */ 84813);
/* harmony import */ var _modules_comp_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ~modules/comp.module */ 58281);
/* harmony import */ var _modules_page_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ~modules/page.module */ 16381);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 61039);
/* harmony import */ var _icon_icon_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../icon/icon.component */ 18840);
var _class;







/** 封装一层的链和币种图标组件 直接传链名和币种即可 */
class SwapTokenChainIconComponent extends _modules_comp_module__WEBPACK_IMPORTED_MODULE_2__.CommonCompBase {
  constructor() {
    super(...arguments);
    /** 图标的大小 */
    this.iconSize = 'icon-4';
    /** 图标名称 */
    this.iconName = 'token-Default';
  }
  init() {
    const {
      swapChainName,
      swapCoinName
    } = this;
    if (swapChainName) {
      let iconName = 'token-Default';
      const chainName = swapChainName in _bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_0__.BNQKL_SWAP_CHAIN_NAME ? _services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_1__.NODE_CHAIN_NAME_TRANSFER[swapChainName] : swapChainName;
      const chainIcon = (0,_services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_1__.transferToChainIcon)(chainName);
      iconName = chainIcon;
      if (swapCoinName) {
        const coinIcon = (0,_services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_1__.transferToTokenIconBychainName)(chainName, swapCoinName);
        iconName = coinIcon;
      }
      this.iconName = iconName;
    }
  }
}
_class = SwapTokenChainIconComponent;
_class.ɵfac = /*@__PURE__*/(() => {
  let ɵSwapTokenChainIconComponent_BaseFactory;
  return function SwapTokenChainIconComponent_Factory(t) {
    return (ɵSwapTokenChainIconComponent_BaseFactory || (ɵSwapTokenChainIconComponent_BaseFactory = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵgetInheritedFactory"](_class)))(t || _class);
  };
})();
_class.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineComponent"]({
  type: _class,
  selectors: [["bs-swap-token-chain-icon"]],
  inputs: {
    iconSize: "iconSize",
    swapChainName: "swapChainName",
    swapCoinName: "swapCoinName"
  },
  standalone: true,
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵInheritDefinitionFeature"], _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵStandaloneFeature"]],
  decls: 1,
  vars: 3,
  consts: [[3, "name"]],
  template: function SwapTokenChainIconComponent_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](0, "bs-icon", 0);
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵclassMap"](ctx.iconSize);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("name", ctx.iconName);
    }
  },
  dependencies: [_modules_page_module__WEBPACK_IMPORTED_MODULE_3__.CommonPageModule, _icon_icon_component__WEBPACK_IMPORTED_MODULE_4__.IconComponent],
  styles: ["[_nghost-%COMP%] {\n  display: flex;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL2FwcHMvYmZzd2FwL3NyYy9jb21wb25lbnRzL3N3YXAtdG9rZW4tY2hhaW4taWNvbi9zd2FwLXRva2VuLWNoYWluLWljb24uY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxhQUFBO0FBQ0oiLCJzb3VyY2VzQ29udGVudCI6WyI6aG9zdHtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbn0iXSwic291cmNlUm9vdCI6IiJ9 */"],
  changeDetection: 0
});
(0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([SwapTokenChainIconComponent.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__metadata)("design:type", String)], SwapTokenChainIconComponent.prototype, "iconName", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([SwapTokenChainIconComponent.OnChanges(), (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__metadata)("design:returntype", void 0)], SwapTokenChainIconComponent.prototype, "init", null);

/***/ }),

/***/ 37514:
/*!*******************************************************************************!*\
  !*** ./apps/bfswap/src/pipes/chain-name-transfer/chain-name-transfer.pipe.ts ***!
  \*******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ChainNameTransferPipe: () => (/* binding */ ChainNameTransferPipe)
/* harmony export */ });
/* harmony import */ var _services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ~services/wallet/wallet.helper */ 84813);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 61039);
var _class;


/** 链名换小写 */
class ChainNameTransferPipe {
  constructor() {
    this.transform = ChainNameTransferPipe.transform;
  }
  /** 转换函数 */
  static transform(chainName) {
    if (chainName === undefined) return '';
    return _services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_0__.NODE_CHAIN_NAME_TRANSFER[chainName];
  }
}
_class = ChainNameTransferPipe;
_class.ɵfac = function ChainNameTransferPipe_Factory(t) {
  return new (t || _class)();
};
_class.ɵpipe = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefinePipe"]({
  name: "chainNameTransfer",
  type: _class,
  pure: true,
  standalone: true
});

/***/ }),

/***/ 63636:
/*!*********************************************************************!*\
  !*** ./apps/bfswap/src/pipes/event-state/event-state-color.pipe.ts ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   EventStateColorPipe: () => (/* binding */ EventStateColorPipe)
/* harmony export */ });
/* harmony import */ var _bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @bnqkl/bnqkl-swap-core */ 70195);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 61039);
var _class;


/** 订单状态对应的颜色 */
class EventStateColorPipe {
  constructor() {
    this.transform = EventStateColorPipe.transform;
  }
  /** 转换函数 */
  static transform(state) {
    if (state === undefined) return '';
    const stateMap = {
      [_bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_0__.TRANSACTION_STATUS.FAILURE]: 'text-red-10',
      [_bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_0__.TRANSACTION_STATUS.INIT]: 'text-subtitle-2',
      [_bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_0__.TRANSACTION_STATUS.PENDING]: 'text-primary',
      [_bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_0__.TRANSACTION_STATUS.SUCCESS]: 'green-20' // '完成',
    };

    return stateMap[state];
  }
}
_class = EventStateColorPipe;
_class.ɵfac = function EventStateColorPipe_Factory(t) {
  return new (t || _class)();
};
_class.ɵpipe = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefinePipe"]({
  name: "eventStateColor",
  type: _class,
  pure: true,
  standalone: true
});

/***/ }),

/***/ 2642:
/*!********************************************************************!*\
  !*** ./apps/bfswap/src/pipes/event-state/event-state-icon.pipe.ts ***!
  \********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   EventStateIconPipe: () => (/* binding */ EventStateIconPipe)
/* harmony export */ });
/* harmony import */ var _bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @bnqkl/bnqkl-swap-core */ 70195);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 61039);
var _class;


/** 事件状态icon */
class EventStateIconPipe {
  constructor() {
    this.transform = EventStateIconPipe.transform;
  }
  /** 转换函数 */
  static transform(state) {
    if (state === undefined) return '';
    const stateMap = {
      [_bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_0__.TRANSACTION_STATUS.FAILURE]: 'icon-waring-fill',
      [_bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_0__.TRANSACTION_STATUS.INIT]: 'icon-timeclock-fill',
      [_bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_0__.TRANSACTION_STATUS.PENDING]: 'icon-radio',
      [_bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_0__.TRANSACTION_STATUS.SUCCESS]: 'icon-prompt-check' // '完成',
    };

    return stateMap[state];
  }
}
_class = EventStateIconPipe;
_class.ɵfac = function EventStateIconPipe_Factory(t) {
  return new (t || _class)();
};
_class.ɵpipe = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefinePipe"]({
  name: "eventStateIcon",
  type: _class,
  pure: true,
  standalone: true
});

/***/ }),

/***/ 24787:
/*!*********************************************************************!*\
  !*** ./apps/bfswap/src/pipes/record-state/record-state-img.pipe.ts ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   RecordStateImagePipe: () => (/* binding */ RecordStateImagePipe)
/* harmony export */ });
/* harmony import */ var _services_liquidity_order_lquidity_order_type__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ~services/liquidity-order/lquidity-order.type */ 84601);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 61039);
var _class;


/** 订单状态对应的图片 */
class RecordStateImagePipe {
  constructor() {
    this.transform = RecordStateImagePipe.transform;
  }
  /** 转换函数 */
  static transform(value) {
    if (value === undefined) {
      return '';
    }
    const map = {
      [_services_liquidity_order_lquidity_order_type__WEBPACK_IMPORTED_MODULE_0__.$ORDER_STATE.SUCCESS]: './assets/images/order-success.png',
      [_services_liquidity_order_lquidity_order_type__WEBPACK_IMPORTED_MODULE_0__.$ORDER_STATE.ING]: './assets/images/order-ing.png',
      [_services_liquidity_order_lquidity_order_type__WEBPACK_IMPORTED_MODULE_0__.$ORDER_STATE.FAIL]: './assets/images/order-fail.png'
    };
    const state = _services_liquidity_order_lquidity_order_type__WEBPACK_IMPORTED_MODULE_0__.ORDER_RECORD_STATE[value];
    return map[state];
  }
}
_class = RecordStateImagePipe;
_class.ɵfac = function RecordStateImagePipe_Factory(t) {
  return new (t || _class)();
};
_class.ɵpipe = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefinePipe"]({
  name: "recordStateImage",
  type: _class,
  pure: true,
  standalone: true
});

/***/ }),

/***/ 7372:
/*!*****************************************************************!*\
  !*** ./apps/bfswap/src/pipes/record-state/record-state.pipe.ts ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   RecordStatePipe: () => (/* binding */ RecordStatePipe)
/* harmony export */ });
/* harmony import */ var _bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @bnqkl/bnqkl-swap-core */ 70195);
/* harmony import */ var _services_liquidity_order_lquidity_order_type__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ~services/liquidity-order/lquidity-order.type */ 84601);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 61039);
var _class;



/** 订单状态管道 */
class RecordStatePipe {
  constructor() {
    this.transform = RecordStatePipe.transform;
  }
  /** 转换函数 */
  static transform(state, type) {
    if (state === undefined) {
      return '- -';
    }
    const swapOrder = {
      [_services_liquidity_order_lquidity_order_type__WEBPACK_IMPORTED_MODULE_1__.$ORDER_STATE.SUCCESS]: '兑换成功',
      [_services_liquidity_order_lquidity_order_type__WEBPACK_IMPORTED_MODULE_1__.$ORDER_STATE.FAIL]: '兑换失败',
      [_services_liquidity_order_lquidity_order_type__WEBPACK_IMPORTED_MODULE_1__.$ORDER_STATE.ING]: '兑换中' // '交易中',
    };

    const addOrder = {
      [_services_liquidity_order_lquidity_order_type__WEBPACK_IMPORTED_MODULE_1__.$ORDER_STATE.SUCCESS]: "Succeed",
      [_services_liquidity_order_lquidity_order_type__WEBPACK_IMPORTED_MODULE_1__.$ORDER_STATE.FAIL]: "Failed",
      [_services_liquidity_order_lquidity_order_type__WEBPACK_IMPORTED_MODULE_1__.$ORDER_STATE.ING]: "Increasing" // '增加中',
    };

    const removeOrder = {
      [_services_liquidity_order_lquidity_order_type__WEBPACK_IMPORTED_MODULE_1__.$ORDER_STATE.SUCCESS]: "Succeed",
      [_services_liquidity_order_lquidity_order_type__WEBPACK_IMPORTED_MODULE_1__.$ORDER_STATE.FAIL]: "Failed",
      [_services_liquidity_order_lquidity_order_type__WEBPACK_IMPORTED_MODULE_1__.$ORDER_STATE.ING]: "Removing" // '移除中',
    };

    const order = {
      [_bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_0__.ORDER_RECORD_TYPES.EXCHANGE_COINS]: swapOrder,
      [_bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_0__.ORDER_RECORD_TYPES.ADD_LIQUIDITY]: addOrder,
      [_bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_0__.ORDER_RECORD_TYPES.REMOVE_LIQUIDITY]: removeOrder
    };
    return order[type][_services_liquidity_order_lquidity_order_type__WEBPACK_IMPORTED_MODULE_1__.ORDER_RECORD_STATE[state]];
  }
}
_class = RecordStatePipe;
_class.ɵfac = function RecordStatePipe_Factory(t) {
  return new (t || _class)();
};
_class.ɵpipe = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefinePipe"]({
  name: "recordState",
  type: _class,
  pure: true,
  standalone: true
});

/***/ }),

/***/ 84601:
/*!*************************************************************************!*\
  !*** ./apps/bfswap/src/services/liquidity-order/lquidity-order.type.ts ***!
  \*************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   $DIRECTION: () => (/* binding */ $DIRECTION),
/* harmony export */   $ORDER_STATE: () => (/* binding */ $ORDER_STATE),
/* harmony export */   $PRICE_TYPE: () => (/* binding */ $PRICE_TYPE),
/* harmony export */   ORDER_RECORD_STATE: () => (/* binding */ ORDER_RECORD_STATE)
/* harmony export */ });
/* harmony import */ var _bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @bnqkl/bnqkl-swap-core */ 70195);

/** 订单的状态 */
var $ORDER_STATE;
(function ($ORDER_STATE) {
  $ORDER_STATE["SUCCESS"] = "SUCESS";
  $ORDER_STATE["FAIL"] = "FAIL";
  $ORDER_STATE["ING"] = "ING";
})($ORDER_STATE || ($ORDER_STATE = {}));
/** 价格类型 */
var $PRICE_TYPE;
(function ($PRICE_TYPE) {
  $PRICE_TYPE["EXPECT"] = "EXPECT";
  $PRICE_TYPE["ACTUAL"] = "ACTUAL";
})($PRICE_TYPE || ($PRICE_TYPE = {}));
/** 方向 */
var $DIRECTION;
(function ($DIRECTION) {
  $DIRECTION["ANCHOR"] = "ANCHOR";
  $DIRECTION["QUOTE"] = "QUOTE";
})($DIRECTION || ($DIRECTION = {}));
/** 订单记录状态 */
const ORDER_RECORD_STATE = {
  [_bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_0__.ORDER_RECORD_STATUS.SUCCESS]: $ORDER_STATE.SUCCESS,
  [_bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_0__.ORDER_RECORD_STATUS.INIT]: $ORDER_STATE.ING,
  [_bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_0__.ORDER_RECORD_STATUS.PAY_TX_ON_CHAIN_FAILURE]: $ORDER_STATE.ING,
  [_bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_0__.ORDER_RECORD_STATUS.PAY_TX_WAIT_ON_CHAIN]: $ORDER_STATE.ING,
  [_bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_0__.ORDER_RECORD_STATUS.RETURN_COMPLETE]: $ORDER_STATE.FAIL,
  [_bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_0__.ORDER_RECORD_STATUS.RETURN_TX_ON_CHAIN_FAILURE]: $ORDER_STATE.ING,
  [_bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_0__.ORDER_RECORD_STATUS.RETURN_TX_WAIT_ON_CHAIN]: $ORDER_STATE.ING,
  [_bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_0__.ORDER_RECORD_STATUS.TX_ON_CHAIN_FAILURE]: $ORDER_STATE.ING,
  [_bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_0__.ORDER_RECORD_STATUS.TX_WAIT_ON_CHAIN]: $ORDER_STATE.ING,
  [_bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_0__.ORDER_RECORD_STATUS.TX_WAIT_CHANGE_LIQUIDITY]: $ORDER_STATE.ING
};

/***/ }),

/***/ 80348:
/*!***************************************************************************************!*\
  !*** ./apps/bfswap/src/services/transaction-settings/transaction-settings.service.ts ***!
  \***************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   TransactionSettingsService: () => (/* binding */ TransactionSettingsService)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 61039);
var _class;

/** 高级设置服务 */
class TransactionSettingsService {
  constructor() {
    /** 默认选中的滑点 */
    this.defaultSlippageIndex = 2;
    /** 临时 */
    this.tempSlippageIndex = 2;
    /** 默认选中的过期事件 */
    this.defaultEndTimesIndex = 2;
    /** 临时 */
    this.tempEndTimesIndex = 2;
    /** 默认选中的增流比例 */
    this.defaultAddRatioIndex = 0;
    /** 临时 */
    this.tempAddRatioIndex = 0;
    /** 滑点容忍度 */
    this.slippages = [{
      label: '0.5%',
      value: '0.005'
    }, {
      label: '1%',
      value: '0.01'
    }, {
      label: '5%',
      value: '0.05'
    }, {
      label: '10%',
      value: '0.1'
    }];
    /** 过期时间 */
    this.endTimes = [{
      label: '5分钟',
      value: 5 * 60 * 1000
    }, {
      label: '15分钟',
      value: 15 * 60 * 1000
    }, {
      label: '30分钟',
      value: 30 * 60 * 1000
    }, {
      label: '45分钟',
      value: 45 * 60 * 1000
    }];
    /** 固定增流比例 */
    this.addLiquidityRatio = [{
      label: '5%',
      value: '0.05'
    }, {
      label: '7%',
      value: '0.07'
    }, {
      label: '9%',
      value: '0.09'
    }, {
      label: '12%',
      value: '0.12'
    }];
  }
  /** 选择滑点 */
  selectSlippage(slippage, index) {
    this.tempSlippageIndex = index;
  }
  /** 选择截至时间 */
  selectEndTime(time, index) {
    this.tempEndTimesIndex = index;
  }
  /** 选择增流比例 */
  selectAddLiquidityRatio(index) {
    this.tempAddRatioIndex = index;
  }
  /** 获取过期时间label */
  getEndTimeLabelByValue(value) {
    return Math.round(value / 1000 / 60);
  }
  /** 获取滑点的label */
  getSlippageLabelByValue(value) {
    return parseFloat(value) * 100;
  }
  /** 获取滑点的label */
  getIncreasedLiquidityRatioByValue(value) {
    return Math.round(parseFloat(value) * 100);
  }
  /** 获取增流比例的label */
  getAddRaioLabelByValue(value) {
    return Number(value) * 100 + '%';
  }
  /** 重置 */
  reset() {
    this.tempEndTimesIndex = 2;
    this.tempSlippageIndex = 2;
    this.tempAddRatioIndex = 0;
    this.defaultEndTimesIndex = 2;
    this.defaultSlippageIndex = 2;
    this.defaultAddRatioIndex = 0;
  }
  /** 关闭 */
  close() {
    this.tempEndTimesIndex = this.defaultEndTimesIndex;
    this.tempSlippageIndex = this.defaultSlippageIndex;
    this.tempAddRatioIndex = this.defaultAddRatioIndex;
  }
  /** 确认 */
  confirm() {
    this.defaultEndTimesIndex = this.tempEndTimesIndex;
    this.defaultSlippageIndex = this.tempSlippageIndex;
    this.defaultAddRatioIndex = this.tempAddRatioIndex;
  }
  /** 获取选中的值 */
  getSelectedValue() {
    const expirationTime = this.endTimes[this.defaultEndTimesIndex];
    const slippageTolerance = this.slippages[this.defaultSlippageIndex];
    const addLiquidityRatio = this.addLiquidityRatio[this.defaultAddRatioIndex];
    return {
      expirationTime,
      slippageTolerance,
      addLiquidityRatio
    };
  }
}
_class = TransactionSettingsService;
_class.ɵfac = function TransactionSettingsService_Factory(t) {
  return new (t || _class)();
};
_class.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjectable"]({
  token: _class,
  factory: _class.ɵfac,
  providedIn: 'root'
});

/***/ })

}]);
//# sourceMappingURL=default-apps_bfswap_src_components_related-events_related-events_component_ts-apps_bfswap_src-4c6996.js.map