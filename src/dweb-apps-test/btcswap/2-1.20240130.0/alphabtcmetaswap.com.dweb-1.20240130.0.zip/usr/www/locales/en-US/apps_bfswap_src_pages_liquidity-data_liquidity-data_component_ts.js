"use strict";
(self["webpackChunkbfswap"] = self["webpackChunkbfswap"] || []).push([["apps_bfswap_src_pages_liquidity-data_liquidity-data_component_ts"],{

/***/ 26193:
/*!*********************************************************************************************!*\
  !*** ./apps/bfswap/src/components/swap-token-chain-icon/swap-token-chain-icon.component.ts ***!
  \*********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   SwapTokenChainIconComponent: () => (/* binding */ SwapTokenChainIconComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! tslib */ 90505);
/* harmony import */ var _bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @bnqkl/bnqkl-swap-core */ 70195);
/* harmony import */ var _services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ~services/wallet/wallet.helper */ 84813);
/* harmony import */ var _modules_comp_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ~modules/comp.module */ 58281);
/* harmony import */ var _modules_page_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ~modules/page.module */ 16381);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 61039);
/* harmony import */ var _icon_icon_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../icon/icon.component */ 18840);
var _class;







/** 封装一层的链和币种图标组件 直接传链名和币种即可 */
class SwapTokenChainIconComponent extends _modules_comp_module__WEBPACK_IMPORTED_MODULE_2__.CommonCompBase {
  constructor() {
    super(...arguments);
    /** 图标的大小 */
    this.iconSize = 'icon-4';
    /** 图标名称 */
    this.iconName = 'token-Default';
  }
  init() {
    const {
      swapChainName,
      swapCoinName
    } = this;
    if (swapChainName) {
      let iconName = 'token-Default';
      const chainName = swapChainName in _bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_0__.BNQKL_SWAP_CHAIN_NAME ? _services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_1__.NODE_CHAIN_NAME_TRANSFER[swapChainName] : swapChainName;
      const chainIcon = (0,_services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_1__.transferToChainIcon)(chainName);
      iconName = chainIcon;
      if (swapCoinName) {
        const coinIcon = (0,_services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_1__.transferToTokenIconBychainName)(chainName, swapCoinName);
        iconName = coinIcon;
      }
      this.iconName = iconName;
    }
  }
}
_class = SwapTokenChainIconComponent;
_class.ɵfac = /*@__PURE__*/(() => {
  let ɵSwapTokenChainIconComponent_BaseFactory;
  return function SwapTokenChainIconComponent_Factory(t) {
    return (ɵSwapTokenChainIconComponent_BaseFactory || (ɵSwapTokenChainIconComponent_BaseFactory = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵgetInheritedFactory"](_class)))(t || _class);
  };
})();
_class.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineComponent"]({
  type: _class,
  selectors: [["bs-swap-token-chain-icon"]],
  inputs: {
    iconSize: "iconSize",
    swapChainName: "swapChainName",
    swapCoinName: "swapCoinName"
  },
  standalone: true,
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵInheritDefinitionFeature"], _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵStandaloneFeature"]],
  decls: 1,
  vars: 3,
  consts: [[3, "name"]],
  template: function SwapTokenChainIconComponent_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](0, "bs-icon", 0);
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵclassMap"](ctx.iconSize);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("name", ctx.iconName);
    }
  },
  dependencies: [_modules_page_module__WEBPACK_IMPORTED_MODULE_3__.CommonPageModule, _icon_icon_component__WEBPACK_IMPORTED_MODULE_4__.IconComponent],
  styles: ["[_nghost-%COMP%] {\n  display: flex;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL2FwcHMvYmZzd2FwL3NyYy9jb21wb25lbnRzL3N3YXAtdG9rZW4tY2hhaW4taWNvbi9zd2FwLXRva2VuLWNoYWluLWljb24uY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxhQUFBO0FBQ0oiLCJzb3VyY2VzQ29udGVudCI6WyI6aG9zdHtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbn0iXSwic291cmNlUm9vdCI6IiJ9 */"],
  changeDetection: 0
});
(0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([SwapTokenChainIconComponent.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__metadata)("design:type", String)], SwapTokenChainIconComponent.prototype, "iconName", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([SwapTokenChainIconComponent.OnChanges(), (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__metadata)("design:returntype", void 0)], SwapTokenChainIconComponent.prototype, "init", null);

/***/ }),

/***/ 5558:
/*!**************************************************************************!*\
  !*** ./apps/bfswap/src/pages/liquidity-data/liquidity-data.component.ts ***!
  \**************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   LiquidityDataPage: () => (/* binding */ LiquidityDataPage),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 52542);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! tslib */ 90505);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @angular/core */ 61039);
/* harmony import */ var _components_token_with_chain_icon_token_with_chain_icon_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ~components/token-with-chain-icon/token-with-chain-icon.component */ 11342);
/* harmony import */ var _modules_page_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ~modules/page.module */ 16381);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @angular/common */ 6729);
/* harmony import */ var echarts__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! echarts */ 23557);
/* harmony import */ var _services_liquidity_pool_liquidity_pool_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ~services/liquidity-pool/liquidity-pool.service */ 20213);
/* harmony import */ var _services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ~services/wallet/wallet.helper */ 84813);
/* harmony import */ var _pipes_amount_format_amount_format_pipe__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ~pipes/amount-format/amount-format.pipe */ 23377);
/* harmony import */ var _pipes_percentage_transfer_percentage_transfer_pipe__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ~pipes/percentage-transfer/percentage-transfer.pipe */ 1726);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! moment */ 76442);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var bignumber_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! bignumber.js */ 61994);
/* harmony import */ var _bnqkl_framework_pipes__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @bnqkl/framework/pipes */ 80909);
/* harmony import */ var _components_swap_token_chain_icon_swap_token_chain_icon_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ~components/swap-token-chain-icon/swap-token-chain-icon.component */ 26193);
/* harmony import */ var _services_liquidity_user_liquidity_user_service__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ~services/liquidity-user/liquidity-user.service */ 34913);
/* harmony import */ var _libs_bnf_directives_click_to_copy_directive__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../../../../../libs/bnf/directives/click-to-copy.directive */ 46413);
/* harmony import */ var _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../../../../../libs/bnf/modules/page/common-page/common-page.component */ 62052);
/* harmony import */ var _libs_bnf_pipes_amountFixed_amount_fixed_pipe__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ../../../../../libs/bnf/pipes/amountFixed/amount-fixed.pipe */ 44070);

var _class;




















const _c0 = ["assetsChart"];
const _c1 = ["totalChart"];
const _c2 = ["ratioChart"];
function LiquidityDataPage_Conditional_147_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](0, "div", 66);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelement"](1, "img", 67);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](2, "div", 29);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵi18n"](3, 68);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]()();
  }
}
const _c39 = a0 => ({
  backgroundColor: a0
});
const _c40 = () => ({
  startIndex: 4,
  endIndex: 4
});
function LiquidityDataPage_For_150_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelement"](0, "div", 69);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](1, "div", 70);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipe"](3, "addressHidden");
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](4, "div", 71);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtext"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](6, "div", 71);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtext"](7);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const item_r7 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpureFunction1"](10, _c39, item_r7.color));
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵproperty"]("wClickToCopy", item_r7.address)("copySuccessMsg", "\u5730\u5740\u5DF2\u590D\u5236");
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipeBind2"](3, 7, item_r7.address, _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpureFunction0"](12, _c40)), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtextInterpolate"](item_r7.value);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtextInterpolate"](item_r7.percent);
  }
}
function LiquidityDataPage_Conditional_151_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](0, "div", 72);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelement"](1, "img", 73);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](2, "div", 74);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵi18n"](3, 75);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]()();
  }
}
function LiquidityDataPage_Conditional_152_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](0, "div", 72);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelement"](1, "img", 76);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](2, "div", 74);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵi18n"](3, 77);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]()();
  }
}
/** 合约池数据 */
class LiquidityDataPage extends _modules_page_module__WEBPACK_IMPORTED_MODULE_2__.CommonPageBase {
  constructor() {
    super(...arguments);
    /** 池子服务 */
    this.poolService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_16__.inject)(_services_liquidity_pool_liquidity_pool_service__WEBPACK_IMPORTED_MODULE_4__.LiquidityPoolService);
    /** 用户服务 */
    this.userService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_16__.inject)(_services_liquidity_user_liquidity_user_service__WEBPACK_IMPORTED_MODULE_12__.LiquidityUserService);
    /** 初始化 */
    this.init = false;
    /** 展示饼图 */
    this.showPieChartMash = true;
    /** maxIndex */
    this.maxIndex = 1000000;
    /** 获取的条数 */
    this.pageSize = 10;
    /** 是否还有 */
    this.hasMore = true;
    /** 报表列表 */
    this.dataList = [];
    /** 池子最新数据 */
    this.newData = undefined;
    /** 是否拿到最新报表 */
    this.getDataFlag = false;
    /** 持有的市值 */
    this.holdUAmount = '';
    /** anchor币图标 */
    this.anchorCoinIcon = undefined;
    /** anchor 链图标 */
    this.anchorChainIcon = undefined;
    /** quote币图标 */
    this.quoteCoinIcon = undefined;
    /** 颜色数组 */
    this.colorList = ['#640ff3', '#90d161', '#ffc83e', '#ff635d', '#70c3ed', '#43a76b', '#ff8240', '#abadc1'];
    /** 权益图下方数据 */
    this.ratioDataList = [];
  }
  /** 初始化图表 */
  initEcharts() {
    var _this = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      var _this$assetsChart, _this$totalChart, _this$ratioChart;
      const assetsDOM = (_this$assetsChart = _this.assetsChart) === null || _this$assetsChart === void 0 ? void 0 : _this$assetsChart.nativeElement;
      const totalDOM = (_this$totalChart = _this.totalChart) === null || _this$totalChart === void 0 ? void 0 : _this$totalChart.nativeElement;
      const ratioDOM = (_this$ratioChart = _this.ratioChart) === null || _this$ratioChart === void 0 ? void 0 : _this$ratioChart.nativeElement;
      _this.assetsInstance = echarts__WEBPACK_IMPORTED_MODULE_3__.init(assetsDOM);
      _this.totalInstance = echarts__WEBPACK_IMPORTED_MODULE_3__.init(totalDOM);
      _this.ratioInstance = echarts__WEBPACK_IMPORTED_MODULE_3__.init(ratioDOM);
      _this.getData();
    })();
  }
  /** 获取数据 */
  getData() {
    var _this2 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const params = _this2.nav.getQueryParams();
      const poolId = params['poolId'];
      if (poolId) {
        const queryParams = {
          poolId: poolId,
          minIndex: 0,
          maxIndex: _this2.maxIndex,
          size: _this2.pageSize
        };
        const result = yield _this2.poolService.getLiquidityPoolReportList(queryParams);
        if (result) {
          const {
            hasMore,
            list
          } = result;
          const reverselList = list.reverse();
          _this2.hasMore = hasMore;
          if (list.length > 0 && _this2.getDataFlag === false) {
            const newData = list[list.length - 1];
            _this2.newData = newData;
            _this2.holdUAmount = new bignumber_js__WEBPACK_IMPORTED_MODULE_9__["default"](newData.quoteCoinsAmount).multipliedBy(2).toString();
            _this2.getDataFlag = true;
            _this2.handleIcon(newData);
            _this2.getPieChartData(newData.reportId);
          }
          _this2.drawTotalChart(reverselList);
          _this2.drawAssetsChart(reverselList);
          _this2.dataList = reverselList;
          _this2.init = true;
        }
      }
    })();
  }
  /** 绘制权益量图表 */
  drawAssetsChart(list) {
    var _this$assetsInstance;
    const xLabel = this.handleXLabelData(list);
    const yData = list.map(item => item.lpCoinsAmount);
    const assetOption = this.getAssetsOption(xLabel, yData);
    (_this$assetsInstance = this.assetsInstance) === null || _this$assetsInstance === void 0 || _this$assetsInstance.setOption(assetOption);
  }
  /** 绘制收益累计图表 */
  drawTotalChart(list) {
    var _this$totalInstance;
    const xLabel = this.handleXLabelData(list);
    const anchorTotal = list.map(item => item.anchorCoinsTotalProfits);
    const quoteTotal = list.map(item => item.quoteCoinsTotalProfits);
    const totalOption = this.getTotalProfitOption(xLabel, anchorTotal, quoteTotal);
    (_this$totalInstance = this.totalInstance) === null || _this$totalInstance === void 0 || _this$totalInstance.setOption(totalOption);
  }
  /** 获取饼图数据 */
  getPieChartData(reportId) {
    var _this3 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const result = yield _this3.userService.getUserPositionPercent({
        reportId
      });
      if (result) {
        var _this3$ratioInstance;
        const option = _this3.getRatioOption(result);
        (_this3$ratioInstance = _this3.ratioInstance) === null || _this3$ratioInstance === void 0 || _this3$ratioInstance.setOption(option);
        _this3.showPieChartMash = false;
      }
    })();
  }
  /** 处理图标 */
  handleIcon(result) {
    this.anchorChainIcon = (0,_services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_5__.transferToChainIcon)(_services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_5__.NODE_CHAIN_NAME_TRANSFER[result.anchorCoinsChainName] || 'Default');
    this.anchorCoinIcon = (0,_services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_5__.transferToTokenIcon)(result.anchorCoinsChainName, result.anchorCoinsName);
    this.quoteCoinIcon = (0,_services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_5__.transferToTokenIcon)(result.quoteCoinsChainName, result.quoteCoinsName);
  }
  /** 获取占比配置 */
  getRatioOption(list) {
    const other = {
      value: new bignumber_js__WEBPACK_IMPORTED_MODULE_9__["default"](0),
      percent: new bignumber_js__WEBPACK_IMPORTED_MODULE_9__["default"](0)
    };
    list.forEach((item, index) => {
      const percent = new bignumber_js__WEBPACK_IMPORTED_MODULE_9__["default"](item.percent).multipliedBy(1e2);
      if (percent.isGreaterThanOrEqualTo(1)) {
        this.ratioDataList.push({
          value: new bignumber_js__WEBPACK_IMPORTED_MODULE_9__["default"](item.lpCoinsAmount).dividedBy(1e8).toNumber(),
          percent: percent.toFixed(2, 1) + '%',
          color: this.colorList[index],
          address: item.userId
        });
      } else {
        other.percent = other.percent.plus(percent);
        other.value = other.value.plus(item.lpCoinsAmount);
      }
    });
    const dataList = this.ratioDataList.map(item => {
      return {
        value: item.value,
        name: item.percent,
        itemStyle: {
          color: item.color
        }
      };
    });
    if (other.value.isGreaterThan(0)) {
      dataList.push({
        value: other.value.dividedBy(1e8).toNumber(),
        name: other.percent.toFixed(2, 1) + '%',
        itemStyle: {
          color: this.colorList[this.colorList.length - 1]
        }
      });
      this.ratioDataList.push({
        value: new bignumber_js__WEBPACK_IMPORTED_MODULE_9__["default"](other.value).dividedBy(1e8).toNumber(),
        percent: other.percent.toFixed(2, 1) + '%',
        color: this.colorList[this.colorList.length - 1],
        address: '其他'
      });
    }
    return {
      series: [{
        type: 'pie',
        radius: ['0', '65%'],
        center: ['50%', '50%'],
        data: dataList
      }]
    };
  }
  /** 处理X轴数据 */
  handleXLabelData(dataList) {
    return dataList.map(item => {
      const month = moment__WEBPACK_IMPORTED_MODULE_8___default()(item.createdTime).format('MM');
      const day = moment__WEBPACK_IMPORTED_MODULE_8___default()(item.createdTime).format('DD');
      return `${month}-${day}`;
    });
  }
  /** 收益累计配置 */
  getTotalProfitOption(xlabel, anchorData, quoteData) {
    const anData = anchorData.map(item => {
      return new bignumber_js__WEBPACK_IMPORTED_MODULE_9__["default"](item).dividedBy(1e8).toString();
    });
    const quData = quoteData.map(item => {
      return new bignumber_js__WEBPACK_IMPORTED_MODULE_9__["default"](item).dividedBy(1e8).toString();
    });
    return {
      tooltip: {
        trigger: 'axis',
        axisPointer: {
          type: 'cross',
          label: {
            backgroundColor: '#6a7985'
          }
        }
      },
      grid: {
        left: '3%',
        right: '5%',
        bottom: '3%',
        top: '10%',
        containLabel: true
      },
      xAxis: {
        type: 'category',
        boundaryGap: false,
        data: xlabel
      },
      yAxis: {
        type: 'value'
      },
      series: [{
        data: anData,
        type: 'line',
        itemStyle: {
          color: '#640ff3'
        }
      }, {
        data: quData,
        type: 'line',
        itemStyle: {
          color: '#fac00a'
        }
      }]
    };
  }
  /** 获取权益量图表的配置 */
  getAssetsOption(xLabel, yData) {
    const y = yData.map(item => {
      return new bignumber_js__WEBPACK_IMPORTED_MODULE_9__["default"](item).dividedBy(1e8).toString();
    });
    /** 权益量配置 */
    return {
      tooltip: {
        trigger: 'axis',
        axisPointer: {
          type: 'cross',
          label: {
            backgroundColor: '#6a7985'
          }
        }
      },
      grid: {
        left: '3%',
        right: '5%',
        bottom: '3%',
        top: '10%',
        containLabel: true
      },
      xAxis: {
        type: 'category',
        boundaryGap: false,
        data: xLabel
      },
      yAxis: {
        type: 'value'
      },
      series: [{
        data: y,
        type: 'line',
        itemStyle: {
          color: '#640ff3'
        }
      }]
    };
  }
}
_class = LiquidityDataPage;
_class.ɵfac = /*@__PURE__*/(() => {
  let ɵLiquidityDataPage_BaseFactory;
  return function LiquidityDataPage_Factory(t) {
    return (ɵLiquidityDataPage_BaseFactory || (ɵLiquidityDataPage_BaseFactory = _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵgetInheritedFactory"](_class)))(t || _class);
  };
})();
_class.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵdefineComponent"]({
  type: _class,
  selectors: [["bs-mine-liquidity-data"]],
  viewQuery: function LiquidityDataPage_Query(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵviewQuery"](_c0, 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵviewQuery"](_c1, 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵviewQuery"](_c2, 5);
    }
    if (rf & 2) {
      let _t;
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵloadQuery"]()) && (ctx.assetsChart = _t.first);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵloadQuery"]()) && (ctx.totalChart = _t.first);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵloadQuery"]()) && (ctx.ratioChart = _t.first);
    }
  },
  standalone: true,
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵInheritDefinitionFeature"], _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵStandaloneFeature"]],
  decls: 153,
  vars: 120,
  consts: () => {
    let i18n_3;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_6565550411645591512$$APPS_BFSWAP_SRC_PAGES_LIQUIDITY_DATA_LIQUIDITY_DATA_COMPONENT_TS_4 = goog.getMsg("\u5408\u7EA6\u6C60\u6570\u636E");
      i18n_3 = MSG_EXTERNAL_6565550411645591512$$APPS_BFSWAP_SRC_PAGES_LIQUIDITY_DATA_LIQUIDITY_DATA_COMPONENT_TS_4;
    } else {
      i18n_3 = "\u5408\u7EA6\u6C60\u6570\u636E";
    }
    let i18n_5;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_7602674803143621945$$APPS_BFSWAP_SRC_PAGES_LIQUIDITY_DATA_LIQUIDITY_DATA_COMPONENT_TS_6 = goog.getMsg("\u7EDF\u8BA1\u81F3:{$interpolation}", {
        "interpolation": "\uFFFD0\uFFFD"
      }, {
        original_code: {
          "interpolation": "{{ newData?.createdTime | date : 'yyyy-MM-dd HH:mm' }}"
        }
      });
      i18n_5 = MSG_EXTERNAL_7602674803143621945$$APPS_BFSWAP_SRC_PAGES_LIQUIDITY_DATA_LIQUIDITY_DATA_COMPONENT_TS_6;
    } else {
      i18n_5 = "\u7EDF\u8BA1\u81F3:" + "\uFFFD0\uFFFD" + "";
    }
    let i18n_7;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_2316329852396974020$$APPS_BFSWAP_SRC_PAGES_LIQUIDITY_DATA_LIQUIDITY_DATA_COMPONENT_TS_8 = goog.getMsg("\u5408\u7EA6\u6C60\u5E02\u503C");
      i18n_7 = MSG_EXTERNAL_2316329852396974020$$APPS_BFSWAP_SRC_PAGES_LIQUIDITY_DATA_LIQUIDITY_DATA_COMPONENT_TS_8;
    } else {
      i18n_7 = "\u5408\u7EA6\u6C60\u5E02\u503C";
    }
    let i18n_9;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_7098743090516790997$$APPS_BFSWAP_SRC_PAGES_LIQUIDITY_DATA_LIQUIDITY_DATA_COMPONENT_TS_10 = goog.getMsg("\u5408\u7EA6\u6C60\u6743\u76CA-\u603B\u91CF");
      i18n_9 = MSG_EXTERNAL_7098743090516790997$$APPS_BFSWAP_SRC_PAGES_LIQUIDITY_DATA_LIQUIDITY_DATA_COMPONENT_TS_10;
    } else {
      i18n_9 = "\u5408\u7EA6\u6C60\u6743\u76CA-\u603B\u91CF";
    }
    let i18n_11;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_6753211418247050081$$APPS_BFSWAP_SRC_PAGES_LIQUIDITY_DATA_LIQUIDITY_DATA_COMPONENT_TS_12 = goog.getMsg("\u5408\u7EA6\u6C60\u6743\u76CA-\u9501\u5B9A\u91CF");
      i18n_11 = MSG_EXTERNAL_6753211418247050081$$APPS_BFSWAP_SRC_PAGES_LIQUIDITY_DATA_LIQUIDITY_DATA_COMPONENT_TS_12;
    } else {
      i18n_11 = "\u5408\u7EA6\u6C60\u6743\u76CA-\u9501\u5B9A\u91CF";
    }
    let i18n_13;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_3442388705626999178$$APPS_BFSWAP_SRC_PAGES_LIQUIDITY_DATA_LIQUIDITY_DATA_COMPONENT_TS_14 = goog.getMsg("\u6D41\u52A8\u6027\u63D0\u4F9B\u5730\u5740\u6570");
      i18n_13 = MSG_EXTERNAL_3442388705626999178$$APPS_BFSWAP_SRC_PAGES_LIQUIDITY_DATA_LIQUIDITY_DATA_COMPONENT_TS_14;
    } else {
      i18n_13 = "\u6D41\u52A8\u6027\u63D0\u4F9B\u5730\u5740\u6570";
    }
    let i18n_15;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_8320996432445560696$$APPS_BFSWAP_SRC_PAGES_LIQUIDITY_DATA_LIQUIDITY_DATA_COMPONENT_TS_16 = goog.getMsg("\u5151\u6362\u624B\u7EED\u8D39\u6BD4\u4F8B");
      i18n_15 = MSG_EXTERNAL_8320996432445560696$$APPS_BFSWAP_SRC_PAGES_LIQUIDITY_DATA_LIQUIDITY_DATA_COMPONENT_TS_16;
    } else {
      i18n_15 = "\u5151\u6362\u624B\u7EED\u8D39\u6BD4\u4F8B";
    }
    let i18n_17;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_5739636166086275789$$APPS_BFSWAP_SRC_PAGES_LIQUIDITY_DATA_LIQUIDITY_DATA_COMPONENT_TS_18 = goog.getMsg("\u521B\u5EFA\u65F6\u95F4");
      i18n_17 = MSG_EXTERNAL_5739636166086275789$$APPS_BFSWAP_SRC_PAGES_LIQUIDITY_DATA_LIQUIDITY_DATA_COMPONENT_TS_18;
    } else {
      i18n_17 = "\u521B\u5EFA\u65F6\u95F4";
    }
    let i18n_19;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_3568630646445966190$$APPS_BFSWAP_SRC_PAGES_LIQUIDITY_DATA_LIQUIDITY_DATA_COMPONENT_TS_20 = goog.getMsg("\u603B\u4EA4\u6613\u989D");
      i18n_19 = MSG_EXTERNAL_3568630646445966190$$APPS_BFSWAP_SRC_PAGES_LIQUIDITY_DATA_LIQUIDITY_DATA_COMPONENT_TS_20;
    } else {
      i18n_19 = "\u603B\u4EA4\u6613\u989D";
    }
    let i18n_21;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_U$$APPS_BFSWAP_SRC_PAGES_LIQUIDITY_DATA_LIQUIDITY_DATA_COMPONENT_TS_22 = goog.getMsg(" {$interpolation} U ", {
        "interpolation": "\uFFFD0\uFFFD"
      }, {
        original_code: {
          "interpolation": "{{ newData?.totalValue | amountFixed : 8 | amountFormat }}"
        }
      });
      i18n_21 = MSG_EXTERNAL_U$$APPS_BFSWAP_SRC_PAGES_LIQUIDITY_DATA_LIQUIDITY_DATA_COMPONENT_TS_22;
    } else {
      i18n_21 = " " + "\uFFFD0\uFFFD" + " U ";
    }
    let i18n_23;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_3625178927256696157$$APPS_BFSWAP_SRC_PAGES_LIQUIDITY_DATA_LIQUIDITY_DATA_COMPONENT_TS_24 = goog.getMsg("\u603B\u5151\u6362\u6B21\u6570");
      i18n_23 = MSG_EXTERNAL_3625178927256696157$$APPS_BFSWAP_SRC_PAGES_LIQUIDITY_DATA_LIQUIDITY_DATA_COMPONENT_TS_24;
    } else {
      i18n_23 = "\u603B\u5151\u6362\u6B21\u6570";
    }
    let i18n_25;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_8446609261808968550$$APPS_BFSWAP_SRC_PAGES_LIQUIDITY_DATA_LIQUIDITY_DATA_COMPONENT_TS_26 = goog.getMsg("{$interpolation} \u6B21", {
        "interpolation": "\uFFFD0\uFFFD"
      }, {
        original_code: {
          "interpolation": "{{ newData?.totalExchangesTimes }}"
        }
      });
      i18n_25 = MSG_EXTERNAL_8446609261808968550$$APPS_BFSWAP_SRC_PAGES_LIQUIDITY_DATA_LIQUIDITY_DATA_COMPONENT_TS_26;
    } else {
      i18n_25 = "" + "\uFFFD0\uFFFD" + " \u6B21";
    }
    let i18n_27;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_7647042285240944934$$APPS_BFSWAP_SRC_PAGES_LIQUIDITY_DATA_LIQUIDITY_DATA_COMPONENT_TS_28 = goog.getMsg("\u6D41\u52A8\u6027\u7D2F\u8BA1\u6536\u76CA");
      i18n_27 = MSG_EXTERNAL_7647042285240944934$$APPS_BFSWAP_SRC_PAGES_LIQUIDITY_DATA_LIQUIDITY_DATA_COMPONENT_TS_28;
    } else {
      i18n_27 = "\u6D41\u52A8\u6027\u7D2F\u8BA1\u6536\u76CA";
    }
    let i18n_29;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_4373921052025507209$$APPS_BFSWAP_SRC_PAGES_LIQUIDITY_DATA_LIQUIDITY_DATA_COMPONENT_TS_30 = goog.getMsg(" {$interpolation}/{$interpolation_1} \u5408\u7EA6\u6C60\u6743\u76CA\u91CF ", {
        "interpolation": "\uFFFD0\uFFFD",
        "interpolation_1": "\uFFFD1\uFFFD"
      }, {
        original_code: {
          "interpolation": "{{ newData?.anchorCoinsName }}",
          "interpolation_1": "{{ newData?.quoteCoinsName }}"
        }
      });
      i18n_29 = MSG_EXTERNAL_4373921052025507209$$APPS_BFSWAP_SRC_PAGES_LIQUIDITY_DATA_LIQUIDITY_DATA_COMPONENT_TS_30;
    } else {
      i18n_29 = " " + "\uFFFD0\uFFFD" + "/" + "\uFFFD1\uFFFD" + " \u5408\u7EA6\u6C60\u6743\u76CA\u91CF ";
    }
    let i18n_31;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_7997431867778497089$$APPS_BFSWAP_SRC_PAGES_LIQUIDITY_DATA_LIQUIDITY_DATA_COMPONENT_TS_32 = goog.getMsg("\u5408\u7EA6\u6C60\u6743\u76CA :");
      i18n_31 = MSG_EXTERNAL_7997431867778497089$$APPS_BFSWAP_SRC_PAGES_LIQUIDITY_DATA_LIQUIDITY_DATA_COMPONENT_TS_32;
    } else {
      i18n_31 = "\u5408\u7EA6\u6C60\u6743\u76CA :";
    }
    let i18n_33;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_3826355777637069240$$APPS_BFSWAP_SRC_PAGES_LIQUIDITY_DATA_LIQUIDITY_DATA_COMPONENT_TS_34 = goog.getMsg("\u5408\u7EA6\u6C60\u6536\u76CA\u7D2F\u8BA1");
      i18n_33 = MSG_EXTERNAL_3826355777637069240$$APPS_BFSWAP_SRC_PAGES_LIQUIDITY_DATA_LIQUIDITY_DATA_COMPONENT_TS_34;
    } else {
      i18n_33 = "\u5408\u7EA6\u6C60\u6536\u76CA\u7D2F\u8BA1";
    }
    let i18n_35;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_5943732459185444775$$APPS_BFSWAP_SRC_PAGES_LIQUIDITY_DATA_LIQUIDITY_DATA_COMPONENT_TS_36 = goog.getMsg("\u5408\u7EA6\u6C60\u6743\u76CA\u5360\u6BD4\u56FE");
      i18n_35 = MSG_EXTERNAL_5943732459185444775$$APPS_BFSWAP_SRC_PAGES_LIQUIDITY_DATA_LIQUIDITY_DATA_COMPONENT_TS_36;
    } else {
      i18n_35 = "\u5408\u7EA6\u6C60\u6743\u76CA\u5360\u6BD4\u56FE";
    }
    let i18n_37;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_8036181925851410124$$APPS_BFSWAP_SRC_PAGES_LIQUIDITY_DATA_LIQUIDITY_DATA_COMPONENT_TS__38 = goog.getMsg("\u6682\u65E0\u6570\u636E");
      i18n_37 = MSG_EXTERNAL_8036181925851410124$$APPS_BFSWAP_SRC_PAGES_LIQUIDITY_DATA_LIQUIDITY_DATA_COMPONENT_TS__38;
    } else {
      i18n_37 = "\u6682\u65E0\u6570\u636E";
    }
    let i18n_41;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_7825757923954104189$$APPS_BFSWAP_SRC_PAGES_LIQUIDITY_DATA_LIQUIDITY_DATA_COMPONENT_TS__42 = goog.getMsg("\u83B7\u53D6\u6570\u636E\u4E2D");
      i18n_41 = MSG_EXTERNAL_7825757923954104189$$APPS_BFSWAP_SRC_PAGES_LIQUIDITY_DATA_LIQUIDITY_DATA_COMPONENT_TS__42;
    } else {
      i18n_41 = "\u83B7\u53D6\u6570\u636E\u4E2D";
    }
    let i18n_43;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_8036181925851410124$$APPS_BFSWAP_SRC_PAGES_LIQUIDITY_DATA_LIQUIDITY_DATA_COMPONENT_TS__44 = goog.getMsg("\u6682\u65E0\u6570\u636E");
      i18n_43 = MSG_EXTERNAL_8036181925851410124$$APPS_BFSWAP_SRC_PAGES_LIQUIDITY_DATA_LIQUIDITY_DATA_COMPONENT_TS__44;
    } else {
      i18n_43 = "\u6682\u65E0\u6570\u636E";
    }
    return [[3, "headerBackground", "titleClass", "contentBackground"], ["headerTitle", "", 1, "flex", "flex-col"], [1, "text-title-10", "text-xl", "font-extrabold"], i18n_3, [1, "text-gray-10", "text-xs"], i18n_5, [1, "_bginner", "h-100", "absolute", "left-0", "top-0", "w-full"], [1, "relative", "z-10", "pb-5"], [1, "flex", "items-center", "pl-9", "pt-6"], [3, "swapCoinName", "swapChainName"], [1, "ml-3"], [1, "text-title-10", "text-base", "font-semibold"], [1, "bg-text-input", "mx-3", "h-8", "w-[1px]"], [3, "iconSize", "swapCoinName", "swapChainName"], [1, "ml-2"], [1, "rounded-5", "mt-4", "bg-white", "p-4"], [1, "text-title-10", "text-base", "font-extrabold"], i18n_7, [1, "text-title-10", "text-2xl", "font-extrabold"], [1, "rounded-2", "bg-base-300", "mt-4", "px-2", "py-3"], [1, "flex", "items-center"], [1, "text-title-10", "ml-1", "mr-2", "text-xs"], [1, "bg-blue-10", "rounded-1", "flex", "items-center", "border", "border-white", "pr-1"], [3, "iconSize", "swapChainName"], [1, "text-xxxs"], [1, "text-title-10", "ml-auto", "text-xs"], [1, "mt-2", "flex", "items-center"], [1, "text-title-10", "ml-auto", "text-xs", "font-medium"], [1, "border-border-10", "grid", "grid-cols-[2fr,3fr]", "gap-y-4", "border-b", "py-4"], [1, "text-subtitle-2"], i18n_9, [1, "text-title-10", "text-right", "font-medium"], i18n_11, i18n_13, i18n_15, i18n_17, [1, "mt-4", "grid", "grid-cols-[3fr,7fr]", "gap-y-4"], i18n_19, i18n_21, i18n_23, i18n_25, i18n_27, [1, "rounded-5", "mt-2", "bg-white", "py-4"], [1, "text-title-10", "pl-4", "text-base", "font-extrabold"], i18n_29, [1, "my-2", "flex", "items-center", "px-4"], [1, "text-title-10", "text-xs"], [1, "bg-primary", "ml-auto", "mr-1", "h-1.5", "w-1.5", "rounded-full"], [1, "text-subtitle", "text-xs"], i18n_31, [1, "h-50", "w-full"], ["assetsChart", ""], i18n_33, [1, "my-2", "flex", "px-4"], [1, "ml-auto", "grid", "grid-cols-[0.8rem,3rem,auto]", "items-center"], [1, "bg-primary", "mr-1", "h-1.5", "w-1.5", "rounded-full"], [1, "bg-orange-20", "mr-1", "h-1.5", "w-1.5", "rounded-full"], ["totalChart", ""], i18n_35, [1, "text-title-10", "my-2", "px-4", "text-xs"], [1, "h-70", "relative", "w-full"], [1, "h-70", "w-full"], ["ratioChart", ""], ["class", "absolute left-0 top-0 flex h-full w-full flex-col items-center justify-center bg-white"], [1, "grid", "grid-cols-[1rem,5rem,auto,4rem]", "items-center", "gap-x-2", "gap-y-1", "px-4", "text-xs"], ["class", "z-10 absolute left-0 top-0 flex h-full w-full flex-col items-center justify-center bg-white"], [1, "absolute", "left-0", "top-0", "flex", "h-full", "w-full", "flex-col", "items-center", "justify-center", "bg-white"], ["src", "./assets/images/placeholder-1.png"], i18n_37, [1, "h-2", "w-4"], [1, "text-text-router", 3, "wClickToCopy", "copySuccessMsg"], [1, "text-title-10", "text-right"], [1, "z-10", "absolute", "left-0", "top-0", "flex", "h-full", "w-full", "flex-col", "items-center", "justify-center", "bg-white"], ["src", "./assets/images/order-ing.png", 1, "h-45", "w-60"], [1, "text-base-200"], i18n_41, ["src", "./assets/images/placeholder-1.png", 1, "h-45", "w-60"], i18n_43];
  },
  template: function LiquidityDataPage_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](0, "common-page", 0)(1, "div", 1)(2, "div", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵi18n"](3, 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](4, "div", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵi18n"](5, 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipe"](6, "date");
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelement"](7, "div", 6);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](8, "div", 7)(9, "div", 8);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelement"](10, "bs-token-with-chain-icon", 9);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](11, "div", 10)(12, "div", 11);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtext"](13);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](14, "div", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtext"](15);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelement"](16, "div", 12)(17, "bs-swap-token-chain-icon", 13);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](18, "div", 14)(19, "div", 11);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtext"](20);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]()()();
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](21, "div", 15)(22, "div", 16);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵi18n"](23, 17);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](24, "div", 18);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtext"](25);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipe"](26, "amountFormat");
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipe"](27, "amountFixed");
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](28, "div", 19)(29, "div", 20);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelement"](30, "bs-swap-token-chain-icon", 13);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](31, "div", 21);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtext"](32);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](33, "div", 22);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelement"](34, "bs-swap-token-chain-icon", 23);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](35, "div", 24);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtext"](36);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](37, "div", 25);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtext"](38);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipe"](39, "amountFormat");
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipe"](40, "amountFixed");
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](41, "div", 26);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelement"](42, "bs-swap-token-chain-icon", 9);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](43, "div", 21);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtext"](44);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](45, "div", 27);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtext"](46);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipe"](47, "amountFormat");
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipe"](48, "amountFixed");
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]()()();
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](49, "div", 28)(50, "div", 29);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵi18n"](51, 30);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](52, "div", 31);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtext"](53);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipe"](54, "amountFormat");
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipe"](55, "amountFixed");
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](56, "div", 29);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵi18n"](57, 32);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](58, "div", 31);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtext"](59);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipe"](60, "amountFormat");
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipe"](61, "amountFixed");
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](62, "div", 29);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵi18n"](63, 33);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](64, "div", 31);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtext"](65);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](66, "div", 29);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵi18n"](67, 34);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](68, "div", 31);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtext"](69);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipe"](70, "percentageTransfer");
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](71, "div", 29);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵi18n"](72, 35);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](73, "div", 31);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtext"](74);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipe"](75, "date");
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](76, "div", 36)(77, "div", 29);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵi18n"](78, 37);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](79, "div", 31);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵi18n"](80, 38);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipe"](81, "amountFormat");
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipe"](82, "amountFixed");
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](83, "div", 29);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵi18n"](84, 39);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](85, "div", 31);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵi18n"](86, 40);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](87, "div", 29);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵi18n"](88, 41);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](89, "div", 31)(90, "div");
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtext"](91);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipe"](92, "amountFormat");
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipe"](93, "amountFixed");
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](94, "div");
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtext"](95);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipe"](96, "amountFormat");
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipe"](97, "amountFixed");
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]()()()();
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](98, "div", 42)(99, "div", 43);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵi18n"](100, 44);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](101, "div", 45)(102, "div", 46);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtext"](103);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipe"](104, "date");
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelement"](105, "div", 47);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](106, "div", 48);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵi18n"](107, 49);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](108, "div", 46);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtext"](109);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipe"](110, "amountFormat");
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipe"](111, "amountFixed");
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelement"](112, "div", 50, 51);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](114, "div", 42)(115, "div", 43);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵi18n"](116, 52);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](117, "div", 53)(118, "div", 46);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtext"](119);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipe"](120, "date");
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](121, "div", 54);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelement"](122, "div", 55);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](123, "div", 48);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtext"](124);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](125, "div", 46);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtext"](126);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipe"](127, "amountFormat");
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipe"](128, "amountFixed");
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelement"](129, "div", 56);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](130, "div", 48);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtext"](131);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](132, "div", 46);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtext"](133);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipe"](134, "amountFormat");
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipe"](135, "amountFixed");
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]()()();
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelement"](136, "div", 50, 57);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](138, "div", 42)(139, "div", 43);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵi18n"](140, 58);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](141, "div", 59);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtext"](142);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipe"](143, "date");
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](144, "div", 60);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelement"](145, "div", 61, 62);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtemplate"](147, LiquidityDataPage_Conditional_147_Template, 4, 0, "div", 63);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](148, "div", 64);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵrepeaterCreate"](149, LiquidityDataPage_For_150_Template, 8, 13, null, null, _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵrepeaterTrackByIndex"]);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]()()();
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtemplate"](151, LiquidityDataPage_Conditional_151_Template, 4, 0, "div", 65)(152, LiquidityDataPage_Conditional_152_Template, 4, 0);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵproperty"]("headerBackground", "transparent")("titleClass", "!justify-start text-title-10 text-xl")("contentBackground", "#f6f7fc");
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](6);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵi18nExp"](_angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipeBind2"](6, 48, ctx.newData == null ? null : ctx.newData.createdTime, "yyyy-MM-dd HH:mm"));
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵi18nApply"](5);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](4);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵproperty"]("swapCoinName", ctx.newData == null ? null : ctx.newData.anchorCoinsName)("swapChainName", ctx.newData == null ? null : ctx.newData.anchorCoinsChainName);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtextInterpolate"](ctx.newData == null ? null : ctx.newData.anchorCoinsName);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtextInterpolate"](ctx.newData == null ? null : ctx.newData.anchorCoinsChainName);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵproperty"]("iconSize", "icon-8")("swapCoinName", ctx.newData == null ? null : ctx.newData.quoteCoinsName)("swapChainName", ctx.newData == null ? null : ctx.newData.quoteCoinsChainName);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtextInterpolate"](ctx.newData == null ? null : ctx.newData.quoteCoinsName);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](5);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtextInterpolate1"]("$ ", _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipeBind1"](26, 51, _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipeBind2"](27, 53, ctx.holdUAmount, 8)), "");
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](5);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵproperty"]("iconSize", "icon-4")("swapCoinName", ctx.newData == null ? null : ctx.newData.anchorCoinsName)("swapChainName", ctx.newData == null ? null : ctx.newData.anchorCoinsChainName);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtextInterpolate"](ctx.newData == null ? null : ctx.newData.anchorCoinsName);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵproperty"]("iconSize", "icon-4")("swapChainName", ctx.newData == null ? null : ctx.newData.anchorCoinsChainName);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtextInterpolate"](ctx.newData == null ? null : ctx.newData.anchorCoinsChainName);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipeBind1"](39, 56, _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipeBind2"](40, 58, ctx.newData == null ? null : ctx.newData.anchorCoinsAmount, 8)), " ");
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](4);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵproperty"]("swapCoinName", ctx.newData == null ? null : ctx.newData.quoteCoinsName)("swapChainName", ctx.newData == null ? null : ctx.newData.quoteCoinsChainName);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtextInterpolate"](ctx.newData == null ? null : ctx.newData.quoteCoinsName);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipeBind1"](47, 61, _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipeBind2"](48, 63, ctx.newData == null ? null : ctx.newData.quoteCoinsAmount, 8)), " ");
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](7);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipeBind1"](54, 66, _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipeBind2"](55, 68, ctx.newData == null ? null : ctx.newData.lpCoinsAmount, 8)), " ");
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](6);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipeBind1"](60, 71, _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipeBind2"](61, 73, ctx.newData == null ? null : ctx.newData.frozenLpCoinsAmount, 8)), " ");
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](6);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtextInterpolate"](ctx.newData == null ? null : ctx.newData.totalHolders);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](4);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipeBind1"](70, 76, ctx.newData == null ? null : ctx.newData.feeRatio));
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](5);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipeBind2"](75, 78, ctx.newData == null ? null : ctx.newData.createdTime, "yyyy.MM.dd HH:mm"));
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](8);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵi18nExp"](_angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipeBind1"](81, 81, _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipeBind2"](82, 83, ctx.newData == null ? null : ctx.newData.totalValue, 8)));
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵi18nApply"](80);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](4);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵi18nExp"](ctx.newData == null ? null : ctx.newData.totalExchangesTimes);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵi18nApply"](86);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](5);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtextInterpolate2"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipeBind1"](92, 86, _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipeBind2"](93, 88, ctx.newData == null ? null : ctx.newData.anchorCoinsTotalProfits, 8)), " ", ctx.newData == null ? null : ctx.newData.anchorCoinsName, " ");
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](4);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtextInterpolate2"](" + ", _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipeBind1"](96, 91, _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipeBind2"](97, 93, ctx.newData == null ? null : ctx.newData.quoteCoinsTotalProfits, 8)), " ", ctx.newData == null ? null : ctx.newData.quoteCoinsName, " ");
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](5);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵi18nExp"](ctx.newData == null ? null : ctx.newData.anchorCoinsName)(ctx.newData == null ? null : ctx.newData.quoteCoinsName);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵi18nApply"](100);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipeBind2"](104, 96, ctx.newData == null ? null : ctx.newData.createdTime, "yyyy.MM.dd"));
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](6);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipeBind1"](110, 99, _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipeBind2"](111, 101, ctx.newData == null ? null : ctx.newData.lpCoinsAmount, 8)));
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](10);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipeBind2"](120, 104, ctx.newData == null ? null : ctx.newData.createdTime, "yyyy.MM.dd"));
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](5);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtextInterpolate1"]("", ctx.newData == null ? null : ctx.newData.anchorCoinsName, " :");
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipeBind1"](127, 107, _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipeBind2"](128, 109, ctx.newData == null ? null : ctx.newData.anchorCoinsTotalProfits, 8)), " ");
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](5);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtextInterpolate1"]("", ctx.newData == null ? null : ctx.newData.quoteCoinsName, " :");
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipeBind1"](134, 112, _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipeBind2"](135, 114, ctx.newData == null ? null : ctx.newData.quoteCoinsTotalProfits, 8)), " ");
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](9);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipeBind2"](143, 117, ctx.newData == null ? null : ctx.newData.createdTime, "yyyy.MM.dd"));
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](5);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵconditional"](147, ctx.showPieChartMash ? 147 : -1);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵrepeater"](ctx.ratioDataList);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵconditional"](151, !ctx.init ? 151 : ctx.dataList.length === 0 ? 152 : -1);
    }
  },
  dependencies: [_bnqkl_framework_pipes__WEBPACK_IMPORTED_MODULE_10__.AddressHiddenPipe, _pipes_percentage_transfer_percentage_transfer_pipe__WEBPACK_IMPORTED_MODULE_7__.PercentageTransferPipe, _pipes_amount_format_amount_format_pipe__WEBPACK_IMPORTED_MODULE_6__.AmountFormatPipe, _modules_page_module__WEBPACK_IMPORTED_MODULE_2__.CommonPageModule, _libs_bnf_directives_click_to_copy_directive__WEBPACK_IMPORTED_MODULE_13__.ClickToCopyDirective, _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_14__.CommonPageComponent, _angular_common__WEBPACK_IMPORTED_MODULE_17__.DatePipe, _libs_bnf_pipes_amountFixed_amount_fixed_pipe__WEBPACK_IMPORTED_MODULE_15__.AmountFixedPipe, _angular_common__WEBPACK_IMPORTED_MODULE_17__.CommonModule, _components_swap_token_chain_icon_swap_token_chain_icon_component__WEBPACK_IMPORTED_MODULE_11__.SwapTokenChainIconComponent, _components_token_with_chain_icon_token_with_chain_icon_component__WEBPACK_IMPORTED_MODULE_1__.TokenWithnChainIconComponent],
  styles: ["[_nghost-%COMP%]   ._bginner[_ngcontent-%COMP%] {\n  background: linear-gradient(180deg, #e3e0f8 0%, #e6e0f8 15%, #faf3f7 45%, #f6f7fc 100%);\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL2FwcHMvYmZzd2FwL3NyYy9wYWdlcy9saXF1aWRpdHktZGF0YS9saXF1aWRpdHktZGF0YS5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFDRTtFQUNFLHVGQUFBO0FBQUoiLCJzb3VyY2VzQ29udGVudCI6WyI6aG9zdCB7XHJcbiAgLl9iZ2lubmVyIHtcclxuICAgIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCgxODBkZWcsICNlM2UwZjggMCUsICNlNmUwZjggMTUlLCAjZmFmM2Y3IDQ1JSwgI2Y2ZjdmYyAxMDAlKTtcclxuICB9XHJcbn1cclxuIl0sInNvdXJjZVJvb3QiOiIifQ== */"],
  changeDetection: 0
});
(0,tslib__WEBPACK_IMPORTED_MODULE_18__.__decorate)([LiquidityDataPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_18__.__metadata)("design:type", Object)], LiquidityDataPage.prototype, "showPieChartMash", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_18__.__decorate)([LiquidityDataPage.OnReady(), (0,tslib__WEBPACK_IMPORTED_MODULE_18__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_18__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_18__.__metadata)("design:returntype", Promise)], LiquidityDataPage.prototype, "initEcharts", null);
(0,tslib__WEBPACK_IMPORTED_MODULE_18__.__decorate)([LiquidityDataPage.States(1), (0,tslib__WEBPACK_IMPORTED_MODULE_18__.__metadata)("design:type", Object)], LiquidityDataPage.prototype, "newData", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_18__.__decorate)([LiquidityDataPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_18__.__metadata)("design:type", Object)], LiquidityDataPage.prototype, "holdUAmount", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_18__.__decorate)([LiquidityDataPage.States(1), (0,tslib__WEBPACK_IMPORTED_MODULE_18__.__metadata)("design:type", Array)], LiquidityDataPage.prototype, "ratioDataList", void 0);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (LiquidityDataPage);

/***/ }),

/***/ 34913:
/*!***************************************************************************!*\
  !*** ./apps/bfswap/src/services/liquidity-user/liquidity-user.service.ts ***!
  \***************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   LiquidityUserService: () => (/* binding */ LiquidityUserService)
/* harmony export */ });
/* harmony import */ var D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 52542);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 61039);
/* harmony import */ var _services_bs_fetch_bs_fetch_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ~services/bs-fetch/bs-fetch.service */ 92925);
/* harmony import */ var _bnqkl_framework_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @bnqkl/framework/core */ 63563);

var _class;




/** 池子相关接口 */
class LiquidityUserService {
  constructor() {
    /** 日志 */
    this.console = (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.inject)(_bnqkl_framework_core__WEBPACK_IMPORTED_MODULE_2__.LoggerService).createLoggerForService(this, 'liquidity-user-service');
    /** fetch服务 */
    this.fetch = (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.inject)(_services_bs_fetch_bs_fetch_service__WEBPACK_IMPORTED_MODULE_1__.SwapFetch);
    /** 后端接口 */
    this.SERVER_API = {
      /** 获取用户持仓列表 POST */
      getLiquidityUserPositionList: this.fetch.APP_URL('/bnqklswap/liquidity/user/position/list'),
      /** 获取用户资产列表 POST */
      getLiquidityUserAssetsList: this.fetch.APP_URL('/bnqklswap/liquidity/user/assets/list'),
      /** 获取用户流动性持仓 */
      getUserLiquidityHolding: this.fetch.APP_URL('/bnqklswap/liquidity/user/position/list'),
      /** 获取用户持仓详情 */
      getUserPositionDetail: this.fetch.APP_URL('/bnqklswap/liquidity/user/position/details'),
      /** 获取用户持仓比例 */
      getUserPositionPercent: this.fetch.APP_URL('/bnqklswap/liquidity/user/position/percent'),
      /** 获取用户流动性持仓冻结数量 */
      getUserLiquidityLocked: this.fetch.APP_URL('/bnqklswap/liquidity/user/position/locked'),
      /** 获取用户流动性持仓冻结列表 */
      getUserLiquidityLockedList: this.fetch.APP_URL('/bnqklswap/liquidity/user/position/locked/list')
    };
  }
  /** 获取用户锁仓量列表 */
  getUserLiquidityLockedList(options) {
    var _this = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      try {
        return _this.fetch.post(_this.SERVER_API.getUserLiquidityLockedList, options);
        // 默认数据
      } catch (error) {
        _this.console.log('getUserLiquidityLockedList', error);
        return;
      }
    })();
  }
  /** 获取用户持仓详情 */
  getUserPositionDetail(options) {
    try {
      return this.fetch.post(this.SERVER_API.getUserPositionDetail, options);
      // 默认数据
    } catch (error) {
      this.console.log('getUserPositionDetail', error);
      return;
    }
  }
  /** 获取用户锁仓量 */
  getUserLiquidityLocked(options) {
    var _this2 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      try {
        return _this2.fetch.post(_this2.SERVER_API.getUserLiquidityLocked, options);
        // 默认数据
      } catch (error) {
        _this2.console.log('getUserLiquidityLocked', error);
        return;
      }
    })();
  }
  /** 获取用户持仓比例 */
  getUserPositionPercent(options) {
    try {
      return this.fetch.post(this.SERVER_API.getUserPositionPercent, options);
      // 默认数据
    } catch (error) {
      this.console.log('getUserPositionPercent', error);
      return;
    }
  }
  /** 获取用户持仓列表 */
  getLiquidityUserPostionList(options) {
    try {
      return this.fetch.post(this.SERVER_API.getLiquidityUserPositionList, options);
      // 默认数据
    } catch (error) {
      this.console.log('getLiquidityUserPostionList', error);
      return;
    }
  }
  /** 获取用户资产列表 */
  getLiquidityUserAssetsList(options) {
    try {
      return this.fetch.post(this.SERVER_API.getLiquidityUserAssetsList, options);
      // 默认数据
    } catch (error) {
      this.console.log('getLiquidityUserPostionList', error);
      return;
    }
  }
  /** 获取用户流动性持仓 */
  getUserLiquidityHolding(options) {
    var _this3 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      try {
        return _this3.fetch.post(_this3.SERVER_API.getUserLiquidityHolding, options);
        // 默认数据
      } catch (error) {
        _this3.console.log('getUserLiquidityHolding', error);
        return;
      }
    })();
  }
}
_class = LiquidityUserService;
_class.ɵfac = function LiquidityUserService_Factory(t) {
  return new (t || _class)();
};
_class.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineInjectable"]({
  token: _class,
  factory: _class.ɵfac,
  providedIn: 'root'
});

/***/ })

}]);
//# sourceMappingURL=apps_bfswap_src_pages_liquidity-data_liquidity-data_component_ts.js.map