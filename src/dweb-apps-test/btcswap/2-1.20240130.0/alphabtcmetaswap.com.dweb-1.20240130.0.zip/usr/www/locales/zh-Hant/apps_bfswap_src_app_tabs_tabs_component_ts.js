(self["webpackChunkbfswap"] = self["webpackChunkbfswap"] || []).push([["apps_bfswap_src_app_tabs_tabs_component_ts"],{

/***/ 88063:
/*!****************************************************!*\
  !*** ./apps/bfswap/src/app/tabs/tabs.component.ts ***!
  \****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   TabsComponent: () => (/* binding */ TabsComponent),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 52542);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! tslib */ 90505);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! @angular/common */ 6729);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! @angular/core */ 61039);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! @angular/router */ 56776);
/* harmony import */ var _bnqkl_framework_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @bnqkl/framework/core */ 63563);
/* harmony import */ var _bnqkl_framework_directives__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @bnqkl/framework/directives */ 11100);
/* harmony import */ var _bnqkl_framework_helpers__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @bnqkl/framework/helpers */ 12169);
/* harmony import */ var _bnqkl_framework_plugins_splash_screen__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @bnqkl/framework/plugins/splash-screen */ 71739);
/* harmony import */ var _components_icon_icon_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../components/icon/icon.component */ 18840);
/* harmony import */ var _components_connect_wallet_panel_connect_wallet_penel_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ~components/connect-wallet-panel/connect-wallet-penel.component */ 43551);
/* harmony import */ var _modules_page_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ~modules/page.module */ 16381);
/* harmony import */ var _pages_home_pages_swap_swap_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ~pages/home/pages/swap/swap.component */ 79010);
/* harmony import */ var _pages_home_pages_market_market_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ~pages/home/pages/market/market.component */ 12425);
/* harmony import */ var _services_color_color_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ~services/color/color.service */ 71044);
/* harmony import */ var _pages_mine_pages_my_liquidity_holdings_my_liquidity_holdings_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ~pages/mine/pages/my-liquidity-holdings/my-liquidity-holdings.component */ 23627);
/* harmony import */ var _pages_mine_pages_my_assets_my_assets_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ~pages/mine/pages/my-assets/my-assets.component */ 59920);
/* harmony import */ var _services_wallet_wallet_service__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ~services/wallet/wallet.service */ 54275);
/* harmony import */ var _components_connect_wallet_panel_connect_wallet_panel_type__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ~components/connect-wallet-panel/connect-wallet-panel.type */ 9218);
/* harmony import */ var _services_wallet_wallet_config__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ~services/wallet/wallet.config */ 57839);
/* harmony import */ var _components_wallet_info_panel_wallet_info_panel_component__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ~components/wallet-info-panel/wallet-info-panel.component */ 5514);
/* harmony import */ var _components_version_info_panel_version_info_panel_component__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ~components/version-info-panel/version-info-panel.component */ 54838);
/* harmony import */ var _bnqkl_framework_controllers__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @bnqkl/framework/controllers */ 47919);
/* harmony import */ var _pages_liquidity_detail_liquidity_detail_component__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ~pages/liquidity-detail/liquidity-detail.component */ 28684);
/* harmony import */ var _bnqkl_util_web_extends_promise__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! @bnqkl/util-web/extends-promise */ 87778);
/* harmony import */ var _libs_bnf_modules_bottom_sheet_components_bottom_sheet_component__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! ../../../../../libs/bnf/modules/bottom-sheet/components/bottom-sheet.component */ 94072);
/* harmony import */ var _libs_bnf_directives_ob_size_directive__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! ../../../../../libs/bnf/directives/ob-size.directive */ 46501);
/* harmony import */ var _libs_bnf_directives_tab_directive__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! ../../../../../libs/bnf/directives/tab.directive */ 384);

var _class;































const _c0 = ["bottomNavSize"];
const _c1 = ["panel"];
const _c2 = ["linkContainer"];
function TabsComponent_Conditional_8_Template(rf, ctx) {
  if (rf & 1) {
    const _r11 = _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵelementStart"](0, "div", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵlistener"]("click", function TabsComponent_Conditional_8_Template_div_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵrestoreView"](_r11);
      const ctx_r10 = _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵresetView"](ctx_r10.openWalletInfoSheet());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵelement"](1, "bs-icon", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵelementStart"](2, "div", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵi18n"](3, 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵelement"](4, "bs-icon", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵproperty"]("name", ctx_r1.walletIcon);
    _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵi18nExp"](ctx_r1.connectedWallet.walletName);
    _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵi18nApply"](3);
  }
}
function TabsComponent_Conditional_9_Template(rf, ctx) {
  if (rf & 1) {
    const _r13 = _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵelementStart"](0, "button", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵlistener"]("click", function TabsComponent_Conditional_9_Template_button_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵrestoreView"](_r13);
      const ctx_r12 = _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵresetView"](ctx_r12.openSwapWalletSheet());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵelement"](1, "bs-icon", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵelementStart"](2, "div", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵi18n"](3, 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵelementEnd"]()();
  }
}
function TabsComponent_div_13_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵelement"](0, "div", 26, 27);
  }
}
function TabsComponent_div_17_Template(rf, ctx) {
  if (rf & 1) {
    const _r19 = _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵelementStart"](0, "div", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵlistener"]("click", function TabsComponent_div_17_Template_div_click_0_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵrestoreView"](_r19);
      const i_r17 = restoredCtx.index;
      const ctx_r18 = _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵresetView"](ctx_r18.selectTab(i_r17));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵelement"](1, "bs-icon", 29);
    _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵelementStart"](2, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const link_r16 = ctx.$implicit;
    const ctx_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵproperty"]("name", (ctx_r6.currLink == null ? null : ctx_r6.currLink.index) === link_r16.index ? link_r16.icon_hover : link_r16.icon_normal);
    _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵclassMapInterpolate1"]("text-xxs -mt-1  ", (ctx_r6.currLink == null ? null : ctx_r6.currLink.index) === link_r16.index ? "text-primary" : "text-subtitle-2", "");
    _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵtextInterpolate1"](" ", link_r16.label_text, " ");
  }
}
function TabsComponent_ng_template_19_Template(rf, ctx) {
  if (rf & 1) {
    const _r21 = _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵelementStart"](0, "bs-wallet-info-panel", 30);
    _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵlistener"]("returnValue$", function TabsComponent_ng_template_19_Template_bs_wallet_info_panel_returnValue__0_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵrestoreView"](_r21);
      const ctx_r20 = _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵresetView"](ctx_r20.onReconnectWallet($event));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r7 = _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵproperty"]("walletIcon", ctx_r7.walletIcon)("connectedWallet", ctx_r7.walletInfoSheet.connectedWallet);
  }
}
function TabsComponent_ng_template_21_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵelement"](0, "bs-version-info-panel");
  }
}
function TabsComponent_ng_template_23_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵelement"](0, "bs-connect-wallet-panel-page", 31);
  }
  if (rf & 2) {
    const ctx_r9 = _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵproperty"]("connectType", ctx_r9.selectWalletSheet.conncetType)("presetWallets", ctx_r9.selectWalletSheet.presetWallets);
  }
}
const _c9 = a0 => ({
  "--page-safe-area-inset-bottom": a0
});
/**
 * 主体导航页面
 */
class TabsComponent extends (0,_bnqkl_framework_core__WEBPACK_IMPORTED_MODULE_1__.MixinBrowser)(_modules_page_module__WEBPACK_IMPORTED_MODULE_7__.CommonPageBase) {
  constructor() {
    super(...arguments);
    /** 减少日志, 如果需要, 补充 logger+=`w-tabs=enable`  */
    this.__console_internal_config__ = {
      default: 'warn',
      matchMode: 'strict'
    };
    /** 已连接的钱包服务 */
    this.walletService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_24__.inject)(_services_wallet_wallet_service__WEBPACK_IMPORTED_MODULE_13__.WalletService);
    /** 底部导航栏的高度 */
    this.bottomNavHeight = '0px';
    /** 所有的 tab 链接 */
    this.links = [{
      index: 0,
      href: 'market',
      icon_normal: 'icon-market-normal',
      icon_hover: 'icon-market-hover',
      label_text: "Quote",
      component: _pages_home_pages_market_market_component__WEBPACK_IMPORTED_MODULE_9__.MarketPage,
      ref: undefined
    }, {
      index: 1,
      href: 'swap',
      icon_normal: 'icon-swap-normal',
      icon_hover: 'icon-swap-hover',
      label_text: "Swap",
      component: _pages_home_pages_swap_swap_component__WEBPACK_IMPORTED_MODULE_8__.SwapPage,
      ref: undefined
    }, {
      index: 2,
      href: 'pool',
      icon_normal: 'icon-pools-normal',
      icon_hover: 'icon-pools-hover',
      label_text: '合约池',
      component: _pages_mine_pages_my_liquidity_holdings_my_liquidity_holdings_component__WEBPACK_IMPORTED_MODULE_11__["default"],
      ref: undefined
    }, {
      index: 3,
      href: 'assets',
      icon_normal: 'icon-assets-normal',
      icon_hover: 'icon-assets-hover',
      label_text: '钱包',
      component: _pages_mine_pages_my_assets_my_assets_component__WEBPACK_IMPORTED_MODULE_12__["default"],
      ref: undefined
    }];
    /** 钱包图标 */
    this.walletIcon = undefined;
    /** 连接的钱包 */
    this.connectedWallet = this.resolveData.conncetedWallet;
    /** 钱包面板重新连接 */
    this.tryToOpenSwapWalletSheet = false;
    /** 钱包选择器的数据 */
    this.selectWalletSheet = {
      is_open: false,
      conncetType: _components_connect_wallet_panel_connect_wallet_panel_type__WEBPACK_IMPORTED_MODULE_14__.CONNECT_TYPE.CONNECT_WALLET,
      presetWallets: []
    };
    /** 钱包信息面板的数据 */
    this.walletInfoSheet = {
      open: false,
      connectedWallet: undefined
    };
    /** 版本信息面板 */
    this.versionInfoSheet = {
      open: false
    };
    /** 颜色服务 */
    this._colorService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_24__.inject)(_services_color_color_service__WEBPACK_IMPORTED_MODULE_10__.ColorService);
    /** 池子详情页面返回 */
    this.poolDetailPageReturnController = new _bnqkl_framework_controllers__WEBPACK_IMPORTED_MODULE_18__.PageReturnController(this, _pages_liquidity_detail_liquidity_detail_component__WEBPACK_IMPORTED_MODULE_19__["default"]);
  }
  /** 监听底部导航栏的大小 */
  set bottomNavSize(obSize) {
    this.takeUntilDestroy(obSize.resized$).subscribe(size => {
      this.bottomNavHeight = size.borderHeight + 'px';
    });
  }
  /** 连接钱包事件 */
  onConnectWallet(data) {
    var _this = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      if (data.walletName) {
        _this.connectedWallet = data;
        _this.console.info('connected to wallet', data);
      }
    })();
  }
  dataInit() {
    var _this2 = this;
    // 监听钱包变化
    this.connectWallet$ = this.walletService.wallletConnected_subject.subscribe( /*#__PURE__*/function () {
      var _ref = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (data) {
        if (data === undefined) {
          return;
        }
        _this2.connectedWallet = data.wallet;
        _this2.handleWalletIcon();
        return;
      });
      return function (_x) {
        return _ref.apply(this, arguments);
      };
    }());
  }
  /** 初始化页面实例 */
  //  private _initLinkRef(link: $Link, linkContainer = this.linkContainerList.get(this.links.indexOf(link))) {
  //   if (link.ref === undefined && link.component !== undefined) {
  //     // eslint-disable-next-line @typescript-eslint/no-explicit-any
  //     link.ref = this._panelVcRef.createComponent(link.component as Type<any>);
  //     if (link.ref.instance instanceof MyAssetsPage) {
  //       link.ref.instance.supportChainList = this.resolveData.supportChainList;
  //     }
  //     this.renderer2.appendChild(linkContainer?.nativeElement, link.ref.location.nativeElement);
  //     link.ref.instance.requestUpdate();
  //     this.cdRef.detectChanges();
  //   }
  // }
  /** 清除订阅监听 */
  unsubscribe() {
    this.console.log('清除 订阅');
    this.connectWallet$ && this.connectWallet$.unsubscribe();
    //  this.walletService.allSubscribes.delete('SwapPage');
  }

  initLink() {
    var _this3 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      /// @TODO 根据URL来变更
      _this3.currLink = _this3.selectTab(0);
      /// 在有空的时候把各个页面初始化出来
      for (const link of _this3.links) {
        yield (0,_bnqkl_framework_helpers__WEBPACK_IMPORTED_MODULE_3__.$requestIdleCallback)();
        _this3._initLinkRef(link);
      }
    })();
  }
  /** 打开钱包信息 */
  openWalletInfoSheet() {
    this.walletInfoSheet.connectedWallet = this.connectedWallet;
    this.walletInfoSheet.open = true;
  }
  hideSplashScreen() {
    _bnqkl_framework_plugins_splash_screen__WEBPACK_IMPORTED_MODULE_4__.SplashScreen.hide();
  }
  /** 打开钱包连接选择弹窗 */
  openSwapWalletSheet() {
    var _this4 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const {
        selectWalletSheet
      } = _this4;
      if (selectWalletSheet.is_open) {
        return;
      }
      _this4.selectWalletSheet.presetWallets = yield _this4.walletService.getPresetWallet();
      selectWalletSheet.is_open = true;
    })();
  }
  /** 关闭钱包面板弹窗 */
  onWalletPanelClose() {
    this.console.log('关闭钱包面板弹窗');
    if (this.tryToOpenSwapWalletSheet) {
      this.openSwapWalletSheet();
      // 使用一次便重置
      this.tryToOpenSwapWalletSheet = false;
    }
  }
  /** 重新打开钱包连接弹窗以重新连接 */
  onReconnectWallet(WalletInfoReturn) {
    if (WalletInfoReturn.reconnectWallet) {
      this.console.info('重新打开钱包连接弹窗以重新连接');
      this.tryToOpenSwapWalletSheet = true;
    }
  }
  /** 配置主题风格 */
  initTheme() {
    this.nav.storeState({
      theme: this._colorService.transform('primary')
    });
  }
  /** 处理钱包图标 */
  handleWalletIcon() {
    const wallet = _services_wallet_wallet_config__WEBPACK_IMPORTED_MODULE_15__.PRESETS_WALLET_CONFIG.find(item => {
      var _this$connectedWallet;
      return item.name === ((_this$connectedWallet = this.connectedWallet) === null || _this$connectedWallet === void 0 ? void 0 : _this$connectedWallet.walletName);
    });
    if (wallet) {
      this.walletIcon = wallet.iconName;
    }
  }
  /**
   * 切换 tab
   */
  selectTab(index) {
    var _this5 = this;
    const linkContainer = this.linkContainerList.get(index);
    if (linkContainer === undefined) {
      return;
    }
    const link = this.links[index];
    if (this.currLink !== link) {
      this.prevLink = this.currLink;
      this.currLink = link;
      this._initLinkRef(link, linkContainer);
      (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
        _this5.panelAnimationsStart();
        yield (0,_bnqkl_framework_helpers__WEBPACK_IMPORTED_MODULE_3__.$requestAnimationFrame)();
        _this5.panelAnimationsDone();
      })();
    }
    return link;
  }
  /** 初始化页面实例 */
  _initLinkRef(link, linkContainer = this.linkContainerList.get(this.links.indexOf(link))) {
    if (link.ref === undefined && link.component !== undefined) {
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      link.ref = this._panelVcRef.createComponent(link.component);
      // this.renderer2.appendChild(linkContainer?.nativeElement, link.ref.location.nativeElement);
      // link.ref.instance.requestUpdate();
      // link.ref = this._panelVcRef.createComponent(link.component as Type<any>);
      if (link.ref.instance instanceof _pages_mine_pages_my_assets_my_assets_component__WEBPACK_IMPORTED_MODULE_12__["default"]) {
        link.ref.instance.supportChainList = this.resolveData.supportChainList;
      }
      this.renderer2.appendChild(linkContainer === null || linkContainer === void 0 ? void 0 : linkContainer.nativeElement, link.ref.location.nativeElement);
      link.ref.instance.requestUpdate();
      this.cdRef.detectChanges();
    }
  }
  /** 监听tab-panel动画开始 */
  panelAnimationsStart() {
    var _this$currLink;
    this.console.info('animation start');
    const page = (_this$currLink = this.currLink) === null || _this$currLink === void 0 || (_this$currLink = _this$currLink.ref) === null || _this$currLink === void 0 ? void 0 : _this$currLink.instance;
    // const prePage = this.prevLink?.ref?.instance;
    // page?.ngPageWillEnter();
    page === null || page === void 0 || page.ngOnResume('tab');
    // prePage?.ngPageWillLeave();
  }
  /** 监听tab-panel动画结束 */
  panelAnimationsDone() {
    var _this$currLink2, _page$pageTheme$, _this$prevLink;
    this.console.info('animation done');
    /// 跟随子页面的风格
    const page = (_this$currLink2 = this.currLink) === null || _this$currLink2 === void 0 || (_this$currLink2 = _this$currLink2.ref) === null || _this$currLink2 === void 0 ? void 0 : _this$currLink2.instance;
    const pageTheme = page === null || page === void 0 || (_page$pageTheme$ = page.pageTheme$) === null || _page$pageTheme$ === void 0 ? void 0 : _page$pageTheme$.value;
    if (pageTheme !== undefined) {
      var _this$pageTheme$;
      (_this$pageTheme$ = this.pageTheme$) === null || _this$pageTheme$ === void 0 || _this$pageTheme$.next(pageTheme);
    }
    // page?.ngPageDidEnter();
    const prePage = (_this$prevLink = this.prevLink) === null || _this$prevLink === void 0 || (_this$prevLink = _this$prevLink.ref) === null || _this$prevLink === void 0 ? void 0 : _this$prevLink.instance;
    // prePage?.ngPageDidLeave();
    prePage === null || prePage === void 0 || prePage.ngOnPause('tab');
  }
  /** 将页面的生命周期向内传递给tab-panel的页面 */
  ngOnPause(reason) {
    var _this$currLink3;
    super.ngOnPause(reason);
    (_this$currLink3 = this.currLink) === null || _this$currLink3 === void 0 || (_this$currLink3 = _this$currLink3.ref) === null || _this$currLink3 === void 0 || (_this$currLink3 = _this$currLink3.instance) === null || _this$currLink3 === void 0 || _this$currLink3.ngOnPause(reason);
  }
  /** 将页面的生命周期向内传递给tab-panel的页面 */
  ngOnResume(reason) {
    var _this$currLink4;
    super.ngOnResume(reason);
    (_this$currLink4 = this.currLink) === null || _this$currLink4 === void 0 || (_this$currLink4 = _this$currLink4.ref) === null || _this$currLink4 === void 0 || (_this$currLink4 = _this$currLink4.instance) === null || _this$currLink4 === void 0 || _this$currLink4.ngOnResume(reason);
    this.pageReturnPromise && this.pageReturnPromise.resolve(true);
  }
  /** 打开版本信息 */
  openVersionSheet() {
    this.versionInfoSheet.open = true;
  } /** 页面返回 */
  /** 初始化池子详情返回值监听 */
  poolDetailPageReturn() {
    var _this6 = this;
    /** 监听池子返回成功返回 打开提现弹窗 */
    this.poolDetailPageReturnController.pageReturn$.subscribe( /*#__PURE__*/function () {
      var _ref3 = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (data) {
        var _this6$links$1$ref;
        _this6.console.log(data);
        _this6.pageReturnPromise = new _bnqkl_util_web_extends_promise__WEBPACK_IMPORTED_MODULE_20__.PromiseOut();
        yield _this6.pageReturnPromise.promise;
        yield (0,_bnqkl_framework_helpers__WEBPACK_IMPORTED_MODULE_3__.$requestAnimationFrame)();
        ((_this6$links$1$ref = _this6.links[1].ref) === null || _this6$links$1$ref === void 0 ? void 0 : _this6$links$1$ref.instance).handleRouterParams(data.swapSelectedAsset);
        _this6.selectTab(1);
      });
      return function (_x2) {
        return _ref3.apply(this, arguments);
      };
    }());
  }
}
_class = TabsComponent;
_class.ɵfac = /*@__PURE__*/(() => {
  let ɵTabsComponent_BaseFactory;
  return function TabsComponent_Factory(t) {
    return (ɵTabsComponent_BaseFactory || (ɵTabsComponent_BaseFactory = _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵgetInheritedFactory"](_class)))(t || _class);
  };
})();
_class.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵdefineComponent"]({
  type: _class,
  selectors: [["bs-tabs"]],
  viewQuery: function TabsComponent_Query(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵviewQuery"](_c0, 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵviewQuery"](_c1, 5, _angular_core__WEBPACK_IMPORTED_MODULE_24__.ViewContainerRef);
      _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵviewQuery"](_c2, 5, _angular_core__WEBPACK_IMPORTED_MODULE_24__.ElementRef);
    }
    if (rf & 2) {
      let _t;
      _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵloadQuery"]()) && (ctx.bottomNavSize = _t.first);
      _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵloadQuery"]()) && (ctx._panelVcRef = _t.first);
      _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵloadQuery"]()) && (ctx.linkContainerList = _t);
    }
  },
  standalone: true,
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵInheritDefinitionFeature"], _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵStandaloneFeature"], _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵHostDirectivesFeature"]([_bnqkl_framework_core__WEBPACK_IMPORTED_MODULE_1__.ThemeStorageDirective])],
  decls: 24,
  vars: 11,
  consts: () => {
    let i18n_3;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_BTCSWAP$$APPS_BFSWAP_SRC_APP_TABS_TABS_COMPONENT_TS_4 = goog.getMsg("BTCSwap");
      i18n_3 = MSG_EXTERNAL_BTCSWAP$$APPS_BFSWAP_SRC_APP_TABS_TABS_COMPONENT_TS_4;
    } else {
      i18n_3 = "BTCSwap";
    }
    let i18n_5;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_BTCSWAP$$APPS_BFSWAP_SRC_APP_TABS_TABS_COMPONENT_TS__6 = goog.getMsg("{$interpolation}", {
        "interpolation": "\uFFFD0\uFFFD"
      }, {
        original_code: {
          "interpolation": "{{ connectedWallet.walletName }}"
        }
      });
      i18n_5 = MSG_EXTERNAL_BTCSWAP$$APPS_BFSWAP_SRC_APP_TABS_TABS_COMPONENT_TS__6;
    } else {
      i18n_5 = "" + "\uFFFD0\uFFFD" + "";
    }
    let i18n_7;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_4415732127162599444$$APPS_BFSWAP_SRC_APP_TABS_TABS_COMPONENT_TS__8 = goog.getMsg("\u8FDE\u63A5\u94B1\u5305");
      i18n_7 = MSG_EXTERNAL_4415732127162599444$$APPS_BFSWAP_SRC_APP_TABS_TABS_COMPONENT_TS__8;
    } else {
      i18n_7 = "\u8FDE\u63A5\u94B1\u5305";
    }
    return [["wObSize", "", 1, "grid-in-[wallet]", "z-[3]", 2, "padding-top", "var(--page-safe-area-inset-top)"], ["navSize", "obSize"], [1, "flex", "h-16", "items-center", "justify-between", "px-4"], [1, "flex", "items-center", 3, "click"], ["src", "../../assets/images/logo.png", 1, "h-6", "w-6"], [1, "ml-1", "text-base", "text-white"], i18n_3, ["name", "icon-chevron-down-small", 1, "text-subtitle-2", "text-xl"], ["class", "flex h-8 items-center rounded-full bg-white/[0.16] px-1"], ["wTabGroup", "", 1, "grid-in-[wallet/wallet/tabs/tabs]", "_wallet", "z-[2]", "grid", "flex-grow", "grid-flow-col", "overflow-x-hidden", 2, "padding-top", "calc(var(--page-safe-area-inset-top) + 4.125rem)", 3, "ngStyle", "selectedIndex", "scrollSmooth", "selectedIndexChange$"], ["panel", ""], ["class", "w-cqw-100 rounded-t-5 block h-full overflow-hidden", "wTab", "", 4, "ngFor", "ngForOf"], ["wObSize", "", 1, "grid-in-[tabs]", "border-border-10", "z-[3]", "border-t", "bg-white", 2, "padding-bottom", "var(--env-safe-area-inset-bottom)"], ["bottomNavSize", "obSize"], [1, "grid", "grid-cols-4"], ["class", "flex flex-col items-center justify-center", 3, "click", 4, "ngFor", "ngForOf"], [3, "isOpen", "isOpenChange", "closed$"], [3, "isOpen", "isOpenChange"], [1, "flex", "h-8", "items-center", "rounded-full", "bg-white/[0.16]", "px-1", 3, "click"], [1, "text-2xl", 3, "name"], [1, "ml-2", "text-xs", "text-white"], i18n_5, [1, "duibs-btn", "duibs-btn-ghost", "min-h-8", "bg-primary", "flex", "h-8", "items-center", "rounded-full", "text-white", 3, "click"], ["name", "icon-link", 1, "text-base", "text-white"], [1, "text-sm"], i18n_7, ["wTab", "", 1, "w-cqw-100", "rounded-t-5", "block", "h-full", "overflow-hidden"], ["linkContainer", ""], [1, "flex", "flex-col", "items-center", "justify-center", 3, "click"], [1, "text-[2.5rem]", 3, "name"], [3, "walletIcon", "connectedWallet", "returnValue$"], [3, "connectType", "presetWallets"]];
  },
  template: function TabsComponent_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵelementStart"](0, "nav", 0, 1)(2, "div", 2)(3, "div", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵlistener"]("click", function TabsComponent_Template_div_click_3_listener() {
        return ctx.openVersionSheet();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵelement"](4, "img", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵelementStart"](5, "div", 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵi18n"](6, 6);
      _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵelement"](7, "bs-icon", 7);
      _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵtemplate"](8, TabsComponent_Conditional_8_Template, 5, 2, "div", 8)(9, TabsComponent_Conditional_9_Template, 4, 0);
      _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵelementStart"](10, "main", 9);
      _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵlistener"]("selectedIndexChange$", function TabsComponent_Template_main_selectedIndexChange__10_listener($event) {
        return ctx.selectTab($event);
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵelementContainer"](11, null, 10);
      _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵtemplate"](13, TabsComponent_div_13_Template, 2, 0, "div", 11);
      _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵelementStart"](14, "nav", 12, 13)(16, "div", 14);
      _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵtemplate"](17, TabsComponent_div_17_Template, 4, 5, "div", 15);
      _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵelementStart"](18, "common-bottom-sheet", 16);
      _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵlistener"]("isOpenChange", function TabsComponent_Template_common_bottom_sheet_isOpenChange_18_listener($event) {
        return ctx.walletInfoSheet.open = $event;
      })("closed$", function TabsComponent_Template_common_bottom_sheet_closed__18_listener() {
        return ctx.onWalletPanelClose();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵtemplate"](19, TabsComponent_ng_template_19_Template, 1, 2, "ng-template");
      _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵelementStart"](20, "common-bottom-sheet", 17);
      _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵlistener"]("isOpenChange", function TabsComponent_Template_common_bottom_sheet_isOpenChange_20_listener($event) {
        return ctx.versionInfoSheet.open = $event;
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵtemplate"](21, TabsComponent_ng_template_21_Template, 1, 0, "ng-template");
      _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵelementStart"](22, "common-bottom-sheet", 17);
      _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵlistener"]("isOpenChange", function TabsComponent_Template_common_bottom_sheet_isOpenChange_22_listener($event) {
        return ctx.selectWalletSheet.is_open = $event;
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵtemplate"](23, TabsComponent_ng_template_23_Template, 1, 2, "ng-template");
      _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵelementEnd"]();
    }
    if (rf & 2) {
      let tmp_2_0;
      _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵadvance"](8);
      _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵconditional"](8, ctx.connectedWallet ? 8 : 9);
      _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵproperty"]("ngStyle", _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵpureFunction1"](9, _c9, ctx.bottomNavHeight))("selectedIndex", (tmp_2_0 = ctx.currLink == null ? null : ctx.currLink.index) !== null && tmp_2_0 !== undefined ? tmp_2_0 : 0)("scrollSmooth", false);
      _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵproperty"]("ngForOf", ctx.links);
      _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵadvance"](4);
      _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵproperty"]("ngForOf", ctx.links);
      _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵproperty"]("isOpen", ctx.walletInfoSheet.open);
      _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵproperty"]("isOpen", ctx.versionInfoSheet.open);
      _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵproperty"]("isOpen", ctx.selectWalletSheet.is_open);
    }
  },
  dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_25__.CommonModule, _angular_common__WEBPACK_IMPORTED_MODULE_25__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_25__.NgStyle, _modules_page_module__WEBPACK_IMPORTED_MODULE_7__.CommonPageModule, _libs_bnf_modules_bottom_sheet_components_bottom_sheet_component__WEBPACK_IMPORTED_MODULE_21__.BottomSheetComponent, _libs_bnf_directives_ob_size_directive__WEBPACK_IMPORTED_MODULE_22__.ObSizeDirective, _libs_bnf_directives_tab_directive__WEBPACK_IMPORTED_MODULE_23__.TabGroupDirective, _libs_bnf_directives_tab_directive__WEBPACK_IMPORTED_MODULE_23__.TabDirective, _components_icon_icon_component__WEBPACK_IMPORTED_MODULE_5__.IconComponent, _angular_router__WEBPACK_IMPORTED_MODULE_26__.RouterModule, _components_connect_wallet_panel_connect_wallet_penel_component__WEBPACK_IMPORTED_MODULE_6__.ConnectWalletPanelPage, _components_wallet_info_panel_wallet_info_panel_component__WEBPACK_IMPORTED_MODULE_16__.WalletInfoPanelComponent, _components_version_info_panel_version_info_panel_component__WEBPACK_IMPORTED_MODULE_17__.VersionInfoPanelComponent],
  styles: ["@charset \"UTF-8\";\n[_nghost-%COMP%] {\n  width: 100%;\n  height: 100%;\n  display: grid;\n  \n\n\n\n\n  grid: auto 1fr auto/1fr;\n  grid-template-areas: \"wallet\" \"panel\" \"tabs\";\n}\n[_nghost-%COMP%]   ._active-border[_ngcontent-%COMP%]{\n  position: absolute;\n  left: 50%;\n  top: 50%;\n  height: 3rem;\n  width: 3rem;\n  transform-origin: center;\n  border-radius: 9999px;\n  border-width: 1px;\n  border-style: solid;\n  border-color: rgb(255 255 255 / 0.5);\n  transform: translate(-50%, -50%);\n}\n[_nghost-%COMP%]   ._wallet[_ngcontent-%COMP%] {\n  background-repeat: no-repeat;\n  background-position: left top;\n  background-size: auto 7.625rem;\n  background-image: linear-gradient(162deg, #000000 0%, #640ff3 100%);\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL2FwcHMvYmZzd2FwL3NyYy9hcHAvdGFicy90YWJzLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLGdCQUFnQjtBQUFoQjtFQUNFLFdBQUE7RUFDQSxZQUFBO0VBQ0EsYUFBQTtFQUNBOzs7TUFBQTtFQUlBLHVCQUFBO0VBRUEsNENBQUE7QUFDRjtBQUVJO0VBQUEsa0JBQUE7RUFBQSxTQUFBO0VBQUEsUUFBQTtFQUFBLFlBQUE7RUFBQSxXQUFBO0VBQUEsd0JBQUE7RUFBQSxxQkFBQTtFQUFBLGlCQUFBO0VBQUEsbUJBQUE7RUFBQSxvQ0FBQTtFQUNBO0FBREE7QUFJRjtFQUNFLDRCQUFBO0VBQ0EsNkJBQUE7RUFDQSw4QkFBQTtFQUNBLG1FQUFBO0FBQUoiLCJzb3VyY2VzQ29udGVudCI6WyI6aG9zdCB7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgaGVpZ2h0OiAxMDAlO1xyXG4gIGRpc3BsYXk6IGdyaWQ7XHJcbiAgLyoqXHJcbiAgICAgKiByb3dzIMOowqHCjMOpwqvCmCDDpsKcwonDpMK4wqTDpMK4wqrDpcKMwrrDpcKfwp8gIDFmciBhdXRvXHJcbiAgICAgKiBjb2x1bW5zIMOlwojCl8Olwq7CvSDDpsKcwonDpMK4woDDpMK4wqrDpcKMwrrDpcKfwp8gMWZyXHJcbiAgICAgKi9cclxuICBncmlkOiBhdXRvIDFmciBhdXRvIC8gMWZyO1xyXG4gIC8vIGdyaWQtdGVtcGxhdGUtcm93czogYXV0byA1MHB4O1xyXG4gIGdyaWQtdGVtcGxhdGUtYXJlYXM6ICd3YWxsZXQnICdwYW5lbCcgJ3RhYnMnO1xyXG5cclxuICAuX2FjdGl2ZS1ib3JkZXIge1xyXG4gICAgQGFwcGx5IGFic29sdXRlIGxlZnQtMS8yIHRvcC0xLzIgaC0xMiB3LTEyIG9yaWdpbi1jZW50ZXIgcm91bmRlZC1mdWxsIGJvcmRlciBib3JkZXItc29saWQgYm9yZGVyLXdoaXRlLzUwO1xyXG4gICAgdHJhbnNmb3JtOiB0cmFuc2xhdGUoLTUwJSwgLTUwJSk7XHJcbiAgfVxyXG5cclxuICAuX3dhbGxldCB7XHJcbiAgICBiYWNrZ3JvdW5kLXJlcGVhdDogbm8tcmVwZWF0O1xyXG4gICAgYmFja2dyb3VuZC1wb3NpdGlvbjogbGVmdCB0b3A7XHJcbiAgICBiYWNrZ3JvdW5kLXNpemU6IGF1dG8gNy42MjVyZW07XHJcbiAgICBiYWNrZ3JvdW5kLWltYWdlOiBsaW5lYXItZ3JhZGllbnQoMTYyZGVnLCAjMDAwMDAwIDAlLCAjNjQwZmYzIDEwMCUpO1xyXG4gIH1cclxufVxyXG4iXSwic291cmNlUm9vdCI6IiJ9 */"],
  changeDetection: 0
});
(0,tslib__WEBPACK_IMPORTED_MODULE_27__.__decorate)([TabsComponent.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_27__.__metadata)("design:type", Object)], TabsComponent.prototype, "bottomNavHeight", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_27__.__decorate)([TabsComponent.OnInit(), (0,tslib__WEBPACK_IMPORTED_MODULE_27__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_27__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_27__.__metadata)("design:returntype", void 0)], TabsComponent.prototype, "dataInit", null);
(0,tslib__WEBPACK_IMPORTED_MODULE_27__.__decorate)([TabsComponent.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_27__.__metadata)("design:type", Object)], TabsComponent.prototype, "currLink", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_27__.__decorate)([TabsComponent.OnDestroy(), (0,tslib__WEBPACK_IMPORTED_MODULE_27__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_27__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_27__.__metadata)("design:returntype", void 0)], TabsComponent.prototype, "unsubscribe", null);
(0,tslib__WEBPACK_IMPORTED_MODULE_27__.__decorate)([TabsComponent.AfterViewInit(), (0,tslib__WEBPACK_IMPORTED_MODULE_27__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_27__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_27__.__metadata)("design:returntype", Promise)], TabsComponent.prototype, "initLink", null);
(0,tslib__WEBPACK_IMPORTED_MODULE_27__.__decorate)([TabsComponent.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_27__.__metadata)("design:type", Object)], TabsComponent.prototype, "walletIcon", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_27__.__decorate)([TabsComponent.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_27__.__metadata)("design:type", Object)], TabsComponent.prototype, "connectedWallet", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_27__.__decorate)([TabsComponent.OnInit(), (0,tslib__WEBPACK_IMPORTED_MODULE_27__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_27__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_27__.__metadata)("design:returntype", void 0)], TabsComponent.prototype, "hideSplashScreen", null);
(0,tslib__WEBPACK_IMPORTED_MODULE_27__.__decorate)([TabsComponent.States(1), (0,tslib__WEBPACK_IMPORTED_MODULE_27__.__metadata)("design:type", Object)], TabsComponent.prototype, "selectWalletSheet", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_27__.__decorate)([TabsComponent.States(1), (0,tslib__WEBPACK_IMPORTED_MODULE_27__.__metadata)("design:type", Object)], TabsComponent.prototype, "walletInfoSheet", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_27__.__decorate)([TabsComponent.States(1), (0,tslib__WEBPACK_IMPORTED_MODULE_27__.__metadata)("design:type", Object)], TabsComponent.prototype, "versionInfoSheet", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_27__.__decorate)([TabsComponent.OnInit(), (0,tslib__WEBPACK_IMPORTED_MODULE_27__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_27__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_27__.__metadata)("design:returntype", void 0)], TabsComponent.prototype, "initTheme", null);
(0,tslib__WEBPACK_IMPORTED_MODULE_27__.__decorate)([TabsComponent.OnInit(), (0,tslib__WEBPACK_IMPORTED_MODULE_27__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_27__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_27__.__metadata)("design:returntype", void 0)], TabsComponent.prototype, "handleWalletIcon", null);
(0,tslib__WEBPACK_IMPORTED_MODULE_27__.__decorate)([TabsComponent.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_27__.__metadata)("design:type", Object)], TabsComponent.prototype, "poolDetailPageReturnController", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_27__.__decorate)([TabsComponent.OnInit(), (0,tslib__WEBPACK_IMPORTED_MODULE_27__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_27__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_27__.__metadata)("design:returntype", void 0)], TabsComponent.prototype, "poolDetailPageReturn", null);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (TabsComponent);

/***/ }),

/***/ 16091:
/*!***********************************************************************************!*\
  !*** ./apps/bfswap/src/components/bs-numeric-input/bs-numeric-input.component.ts ***!
  \***********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   NumericInputComponent: () => (/* binding */ NumericInputComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! tslib */ 90505);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 61039);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/forms */ 7820);
/* harmony import */ var bignumber_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! bignumber.js */ 61994);
/* harmony import */ var _utils_keys__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./utils/keys */ 77068);
/* harmony import */ var _utils_utils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./utils/utils */ 56853);
/* harmony import */ var _components_bs_numeric_keyboard_bs_numeric_keyboard_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ~components/bs-numeric-keyboard/bs-numeric-keyboard.component */ 52766);
/* harmony import */ var _modules_page_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ~modules/page.module */ 16381);
/* harmony import */ var _bnqkl_wallet_base_services__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @bnqkl/wallet-base/services */ 62479);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/common */ 6729);
var _class;











function NumericInputComponent_span_4_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "span", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const value_r4 = ctx.$implicit;
    const i_r5 = ctx.index;
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵattribute"]("data-index", i_r5);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate1"](" ", value_r4, " ");
  }
}
function NumericInputComponent_span_5_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](0, "span", 8);
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵattribute"]("data-index", ctx_r1.ks == null ? null : ctx_r1.ks.rawValue == null ? null : ctx_r1.ks.rawValue.length);
  }
}
function NumericInputComponent_div_6_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "div", 9)(1, "span", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate1"](" ", ctx_r2.kp == null ? null : ctx_r2.kp.placeholder, " ");
  }
}
function NumericInputComponent_div_7_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](0, "div", 11);
  }
  if (rf & 2) {
    const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵstyleProp"]("background", ctx_r3.ks == null ? null : ctx_r3.ks.cursorColor);
  }
}
/** 正则小数 */
const RNumber = /^\d*(?:\.\d*)?$/;
/** 整数 */
const RTel = /^\d*$/;
/** 键盘事件 */
const KeyboardCenter = (() => {
  let activeInput;
  return {
    register(input) {
      this.unregister(undefined);
      activeInput = input;
      document.addEventListener('touchend', this.unregister, false);
    },
    unregister(e) {
      if (activeInput) {
        if (e && (activeInput.ks["inputElement"].contains(e.target) || activeInput.ks["keyboardElement"].contains(e.target))) {
          return;
        }
        activeInput.closeKeyboard();
        activeInput = null;
        document.removeEventListener('touchend', this.unregister, false);
      }
      return;
    }
  };
})();
/** 选项 */
const Options = {
  type: 'number',
  value: '',
  autofocus: false,
  disabled: false,
  readonly: false,
  maxlength: 255,
  maxDecimals: 255,
  name: '',
  placeholder: '',
  format: '^',
  layout: 'string',
  entertext: "Confirm"
};
/** 键盘输入 */
class NumericInputComponent extends _modules_page_module__WEBPACK_IMPORTED_MODULE_4__.CommonPageBase {
  constructor() {
    super(...arguments);
    /** 聚焦 */
    this._autofocus = Options.autofocus;
    /** 禁用 */
    this._disabled = Options.disabled;
    /** 只读 */
    this._readonly = Options.readonly;
    /** 值 */
    this._value = Options.value;
    /** 激活颜色 */
    this.activeColor = '#3B3B3B';
    /** 是否聚焦 */
    this.isFocus = false;
    /** 最大值 */
    this.maxValue = "";
    /** 类型 */
    this.type = Options.type;
    /** 显示值 */
    this.value = Options.value;
    /** 最大长度 */
    this.maxlength = Options.maxlength;
    /** 精确度 */
    this.maxDecimals = Options.maxDecimals;
    /** 名称 */
    this.name = Options.name;
    /** 输入提示 */
    this.placeholder = Options.placeholder;
    /** 格式 */
    this.format = Options.format;
    /** 布局 */
    this.layout = Options.layout;
    /** 确认文本 */
    this.entertext = Options.entertext;
    /** 聚焦事件 */
    this.inputFocus = new _angular_core__WEBPACK_IMPORTED_MODULE_6__.EventEmitter();
    /**  失焦事件 */
    this.inputBlur = new _angular_core__WEBPACK_IMPORTED_MODULE_6__.EventEmitter();
    /** 确认事件 */
    this.enterpress = new _angular_core__WEBPACK_IMPORTED_MODULE_6__.EventEmitter();
    /** 绑定变更 */
    this.ngModelChange = new _angular_core__WEBPACK_IMPORTED_MODULE_6__.EventEmitter();
    /** 变更 */
    this._onChange = () => {};
    /** dom */
    this.element = (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.inject)(_angular_core__WEBPACK_IMPORTED_MODULE_6__.ElementRef);
    /** appref */
    this.appRef = (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.inject)(_angular_core__WEBPACK_IMPORTED_MODULE_6__.ApplicationRef);
    /** 创建dom */
    this.componentFactoryResolver = (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.inject)(_angular_core__WEBPACK_IMPORTED_MODULE_6__.ComponentFactoryResolver);
  }
  /** 自动聚焦 */
  get autofocus() {
    return this._autofocus;
  }
  set autofocus(value) {
    this._autofocus = (0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__.coerceBooleanProperty)(value);
    this.cdRef.detectChanges();
  }
  /** 禁用 */
  get disabled() {
    return this._disabled;
  }
  set disabled(value) {
    this._disabled = (0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__.coerceBooleanProperty)(value);
    this.cdRef.detectChanges();
  }
  /** 只读 */
  get readonly() {
    return this._readonly;
  }
  set readonly(value) {
    this._readonly = (0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__.coerceBooleanProperty)(value);
    this.cdRef.detectChanges();
  }
  /** 双向绑定 */
  get ngModel() {
    return this._value;
  }
  set ngModel(value) {
    if (this.ks && this.ks["value"] !== value) {
      const rawValue = value.toString().split('');
      const cursorPos = rawValue.length;
      this.set('rawValue', rawValue);
      this.set('cursorPos', cursorPos);
    }
    this._value = value;
    this.cdRef.detectChanges();
  }
  /** 初始化 */
  onInit() {
    const resolvedOptions = {};
    Object.keys(Options).forEach(key => {
      resolvedOptions[key] = Reflect.get(this, key);
    });
    this.init(resolvedOptions);
    this.cdRef.detectChanges();
  }
  /** 销毁 */
  onDestroy() {
    KeyboardCenter.unregister(null);
  }
  /** 试图初始化后 */
  afterViewInit() {
    this.onMounted(this.element.nativeElement.querySelector('.numeric-input'));
  }
  /** 变更检查 */
  ngAfterViewChecked() {
    this.onUpdated();
    this.cdRef.detectChanges();
  }
  /** 激活的索引 */
  trackByIndex(index) {
    return index;
  }
  /** 写入值 */
  writeValue(value) {
    if (typeof value === "undefined" || value === null) {
      this._value = '';
    } else {
      this._value = value;
    }
    this.cdRef.detectChanges();
  }
  /** 重写函数 */
  registerOnChange(fn) {
    this._onChange = fn;
  }
  /** 触碰 */
  registerOnTouched() {}
  /** 聚焦事件 */
  onFocus(e) {
    e.stopPropagation();
    this.openKeyboard();
    const ele = e.target;
    if (ele) {
      const cursorPos = +(ele.dataset['index'] || this.ks["rawValue"].length);
      this.set('cursorPos', isNaN(cursorPos) ? this.ks["rawValue"].length : cursorPos);
      this.cdRef.detectChanges();
    }
  }
  /** 事件处理 */
  dispatch(event, payload) {
    switch (event) {
      case 'focus':
        this.inputFocus.emit();
        break;
      case 'blur':
        this.inputBlur.emit();
        break;
      case 'enterpress':
        this.enterpress.emit();
        break;
      case 'input':
        this.ngModelChange.emit(payload);
        break;
    }
    this.cdRef.detectChanges();
  }
  /** 创建键盘 */
  createKeyboard(el, options, events, callback) {
    const componentRef = this.componentFactoryResolver.resolveComponentFactory(_components_bs_numeric_keyboard_bs_numeric_keyboard_component__WEBPACK_IMPORTED_MODULE_3__.BsNumericKeyboardComponent).create(this.injector);
    Object.assign(componentRef.instance, options);
    componentRef.instance.ngOnInit();
    for (const event in events) {
      Reflect.get(componentRef.instance, event).subscribe(events[event]);
    }
    this.appRef.attachView(componentRef.hostView);
    const element = componentRef.hostView.rootNodes[0];
    el.appendChild(element);
    callback(componentRef);
    this.cdRef.detectChanges();
  }
  /** 销毁键盘 */
  destroyKeyboard(el, keyboard) {
    keyboard.destroy();
    this.appRef.detachView(keyboard.hostView);
    this.cdRef.detectChanges();
  }
  /** 初始化 */
  init(options) {
    let formatFn = options['format'];
    if (typeof formatFn === 'string') {
      formatFn = (rformat => val => rformat.test(val))(new RegExp(options['format']));
    }
    const value = options['value'];
    const rawValue = value.toString().split('');
    const cursorPos = rawValue.length;
    this.kp = options;
    this.ks = {
      formatFn,
      value,
      rawValue,
      cursorPos,
      cursorColor: null,
      cursorActive: false,
      keyboard: null,
      inputElement: null,
      keyboardElement: null
    };
    this.cdRef.detectChanges();
  }
  /** 写入 */
  set(key, value) {
    Reflect.set(this.ks, key, value);
    this.cdRef.detectChanges();
  }
  /** 鼠标 */
  onMounted(el) {
    this.set('inputElement', el);
    this.set('cursorColor', this.activeColor);
    if (this.kp["autofocus"] && (this.kp["readonly"] === undefined || this.kp["readonly"] === null) && (this.kp["disabled"] === undefined || this.kp["disabled"] === null)) {
      setTimeout(() => this.openKeyboard(), 500);
    }
  }
  /** 更新 */
  onUpdated() {
    this.moveCursor();
    this.cdRef.detectChanges();
  }
  /** slider值变更事件 */
  sliderValueChange(v) {
    if (isNaN(+this.maxValue) === false) {
      const chainService = this.injectorForceGet(_bnqkl_wallet_base_services__WEBPACK_IMPORTED_MODULE_5__.ChainService);
      const maxValue = chainService.getPrecisionInteger(this.maxValue, 8);
      const amount = new bignumber_js__WEBPACK_IMPORTED_MODULE_0__["default"](String(BigInt(maxValue) * BigInt(v) / BigInt(100))).dividedBy(1e8).toFixed(8, 1);
      this.dispatch('input', amount);
    }
  }
  /** 输入值 */
  input(key) {
    const {
      type,
      maxlength,
      maxDecimals
    } = this.kp;
    const {
      rawValue,
      cursorPos,
      formatFn
    } = this.ks;
    const input = inputKey => {
      const isAdd = typeof inputKey !== 'undefined';
      const newRawValue = rawValue.slice();
      if (isAdd) {
        newRawValue.splice(cursorPos, 0, inputKey);
      } else {
        newRawValue.splice(cursorPos - 1, 1);
      }
      let newValue = newRawValue.join('');
      if (formatFn(newValue)) {
        if (type === 'number') {
          if (RNumber.test(newValue) === false) {
            return;
          }
          if (isNaN(parseFloat(newValue))) {
            newValue = '';
          }
        } else if (newValue.length > maxlength || type === 'tel' && RTel.test(newValue) === false) {
          return;
        }
        /// 判断小数位
        const _vs = newValue.split(".");
        if (_vs[1] && _vs[1].length > maxDecimals) {
          return;
        }
        this.set('value', newValue);
        this.set('rawValue', newRawValue);
        this.set('cursorPos', isAdd ? cursorPos + 1 : cursorPos - 1);
        this.dispatch('input', newValue);
      }
    };
    switch (key) {
      case _utils_keys__WEBPACK_IMPORTED_MODULE_1__.BLANK:
        break;
      case _utils_keys__WEBPACK_IMPORTED_MODULE_1__.ESC:
        this.closeKeyboard();
        break;
      case _utils_keys__WEBPACK_IMPORTED_MODULE_1__.ENTER:
        this.closeKeyboard();
        this.dispatch('enterpress');
        break;
      case _utils_keys__WEBPACK_IMPORTED_MODULE_1__.DEL:
        if (cursorPos > 0) {
          input(undefined);
        }
        break;
      case _utils_keys__WEBPACK_IMPORTED_MODULE_1__.DOT:
      case _utils_keys__WEBPACK_IMPORTED_MODULE_1__.ZERO:
      case _utils_keys__WEBPACK_IMPORTED_MODULE_1__.ONE:
      case _utils_keys__WEBPACK_IMPORTED_MODULE_1__.TWO:
      case _utils_keys__WEBPACK_IMPORTED_MODULE_1__.THREE:
      case _utils_keys__WEBPACK_IMPORTED_MODULE_1__.FOUR:
      case _utils_keys__WEBPACK_IMPORTED_MODULE_1__.FIVE:
      case _utils_keys__WEBPACK_IMPORTED_MODULE_1__.SIX:
      case _utils_keys__WEBPACK_IMPORTED_MODULE_1__.SEVEN:
      case _utils_keys__WEBPACK_IMPORTED_MODULE_1__.EIGHT:
      case _utils_keys__WEBPACK_IMPORTED_MODULE_1__.NINE:
      default:
        input(key);
        break;
    }
    this.cdRef.detectChanges();
  }
  /** 移动 */
  moveCursor() {
    if (this.ks["cursorActive"]) {
      const elCursor = this.ks['inputElement'].querySelector('.numeric-input-cursor');
      const elText = this.ks['inputElement'].querySelector('.numeric-input-text');
      const elCharactor = elText.querySelector(`span:nth-child(${this.ks['cursorPos']})`);
      if (elCharactor === undefined || elCharactor === null) {
        elCursor.style.transform = 'translateX(0)';
        elText.style.transform = 'translateX(0)';
        return;
      }
      const cursorOffset = elCharactor.offsetLeft + elCharactor.offsetWidth;
      const maxVisibleWidth = elText.parentNode.offsetWidth;
      elCursor.style.transform = `translateX(${Math.min(maxVisibleWidth - 1, cursorOffset)}px)`;
      elText.style.transform = `translateX(${Math.min(0, maxVisibleWidth - cursorOffset)}px)`;
      this.cdRef.detectChanges();
    }
    return;
  }
  /** 打开键盘 */
  openKeyboard() {
    if (this.ks['keyboard']) {
      return;
    }
    const elContainer = document.createElement('div');
    const elShadow = document.createElement('div');
    const elKeyboard = document.createElement('div');
    elContainer.className = 'numeric-keyboard-actionsheet';
    elContainer.appendChild(elShadow);
    elContainer.appendChild(elKeyboard);
    document.body.appendChild(elContainer);
    const inputHandler = this.input.bind(this);
    const sliderValueChange = this.sliderValueChange.bind(this);
    this.createKeyboard(elKeyboard, {
      layout: this.kp["layout"] || this.kp['type'],
      entertext: this.kp['entertext'],
      numericInput: this.hostElement
    }, {
      press: inputHandler,
      longPress: inputHandler,
      sliderValueChange: sliderValueChange
    }, keyboard => this.set('keyboard', keyboard));
    (0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__.animate)((timestamp, frame, frames) => {
      elKeyboard.style.position = 'fixed';
      elKeyboard.style.bottom = '0';
      elKeyboard.style.left = '0';
      elKeyboard.style.transform = `translateY(${(frames - frame) / frames * 100}%)`;
    }, () => {}, 10);
    this.set('keyboardElement', elKeyboard);
    this.set('cursorActive', true);
    this.set('cursorPos', this.ks['rawValue'].length);
    this.isFocus = true;
    this.dispatch('focus');
    KeyboardCenter.register(this);
    this.cdRef.detectChanges();
  }
  /** 关闭键盘 */
  closeKeyboard() {
    if (this.ks['keyboard']) {
      const keyboard = this.ks['keyboard'];
      const elKeyboard = this.ks['keyboardElement'];
      (0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__.animate)((timestamp, frame, frames) => {
        elKeyboard.style.transform = `translateY(${frame / frames * 100}%)`;
      }, () => {
        setTimeout(() => {
          this.destroyKeyboard(elKeyboard, keyboard);
          document.body.removeChild(elKeyboard.parentNode);
        }, 50);
      }, 10);
      this.set('keyboard', null);
      this.set('keyboardElement', null);
      this.set('cursorActive', false);
      this.set('cursorPos', 0);
      this.isFocus = false;
      this.dispatch('blur');
      KeyboardCenter.unregister(null);
      this.cdRef.detectChanges();
    }
    return;
  }
}
_class = NumericInputComponent;
_class.ɵfac = /*@__PURE__*/(() => {
  let ɵNumericInputComponent_BaseFactory;
  return function NumericInputComponent_Factory(t) {
    return (ɵNumericInputComponent_BaseFactory || (ɵNumericInputComponent_BaseFactory = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵgetInheritedFactory"](_class)))(t || _class);
  };
})();
_class.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdefineComponent"]({
  type: _class,
  selectors: [["bs-numeric-input"]],
  inputs: {
    activeColor: "activeColor",
    autofocus: "autofocus",
    disabled: "disabled",
    readonly: "readonly",
    ngModel: "ngModel",
    maxValue: "maxValue",
    type: "type",
    value: "value",
    maxlength: "maxlength",
    maxDecimals: "maxDecimals",
    name: "name",
    placeholder: "placeholder",
    format: "format",
    layout: "layout",
    entertext: "entertext"
  },
  outputs: {
    inputFocus: "inputFocus",
    inputBlur: "inputBlur",
    enterpress: "enterpress",
    ngModelChange: "ngModelChange"
  },
  standalone: true,
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵProvidersFeature"]([{
    provide: _angular_forms__WEBPACK_IMPORTED_MODULE_7__.NG_VALUE_ACCESSOR,
    useExisting: (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.forwardRef)(() => _class),
    multi: true
  }]), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵInheritDefinitionFeature"], _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵStandaloneFeature"]],
  decls: 8,
  vars: 9,
  consts: [[1, "numeric-input-container"], [1, "numeric-input", 3, "touchend"], [1, "numeric-input-text", "flex"], ["class", "input-text", 4, "ngFor", "ngForOf", "ngForTrackBy"], ["class", "input-text w-1", 4, "ngIf"], ["class", "numeric-input-placeholder", 4, "ngIf"], ["class", "numeric-input-cursor blinking-cursor", 3, "background", 4, "ngIf"], [1, "input-text"], [1, "input-text", "w-1"], [1, "numeric-input-placeholder"], [1, "typo-placeholder", "font-normal", "text-base-200"], [1, "numeric-input-cursor", "blinking-cursor"]],
  template: function NumericInputComponent_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "div", 0)(1, "div", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("touchend", function NumericInputComponent_Template_div_touchend_1_listener($event) {
        return ctx.onFocus($event);
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](2, "div")(3, "div", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](4, NumericInputComponent_span_4_Template, 2, 2, "span", 3)(5, NumericInputComponent_span_5_Template, 1, 1, "span", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](6, NumericInputComponent_div_6_Template, 3, 1, "div", 5)(7, NumericInputComponent_div_7_Template, 1, 2, "div", 6);
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()();
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵclassProp"]("readonly", ctx.kp == null ? null : ctx.kp.readonly)("disabled", ctx.kp == null ? null : ctx.kp.disabled);
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngForOf", ctx.ks == null ? null : ctx.ks.rawValue)("ngForTrackBy", ctx.trackByIndex);
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", (ctx.ks == null ? null : ctx.ks.rawValue == null ? null : ctx.ks.rawValue.length) !== 0);
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", (ctx.ks == null ? null : ctx.ks.rawValue == null ? null : ctx.ks.rawValue.length) === 0);
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx.ks == null ? null : ctx.ks.cursorActive);
    }
  },
  dependencies: [_modules_page_module__WEBPACK_IMPORTED_MODULE_4__.CommonPageModule, _angular_common__WEBPACK_IMPORTED_MODULE_8__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_8__.NgIf],
  styles: [".numeric-input-container[_ngcontent-%COMP%] {\n  display: flex;\n  text-align: left;\n}\n.numeric-input-container[_ngcontent-%COMP%]   .numeric-input[_ngcontent-%COMP%] {\n  display: block;\n  background: transparent;\n  width: 100%;\n  height: 100%;\n  padding: 0;\n  text-align: inherit;\n}\n.numeric-input-container[_ngcontent-%COMP%]   .numeric-input.readonly[_ngcontent-%COMP%], .numeric-input-container[_ngcontent-%COMP%]   .numeric-input.disabled[_ngcontent-%COMP%] {\n  opacity: 0.5;\n  pointer-events: none;\n}\n.numeric-input-container[_ngcontent-%COMP%]   .numeric-input[_ngcontent-%COMP%]    > div[_ngcontent-%COMP%] {\n  position: relative;\n  overflow: hidden;\n  height: 100%;\n}\n.numeric-input-container[_ngcontent-%COMP%]   .numeric-input-placeholder[_ngcontent-%COMP%] {\n  color: #757575;\n}\n.numeric-input-container[_ngcontent-%COMP%]   .numeric-input-text[_ngcontent-%COMP%] {\n  width: 10000%;\n}\n.numeric-input-container[_ngcontent-%COMP%]   .numeric-input-cursor[_ngcontent-%COMP%] {\n  pointer-events: none;\n  position: absolute;\n  left: 1px;\n  top: 1px;\n  width: 1px;\n  height: 90%;\n  animation: _ngcontent-%COMP%_numeric-input-cursor 1s steps(1) infinite;\n}\n@keyframes _ngcontent-%COMP%_numeric-input-cursor {\n  50% {\n    background-color: transparent;\n  }\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL2FwcHMvYmZzd2FwL3NyYy9jb21wb25lbnRzL2JzLW51bWVyaWMtaW5wdXQvYnMtbnVtZXJpYy1pbnB1dC5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBRTtFQUdFLGFBQUE7RUFDQSxnQkFBQTtBQUNKO0FBQ0k7RUFDRSxjQUFBO0VBQ0EsdUJBQUE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtFQUNBLFVBQUE7RUFDQSxtQkFBQTtBQUNOO0FBQ007RUFFRSxZQUFBO0VBQ0Esb0JBQUE7QUFBUjtBQUdNO0VBQ0Usa0JBQUE7RUFDQSxnQkFBQTtFQUNBLFlBQUE7QUFEUjtBQUtJO0VBQ0UsY0FBQTtBQUhOO0FBTUk7RUFDRSxhQUFBO0FBSk47QUFXSTtFQUNFLG9CQUFBO0VBQ0Esa0JBQUE7RUFDQSxTQUFBO0VBQ0EsUUFBQTtFQUNBLFVBQUE7RUFDQSxXQUFBO0VBRUEsb0RBQUE7QUFUTjtBQWtCSTtFQUNFO0lBQ0UsNkJBQUE7RUFYTjtBQUNGIiwic291cmNlc0NvbnRlbnQiOlsiICAubnVtZXJpYy1pbnB1dC1jb250YWluZXIge1xyXG4gICAgZGlzcGxheTogLXdlYmtpdC1ib3g7XHJcbiAgICBkaXNwbGF5OiAtbXMtZmxleGJveDtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICB0ZXh0LWFsaWduOiBsZWZ0O1xyXG5cclxuICAgIC5udW1lcmljLWlucHV0IHtcclxuICAgICAgZGlzcGxheTogYmxvY2s7XHJcbiAgICAgIGJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xyXG4gICAgICB3aWR0aDogMTAwJTtcclxuICAgICAgaGVpZ2h0OiAxMDAlO1xyXG4gICAgICBwYWRkaW5nOiAwO1xyXG4gICAgICB0ZXh0LWFsaWduOiBpbmhlcml0O1xyXG5cclxuICAgICAgJi5yZWFkb25seSxcclxuICAgICAgJi5kaXNhYmxlZCB7XHJcbiAgICAgICAgb3BhY2l0eTogMC41O1xyXG4gICAgICAgIHBvaW50ZXItZXZlbnRzOiBub25lO1xyXG4gICAgICB9XHJcblxyXG4gICAgICA+ZGl2IHtcclxuICAgICAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgICAgICAgb3ZlcmZsb3c6IGhpZGRlbjtcclxuICAgICAgICBoZWlnaHQ6IDEwMCU7XHJcbiAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICAubnVtZXJpYy1pbnB1dC1wbGFjZWhvbGRlciB7XHJcbiAgICAgIGNvbG9yOiAjNzU3NTc1O1xyXG4gICAgfVxyXG5cclxuICAgIC5udW1lcmljLWlucHV0LXRleHQge1xyXG4gICAgICB3aWR0aDogMTAwMDAlO1xyXG5cclxuICAgICAgLy8gLmlucHV0LXRleHQge1xyXG4gICAgICAvLyAgIGxldHRlci1zcGFjaW5nOiAtMi42cHg7XHJcbiAgICAgIC8vIH1cclxuICAgIH1cclxuXHJcbiAgICAubnVtZXJpYy1pbnB1dC1jdXJzb3Ige1xyXG4gICAgICBwb2ludGVyLWV2ZW50czogbm9uZTtcclxuICAgICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgICBsZWZ0OiAxcHg7XHJcbiAgICAgIHRvcDogMXB4O1xyXG4gICAgICB3aWR0aDogMXB4O1xyXG4gICAgICBoZWlnaHQ6IDkwJTtcclxuICAgICAgLXdlYmtpdC1hbmltYXRpb246IG51bWVyaWMtaW5wdXQtY3Vyc29yIDFzIHN0ZXBzKDEpIGluZmluaXRlO1xyXG4gICAgICBhbmltYXRpb246IG51bWVyaWMtaW5wdXQtY3Vyc29yIDFzIHN0ZXBzKDEpIGluZmluaXRlO1xyXG4gICAgfVxyXG5cclxuICAgIEAtd2Via2l0LWtleWZyYW1lcyBudW1lcmljLWlucHV0LWN1cnNvciB7XHJcbiAgICAgIDUwJSB7XHJcbiAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogdHJhbnNwYXJlbnQ7XHJcbiAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBAa2V5ZnJhbWVzIG51bWVyaWMtaW5wdXQtY3Vyc29yIHtcclxuICAgICAgNTAlIHtcclxuICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiB0cmFuc3BhcmVudDtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH0iXSwic291cmNlUm9vdCI6IiJ9 */"]
});
(0,tslib__WEBPACK_IMPORTED_MODULE_9__.__decorate)([NumericInputComponent.OnInit(), (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__metadata)("design:returntype", void 0)], NumericInputComponent.prototype, "onInit", null);
(0,tslib__WEBPACK_IMPORTED_MODULE_9__.__decorate)([NumericInputComponent.OnDestroy(), (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__metadata)("design:returntype", void 0)], NumericInputComponent.prototype, "onDestroy", null);
(0,tslib__WEBPACK_IMPORTED_MODULE_9__.__decorate)([NumericInputComponent.OnReady(), (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__metadata)("design:returntype", void 0)], NumericInputComponent.prototype, "afterViewInit", null);

/***/ }),

/***/ 77068:
/*!*******************************************************************!*\
  !*** ./apps/bfswap/src/components/bs-numeric-input/utils/keys.ts ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   BLANK: () => (/* binding */ BLANK),
/* harmony export */   DEL: () => (/* binding */ DEL),
/* harmony export */   DOT: () => (/* binding */ DOT),
/* harmony export */   EIGHT: () => (/* binding */ EIGHT),
/* harmony export */   ENTER: () => (/* binding */ ENTER),
/* harmony export */   ESC: () => (/* binding */ ESC),
/* harmony export */   FIVE: () => (/* binding */ FIVE),
/* harmony export */   FOUR: () => (/* binding */ FOUR),
/* harmony export */   NINE: () => (/* binding */ NINE),
/* harmony export */   ONE: () => (/* binding */ ONE),
/* harmony export */   SEVEN: () => (/* binding */ SEVEN),
/* harmony export */   SIX: () => (/* binding */ SIX),
/* harmony export */   THREE: () => (/* binding */ THREE),
/* harmony export */   TWO: () => (/* binding */ TWO),
/* harmony export */   ZERO: () => (/* binding */ ZERO)
/* harmony export */ });
/** 0 */
const ZERO = '0';
/** 1 */
const ONE = '1';
/** 2 */
const TWO = '2';
/** 3 */
const THREE = '3';
/** 4 */
const FOUR = '4';
/** 5 */
const FIVE = '5';
/** 6 */
const SIX = '6';
/** 7 */
const SEVEN = '7';
/** 8 */
const EIGHT = '8';
/** 9 */
const NINE = '9';
/** export const DOT = '.'; */
const DOT = '.';
/** del */
const DEL = 'del';
/** enter */
const ENTER = 'enter';
/** esc */
const ESC = 'esc';
/** export const BLANK = ''; */
const BLANK = '';

/***/ }),

/***/ 80125:
/*!**********************************************************************!*\
  !*** ./apps/bfswap/src/components/bs-numeric-input/utils/layouts.ts ***!
  \**********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Layouts: () => (/* binding */ Layouts)
/* harmony export */ });
/* harmony import */ var _keys__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./keys */ 77068);

/**
 * 数字布局
 * */
const NumberLayout = [[{
  key: _keys__WEBPACK_IMPORTED_MODULE_0__.ONE
}, {
  key: _keys__WEBPACK_IMPORTED_MODULE_0__.TWO
}, {
  key: _keys__WEBPACK_IMPORTED_MODULE_0__.THREE
}, {
  key: _keys__WEBPACK_IMPORTED_MODULE_0__.ENTER,
  rowspan: 3,
  color: '!text-white'
}], [{
  key: _keys__WEBPACK_IMPORTED_MODULE_0__.FOUR
}, {
  key: _keys__WEBPACK_IMPORTED_MODULE_0__.FIVE
}, {
  key: _keys__WEBPACK_IMPORTED_MODULE_0__.SIX
}], [{
  key: _keys__WEBPACK_IMPORTED_MODULE_0__.SEVEN
}, {
  key: _keys__WEBPACK_IMPORTED_MODULE_0__.EIGHT
}, {
  key: _keys__WEBPACK_IMPORTED_MODULE_0__.NINE
}], [{
  key: _keys__WEBPACK_IMPORTED_MODULE_0__.DOT
}, {
  key: _keys__WEBPACK_IMPORTED_MODULE_0__.ZERO
}, {
  key: _keys__WEBPACK_IMPORTED_MODULE_0__.DEL,
  iconName: 'icon-delete-rectangle',
  iconColor: 'text-black-10'
}, {
  key: _keys__WEBPACK_IMPORTED_MODULE_0__.ESC,
  rowspan: 1,
  iconName: 'icon-chevron-down-big',
  color: '!text-primary'
}]];
/**
 * 电话布局
 * */
const TelLayout = [[{
  key: _keys__WEBPACK_IMPORTED_MODULE_0__.ONE
}, {
  key: _keys__WEBPACK_IMPORTED_MODULE_0__.TWO
}, {
  key: _keys__WEBPACK_IMPORTED_MODULE_0__.THREE
}], [{
  key: _keys__WEBPACK_IMPORTED_MODULE_0__.FOUR
}, {
  key: _keys__WEBPACK_IMPORTED_MODULE_0__.FIVE
}, {
  key: _keys__WEBPACK_IMPORTED_MODULE_0__.SIX
}], [{
  key: _keys__WEBPACK_IMPORTED_MODULE_0__.SEVEN
}, {
  key: _keys__WEBPACK_IMPORTED_MODULE_0__.EIGHT
}, {
  key: _keys__WEBPACK_IMPORTED_MODULE_0__.NINE
}], [{
  key: _keys__WEBPACK_IMPORTED_MODULE_0__.DEL
}, {
  key: _keys__WEBPACK_IMPORTED_MODULE_0__.ZERO
}, {
  key: _keys__WEBPACK_IMPORTED_MODULE_0__.ENTER
}]];
/**
 * 手机布局
 * */
const PhoneLayout = [[{
  key: _keys__WEBPACK_IMPORTED_MODULE_0__.ONE
}, {
  key: _keys__WEBPACK_IMPORTED_MODULE_0__.TWO
}, {
  key: _keys__WEBPACK_IMPORTED_MODULE_0__.THREE
}, {
  key: _keys__WEBPACK_IMPORTED_MODULE_0__.DEL
}], [{
  key: _keys__WEBPACK_IMPORTED_MODULE_0__.FOUR
}, {
  key: _keys__WEBPACK_IMPORTED_MODULE_0__.FIVE
}, {
  key: _keys__WEBPACK_IMPORTED_MODULE_0__.SIX
}, {
  key: _keys__WEBPACK_IMPORTED_MODULE_0__.ENTER
}], [{
  key: _keys__WEBPACK_IMPORTED_MODULE_0__.SEVEN
}, {
  key: _keys__WEBPACK_IMPORTED_MODULE_0__.EIGHT
}, {
  key: _keys__WEBPACK_IMPORTED_MODULE_0__.NINE
}, {
  key: _keys__WEBPACK_IMPORTED_MODULE_0__.DOT
}], [{
  key: _keys__WEBPACK_IMPORTED_MODULE_0__.BLANK
}, {
  key: _keys__WEBPACK_IMPORTED_MODULE_0__.ZERO
}, {
  key: _keys__WEBPACK_IMPORTED_MODULE_0__.BLANK
}, {
  key: _keys__WEBPACK_IMPORTED_MODULE_0__.ESC
}]];
/**
 * 布局类型
 * */
const Layouts = {
  number: NumberLayout,
  tel: TelLayout,
  phone: PhoneLayout
};

/***/ }),

/***/ 56853:
/*!********************************************************************!*\
  !*** ./apps/bfswap/src/components/bs-numeric-input/utils/utils.ts ***!
  \********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   animate: () => (/* binding */ animate),
/* harmony export */   coerceBooleanProperty: () => (/* binding */ coerceBooleanProperty)
/* harmony export */ });
/** 帧时间 */
const requestAnimationFrame = window.requestAnimationFrame;
/** 运行动画 */
const animate = (iterable, done = () => {}, frames = 60) => {
  let running = true;
  let frame = 0;
  const closure = timestamp => {
    if (running === false) {
      return;
    }
    iterable(timestamp, ++frame, frames);
    if (frame < frames) {
      requestAnimationFrame(closure);
    } else {
      done();
    }
  };
  requestAnimationFrame(closure);
  return () => {
    running = false;
  };
};
/** 判断 */
const coerceBooleanProperty = value => {
  return value != null && `${value}` !== 'false';
};

/***/ }),

/***/ 52766:
/*!*****************************************************************************************!*\
  !*** ./apps/bfswap/src/components/bs-numeric-keyboard/bs-numeric-keyboard.component.ts ***!
  \*****************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   BsNumericKeyboardComponent: () => (/* binding */ BsNumericKeyboardComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 61039);
/* harmony import */ var _components_bs_numeric_input_utils_keys__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ~components/bs-numeric-input/utils/keys */ 77068);
/* harmony import */ var _components_bs_numeric_input_utils_layouts__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ~components/bs-numeric-input/utils/layouts */ 80125);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rxjs */ 19177);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! rxjs */ 58508);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! rxjs */ 13135);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! rxjs */ 91317);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! rxjs */ 41720);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! rxjs */ 54498);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! rxjs */ 96121);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! rxjs */ 81341);
/* harmony import */ var _modules_page_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ~modules/page.module */ 16381);
/* harmony import */ var _angular_material_slider__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @angular/material/slider */ 83402);
/* harmony import */ var _bnqkl_framework_helpers__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @bnqkl/framework/helpers */ 12169);
/* harmony import */ var _libs_bnf_directives_auto_complete_off_directive__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../../../libs/bnf/directives/auto-complete-off.directive */ 66722);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @angular/common */ 6729);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @angular/forms */ 7820);
/* harmony import */ var _icon_icon_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../icon/icon.component */ 18840);
var _class;













function BsNumericKeyboardComponent_tr_8_td_1_bs_icon_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](0, "bs-icon", 11);
  }
  if (rf & 2) {
    const c_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("name", c_r3.iconName)("ngClass", c_r3.iconColor);
  }
}
function BsNumericKeyboardComponent_tr_8_td_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r7 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "td", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("touchstart", function BsNumericKeyboardComponent_tr_8_td_1_Template_td_touchstart_0_listener($event) {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵrestoreView"](_r7);
      const c_r3 = restoredCtx.$implicit;
      const ctx_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵresetView"](ctx_r6.onTouchStart($event, c_r3));
    })("touchend", function BsNumericKeyboardComponent_tr_8_td_1_Template_td_touchend_0_listener($event) {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵrestoreView"](_r7);
      const c_r3 = restoredCtx.$implicit;
      const ctx_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵresetView"](ctx_r8.onTouchEnd($event, c_r3));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](1, BsNumericKeyboardComponent_tr_8_td_1_bs_icon_1_Template, 1, 2, "bs-icon", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const c_r3 = ctx.$implicit;
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵclassProp"]("active", ctx_r2._keyItem === c_r3);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngClass", (c_r3.key === ctx_r2.ENTER ? "rounded-1 " : " ") + c_r3.color);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵattribute"]("rowspan", c_r3.rowspan)("colspan", c_r3.colspan)("data-key", c_r3.key)("data-icon", c_r3.key === ctx_r2.ENTER ? ctx_r2.kp == null ? null : ctx_r2.kp.entertext : c_r3.key);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", !!c_r3.iconName);
  }
}
function BsNumericKeyboardComponent_tr_8_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "tr");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](1, BsNumericKeyboardComponent_tr_8_td_1_Template, 2, 8, "td", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const r_r1 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngForOf", r_r1);
  }
}
/** css样式初始化  */
const setupEnvKeyboardStyle = (0,_bnqkl_framework_helpers__WEBPACK_IMPORTED_MODULE_3__.$once)(() => {
  const cssPropertyName = (0,_bnqkl_framework_helpers__WEBPACK_IMPORTED_MODULE_3__.registryCssProperty)('--virtual-keyboard-cover-height', '<length>', 0, 'false');
  return cssPropertyName;
});
/** 自定义键盘 */
class BsNumericKeyboardComponent {
  constructor() {
    /** 自定义样式名称 */
    this.cssProp = setupEnvKeyboardStyle();
    /** 键盘布局 */
    this.layout = 'number';
    /** 确认文本 */
    this.entertext = 'Enter';
    /** 滑块值 */
    this.sliderValue = 0;
    /** 键盘高度写入元素 */
    this.hostEle = document.querySelector("common-pages-outlet");
    /** 滑块变动事件 */
    this.sliderValueChange = new _angular_core__WEBPACK_IMPORTED_MODULE_6__.EventEmitter();
    /** 点击 */
    this.press = new _angular_core__WEBPACK_IMPORTED_MODULE_6__.EventEmitter();
    /** 确认 */
    this.enterpress = new _angular_core__WEBPACK_IMPORTED_MODULE_6__.EventEmitter();
    /**
     * 长按
     */
    this.longPress = new _angular_core__WEBPACK_IMPORTED_MODULE_6__.EventEmitter();
    /**
     * 长按
     */
    this.longEnterpress = new _angular_core__WEBPACK_IMPORTED_MODULE_6__.EventEmitter();
    /**
     * 长按结束
     */
    this.longPressEnd = new _angular_core__WEBPACK_IMPORTED_MODULE_6__.EventEmitter();
    /**
     * 长按结束
     */
    this.longEnterpressEnd = new _angular_core__WEBPACK_IMPORTED_MODULE_6__.EventEmitter();
    /** 本身dom */
    this.eleRef = (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.inject)(_angular_core__WEBPACK_IMPORTED_MODULE_6__.ElementRef);
    /** 销毁 */
    this.destroy$ = new rxjs__WEBPACK_IMPORTED_MODULE_7__.Subject();
    /** ks */
    this.ks = {
      resolvedLayout: []
    };
    /** enter */
    this.ENTER = _components_bs_numeric_input_utils_keys__WEBPACK_IMPORTED_MODULE_0__.ENTER;
    /** del */
    this.DEL = _components_bs_numeric_input_utils_keys__WEBPACK_IMPORTED_MODULE_0__.DEL;
    /** esc */
    this.ESC = _components_bs_numeric_input_utils_keys__WEBPACK_IMPORTED_MODULE_0__.ESC;
    /** 触碰结束 */
    this.touchEnd$ = new rxjs__WEBPACK_IMPORTED_MODULE_7__.Subject();
    /** 移动 */
    this.touchMove$ = (0,rxjs__WEBPACK_IMPORTED_MODULE_8__.fromEvent)(document, 'touchmove').pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_9__.takeUntil)(this.destroy$));
  }
  /** 触发滑块变动 */
  getSliderValueChange(v) {
    this.sliderValueChange.emit(v);
  }
  /** 初始化 */
  ngOnInit() {
    const options = {
      layout: this.layout,
      entertext: this.entertext
    };
    this.init(options);
  }
  /** 试图初始化后 */
  ngAfterViewInit() {
    this.setPageKeyHeight();
  }
  /** 写入样式 */
  _setStyle(ele, key, value) {
    ele.style.setProperty(key, value);
  }
  /** 等于renderer2 removeStyle
   * 目前renderer2 对自定义属性的支持很差，所以只能用原生的API
   */
  _removeStyle(ele, key) {
    ele.style.removeProperty(key);
  }
  /** 写入键盘高度 */
  setPageKeyHeight() {
    var _this$eleRef$nativeEl;
    const keyHeight = (_this$eleRef$nativeEl = this.eleRef.nativeElement.querySelector("table")) === null || _this$eleRef$nativeEl === void 0 ? void 0 : _this$eleRef$nativeEl.offsetHeight;
    if (keyHeight === undefined || keyHeight <= 0) {
      setTimeout(() => {
        this.setPageKeyHeight();
      }, 380);
      return;
    }
    if (this.hostEle) {
      var _this$numericInput;
      this._setStyle(this.hostEle, this.cssProp, keyHeight + 'px');
      (_this$numericInput = this.numericInput) === null || _this$numericInput === void 0 || _this$numericInput.scrollIntoView({
        behavior: 'smooth',
        block: 'end'
      });
    }
  }
  /** 事件阻止 */
  stopEvent(event) {
    event.stopPropagation();
    event.preventDefault();
  }
  /** 触碰开始 */
  onTouchStart(event, item) {
    this._keyItem = item;
    this.touchStart = event;
    (0,rxjs__WEBPACK_IMPORTED_MODULE_10__.timer)(500).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_11__.map)(() => item)).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_9__.takeUntil)((0,rxjs__WEBPACK_IMPORTED_MODULE_12__.merge)(this.touchEnd$, this.touchMove$))).subscribe(value => {
      // 超过500ms为长按
      this.touchStart = undefined;
      this.longPress.emit(value.key);
      if (value.key === _components_bs_numeric_input_utils_keys__WEBPACK_IMPORTED_MODULE_0__.ENTER) {
        this.longEnterpress.emit();
      }
    });
  }
  /** 触碰结束 */
  onTouchEnd(event, item) {
    this._keyItem = undefined;
    this.touchEnd$.next(item);
    // 长按结束
    if (this.touchStart) {
      ///
    } else {
      this.longPressEnd.emit(item.key);
      if (item.key === _components_bs_numeric_input_utils_keys__WEBPACK_IMPORTED_MODULE_0__.ENTER) {
        this.longEnterpressEnd.emit(item.key);
      }
    }
    (0,rxjs__WEBPACK_IMPORTED_MODULE_13__.of)(item).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_14__.filter)(() => this.touchStart !== undefined), (0,rxjs__WEBPACK_IMPORTED_MODULE_9__.takeUntil)(this.touchMove$)).subscribe(value => {
      this.press.emit(value.key);
      if (value.key === _components_bs_numeric_input_utils_keys__WEBPACK_IMPORTED_MODULE_0__.ENTER) {
        this.enterpress.emit();
      }
    });
  }
  /** 初始化 */
  init(options) {
    const {
      layout
    } = options;
    let resolvedLayout;
    if (typeof layout === 'string') {
      resolvedLayout = _components_bs_numeric_input_utils_layouts__WEBPACK_IMPORTED_MODULE_1__.Layouts[layout];
      if (Array.isArray(resolvedLayout) === false) {
        throw new Error(`${layout} is not a build-in layout.`);
      }
    } else {
      if (layout === undefined || layout === null || Array.isArray(layout) === false || layout.every(i => Array.isArray(i)) === false) {
        throw new Error(`custom layout must be a two-dimensional array.`);
      }
      resolvedLayout = layout;
    }
    this.kp = options;
    this.ks = {
      resolvedLayout
    };
  }
  /** 销毁 */
  ngOnDestroy() {
    this.destroy$.next(); // 发出一个值，通知所有订阅了 destroy$ 的可观察对象停止向下传递值
    this.destroy$.complete(); // 停止 destroy$ 的传播，释放资源
    this.hostEle && this._removeStyle(this.hostEle, this.cssProp);
  }
}
_class = BsNumericKeyboardComponent;
_class.ɵfac = function BsNumericKeyboardComponent_Factory(t) {
  return new (t || _class)();
};
_class.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdefineComponent"]({
  type: _class,
  selectors: [["bs-numeric-keyboard"]],
  inputs: {
    layout: "layout",
    entertext: "entertext",
    numericInput: "numericInput"
  },
  outputs: {
    sliderValueChange: "sliderValueChange",
    press: "press",
    enterpress: "enterpress",
    longPress: "longPress",
    longEnterpress: "longEnterpress",
    longPressEnd: "longPressEnd",
    longEnterpressEnd: "longEnterpressEnd"
  },
  standalone: true,
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵStandaloneFeature"]],
  decls: 9,
  vars: 3,
  consts: [[1, "numeric-keyboard", "text-2xl", "border-t-tiny", "border-border-10", 2, "padding-bottom", "var(--env-safe-area-inset-bottom)"], [1, "h-12"], ["colspan", "3"], [1, "keyboard-slider", "w-[76%]"], ["matSliderThumb", "", 3, "ngModel", "ngModelChange", "valueChange"], ["colspan", "1"], [1, "border-tiny", "border-text-input", "rounded-1", "text-title-10", "text-sm", "h-8", "flex", "justify-center", "items-center"], [4, "ngFor", "ngForOf"], ["class", "numeric-keyboard-key", 3, "ngClass", "active", "touchstart", "touchend", 4, "ngFor", "ngForOf"], [1, "numeric-keyboard-key", 3, "ngClass", "touchstart", "touchend"], ["class", "text-2xl", 3, "name", "ngClass", 4, "ngIf"], [1, "text-2xl", 3, "name", "ngClass"]],
  template: function BsNumericKeyboardComponent_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "table", 0)(1, "tr", 1)(2, "td", 2)(3, "mat-slider", 3)(4, "input", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("ngModelChange", function BsNumericKeyboardComponent_Template_input_ngModelChange_4_listener($event) {
        return ctx.sliderValue = $event;
      })("valueChange", function BsNumericKeyboardComponent_Template_input_valueChange_4_listener($event) {
        return ctx.getSliderValueChange($event);
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()();
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](5, "td", 5)(6, "div", 6);
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](7);
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()();
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](8, BsNumericKeyboardComponent_tr_8_Template, 2, 1, "tr", 7);
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](4);
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngModel", ctx.sliderValue);
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate1"]("", ctx.sliderValue, "%");
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngForOf", ctx.ks.resolvedLayout);
    }
  },
  dependencies: [_modules_page_module__WEBPACK_IMPORTED_MODULE_2__.CommonPageModule, _libs_bnf_directives_auto_complete_off_directive__WEBPACK_IMPORTED_MODULE_4__.AutoCompleteOffDirective, _angular_common__WEBPACK_IMPORTED_MODULE_15__.NgClass, _angular_common__WEBPACK_IMPORTED_MODULE_15__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_15__.NgIf, _angular_forms__WEBPACK_IMPORTED_MODULE_16__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_16__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_16__.NgModel, _icon_icon_component__WEBPACK_IMPORTED_MODULE_5__.IconComponent, _angular_material_slider__WEBPACK_IMPORTED_MODULE_17__.MatSliderModule, _angular_material_slider__WEBPACK_IMPORTED_MODULE_17__.MatSlider, _angular_material_slider__WEBPACK_IMPORTED_MODULE_17__.MatSliderThumb],
  styles: [".half[_ngcontent-%COMP%] {\n  height: 50%;\n}\n\n  .keyboard-slider {\n  --mdc-slider-handle-width: 14px;\n  --mdc-slider-handle-height: 14px;\n  --mdc-slider-active-track-color: #9357f7;\n}\n  .keyboard-slider .mdc-slider__thumb-knob {\n  border: 2px solid #9357f7 !important;\n  background: white !important;\n}\n  .keyboard-slider .mdc-slider__track--inactive {\n  background-color: #eaedf0 !important;\n  opacity: 1 !important;\n}\n\n.numeric-keyboard[_ngcontent-%COMP%] {\n  padding-left: 4px;\n  padding-right: 4px;\n  width: 100%;\n  height: 100%;\n  background: #fff;\n  table-layout: fixed;\n  border-collapse: separate;\n  border-spacing: 4px;\n  text-align: center;\n}\n\n.numeric-keyboard-key[_ngcontent-%COMP%] {\n  touch-action: manipulation;\n  transition: background 0.3s;\n  color: #050615;\n  background: #eaedf0;\n  padding: 5px 0 5px 0;\n}\n.numeric-keyboard-key.active[_ngcontent-%COMP%] {\n  background: #e1e1e1;\n}\n\n.numeric-keyboard-key[data-key=\"\"][_ngcontent-%COMP%] {\n  pointer-events: none;\n  background: #edeef1;\n}\n\n.numeric-keyboard-key[data-key=esc][_ngcontent-%COMP%] {\n  background: #edeef1;\n}\n\n.numeric-keyboard-key[data-key=enter][_ngcontent-%COMP%] {\n  color: #5695e8;\n  background: #ededed;\n  font-size: 20px;\n  letter-spacing: -0.5px !important;\n}\n\n.numeric-keyboard-key[data-key=del][_ngcontent-%COMP%], .numeric-keyboard-key[data-key=\".\"][_ngcontent-%COMP%] {\n  background: #ededed;\n  color: #4c4c4c;\n}\n\n.numeric-keyboard-key[data-key=enter][_ngcontent-%COMP%]:active, .numeric-keyboard-key[data-key=del][_ngcontent-%COMP%]:active, .numeric-keyboard-key[data-key=\".\"][_ngcontent-%COMP%]:active {\n  background: #d5d5d5;\n}\n\n.numeric-keyboard-key[data-icon][_ngcontent-%COMP%]::before {\n  content: attr(data-icon);\n}\n\n.numeric-keyboard-key[data-icon=esc][_ngcontent-%COMP%]::before, .numeric-keyboard-key[data-icon=del][_ngcontent-%COMP%]::before {\n  display: block;\n  content: \" \";\n}\n\n.numeric-keyboard-actionsheet[_nghost-%COMP%] {\n  position: fixed;\n  bottom: 0px;\n  left: 0px;\n  width: 100%;\n  height: 40%;\n}\n.numeric-keyboard-actionsheet[_nghost-%COMP%]    > div[_ngcontent-%COMP%]:first-child {\n  height: 100%;\n}\n.numeric-keyboard-actionsheet[_nghost-%COMP%]    > div[_ngcontent-%COMP%]:last-child {\n  position: absolute;\n  top: 0;\n  right: 0;\n  bottom: 0;\n  left: 0;\n  transform: translateY(100%);\n  box-shadow: 0 -2px 4px 0 #cfd4da;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL2FwcHMvYmZzd2FwL3NyYy9jb21wb25lbnRzL2JzLW51bWVyaWMta2V5Ym9hcmQvYnMtbnVtZXJpYy1rZXlib2FyZC5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLFdBQUE7QUFDSjs7QUFFSTtFQUNJLCtCQUFBO0VBQ0EsZ0NBQUE7RUFDQSx3Q0FBQTtBQUNSO0FBQVE7RUFDSSxvQ0FBQTtFQUNBLDRCQUFBO0FBRVo7QUFBUTtFQUNJLG9DQUFBO0VBQ0EscUJBQUE7QUFFWjs7QUFHQTtFQUNJLGlCQUFBO0VBQ0Esa0JBQUE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtFQUNBLGdCQUFBO0VBQ0EsbUJBQUE7RUFDQSx5QkFBQTtFQUNBLG1CQUFBO0VBQ0Esa0JBQUE7QUFBSjs7QUFHQTtFQUVJLDBCQUFBO0VBR0EsMkJBQUE7RUFDQSxjQUFBO0VBQ0EsbUJBQUE7RUFDQSxvQkFBQTtBQUFKO0FBRUk7RUFDSSxtQkFBQTtBQUFSOztBQUlBO0VBQ0ksb0JBQUE7RUFDQSxtQkFBQTtBQURKOztBQUlBO0VBQ0ksbUJBQUE7QUFESjs7QUFJQTtFQUNJLGNBQUE7RUFDQSxtQkFBQTtFQUNBLGVBQUE7RUFDQSxpQ0FBQTtBQURKOztBQUlBOztFQUVJLG1CQUFBO0VBQ0EsY0FBQTtBQURKOztBQUlBOzs7RUFHSSxtQkFBQTtBQURKOztBQUlBO0VBQ0ksd0JBQUE7QUFESjs7QUFJQTs7RUFFSSxjQUFBO0VBQ0EsWUFBQTtBQURKOztBQUlBO0VBQ0ksZUFBQTtFQUNBLFdBQUE7RUFDQSxTQUFBO0VBQ0EsV0FBQTtFQUNBLFdBQUE7QUFESjtBQUlRO0VBQ0ksWUFBQTtBQUZaO0FBS1E7RUFDSSxrQkFBQTtFQUNBLE1BQUE7RUFDQSxRQUFBO0VBQ0EsU0FBQTtFQUNBLE9BQUE7RUFHQSwyQkFBQTtFQUVBLGdDQUFBO0FBSFoiLCJzb3VyY2VzQ29udGVudCI6WyIuaGFsZiB7XHJcbiAgICBoZWlnaHQ6IDUwJTtcclxufVxyXG46Om5nLWRlZXAge1xyXG4gICAgLmtleWJvYXJkLXNsaWRlciB7XHJcbiAgICAgICAgLS1tZGMtc2xpZGVyLWhhbmRsZS13aWR0aDogMTRweDtcclxuICAgICAgICAtLW1kYy1zbGlkZXItaGFuZGxlLWhlaWdodDogMTRweDtcclxuICAgICAgICAtLW1kYy1zbGlkZXItYWN0aXZlLXRyYWNrLWNvbG9yOiAjOTM1N2Y3O1xyXG4gICAgICAgIC5tZGMtc2xpZGVyX190aHVtYi1rbm9iIHtcclxuICAgICAgICAgICAgYm9yZGVyOiAycHggc29saWQgIzkzNTdmNyAhaW1wb3J0YW50O1xyXG4gICAgICAgICAgICBiYWNrZ3JvdW5kOiB3aGl0ZSAhaW1wb3J0YW50O1xyXG4gICAgICAgIH1cclxuICAgICAgICAubWRjLXNsaWRlcl9fdHJhY2stLWluYWN0aXZlIHtcclxuICAgICAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogI2VhZWRmMCAhaW1wb3J0YW50O1xyXG4gICAgICAgICAgICBvcGFjaXR5OiAxICFpbXBvcnRhbnQ7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59XHJcblxyXG4ubnVtZXJpYy1rZXlib2FyZCB7XHJcbiAgICBwYWRkaW5nLWxlZnQ6IDRweDtcclxuICAgIHBhZGRpbmctcmlnaHQ6IDRweDtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgaGVpZ2h0OiAxMDAlO1xyXG4gICAgYmFja2dyb3VuZDogI2ZmZjtcclxuICAgIHRhYmxlLWxheW91dDogZml4ZWQ7XHJcbiAgICBib3JkZXItY29sbGFwc2U6IHNlcGFyYXRlO1xyXG4gICAgYm9yZGVyLXNwYWNpbmc6IDRweDtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxufVxyXG5cclxuLm51bWVyaWMta2V5Ym9hcmQta2V5IHtcclxuICAgIC1tcy10b3VjaC1hY3Rpb246IG1hbmlwdWxhdGlvbjtcclxuICAgIHRvdWNoLWFjdGlvbjogbWFuaXB1bGF0aW9uO1xyXG4gICAgLXdlYmtpdC10cmFuc2l0aW9uOiBiYWNrZ3JvdW5kIDAuM3M7XHJcbiAgICAtby10cmFuc2l0aW9uOiBiYWNrZ3JvdW5kIDAuM3M7XHJcbiAgICB0cmFuc2l0aW9uOiBiYWNrZ3JvdW5kIDAuM3M7XHJcbiAgICBjb2xvcjogIzA1MDYxNTtcclxuICAgIGJhY2tncm91bmQ6ICNlYWVkZjA7XHJcbiAgICBwYWRkaW5nOiA1cHggMCA1cHggMDtcclxuXHJcbiAgICAmLmFjdGl2ZSB7XHJcbiAgICAgICAgYmFja2dyb3VuZDogI2UxZTFlMTtcclxuICAgIH1cclxufVxyXG5cclxuLm51bWVyaWMta2V5Ym9hcmQta2V5W2RhdGEta2V5PScnXSB7XHJcbiAgICBwb2ludGVyLWV2ZW50czogbm9uZTtcclxuICAgIGJhY2tncm91bmQ6ICNlZGVlZjE7XHJcbn1cclxuXHJcbi5udW1lcmljLWtleWJvYXJkLWtleVtkYXRhLWtleT0nZXNjJ10ge1xyXG4gICAgYmFja2dyb3VuZDogI2VkZWVmMTtcclxufVxyXG5cclxuLm51bWVyaWMta2V5Ym9hcmQta2V5W2RhdGEta2V5PSdlbnRlciddIHtcclxuICAgIGNvbG9yOiAjNTY5NWU4O1xyXG4gICAgYmFja2dyb3VuZDogI2VkZWRlZDtcclxuICAgIGZvbnQtc2l6ZTogMjBweDtcclxuICAgIGxldHRlci1zcGFjaW5nOiAtMC41cHggIWltcG9ydGFudDtcclxufVxyXG5cclxuLm51bWVyaWMta2V5Ym9hcmQta2V5W2RhdGEta2V5PSdkZWwnXSxcclxuLm51bWVyaWMta2V5Ym9hcmQta2V5W2RhdGEta2V5PScuJ10ge1xyXG4gICAgYmFja2dyb3VuZDogI2VkZWRlZDtcclxuICAgIGNvbG9yOiAjNGM0YzRjO1xyXG59XHJcblxyXG4ubnVtZXJpYy1rZXlib2FyZC1rZXlbZGF0YS1rZXk9J2VudGVyJ106YWN0aXZlLFxyXG4ubnVtZXJpYy1rZXlib2FyZC1rZXlbZGF0YS1rZXk9J2RlbCddOmFjdGl2ZSxcclxuLm51bWVyaWMta2V5Ym9hcmQta2V5W2RhdGEta2V5PScuJ106YWN0aXZlIHtcclxuICAgIGJhY2tncm91bmQ6ICNkNWQ1ZDU7XHJcbn1cclxuXHJcbi5udW1lcmljLWtleWJvYXJkLWtleVtkYXRhLWljb25dOjpiZWZvcmUge1xyXG4gICAgY29udGVudDogYXR0cihkYXRhLWljb24pO1xyXG59XHJcblxyXG4ubnVtZXJpYy1rZXlib2FyZC1rZXlbZGF0YS1pY29uPSdlc2MnXTo6YmVmb3JlLFxyXG4ubnVtZXJpYy1rZXlib2FyZC1rZXlbZGF0YS1pY29uPSdkZWwnXTo6YmVmb3JlIHtcclxuICAgIGRpc3BsYXk6IGJsb2NrO1xyXG4gICAgY29udGVudDogJyAnO1xyXG59XHJcblxyXG46aG9zdCgubnVtZXJpYy1rZXlib2FyZC1hY3Rpb25zaGVldCkge1xyXG4gICAgcG9zaXRpb246IGZpeGVkO1xyXG4gICAgYm90dG9tOiAwcHg7XHJcbiAgICBsZWZ0OiAwcHg7XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICAgIGhlaWdodDogNDAlO1xyXG5cclxuICAgID5kaXYge1xyXG4gICAgICAgICY6Zmlyc3QtY2hpbGQge1xyXG4gICAgICAgICAgICBoZWlnaHQ6IDEwMCU7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICAmOmxhc3QtY2hpbGQge1xyXG4gICAgICAgICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICAgICAgICAgIHRvcDogMDtcclxuICAgICAgICAgICAgcmlnaHQ6IDA7XHJcbiAgICAgICAgICAgIGJvdHRvbTogMDtcclxuICAgICAgICAgICAgbGVmdDogMDtcclxuICAgICAgICAgICAgLXdlYmtpdC10cmFuc2Zvcm06IHRyYW5zbGF0ZVkoMTAwJSk7XHJcbiAgICAgICAgICAgIC1tcy10cmFuc2Zvcm06IHRyYW5zbGF0ZVkoMTAwJSk7XHJcbiAgICAgICAgICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlWSgxMDAlKTtcclxuICAgICAgICAgICAgLXdlYmtpdC1ib3gtc2hhZG93OiAwIC0ycHggNHB4IDAgI2NmZDRkYTtcclxuICAgICAgICAgICAgYm94LXNoYWRvdzogMCAtMnB4IDRweCAwICNjZmQ0ZGE7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59Il0sInNvdXJjZVJvb3QiOiIifQ== */"]
});

/***/ }),

/***/ 60397:
/*!*************************************************************************************!*\
  !*** ./apps/bfswap/src/components/swap-detail-panel/swap-detail-panel.component.ts ***!
  \*************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   SwapDetailPanelPage: () => (/* binding */ SwapDetailPanelPage),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 52542);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! tslib */ 90505);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! @angular/core */ 61039);
/* harmony import */ var _bnqkl_framework_pipes__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @bnqkl/framework/pipes */ 80909);
/* harmony import */ var _modules_page_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ~modules/page.module */ 16381);
/* harmony import */ var _services_transaction_settings_transaction_settings_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ~services/transaction-settings/transaction-settings.service */ 80348);
/* harmony import */ var bignumber_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! bignumber.js */ 61994);
/* harmony import */ var _services_wallet_wallet_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ~services/wallet/wallet.service */ 54275);
/* harmony import */ var _bnqkl_framework_plugins_toast__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @bnqkl/framework/plugins/toast */ 18030);
/* harmony import */ var _components_token_with_chain_icon_token_with_chain_icon_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ~components/token-with-chain-icon/token-with-chain-icon.component */ 11342);
/* harmony import */ var _services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ~services/wallet/wallet.helper */ 84813);
/* harmony import */ var _pipes_remove_trailing_zeros_remove_trailing_zeros_pipe__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ~pipes/remove-trailing-zeros/remove-trailing-zeros.pipe */ 53494);
/* harmony import */ var _environments_index__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ~environments/index */ 11295);
/* harmony import */ var _plaoc_plugins__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @plaoc/plugins */ 53396);
/* harmony import */ var _bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @bnqkl/bnqkl-swap-core */ 70195);
/* harmony import */ var _services_liquidity_pool_liquidity_pool_helper__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ~services/liquidity-pool/liquidity-pool.helper */ 17827);
/* harmony import */ var _components_swap_token_chain_icon_swap_token_chain_icon_component__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ~components/swap-token-chain-icon/swap-token-chain-icon.component */ 26193);
/* harmony import */ var _libs_bnf_components_ripple_button_ripple_button_directive__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ../../../../../libs/bnf/components/ripple-button/ripple-button.directive */ 16505);
/* harmony import */ var _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ../../../../../libs/bnf/modules/page/common-page/common-page.component */ 62052);
/* harmony import */ var _icon_icon_component__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ../icon/icon.component */ 18840);
/* harmony import */ var _libs_bnf_components_loading_wrapper_loading_wrapper_component__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ../../../../../libs/bnf/components/loading-wrapper/loading-wrapper.component */ 51263);
/* harmony import */ var _pipes_color_color_pipe__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ../../pipes/color/color.pipe */ 67481);

var _class;






















function SwapDetailPanelPage_Conditional_25_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](0, "div", 47);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelement"](1, "bs-swap-token-chain-icon", 48);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](2, "div", 49);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵproperty"]("swapChainName", ctx_r0.sellPanel.chain);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtextInterpolate"](ctx_r0.sellPanel.chain);
  }
}
function SwapDetailPanelPage_Conditional_34_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](0, "div", 50);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelement"](1, "bs-swap-token-chain-icon", 48);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](2, "div", 51);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵproperty"]("swapChainName", ctx_r1.buyPanel.chain);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtextInterpolate"](ctx_r1.buyPanel.chain);
  }
}
const _c26 = () => ({
  removeZero: true
});
function SwapDetailPanelPage_For_68_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](0, "div", 52)(1, "div", 53);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵpipe"](3, "amountFixed");
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelement"](4, "bs-token-with-chain-icon", 54)(5, "bs-swap-token-chain-icon", 55);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const item_r3 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵpipeBind3"](3, 7, item_r3.lpCoinsAmount, 8, _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵpureFunction0"](11, _c26)), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵproperty"]("size", 24)("swapChainName", item_r3.anchorCoinsChainName)("swapCoinName", item_r3.anchorCoinsName);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵproperty"]("iconSize", "icon-6")("swapCoinName", item_r3.quoteCoinsName)("swapChainName", item_r3.quoteCoinsChainName);
  }
}
const _c27 = a0 => ({
  color: a0
});
/**
 * 兑换详情弹窗
 */
class SwapDetailPanelPage extends _modules_page_module__WEBPACK_IMPORTED_MODULE_2__.CommonPageBase {
  constructor() {
    super(...arguments);
    /** 高级选项服务 */
    this.service = (0,_angular_core__WEBPACK_IMPORTED_MODULE_20__.inject)(_services_transaction_settings_transaction_settings_service__WEBPACK_IMPORTED_MODULE_3__.TransactionSettingsService);
    /** 钱包服务 */
    this.walletService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_20__.inject)(_services_wallet_wallet_service__WEBPACK_IMPORTED_MODULE_5__.WalletService);
    /** 最小接受额 */
    this.leastGainAmount = '0';
    /** 手续费 */
    this.transactionFee = '0';
    /** 手续费比例 */
    this.feeRatio = '0';
    /** 滑点 */
    this.slippageTolerance = '';
    /** 过期时间 */
    this.expirationTime = '';
    /** 添加流动性比例 */
    this.addLiquidityRatio = '';
    /** 卖的价格 */
    this.priceSell = '0';
    /** 买的价格 */
    this.priceBuy = '0';
    /** 预期的买入数量  */
    this.expectBuyAmount = '';
    /** 预期的卖出数量 */
    this.expectSellAmount = '';
    /** 返回类型 */
    this.returnValue$ = new _modules_page_module__WEBPACK_IMPORTED_MODULE_2__.PageReturnValue();
    /** 按钮文本 */
    this.btnText = "Confirm";
    /** loading */
    this.loading = false;
    /** disabled */
    this.disabled = false;
    /** 卖币图标 */
    this.sellCoinIcon = undefined;
    /** 卖链图标 */
    this.sellChainIcon = undefined;
    /** 卖币图标 */
    this.buyCoinIcon = undefined;
    /** 卖链图标 */
    this.buyChainIcon = undefined;
    /** 平台手续费 */
    this.platformFee = '';
    /** 展示添加流动性 */
    this.showAddLiquidityDetail = false;
    /** 卖的币是否U */
    this.sellCoinIsU = false;
    /** 卖的币是否U */
    this.buyCoinIsU = false;
    /** 添加流动性数据 */
    this.expectedIncreasedLiquiditys = [];
    /** 汇率对象  */
    this.price = {
      leftCoin: undefined,
      rightCoin: undefined,
      forwordPrice: _services_liquidity_pool_liquidity_pool_helper__WEBPACK_IMPORTED_MODULE_13__.PRICE_NONE.AMOUNT_NONE,
      backwordPirce: _services_liquidity_pool_liquidity_pool_helper__WEBPACK_IMPORTED_MODULE_13__.PRICE_NONE.AMOUNT_NONE,
      showPrice: _services_liquidity_pool_liquidity_pool_helper__WEBPACK_IMPORTED_MODULE_13__.PRICE_NONE.AMOUNT_NONE,
      direction: _services_liquidity_pool_liquidity_pool_helper__WEBPACK_IMPORTED_MODULE_13__.PRICE_DIRECTION.BACKWARD
    };
  }
  /** 判断币是否是U */
  judgeCoinIsU(sellCoin, buyCoin) {
    this.sellCoinIsU = sellCoin === _bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_12__.BNQKL_SWAP_COIN_NAME.USDM;
    this.buyCoinIsU = buyCoin === _bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_12__.BNQKL_SWAP_COIN_NAME.USDM;
  }
  /** 切换显示与隐藏 */
  toggleShowDetail() {
    this.showAddLiquidityDetail = !this.showAddLiquidityDetail;
  }
  /** 初始化数据 */
  init() {
    const {
      sellPanel,
      buyPanel
    } = this;
    if (sellPanel === undefined || buyPanel === undefined) return;
    const {
      coin: sellCoin
    } = sellPanel;
    const {
      coin: buyCoin
    } = buyPanel;
    if (sellCoin === undefined || buyCoin === undefined) return;
    const {
      slippageTolerance,
      expirationTime,
      addLiquidityRatio
    } = this.service.getSelectedValue();
    if (slippageTolerance === undefined || expirationTime === undefined) return;
    this.slippageTolerance = slippageTolerance.label;
    this.expirationTime = expirationTime.label;
    this.addLiquidityRatio = addLiquidityRatio.label;
    const addRatioValue = new bignumber_js__WEBPACK_IMPORTED_MODULE_4__["default"](1).minus(addLiquidityRatio.value);
    const sellAmount = this.sellPanel.amount;
    this.expectSellAmount = _pipes_remove_trailing_zeros_remove_trailing_zeros_pipe__WEBPACK_IMPORTED_MODULE_9__.RemoveTrailingZerosPipe.transform(addRatioValue.multipliedBy(sellAmount).toFixed(8, 1));
    const buyAmount = this.buyPanel.amount;
    this.transactionFee = _pipes_remove_trailing_zeros_remove_trailing_zeros_pipe__WEBPACK_IMPORTED_MODULE_9__.RemoveTrailingZerosPipe.transform(new bignumber_js__WEBPACK_IMPORTED_MODULE_4__["default"](this.expectSellAmount).multipliedBy(this.platformFee).toFixed(8, 1));
    this.feeRatio = new bignumber_js__WEBPACK_IMPORTED_MODULE_4__["default"](this.platformFee).multipliedBy(1e2).toString();
    this.priceSell = _pipes_remove_trailing_zeros_remove_trailing_zeros_pipe__WEBPACK_IMPORTED_MODULE_9__.RemoveTrailingZerosPipe.transform(new bignumber_js__WEBPACK_IMPORTED_MODULE_4__["default"](this.expectBuyAmount).div(this.expectSellAmount).toFixed(8, 1));
    this.priceBuy = _pipes_remove_trailing_zeros_remove_trailing_zeros_pipe__WEBPACK_IMPORTED_MODULE_9__.RemoveTrailingZerosPipe.transform(new bignumber_js__WEBPACK_IMPORTED_MODULE_4__["default"](this.expectSellAmount).div(this.expectBuyAmount).toFixed(8, 1));
    this.handlePriceCaculate(sellCoin, this.expectSellAmount, buyCoin, this.expectBuyAmount);
    const v = new bignumber_js__WEBPACK_IMPORTED_MODULE_4__["default"](1).minus(slippageTolerance.value);
    const leastGainAmount = _pipes_remove_trailing_zeros_remove_trailing_zeros_pipe__WEBPACK_IMPORTED_MODULE_9__.RemoveTrailingZerosPipe.transform(v.multipliedBy(this.expectBuyAmount).toFixed(8, 1));
    this.leastGainAmount = Number(leastGainAmount) === 0 ? buyAmount : leastGainAmount;
    this.judgeCoinIsU(sellPanel.coin, buyPanel.coin);
    this.handleAddLiquidityInfo();
    this.initIcon();
  }
  /** 处理添加流动性数据信息 */
  handleAddLiquidityInfo() {
    if (this.preParams) {
      const {
        expectedIncreasedLiquiditys
      } = this.preParams;
      if (expectedIncreasedLiquiditys) {
        const len = expectedIncreasedLiquiditys.length;
        this.expectedIncreasedLiquiditys = expectedIncreasedLiquiditys.map(item => {
          const anchorCoinsChainName = _services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_8__.NODE_CHAIN_NAME_TRANSFER[item.anchorCoinsChainName];
          const anchorChainIcon = (0,_services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_8__.transferToChainIcon)(anchorCoinsChainName || 'Default');
          const anchorCoinIcon = (0,_services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_8__.transferToTokenIcon)(item.anchorCoinsChainName, item.anchorCoinsName);
          const quoteChainName = len === 1 ? _services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_8__.NODE_CHAIN_NAME_TRANSFER_REVERSE[this.buyPanel.chain] : item.quoteCoinsChainName;
          const quoteCoinsChainName = _services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_8__.NODE_CHAIN_NAME_TRANSFER[quoteChainName];
          const quoteChainIcon = (0,_services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_8__.transferToChainIcon)(quoteCoinsChainName || 'Default');
          const quoteCoinIcon = (0,_services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_8__.transferToTokenIcon)(quoteChainName, item.quoteCoinsName);
          const isBigU = item.quoteCoinsChainName === _bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_12__.BNQKL_SWAP_CHAIN_NAME.SWAP && item.quoteCoinsName === _bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_12__.BNQKL_SWAP_COIN_NAME.USDM;
          return {
            ...item,
            anchorChainIcon,
            anchorCoinIcon,
            quoteChainIcon,
            quoteCoinIcon,
            isBigU
          };
        });
      }
    }
  }
  /** 初始化图标 */
  initIcon() {
    const {
      sellPanel,
      buyPanel
    } = this;
    this.sellCoinIcon = (0,_services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_8__.transferToTokenIcon)(_services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_8__.NODE_CHAIN_NAME_TRANSFER_REVERSE[sellPanel.chain], sellPanel.coin);
    this.sellChainIcon = (0,_services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_8__.transferToChainIcon)(sellPanel.chain || 'Default');
    this.buyCoinIcon = (0,_services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_8__.transferToTokenIcon)(_services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_8__.NODE_CHAIN_NAME_TRANSFER_REVERSE[buyPanel.chain], buyPanel.coin);
    this.buyChainIcon = (0,_services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_8__.transferToChainIcon)(buyPanel.chain || 'Default');
  }
  /** 提交 */
  submit() {
    var _this = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const {
        preParams,
        transferOptions
      } = _this;
      if (preParams === undefined || transferOptions === undefined) {
        _this.console.error('兑换面板数据出错：', preParams, transferOptions);
        _bnqkl_framework_plugins_toast__WEBPACK_IMPORTED_MODULE_6__.Toast.show('兑换数据出错');
        return;
      }
      _this.btnText = "Requesting signature";
      _this.loading = true;
      _this.disabled = true;
      const params = yield _this.walletService.getSwapOrderInfoWithSignature(preParams, transferOptions);
      _this.console.log(params);
      if (_this.loading && params) {
        if (_environments_index__WEBPACK_IMPORTED_MODULE_10__.environment.DWEB_APP) {
          _plaoc_plugins__WEBPACK_IMPORTED_MODULE_11__.windowPlugin.focusWindow();
        }
        _this.returnValue$.return({
          transactionData: params
        });
        _this.nav.back();
      } else {
        if (params === undefined) {
          _bnqkl_framework_plugins_toast__WEBPACK_IMPORTED_MODULE_6__.Toast.show('无钱包连接');
        } else if (params === null) {
          _bnqkl_framework_plugins_toast__WEBPACK_IMPORTED_MODULE_6__.Toast.show('签名被拒绝');
          if (_environments_index__WEBPACK_IMPORTED_MODULE_10__.environment.DWEB_APP) {
            _plaoc_plugins__WEBPACK_IMPORTED_MODULE_11__.windowPlugin.focusWindow();
          }
        } else {
          _bnqkl_framework_plugins_toast__WEBPACK_IMPORTED_MODULE_6__.Toast.show('签名出错');
        }
        _this.btnText = "Confirm";
        _this.console.error('签名出错:sinature:', params);
      }
      _this.disabled = false;
      _this.loading = false;
    })();
  }
  /** 关闭事件 */
  handleClose() {
    this.disabled = false;
    this.loading = false;
    _bnqkl_framework_plugins_toast__WEBPACK_IMPORTED_MODULE_6__.Toast.show('交易取消');
    this.nav.back();
  }
  /** 反转价格 */
  handleReversePrice() {
    Object.assign(this.price, (0,_services_liquidity_pool_liquidity_pool_helper__WEBPACK_IMPORTED_MODULE_13__.reversePriceUtil)(this.price));
  }
  /** 价格的计算和赋值 */
  handlePriceCaculate(sellCoin, sellAmount, buyCoin, buyAmount) {
    if (Number(sellAmount) === 0 || Number(buyAmount) === 0) {
      this.console.log('数量不能为零');
      return;
    }
    this.price.direction = _services_liquidity_pool_liquidity_pool_helper__WEBPACK_IMPORTED_MODULE_13__.PRICE_DIRECTION.FORWARD;
    const forwardPrice = Number(new bignumber_js__WEBPACK_IMPORTED_MODULE_4__["default"](sellAmount).dividedBy(buyAmount).toFixed(8, 1)).toString();
    const backPrice = Number(new bignumber_js__WEBPACK_IMPORTED_MODULE_4__["default"](buyAmount).dividedBy(sellAmount).toFixed(8, 1)).toString();
    const option = {
      direction: _services_liquidity_pool_liquidity_pool_helper__WEBPACK_IMPORTED_MODULE_13__.PRICE_DIRECTION.FORWARD,
      format: false
    };
    const generatePrice = (0,_services_liquidity_pool_liquidity_pool_helper__WEBPACK_IMPORTED_MODULE_13__.generatePriceUtil)(buyCoin, forwardPrice, sellCoin, backPrice, option);
    this.price = generatePrice;
  }
}
_class = SwapDetailPanelPage;
_class.ɵfac = /*@__PURE__*/(() => {
  let ɵSwapDetailPanelPage_BaseFactory;
  return function SwapDetailPanelPage_Factory(t) {
    return (ɵSwapDetailPanelPage_BaseFactory || (ɵSwapDetailPanelPage_BaseFactory = _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵgetInheritedFactory"](_class)))(t || _class);
  };
})();
_class.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵdefineComponent"]({
  type: _class,
  selectors: [["bs-swap-detail-panel-page"]],
  inputs: {
    sellPanel: "sellPanel",
    buyPanel: "buyPanel",
    preParams: "preParams",
    transferOptions: "transferOptions",
    expectBuyAmount: "expectBuyAmount",
    platformFee: "platformFee"
  },
  outputs: {
    returnValue$: "returnValue$"
  },
  standalone: true,
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵInheritDefinitionFeature"], _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵStandaloneFeature"]],
  decls: 81,
  vars: 49,
  consts: () => {
    let i18n_0;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_SWAP_DETAIL_PANEL$$APPS_BFSWAP_SRC_COMPONENTS_SWAP_DETAIL_PANEL_SWAP_DETAIL_PANEL_COMPONENT_TS_1 = goog.getMsg("Swap Detail Panel");
      i18n_0 = MSG_EXTERNAL_SWAP_DETAIL_PANEL$$APPS_BFSWAP_SRC_COMPONENTS_SWAP_DETAIL_PANEL_SWAP_DETAIL_PANEL_COMPONENT_TS_1;
    } else {
      i18n_0 = "Swap Detail Panel";
    }
    let i18n_2;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_3863181258168496688$$APPS_BFSWAP_SRC_COMPONENTS_SWAP_DETAIL_PANEL_SWAP_DETAIL_PANEL_COMPONENT_TS_3 = goog.getMsg("\u652F\u4ED8");
      i18n_2 = MSG_EXTERNAL_3863181258168496688$$APPS_BFSWAP_SRC_COMPONENTS_SWAP_DETAIL_PANEL_SWAP_DETAIL_PANEL_COMPONENT_TS_3;
    } else {
      i18n_2 = "\u652F\u4ED8";
    }
    let i18n_4;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_7873689962789072606$$APPS_BFSWAP_SRC_COMPONENTS_SWAP_DETAIL_PANEL_SWAP_DETAIL_PANEL_COMPONENT_TS_5 = goog.getMsg("\u83B7\u5F97\u4E00\uFF1A");
      i18n_4 = MSG_EXTERNAL_7873689962789072606$$APPS_BFSWAP_SRC_COMPONENTS_SWAP_DETAIL_PANEL_SWAP_DETAIL_PANEL_COMPONENT_TS_5;
    } else {
      i18n_4 = "\u83B7\u5F97\u4E00\uFF1A";
    }
    let i18n_6;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_8227609704265439587$$APPS_BFSWAP_SRC_COMPONENTS_SWAP_DETAIL_PANEL_SWAP_DETAIL_PANEL_COMPONENT_TS_7 = goog.getMsg("\u53D1\u8D77\u4EF7\u683C");
      i18n_6 = MSG_EXTERNAL_8227609704265439587$$APPS_BFSWAP_SRC_COMPONENTS_SWAP_DETAIL_PANEL_SWAP_DETAIL_PANEL_COMPONENT_TS_7;
    } else {
      i18n_6 = "\u53D1\u8D77\u4EF7\u683C";
    }
    let i18n_8;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_MINIMUM_AMOUNT_ACCEPTED$$APPS_BFSWAP_SRC_COMPONENTS_SWAP_DETAIL_PANEL_SWAP_DETAIL_PANEL_COMPONENT_TS_9 = goog.getMsg("Minimum amount accepted");
      i18n_8 = MSG_EXTERNAL_MINIMUM_AMOUNT_ACCEPTED$$APPS_BFSWAP_SRC_COMPONENTS_SWAP_DETAIL_PANEL_SWAP_DETAIL_PANEL_COMPONENT_TS_9;
    } else {
      i18n_8 = "Minimum amount accepted";
    }
    let i18n_10;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_LIQUIDITY_FEE_0_2$$APPS_BFSWAP_SRC_COMPONENTS_SWAP_DETAIL_PANEL_SWAP_DETAIL_PANEL_COMPONENT_TS_11 = goog.getMsg("Liquidity fee ({$interpolation})", {
        "interpolation": "\uFFFD0\uFFFD"
      }, {
        original_code: {
          "interpolation": "{{ feeRatio }}"
        }
      });
      i18n_10 = MSG_EXTERNAL_LIQUIDITY_FEE_0_2$$APPS_BFSWAP_SRC_COMPONENTS_SWAP_DETAIL_PANEL_SWAP_DETAIL_PANEL_COMPONENT_TS_11;
    } else {
      i18n_10 = "Liquidity fee (" + "\uFFFD0\uFFFD" + ")";
    }
    let i18n_12;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_SLIPPAGE_TOLERANCE$$APPS_BFSWAP_SRC_COMPONENTS_SWAP_DETAIL_PANEL_SWAP_DETAIL_PANEL_COMPONENT_TS_13 = goog.getMsg("Slippage Tolerance");
      i18n_12 = MSG_EXTERNAL_SLIPPAGE_TOLERANCE$$APPS_BFSWAP_SRC_COMPONENTS_SWAP_DETAIL_PANEL_SWAP_DETAIL_PANEL_COMPONENT_TS_13;
    } else {
      i18n_12 = "Slippage Tolerance";
    }
    let i18n_14;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_DEADLINE$$APPS_BFSWAP_SRC_COMPONENTS_SWAP_DETAIL_PANEL_SWAP_DETAIL_PANEL_COMPONENT_TS_15 = goog.getMsg("Deadline");
      i18n_14 = MSG_EXTERNAL_DEADLINE$$APPS_BFSWAP_SRC_COMPONENTS_SWAP_DETAIL_PANEL_SWAP_DETAIL_PANEL_COMPONENT_TS_15;
    } else {
      i18n_14 = "Deadline";
    }
    let i18n_16;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_2047354512736196164$$APPS_BFSWAP_SRC_COMPONENTS_SWAP_DETAIL_PANEL_SWAP_DETAIL_PANEL_COMPONENT_TS_17 = goog.getMsg("{$interpolation}", {
        "interpolation": "\uFFFD0\uFFFD"
      }, {
        original_code: {
          "interpolation": "{{ expirationTime }}"
        }
      });
      i18n_16 = MSG_EXTERNAL_2047354512736196164$$APPS_BFSWAP_SRC_COMPONENTS_SWAP_DETAIL_PANEL_SWAP_DETAIL_PANEL_COMPONENT_TS_17;
    } else {
      i18n_16 = "" + "\uFFFD0\uFFFD" + "";
    }
    let i18n_18;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_8333618867862558530$$APPS_BFSWAP_SRC_COMPONENTS_SWAP_DETAIL_PANEL_SWAP_DETAIL_PANEL_COMPONENT_TS_19 = goog.getMsg("\u83B7\u5F97\u4E8C\uFF1A");
      i18n_18 = MSG_EXTERNAL_8333618867862558530$$APPS_BFSWAP_SRC_COMPONENTS_SWAP_DETAIL_PANEL_SWAP_DETAIL_PANEL_COMPONENT_TS_19;
    } else {
      i18n_18 = "\u83B7\u5F97\u4E8C\uFF1A";
    }
    let i18n_20;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_2160098162517155843$$APPS_BFSWAP_SRC_COMPONENTS_SWAP_DETAIL_PANEL_SWAP_DETAIL_PANEL_COMPONENT_TS_21 = goog.getMsg("\u5408\u7EA6\u6C60\u6743\u76CA");
      i18n_20 = MSG_EXTERNAL_2160098162517155843$$APPS_BFSWAP_SRC_COMPONENTS_SWAP_DETAIL_PANEL_SWAP_DETAIL_PANEL_COMPONENT_TS_21;
    } else {
      i18n_20 = "\u5408\u7EA6\u6C60\u6743\u76CA";
    }
    let i18n_22;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_1203469798003655104$$APPS_BFSWAP_SRC_COMPONENTS_SWAP_DETAIL_PANEL_SWAP_DETAIL_PANEL_COMPONENT_TS_23 = goog.getMsg("\u56FA\u5B9A\u589E\u6D41\u6BD4\u4F8B");
      i18n_22 = MSG_EXTERNAL_1203469798003655104$$APPS_BFSWAP_SRC_COMPONENTS_SWAP_DETAIL_PANEL_SWAP_DETAIL_PANEL_COMPONENT_TS_23;
    } else {
      i18n_22 = "\u56FA\u5B9A\u589E\u6D41\u6BD4\u4F8B";
    }
    let i18n_24;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_5699150638670410747$$APPS_BFSWAP_SRC_COMPONENTS_SWAP_DETAIL_PANEL_SWAP_DETAIL_PANEL_COMPONENT_TS_25 = goog.getMsg("\u83B7\u5F97\u91CF\u662F\u9884\u4F30\u503C\uFF0C\u6CE8\u610F\u9884\u7559\u7F51\u7EDC\u8D39\u4E8E\u94B1\u5305\u7B7E\u540D");
      i18n_24 = MSG_EXTERNAL_5699150638670410747$$APPS_BFSWAP_SRC_COMPONENTS_SWAP_DETAIL_PANEL_SWAP_DETAIL_PANEL_COMPONENT_TS_25;
    } else {
      i18n_24 = "\u83B7\u5F97\u91CF\u662F\u9884\u4F30\u503C\uFF0C\u6CE8\u610F\u9884\u7559\u7F51\u7EDC\u8D39\u4E8E\u94B1\u5305\u7B7E\u540D";
    }
    return [["headerTitle", i18n_0, 3, "hideBackButton", "headerClass", "titleClass", "contentBackground", "contentSafeArea", "contentClass", "footerClass"], ["endMenu", "", "bnRippleButton", "", 1, "icon-7", 3, "mode", "click"], ["name", "icon-popup-close"], [1, "rounded-4", "bg-base-300", "mt-2.5", "mb-4", "flex", "items-center", "p-3"], [1, "text-base", "font-bold", "text-title-10"], i18n_2, [1, "text-title-10", "ml-auto", "text-base", "font-bold"], [1, "text-subtitle", "mx-1", "text-xs", "font-normal"], [3, "size", "swapCoinName", "swapChainName"], [1, "rounded-4", "bg-base-300", "mb-2", "p-3"], [1, "mb-3", "flex", "items-center"], i18n_4, [1, "bg-gray-30", "rounded-2", "mb-3", "p-2"], [1, "flex", "items-center"], [3, "swapCoinName", "swapChainName"], [1, "text-subtitle", "mx-1"], ["class", "bg-blue-10 rounded-1 flex items-center border border-white  pr-1"], [1, "text-subtitle", "ml-auto"], [1, "flex", "justify-end"], ["name", "icon-arrow-down", 1, "text-subtitle-2", "text-xl"], ["class", "bg-blue-10 rounded-1 flex items-center border border-white px-1 py-0.5"], [1, "text-subtitle-2", "grid", "grid-cols-[1fr,auto]", "items-center", "gap-y-2", "text-xs"], [1, "text-base-200"], i18n_6, [1, "flex", "items-center", "text-subtitle"], ["name", "icon-swap-horizonal-small", 1, "ml-1", "text-lg", 3, "click"], i18n_8, [1, "text-right", "text-subtitle"], i18n_10, i18n_12, i18n_14, i18n_16, [1, "rounded-4", "bg-base-300", "mb-4", "p-3"], [1, "mb-2", "text-base", "font-bold", "text-title-10"], i18n_18, [1, "flex", "items-center", "justify-between", "mb-3"], [1, "text-title-10", "text-sm"], i18n_20, [1, "text-subtitle-2", "flex", "items-center", "text-xs"], i18n_22, [1, "ml-auto", "text-subtitle", "text-xs"], ["footer", ""], [1, "text-xs", "text-subtitle-2", "my-1.5", "text-center"], i18n_24, ["bnRippleButton", "", 1, "bg-primary", "rounded-12", "flex", "h-12", "w-full", "items-center", "justify-center", "text-lg", "font-extrabold", "text-white", 3, "disabled", "click"], [1, "relative"], [1, "icon-6", "absolute", "-right-6", "top-0", 3, "loadingTheme", "showLoading"], [1, "bg-blue-10", "rounded-1", "flex", "items-center", "border", "border-white", "pr-1"], [3, "swapChainName"], [1, "text-primary", "text-xxs"], [1, "bg-blue-10", "rounded-1", "flex", "items-center", "border", "border-white", "px-1", "py-0.5"], [1, "text-primary", "leading-2.5", "text-xxs", "ml-0.5"], [1, "flex", "items-center", "mb-3"], [1, "text-title-10", "ml-auto", "text-sm", "font-bold"], [1, "mx-1", 3, "size", "swapChainName", "swapCoinName"], [3, "iconSize", "swapCoinName", "swapChainName"], ["class", "flex items-center mb-3"]];
  },
  template: function SwapDetailPanelPage_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](0, "common-page", 0)(1, "button", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵlistener"]("click", function SwapDetailPanelPage_Template_button_click_1_listener() {
        return ctx.handleClose();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelement"](2, "bs-icon", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](3, "div", 3)(4, "div", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵi18n"](5, 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](6, "div", 6);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtext"](7);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](8, "div", 7);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtext"](9);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelement"](10, "bs-token-with-chain-icon", 8);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](11, "div", 9)(12, "div", 10)(13, "div", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵi18n"](14, 11);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](15, "div", 6);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtext"](16);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](17, "div", 7);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtext"](18);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelement"](19, "bs-token-with-chain-icon", 8);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](20, "div", 12)(21, "div", 13);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelement"](22, "bs-swap-token-chain-icon", 14);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](23, "div", 15);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtext"](24);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtemplate"](25, SwapDetailPanelPage_Conditional_25_Template, 4, 2, "div", 16);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](26, "div", 17);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtext"](27);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](28, "div", 18);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelement"](29, "bs-icon", 19);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](30, "div", 13);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelement"](31, "bs-swap-token-chain-icon", 14);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](32, "div", 15);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtext"](33);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtemplate"](34, SwapDetailPanelPage_Conditional_34_Template, 4, 2, "div", 20);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](35, "div", 17);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtext"](36);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]()()();
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](37, "div", 21)(38, "div", 22);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵi18n"](39, 23);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](40, "div", 24);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtext"](41);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](42, "bs-icon", 25);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵlistener"]("click", function SwapDetailPanelPage_Template_bs_icon_click_42_listener() {
        return ctx.handleReversePrice();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵpipe"](43, "color");
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](44, "div");
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵi18n"](45, 26);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](46, "div", 27);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtext"](47);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](48, "div");
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵi18n"](49, 28);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](50, "div", 27);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtext"](51);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](52, "div");
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵi18n"](53, 29);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](54, "div", 27);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtext"](55);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](56, "div");
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵi18n"](57, 30);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](58, "div", 27);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵi18n"](59, 31);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]()()();
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](60, "div", 32)(61, "div", 33);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵi18n"](62, 34);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](63, "div", 35)(64, "div", 36);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵi18n"](65, 37);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](66, "div");
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵrepeaterCreate"](67, SwapDetailPanelPage_For_68_Template, 6, 12, "div", 56, _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵrepeaterTrackByIndex"]);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](69, "div", 38)(70, "div");
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵi18n"](71, 39);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](72, "div", 40);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtext"](73);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]()()();
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](74, "section", 41)(75, "div", 42);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵi18n"](76, 43);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](77, "button", 44);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵlistener"]("click", function SwapDetailPanelPage_Template_button_click_77_listener() {
        return ctx.submit();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](78, "div", 45);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtext"](79);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelement"](80, "bn-loading-wrapper", 46);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]()()()();
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵproperty"]("hideBackButton", true)("headerClass", "pt-2.5 text-lg")("titleClass", "!text-title-10")("contentBackground", "white")("contentSafeArea", true)("contentClass", "!px-3")("footerClass", "pb-0");
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵproperty"]("mode", "icon");
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](6);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtextInterpolate"](ctx.sellPanel.amount);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtextInterpolate"](ctx.sellPanel.coin);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵproperty"]("size", 24)("swapCoinName", ctx.sellPanel.coin)("swapChainName", ctx.sellPanel.chain);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](6);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtextInterpolate"](ctx.expectBuyAmount);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtextInterpolate"](ctx.buyPanel.coin);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵproperty"]("size", 24)("swapCoinName", ctx.buyPanel.coin)("swapChainName", ctx.buyPanel.chain);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵproperty"]("swapCoinName", ctx.sellPanel.coin)("swapChainName", ctx.sellPanel.chain);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtextInterpolate"](ctx.sellPanel.coin);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵconditional"](25, !ctx.sellCoinIsU ? 25 : -1);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtextInterpolate"](ctx.expectSellAmount);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](4);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵproperty"]("swapCoinName", ctx.buyPanel.coin)("swapChainName", ctx.buyPanel.chain);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtextInterpolate"](ctx.buyPanel.coin);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵconditional"](34, !ctx.buyCoinIsU ? 34 : -1);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtextInterpolate"](ctx.expectBuyAmount);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](5);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtextInterpolate3"](" 1 ", ctx.price.leftCoin, " = ", ctx.price.showPrice, " ", ctx.price.rightCoin, " ");
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵpureFunction1"](47, _c27, _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵpipeBind1"](43, 45, "title-10")));
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](5);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtextInterpolate2"]("", ctx.leastGainAmount, " ", ctx.buyPanel.coin, "");
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵi18nExp"](ctx.feeRatio);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵi18nApply"](49);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtextInterpolate2"]("", ctx.transactionFee, " ", ctx.sellPanel.coin, "");
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](4);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtextInterpolate"](ctx.slippageTolerance);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](4);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵi18nExp"](ctx.expirationTime);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵi18nApply"](59);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](8);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵrepeater"](ctx.expectedIncreasedLiquiditys);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](6);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtextInterpolate"](ctx.addLiquidityRatio);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](4);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵproperty"]("disabled", ctx.disabled);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtextInterpolate1"](" ", ctx.btnText, " ");
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵproperty"]("loadingTheme", "ellipsis")("showLoading", ctx.loading);
    }
  },
  dependencies: [_components_swap_token_chain_icon_swap_token_chain_icon_component__WEBPACK_IMPORTED_MODULE_14__.SwapTokenChainIconComponent, _bnqkl_framework_pipes__WEBPACK_IMPORTED_MODULE_1__.AmountFixedPipe, _modules_page_module__WEBPACK_IMPORTED_MODULE_2__.CommonPageModule, _libs_bnf_components_ripple_button_ripple_button_directive__WEBPACK_IMPORTED_MODULE_15__.RippleButtonDirective, _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_16__.CommonPageComponent, _icon_icon_component__WEBPACK_IMPORTED_MODULE_17__.IconComponent, _libs_bnf_components_loading_wrapper_loading_wrapper_component__WEBPACK_IMPORTED_MODULE_18__.LoadingWrapperComponent, _pipes_color_color_pipe__WEBPACK_IMPORTED_MODULE_19__.ColorPipe, _components_token_with_chain_icon_token_with_chain_icon_component__WEBPACK_IMPORTED_MODULE_7__.TokenWithnChainIconComponent],
  encapsulation: 2,
  changeDetection: 0
});
(0,tslib__WEBPACK_IMPORTED_MODULE_21__.__decorate)([SwapDetailPanelPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_21__.__metadata)("design:type", Object)], SwapDetailPanelPage.prototype, "leastGainAmount", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_21__.__decorate)([SwapDetailPanelPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_21__.__metadata)("design:type", Object)], SwapDetailPanelPage.prototype, "transactionFee", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_21__.__decorate)([SwapDetailPanelPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_21__.__metadata)("design:type", Object)], SwapDetailPanelPage.prototype, "feeRatio", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_21__.__decorate)([SwapDetailPanelPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_21__.__metadata)("design:type", Object)], SwapDetailPanelPage.prototype, "slippageTolerance", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_21__.__decorate)([SwapDetailPanelPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_21__.__metadata)("design:type", Object)], SwapDetailPanelPage.prototype, "expirationTime", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_21__.__decorate)([SwapDetailPanelPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_21__.__metadata)("design:type", Object)], SwapDetailPanelPage.prototype, "addLiquidityRatio", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_21__.__decorate)([SwapDetailPanelPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_21__.__metadata)("design:type", Object)], SwapDetailPanelPage.prototype, "priceSell", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_21__.__decorate)([SwapDetailPanelPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_21__.__metadata)("design:type", Object)], SwapDetailPanelPage.prototype, "priceBuy", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_21__.__decorate)([SwapDetailPanelPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_21__.__metadata)("design:type", String)], SwapDetailPanelPage.prototype, "expectSellAmount", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_21__.__decorate)([SwapDetailPanelPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_21__.__metadata)("design:type", Object)], SwapDetailPanelPage.prototype, "btnText", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_21__.__decorate)([SwapDetailPanelPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_21__.__metadata)("design:type", Object)], SwapDetailPanelPage.prototype, "loading", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_21__.__decorate)([SwapDetailPanelPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_21__.__metadata)("design:type", Object)], SwapDetailPanelPage.prototype, "disabled", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_21__.__decorate)([SwapDetailPanelPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_21__.__metadata)("design:type", Object)], SwapDetailPanelPage.prototype, "sellCoinIcon", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_21__.__decorate)([SwapDetailPanelPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_21__.__metadata)("design:type", Object)], SwapDetailPanelPage.prototype, "sellChainIcon", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_21__.__decorate)([SwapDetailPanelPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_21__.__metadata)("design:type", Object)], SwapDetailPanelPage.prototype, "buyCoinIcon", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_21__.__decorate)([SwapDetailPanelPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_21__.__metadata)("design:type", Object)], SwapDetailPanelPage.prototype, "buyChainIcon", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_21__.__decorate)([SwapDetailPanelPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_21__.__metadata)("design:type", Object)], SwapDetailPanelPage.prototype, "showAddLiquidityDetail", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_21__.__decorate)([SwapDetailPanelPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_21__.__metadata)("design:type", Object)], SwapDetailPanelPage.prototype, "sellCoinIsU", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_21__.__decorate)([SwapDetailPanelPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_21__.__metadata)("design:type", Object)], SwapDetailPanelPage.prototype, "buyCoinIsU", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_21__.__decorate)([SwapDetailPanelPage.OnInit(), (0,tslib__WEBPACK_IMPORTED_MODULE_21__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_21__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_21__.__metadata)("design:returntype", void 0)], SwapDetailPanelPage.prototype, "init", null);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SwapDetailPanelPage);

/***/ }),

/***/ 54838:
/*!***************************************************************************************!*\
  !*** ./apps/bfswap/src/components/version-info-panel/version-info-panel.component.ts ***!
  \***************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   VersionInfoPanelComponent: () => (/* binding */ VersionInfoPanelComponent),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 52542);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! tslib */ 90505);
/* harmony import */ var _modules_page_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ~modules/page.module */ 16381);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/core */ 61039);
/* harmony import */ var _components_version_upgrade_dialog_defines_version_upgrade_dialog_defines_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ~components/version-upgrade/dialog-defines/version-upgrade-dialog-defines.component */ 24499);
/* harmony import */ var _bnqkl_framework_plugins_toast__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @bnqkl/framework/plugins/toast */ 18030);
/* harmony import */ var _components_connect_wallet_panel_connect_wallet_panel_type__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ~components/connect-wallet-panel/connect-wallet-panel.type */ 9218);
/* harmony import */ var _components_connect_wallet_panel_connect_wallet_penel_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ~components/connect-wallet-panel/connect-wallet-penel.component */ 43551);
/* harmony import */ var _services_wallet_wallet_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ~services/wallet/wallet.service */ 54275);
/* harmony import */ var _components_version_upgrade_version_upgrade_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ~components/version-upgrade/version-upgrade.service */ 21673);
/* harmony import */ var _libs_bnf_modules_bottom_sheet_components_bottom_sheet_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../../../libs/bnf/modules/bottom-sheet/components/bottom-sheet.component */ 94072);
/* harmony import */ var _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../../../../libs/bnf/modules/page/common-page/common-page.component */ 62052);
/* harmony import */ var _icon_icon_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../icon/icon.component */ 18840);

var _class;













function VersionInfoPanelComponent_Conditional_15_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](0, "span", 19);
  }
}
function VersionInfoPanelComponent_Conditional_16_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "div", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](2, "div", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵi18n"](3, 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](4, "bs-icon", 23);
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](ctx_r1.newVersion);
  }
}
function VersionInfoPanelComponent_Conditional_17_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "div", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵi18n"](1, 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
  }
}
function VersionInfoPanelComponent_ng_template_23_Template(rf, ctx) {
  if (rf & 1) {
    const _r5 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "bs-connect-wallet-panel-page", 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵlistener"]("returnValue$", function VersionInfoPanelComponent_ng_template_23_Template_bs_connect_wallet_panel_page_returnValue__0_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵrestoreView"](_r5);
      const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵresetView"](ctx_r4.onConnectWallet($event));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("connectType", ctx_r3.selectWalletSheet.conncetType)("presetWallets", ctx_r3.selectWalletSheet.presetWallets);
  }
}
/** 版本信息弹窗 */
class VersionInfoPanelComponent extends _modules_page_module__WEBPACK_IMPORTED_MODULE_1__.CommonPageBase {
  constructor() {
    super(...arguments);
    /** 钱包服务 */
    this.walletService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_11__.inject)(_services_wallet_wallet_service__WEBPACK_IMPORTED_MODULE_6__.WalletService);
    /** 版本号 */
    this.version = '';
    /** 更新服务 */
    this._versionUpgradeService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_11__.inject)(_components_version_upgrade_version_upgrade_service__WEBPACK_IMPORTED_MODULE_7__.VersionUpgradeService);
    /** 正在确认版本号 */
    this.isCheckingVersion = true;
    /** 是否可以升级 */
    this.canUpgrade = false;
    /** 最新版本号 */
    this.newVersion = '';
    /** 钱包选择器的数据 */
    this.selectWalletSheet = {
      is_open: false,
      conncetType: _components_connect_wallet_panel_connect_wallet_panel_type__WEBPACK_IMPORTED_MODULE_4__.CONNECT_TYPE.CONNECT_WALLET,
      presetWallets: []
    };
  }
  /** 跳转用户协议 */
  jumpUserAgreement() {
    this.nav.routeTo('/mine/user-agreement');
  }
  /** 初始化 */
  initData() {
    // 获取版本号
    const version = localStorage.getItem('version');
    if (version) {
      this.version = version;
    }
  }
  checkUpdate() {
    var _this = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this.isCheckingVersion = true;
      const res = yield _this._versionUpgradeService.checkUpdate(_this.injectorForceGet(_angular_core__WEBPACK_IMPORTED_MODULE_11__.LOCALE_ID));
      _this.isCheckingVersion = false;
      if (typeof res !== 'object' || _this._versionUpgradeService.needUpgradeApp.hasNeed === false) {
        _this.canUpgrade = false;
      } else {
        _this.canUpgrade = true;
        _this.newVersion = res.version;
      }
    })();
  }
  /** 检查更新 */
  checkVersionUpgrade() {
    var _this2 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      if (_this2.isCheckingVersion) {
        return;
      }
      try {
        yield _this2._templateDialogService.openDialogByName('checkVersionUpgrade', {
          input: undefined
        });
      } catch (err) {
        if (err === false) {
          _bnqkl_framework_plugins_toast__WEBPACK_IMPORTED_MODULE_3__.Toast.show('已是最新版本');
          _this2.console.log('no need upgrade');
        } else {
          throw err;
        }
      }
    })();
  }
  /** 连接钱包事件 */
  onConnectWallet(data) {
    var _this3 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      if (data.walletName) {
        _this3.console.info('switch to wallet', data);
        _this3._returnRootPage();
      }
    })();
  }
  /** 跳转到root页面 */
  _returnRootPage() {
    // 取消所有订阅，修复setroot无法触发destroy的bug
    Array.from(this.walletService.allSubscribes.values()).forEach(subscribes => {
      subscribes.forEach(sub => {
        sub.unsubscribe();
      });
    });
    this.walletService.allSubscribes = new Map();
    // this.nav.routeBack('tabs');
    this.nav.setPageRoot('tabs');
  }
}
_class = VersionInfoPanelComponent;
_class.ɵfac = /*@__PURE__*/(() => {
  let ɵVersionInfoPanelComponent_BaseFactory;
  return function VersionInfoPanelComponent_Factory(t) {
    return (ɵVersionInfoPanelComponent_BaseFactory || (ɵVersionInfoPanelComponent_BaseFactory = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵgetInheritedFactory"](_class)))(t || _class);
  };
})();
_class.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdefineComponent"]({
  type: _class,
  selectors: [["bs-version-info-panel"]],
  standalone: true,
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵInheritDefinitionFeature"], _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵStandaloneFeature"]],
  decls: 24,
  vars: 7,
  consts: () => {
    let i18n_0;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_BTCSWAP$$APPS_BFSWAP_SRC_COMPONENTS_VERSION_INFO_PANEL_VERSION_INFO_PANEL_COMPONENT_TS_1 = goog.getMsg("BTCSwap");
      i18n_0 = MSG_EXTERNAL_BTCSWAP$$APPS_BFSWAP_SRC_COMPONENTS_VERSION_INFO_PANEL_VERSION_INFO_PANEL_COMPONENT_TS_1;
    } else {
      i18n_0 = "BTCSwap";
    }
    let i18n_2;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_8547377829580279349$$APPS_BFSWAP_SRC_COMPONENTS_VERSION_INFO_PANEL_VERSION_INFO_PANEL_COMPONENT_TS_3 = goog.getMsg("\u7248\u672C\u66F4\u65B0");
      i18n_2 = MSG_EXTERNAL_8547377829580279349$$APPS_BFSWAP_SRC_COMPONENTS_VERSION_INFO_PANEL_VERSION_INFO_PANEL_COMPONENT_TS_3;
    } else {
      i18n_2 = "\u7248\u672C\u66F4\u65B0";
    }
    let i18n_4;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_2802466502535724870$$APPS_BFSWAP_SRC_COMPONENTS_VERSION_INFO_PANEL_VERSION_INFO_PANEL_COMPONENT_TS_5 = goog.getMsg("\u7528\u6237\u534F\u8BAE");
      i18n_4 = MSG_EXTERNAL_2802466502535724870$$APPS_BFSWAP_SRC_COMPONENTS_VERSION_INFO_PANEL_VERSION_INFO_PANEL_COMPONENT_TS_5;
    } else {
      i18n_4 = "\u7528\u6237\u534F\u8BAE";
    }
    let i18n_6;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_NEW$$APPS_BFSWAP_SRC_COMPONENTS_VERSION_INFO_PANEL_VERSION_INFO_PANEL_COMPONENT_TS__7 = goog.getMsg(" New ");
      i18n_6 = MSG_EXTERNAL_NEW$$APPS_BFSWAP_SRC_COMPONENTS_VERSION_INFO_PANEL_VERSION_INFO_PANEL_COMPONENT_TS__7;
    } else {
      i18n_6 = " New ";
    }
    let i18n_8;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_570922992768511593$$APPS_BFSWAP_SRC_COMPONENTS_VERSION_INFO_PANEL_VERSION_INFO_PANEL_COMPONENT_TS__9 = goog.getMsg("\u5DF2\u662F\u6700\u65B0\u7248\u672C");
      i18n_8 = MSG_EXTERNAL_570922992768511593$$APPS_BFSWAP_SRC_COMPONENTS_VERSION_INFO_PANEL_VERSION_INFO_PANEL_COMPONENT_TS__9;
    } else {
      i18n_8 = "\u5DF2\u662F\u6700\u65B0\u7248\u672C";
    }
    return [[3, "hideBackButton", "hideHeader", "contentBackground", "contentSafeArea"], [1, "p-4"], [1, "flex", "justify-end"], ["name", "icon-close", 1, "ml-auto", "text-3xl", 3, "click"], [1, "flex", "flex-col", "items-center"], [1, "border-border-10", "rounded-4", "flex", "h-16", "w-16", "items-center", "justify-center", "border"], ["src", "../../assets/images/logo.png", 1, "h-12", "w-12"], [1, "text-title-10", "mb-2", "mt-3", "text-xl", "font-semibold"], i18n_0, [1, "text-subtitle-2", "text-xs"], [1, "mt-10", "flex", "items-center", "justify-between", 3, "click"], [1, "text-title-10", "text-base", "font-semibold"], i18n_2, [1, "flex", "items-center", "justify-end"], ["class", "duibs-loading duibs-loading-dots duibs-loading-md text-primary mx-auto block"], [1, "mb-3", "mt-8", "flex", "items-center", 3, "click"], i18n_4, ["name", "icon-chevron-right", 1, "ml-auto", "text-xl"], [3, "isOpen", "isOpenChange"], [1, "duibs-loading", "duibs-loading-dots", "duibs-loading-md", "text-primary", "mx-auto", "block"], [1, "text-subtitle-2", "ml-auto", "text-xs"], [1, "bg-primary", "text-xxs", "ml-2", "mr-1", "flex", "h-4", "items-center", "rounded-full", "px-2", "text-white"], i18n_6, ["name", "icon-chevron-right", 1, "text-xl"], i18n_8, [3, "connectType", "presetWallets", "returnValue$"]];
  },
  template: function VersionInfoPanelComponent_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "common-page", 0)(1, "div", 1)(2, "div", 2)(3, "bs-icon", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵlistener"]("click", function VersionInfoPanelComponent_Template_bs_icon_click_3_listener() {
        return ctx.nav.back();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](4, "div", 4)(5, "div", 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](6, "img", 6);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](7, "div", 7);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵi18n"](8, 8);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](9, "div", 9);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](10);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](11, "div", 10);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵlistener"]("click", function VersionInfoPanelComponent_Template_div_click_11_listener() {
        return ctx.checkVersionUpgrade();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](12, "div", 11);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵi18n"](13, 12);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](14, "div", 13);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](15, VersionInfoPanelComponent_Conditional_15_Template, 1, 0, "span", 14)(16, VersionInfoPanelComponent_Conditional_16_Template, 5, 1)(17, VersionInfoPanelComponent_Conditional_17_Template, 2, 0);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](18, "div", 15);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵlistener"]("click", function VersionInfoPanelComponent_Template_div_click_18_listener() {
        return ctx.jumpUserAgreement();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](19, "div", 11);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵi18n"](20, 16);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](21, "bs-icon", 17);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()()();
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](22, "common-bottom-sheet", 18);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵlistener"]("isOpenChange", function VersionInfoPanelComponent_Template_common_bottom_sheet_isOpenChange_22_listener($event) {
        return ctx.selectWalletSheet.is_open = $event;
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](23, VersionInfoPanelComponent_ng_template_23_Template, 1, 2, "ng-template");
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("hideBackButton", true)("hideHeader", true)("contentBackground", "white")("contentSafeArea", false);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](10);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](ctx.version);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](5);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵconditional"](15, ctx.isCheckingVersion ? 15 : ctx.canUpgrade ? 16 : ctx.canUpgrade == false ? 17 : -1);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](7);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("isOpen", ctx.selectWalletSheet.is_open);
    }
  },
  dependencies: [_modules_page_module__WEBPACK_IMPORTED_MODULE_1__.CommonPageModule, _libs_bnf_modules_bottom_sheet_components_bottom_sheet_component__WEBPACK_IMPORTED_MODULE_8__.BottomSheetComponent, _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_9__.CommonPageComponent, _icon_icon_component__WEBPACK_IMPORTED_MODULE_10__.IconComponent, _components_connect_wallet_panel_connect_wallet_penel_component__WEBPACK_IMPORTED_MODULE_5__["default"]],
  styles: [".mat-bottom-sheet-container {\n  border-top-left-radius: 1.25rem !important;\n  border-top-right-radius: 1.25rem !important;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL2FwcHMvYmZzd2FwL3NyYy9jb21wb25lbnRzL3ZlcnNpb24taW5mby1wYW5lbC92ZXJzaW9uLWluZm8tcGFuZWwuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSwwQ0FBQTtFQUNBLDJDQUFBO0FBQ0oiLCJzb3VyY2VzQ29udGVudCI6WyI6Om5nLWRlZXAgLm1hdC1ib3R0b20tc2hlZXQtY29udGFpbmVyIHtcclxuICAgIGJvcmRlci10b3AtbGVmdC1yYWRpdXM6IDEuMjVyZW0gIWltcG9ydGFudDtcclxuICAgIGJvcmRlci10b3AtcmlnaHQtcmFkaXVzOiAxLjI1cmVtICFpbXBvcnRhbnQ7XHJcbn0iXSwic291cmNlUm9vdCI6IiJ9 */"],
  changeDetection: 0
});
(0,tslib__WEBPACK_IMPORTED_MODULE_12__.__decorate)([VersionInfoPanelComponent.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_12__.__metadata)("design:type", Object)], VersionInfoPanelComponent.prototype, "version", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_12__.__decorate)([VersionInfoPanelComponent.OnInit(), (0,tslib__WEBPACK_IMPORTED_MODULE_12__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_12__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_12__.__metadata)("design:returntype", void 0)], VersionInfoPanelComponent.prototype, "initData", null);
(0,tslib__WEBPACK_IMPORTED_MODULE_12__.__decorate)([VersionInfoPanelComponent.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_12__.__metadata)("design:type", Object)], VersionInfoPanelComponent.prototype, "isCheckingVersion", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_12__.__decorate)([VersionInfoPanelComponent.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_12__.__metadata)("design:type", Object)], VersionInfoPanelComponent.prototype, "canUpgrade", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_12__.__decorate)([VersionInfoPanelComponent.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_12__.__metadata)("design:type", Object)], VersionInfoPanelComponent.prototype, "newVersion", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_12__.__decorate)([VersionInfoPanelComponent.OnReady(), (0,tslib__WEBPACK_IMPORTED_MODULE_12__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_12__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_12__.__metadata)("design:returntype", Promise)], VersionInfoPanelComponent.prototype, "checkUpdate", null);
(0,tslib__WEBPACK_IMPORTED_MODULE_12__.__decorate)([VersionInfoPanelComponent.States(1), (0,tslib__WEBPACK_IMPORTED_MODULE_12__.__metadata)("design:type", Object)], VersionInfoPanelComponent.prototype, "selectWalletSheet", void 0);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (VersionInfoPanelComponent);

/***/ }),

/***/ 5514:
/*!*************************************************************************************!*\
  !*** ./apps/bfswap/src/components/wallet-info-panel/wallet-info-panel.component.ts ***!
  \*************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   WalletInfoPanelComponent: () => (/* binding */ WalletInfoPanelComponent),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 52542);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! tslib */ 90505);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/core */ 61039);
/* harmony import */ var _services_wallet_wallet_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ~services/wallet/wallet.service */ 54275);
/* harmony import */ var _modules_page_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ~modules/page.module */ 16381);
/* harmony import */ var _services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ~services/wallet/wallet.helper */ 84813);
/* harmony import */ var _bnqkl_framework_pipes__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @bnqkl/framework/pipes */ 80909);
/* harmony import */ var _bnqkl_framework_plugins__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @bnqkl/framework/plugins */ 43990);
/* harmony import */ var _bnqkl_util_web_extends_promise__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @bnqkl/util-web/extends-promise */ 87778);
/* harmony import */ var _components_connect_wallet_panel_connect_wallet_panel_type__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ~components/connect-wallet-panel/connect-wallet-panel.type */ 9218);
/* harmony import */ var _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../../../libs/bnf/modules/page/common-page/common-page.component */ 62052);
/* harmony import */ var _icon_icon_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../icon/icon.component */ 18840);

var _class;












function WalletInfoPanelComponent_For_19_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "div", 20)(1, "div", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](2, "bs-icon", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](3, "div", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](5, "div", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpipe"](7, "addressHidden");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const item_r1 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("name", item_r1.icon);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtextInterpolate"](item_r1.chain);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpipeBind1"](7, 3, item_r1.address));
  }
}
/** 钱包信息弹窗 */
class WalletInfoPanelComponent extends _modules_page_module__WEBPACK_IMPORTED_MODULE_2__.CommonPageBase {
  constructor() {
    super(...arguments);
    /** 返回类型 */
    this.returnValue$ = new _modules_page_module__WEBPACK_IMPORTED_MODULE_2__.PageReturnValue();
    /** 钱包服务 */
    this.walletService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_10__.inject)(_services_wallet_wallet_service__WEBPACK_IMPORTED_MODULE_1__.WalletService);
    /** 链数据 */
    this.chainInfo = [];
    /** 钱包选择器的数据 */
    this.selectWalletSheet = {
      is_open: false,
      conncetType: _components_connect_wallet_panel_connect_wallet_panel_type__WEBPACK_IMPORTED_MODULE_7__.CONNECT_TYPE.CONNECT_WALLET,
      presetWallets: []
    };
  }
  /** 初始化数据 */
  initData() {
    if (this.connectedWallet) {
      for (const [key, value] of this.connectedWallet.assetInfoListMap) {
        const icon = (0,_services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_3__.transferToChainIcon)(key || 'Default');
        this.chainInfo.push({
          icon,
          chain: key,
          address: value.address
        });
      }
    }
  }
  /** 断开钱包 */
  disconnectWallet() {
    var _this = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const result = yield _this.confirm({
        bodyMessage: "Do you want to exit the current wallet account?",
        footerTheme: 'normal'
      });
      _this._templateDialogService;
      yield (0,_bnqkl_util_web_extends_promise__WEBPACK_IMPORTED_MODULE_6__.sleep)(250);
      if (result) {
        const result = yield _this.walletService.disconnectWallet();
        if (result) {
          _this.console.info('disconnect wallet success');
          _this._returnRootPage();
          _bnqkl_framework_plugins__WEBPACK_IMPORTED_MODULE_5__.Toast.show(`已断开连接`);
        } else {
          _bnqkl_framework_plugins__WEBPACK_IMPORTED_MODULE_5__.Toast.show(`断开失败`);
        }
      }
    })();
  }
  /** 跳转到root页面 */
  _returnRootPage() {
    // 取消所有订阅，修复setroot无法触发destroy的bug
    Array.from(this.walletService.allSubscribes.values()).forEach(subscribes => {
      subscribes.forEach(sub => {
        sub.unsubscribe();
      });
    });
    this.walletService.allSubscribes = new Map();
    // this.nav.routeBack('tabs');
    // this.nav.setPageRoot('tabs');
    this.nav.back();
  }
  /** 打开钱包连接选择弹窗 */
  openSwapWalletSheet() {
    var _this2 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      // const { selectWalletSheet } = this;
      // if (selectWalletSheet.is_open) {
      //   return;
      // }
      // this.selectWalletSheet.presetWallets = await this.walletService.getPresetWallet();
      // selectWalletSheet.is_open = true;
      _this2.returnValue$.return({
        reconnectWallet: true
      });
      _this2.nav.back();
    })();
  }
}
_class = WalletInfoPanelComponent;
_class.ɵfac = /*@__PURE__*/(() => {
  let ɵWalletInfoPanelComponent_BaseFactory;
  return function WalletInfoPanelComponent_Factory(t) {
    return (ɵWalletInfoPanelComponent_BaseFactory || (ɵWalletInfoPanelComponent_BaseFactory = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵgetInheritedFactory"](_class)))(t || _class);
  };
})();
_class.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵdefineComponent"]({
  type: _class,
  selectors: [["bs-wallet-info-panel"]],
  inputs: {
    connectedWallet: "connectedWallet",
    walletIcon: "walletIcon"
  },
  outputs: {
    returnValue$: "returnValue$"
  },
  standalone: true,
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵInheritDefinitionFeature"], _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵStandaloneFeature"]],
  decls: 22,
  vars: 6,
  consts: () => {
    let i18n_0;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_ETHMETA$$APPS_BFSWAP_SRC_COMPONENTS_WALLET_INFO_PANEL_WALLET_INFO_PANEL_COMPONENT_TS_1 = goog.getMsg("{$interpolation} \u94B1\u5305", {
        "interpolation": "\uFFFD0\uFFFD"
      }, {
        original_code: {
          "interpolation": "{{ connectedWallet?.walletName }}"
        }
      });
      i18n_0 = MSG_EXTERNAL_ETHMETA$$APPS_BFSWAP_SRC_COMPONENTS_WALLET_INFO_PANEL_WALLET_INFO_PANEL_COMPONENT_TS_1;
    } else {
      i18n_0 = "" + "\uFFFD0\uFFFD" + " \u94B1\u5305";
    }
    let i18n_2;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_5632804454582451636$$APPS_BFSWAP_SRC_COMPONENTS_WALLET_INFO_PANEL_WALLET_INFO_PANEL_COMPONENT_TS_3 = goog.getMsg("\u5DF2\u8FDE\u63A5");
      i18n_2 = MSG_EXTERNAL_5632804454582451636$$APPS_BFSWAP_SRC_COMPONENTS_WALLET_INFO_PANEL_WALLET_INFO_PANEL_COMPONENT_TS_3;
    } else {
      i18n_2 = "\u5DF2\u8FDE\u63A5";
    }
    let i18n_4;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_6503494012668698771$$APPS_BFSWAP_SRC_COMPONENTS_WALLET_INFO_PANEL_WALLET_INFO_PANEL_COMPONENT_TS_5 = goog.getMsg("\u5173\u8054\u7684\u94B1\u5305\u5404\u94FE\u5730\u5740\u5982\u4E0B:");
      i18n_4 = MSG_EXTERNAL_6503494012668698771$$APPS_BFSWAP_SRC_COMPONENTS_WALLET_INFO_PANEL_WALLET_INFO_PANEL_COMPONENT_TS_5;
    } else {
      i18n_4 = "\u5173\u8054\u7684\u94B1\u5305\u5404\u94FE\u5730\u5740\u5982\u4E0B:";
    }
    let i18n_6;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_5452139563909373752$$APPS_BFSWAP_SRC_COMPONENTS_WALLET_INFO_PANEL_WALLET_INFO_PANEL_COMPONENT_TS_7 = goog.getMsg(" \u91CD\u65B0\u8FDE\u63A5 ");
      i18n_6 = MSG_EXTERNAL_5452139563909373752$$APPS_BFSWAP_SRC_COMPONENTS_WALLET_INFO_PANEL_WALLET_INFO_PANEL_COMPONENT_TS_7;
    } else {
      i18n_6 = " \u91CD\u65B0\u8FDE\u63A5 ";
    }
    return [[3, "hideBackButton", "hideHeader", "contentBackground", "contentSafeArea"], [1, "p-4"], [1, "flex"], [1, "rounded-4", "border-border-10", "flex", "h-14", "w-14", "items-center", "justify-center", "border"], [1, "text-4xl", 3, "name"], [1, "ml-2", "flex", "flex-col"], [1, "flex", "items-center"], [1, "text-black-10", "text-lg", "font-semibold"], i18n_0, ["name", "icon-log-out", 1, "text-red-10", "ml-2", "text-base", 3, "click"], [1, "bg-bg-tip-green-6", "flex", "w-fit", "items-center", "justify-center", "px-2", "py-1", "rounded"], [1, "bg-green-20", "mr-1", "h-1.5", "w-1.5", "rounded-full"], [1, "text-green-20", "text-xs"], i18n_2, ["name", "icon-close", 1, "ml-auto", "text-3xl", 3, "click"], [1, "px-3.5"], [1, "text-subtitle", "mb-4", "mt-8", "text-xs"], i18n_4, [1, "bg-primary", "mt-8", "flex", "items-center", "justify-center", "rounded-full", "py-3", "text-lg", "leading-6", "text-white", 3, "click"], i18n_6, [1, "mb-2", "flex", "items-center"], [1, "rounded-1.5", "bg-blue-10", "flex", "h-6", "w-6", "items-center", "justify-center"], [1, "text-lg", 3, "name"], [1, "text-subtitle", "ml-2", "text-xs"], [1, "text-title-10", "ml-auto", "text-xs", "font-semibold"], ["class", "mb-2 flex items-center"]];
  },
  template: function WalletInfoPanelComponent_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "common-page", 0)(1, "div", 1)(2, "div", 2)(3, "div", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](4, "bs-icon", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](5, "div", 5)(6, "div", 6)(7, "div", 7);
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵi18n"](8, 8);
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](9, "bs-icon", 9);
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("click", function WalletInfoPanelComponent_Template_bs_icon_click_9_listener() {
        return ctx.disconnectWallet();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](10, "div", 10);
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](11, "div", 11);
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](12, "div", 12);
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵi18n"](13, 13);
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()()();
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](14, "bs-icon", 14);
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("click", function WalletInfoPanelComponent_Template_bs_icon_click_14_listener() {
        return ctx.nav.back();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](15, "div", 15)(16, "div", 16);
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵi18n"](17, 17);
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵrepeaterCreate"](18, WalletInfoPanelComponent_For_19_Template, 8, 5, "div", 25, _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵrepeaterTrackByIndex"]);
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](20, "div", 18);
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("click", function WalletInfoPanelComponent_Template_div_click_20_listener() {
        return ctx.openSwapWalletSheet();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵi18n"](21, 19);
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()()();
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("hideBackButton", true)("hideHeader", true)("contentBackground", "white")("contentSafeArea", false);
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](4);
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("name", ctx.walletIcon);
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](4);
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵi18nExp"](ctx.connectedWallet == null ? null : ctx.connectedWallet.walletName);
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵi18nApply"](8);
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](10);
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵrepeater"](ctx.chainInfo);
    }
  },
  dependencies: [_modules_page_module__WEBPACK_IMPORTED_MODULE_2__.CommonPageModule, _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_8__.CommonPageComponent, _icon_icon_component__WEBPACK_IMPORTED_MODULE_9__.IconComponent, _bnqkl_framework_pipes__WEBPACK_IMPORTED_MODULE_4__.AddressHiddenPipe],
  styles: [".mat-bottom-sheet-container {\n  border-top-left-radius: 1.25rem !important;\n  border-top-right-radius: 1.25rem !important;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL2FwcHMvYmZzd2FwL3NyYy9jb21wb25lbnRzL3dhbGxldC1pbmZvLXBhbmVsL3dhbGxldC1pbmZvLXBhbmVsLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksMENBQUE7RUFDQSwyQ0FBQTtBQUNKIiwic291cmNlc0NvbnRlbnQiOlsiOjpuZy1kZWVwIC5tYXQtYm90dG9tLXNoZWV0LWNvbnRhaW5lciB7XHJcbiAgICBib3JkZXItdG9wLWxlZnQtcmFkaXVzOiAxLjI1cmVtICFpbXBvcnRhbnQ7XHJcbiAgICBib3JkZXItdG9wLXJpZ2h0LXJhZGl1czogMS4yNXJlbSAhaW1wb3J0YW50O1xyXG59Il0sInNvdXJjZVJvb3QiOiIifQ== */"],
  changeDetection: 0
});
(0,tslib__WEBPACK_IMPORTED_MODULE_11__.__decorate)([WalletInfoPanelComponent.OnInit(), (0,tslib__WEBPACK_IMPORTED_MODULE_11__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_11__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_11__.__metadata)("design:returntype", void 0)], WalletInfoPanelComponent.prototype, "initData", null);
(0,tslib__WEBPACK_IMPORTED_MODULE_11__.__decorate)([WalletInfoPanelComponent.States(1), (0,tslib__WEBPACK_IMPORTED_MODULE_11__.__metadata)("design:type", Object)], WalletInfoPanelComponent.prototype, "selectWalletSheet", void 0);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (WalletInfoPanelComponent);

/***/ }),

/***/ 12425:
/*!*********************************************************************!*\
  !*** ./apps/bfswap/src/pages/home/pages/market/market.component.ts ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   MarketPage: () => (/* binding */ MarketPage),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 52542);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! tslib */ 90505);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @angular/common */ 6729);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/core */ 61039);
/* harmony import */ var _modules_page_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ~modules/page.module */ 16381);
/* harmony import */ var _components_token_with_chain_icon_token_with_chain_icon_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ~components/token-with-chain-icon/token-with-chain-icon.component */ 11342);
/* harmony import */ var _market_type__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./market.type */ 35883);
/* harmony import */ var _services_liquidity_pool_liquidity_pool_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ~services/liquidity-pool/liquidity-pool.service */ 20213);
/* harmony import */ var _services_wallet_wallet_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ~services/wallet/wallet.service */ 54275);
/* harmony import */ var bignumber_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! bignumber.js */ 61994);
/* harmony import */ var _market_helper__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./market.helper */ 64875);
/* harmony import */ var _bnqkl_framework_directives__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @bnqkl/framework/directives */ 11100);
/* harmony import */ var _services_market_market_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ~services/market/market.service */ 89877);
/* harmony import */ var _pipes_significant_digits_significant_digits_pipe__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ~pipes/significant-digits/significant-digits.pipe */ 41856);
/* harmony import */ var _libs_bnf_components_pull_to_refresh_pull_to_refresh_directive__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../../../../../../libs/bnf/components/pull-to-refresh/pull-to-refresh.directive */ 97063);
/* harmony import */ var _libs_bnf_components_pull_to_refresh_pull_to_refresh_spinner_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../../../../../../libs/bnf/components/pull-to-refresh/pull-to-refresh-spinner.component */ 75387);
/* harmony import */ var _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../../../../../../../libs/bnf/modules/page/common-page/common-page.component */ 62052);

var _class;


















const _c2 = a0 => ({
  "text-left": a0
});
function MarketPage_For_7_Template(rf, ctx) {
  if (rf & 1) {
    const _r14 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](0, "div", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵlistener"]("click", function MarketPage_For_7_Template_div_click_0_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵrestoreView"](_r14);
      const filter_r8 = restoredCtx.$implicit;
      const ctx_r13 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵresetView"](ctx_r13.handleFilterClick(filter_r8.key));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](1, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelement"](3, "img", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const filter_r8 = ctx.$implicit;
    const i_r9 = ctx.$index;
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("ngClass", i_r9 === 0 ? "justify-start" : "justify-end");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵclassMap"](_angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpureFunction1"](5, _c2, i_r9 === 0));
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtextInterpolate"](filter_r8.title);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("src", ctx_r0.getIconByFilterKey(filter_r8.key), _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵsanitizeUrl"]);
  }
}
const _c3 = a0 => ({
  list: a0
});
function MarketPage_ng_container_9_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementContainer"](0, 13);
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnextContext"]();
    const _r3 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵreference"](11);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("ngTemplateOutlet", _r3)("ngTemplateOutletContext", _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpureFunction1"](2, _c3, ctx_r1.marketListByFilter));
  }
}
const _c4 = (a0, a1, a2) => ({
  "text-subtitle-2": a0,
  "text-green-20": a1,
  "text-red-10": a2
});
function MarketPage_ng_template_10_li_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r19 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](0, "li", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵlistener"]("click", function MarketPage_ng_template_10_li_2_Template_li_click_0_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵrestoreView"](_r19);
      const item_r17 = restoredCtx.$implicit;
      const ctx_r18 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵresetView"](ctx_r18.goToDetailPage(item_r17));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](1, "div", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelement"](2, "bs-token-with-chain-icon", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](3, "div", 20)(4, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](6, "span", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](7);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](8, "div", 22)(9, "span", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](10);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipe"](11, "significantDigits");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](12, "div", 24)(13, "span", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](14);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const item_r17 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("tokenSize", "text-4xl")("tokenName", item_r17.tokenIcon)("chainName", item_r17.chainIcon);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtextInterpolate1"](" ", item_r17.coinName, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtextInterpolate1"](" ", item_r17.chainName, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtextInterpolate1"]("", _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipeBind1"](11, 8, item_r17.price), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpureFunction3"](10, _c4, item_r17.fluctuation !== "--" && +item_r17.fluctuation === 0, item_r17.fluctuation !== "--" && +item_r17.fluctuation > 0, item_r17.fluctuation !== "--" && +item_r17.fluctuation < 0));
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtextInterpolate"](item_r17.fluctuation === "--" ? "--" : (item_r17.fluctuationNumber > 0 ? "+" : "") + item_r17.fluctuation + "%");
  }
}
function MarketPage_ng_template_10_Template(rf, ctx) {
  if (rf & 1) {
    const _r21 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](0, "ul", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵlistener"]("pulled$", function MarketPage_ng_template_10_Template_ul_pulled__0_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵrestoreView"](_r21);
      const ctx_r20 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵresetView"]($event.waitFor(ctx_r20.regetMarketList()));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelement"](1, "bn-pull-to-refresh-spinner", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtemplate"](2, MarketPage_ng_template_10_li_2_Template, 15, 14, "li", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const list_r15 = ctx.list;
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("emitDistance", 158)("maxDistance", 200);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("ngForOf", list_r15)("ngForTrackBy", ctx_r2.trackByKey("poolId"));
  }
}
function MarketPage_ng_template_12_ng_container_0_Template(rf, ctx) {
  if (rf & 1) {
    const _r24 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](1, "div", 26);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelement"](2, "img", 27);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](3, "span", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵi18n"](4, 29);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](5, "div", 30);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵlistener"]("click", function MarketPage_ng_template_12_ng_container_0_Template_div_click_5_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵrestoreView"](_r24);
      const ctx_r23 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵresetView"](ctx_r23.nav.routeTo("add-liquidity"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵi18n"](6, 31);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementContainerEnd"]();
  }
}
function MarketPage_ng_template_12_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtemplate"](0, MarketPage_ng_template_12_ng_container_0_Template, 7, 0, "ng-container", 25);
  }
  if (rf & 2) {
    const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnextContext"]();
    const _r7 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵreference"](15);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("ngIf", !ctx_r4.marketListUpdating)("ngIfElse", _r7);
  }
}
function MarketPage_ng_template_14_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](0, "div", 26);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelement"](1, "span", 32);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
  }
}
const _c9 = () => ({
  "--page-safe-area-inset-top": 0
});
/** 行情页面 */
class MarketPage extends _modules_page_module__WEBPACK_IMPORTED_MODULE_1__.CommonPageBase {
  constructor() {
    super(...arguments);
    /** 过滤选项 */
    this.filterOptions = [{
      title: "Name",
      key: _market_type__WEBPACK_IMPORTED_MODULE_3__.FILTER_OPTIONS_KEY.NAME
    }, {
      title: "Last Price" + '(USDM)',
      key: _market_type__WEBPACK_IMPORTED_MODULE_3__.FILTER_OPTIONS_KEY.PRICE
    }, {
      title: "24h Change",
      key: _market_type__WEBPACK_IMPORTED_MODULE_3__.FILTER_OPTIONS_KEY.FLUCTUATION
    }];
    /** 合约池服务 */
    this.poolService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_14__.inject)(_services_liquidity_pool_liquidity_pool_service__WEBPACK_IMPORTED_MODULE_4__.LiquidityPoolService);
    /** 錢包服務 */
    this.walletService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_14__.inject)(_services_wallet_wallet_service__WEBPACK_IMPORTED_MODULE_5__.WalletService);
    /** 市場服務 */
    this.marketService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_14__.inject)(_services_market_market_service__WEBPACK_IMPORTED_MODULE_9__.MarketService);
    /** poolList，初始化从数据库中获取 */
    this.marketList = [];
    /** 数据初始化 */
    this.inited = false;
    /** 是否正在更新數據 */
    this.marketListUpdating = false;
    // ws监听池子价格变化
    this.poolDetailChangeHandle = updatePoolListString => {
      const updatePoolList = JSON.parse(updatePoolListString);
      this.console.info('websocket pool price:market page', updatePoolList);
      if (updatePoolList == undefined || updatePoolList.length <= 0) {
        return;
      }
      if (this.inited == false) {
        return;
      }
      const marketList = this.marketList;
      updatePoolList.forEach(poolDetail => {
        const marketItem = marketList.find(mItem => {
          return poolDetail.poolId == mItem.poolId;
        });
        if (marketItem) {
          this.console.info('websocket pool price: check', marketItem);
          const newMarketItem = (0,_market_helper__WEBPACK_IMPORTED_MODULE_7__.transferPoolItemToMaketItem)(poolDetail);
          if (newMarketItem) {
            marketItem.fluctuation = newMarketItem.fluctuation;
            marketItem.fluctuationNumber = newMarketItem.fluctuationNumber;
            marketItem.price = newMarketItem.price;
            this.console.info('websocket pool price: to =>', newMarketItem);
            this.marketService.updateMarketList(this.marketList);
            this.cdRef.detectChanges();
          }
        }
      });
    };
  }
  /** 初始化数据 */
  dataInit() {
    var _this = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this.poolService.watchLiquidityPoolPriceChange(_this.poolDetailChangeHandle);
      _this.marketList = yield _this.marketService.getLiquidityPoolMarket();
      _this.console.log('Lifecycle MarketPage init:watchLiquidityPoolPriceChange');
      _this.initRemoteData();
    })();
  }
  initRemoteData() {
    var _this2 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      if (_this2.marketListUpdating === false && _this2.marketList.length <= 0) {
        _this2.marketListUpdating = true;
      }
      const poolList = yield _this2.poolService.wsGetLiquidityPoolMarketList();
      _this2.marketList = (0,_market_helper__WEBPACK_IMPORTED_MODULE_7__.transferPoolListToMaketList)(poolList);
      _this2.marketService.updateMarketList(_this2.marketList);
      _this2.marketListUpdating = false;
      _this2.inited = true;
      _this2.console.log('MarketPage init', 'get market list', poolList);
    })();
  }
  /** 清除订阅监听 */
  unsubscribe() {
    this.console.log('清除 订阅');
    this.poolList$ && this.poolList$.unsubscribe();
    this.poolDetailChange$ && this.poolDetailChange$.unsubscribe();
    this.walletService.allSubscribes.delete('MarketPage');
  }
  /** 过滤过后的列表 */
  get marketListByFilter() {
    if (this.activeFilter) {
      if (this.activeFilter.key === _market_type__WEBPACK_IMPORTED_MODULE_3__.FILTER_OPTIONS_KEY.PRICE) {
        return this.marketList.sort((poolA, poolB) => {
          var _this$activeFilter;
          const priceA = new bignumber_js__WEBPACK_IMPORTED_MODULE_6__["default"](poolA.price);
          const priceB = new bignumber_js__WEBPACK_IMPORTED_MODULE_6__["default"](poolB.price);
          if (((_this$activeFilter = this.activeFilter) === null || _this$activeFilter === void 0 ? void 0 : _this$activeFilter.value) === _market_type__WEBPACK_IMPORTED_MODULE_3__.FILTER_VALUE_ENUM.DESC) {
            return priceB.comparedTo(priceA);
          } else {
            return priceA.comparedTo(priceB);
          }
        });
      } else if (this.activeFilter.key === _market_type__WEBPACK_IMPORTED_MODULE_3__.FILTER_OPTIONS_KEY.NAME) {
        return this.marketList.sort((poolA, poolB) => {
          var _this$activeFilter2;
          if (((_this$activeFilter2 = this.activeFilter) === null || _this$activeFilter2 === void 0 ? void 0 : _this$activeFilter2.value) === _market_type__WEBPACK_IMPORTED_MODULE_3__.FILTER_VALUE_ENUM.DESC) {
            return poolB.coinName > poolA.coinName ? 1 : -1;
          } else {
            return poolA.coinName > poolB.coinName ? 1 : -1;
          }
        });
      } else if (this.activeFilter.key === _market_type__WEBPACK_IMPORTED_MODULE_3__.FILTER_OPTIONS_KEY.FLUCTUATION) {
        return this.marketList.sort((poolA, poolB) => {
          var _this$activeFilter3;
          const fluctuationRangeA = new bignumber_js__WEBPACK_IMPORTED_MODULE_6__["default"](poolB.fluctuation || '0');
          const fluctuationRangeB = new bignumber_js__WEBPACK_IMPORTED_MODULE_6__["default"](poolA.fluctuation || '0');
          if (((_this$activeFilter3 = this.activeFilter) === null || _this$activeFilter3 === void 0 ? void 0 : _this$activeFilter3.value) === _market_type__WEBPACK_IMPORTED_MODULE_3__.FILTER_VALUE_ENUM.DESC) {
            return fluctuationRangeA.comparedTo(fluctuationRangeB);
          } else {
            return fluctuationRangeB.comparedTo(fluctuationRangeA);
          }
        });
      } else {
        return this.marketList;
      }
    }
    // 未激活排序依据
    else {
      return this.marketList;
    }
  }
  /**
   * 根据过滤器的值设置过滤图标
   *
   * @param key 过滤器对应键值
   * @returns 过滤头的图片路径
   */
  getIconByFilterKey(key) {
    if (this.activeFilter && this.activeFilter.key == key) {
      return _market_type__WEBPACK_IMPORTED_MODULE_3__.FILTER_ICON[this.activeFilter.value];
    }
    return _market_type__WEBPACK_IMPORTED_MODULE_3__.FILTER_ICON[_market_type__WEBPACK_IMPORTED_MODULE_3__.FILTER_VALUE_ENUM.DEFAULT];
  }
  /**
   * 更新排序条件
   *
   * @param filterKey 当前被点击的过滤器的值
   * @returns
   */
  handleFilterClick(filterKey) {
    if (this.marketList.length == 0) {
      return;
    }
    if (this.activeFilter) {
      const {
        key,
        value
      } = this.activeFilter;
      // 切换排序依据
      if (key == filterKey) {
        this.activeFilter.value = value == _market_type__WEBPACK_IMPORTED_MODULE_3__.FILTER_VALUE_ENUM.ASC ? _market_type__WEBPACK_IMPORTED_MODULE_3__.FILTER_VALUE_ENUM.DESC : _market_type__WEBPACK_IMPORTED_MODULE_3__.FILTER_VALUE_ENUM.ASC;
      }
      // 切换排序类目
      else {
        this.activeFilter = {
          key: filterKey,
          value: _market_type__WEBPACK_IMPORTED_MODULE_3__.FILTER_VALUE_ENUM.ASC
        };
      }
    } else {
      this.activeFilter = {
        key: filterKey,
        value: _market_type__WEBPACK_IMPORTED_MODULE_3__.FILTER_VALUE_ENUM.ASC
      };
    }
  }
  /**
   *  池子详情页面
   *
   * @param itemInfo
   */
  goToDetailPage(liquidityDetail) {
    this.nav.routeTo('liquidity-detail', {
      poolDetailstring: JSON.stringify(liquidityDetail)
    });
  }
  /** 离开页面取消监听 */
  pageOnPause() {
    this.poolService.unwatchLiquidityPoolPriceChange(this.poolDetailChangeHandle);
    this.console.log('Lifecycle MarketPage pause: unwatchLiquidityPoolPriceChange');
  }
  /** 返回页面事件 */
  pageOnResume() {
    var _this3 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this3.poolService.watchLiquidityPoolPriceChange(_this3.poolDetailChangeHandle);
      _this3.console.log('Lifecycle MarketPage Resume: watchLiquidityPoolPriceChange');
      yield _this3.regetMarketList();
    })();
  }
  /** 重置行情列表 */
  regetMarketList() {
    var _this4 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const poolList = yield _this4.poolService.wsGetLiquidityPoolMarketList();
      _this4.marketList = (0,_market_helper__WEBPACK_IMPORTED_MODULE_7__.transferPoolListToMaketList)(poolList);
      _this4.marketService.updateMarketList(_this4.marketList);
      _this4.console.log('MarketPage get market list', poolList);
    })();
  }
}
_class = MarketPage;
_class.ɵfac = /*@__PURE__*/(() => {
  let ɵMarketPage_BaseFactory;
  return function MarketPage_Factory(t) {
    return (ɵMarketPage_BaseFactory || (ɵMarketPage_BaseFactory = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵgetInheritedFactory"](_class)))(t || _class);
  };
})();
_class.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵdefineComponent"]({
  type: _class,
  selectors: [["bs-market-page"]],
  standalone: true,
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵInheritDefinitionFeature"], _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵStandaloneFeature"]],
  decls: 16,
  vars: 6,
  consts: () => {
    let i18n_0;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_7340161344404279421$$APPS_BFSWAP_SRC_PAGES_HOME_PAGES_MARKET_MARKET_COMPONENT_TS_1 = goog.getMsg("\u884C\u60C5");
      i18n_0 = MSG_EXTERNAL_7340161344404279421$$APPS_BFSWAP_SRC_PAGES_HOME_PAGES_MARKET_MARKET_COMPONENT_TS_1;
    } else {
      i18n_0 = "\u884C\u60C5";
    }
    let i18n_5;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_NO_TRADING_POOL_HAS_BEEN_CREATED_YET$$APPS_BFSWAP_SRC_PAGES_HOME_PAGES_MARKET_MARKET_COMPONENT_TS___6 = goog.getMsg("No trading pool has been created yet");
      i18n_5 = MSG_EXTERNAL_NO_TRADING_POOL_HAS_BEEN_CREATED_YET$$APPS_BFSWAP_SRC_PAGES_HOME_PAGES_MARKET_MARKET_COMPONENT_TS___6;
    } else {
      i18n_5 = "No trading pool has been created yet";
    }
    let i18n_7;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_INCREASE_LIQUIDITY$$APPS_BFSWAP_SRC_PAGES_HOME_PAGES_MARKET_MARKET_COMPONENT_TS___8 = goog.getMsg(" Increase liquidity ");
      i18n_7 = MSG_EXTERNAL_INCREASE_LIQUIDITY$$APPS_BFSWAP_SRC_PAGES_HOME_PAGES_MARKET_MARKET_COMPONENT_TS___8;
    } else {
      i18n_7 = " Increase liquidity ";
    }
    return [[3, "headerTitle", "ngStyle", "hideHeader"], [1, "h-full", "overflow-hidden", "pt-4"], [1, "flex", "h-10", "items-center", "px-4"], [1, "text-title-10", "text-[2rem]", "font-semibold"], i18n_0, [1, "text-base-gray", "grid", "h-12", "grid-cols-[auto,1fr,6rem]", "py-3", "pl-4", "pr-1"], ["bnRestoreScrollPosition", "", 1, "_market-list-height", "flex", "w-full", "flex-col", "overflow-y-auto", "rounded-t-2xl", "bg-white", "px-4"], [3, "ngTemplateOutlet", "ngTemplateOutletContext", 4, "ngIf", "ngIfElse"], ["listView", ""], ["emptyListView", ""], ["updatingListView", ""], [1, "flex", "items-center", "text-xs", 3, "ngClass", "click"], [1, "h-6", "w-6", 3, "src"], [3, "ngTemplateOutlet", "ngTemplateOutletContext"], ["wPullToRefresh", "", 3, "emitDistance", "maxDistance", "pulled$"], [1, "text-subtext"], ["class", "font grid grid-cols-[auto,1fr,6rem] items-center py-2.5 font-semibold", 3, "click", 4, "ngFor", "ngForOf", "ngForTrackBy"], [1, "font", "grid", "grid-cols-[auto,1fr,6rem]", "items-center", "py-2.5", "font-semibold", 3, "click"], [1, "flex", "w-full", "items-center"], [3, "tokenSize", "tokenName", "chainName"], [1, "text-title-10", "ml-2", "flex", "flex-col", "overflow-hidden", "text-ellipsis", "text-base"], [1, "text-base-200", "text-xs", "font-normal"], [1, "flex", "items-center", "justify-end", "overflow-hidden", "text-ellipsis"], [1, "text-black-10", "mr-0.5", "overflow-hidden", "text-ellipsis"], [1, "flex", "w-full", "flex-col", "justify-end", 3, "ngClass"], [4, "ngIf", "ngIfElse"], [1, "flex", "h-full", "w-full", "flex-col", "items-center", "justify-center"], ["src", "./assets/images/placeholder-2.png", 1, "-mt-30"], [1, "text-line", "text-sm", "text-gray-400"], i18n_5, [1, "duibs-btn", "duibs-btn-primary", "mt-8", "w-[10.25rem]", "rounded-full", "text-white", 3, "click"], i18n_7, [1, "duibs-loading", "duibs-loading-infinity", "duibs-loading-lg", "text-primary"], ["class", "flex items-center text-xs", 3, "ngClass"]];
  },
  template: function MarketPage_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](0, "common-page", 0)(1, "div", 1)(2, "div", 2)(3, "div", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵi18n"](4, 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](5, "header", 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵrepeaterCreate"](6, MarketPage_For_7_Template, 4, 7, "div", 33, _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵrepeaterTrackByIndex"]);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](8, "div", 6);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtemplate"](9, MarketPage_ng_container_9_Template, 1, 4, "ng-container", 7);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]()()();
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtemplate"](10, MarketPage_ng_template_10_Template, 3, 4, "ng-template", null, 8, _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtemplateRefExtractor"])(12, MarketPage_ng_template_12_Template, 1, 2, "ng-template", null, 9, _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtemplateRefExtractor"])(14, MarketPage_ng_template_14_Template, 2, 0, "ng-template", null, 10, _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtemplateRefExtractor"]);
    }
    if (rf & 2) {
      const _r5 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵreference"](13);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("headerTitle", "Market")("ngStyle", _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpureFunction0"](5, _c9))("hideHeader", true);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](6);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵrepeater"](ctx.filterOptions);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("ngIf", ctx.marketList.length)("ngIfElse", _r5);
    }
  },
  dependencies: [_pipes_significant_digits_significant_digits_pipe__WEBPACK_IMPORTED_MODULE_10__.SignificantDigitsPipe, _modules_page_module__WEBPACK_IMPORTED_MODULE_1__.CommonPageModule, _libs_bnf_components_pull_to_refresh_pull_to_refresh_directive__WEBPACK_IMPORTED_MODULE_11__.PullToRefreshDirective, _libs_bnf_components_pull_to_refresh_pull_to_refresh_spinner_component__WEBPACK_IMPORTED_MODULE_12__.PullToRefreshSpinnerComponent, _angular_common__WEBPACK_IMPORTED_MODULE_15__.NgClass, _angular_common__WEBPACK_IMPORTED_MODULE_15__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_15__.NgIf, _angular_common__WEBPACK_IMPORTED_MODULE_15__.NgTemplateOutlet, _angular_common__WEBPACK_IMPORTED_MODULE_15__.NgStyle, _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_13__.CommonPageComponent, _angular_common__WEBPACK_IMPORTED_MODULE_15__.CommonModule, _components_token_with_chain_icon_token_with_chain_icon_component__WEBPACK_IMPORTED_MODULE_2__.TokenWithnChainIconComponent, _bnqkl_framework_directives__WEBPACK_IMPORTED_MODULE_8__.RestoreScrollPositionDirective],
  styles: ["._market-list-height[_ngcontent-%COMP%] {\n  height: calc(100% - 6.25rem);\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL2FwcHMvYmZzd2FwL3NyYy9wYWdlcy9ob21lL3BhZ2VzL21hcmtldC9tYXJrZXQuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSw0QkFBQTtBQUNGIiwic291cmNlc0NvbnRlbnQiOlsiLl9tYXJrZXQtbGlzdC1oZWlnaHQge1xyXG4gIGhlaWdodDogY2FsYygxMDAlIC0gNi4yNXJlbSk7XHJcbn1cclxuIl0sInNvdXJjZVJvb3QiOiIifQ== */"],
  changeDetection: 0
});
(0,tslib__WEBPACK_IMPORTED_MODULE_16__.__decorate)([MarketPage.States(1), (0,tslib__WEBPACK_IMPORTED_MODULE_16__.__metadata)("design:type", Object)], MarketPage.prototype, "activeFilter", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_16__.__decorate)([MarketPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_16__.__metadata)("design:type", Array)], MarketPage.prototype, "marketList", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_16__.__decorate)([MarketPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_16__.__metadata)("design:type", Object)], MarketPage.prototype, "inited", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_16__.__decorate)([MarketPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_16__.__metadata)("design:type", Object)], MarketPage.prototype, "marketListUpdating", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_16__.__decorate)([MarketPage.OnInit(), (0,tslib__WEBPACK_IMPORTED_MODULE_16__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_16__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_16__.__metadata)("design:returntype", Promise)], MarketPage.prototype, "dataInit", null);
(0,tslib__WEBPACK_IMPORTED_MODULE_16__.__decorate)([MarketPage.OnDestroy(), (0,tslib__WEBPACK_IMPORTED_MODULE_16__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_16__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_16__.__metadata)("design:returntype", void 0)], MarketPage.prototype, "unsubscribe", null);
(0,tslib__WEBPACK_IMPORTED_MODULE_16__.__decorate)([MarketPage.OnPause(), (0,tslib__WEBPACK_IMPORTED_MODULE_16__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_16__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_16__.__metadata)("design:returntype", void 0)], MarketPage.prototype, "pageOnPause", null);
(0,tslib__WEBPACK_IMPORTED_MODULE_16__.__decorate)([MarketPage.OnResume(), (0,tslib__WEBPACK_IMPORTED_MODULE_16__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_16__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_16__.__metadata)("design:returntype", Promise)], MarketPage.prototype, "pageOnResume", null);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MarketPage);

/***/ }),

/***/ 35883:
/*!****************************************************************!*\
  !*** ./apps/bfswap/src/pages/home/pages/market/market.type.ts ***!
  \****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   FILTER_ICON: () => (/* binding */ FILTER_ICON),
/* harmony export */   FILTER_OPTIONS_KEY: () => (/* binding */ FILTER_OPTIONS_KEY),
/* harmony export */   FILTER_VALUE_ENUM: () => (/* binding */ FILTER_VALUE_ENUM)
/* harmony export */ });
/** 排序的枚举值 */
var FILTER_VALUE_ENUM;
(function (FILTER_VALUE_ENUM) {
  /** 倒序 */
  FILTER_VALUE_ENUM["DESC"] = "DESC";
  /** 正序 */
  FILTER_VALUE_ENUM["ASC"] = "ASC";
  /** 默认按USDM的数量排序 */
  FILTER_VALUE_ENUM["DEFAULT"] = "DEFAULT";
})(FILTER_VALUE_ENUM || (FILTER_VALUE_ENUM = {}));
/** 排序依据 */
var FILTER_OPTIONS_KEY;
(function (FILTER_OPTIONS_KEY) {
  /** 按名字排序 */
  FILTER_OPTIONS_KEY["NAME"] = "NAME";
  /** 按价格排序 */
  FILTER_OPTIONS_KEY["PRICE"] = "PRICE";
  /** 按涨幅排序 */
  FILTER_OPTIONS_KEY["FLUCTUATION"] = "FLUCTUATION";
})(FILTER_OPTIONS_KEY || (FILTER_OPTIONS_KEY = {}));
/** 过滤器图片状态 */
const FILTER_ICON = {
  [FILTER_VALUE_ENUM.ASC]: './assets/images/price_upper.png',
  [FILTER_VALUE_ENUM.DESC]: './assets/images/price_below.png',
  [FILTER_VALUE_ENUM.DEFAULT]: './assets/images/price_default.png'
};

/***/ }),

/***/ 79010:
/*!*****************************************************************!*\
  !*** ./apps/bfswap/src/pages/home/pages/swap/swap.component.ts ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   SwapPage: () => (/* binding */ SwapPage),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 52542);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_32__ = __webpack_require__(/*! tslib */ 90505);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(/*! @angular/common */ 6729);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! @angular/core */ 61039);
/* harmony import */ var _bnqkl_framework_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @bnqkl/framework/components */ 24182);
/* harmony import */ var _components_icon_icon_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../components/icon/icon.component */ 18840);
/* harmony import */ var _components_select_token_panel_select_token_panel_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ~components/select-token-panel/select-token-panel.component */ 87002);
/* harmony import */ var _components_swap_detail_panel_swap_detail_panel_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ~components/swap-detail-panel/swap-detail-panel.component */ 60397);
/* harmony import */ var _modules_page_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ~modules/page.module */ 16381);
/* harmony import */ var _components_order_settings_order_settings_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ~components/order-settings/order-settings.component */ 67877);
/* harmony import */ var _services_wallet_wallet_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ~services/wallet/wallet.service */ 54275);
/* harmony import */ var _services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ~services/wallet/wallet.helper */ 84813);
/* harmony import */ var _bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @bnqkl/bnqkl-swap-core */ 70195);
/* harmony import */ var _bnqkl_util_web_extends_promise__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @bnqkl/util-web/extends-promise */ 87778);
/* harmony import */ var _services_liquidity_pool_liquidity_pool_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ~services/liquidity-pool/liquidity-pool.service */ 20213);
/* harmony import */ var _services_liquidity_order_liquidity_order_service__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ~services/liquidity-order/liquidity-order.service */ 84435);
/* harmony import */ var _services_transaction_settings_transaction_settings_service__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ~services/transaction-settings/transaction-settings.service */ 80348);
/* harmony import */ var _bnqkl_wallet_base_services__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @bnqkl/wallet-base/services */ 62479);
/* harmony import */ var _components_connect_wallet_panel_connect_wallet_panel_type__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ~components/connect-wallet-panel/connect-wallet-panel.type */ 9218);
/* harmony import */ var _components_connect_wallet_panel_connect_wallet_penel_component__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ~components/connect-wallet-panel/connect-wallet-penel.component */ 43551);
/* harmony import */ var lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! lodash/cloneDeep */ 14405);
/* harmony import */ var lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var _bnqkl_framework_pipes__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @bnqkl/framework/pipes */ 80909);
/* harmony import */ var _bnqkl_framework_plugins_toast__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! @bnqkl/framework/plugins/toast */ 18030);
/* harmony import */ var _services_liquidity_pool_liquidity_pool_helper__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ~services/liquidity-pool/liquidity-pool.helper */ 17827);
/* harmony import */ var _components_version_upgrade_dialog_defines_version_upgrade_dialog_defines_component__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! ~components/version-upgrade/dialog-defines/version-upgrade-dialog-defines.component */ 24499);
/* harmony import */ var bignumber_js__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! bignumber.js */ 61994);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(/*! @angular/forms */ 7820);
/* harmony import */ var _bnqkl_wallet_base_tools__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! @bnqkl/wallet-base/tools */ 38881);
/* harmony import */ var _swap_type__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! ./swap.type */ 25472);
/* harmony import */ var _components_bs_numeric_input_bs_numeric_input_component__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! ~components/bs-numeric-input/bs-numeric-input.component */ 16091);
/* harmony import */ var _libs_bnf_modules_bottom_sheet_components_bottom_sheet_component__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! ../../../../../../../libs/bnf/modules/bottom-sheet/components/bottom-sheet.component */ 94072);
/* harmony import */ var _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! ../../../../../../../libs/bnf/modules/page/common-page/common-page.component */ 62052);
/* harmony import */ var _libs_bnf_components_loading_wrapper_loading_wrapper_component__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! ../../../../../../../libs/bnf/components/loading-wrapper/loading-wrapper.component */ 51263);

var _class;





































const _c0 = ["sellInputRef"];
const _c1 = ["buyInputRef"];
function SwapPage_Conditional_17_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵelementStart"](0, "div", 41);
    _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵelement"](1, "bs-icon", 42);
    _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵelementStart"](2, "div", 43);
    _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵproperty"]("name", ctx_r0.buyPanel.chainIcon);
    _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵtextInterpolate1"](" ", ctx_r0.buyPanel.chain, " ");
  }
}
function SwapPage_Conditional_20_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵelementStart"](0, "div", 44)(1, "div", 45);
    _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵi18n"](2, 46);
    _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵelement"](3, "bs-icon", 47);
    _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵproperty"]("mode", "icon");
  }
}
function SwapPage_Conditional_21_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵelement"](0, "bs-icon", 48);
    _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵelementStart"](1, "span", 49);
    _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵelementStart"](3, "button", 50);
    _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵelement"](4, "bs-icon", 51);
    _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵproperty"]("name", ctx_r2.buyPanel.coinIcon);
    _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵtextInterpolate"](ctx_r2.buyPanel.coin);
    _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵproperty"]("mode", "icon");
  }
}
function SwapPage_Conditional_34_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵelementStart"](0, "div", 52);
    _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵelement"](1, "bs-icon", 42);
    _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵelementStart"](2, "div", 43);
    _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵproperty"]("name", ctx_r3.sellPanel.chainIcon);
    _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵtextInterpolate1"](" ", ctx_r3.sellPanel.chain, " ");
  }
}
function SwapPage_Conditional_37_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵelementStart"](0, "div", 53)(1, "div", 45);
    _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵi18n"](2, 54);
    _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵelement"](3, "bs-icon", 47);
    _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵproperty"]("mode", "icon");
  }
}
function SwapPage_Conditional_38_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵelement"](0, "bs-icon", 48);
    _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵelementStart"](1, "span", 49);
    _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵelementStart"](3, "button", 50);
    _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵelement"](4, "bs-icon", 51);
    _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵproperty"]("name", ctx_r5.sellPanel.coinIcon);
    _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵtextInterpolate"](ctx_r5.sellPanel.coin);
    _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵproperty"]("mode", "icon");
  }
}
function SwapPage_Conditional_44_Template(rf, ctx) {
  if (rf & 1) {
    const _r16 = _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵelementStart"](0, "button", 55);
    _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵlistener"]("click", function SwapPage_Conditional_44_Template_button_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵrestoreView"](_r16);
      const ctx_r15 = _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵresetView"](ctx_r15.handleMaxBtn());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵi18n"](1, 56);
    _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵelementEnd"]();
  }
}
function SwapPage_Conditional_45_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵelementStart"](0, "div", 57);
    _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵi18n"](1, 58);
    _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r7 = _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵi18nExp"](ctx_r7.addLiquilidityRatioLabel);
    _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵi18nApply"](1);
  }
}
function SwapPage_Conditional_47_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵelement"](0, "img", 60);
  }
}
function SwapPage_Conditional_47_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵelement"](0, "img", 62);
  }
}
function SwapPage_Conditional_47_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵelementStart"](0, "div", 59);
    _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵtemplate"](1, SwapPage_Conditional_47_Conditional_1_Template, 1, 0, "img", 60)(2, SwapPage_Conditional_47_Conditional_2_Template, 1, 0);
    _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵelementStart"](3, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵi18n"](4, 61);
    _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵconditional"](1, ctx_r8.gasFeeIsEnough ? 1 : 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵclassMapInterpolate1"]("", ctx_r8.gasFeeIsEnough ? "text-green-20" : "text-red-10", "  ml-2 text-xs");
    _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵi18nExp"](ctx_r8.gasFeeTipText);
    _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵi18nApply"](4);
  }
}
function SwapPage_Conditional_52_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵelementStart"](0, "div", 63);
    _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵi18n"](1, 64);
    _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r9 = _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵi18nExp"](ctx_r9.poolUNotEnoughTip);
    _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵi18nApply"](1);
  }
}
const _c30 = a0 => ({
  "_price-ani": a0
});
const _c31 = () => ({
  "--color-1": "#7a7b90"
});
function SwapPage_Conditional_53_Template(rf, ctx) {
  if (rf & 1) {
    const _r20 = _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵelementStart"](0, "div", 65)(1, "bs-icon", 66);
    _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵlistener"]("click", function SwapPage_Conditional_53_Template_bs_icon_click_1_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵrestoreView"](_r20);
      const ctx_r19 = _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵresetView"](ctx_r19.refreshPrice());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵelementStart"](2, "span", 67);
    _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵelementStart"](4, "bs-icon", 68);
    _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵlistener"]("click", function SwapPage_Conditional_53_Template_bs_icon_click_4_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵrestoreView"](_r20);
      const ctx_r21 = _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵresetView"](ctx_r21.handleReversePrice());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r10 = _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵclassMap"](_angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵpureFunction1"](7, _c30, ctx_r10.priceAnimationState));
    _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵproperty"]("ngStyle", _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵpureFunction0"](9, _c31));
    _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵtextInterpolate3"]("1 ", ctx_r10.price.leftCoin, " = ", ctx_r10.price.showPrice, " ", ctx_r10.price.rightCoin, "");
    _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵproperty"]("ngStyle", _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵpureFunction0"](10, _c31));
  }
}
function SwapPage_ng_template_55_Template(rf, ctx) {
  if (rf & 1) {
    const _r23 = _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵelementStart"](0, "bs-swap-detail-panel-page", 69);
    _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵlistener"]("returnValue$", function SwapPage_ng_template_55_Template_bs_swap_detail_panel_page_returnValue__0_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵrestoreView"](_r23);
      const ctx_r22 = _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵresetView"](ctx_r22.onSwapSubmited($event));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r11 = _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵproperty"]("sellPanel", ctx_r11.sellPanel)("buyPanel", ctx_r11.buyPanel)("preParams", ctx_r11.preParams)("transferOptions", ctx_r11.transferOptions)("platformFee", ctx_r11.platformFee)("expectBuyAmount", ctx_r11.expectBuyAmount);
  }
}
function SwapPage_ng_template_57_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵelement"](0, "bs-order-settings-page");
  }
}
function SwapPage_ng_template_59_Template(rf, ctx) {
  if (rf & 1) {
    const _r25 = _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵelementStart"](0, "bs-select-token-panel-page", 70);
    _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵlistener"]("returnValue$", function SwapPage_ng_template_59_Template_bs_select_token_panel_page_returnValue__0_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵrestoreView"](_r25);
      const ctx_r24 = _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵresetView"](ctx_r24.onSelectToken($event));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r13 = _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵproperty"]("noUSDM", ctx_r13.selectAssetSheet.data.noUSDM)("liquidityPoolAssetsInfo", ctx_r13.selectAssetSheet.data.liquidityPoolAssetsInfo)("selectedAsset", ctx_r13.selectAssetSheet.data.selectedAsset)("disabledAsset", ctx_r13.selectAssetSheet.data.disabledAsset)("chainGroupInfo", ctx_r13.selectAssetSheet.data.chainGroupInfo);
  }
}
function SwapPage_ng_template_61_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵelement"](0, "bs-connect-wallet-panel-page", 71);
  }
  if (rf & 2) {
    const ctx_r14 = _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵproperty"]("connectType", ctx_r14.selectWalletSheet.conncetType)("presetWallets", ctx_r14.selectWalletSheet.presetWallets);
  }
}
const _c32 = () => ({
  "--page-safe-area-inset-top": 0
});
/** 兑换组件 */
class SwapPage extends _modules_page_module__WEBPACK_IMPORTED_MODULE_5__.CommonPageBase {
  constructor() {
    super(...arguments);
    /** 跳转flag */
    this.fromRouter = false;
    /** 订单服务 */
    this.orderService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_29__.inject)(_services_liquidity_order_liquidity_order_service__WEBPACK_IMPORTED_MODULE_12__.LiquidityOrderService);
    this.OPERATE = _swap_type__WEBPACK_IMPORTED_MODULE_24__.OPERATE;
    /** 合约池服务 */
    this.poolService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_29__.inject)(_services_liquidity_pool_liquidity_pool_service__WEBPACK_IMPORTED_MODULE_11__.LiquidityPoolService);
    /** 高级设置服务 */
    this.settingsService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_29__.inject)(_services_transaction_settings_transaction_settings_service__WEBPACK_IMPORTED_MODULE_13__.TransactionSettingsService);
    /** 钱包服务 */
    this.walletService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_29__.inject)(_services_wallet_wallet_service__WEBPACK_IMPORTED_MODULE_7__.WalletService);
    /** 已连接钱包 */
    this.connectedWallet = this.walletService.connectedWallet;
    /** 合约池列表 */
    this.liquidityPoolAssetsListWithAmount = [];
    /** 池子详情列表 */
    this.poolDetailList = [];
    /** 滑点容忍度 */
    this.slippageTolerance = '';
    /** 过期时间 */
    this.expirationTime = 0;
    /** 价格动画开关 */
    this.priceAnimationState = false;
    /** 按钮的文字 */
    this.btnText = '连接钱包';
    /** 按钮是否禁用 */
    this.btnDisabled = false;
    /** 按钮对应的事件 */
    this.btnEvent = this.openConnectWalletPanel;
    /** 大个按钮上的loading  */
    this.loading = false;
    /** 操作类型 买和卖 */
    this.operate = _swap_type__WEBPACK_IMPORTED_MODULE_24__.OPERATE.BUY;
    /** 最后一次输入操作 */
    this.lastInput = undefined;
    /** 版本号 */
    this.version = '';
    /** 平台手续费 */
    this.feeRatio = '0';
    /** 关联的池子 */
    this.relatePool = {
      sellPool: undefined,
      buyPool: undefined
    };
    /** 关联池子的id 关联池子id是所有路径的池子id 最终的交易池子需要通过计算最佳路径才能确定 */
    this.relatePoolId = {
      sellPoolId: '',
      buyPoolId: ''
    };
    /** 计算错误 */
    this.caculateErr = _swap_type__WEBPACK_IMPORTED_MODULE_24__.CACULATE_RESULT_ERROR_STATUS.HAS_NO_LIQUIDITY;
    /** 计算结果 */
    this.caculateResult = true;
    /** 汇率对象  */
    this.price = {
      leftCoin: undefined,
      rightCoin: undefined,
      forwordPrice: _services_liquidity_pool_liquidity_pool_helper__WEBPACK_IMPORTED_MODULE_20__.PRICE_NONE.AMOUNT_NONE,
      backwordPirce: _services_liquidity_pool_liquidity_pool_helper__WEBPACK_IMPORTED_MODULE_20__.PRICE_NONE.AMOUNT_NONE,
      showPrice: _services_liquidity_pool_liquidity_pool_helper__WEBPACK_IMPORTED_MODULE_20__.PRICE_NONE.AMOUNT_NONE,
      direction: _services_liquidity_pool_liquidity_pool_helper__WEBPACK_IMPORTED_MODULE_20__.PRICE_DIRECTION.BACKWARD
    };
    /** 买入的各项参数 */
    this.buyPanel = {
      coinIcon: undefined,
      chainIcon: undefined,
      chain: undefined,
      coin: undefined,
      amount: '',
      balance: '- -'
    };
    /** 卖出的各项参数 */
    this.sellPanel = {
      coinIcon: undefined,
      chainIcon: undefined,
      chain: undefined,
      coin: undefined,
      amount: '',
      balance: '- -'
    };
    /** 代币精确度 */
    this.DECIMALS = 8;
    /** 平台手续费 */
    this.platformFee = '';
    /** 是否展示矿工费提示 */
    this.showGasTip = false;
    /** 签名参数 */
    this.preParams = undefined;
    /** 签名参数 */
    this.transferOptions = undefined;
    /** 预期买入的数量 */
    this.expectBuyAmount = '0';
    this._sellControlRun = false;
    this.sellControl = new _angular_forms__WEBPACK_IMPORTED_MODULE_30__.FormControl('', {
      validators: [control => {
        // 矫正输入
        const inputValue = String(control.value);
        const value = (0,_bnqkl_wallet_base_tools__WEBPACK_IMPORTED_MODULE_23__.getValueByDecimalsRange)(inputValue, this.DECIMALS);
        if (value !== inputValue) {
          control.setValue(value);
        }
        if (this._buyControlRun === false) {
          this._sellControlRun = true;
          this.sellInputEvent();
        }
        return null;
      }]
    });
    this._buyControlRun = false;
    this.buyControl = new _angular_forms__WEBPACK_IMPORTED_MODULE_30__.FormControl('', {
      validators: [control => {
        const inputValue = String(control.value);
        const value = (0,_bnqkl_wallet_base_tools__WEBPACK_IMPORTED_MODULE_23__.getValueByDecimalsRange)(inputValue, this.DECIMALS);
        if (value !== inputValue) {
          control.setValue(value);
        }
        if (this._sellControlRun === false) {
          this._buyControlRun = true;
          this.buyInputEvent();
        }
        return null;
      }]
    });
    /** 按钮事件列表 */
    this.btnObjList = [{
      text: "Connect wallet",
      disabled: false,
      check: this.checkWallet.bind(this),
      event: this.openConnectWalletPanel
    }, {
      text: "Select token",
      disabled: false,
      check: this.checkToken.bind(this),
      event: this.openSelectAssetSheet
    }, {
      text: "Getting data",
      disabled: true,
      check: this.checkLoading.bind(this),
      event: undefined
    }, {
      text: '暂无当前币种池子',
      disabled: true,
      check: this.checkPool.bind(this),
      event: undefined
    }, {
      text: "No liquid trading pool",
      disabled: false,
      check: this.checkPoolLiquidity.bind(this),
      event: this.openAddLiquidityDialog.bind(this)
    }, {
      text: "Insufficient balance",
      disabled: true,
      check: this.checkGasFee.bind(this),
      event: undefined
    }, {
      text: "Insufficient balance",
      disabled: true,
      check: this.checkBalance.bind(this),
      event: undefined
    }, {
      text: () => this.caculateErr,
      disabled: true,
      check: this.checkLiquidityAmount.bind(this),
      event: undefined
    }, {
      text: "Enter",
      disabled: false,
      check: this.checkAmount.bind(this),
      event: this.onManuallyFocus
    }, {
      text: "The quantity can not be zero",
      disabled: true,
      check: this.checkZero.bind(this),
      event: undefined
    }, {
      text: "Swap",
      disabled: false,
      check: () => false,
      event: this.openSwapSheet
    }];
    /** 主币种 */
    this.mainCoin = '';
    /**  矿工费 */
    this.gasFee = '';
    /** 矿工非是否足够 */
    this.gasFeeIsEnough = true;
    /** 矿工非提示文本 */
    this.gasFeeTipText = '';
    /** 添加流动性提交面板的数据 */
    this.swapSheet = {
      is_open: false
    };
    /** 选择币种面板 */
    this.selectAssetSheet = {
      isOpen: false,
      data: {
        liquidityPoolAssetsInfo: [],
        selectedAsset: [{
          tokenName: 'USDM',
          chainName: _bnqkl_wallet_base_services__WEBPACK_IMPORTED_MODULE_14__.CHAIN_NAME.PMChain
        }],
        disabledAsset: [],
        noUSDM: false,
        chainGroupInfo: []
      }
    };
    /** 钱包选择器的数据 */
    this.selectWalletSheet = {
      is_open: false,
      conncetType: _components_connect_wallet_panel_connect_wallet_panel_type__WEBPACK_IMPORTED_MODULE_15__.CONNECT_TYPE.CONNECT_WALLET,
      presetWallets: []
    };
    /** 高级设置弹窗设置 */
    this.advancedSettingsSheet = {
      is_open: false
    };
    /** 点击max标识 */
    this.maxMode = false;
    /** 展示池子数量不够 */
    this.showPoolCoinNotEnough = false;
    /** 池子中U不足的提示 */
    this.poolUNotEnoughTip = '';
  }
  /** 获取滑点标签 */
  get slippageLabel() {
    const {
      slippageTolerance
    } = this.settingsService.getSelectedValue();
    return slippageTolerance.label;
  }
  /** 获取增流比例标签 */
  get addLiquilidityRatioLabel() {
    const {
      addLiquidityRatio
    } = this.settingsService.getSelectedValue();
    return addLiquidityRatio.label;
  }
  /** 获取增流比例数值 */
  get addLiquilidityRatioValue() {
    const {
      addLiquidityRatio
    } = this.settingsService.getSelectedValue();
    return addLiquidityRatio.value;
  }
  /** 是否展示增流比例 */
  get showAddLiquidityRatio() {
    const {
      sellCoin
    } = this.poolUtil();
    return Boolean(sellCoin);
  }
  /** 对换面板 */
  reversePanel() {
    const {
      buyPanel,
      sellPanel
    } = this;
    buyPanel.amount = '';
    sellPanel.amount = '';
    const temp = lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_17___default()(buyPanel);
    this.buyPanel = lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_17___default()(sellPanel);
    this.sellPanel = temp;
    this.lastInput = undefined;
    this.caculateResult = true; // 重置计算结果
    this.initGasFeeInfo(); // 清空矿工费信息
    this.initMainCoinInfoAndFee(); // 清空主币种和手续费
    this.initPoolInfo(); // 清空原来的路径和池子
    this.handleRelateId(); // 重新设置POOLID
    this.handlePoolInfo();
    this.checkEventList();
    this.showPoolCoinNotEnough = false;
    // 重新获取主币种和该链手续费
    const {
      chain: sellChain
    } = this.sellPanel;
    if (sellChain) {
      this.getMainChainInfoandCalculateFee(sellChain);
    }
  }
  /** 执行兑换操作 */
  onSwapSubmited(data) {
    var _this = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this.swapSheet.is_open = false;
      const {
        transactionData
      } = data;
      _this.loading = true;
      const result = yield _this.orderService.exchangeOrder(transactionData);
      _this.loading = false;
      _this.console.log(result);
      if (result) {
        _this.sellPanel.amount = '';
        _this.buyPanel.amount = '';
        _this.checkEventList();
        _bnqkl_framework_plugins_toast__WEBPACK_IMPORTED_MODULE_19__.Toast.show('兑换交易已提交');
        yield (0,_bnqkl_util_web_extends_promise__WEBPACK_IMPORTED_MODULE_10__.sleep)(500);
        _this.nav.routeTo('/mine/my-record-swap');
      } else {
        _bnqkl_framework_plugins_toast__WEBPACK_IMPORTED_MODULE_19__.Toast.show('兑换失败');
      }
    })();
  }
  /** 清除订阅监听 */
  unsubscribe() {
    this.console.log('清除 订阅');
    this.walletAssets$ && this.walletAssets$.unsubscribe();
    this.poolAssets$ && this.poolAssets$.unsubscribe();
    this.connectWallet$ && this.connectWallet$.unsubscribe();
    this.poolDetail$ && this.poolDetail$.unsubscribe();
    this.walletService.allSubscribes.delete('SwapPage');
    this.settingsService.reset();
    this.sellInputRef && this.sellInputRef.nativeElement.removeEventListener('input', this.sellInputEvent.bind(this));
    this.buyInputRef && this.buyInputRef.nativeElement.removeEventListener('input', this.buyInputEvent.bind(this));
  }
  /** 卖出输入框输入事件 */
  sellInputEvent() {
    if (this.sellTimer) {
      clearTimeout(this.sellTimer);
    }
    this.sellTimer = setTimeout(() => {
      this.maxMode = false;
      this.lastInput = _swap_type__WEBPACK_IMPORTED_MODULE_24__.OPERATE.SELL;
      this.showPoolCoinNotEnough = false;
      this.initGasFeeInfo();
      this.handleSellCaculate();
      this.checkEventList();
      setTimeout(() => {
        this._sellControlRun = false;
      }, 100);
    }, 500);
  }
  /** 买入输入框输入事件 */
  buyInputEvent() {
    if (this.buyTimer) {
      clearTimeout(this.buyTimer);
    }
    this.buyTimer = setTimeout(() => {
      this.maxMode = false;
      this.lastInput = _swap_type__WEBPACK_IMPORTED_MODULE_24__.OPERATE.BUY;
      this.showPoolCoinNotEnough = false;
      this.initGasFeeInfo();
      this.handleBuyCaculate();
      this.checkEventList();
      setTimeout(() => {
        this._buyControlRun = false;
      }, 100);
    }, 500);
  }
  /** 刷新汇率 */
  refreshPrice() {
    this.getLiquidityPoolDetail();
  }
  /** 检查更新 */
  checkVersionUpgrade() {
    var _this2 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      try {
        yield _this2._templateDialogService.openDialogByName('checkVersionUpgrade', {
          input: undefined
        });
      } catch (err) {
        if (err === false) {
          _bnqkl_framework_plugins_toast__WEBPACK_IMPORTED_MODULE_19__.Toast.show('已是最新版本');
          _this2.console.log('no need upgrade');
        } else {
          throw err;
        }
      }
    })();
  }
  /** 初始化数据 */
  dataInit() {
    var _this3 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      // 获取版本号
      const version = localStorage.getItem('version');
      if (version) {
        _this3.version = version;
      }
      // 监听余额变化
      _this3.walletAssets$ = _this3.walletService.curentWalletAssets_subject.subscribe( /*#__PURE__*/function () {
        var _ref = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (assetTaskInfo) {
          if (assetTaskInfo.updating || assetTaskInfo.connectedWallet === undefined) {
            return;
          }
          _this3.connectedWallet = assetTaskInfo.connectedWallet;
          /** 实时变更界面余额(如果余额发生变化的话) */
          _this3.console.info('兑换面板监听到余额变化', _this3.connectedWallet);
          _this3.changeViewBalanceAmount();
          return;
        });
        return function (_x) {
          return _ref.apply(this, arguments);
        };
      }());
      // 监听池子可选币种余额列表变化
      _this3.poolAssets$ = _this3.walletService.liquidityPoolAssetsListWithAmout_subject.subscribe( /*#__PURE__*/function () {
        var _ref2 = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (liquidityPoolAssetsListWithAmountInfo) {
          if (liquidityPoolAssetsListWithAmountInfo && liquidityPoolAssetsListWithAmountInfo.updating == false && liquidityPoolAssetsListWithAmountInfo.liquidityPoolAssetsListWithAmount) {
            _this3.console.info('池子币种面板监听到池子币种余额列表更新', liquidityPoolAssetsListWithAmountInfo.liquidityPoolAssetsListWithAmount);
            _this3.liquidityPoolAssetsListWithAmount = liquidityPoolAssetsListWithAmountInfo.liquidityPoolAssetsListWithAmount;
            _this3._updateSelectAssetSheet(_this3.liquidityPoolAssetsListWithAmount);
            return;
          }
        });
        return function (_x2) {
          return _ref2.apply(this, arguments);
        };
      }());
      // 监听池子详情变化
      _this3.poolDetail$ = _this3.poolService.liquidityPoolDetailQueryTask_subject.subscribe(detail => {
        if (detail == undefined) {
          return;
        }
        _this3.console.info('兑换面板监听到池子详情变化', detail);
        if (detail) {
          const {
            liquidityPoolsdetail,
            updating
          } = detail;
          _this3.priceAnimationState = updating;
          _this3.loading = updating;
          if (updating === false && liquidityPoolsdetail) {
            _this3.poolDetailList = liquidityPoolsdetail;
            if (_this3.fromRouter) {
              _this3.handleRouerSelectCoin();
            }
            _this3.handlePoolInfo();
            _this3.lastInput && _this3.lastInput === _swap_type__WEBPACK_IMPORTED_MODULE_24__.OPERATE.SELL ? _this3.handleSellCaculate() : _this3.handleBuyCaculate();
          }
          _this3.checkEventList();
        }
      });
      // 监听钱包变化
      _this3.connectWallet$ = _this3.walletService.wallletConnected_subject.subscribe( /*#__PURE__*/function () {
        var _ref3 = (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (data) {
          if (data === undefined) {
            return;
          }
          const {
            wallet
          } = data;
          if (wallet === undefined) {
            _this3.clearAllInfo();
          }
          _this3.connectedWallet = wallet;
          _this3.checkEventList();
          return;
        });
        return function (_x3) {
          return _ref3.apply(this, arguments);
        };
      }());
      // 绑定池子币种选择面板数据
      _this3.liquidityPoolAssetsListWithAmount = yield _this3.walletService.getliquidityPoolAssetsListWithAmountAtFirst();
      _this3._updateSelectAssetSheet(_this3.liquidityPoolAssetsListWithAmount);
      // this.initDefaultSellCoin();
      // this.walletService.allSubscribes.set('SwapPage', [this.walletAssets$, this.poolAssets$, this.connectWallet$]);
    })();
  }

  bindButton() {
    this.checkEventList();
  }
  /** 反转价格 */
  handleReversePrice() {
    Object.assign(this.price, (0,_services_liquidity_pool_liquidity_pool_helper__WEBPACK_IMPORTED_MODULE_20__.reversePriceUtil)(this.price));
  }
  /** 是否正在获取数据 */
  checkLoading() {
    return this.loading === false;
  }
  /** 是否有池子检查 */
  checkPool() {
    const {
      sellChain,
      sellCoin,
      buyChain,
      buyCoin
    } = this.poolUtil();
    const {
      loading
    } = this;
    if (sellChain && sellCoin && buyChain && buyCoin && loading === false) {
      const {
        sellPoolId,
        buyPoolId
      } = this.relatePoolId;
      return Boolean(sellPoolId) && Boolean(buyPoolId);
    }
    return true;
  }
  /** 打开兑换面板 */
  openSwapSheet() {
    var _this$connectedWallet, _this$connectedWallet2;
    const userId = (_this$connectedWallet = this.connectedWallet) === null || _this$connectedWallet === void 0 ? void 0 : _this$connectedWallet.pmchainAddress;
    const publicKey = (_this$connectedWallet2 = this.connectedWallet) === null || _this$connectedWallet2 === void 0 ? void 0 : _this$connectedWallet2.pmchainPublicKey;
    const {
      gasFee
    } = this;
    const {
      slippageTolerance,
      expirationTime,
      addLiquidityRatio
    } = this.settingsService.getSelectedValue();
    const ratioValue = addLiquidityRatio.value;
    const {
      sellCoin,
      sellChain,
      buyCoin,
      buyChain,
      sellAmount,
      buyAmount,
      sellPool,
      buyPool,
      sellIsQuote,
      buyIsQuote
    } = this.poolUtil();
    if (sellPool === undefined || buyPool === undefined || publicKey === undefined || userId === undefined || sellCoin === undefined || sellChain === undefined || buyCoin === undefined || buyChain === undefined || sellAmount === undefined || buyAmount === undefined || slippageTolerance === undefined || expirationTime === undefined) {
      this.console.error('兑换面板数据出错：', sellCoin, sellChain, buyCoin, buyChain, sellAmount, buyAmount);
      throw new Error('兑换面板数据出错');
    }
    const {
      anchorCoinsChainName,
      anchorCoinsName,
      anchorCoinsRecipientAddress,
      poolId: sellPoolId,
      quoteAssociatedCoins
    } = sellPool;
    const {
      poolId: buyPoolId
    } = buyPool;
    const {
      anchorCoinsAmount: sellAnchorCoinsAmount,
      quoteCoinsAmount: sellQuoteCoinsAmount
    } = sellPool;
    const {
      anchorCoinsAmount: buyanchorCoinsAmount,
      quoteCoinsAmount: buyQuoteCoinsAmount
    } = buyPool;
    const isAnchor = sellCoin === anchorCoinsName && _services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_8__.NODE_CHAIN_NAME_TRANSFER_REVERSE[sellChain] === anchorCoinsChainName;
    const sellAmountBen = new bignumber_js__WEBPACK_IMPORTED_MODULE_22__["default"](sellAmount).multipliedBy(1e8).toString();
    const sellAddAmount = new bignumber_js__WEBPACK_IMPORTED_MODULE_22__["default"](sellAmountBen).multipliedBy(ratioValue).dp(0, bignumber_js__WEBPACK_IMPORTED_MODULE_22__["default"].ROUND_CEIL).toString();
    const sellSwapAmount = new bignumber_js__WEBPACK_IMPORTED_MODULE_22__["default"](sellAmountBen).minus(sellAddAmount).toString();
    const caculateSellAmountBen_ = _bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_9__.calculateHelper.calculateGainByExchange(_services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_8__.NODE_CHAIN_NAME_TRANSFER_REVERSE[sellChain], sellCoin, sellSwapAmount, sellPool);
    const caculateSellAmountBen = caculateSellAmountBen_.toString();
    let receiveAddress = '';
    if (isAnchor) {
      receiveAddress = anchorCoinsRecipientAddress;
    } else {
      const quoteAdd = quoteAssociatedCoins.find(item => {
        return item.chainName === _services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_8__.NODE_CHAIN_NAME_TRANSFER_REVERSE[sellChain];
      });
      if (quoteAdd === undefined) {
        throw new Error('找不到小U');
      }
      receiveAddress = quoteAdd.recipientAddress;
    }
    const multiplePool = sellPoolId !== buyPoolId;
    const backSellPool = lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_17___default()(sellPool);
    const backBuyPool = lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_17___default()(buyPool);
    if (sellIsQuote) {
      backSellPool.quoteCoinsAmount = new bignumber_js__WEBPACK_IMPORTED_MODULE_22__["default"](backSellPool.quoteCoinsAmount).plus(sellSwapAmount).toString();
      backSellPool.anchorCoinsAmount = new bignumber_js__WEBPACK_IMPORTED_MODULE_22__["default"](backSellPool.anchorCoinsAmount).minus(caculateSellAmountBen).toString();
    } else {
      backSellPool.quoteCoinsAmount = new bignumber_js__WEBPACK_IMPORTED_MODULE_22__["default"](backSellPool.quoteCoinsAmount).minus(caculateSellAmountBen).toString();
      backSellPool.anchorCoinsAmount = new bignumber_js__WEBPACK_IMPORTED_MODULE_22__["default"](backSellPool.anchorCoinsAmount).plus(sellSwapAmount).toString();
    }
    let expectBuyAmountBen = '';
    const needAddAmount = _bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_9__.calculateHelper.calculateIncreasedAmount(_services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_8__.NODE_CHAIN_NAME_TRANSFER_REVERSE[sellChain], sellCoin, sellAddAmount, backSellPool).toString();
    let needBAmount = '0';
    let addUAmount = '0';
    if (sellIsQuote === false && buyIsQuote === false) {
      const firstResult = new bignumber_js__WEBPACK_IMPORTED_MODULE_22__["default"](caculateSellAmountBen).minus(needAddAmount).toString();
      addUAmount = new bignumber_js__WEBPACK_IMPORTED_MODULE_22__["default"](firstResult).multipliedBy(ratioValue).dp(0, bignumber_js__WEBPACK_IMPORTED_MODULE_22__["default"].ROUND_CEIL).toString();
      const swapUAmount = new bignumber_js__WEBPACK_IMPORTED_MODULE_22__["default"](firstResult).minus(addUAmount).toString();
      const caculateBuyAmountBen_ = _bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_9__.calculateHelper.calculateGainByExchange(_bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_9__.BNQKL_SWAP_CHAIN_NAME.SWAP, _bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_9__.BNQKL_SWAP_COIN_NAME.USDM, swapUAmount, backBuyPool);
      const caculateBuyAmountBen = caculateBuyAmountBen_.toString();
      backBuyPool.quoteCoinsAmount = new bignumber_js__WEBPACK_IMPORTED_MODULE_22__["default"](backBuyPool.quoteCoinsAmount).plus(swapUAmount).toString();
      backBuyPool.anchorCoinsAmount = new bignumber_js__WEBPACK_IMPORTED_MODULE_22__["default"](backBuyPool.anchorCoinsAmount).minus(caculateBuyAmountBen).toString();
      needBAmount = _bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_9__.calculateHelper.calculateIncreasedAmount(_bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_9__.BNQKL_SWAP_CHAIN_NAME.SWAP, _bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_9__.BNQKL_SWAP_COIN_NAME.USDM, addUAmount, backBuyPool).toString();
      const BAmount = new bignumber_js__WEBPACK_IMPORTED_MODULE_22__["default"](caculateBuyAmountBen).minus(needBAmount.toString()).toString();
      expectBuyAmountBen = BAmount;
    } else {
      expectBuyAmountBen = new bignumber_js__WEBPACK_IMPORTED_MODULE_22__["default"](caculateSellAmountBen).minus(needAddAmount).toString();
    }
    this.expectBuyAmount = new bignumber_js__WEBPACK_IMPORTED_MODULE_22__["default"](expectBuyAmountBen).dividedBy(1e8).toString();
    const sellCoinOptions = {
      poolId: sellPoolId,
      anchorCoinsAmount: sellAnchorCoinsAmount,
      quoteCoinsAmount: sellQuoteCoinsAmount,
      chainName: _services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_8__.NODE_CHAIN_NAME_TRANSFER_REVERSE[sellChain],
      payload: undefined
    };
    const buyCoinOptions = {
      poolId: buyPoolId,
      anchorCoinsAmount: buyanchorCoinsAmount,
      quoteCoinsAmount: buyQuoteCoinsAmount,
      chainName: _services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_8__.NODE_CHAIN_NAME_TRANSFER_REVERSE[buyChain],
      coinName: buyCoin,
      amount: expectBuyAmountBen
    };
    const startTime = Date.now();
    const expiraion = new bignumber_js__WEBPACK_IMPORTED_MODULE_22__["default"](startTime).plus(expirationTime.value);
    const addSellAmountBen = parseInt(new bignumber_js__WEBPACK_IMPORTED_MODULE_22__["default"](sellAmountBen).multipliedBy(ratioValue).toString()).toString();
    const anchorA = sellIsQuote ? needAddAmount : sellAddAmount;
    const quoteA = sellIsQuote ? addSellAmountBen : needAddAmount;
    const sellAddLiquiditys = this.handleAddLiquidityRatioInfo(backSellPool, anchorA, quoteA);
    const expectedIncreasedLiquiditys = [sellAddLiquiditys];
    if (multiplePool) {
      const buyAddLiquiditys = this.handleAddLiquidityRatioInfo(backBuyPool, needBAmount, addUAmount);
      expectedIncreasedLiquiditys.push(buyAddLiquiditys);
    }
    const transferOptions = {
      chainName: sellChain,
      receiveAddress: receiveAddress,
      assetType: sellCoin,
      amount: sellAmountBen,
      fee: gasFee,
      remark: {
        chainName: _services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_8__.NODE_CHAIN_NAME_TRANSFER_REVERSE[buyChain],
        assetType: buyCoin,
        address: userId,
        from: 'btcswap'
      }
    };
    const preParams = {
      type: _bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_9__.ORDER_RECORD_TYPES.EXCHANGE_COINS,
      userId,
      recipientAddress: userId,
      slippageTolerance: String(slippageTolerance.value),
      startTime,
      expirationTime: Number(expiraion),
      transaction: {
        sellCoinOptions,
        buyCoinOptions
      },
      publicKey,
      increasedLiquidityRatio: ratioValue,
      expectedIncreasedLiquiditys
    };
    this.transferOptions = transferOptions;
    this.preParams = preParams;
    this.platformFee = sellPool.feeRatio;
    this.swapSheet.is_open = true;
  }
  /** 增流数量计算 */
  addLiAmountCalc(amount, ratio, chain, coin, pool) {
    const addLAmount = parseInt(new bignumber_js__WEBPACK_IMPORTED_MODULE_22__["default"](ratio).multipliedBy(amount).toString()).toString();
    const needAmount = _bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_9__.calculateHelper.calculateIncreasedAmount(chain, coin, addLAmount, pool);
    return needAmount.toString();
  }
  /** 获取变化的池子 */
  getChangePool(sellPool, buyPool, sellIsQuote, buyIsQuote, expectSellAmountBen, expectBuyAmountBen, sellChain, sellCoin) {
    const backSellPool = lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_17___default()(sellPool);
    const backBuyPool = lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_17___default()(buyPool);
    if (sellIsQuote) {
      backSellPool.quoteCoinsAmount = new bignumber_js__WEBPACK_IMPORTED_MODULE_22__["default"](backSellPool.quoteCoinsAmount).plus(expectSellAmountBen).toString();
      backSellPool.anchorCoinsAmount = new bignumber_js__WEBPACK_IMPORTED_MODULE_22__["default"](backSellPool.anchorCoinsAmount).minus(expectBuyAmountBen).toString();
    }
    if (buyIsQuote) {
      backSellPool.quoteCoinsAmount = new bignumber_js__WEBPACK_IMPORTED_MODULE_22__["default"](backSellPool.quoteCoinsAmount).minus(expectBuyAmountBen).toString();
      backSellPool.anchorCoinsAmount = new bignumber_js__WEBPACK_IMPORTED_MODULE_22__["default"](backSellPool.anchorCoinsAmount).plus(expectSellAmountBen).toString();
    }
    if (buyIsQuote === false && sellIsQuote === false) {
      backSellPool.anchorCoinsAmount = new bignumber_js__WEBPACK_IMPORTED_MODULE_22__["default"](backSellPool.anchorCoinsAmount).plus(expectSellAmountBen).toString();
      const gainUAmount = _bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_9__.calculateHelper.calculateGainByExchange(_services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_8__.NODE_CHAIN_NAME_TRANSFER_REVERSE[sellChain], sellCoin, expectSellAmountBen, sellPool);
      backSellPool.quoteCoinsAmount = new bignumber_js__WEBPACK_IMPORTED_MODULE_22__["default"](backSellPool.quoteCoinsAmount).minus(gainUAmount.toString()).toString();
      backBuyPool.quoteCoinsAmount = new bignumber_js__WEBPACK_IMPORTED_MODULE_22__["default"](backBuyPool.quoteCoinsAmount).plus(gainUAmount.toString()).toString();
      backBuyPool.anchorCoinsAmount = new bignumber_js__WEBPACK_IMPORTED_MODULE_22__["default"](backBuyPool.anchorCoinsAmount).minus(expectBuyAmountBen).toString();
    }
    return {
      changeSellPool: backSellPool,
      changeBuyPool: backBuyPool
    };
  }
  /** 处理增流比例信息 */
  handleAddLiquidityRatioInfo(pool, anchorAmount, quoteAmount) {
    const gainLPAmount = _bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_9__.calculateHelper.calculateLPCoinByAdd(anchorAmount, quoteAmount, pool);
    return {
      poolId: pool.poolId,
      anchorCoinsChainName: pool.anchorCoinsChainName,
      anchorCoinsName: pool.anchorCoinsName,
      anchorCoinsAmount: anchorAmount,
      quoteCoinsChainName: pool.quoteCoinsChainName,
      quoteCoinsName: pool.quoteCoinsName,
      quoteCoinsAmount: quoteAmount,
      lpCoinsAmount: gainLPAmount.toString()
    };
  }
  /** 检查按钮状态  */
  checkEventList() {
    var _this4 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const {
        btnObjList
      } = _this4;
      for (let i = 0; i < btnObjList.length; i++) {
        const btn = btnObjList[i];
        const result = btn.check();
        const r = typeof result === 'boolean' ? result : yield result;
        if (r === false) {
          const {
            text,
            disabled,
            event
          } = btn;
          _this4.btnText = typeof text === 'string' ? text : String(_swap_type__WEBPACK_IMPORTED_MODULE_24__.errorTextObj[text()]);
          _this4.btnDisabled = disabled;
          if (event) {
            _this4.btnEvent = event;
          }
          return;
        }
      }
    })();
  }
  /** 获取主币种信息，计算该链手续费 */
  getMainChainInfoandCalculateFee(chain) {
    var _this5 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const config = _this5.walletService.CHAIN_CONFIG_MAP;
      const chainMap = config.get(chain);
      if (chainMap) {
        _this5.mainCoin = chainMap.symbol;
      } else {
        throw new Error('没有找到主币种');
      }
      const gasfee = yield _this5.walletService.getBioforestChainFeeByChainName(chain);
      _this5.gasFee = gasfee;
    })();
  }
  /** 检查矿工费 */
  checkGasFee() {
    var _this6 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      var _this6$connectedWalle;
      const {
        sellCoin,
        sellChain,
        sellAmount
      } = _this6.poolUtil();
      if (sellCoin === undefined || sellChain === undefined) {
        throw new Error('未选择币种，无法计算');
      }
      if (Boolean(sellAmount) === false) {
        return true;
      }
      const {
        mainCoin: mainChainCoin,
        gasFee
      } = _this6;
      const assetInfoList = (_this6$connectedWalle = _this6.connectedWallet) === null || _this6$connectedWalle === void 0 ? void 0 : _this6$connectedWalle.assetInfoListMap.get(sellChain);
      const mainAssetInfo = assetInfoList === null || assetInfoList === void 0 ? void 0 : assetInfoList.assets.find(item => item.assetType === mainChainCoin);
      if (mainAssetInfo === undefined) {
        throw new Error('没有找到主链币种钱包信息');
      }
      const isMainCoin = sellCoin === mainChainCoin;
      const ratio = new bignumber_js__WEBPACK_IMPORTED_MODULE_22__["default"](1).minus(_this6.addLiquilidityRatioValue);
      const needAmount = isMainCoin ? new bignumber_js__WEBPACK_IMPORTED_MODULE_22__["default"](sellAmount).multipliedBy(1e8).multipliedBy(ratio).plus(gasFee).toString() : gasFee;
      const flag = new bignumber_js__WEBPACK_IMPORTED_MODULE_22__["default"](mainAssetInfo.amount).isGreaterThanOrEqualTo(needAmount);
      _this6.gasFeeIsEnough = flag;
      _this6.showGasTip = true;
      if (flag) {
        if (_this6.maxMode) {
          _this6.gasFeeTipText = '已为您预留钱包签名手续费';
        } else {
          _this6.showGasTip = false;
        }
      } else if (isMainCoin) {
        const amount = _bnqkl_framework_pipes__WEBPACK_IMPORTED_MODULE_18__.AmountFixedPipe.transform(gasFee, String(_this6.DECIMALS), {
          removeZero: true
        });
        _this6.gasFeeTipText = `请预留 ${amount} ${mainChainCoin}矿工费`;
        return false;
      } else {
        _this6.gasFeeTipText = `当前 ${mainChainCoin}不足，可能无法签名`;
      }
      return true;
    })();
  }
  /** 初始化矿工费提示信息 */
  initGasFeeInfo() {
    this.showGasTip = false;
    this.gasFeeIsEnough = true;
    this.gasFeeTipText = '';
  }
  /** 初始化卖出币种所在的链的主币种和所需手续费 */
  initMainCoinInfoAndFee() {
    this.mainCoin = '';
    this.gasFee = '';
  }
  /** 改变界面余额数量 */
  changeViewBalanceAmount() {
    [this.sellPanel, this.buyPanel].forEach(item => {
      var _this$connectedWallet3;
      const {
        chain,
        coin
      } = item;
      if (chain === undefined || coin === undefined) return;
      const wallet = (_this$connectedWallet3 = this.connectedWallet) === null || _this$connectedWallet3 === void 0 ? void 0 : _this$connectedWallet3.assetInfoListMap.get(chain);
      if (wallet === undefined) return;
      const {
        assets
      } = wallet;
      const asset = assets.find(asset => asset.assetType === coin);
      if (asset === undefined) return;
      const isNumber = Number.isNaN(parseFloat(asset.amount));
      const amount = isNumber ? '- -' : _bnqkl_framework_pipes__WEBPACK_IMPORTED_MODULE_18__.AmountFixedPipe.transform(asset.amount, asset.decimals, {
        removeZero: true
      });
      item.balance = amount;
    });
  }
  /** 检查是否连接钱包 */
  checkWallet() {
    return Boolean(this.connectedWallet);
  }
  /** 检查是否选择币种 */
  checkToken() {
    return Boolean(this.buyPanel.coin) && Boolean(this.sellPanel.coin);
  }
  /** 非零检查 */
  checkZero() {
    const isZero = parseFloat(this.sellPanel.amount) === 0 || parseFloat(this.buyPanel.amount) === 0;
    return isZero === false;
  }
  /** 检查输入的数量 */
  checkAmount() {
    const sellHasAmount = Number.isNaN(parseFloat(this.sellPanel.amount)) === false;
    const buyHasAmount = Number.isNaN(parseFloat(this.buyPanel.amount)) === false;
    return sellHasAmount && buyHasAmount;
  }
  /** 检查是否获取数据 */
  checkData() {
    return Boolean(this.buyTimer) === false;
  }
  /** 检查余额 */
  checkBalance() {
    const {
      amount,
      balance
    } = this.sellPanel;
    if (amount && balance) {
      const b = new bignumber_js__WEBPACK_IMPORTED_MODULE_22__["default"](balance);
      return b.isGreaterThanOrEqualTo(amount);
    }
    return true;
  }
  /** 输入的值和池子的币对比 */
  compareCoinAmount(inputAmount, coinAmount) {
    const input = new bignumber_js__WEBPACK_IMPORTED_MODULE_22__["default"](inputAmount).multipliedBy(1e8);
    return new bignumber_js__WEBPACK_IMPORTED_MODULE_22__["default"](coinAmount).isGreaterThan(input);
  }
  /** 检查流动性数量是否足够 */
  checkLiquidityAmount() {
    const {
      caculateResult
    } = this;
    return caculateResult;
  }
  /** 检查是否有流动性(有路径) */
  checkPoolLiquidity() {
    const {
      relatePool
    } = this;
    const {
      sellPool,
      buyPool
    } = relatePool;
    return [sellPool, buyPool].some(pool => {
      if (pool) {
        const {
          anchorCoinsAmount,
          quoteCoinsAmount
        } = pool;
        return Number(anchorCoinsAmount) > 0 && Number(quoteCoinsAmount) > 0;
      }
    });
  }
  /** 是否展示价格 */
  get showPrice() {
    const {
      sellAmount,
      buyAmount,
      sellPool,
      buyPool
    } = this.poolUtil();
    const flag = sellPool && buyPool && Number(sellAmount) > 0 && Number(buyAmount) > 0;
    return flag;
  }
  /** 获取合约池详情 */
  getLiquidityPoolDetail() {
    const poolIdList = [];
    const {
      sellPoolId,
      buyPoolId
    } = this.relatePoolId;
    sellPoolId && poolIdList.push(sellPoolId);
    buyPoolId && poolIdList.push(buyPoolId);
    const poolIds = [...new Set(poolIdList)];
    if (poolIds.length > 0) {
      this.poolService.startQueryPoolTask(poolIds);
    }
  }
  /** 手动获取输入框焦点 */
  onManuallyFocus() {
    const inputList = [this.sellInputRef, this.buyInputRef];
    for (const input of inputList) {
      if (input) {
        const inputDom = input.nativeElement;
        if (Boolean(inputDom.value) === false) {
          inputDom.focus();
          break;
        }
      }
    }
  }
  /** 更新选择资产弹窗的初始数据  */
  _updateSelectAssetSheet(poolAssetTaskInfo) {
    this.selectAssetSheet.data.liquidityPoolAssetsInfo = poolAssetTaskInfo;
    this.selectAssetSheet.data.chainGroupInfo = Array.from(new Set(poolAssetTaskInfo.map(asset => {
      return asset.chainName;
    }))).map(item => {
      return {
        chain: item,
        chainI18nName: item
      };
    });
  }
  /** 初始化输入框输入事件 */
  initInputListenEvent() {
    this.sellInputRef && this.sellInputRef.nativeElement.addEventListener('input', this.sellInputEvent.bind(this));
    this.buyInputRef && this.buyInputRef.nativeElement.addEventListener('input', this.buyInputEvent.bind(this));
  }
  /** 打开钱包连接面板 */
  openConnectWalletPanel() {
    var _this7 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const {
        selectWalletSheet
      } = _this7;
      if (selectWalletSheet.is_open) {
        return;
      }
      _this7.selectWalletSheet.presetWallets = yield _this7.walletService.getPresetWallet();
      selectWalletSheet.is_open = true;
    })();
  }
  /** 打开兑换弹窗 */
  swapSubmit() {
    var _this8 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const {
        swapSheet
      } = _this8;
      if (swapSheet.is_open) {
        return;
      }
      swapSheet.is_open = true;
    })();
  }
  /** 打开高级设置弹窗 */
  openAdvancedSettingsSheet() {
    var _this9 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const {
        advancedSettingsSheet
      } = _this9;
      if (advancedSettingsSheet.is_open) {
        return;
      }
      advancedSettingsSheet.is_open = true;
    })();
  }
  /** 打开选择币种面板 */
  openSelectAssetSheet(operate) {
    var _this10 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const {
        sellChain,
        buyChain,
        sellCoin,
        buyCoin,
        sellIsQuote,
        buyIsQuote
      } = _this10.poolUtil();
      if (operate) {
        _this10.operate = operate;
      } else {
        _this10.operate = _this10.sellPanel.coin ? _swap_type__WEBPACK_IMPORTED_MODULE_24__.OPERATE.BUY : _swap_type__WEBPACK_IMPORTED_MODULE_24__.OPERATE.SELL;
      }
      const anchorFlag = operate === _swap_type__WEBPACK_IMPORTED_MODULE_24__.OPERATE.SELL && buyIsQuote;
      const quoteFlag = operate === _swap_type__WEBPACK_IMPORTED_MODULE_24__.OPERATE.BUY && sellIsQuote;
      let disabledList = [];
      if (anchorFlag) {
        disabledList = _this10.selectAssetSheet.data.liquidityPoolAssetsInfo.filter(item => {
          return item.tokenName === _bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_9__.BNQKL_SWAP_COIN_NAME.USDM && item.chainName !== buyChain;
        });
      }
      if (quoteFlag) {
        disabledList = _this10.selectAssetSheet.data.liquidityPoolAssetsInfo.filter(item => {
          return item.tokenName === _bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_9__.BNQKL_SWAP_COIN_NAME.USDM && item.chainName !== sellChain;
        });
      }
      _this10.selectAssetSheet.data.disabledAsset = disabledList;
      let selectList = [];
      if (_this10.operate === _swap_type__WEBPACK_IMPORTED_MODULE_24__.OPERATE.BUY) {
        selectList = _this10.selectAssetSheet.data.liquidityPoolAssetsInfo.filter(item => {
          return item.tokenName === buyCoin && item.chainName === buyChain;
        });
      } else {
        selectList = _this10.selectAssetSheet.data.liquidityPoolAssetsInfo.filter(item => {
          return item.tokenName === sellCoin && item.chainName === sellChain;
        });
      }
      _this10.selectAssetSheet.data.selectedAsset = selectList;
      const {
        selectAssetSheet
      } = _this10;
      if (selectAssetSheet.isOpen === false) {
        selectAssetSheet.isOpen = true;
      }
    })();
  }
  /** 清空池子信息 */
  initPoolInfo() {
    this.relatePool.buyPool = undefined;
    this.relatePool.sellPool = undefined;
  }
  /** 清空面板 */
  initPanel(type) {
    const initPanel = {
      poolId: '',
      icon: undefined,
      chain: undefined,
      coin: undefined,
      amount: '',
      balance: '- -'
    };
    const targetPanel = type === _swap_type__WEBPACK_IMPORTED_MODULE_24__.OPERATE.SELL ? this.sellPanel : this.buyPanel;
    Object.assign(targetPanel, initPanel);
  }
  /** 清空池子信息 */
  clearPoolInfo() {
    this.showPoolCoinNotEnough = false;
    this.poolDetailList = [];
    this.relatePoolId = {
      sellPoolId: '',
      buyPoolId: ''
    };
    this.relatePool.buyPool = undefined;
    this.relatePool.sellPool = undefined;
  }
  /** 清空所有信息 */
  clearAllInfo() {
    this.initPanel(_swap_type__WEBPACK_IMPORTED_MODULE_24__.OPERATE.BUY);
    this.initPanel(_swap_type__WEBPACK_IMPORTED_MODULE_24__.OPERATE.SELL);
    this.clearPoolInfo();
    this.initGasFeeInfo();
    this.initMainCoinInfoAndFee();
  }
  /** 选择币种事件 */
  onSelectToken(data) {
    var _this11 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this11.console.info('submit select token', data);
      const {
        selectedAsset
      } = data;
      const {
        chainName,
        tokenName,
        tokenIcon
      } = selectedAsset;
      const isSell = _this11.operate === _swap_type__WEBPACK_IMPORTED_MODULE_24__.OPERATE.SELL;
      /** 因为选择币种后会重新获取池子详情 所以先清空 */
      _this11.clearPoolInfo();
      _this11.initGasFeeInfo();
      if (isSell) {
        _this11.initMainCoinInfoAndFee();
        yield _this11.getMainChainInfoandCalculateFee(chainName);
        const {
          chain,
          coin
        } = _this11.buyPanel;
        if (chain === chainName && coin === tokenName) {
          _this11.initPanel(_swap_type__WEBPACK_IMPORTED_MODULE_24__.OPERATE.BUY);
        }
      } else {
        const {
          chain,
          coin
        } = _this11.sellPanel;
        if (chain === chainName && coin === tokenName) {
          _this11.initPanel(_swap_type__WEBPACK_IMPORTED_MODULE_24__.OPERATE.SELL);
        }
      }
      const item = isSell ? _this11.sellPanel : _this11.buyPanel;
      item.coinIcon = tokenIcon;
      item.chainIcon = (0,_services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_8__.transferToChainIcon)(chainName || 'Default');
      item.coin = tokenName;
      item.chain = chainName;
      const assetList = _this11.selectAssetSheet.data.liquidityPoolAssetsInfo;
      const token = assetList.find(item => {
        return item.chainName === chainName && item.tokenName === tokenName;
      });
      if (token) {
        const isNumber = Number.isNaN(parseFloat(token.amount));
        item.balance = isNumber ? '- -' : _bnqkl_framework_pipes__WEBPACK_IMPORTED_MODULE_18__.AmountFixedPipe.transform(token.amount, token.decimals, {
          removeZero: true
        });
      }
      _this11.handleRelateId();
      _this11.getLiquidityPoolDetail();
    })();
  }
  /** 进入其他页面 */
  pageOnPause() {
    this.console.log('Lifecycle SwapPage pause: removeQueryPoolTask');
    this.fromRouter = false;
    this.poolService.removeQueryPoolTask();
  }
  /** 处理路由选中币种 */
  handleRouerSelectCoin() {
    this.fromRouter = false;
    const pool = this.poolDetailList[0];
    let smallU = undefined;
    pool.quoteAssociatedCoins.forEach(item => {
      if (smallU === undefined) {
        smallU = item;
      } else if (Number(item.amount) > Number(smallU.amount)) {
        smallU = item;
      }
    });
    if (smallU === undefined) {
      throw new Error('没有找到小U');
    }
    const {
      chainName,
      coinName
    } = smallU;
    const quoteIcon = (0,_services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_8__.transferToTokenIcon)(chainName, coinName);
    const onSelectedAssetData = {
      chainName: _services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_8__.NODE_CHAIN_NAME_TRANSFER[chainName],
      tokenName: coinName,
      tokenIcon: quoteIcon
    };
    this.maxMode = false;
    this.onSelectToken({
      selectedAsset: onSelectedAssetData
    });
  }
  /** 处理路由传参 */
  handleRouterParams(swapSelectedAsset) {
    const {
      anchorIcon,
      anchorCoin,
      anchorChain
    } = swapSelectedAsset;
    const poolId = this.getPoolIdByToken(anchorChain, anchorCoin);
    if (Boolean(poolId) === false || poolId === undefined) {
      throw new Error('没有找到池子ID');
    }
    this.buyPanel.chain = anchorChain;
    this.buyPanel.coin = anchorCoin;
    this.buyPanel.coinIcon = anchorIcon;
    this.buyPanel.chainIcon = (0,_services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_8__.transferToChainIcon)(anchorChain || 'Default');
    this.operate = _swap_type__WEBPACK_IMPORTED_MODULE_24__.OPERATE.SELL;
    const assetList = this.selectAssetSheet.data.liquidityPoolAssetsInfo;
    const token = assetList.find(item => {
      return item.tokenName === anchorCoin;
    });
    if (token) {
      const isNumber = Number.isNaN(parseFloat(token.amount));
      this.buyPanel.balance = isNumber ? '- -' : _bnqkl_framework_pipes__WEBPACK_IMPORTED_MODULE_18__.AmountFixedPipe.transform(token.amount, token.decimals, {
        removeZero: true
      });
    }
    this.fromRouter = true;
    this.poolService.startQueryPoolTask([poolId]);
  }
  /** 跳转兑换记录页面 */
  jumpSwapPage() {
    if (this.connectedWallet) {
      this.nav.routeTo('/mine/my-record-swap');
    } else {
      _bnqkl_framework_plugins_toast__WEBPACK_IMPORTED_MODULE_19__.Toast.show('请先连接钱包');
    }
  }
  /** 从其他页面返回 */
  pageOnResume() {
    this.getLiquidityPoolDetail();
    this.console.log('Lifecycle SwapPage resume: getLiquidityPoolDetail');
  }
  /** 当余额是 - - 或者 0 时不显示Max按钮 */
  showMax() {
    const balance = parseFloat(this.sellPanel.balance);
    return !Number.isNaN(balance) && balance !== 0;
  }
  /** 最大卖出量 */
  get getSellMaxValue() {
    const {
      gasFee
    } = this;
    const gasFeeAmount = new bignumber_js__WEBPACK_IMPORTED_MODULE_22__["default"](gasFee).dividedBy(1e8).toFixed(8, 1);
    const amount = new bignumber_js__WEBPACK_IMPORTED_MODULE_22__["default"](this.sellPanel.balance).minus(gasFeeAmount);
    return amount.toString();
  }
  /** 最大买入量 */
  get getBuyMaxValue() {
    this.caculateErr = _swap_type__WEBPACK_IMPORTED_MODULE_24__.CACULATE_RESULT_ERROR_STATUS.HAS_NO_LIQUIDITY;
    this.caculateResult = true;
    const {
      sellCoin,
      buyCoin,
      sellChain,
      buyChain
    } = this.poolUtil();
    const {
      relatePool
    } = this;
    const {
      sellPool,
      buyPool
    } = relatePool;
    if (sellPool === undefined || buyPool === undefined) {
      this.console.log('没有对应池子');
      return "0";
    }
    if (sellCoin && buyCoin && sellChain && buyChain) {
      if (this.getSellMaxValue === '') {
        return "0";
      }
      if (Number(this.getSellMaxValue) === 0) {
        return "0";
      }
      const caculateResult = this.caculateSell(sellChain, sellCoin, this.getSellMaxValue, sellPool, buyPool, buyChain, buyCoin);
      const {
        result
      } = caculateResult;
      this.caculateResult = result;
      if (result) {
        const {
          amount
        } = caculateResult;
        return amount;
      } else {
        return "0";
      }
    }
    return "0";
  }
  /** 处理卖出Max按钮 */
  handleMaxBtn() {
    const {
      gasFee,
      mainCoin
    } = this;
    const {
      sellCoin
    } = this.poolUtil();
    const amount = this.getSellMaxValue;
    this.showPoolCoinNotEnough = false;
    this.maxMode = true;
    if (+amount > 0) {
      if (mainCoin === sellCoin) {
        this.sellPanel.amount = amount;
      } else {
        this.sellPanel.amount = this.sellPanel.balance;
      }
      this.lastInput = _swap_type__WEBPACK_IMPORTED_MODULE_24__.OPERATE.SELL;
      this.handleSellCaculate();
    } else {
      const gasFeeAmount = new bignumber_js__WEBPACK_IMPORTED_MODULE_22__["default"](gasFee).dividedBy(1e8).toFixed(8, 1);
      this.gasFeeIsEnough = false;
      this.showGasTip = true;
      this.gasFeeTipText = `请预留 ${gasFeeAmount} ${sellCoin} 矿工费`;
    }
    this.checkEventList();
  }
  /** 通过币和池获取池子 */
  getPoolIdByToken(chain, coin) {
    const option = {
      quoteChainName: _bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_9__.BNQKL_SWAP_CHAIN_NAME.SWAP,
      quoteCoinsName: _bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_9__.BNQKL_SWAP_COIN_NAME.USDM,
      anchorChainName: _services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_8__.NODE_CHAIN_NAME_TRANSFER_REVERSE[chain],
      anchorCoinsName: coin
    };
    const poolIds = this.poolService.getPoolIdBytoken(option);
    if (poolIds.length > 0) {
      return poolIds[0];
    }
  }
  /** 获取池子ID */
  getPoolById(id) {
    const targetPool = this.poolDetailList.find(poolItem => {
      return poolItem.poolId === id;
    });
    return targetPool;
  }
  /** 设置池子信息 */
  handlePoolInfo() {
    const {
      sellPoolId,
      buyPoolId
    } = this.relatePoolId;
    const sellPool = this.getPoolById(sellPoolId);
    const buyPool = this.getPoolById(buyPoolId);
    if (sellPool && buyPool) {
      this.relatePool.sellPool = sellPool;
      this.relatePool.buyPool = buyPool;
    }
  }
  /** 选择币种后，获取所有相关池子的id */
  handleRelateId() {
    const {
      sellIsQuote,
      buyIsQuote,
      sellChain,
      sellCoin,
      buyChain,
      buyCoin
    } = this.poolUtil();
    if (sellChain === undefined || sellCoin === undefined || buyChain === undefined || buyCoin === undefined) {
      return;
    }
    /** 单个池子 */
    if (sellIsQuote || buyIsQuote) {
      const chain = sellIsQuote ? buyChain : sellChain;
      const coin = sellIsQuote ? buyCoin : sellCoin;
      const poolId = this.getPoolIdByToken(chain, coin);
      if (poolId) {
        this.relatePoolId = {
          sellPoolId: poolId,
          buyPoolId: poolId
        };
      } else {
        this.checkEventList();
        throw new Error('没有找到对应池子ID');
      }
    } else {
      /** 跨池子 */
      const sellPoolId = this.getPoolIdByToken(sellChain, sellCoin);
      const buyPoolId = this.getPoolIdByToken(buyChain, buyCoin);
      if (sellPoolId) {
        this.relatePoolId.sellPoolId = sellPoolId;
      }
      if (buyPoolId) {
        this.relatePoolId.buyPoolId = buyPoolId;
      }
    }
  }
  /** 池子的工具方法 */
  poolUtil() {
    const {
      sellPanel,
      buyPanel,
      relatePool
    } = this;
    const {
      coin: sellCoin,
      chain: sellChain,
      amount: sellAmount
    } = sellPanel;
    const {
      coin: buyCoin,
      chain: buyChain,
      amount: buyAmount
    } = buyPanel;
    const sellIsQuote = sellCoin === _bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_9__.BNQKL_SWAP_COIN_NAME.USDM;
    const buyIsQuote = buyCoin === _bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_9__.BNQKL_SWAP_COIN_NAME.USDM;
    const {
      sellPool,
      buyPool
    } = relatePool;
    return {
      sellAmount,
      buyAmount,
      sellCoin,
      buyCoin,
      sellChain,
      buyChain,
      sellIsQuote,
      buyIsQuote,
      sellPool,
      buyPool
    };
  }
  /** 卖出的计算和赋值 */
  handleSellCaculate() {
    this.caculateErr = _swap_type__WEBPACK_IMPORTED_MODULE_24__.CACULATE_RESULT_ERROR_STATUS.HAS_NO_LIQUIDITY;
    this.caculateResult = true;
    const {
      sellCoin,
      sellAmount,
      buyCoin,
      sellChain,
      buyChain
    } = this.poolUtil();
    const {
      relatePool
    } = this;
    const {
      sellPool,
      buyPool
    } = relatePool;
    if (sellPool === undefined || buyPool === undefined) {
      this.console.log('没有对应池子');
      return;
    }
    if (sellCoin && buyCoin && sellChain && buyChain) {
      if (sellAmount === '') {
        this.buyPanel.amount = '';
        return;
      }
      if (Number(sellAmount) === 0) {
        this.buyPanel.amount = '';
        this.caculateResult = false;
        this.caculateErr = _swap_type__WEBPACK_IMPORTED_MODULE_24__.CACULATE_RESULT_ERROR_STATUS.INPUT_ZERO;
        return;
      }
      const caculateResult = this.caculateSell(sellChain, sellCoin, sellAmount, sellPool, buyPool, buyChain, buyCoin);
      const {
        result
      } = caculateResult;
      this.caculateResult = result;
      if (result) {
        const {
          amount
        } = caculateResult;
        this.buyPanel.amount = amount;
        this.handlePriceCaculate(sellCoin, sellAmount, buyCoin, amount);
      } else {
        this.buyPanel.amount = '';
        const {
          message
        } = caculateResult;
        this.caculateErr = message;
      }
    }
  }
  /** 价格的计算和赋值 */
  handlePriceCaculate(sellCoin, sellAmount, buyCoin, buyAmount) {
    if (Number(sellAmount) === 0 || Number(buyAmount) === 0) {
      this.console.log('数量不能为零');
      return;
    }
    this.price.direction = _services_liquidity_pool_liquidity_pool_helper__WEBPACK_IMPORTED_MODULE_20__.PRICE_DIRECTION.FORWARD;
    const forwardPrice = Number(new bignumber_js__WEBPACK_IMPORTED_MODULE_22__["default"](sellAmount).dividedBy(buyAmount).toFixed(8, 1)).toString();
    const backPrice = Number(new bignumber_js__WEBPACK_IMPORTED_MODULE_22__["default"](buyAmount).dividedBy(sellAmount).toFixed(8, 1)).toString();
    const option = {
      direction: _services_liquidity_pool_liquidity_pool_helper__WEBPACK_IMPORTED_MODULE_20__.PRICE_DIRECTION.FORWARD,
      format: false
    };
    const generatePrice = (0,_services_liquidity_pool_liquidity_pool_helper__WEBPACK_IMPORTED_MODULE_20__.generatePriceUtil)(buyCoin, forwardPrice, sellCoin, backPrice, option);
    this.price = generatePrice;
  }
  /** 计算可以得到的数量 */
  caculateSell(chain, coin, inputAmount, sellPool, buyPool, buyChain, buyCoin) {
    const amount = String(parseInt(new bignumber_js__WEBPACK_IMPORTED_MODULE_22__["default"](inputAmount).multipliedBy(1e8).toString()));
    const {
      sellIsQuote,
      buyIsQuote
    } = this.poolUtil();
    /** 卖出或者买入的币 其中有一个是锚定货币 此时只涉及一个池子 */
    if (sellIsQuote || buyIsQuote) {
      const UName = sellIsQuote ? coin : buyCoin;
      const UChain = sellIsQuote ? chain : buyChain;
      const {
        success,
        amount: poolUAmount
      } = this.getPoolSmallUAmountByCoinName(sellPool, UChain);
      if (success === false) {
        this.showPoolCoinNotEnough = true;
        this.poolUNotEnoughTip = `当前池子不支持 ${_bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_9__.BNQKL_SWAP_COIN_NAME.USDM} ( ${UChain} ) 的交易,请重选`;
        return {
          result: false,
          message: _swap_type__WEBPACK_IMPORTED_MODULE_24__.CACULATE_RESULT_ERROR_STATUS.HAS_NO_LIQUIDITY
        };
      }
      const gainAmount = _bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_9__.calculateHelper.calculateGainByExchange(_services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_8__.NODE_CHAIN_NAME_TRANSFER_REVERSE[chain], coin, amount, sellPool);
      const gAmount = _bnqkl_framework_pipes__WEBPACK_IMPORTED_MODULE_18__.AmountFixedPipe.transform(Number(gainAmount), 8, {
        removeZero: true
      });
      const UAmount = sellIsQuote ? amount : gainAmount.toString();
      if (buyIsQuote && new bignumber_js__WEBPACK_IMPORTED_MODULE_22__["default"](UAmount).isGreaterThanOrEqualTo(poolUAmount)) {
        this.showPoolCoinNotEnough = true;
        const poolUCoinAmount = _bnqkl_framework_pipes__WEBPACK_IMPORTED_MODULE_18__.AmountFixedPipe.transform(Number(poolUAmount), 8, {
          removeZero: true
        });
        this.poolUNotEnoughTip = `* 池中${_bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_9__.BNQKL_SWAP_COIN_NAME.USDM}(${UChain}) 的数量剩余 ${poolUCoinAmount} ，请修改买入数量`;
        return {
          result: false,
          message: _swap_type__WEBPACK_IMPORTED_MODULE_24__.CACULATE_RESULT_ERROR_STATUS.HAS_NO_LIQUIDITY
        };
      }
      return {
        result: true,
        amount: gAmount
      };
    } else {
      const caculateResult = this.sellPoolCaculate(sellPool, buyPool, chain, coin, amount);
      const {
        result
      } = caculateResult;
      if (result) {
        const {
          amount
        } = caculateResult;
        const formatAmount = _bnqkl_framework_pipes__WEBPACK_IMPORTED_MODULE_18__.AmountFixedPipe.transform(Number(amount), 8, {
          removeZero: true
        });
        return {
          result: true,
          amount: formatAmount
        };
      } else {
        const {
          message
        } = caculateResult;
        return {
          result: false,
          message
        };
      }
    }
  }
  /** 获取池子币的数量 */
  getPoolCoinAmountByCoinAndChain(coin, chain, pool) {
    const {
      anchorCoinsName,
      anchorCoinsChainName,
      anchorCoinsAmount,
      quoteCoinsAmount
    } = pool;
    if (coin === anchorCoinsName && chain === _services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_8__.NODE_CHAIN_NAME_TRANSFER[anchorCoinsChainName]) {
      return anchorCoinsAmount;
    } else {
      return quoteCoinsAmount;
    }
  }
  buyPoolCaculate(poolA, poolB, chain, coin, amount) {
    this.console.log('兑换路径计算', `${poolA.anchorCoinsChainName}-${poolA.anchorCoinsName}-${poolB.quoteCoinsChainName}-${poolB.quoteCoinsName} => ${poolB.anchorCoinsChainName}-${poolB.anchorCoinsName}-${poolB.quoteCoinsChainName}-${poolA.quoteCoinsName}`, '关联池子信息', poolA, poolB);
    /** 如何输入的数量大于池子数量 直接放弃计算 */
    const poolCoinAmount = this.getPoolCoinAmountByCoinAndChain(coin, chain, poolA);
    if (Number(amount) > Number(poolCoinAmount)) {
      this.console.log('兑换路径计算结果：输入值', `${amount}`, '大于POOLA的数量：', `${poolCoinAmount}`);
      return {
        message: _swap_type__WEBPACK_IMPORTED_MODULE_24__.CACULATE_RESULT_ERROR_STATUS.HAS_NO_LIQUIDITY,
        result: false
      };
    }
    const gainAmount = _bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_9__.calculateHelper.calculateSpendByExchange(_services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_8__.NODE_CHAIN_NAME_TRANSFER_REVERSE[chain], coin, amount, poolA);
    this.console.log('兑换路径计算：获得的U的数量', gainAmount);
    const {
      chain: sellChain,
      coin: sellCoin
    } = this.sellPanel;
    if (sellChain === undefined || sellCoin === undefined) {
      throw new Error('面板输入值不应该为undefined');
    }
    const {
      anchorCoinsChainName,
      anchorCoinsName,
      quoteCoinsName,
      quoteCoinsChainName
    } = poolB;
    const flag = sellChain === _services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_8__.NODE_CHAIN_NAME_TRANSFER[anchorCoinsChainName] && sellCoin === anchorCoinsName;
    const chainName = flag ? quoteCoinsChainName : anchorCoinsChainName;
    const coinName = flag ? quoteCoinsName : anchorCoinsName;
    /** 如何输入的数量大于池子数量 直接放弃计算 */
    if (Number(gainAmount) > Number(this.getPoolCoinAmountByCoinAndChain(coinName, _services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_8__.NODE_CHAIN_NAME_TRANSFER[chainName], poolB))) {
      this.console.log('兑换路径计算结果：B池子U数量不足以兑换');
      return {
        message: _swap_type__WEBPACK_IMPORTED_MODULE_24__.CACULATE_RESULT_ERROR_STATUS.HAS_NO_LIQUIDITY,
        result: false
      };
    }
    if (Number(gainAmount) === 0) {
      this.console.log('兑换路径计算结果：兑换出来的U过小');
      return {
        message: _swap_type__WEBPACK_IMPORTED_MODULE_24__.CACULATE_RESULT_ERROR_STATUS.HAS_NO_LIQUIDITY,
        result: false
      };
    }
    const lastAmount = _bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_9__.calculateHelper.calculateSpendByExchange(chainName, coinName, String(gainAmount), poolB);
    this.console.log('兑换路径计算结果：获得最终token数量', lastAmount);
    return {
      result: true,
      amount: String(lastAmount)
    };
  }
  sellPoolCaculate(poolA, poolB, chain, coin, amount) {
    this.console.log('兑换路径计算', `${poolA.anchorCoinsChainName}-${poolA.anchorCoinsName}-${poolB.quoteCoinsChainName}-${poolB.quoteCoinsName} => ${poolB.anchorCoinsChainName}-${poolB.anchorCoinsName}-${poolB.quoteCoinsChainName}-${poolA.quoteCoinsName}`, '关联池子信息', poolA, poolB);
    const gainAmount = _bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_9__.calculateHelper.calculateGainByExchange(_services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_8__.NODE_CHAIN_NAME_TRANSFER_REVERSE[chain], coin, amount, poolA);
    const {
      chain: buyChain,
      coin: buyCoin
    } = this.buyPanel;
    this.console.log('兑换路径计算：获得的U的数量', gainAmount);
    if (Number(gainAmount) === 0) {
      this.console.log('兑换路径计算结果：兑换出来的U过小');
      return {
        message: _swap_type__WEBPACK_IMPORTED_MODULE_24__.CACULATE_RESULT_ERROR_STATUS.HAS_NO_LIQUIDITY,
        result: false
      };
    }
    const {
      anchorCoinsChainName,
      anchorCoinsName,
      quoteCoinsName,
      quoteCoinsChainName
    } = poolB;
    const flag = buyChain === _services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_8__.NODE_CHAIN_NAME_TRANSFER[anchorCoinsChainName] && buyCoin === anchorCoinsName;
    const chainName = flag ? quoteCoinsChainName : anchorCoinsChainName;
    const coinName = flag ? quoteCoinsName : anchorCoinsName;
    const lastAmount = _bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_9__.calculateHelper.calculateGainByExchange(chainName, coinName, String(gainAmount), poolB);
    this.console.log('兑换路径计算：获得最终token数量', lastAmount);
    return {
      result: true,
      amount: String(lastAmount)
    };
  }
  /** 买入的计算和赋值 */
  handleBuyCaculate() {
    this.caculateResult = true;
    this.caculateErr = _swap_type__WEBPACK_IMPORTED_MODULE_24__.CACULATE_RESULT_ERROR_STATUS.HAS_NO_LIQUIDITY;
    const {
      buyCoin,
      buyAmount,
      sellCoin,
      buyChain,
      sellChain
    } = this.poolUtil();
    const {
      relatePool
    } = this;
    const {
      sellPool,
      buyPool
    } = relatePool;
    if (sellPool === undefined || buyPool === undefined) {
      this.console.log('没有对应池子');
      return;
    }
    if (sellCoin && buyCoin && buyChain && sellChain) {
      if (buyAmount === '') {
        this.sellPanel.amount = '';
        return;
      }
      if (Number(buyAmount) === 0) {
        this.sellPanel.amount = '';
        this.caculateResult = false;
        this.caculateErr = _swap_type__WEBPACK_IMPORTED_MODULE_24__.CACULATE_RESULT_ERROR_STATUS.INPUT_ZERO;
        return;
      }
      const caculateResult = this.caculateBuy(buyChain, buyCoin, buyAmount, sellPool, buyPool, sellChain, sellCoin);
      const {
        result
      } = caculateResult;
      this.caculateResult = result;
      if (result) {
        const {
          amount
        } = caculateResult;
        this.sellPanel.amount = amount;
        this.handlePriceCaculate(sellCoin, amount, buyCoin, buyAmount);
      } else {
        const {
          message
        } = caculateResult;
        this.caculateErr = message;
        this.sellPanel.amount = '';
      }
    }
  }
  /** 获取池子小U数量 */
  getPoolSmallUAmountByCoinName(pool, chain) {
    const targetU = pool.quoteAssociatedCoins.find(item => {
      return item.chainName === _services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_8__.NODE_CHAIN_NAME_TRANSFER_REVERSE[chain];
    });
    if (targetU === undefined) {
      return {
        success: false,
        amount: '0'
      };
    }
    return {
      success: true,
      amount: targetU.amount
    };
  }
  /** 计算需要花费的数量 */
  caculateBuy(chain, coin, inputAmount, sellPool, buyPool, sellChain, sellCoin) {
    const amount = String(parseInt(new bignumber_js__WEBPACK_IMPORTED_MODULE_22__["default"](inputAmount).multipliedBy(1e8).toString()));
    const {
      sellIsQuote,
      buyIsQuote
    } = this.poolUtil();
    /** 买入的币是锚定货币 此时只涉及一个池子 */
    if (sellIsQuote || buyIsQuote) {
      const poolAmount = sellPool.anchorCoinsChainName === _services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_8__.NODE_CHAIN_NAME_TRANSFER_REVERSE[chain] && sellPool.anchorCoinsName === coin ? sellPool.anchorCoinsAmount : sellPool.quoteCoinsAmount;
      if (new bignumber_js__WEBPACK_IMPORTED_MODULE_22__["default"](amount).isGreaterThanOrEqualTo(poolAmount)) {
        return {
          result: false,
          message: _swap_type__WEBPACK_IMPORTED_MODULE_24__.CACULATE_RESULT_ERROR_STATUS.HAS_NO_LIQUIDITY
        };
      }
      const UChain = buyIsQuote ? chain : sellChain;
      const result = this.getPoolSmallUAmountByCoinName(sellPool, UChain);
      const {
        success,
        amount: poolUAmount
      } = result;
      if (success === false) {
        this.showPoolCoinNotEnough = true;
        this.poolUNotEnoughTip = `当前池子不支持 ${_bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_9__.BNQKL_SWAP_COIN_NAME.USDM} ( ${UChain} ) 的交易,请重选`;
        return {
          result: false,
          message: _swap_type__WEBPACK_IMPORTED_MODULE_24__.CACULATE_RESULT_ERROR_STATUS.HAS_NO_LIQUIDITY
        };
      }
      const spendAmount = _bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_9__.calculateHelper.calculateSpendByExchange(_services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_8__.NODE_CHAIN_NAME_TRANSFER_REVERSE[chain], coin, amount, sellPool);
      const formatAmount = _bnqkl_framework_pipes__WEBPACK_IMPORTED_MODULE_18__.AmountFixedPipe.transform(Number(spendAmount), 8, {
        removeZero: true
      });
      const UAmount = buyIsQuote ? amount : spendAmount.toString();
      if (new bignumber_js__WEBPACK_IMPORTED_MODULE_22__["default"](UAmount).isGreaterThanOrEqualTo(poolUAmount)) {
        this.showPoolCoinNotEnough = true;
        const poolUCoinAmount = _bnqkl_framework_pipes__WEBPACK_IMPORTED_MODULE_18__.AmountFixedPipe.transform(Number(poolUAmount), 8, {
          removeZero: true
        });
        this.poolUNotEnoughTip = `* 池中${_bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_9__.BNQKL_SWAP_COIN_NAME.USDM}(${UChain}) 的数量剩余 ${poolUCoinAmount} ，请修改买入数量`;
        return {
          result: false,
          message: _swap_type__WEBPACK_IMPORTED_MODULE_24__.CACULATE_RESULT_ERROR_STATUS.HAS_NO_LIQUIDITY
        };
      }
      return {
        result: true,
        amount: formatAmount
      };
    } else {
      /** 卖出的币不是锚定货币 此时涉及多个池子 */
      const caculateResult = this.buyPoolCaculate(buyPool, sellPool, chain, coin, amount);
      const {
        result
      } = caculateResult;
      if (result) {
        const {
          amount
        } = caculateResult;
        const formatAmount = _bnqkl_framework_pipes__WEBPACK_IMPORTED_MODULE_18__.AmountFixedPipe.transform(amount, 8, {
          removeZero: true
        });
        return {
          amount: formatAmount,
          result: true
        };
      } else {
        const {
          message
        } = caculateResult;
        return {
          message,
          result: false
        };
      }
    }
  }
  /** 打开增加流动性弹窗 */
  openAddLiquidityDialog() {
    var _this12 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const {
        sellIsQuote,
        buyIsQuote,
        sellCoin,
        buyCoin,
        sellChain,
        buyChain
      } = _this12.poolUtil();
      if (buyChain === undefined || buyCoin === undefined || sellCoin === undefined || sellChain === undefined) return;
      const coinName = `${sellCoin}-${buyCoin}`;
      const poolName = sellIsQuote || buyIsQuote ? `${coinName}` : `${sellCoin}-${_bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_9__.BNQKL_SWAP_COIN_NAME.USDM},${buyCoin}-${_bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_9__.BNQKL_SWAP_COIN_NAME.USDM}`;
      let params = {};
      if (sellIsQuote) {
        params = {
          anchorCoinName: buyCoin,
          anchorChainName: _services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_8__.NODE_CHAIN_NAME_TRANSFER_REVERSE[buyChain],
          quoteCoinName: sellCoin,
          quoteChainName: _services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_8__.NODE_CHAIN_NAME_TRANSFER_REVERSE[sellChain]
        };
      } else if (buyIsQuote) {
        params = {
          anchorCoinName: sellCoin,
          anchorChainName: _services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_8__.NODE_CHAIN_NAME_TRANSFER_REVERSE[sellChain],
          quoteCoinName: buyCoin,
          quoteChainName: _services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_8__.NODE_CHAIN_NAME_TRANSFER_REVERSE[buyChain]
        };
      }
      const confirm = yield _this12.confirm({
        headerTitle: `当前${poolName}流动性池暂无资金，无法进行${coinName}的兑换。`,
        bodyMessage: '您可以等待其他用户提供流动性后再进行兑换，也可以前往增加对应币种的流动性。',
        footerTheme: 'normal',
        bodyAlign: 'left',
        confirmText: '增加流动性'
      });
      _this12._templateDialogService;
      yield (0,_bnqkl_util_web_extends_promise__WEBPACK_IMPORTED_MODULE_10__.sleep)(250);
      if (confirm) {
        _this12.nav.routeTo('/add-liquidity', {
          ...params
        });
      }
    })();
  }
}
_class = SwapPage;
_class.ɵfac = /*@__PURE__*/(() => {
  let ɵSwapPage_BaseFactory;
  return function SwapPage_Factory(t) {
    return (ɵSwapPage_BaseFactory || (ɵSwapPage_BaseFactory = _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵgetInheritedFactory"](_class)))(t || _class);
  };
})();
_class.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵdefineComponent"]({
  type: _class,
  selectors: [["bs-swap-page"]],
  viewQuery: function SwapPage_Query(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵviewQuery"](_c0, 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵviewQuery"](_c1, 5);
    }
    if (rf & 2) {
      let _t;
      _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵloadQuery"]()) && (ctx.sellInputRef = _t.first);
      _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵloadQuery"]()) && (ctx.buyInputRef = _t.first);
    }
  },
  standalone: true,
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵInheritDefinitionFeature"], _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵStandaloneFeature"]],
  decls: 62,
  vars: 37,
  consts: () => {
    let i18n_2;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_414265532316095642$$APPS_BFSWAP_SRC_PAGES_HOME_PAGES_SWAP_SWAP_COMPONENT_TS_3 = goog.getMsg("\u5151\u6362");
      i18n_2 = MSG_EXTERNAL_414265532316095642$$APPS_BFSWAP_SRC_PAGES_HOME_PAGES_SWAP_SWAP_COMPONENT_TS_3;
    } else {
      i18n_2 = "\u5151\u6362";
    }
    let i18n_4;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_6152238977593172558$$APPS_BFSWAP_SRC_PAGES_HOME_PAGES_SWAP_SWAP_COMPONENT_TS_5 = goog.getMsg("{$interpolation} \u6ED1\u70B9", {
        "interpolation": "\uFFFD0\uFFFD"
      }, {
        original_code: {
          "interpolation": "{{ slippageLabel }}"
        }
      });
      i18n_4 = MSG_EXTERNAL_6152238977593172558$$APPS_BFSWAP_SRC_PAGES_HOME_PAGES_SWAP_SWAP_COMPONENT_TS_5;
    } else {
      i18n_4 = "" + "\uFFFD0\uFFFD" + " \u6ED1\u70B9";
    }
    let i18n_6;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_BUY$$APPS_BFSWAP_SRC_PAGES_HOME_PAGES_SWAP_SWAP_COMPONENT_TS_7 = goog.getMsg("Buy");
      i18n_6 = MSG_EXTERNAL_BUY$$APPS_BFSWAP_SRC_PAGES_HOME_PAGES_SWAP_SWAP_COMPONENT_TS_7;
    } else {
      i18n_6 = "Buy";
    }
    let i18n_8;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_NUMBER$$APPS_BFSWAP_SRC_PAGES_HOME_PAGES_SWAP_SWAP_COMPONENT_TS_9 = goog.getMsg("number");
      i18n_8 = MSG_EXTERNAL_NUMBER$$APPS_BFSWAP_SRC_PAGES_HOME_PAGES_SWAP_SWAP_COMPONENT_TS_9;
    } else {
      i18n_8 = "number";
    }
    let i18n_10;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_ENTER_QUANTITY$$APPS_BFSWAP_SRC_PAGES_HOME_PAGES_SWAP_SWAP_COMPONENT_TS_11 = goog.getMsg("Enter");
      i18n_10 = MSG_EXTERNAL_ENTER_QUANTITY$$APPS_BFSWAP_SRC_PAGES_HOME_PAGES_SWAP_SWAP_COMPONENT_TS_11;
    } else {
      i18n_10 = "Enter quantity";
    }
    let i18n_12;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_SELL$$APPS_BFSWAP_SRC_PAGES_HOME_PAGES_SWAP_SWAP_COMPONENT_TS_13 = goog.getMsg("Sell");
      i18n_12 = MSG_EXTERNAL_SELL$$APPS_BFSWAP_SRC_PAGES_HOME_PAGES_SWAP_SWAP_COMPONENT_TS_13;
    } else {
      i18n_12 = "Sell";
    }
    let i18n_14;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_NUMBER$$APPS_BFSWAP_SRC_PAGES_HOME_PAGES_SWAP_SWAP_COMPONENT_TS_15 = goog.getMsg("number");
      i18n_14 = MSG_EXTERNAL_NUMBER$$APPS_BFSWAP_SRC_PAGES_HOME_PAGES_SWAP_SWAP_COMPONENT_TS_15;
    } else {
      i18n_14 = "number";
    }
    let i18n_16;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_ENTER_QUANTITY$$APPS_BFSWAP_SRC_PAGES_HOME_PAGES_SWAP_SWAP_COMPONENT_TS_17 = goog.getMsg("Enter");
      i18n_16 = MSG_EXTERNAL_ENTER_QUANTITY$$APPS_BFSWAP_SRC_PAGES_HOME_PAGES_SWAP_SWAP_COMPONENT_TS_17;
    } else {
      i18n_16 = "Enter quantity";
    }
    let i18n_18;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_SELECT_TOKENS$$APPS_BFSWAP_SRC_PAGES_HOME_PAGES_SWAP_SWAP_COMPONENT_TS__19 = goog.getMsg("Select tokens");
      i18n_18 = MSG_EXTERNAL_SELECT_TOKENS$$APPS_BFSWAP_SRC_PAGES_HOME_PAGES_SWAP_SWAP_COMPONENT_TS__19;
    } else {
      i18n_18 = "Select tokens";
    }
    let i18n_20;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_SELECT_TOKENS$$APPS_BFSWAP_SRC_PAGES_HOME_PAGES_SWAP_SWAP_COMPONENT_TS__21 = goog.getMsg("Select tokens");
      i18n_20 = MSG_EXTERNAL_SELECT_TOKENS$$APPS_BFSWAP_SRC_PAGES_HOME_PAGES_SWAP_SWAP_COMPONENT_TS__21;
    } else {
      i18n_20 = "Select tokens";
    }
    let i18n_22;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_2229239702615161749$$APPS_BFSWAP_SRC_PAGES_HOME_PAGES_SWAP_SWAP_COMPONENT_TS__23 = goog.getMsg(" \u6700\u5927 ");
      i18n_22 = MSG_EXTERNAL_2229239702615161749$$APPS_BFSWAP_SRC_PAGES_HOME_PAGES_SWAP_SWAP_COMPONENT_TS__23;
    } else {
      i18n_22 = " \u6700\u5927 ";
    }
    let i18n_24;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_7497479747351602435$$APPS_BFSWAP_SRC_PAGES_HOME_PAGES_SWAP_SWAP_COMPONENT_TS__25 = goog.getMsg(" * {$interpolation} \u5151\u6362\u91CF\u5C06\u7528\u4E8E\u589E\u52A0\u6D41\u52A8\u6027\uFF0C\u5E76\u83B7\u5F97\u5408\u7EA6\u6C60\u6743\u76CA ", {
        "interpolation": "\uFFFD0\uFFFD"
      }, {
        original_code: {
          "interpolation": "{{ addLiquilidityRatioLabel }}"
        }
      });
      i18n_24 = MSG_EXTERNAL_7497479747351602435$$APPS_BFSWAP_SRC_PAGES_HOME_PAGES_SWAP_SWAP_COMPONENT_TS__25;
    } else {
      i18n_24 = " * " + "\uFFFD0\uFFFD" + " \u5151\u6362\u91CF\u5C06\u7528\u4E8E\u589E\u52A0\u6D41\u52A8\u6027\uFF0C\u5E76\u83B7\u5F97\u5408\u7EA6\u6C60\u6743\u76CA ";
    }
    let i18n_26;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_4858575122153707666$$APPS_BFSWAP_SRC_PAGES_HOME_PAGES_SWAP_SWAP_COMPONENT_TS__27 = goog.getMsg("{$interpolation}", {
        "interpolation": "\uFFFD0\uFFFD"
      }, {
        original_code: {
          "interpolation": "{{\r\n          gasFeeTipText\r\n          }}"
        }
      });
      i18n_26 = MSG_EXTERNAL_4858575122153707666$$APPS_BFSWAP_SRC_PAGES_HOME_PAGES_SWAP_SWAP_COMPONENT_TS__27;
    } else {
      i18n_26 = "" + "\uFFFD0\uFFFD" + "";
    }
    let i18n_28;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_5338848983777297211$$APPS_BFSWAP_SRC_PAGES_HOME_PAGES_SWAP_SWAP_COMPONENT_TS__29 = goog.getMsg(" {$interpolation} ", {
        "interpolation": "\uFFFD0\uFFFD"
      }, {
        original_code: {
          "interpolation": "{{ poolUNotEnoughTip }}"
        }
      });
      i18n_28 = MSG_EXTERNAL_5338848983777297211$$APPS_BFSWAP_SRC_PAGES_HOME_PAGES_SWAP_SWAP_COMPONENT_TS__29;
    } else {
      i18n_28 = " " + "\uFFFD0\uFFFD" + " ";
    }
    return [[3, "headerTitle", "contentBackground", "hideHeader", "ngStyle"], [1, "px-4", "pt-4"], [1, "mb-4", "flex", "h-10", "items-center"], [1, "text-title-10", "text-[2rem]", "font-semibold"], i18n_2, [1, "rounded-2.5", "border-base-300", "ml-auto", "mr-3", "flex", "items-center", "justify-center", "border", "pl-3", 3, "click"], [1, "text-subtitle", "text-xs"], i18n_4, [1, "bg-base-300", "rounded-2.5", "ml-2.5", "flex", "h-8", "w-8", "items-center", "justify-center"], ["name", "icon-slider", 1, "text-xl"], [1, "bg-base-300", "rounded-2.5", "flex", "h-8", "w-8", "items-center", "justify-center"], ["name", "icon-history", 1, "icon-5", 3, "click"], [1, "rounded-4", "bg-base-300", "relative", "mb-2", "flex-shrink-0", "p-4"], [1, "relative", "z-10"], [1, "mb-4", "flex", "items-center"], [1, "text-gray-10", "text-sm", "font-semibold"], i18n_6, [1, "flex", "items-center", 3, "click"], ["class", "rounded-1.5 flex flex-shrink-0 items-center bg-white py-1 pl-3 pr-2"], ["layout", i18n_8, "placeholder", i18n_10, 1, "text-black-10", "placeholder:text-base-200", "ml-auto", "max-w-1/2", "border-none", "text-right", "text-2xl", "font-semibold", "outline-none", "placeholder:text-2xl", 3, "maxDecimals", "maxValue", "formControl", "ngModel", "ngModelChange"], [1, "relative", "z-10", "flex", "items-center", "text-sm"], ["name", "icon-assets-normal", 1, "text-2xl"], [1, "text-gray-10", "mr-1"], [1, "rounded-4", "bg-base-300", "relative", "mb-2", "p-4"], [1, "absolute", "-top-6", "right-16", "z-20", "flex", "h-12", "w-12", "items-center", "justify-center", "rounded-full", "bg-white", 3, "click"], ["name", "icon-home-arrow-exchange", 1, "text-2xl"], i18n_12, ["class", "rounded-1.5 flex flex-shrink-0 items-center bg-white py-1 pl-2 pr-3"], ["layout", i18n_14, "placeholder", i18n_16, 1, "text-black-10", "placeholder:text-base-200", "ml-auto", "max-w-1/2", "border-none", "text-right", "text-2xl", "font-semibold", "outline-none", "placeholder:text-2xl", 3, "maxDecimals", "maxValue", "formControl", "ngModel", "ngModelChange"], [1, "flex", "items-center", "text-sm"], ["class", "text-primary bg-bg-button-6 rounded-1 ml-auto px-2 py-1 text-xs"], ["class", "text-base-200 text-center text-xs"], [1, "flex", "h-8", "items-center", "justify-center"], ["class", "flex items-center justify-center"], ["bnRippleButton", "", 1, "rounded-12", "mt-4", "flex", "w-full", "shrink-0", "items-center", "justify-center", "py-2.5", "text-lg", "font-semibold", "text-white", 3, "disabled", "click"], [1, "relative"], [1, "icon-6", "absolute", "-right-6", "top-0", 3, "loadingTheme", "showLoading"], ["class", "text-red-10 mx-auto mt-2 w-4/5 text-center text-xs leading-5"], ["class", "my-6 flex items-center justify-center"], [3, "isOpen", "panelClass", "isOpenChange"], [3, "isOpen", "isOpenChange"], [1, "rounded-1.5", "mx-1", "flex", "h-5", "w-5", "items-center", "justify-center", "border", "border-white"], [1, "text-lg", 3, "name"], [1, "text-black-10"], [1, "rounded-1.5", "flex", "flex-shrink-0", "items-center", "bg-white", "py-1", "pl-3", "pr-2"], [1, "text-title-10", "mr-1"], i18n_18, ["name", "icon-home-arrow-token", "bnRippleButton", "", 1, "icon-4", 3, "mode"], [1, "text-[1.75rem]", 3, "name"], [1, "text-base-content-100", "mx-1", "text-base", "font-semibold"], ["bnRippleButton", "", 1, "icon-4", 3, "mode"], ["name", "icon-home-arrow-token"], [1, "rounded-1", "mx-1", "flex", "h-5", "w-5", "items-center", "justify-center", "border", "border-white"], [1, "rounded-1.5", "flex", "flex-shrink-0", "items-center", "bg-white", "py-1", "pl-2", "pr-3"], i18n_20, [1, "text-primary", "bg-bg-button-6", "rounded-1", "ml-auto", "px-2", "py-1", "text-xs", 3, "click"], i18n_22, [1, "text-base-200", "text-center", "text-xs"], i18n_24, [1, "flex", "items-center", "justify-center"], ["src", "./assets/images/icon-right.svg"], i18n_26, ["src", "./assets/images/icon-wrong.svg"], [1, "text-red-10", "mx-auto", "mt-2", "w-4/5", "text-center", "text-xs", "leading-5"], i18n_28, [1, "my-6", "flex", "items-center", "justify-center"], ["name", "icon-home-refresh", 1, "text-2xl", 3, "ngStyle", "click"], [1, "text-gray-10", "mx-1"], ["name", "icon-home-arrow-exchange-rate", 1, "text-2xl", 3, "ngStyle", "click"], [3, "sellPanel", "buyPanel", "preParams", "transferOptions", "platformFee", "expectBuyAmount", "returnValue$"], [3, "noUSDM", "liquidityPoolAssetsInfo", "selectedAsset", "disabledAsset", "chainGroupInfo", "returnValue$"], [3, "connectType", "presetWallets"]];
  },
  template: function SwapPage_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵelementStart"](0, "common-page", 0)(1, "div", 1)(2, "div", 2)(3, "div", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵi18n"](4, 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵelementStart"](5, "div", 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵlistener"]("click", function SwapPage_Template_div_click_5_listener() {
        return ctx.openAdvancedSettingsSheet();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵelementStart"](6, "div", 6);
      _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵi18n"](7, 7);
      _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵelementStart"](8, "button", 8);
      _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵelement"](9, "bs-icon", 9);
      _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵelementStart"](10, "button", 10)(11, "bs-icon", 11);
      _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵlistener"]("click", function SwapPage_Template_bs_icon_click_11_listener() {
        return ctx.jumpSwapPage();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵelementEnd"]()()();
      _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵelementStart"](12, "div", 12)(13, "div", 13)(14, "div", 14)(15, "div", 15);
      _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵi18n"](16, 16);
      _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵtemplate"](17, SwapPage_Conditional_17_Template, 4, 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵelementStart"](18, "div", 2)(19, "div", 17);
      _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵlistener"]("click", function SwapPage_Template_div_click_19_listener() {
        return ctx.openSelectAssetSheet(ctx.OPERATE.BUY);
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵtemplate"](20, SwapPage_Conditional_20_Template, 4, 1, "div", 18)(21, SwapPage_Conditional_21_Template, 5, 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵelementStart"](22, "bs-numeric-input", 19);
      _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵlistener"]("ngModelChange", function SwapPage_Template_bs_numeric_input_ngModelChange_22_listener($event) {
        return ctx.buyPanel.amount = $event;
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵelementStart"](23, "div", 20);
      _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵelement"](24, "bs-icon", 21);
      _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵelementStart"](25, "span", 22);
      _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵtext"](26);
      _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵelementEnd"]()()()();
      _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵelementStart"](27, "div", 23)(28, "div", 24);
      _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵlistener"]("click", function SwapPage_Template_div_click_28_listener() {
        return ctx.reversePanel();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵelement"](29, "bs-icon", 25);
      _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵelementStart"](30, "div", 13)(31, "div", 14)(32, "div", 15);
      _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵi18n"](33, 26);
      _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵtemplate"](34, SwapPage_Conditional_34_Template, 4, 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵelementStart"](35, "div", 2)(36, "div", 17);
      _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵlistener"]("click", function SwapPage_Template_div_click_36_listener() {
        return ctx.openSelectAssetSheet(ctx.OPERATE.SELL);
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵtemplate"](37, SwapPage_Conditional_37_Template, 4, 1, "div", 27)(38, SwapPage_Conditional_38_Template, 5, 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵelementStart"](39, "bs-numeric-input", 28);
      _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵlistener"]("ngModelChange", function SwapPage_Template_bs_numeric_input_ngModelChange_39_listener($event) {
        return ctx.sellPanel.amount = $event;
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵelementStart"](40, "div", 29);
      _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵelement"](41, "bs-icon", 21);
      _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵelementStart"](42, "span", 22);
      _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵtext"](43);
      _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵtemplate"](44, SwapPage_Conditional_44_Template, 2, 0, "button", 30);
      _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵelementEnd"]()()();
      _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵtemplate"](45, SwapPage_Conditional_45_Template, 2, 1, "div", 31);
      _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵelementStart"](46, "div", 32);
      _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵtemplate"](47, SwapPage_Conditional_47_Template, 5, 5, "div", 33);
      _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵelementStart"](48, "button", 34);
      _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵlistener"]("click", function SwapPage_Template_button_click_48_listener() {
        return ctx.btnEvent();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵelementStart"](49, "div", 35);
      _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵtext"](50);
      _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵelement"](51, "bn-loading-wrapper", 36);
      _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵtemplate"](52, SwapPage_Conditional_52_Template, 2, 1, "div", 37)(53, SwapPage_Conditional_53_Template, 5, 11, "div", 38);
      _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵelementStart"](54, "common-bottom-sheet", 39);
      _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵlistener"]("isOpenChange", function SwapPage_Template_common_bottom_sheet_isOpenChange_54_listener($event) {
        return ctx.swapSheet.is_open = $event;
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵtemplate"](55, SwapPage_ng_template_55_Template, 1, 6, "ng-template");
      _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵelementStart"](56, "common-bottom-sheet", 40);
      _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵlistener"]("isOpenChange", function SwapPage_Template_common_bottom_sheet_isOpenChange_56_listener($event) {
        return ctx.advancedSettingsSheet.is_open = $event;
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵtemplate"](57, SwapPage_ng_template_57_Template, 1, 0, "ng-template");
      _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵelementStart"](58, "common-bottom-sheet", 39);
      _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵlistener"]("isOpenChange", function SwapPage_Template_common_bottom_sheet_isOpenChange_58_listener($event) {
        return ctx.selectAssetSheet.isOpen = $event;
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵtemplate"](59, SwapPage_ng_template_59_Template, 1, 5, "ng-template");
      _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵelementStart"](60, "common-bottom-sheet", 40);
      _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵlistener"]("isOpenChange", function SwapPage_Template_common_bottom_sheet_isOpenChange_60_listener($event) {
        return ctx.selectWalletSheet.is_open = $event;
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵtemplate"](61, SwapPage_ng_template_61_Template, 1, 2, "ng-template");
      _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵelementEnd"]();
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵproperty"]("headerTitle", "Swap")("contentBackground", "#fff")("hideHeader", true)("ngStyle", _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵpureFunction0"](36, _c32));
      _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵadvance"](7);
      _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵi18nExp"](ctx.slippageLabel);
      _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵi18nApply"](7);
      _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵadvance"](10);
      _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵconditional"](17, ctx.buyPanel.chain ? 17 : -1);
      _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵconditional"](20, !ctx.buyPanel.coin ? 20 : 21);
      _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵproperty"]("maxDecimals", 8)("maxValue", ctx.getBuyMaxValue)("formControl", ctx.buyControl)("ngModel", ctx.buyPanel.amount);
      _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵadvance"](4);
      _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵtextInterpolate"](ctx.buyPanel.balance);
      _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵadvance"](8);
      _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵconditional"](34, ctx.sellPanel.chain ? 34 : -1);
      _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵconditional"](37, !ctx.sellPanel.coin ? 37 : 38);
      _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵproperty"]("maxDecimals", 8)("maxValue", ctx.getSellMaxValue)("formControl", ctx.sellControl)("ngModel", ctx.sellPanel.amount);
      _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵadvance"](4);
      _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵtextInterpolate"](ctx.sellPanel.balance);
      _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵconditional"](44, ctx.showMax() ? 44 : -1);
      _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵconditional"](45, ctx.showAddLiquidityRatio ? 45 : -1);
      _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵconditional"](47, ctx.showGasTip ? 47 : -1);
      _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵclassMap"](ctx.btnDisabled ? "bg-base-200" : " bg-primary");
      _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵproperty"]("disabled", ctx.btnDisabled);
      _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵtextInterpolate1"](" ", ctx.btnText, " ");
      _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵproperty"]("loadingTheme", "ellipsis")("showLoading", ctx.loading);
      _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵconditional"](52, ctx.showPoolCoinNotEnough ? 52 : -1);
      _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵconditional"](53, ctx.showPrice ? 53 : -1);
      _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵproperty"]("isOpen", ctx.swapSheet.is_open)("panelClass", "max-h-4/5");
      _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵproperty"]("isOpen", ctx.advancedSettingsSheet.is_open);
      _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵproperty"]("isOpen", ctx.selectAssetSheet.isOpen)("panelClass", "h-4/5");
      _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_29__["ɵɵproperty"]("isOpen", ctx.selectWalletSheet.is_open);
    }
  },
  dependencies: [_bnqkl_framework_components__WEBPACK_IMPORTED_MODULE_1__.RippleButtonDirective, _modules_page_module__WEBPACK_IMPORTED_MODULE_5__.CommonPageModule, _libs_bnf_modules_bottom_sheet_components_bottom_sheet_component__WEBPACK_IMPORTED_MODULE_26__.BottomSheetComponent, _angular_common__WEBPACK_IMPORTED_MODULE_31__.NgStyle, _angular_forms__WEBPACK_IMPORTED_MODULE_30__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_30__.FormControlDirective, _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_27__.CommonPageComponent, _components_icon_icon_component__WEBPACK_IMPORTED_MODULE_2__.IconComponent, _libs_bnf_components_loading_wrapper_loading_wrapper_component__WEBPACK_IMPORTED_MODULE_28__.LoadingWrapperComponent, _angular_common__WEBPACK_IMPORTED_MODULE_31__.CommonModule, _components_swap_detail_panel_swap_detail_panel_component__WEBPACK_IMPORTED_MODULE_4__["default"], _components_order_settings_order_settings_component__WEBPACK_IMPORTED_MODULE_6__.OrderSettingsPage, _components_select_token_panel_select_token_panel_component__WEBPACK_IMPORTED_MODULE_3__["default"], _components_connect_wallet_panel_connect_wallet_penel_component__WEBPACK_IMPORTED_MODULE_16__["default"], _components_bs_numeric_input_bs_numeric_input_component__WEBPACK_IMPORTED_MODULE_25__.NumericInputComponent],
  styles: ["@keyframes _ngcontent-%COMP%_ring {\n  0% {\n    transform: rotate(0);\n  }\n  100% {\n    transform: rotate(-360deg);\n  }\n}\n[_nghost-%COMP%]   ._price-ani[_ngcontent-%COMP%] {\n  animation-name: _ngcontent-%COMP%_ring;\n  animation-duration: 2s;\n  animation-timing-function: linear;\n  animation-iteration-count: infinite;\n}\n[_nghost-%COMP%]   ._reverse-ani[_ngcontent-%COMP%] {\n  animation-name: _ngcontent-%COMP%_ring;\n  animation-duration: 1s;\n  animation-timing-function: linear;\n  animation-iteration-count: 1;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL2FwcHMvYmZzd2FwL3NyYy9wYWdlcy9ob21lL3BhZ2VzL3N3YXAvc3dhcC5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFDRTtFQUNFO0lBQ0Usb0JBQUE7RUFBSjtFQUdFO0lBQ0UsMEJBQUE7RUFESjtBQUNGO0FBSUU7RUFDRSxvQkFBQTtFQUNBLHNCQUFBO0VBQ0EsaUNBQUE7RUFDQSxtQ0FBQTtBQUZKO0FBS0U7RUFDRSxvQkFBQTtFQUNBLHNCQUFBO0VBQ0EsaUNBQUE7RUFDQSw0QkFBQTtBQUhKIiwic291cmNlc0NvbnRlbnQiOlsiOmhvc3Qge1xyXG4gIEBrZXlmcmFtZXMgcmluZyB7XHJcbiAgICAwJSB7XHJcbiAgICAgIHRyYW5zZm9ybTogcm90YXRlKDApO1xyXG4gICAgfVxyXG5cclxuICAgIDEwMCUge1xyXG4gICAgICB0cmFuc2Zvcm06IHJvdGF0ZSgtMzYwZGVnKTtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIC5fcHJpY2UtYW5pIHtcclxuICAgIGFuaW1hdGlvbi1uYW1lOiByaW5nO1xyXG4gICAgYW5pbWF0aW9uLWR1cmF0aW9uOiAycztcclxuICAgIGFuaW1hdGlvbi10aW1pbmctZnVuY3Rpb246IGxpbmVhcjtcclxuICAgIGFuaW1hdGlvbi1pdGVyYXRpb24tY291bnQ6IGluZmluaXRlO1xyXG4gIH1cclxuXHJcbiAgLl9yZXZlcnNlLWFuaSB7XHJcbiAgICBhbmltYXRpb24tbmFtZTogcmluZztcclxuICAgIGFuaW1hdGlvbi1kdXJhdGlvbjogMXM7XHJcbiAgICBhbmltYXRpb24tdGltaW5nLWZ1bmN0aW9uOiBsaW5lYXI7XHJcbiAgICBhbmltYXRpb24taXRlcmF0aW9uLWNvdW50OiAxO1xyXG4gIH1cclxufVxyXG4iXSwic291cmNlUm9vdCI6IiJ9 */"],
  changeDetection: 0
});
(0,tslib__WEBPACK_IMPORTED_MODULE_32__.__decorate)([SwapPage.QueryParams(), (0,tslib__WEBPACK_IMPORTED_MODULE_32__.__metadata)("design:type", Object)], SwapPage.prototype, "queryParams", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_32__.__decorate)([SwapPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_32__.__metadata)("design:type", Object)], SwapPage.prototype, "OPERATE", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_32__.__decorate)([SwapPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_32__.__metadata)("design:type", Object)], SwapPage.prototype, "connectedWallet", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_32__.__decorate)([SwapPage.States(1), (0,tslib__WEBPACK_IMPORTED_MODULE_32__.__metadata)("design:type", Array)], SwapPage.prototype, "poolDetailList", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_32__.__decorate)([SwapPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_32__.__metadata)("design:type", Object)], SwapPage.prototype, "priceAnimationState", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_32__.__decorate)([SwapPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_32__.__metadata)("design:type", Object)], SwapPage.prototype, "btnText", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_32__.__decorate)([SwapPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_32__.__metadata)("design:type", Object)], SwapPage.prototype, "btnDisabled", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_32__.__decorate)([SwapPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_32__.__metadata)("design:type", Object)], SwapPage.prototype, "loading", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_32__.__decorate)([SwapPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_32__.__metadata)("design:type", Object)], SwapPage.prototype, "version", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_32__.__decorate)([SwapPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_32__.__metadata)("design:type", Object)], SwapPage.prototype, "feeRatio", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_32__.__decorate)([SwapPage.States(1), (0,tslib__WEBPACK_IMPORTED_MODULE_32__.__metadata)("design:type", Object)], SwapPage.prototype, "buyPanel", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_32__.__decorate)([SwapPage.States(1), (0,tslib__WEBPACK_IMPORTED_MODULE_32__.__metadata)("design:type", Object)], SwapPage.prototype, "sellPanel", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_32__.__decorate)([SwapPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_32__.__metadata)("design:type", Object)], SwapPage.prototype, "platformFee", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_32__.__decorate)([SwapPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_32__.__metadata)("design:type", Object)], SwapPage.prototype, "showGasTip", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_32__.__decorate)([SwapPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_32__.__metadata)("design:type", Object)], SwapPage.prototype, "preParams", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_32__.__decorate)([SwapPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_32__.__metadata)("design:type", Object)], SwapPage.prototype, "transferOptions", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_32__.__decorate)([SwapPage.OnDestroy(), (0,tslib__WEBPACK_IMPORTED_MODULE_32__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_32__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_32__.__metadata)("design:returntype", void 0)], SwapPage.prototype, "unsubscribe", null);
(0,tslib__WEBPACK_IMPORTED_MODULE_32__.__decorate)([SwapPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_32__.__metadata)("design:type", Object)], SwapPage.prototype, "sellControl", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_32__.__decorate)([SwapPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_32__.__metadata)("design:type", Object)], SwapPage.prototype, "buyControl", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_32__.__decorate)([SwapPage.OnInit(), (0,tslib__WEBPACK_IMPORTED_MODULE_32__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_32__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_32__.__metadata)("design:returntype", Promise)], SwapPage.prototype, "dataInit", null);
(0,tslib__WEBPACK_IMPORTED_MODULE_32__.__decorate)([SwapPage.OnInit(), (0,tslib__WEBPACK_IMPORTED_MODULE_32__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_32__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_32__.__metadata)("design:returntype", void 0)], SwapPage.prototype, "bindButton", null);
(0,tslib__WEBPACK_IMPORTED_MODULE_32__.__decorate)([SwapPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_32__.__metadata)("design:type", Object)], SwapPage.prototype, "gasFeeIsEnough", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_32__.__decorate)([SwapPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_32__.__metadata)("design:type", Object)], SwapPage.prototype, "gasFeeTipText", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_32__.__decorate)([SwapPage.States(1), (0,tslib__WEBPACK_IMPORTED_MODULE_32__.__metadata)("design:type", Object)], SwapPage.prototype, "swapSheet", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_32__.__decorate)([SwapPage.States(1), (0,tslib__WEBPACK_IMPORTED_MODULE_32__.__metadata)("design:type", Object)], SwapPage.prototype, "selectAssetSheet", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_32__.__decorate)([SwapPage.AfterViewInit(), (0,tslib__WEBPACK_IMPORTED_MODULE_32__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_32__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_32__.__metadata)("design:returntype", void 0)], SwapPage.prototype, "initInputListenEvent", null);
(0,tslib__WEBPACK_IMPORTED_MODULE_32__.__decorate)([SwapPage.States(1), (0,tslib__WEBPACK_IMPORTED_MODULE_32__.__metadata)("design:type", Object)], SwapPage.prototype, "selectWalletSheet", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_32__.__decorate)([SwapPage.States(1), (0,tslib__WEBPACK_IMPORTED_MODULE_32__.__metadata)("design:type", Object)], SwapPage.prototype, "advancedSettingsSheet", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_32__.__decorate)([SwapPage.OnPause(), (0,tslib__WEBPACK_IMPORTED_MODULE_32__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_32__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_32__.__metadata)("design:returntype", void 0)], SwapPage.prototype, "pageOnPause", null);
(0,tslib__WEBPACK_IMPORTED_MODULE_32__.__decorate)([SwapPage.OnResume(), (0,tslib__WEBPACK_IMPORTED_MODULE_32__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_32__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_32__.__metadata)("design:returntype", void 0)], SwapPage.prototype, "pageOnResume", null);
(0,tslib__WEBPACK_IMPORTED_MODULE_32__.__decorate)([SwapPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_32__.__metadata)("design:type", Object)], SwapPage.prototype, "maxMode", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_32__.__decorate)([SwapPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_32__.__metadata)("design:type", Object)], SwapPage.prototype, "showPoolCoinNotEnough", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_32__.__decorate)([SwapPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_32__.__metadata)("design:type", Object)], SwapPage.prototype, "poolUNotEnoughTip", void 0);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SwapPage);

/***/ }),

/***/ 25472:
/*!************************************************************!*\
  !*** ./apps/bfswap/src/pages/home/pages/swap/swap.type.ts ***!
  \************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   CACULATE_RESULT_ERROR_STATUS: () => (/* binding */ CACULATE_RESULT_ERROR_STATUS),
/* harmony export */   OPERATE: () => (/* binding */ OPERATE),
/* harmony export */   errorTextObj: () => (/* binding */ errorTextObj)
/* harmony export */ });
/** 错误类型 */
var CACULATE_RESULT_ERROR_STATUS;
(function (CACULATE_RESULT_ERROR_STATUS) {
  /** HAS_NO_LIQUIDITY */
  CACULATE_RESULT_ERROR_STATUS["HAS_NO_LIQUIDITY"] = "HAS_NO_LIQUIDITY";
  /** INPUT_ZERO */
  CACULATE_RESULT_ERROR_STATUS["INPUT_ZERO"] = "INPUT_ZERO";
})(CACULATE_RESULT_ERROR_STATUS || (CACULATE_RESULT_ERROR_STATUS = {}));
/** 错误翻译 */
const errorTextObj = {
  /** HAS_NO_LIQUIDITY */
  [CACULATE_RESULT_ERROR_STATUS.HAS_NO_LIQUIDITY]: "Insufficient liquidity",
  /** INPUT_ZERO */
  [CACULATE_RESULT_ERROR_STATUS.INPUT_ZERO]: "The quantity can not be zero"
};
/** 操作枚举 */
var OPERATE;
(function (OPERATE) {
  OPERATE["SELL"] = "SELL";
  OPERATE["BUY"] = "BUY";
})(OPERATE || (OPERATE = {}));

/***/ }),

/***/ 89877:
/*!***********************************************************!*\
  !*** ./apps/bfswap/src/services/market/market.service.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   MarketService: () => (/* binding */ MarketService)
/* harmony export */ });
/* harmony import */ var D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 52542);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 61039);
/* harmony import */ var _bnqkl_framework_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @bnqkl/framework/core */ 63563);
/* harmony import */ var _pages_home_pages_market_market_helper__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ~pages/home/pages/market/market.helper */ 64875);
/* harmony import */ var _services_liquidity_pool_liquidity_pool_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ~services/liquidity-pool/liquidity-pool.service */ 20213);

var _class;





class MarketService {
  constructor() {
    /** 日志 */
    this.console = (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.inject)(_bnqkl_framework_core__WEBPACK_IMPORTED_MODULE_1__.LoggerService).createLoggerForService(this, 'market');
    /** 錢包服務 */
    this.liquidityPoolService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.inject)(_services_liquidity_pool_liquidity_pool_service__WEBPACK_IMPORTED_MODULE_3__.LiquidityPoolService);
    /** 市場行情信息 */
    this._marketList = [];
    /** 是否初始化 */
    this.inited = false;
  }
  /** 獲取行情列表 */
  getLiquidityPoolMarket() {
    var _this = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      if (_this.inited) {
        return _this._marketList;
      } else {
        // 初始列表
        const liquidityPooldata = yield _this.liquidityPoolService.getLiquidityPoolConfig();
        const marketList = (0,_pages_home_pages_market_market_helper__WEBPACK_IMPORTED_MODULE_2__.transferPoolListToMaketList)(liquidityPooldata);
        _this.inited = true;
        return marketList;
      }
    })();
  }
  /** 更新市場行情 */
  updateMarketList(marketList) {
    this._marketList = marketList;
  }
}
_class = MarketService;
_class.ɵfac = function MarketService_Factory(t) {
  return new (t || _class)();
};
_class.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineInjectable"]({
  token: _class,
  factory: _class.ɵfac,
  providedIn: 'root'
});

/***/ }),

/***/ 11606:
/*!************************************************************!*\
  !*** ./libs/bnf/controllers/form-validators.controller.ts ***!
  \************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   FormValidatorsController: () => (/* binding */ FormValidatorsController)
/* harmony export */ });
/* harmony import */ var _bnqkl_framework_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @bnqkl/framework/core */ 63563);
/* harmony import */ var _bnqkl_util_web_extends_map__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @bnqkl/util-web/extends-map */ 37689);


/**
 * 页面表单扩展验证器
 *
 * > 因为涉及到FromControl的生命周期管理，所以这里需要使用Controller模式来获取组件/页面的生命周期
 *
 * 为了确保类型安全, 请遵循以下规则去定义验证器:
 * 1. 尽可能直接提供 $ValidatorFn,比如 `trimRequired(control: AbstractControl): $ValidationErrors | null {...}`
 * 2. 如果不能直接提供 $ValidatorFn, 那么作为工厂模式,必然要有参数传入,比如 `equals(leaderCtrl: AbstractControl): $ValidatorFn {...}`
 */
class FormValidatorsController {
  /**
   * 通过订阅原页面的生命周期，来对订阅的字段进行监听解除
   */
  constructor(comp) {
    /**
     * 判断两个数据字段相等的时，left===right 中 left的数据订阅
     */
    this._equalsLeaderMap = _bnqkl_util_web_extends_map__WEBPACK_IMPORTED_MODULE_1__.EasyMap.from({
      creater(ctrl) {
        const sub = {
          sub$: ctrl.valueChanges.subscribe(() => {
            for (const ctrl of sub.destControls) {
              ctrl.updateValueAndValidity();
            }
          }),
          destControls: new Set()
        };
        return sub;
      }
    });
    (0,_bnqkl_framework_core__WEBPACK_IMPORTED_MODULE_0__.addLifecycleMethods)(comp, 'ngOnDestroy', {
      origin: 'form-validator',
      method: () => {
        for (const {
          sub$
        } of this._equalsLeaderMap.values()) {
          sub$.unsubscribe();
        }
        this._equalsLeaderMap.clear();
      },
      order: Number.MAX_SAFE_INTEGER /* 最后才做这些事情 */
    });
  }
  /** 两个字段对比 相等就过 不相等返回 {equals:true} */
  equals(leaderCtrl) {
    const leader = this._equalsLeaderMap.forceGet(leaderCtrl);
    // pwdCtrl.val
    return follerCtrl => {
      leader.destControls.add(follerCtrl);
      if (leaderCtrl.value === follerCtrl.value) {
        return null;
      }
      return {
        equals: true
      };
    };
  }
  /** 是否包含空格 */
  whitespace(control) {
    const value = control.value;
    if (typeof value === 'string' && /\s/.test(value)) {
      return {
        whitespace: true
      };
    }
    return null;
  }
  /** required 变体, 左右两边不能包含空格 */
  trimRequired(control) {
    const value = control.value;
    if (typeof value === 'string' && value.trim().length === 0 || value == undefined) {
      return {
        trimRequired: true
      };
    }
    return null;
  }
}

/***/ }),

/***/ 47919:
/*!***************************************!*\
  !*** ./libs/bnf/controllers/index.ts ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   FormValidatorsController: () => (/* reexport safe */ _form_validators_controller__WEBPACK_IMPORTED_MODULE_0__.FormValidatorsController),
/* harmony export */   PageReturnController: () => (/* reexport safe */ _page_return_controller__WEBPACK_IMPORTED_MODULE_1__.PageReturnController)
/* harmony export */ });
/* harmony import */ var _form_validators_controller__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./form-validators.controller */ 11606);
/* harmony import */ var _page_return_controller__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./page-return.controller */ 62893);



/***/ }),

/***/ 62893:
/*!********************************************************!*\
  !*** ./libs/bnf/controllers/page-return.controller.ts ***!
  \********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   PageReturnController: () => (/* binding */ PageReturnController)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 54106);
/* harmony import */ var _bnqkl_util_web_decorator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @bnqkl/util-web/decorator */ 18112);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs */ 19177);



/**
 * 页面数据返回值的订阅功能
 * > Controller 必须在构造函数期间执行
 */
class PageReturnController {
  /** 继承日志 */
  get console() {
    return this.fromPage.console;
  }
  /**
   * 传入源页面与目标页面的构造函数，并通过订阅原页面的生命周期，来初始化对路由的订阅
   * 这里依赖 ion-router-outlet 来获取跳转过去的页面
   * 注：该监听返回是全触发（只要页面没被销毁掉不管页面是否处于激活状态）
   * @param specific 用于指定fromPage触发（需要手动指定），业务需要
   */
  constructor(fromPage, toPageCtor, specific = false) {
    this.fromPage = fromPage;
    /** 当前定阅过的页面 */
    this._toPages = new WeakSet();
    /**
     * 订阅到的返回内容，
     * 类型由对应页面的 returnValue$ 的定义决定
     */
    this.pageReturn$ = new rxjs__WEBPACK_IMPORTED_MODULE_1__.Subject();
    const {
      nav
    } = fromPage;
    fromPage.takeUntilDestroy(nav.pageActiveState$).subscribe(event => {
      /// 只监听新激活的页面
      if (event.type !== 'activate') {
        return;
      }
      const toPage = event.target;
      if (toPage instanceof toPageCtor &&
      // 去重
      this._toPages.has(toPage) === false) {
        if (toPage.returnValue$ === undefined) {
          return;
        }
        this._toPages.add(toPage);
        if (specific) {
          var _toPage$specificRetur;
          (_toPage$specificRetur = toPage.specificReturnPages) === null || _toPage$specificRetur === void 0 || _toPage$specificRetur.add(fromPage);
        }
        fromPage.takeUntilDestroy(toPage.returnValue$).subscribe({
          next: data => {
            /// 这里不用判断specific
            if (toPage.specificReturnPages && toPage.specificReturnPages.size) {
              /// 如果有写入，那么就只需要触发相对应页面就行
              toPage.specificReturnPages.has(fromPage) && this.pageReturn$.next(data);
              return;
            }
            this.pageReturn$.next(data);
          },
          complete: () => {
            var _toPage$specificRetur2;
            // 释放内存引用
            (_toPage$specificRetur2 = toPage.specificReturnPages) === null || _toPage$specificRetur2 === void 0 || _toPage$specificRetur2.delete(fromPage);
            return this._toPages.delete(toPage);
          }
        });
      }
    });
  }
}
(0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([_bnqkl_util_web_decorator__WEBPACK_IMPORTED_MODULE_0__.cacheGetter, (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__metadata)("design:type", Object), (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__metadata)("design:paramtypes", [])], PageReturnController.prototype, "console", null);

/***/ }),

/***/ 98467:
/*!*****************************************************************************!*\
  !*** ./node_modules/.pnpm/lodash@4.17.21/node_modules/lodash/_arrayEach.js ***!
  \*****************************************************************************/
/***/ ((module) => {

/**
 * A specialized version of `_.forEach` for arrays without support for
 * iteratee shorthands.
 *
 * @private
 * @param {Array} [array] The array to iterate over.
 * @param {Function} iteratee The function invoked per iteration.
 * @returns {Array} Returns `array`.
 */
function arrayEach(array, iteratee) {
  var index = -1,
    length = array == null ? 0 : array.length;
  while (++index < length) {
    if (iteratee(array[index], index, array) === false) {
      break;
    }
  }
  return array;
}
module.exports = arrayEach;

/***/ }),

/***/ 81884:
/*!*******************************************************************************!*\
  !*** ./node_modules/.pnpm/lodash@4.17.21/node_modules/lodash/_assignValue.js ***!
  \*******************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var baseAssignValue = __webpack_require__(/*! ./_baseAssignValue */ 86087),
  eq = __webpack_require__(/*! ./eq */ 13186);

/** Used for built-in method references. */
var objectProto = Object.prototype;

/** Used to check objects for own properties. */
var hasOwnProperty = objectProto.hasOwnProperty;

/**
 * Assigns `value` to `key` of `object` if the existing value is not equivalent
 * using [`SameValueZero`](http://ecma-international.org/ecma-262/7.0/#sec-samevaluezero)
 * for equality comparisons.
 *
 * @private
 * @param {Object} object The object to modify.
 * @param {string} key The key of the property to assign.
 * @param {*} value The value to assign.
 */
function assignValue(object, key, value) {
  var objValue = object[key];
  if (!(hasOwnProperty.call(object, key) && eq(objValue, value)) || value === undefined && !(key in object)) {
    baseAssignValue(object, key, value);
  }
}
module.exports = assignValue;

/***/ }),

/***/ 78907:
/*!******************************************************************************!*\
  !*** ./node_modules/.pnpm/lodash@4.17.21/node_modules/lodash/_baseAssign.js ***!
  \******************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var copyObject = __webpack_require__(/*! ./_copyObject */ 80706),
  keys = __webpack_require__(/*! ./keys */ 54558);

/**
 * The base implementation of `_.assign` without support for multiple sources
 * or `customizer` functions.
 *
 * @private
 * @param {Object} object The destination object.
 * @param {Object} source The source object.
 * @returns {Object} Returns `object`.
 */
function baseAssign(object, source) {
  return object && copyObject(source, keys(source), object);
}
module.exports = baseAssign;

/***/ }),

/***/ 86897:
/*!********************************************************************************!*\
  !*** ./node_modules/.pnpm/lodash@4.17.21/node_modules/lodash/_baseAssignIn.js ***!
  \********************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var copyObject = __webpack_require__(/*! ./_copyObject */ 80706),
  keysIn = __webpack_require__(/*! ./keysIn */ 28101);

/**
 * The base implementation of `_.assignIn` without support for multiple sources
 * or `customizer` functions.
 *
 * @private
 * @param {Object} object The destination object.
 * @param {Object} source The source object.
 * @returns {Object} Returns `object`.
 */
function baseAssignIn(object, source) {
  return object && copyObject(source, keysIn(source), object);
}
module.exports = baseAssignIn;

/***/ }),

/***/ 86087:
/*!***********************************************************************************!*\
  !*** ./node_modules/.pnpm/lodash@4.17.21/node_modules/lodash/_baseAssignValue.js ***!
  \***********************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var defineProperty = __webpack_require__(/*! ./_defineProperty */ 73488);

/**
 * The base implementation of `assignValue` and `assignMergeValue` without
 * value checks.
 *
 * @private
 * @param {Object} object The object to modify.
 * @param {string} key The key of the property to assign.
 * @param {*} value The value to assign.
 */
function baseAssignValue(object, key, value) {
  if (key == '__proto__' && defineProperty) {
    defineProperty(object, key, {
      'configurable': true,
      'enumerable': true,
      'value': value,
      'writable': true
    });
  } else {
    object[key] = value;
  }
}
module.exports = baseAssignValue;

/***/ }),

/***/ 17766:
/*!*****************************************************************************!*\
  !*** ./node_modules/.pnpm/lodash@4.17.21/node_modules/lodash/_baseClone.js ***!
  \*****************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var Stack = __webpack_require__(/*! ./_Stack */ 24854),
  arrayEach = __webpack_require__(/*! ./_arrayEach */ 98467),
  assignValue = __webpack_require__(/*! ./_assignValue */ 81884),
  baseAssign = __webpack_require__(/*! ./_baseAssign */ 78907),
  baseAssignIn = __webpack_require__(/*! ./_baseAssignIn */ 86897),
  cloneBuffer = __webpack_require__(/*! ./_cloneBuffer */ 88284),
  copyArray = __webpack_require__(/*! ./_copyArray */ 5517),
  copySymbols = __webpack_require__(/*! ./_copySymbols */ 36929),
  copySymbolsIn = __webpack_require__(/*! ./_copySymbolsIn */ 18229),
  getAllKeys = __webpack_require__(/*! ./_getAllKeys */ 82775),
  getAllKeysIn = __webpack_require__(/*! ./_getAllKeysIn */ 17839),
  getTag = __webpack_require__(/*! ./_getTag */ 68147),
  initCloneArray = __webpack_require__(/*! ./_initCloneArray */ 74567),
  initCloneByTag = __webpack_require__(/*! ./_initCloneByTag */ 86237),
  initCloneObject = __webpack_require__(/*! ./_initCloneObject */ 61052),
  isArray = __webpack_require__(/*! ./isArray */ 8264),
  isBuffer = __webpack_require__(/*! ./isBuffer */ 77873),
  isMap = __webpack_require__(/*! ./isMap */ 92785),
  isObject = __webpack_require__(/*! ./isObject */ 99964),
  isSet = __webpack_require__(/*! ./isSet */ 67925),
  keys = __webpack_require__(/*! ./keys */ 54558),
  keysIn = __webpack_require__(/*! ./keysIn */ 28101);

/** Used to compose bitmasks for cloning. */
var CLONE_DEEP_FLAG = 1,
  CLONE_FLAT_FLAG = 2,
  CLONE_SYMBOLS_FLAG = 4;

/** `Object#toString` result references. */
var argsTag = '[object Arguments]',
  arrayTag = '[object Array]',
  boolTag = '[object Boolean]',
  dateTag = '[object Date]',
  errorTag = '[object Error]',
  funcTag = '[object Function]',
  genTag = '[object GeneratorFunction]',
  mapTag = '[object Map]',
  numberTag = '[object Number]',
  objectTag = '[object Object]',
  regexpTag = '[object RegExp]',
  setTag = '[object Set]',
  stringTag = '[object String]',
  symbolTag = '[object Symbol]',
  weakMapTag = '[object WeakMap]';
var arrayBufferTag = '[object ArrayBuffer]',
  dataViewTag = '[object DataView]',
  float32Tag = '[object Float32Array]',
  float64Tag = '[object Float64Array]',
  int8Tag = '[object Int8Array]',
  int16Tag = '[object Int16Array]',
  int32Tag = '[object Int32Array]',
  uint8Tag = '[object Uint8Array]',
  uint8ClampedTag = '[object Uint8ClampedArray]',
  uint16Tag = '[object Uint16Array]',
  uint32Tag = '[object Uint32Array]';

/** Used to identify `toStringTag` values supported by `_.clone`. */
var cloneableTags = {};
cloneableTags[argsTag] = cloneableTags[arrayTag] = cloneableTags[arrayBufferTag] = cloneableTags[dataViewTag] = cloneableTags[boolTag] = cloneableTags[dateTag] = cloneableTags[float32Tag] = cloneableTags[float64Tag] = cloneableTags[int8Tag] = cloneableTags[int16Tag] = cloneableTags[int32Tag] = cloneableTags[mapTag] = cloneableTags[numberTag] = cloneableTags[objectTag] = cloneableTags[regexpTag] = cloneableTags[setTag] = cloneableTags[stringTag] = cloneableTags[symbolTag] = cloneableTags[uint8Tag] = cloneableTags[uint8ClampedTag] = cloneableTags[uint16Tag] = cloneableTags[uint32Tag] = true;
cloneableTags[errorTag] = cloneableTags[funcTag] = cloneableTags[weakMapTag] = false;

/**
 * The base implementation of `_.clone` and `_.cloneDeep` which tracks
 * traversed objects.
 *
 * @private
 * @param {*} value The value to clone.
 * @param {boolean} bitmask The bitmask flags.
 *  1 - Deep clone
 *  2 - Flatten inherited properties
 *  4 - Clone symbols
 * @param {Function} [customizer] The function to customize cloning.
 * @param {string} [key] The key of `value`.
 * @param {Object} [object] The parent object of `value`.
 * @param {Object} [stack] Tracks traversed objects and their clone counterparts.
 * @returns {*} Returns the cloned value.
 */
function baseClone(value, bitmask, customizer, key, object, stack) {
  var result,
    isDeep = bitmask & CLONE_DEEP_FLAG,
    isFlat = bitmask & CLONE_FLAT_FLAG,
    isFull = bitmask & CLONE_SYMBOLS_FLAG;
  if (customizer) {
    result = object ? customizer(value, key, object, stack) : customizer(value);
  }
  if (result !== undefined) {
    return result;
  }
  if (!isObject(value)) {
    return value;
  }
  var isArr = isArray(value);
  if (isArr) {
    result = initCloneArray(value);
    if (!isDeep) {
      return copyArray(value, result);
    }
  } else {
    var tag = getTag(value),
      isFunc = tag == funcTag || tag == genTag;
    if (isBuffer(value)) {
      return cloneBuffer(value, isDeep);
    }
    if (tag == objectTag || tag == argsTag || isFunc && !object) {
      result = isFlat || isFunc ? {} : initCloneObject(value);
      if (!isDeep) {
        return isFlat ? copySymbolsIn(value, baseAssignIn(result, value)) : copySymbols(value, baseAssign(result, value));
      }
    } else {
      if (!cloneableTags[tag]) {
        return object ? value : {};
      }
      result = initCloneByTag(value, tag, isDeep);
    }
  }
  // Check for circular references and return its corresponding clone.
  stack || (stack = new Stack());
  var stacked = stack.get(value);
  if (stacked) {
    return stacked;
  }
  stack.set(value, result);
  if (isSet(value)) {
    value.forEach(function (subValue) {
      result.add(baseClone(subValue, bitmask, customizer, subValue, value, stack));
    });
  } else if (isMap(value)) {
    value.forEach(function (subValue, key) {
      result.set(key, baseClone(subValue, bitmask, customizer, key, value, stack));
    });
  }
  var keysFunc = isFull ? isFlat ? getAllKeysIn : getAllKeys : isFlat ? keysIn : keys;
  var props = isArr ? undefined : keysFunc(value);
  arrayEach(props || value, function (subValue, key) {
    if (props) {
      key = subValue;
      subValue = value[key];
    }
    // Recursively populate clone (susceptible to call stack limits).
    assignValue(result, key, baseClone(subValue, bitmask, customizer, key, value, stack));
  });
  return result;
}
module.exports = baseClone;

/***/ }),

/***/ 42250:
/*!******************************************************************************!*\
  !*** ./node_modules/.pnpm/lodash@4.17.21/node_modules/lodash/_baseCreate.js ***!
  \******************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var isObject = __webpack_require__(/*! ./isObject */ 99964);

/** Built-in value references. */
var objectCreate = Object.create;

/**
 * The base implementation of `_.create` without support for assigning
 * properties to the created object.
 *
 * @private
 * @param {Object} proto The object to inherit from.
 * @returns {Object} Returns the new object.
 */
var baseCreate = function () {
  function object() {}
  return function (proto) {
    if (!isObject(proto)) {
      return {};
    }
    if (objectCreate) {
      return objectCreate(proto);
    }
    object.prototype = proto;
    var result = new object();
    object.prototype = undefined;
    return result;
  };
}();
module.exports = baseCreate;

/***/ }),

/***/ 7308:
/*!*****************************************************************************!*\
  !*** ./node_modules/.pnpm/lodash@4.17.21/node_modules/lodash/_baseIsMap.js ***!
  \*****************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var getTag = __webpack_require__(/*! ./_getTag */ 68147),
  isObjectLike = __webpack_require__(/*! ./isObjectLike */ 72933);

/** `Object#toString` result references. */
var mapTag = '[object Map]';

/**
 * The base implementation of `_.isMap` without Node.js optimizations.
 *
 * @private
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is a map, else `false`.
 */
function baseIsMap(value) {
  return isObjectLike(value) && getTag(value) == mapTag;
}
module.exports = baseIsMap;

/***/ }),

/***/ 91107:
/*!*****************************************************************************!*\
  !*** ./node_modules/.pnpm/lodash@4.17.21/node_modules/lodash/_baseIsSet.js ***!
  \*****************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var getTag = __webpack_require__(/*! ./_getTag */ 68147),
  isObjectLike = __webpack_require__(/*! ./isObjectLike */ 72933);

/** `Object#toString` result references. */
var setTag = '[object Set]';

/**
 * The base implementation of `_.isSet` without Node.js optimizations.
 *
 * @private
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is a set, else `false`.
 */
function baseIsSet(value) {
  return isObjectLike(value) && getTag(value) == setTag;
}
module.exports = baseIsSet;

/***/ }),

/***/ 74320:
/*!******************************************************************************!*\
  !*** ./node_modules/.pnpm/lodash@4.17.21/node_modules/lodash/_baseKeysIn.js ***!
  \******************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var isObject = __webpack_require__(/*! ./isObject */ 99964),
  isPrototype = __webpack_require__(/*! ./_isPrototype */ 79253),
  nativeKeysIn = __webpack_require__(/*! ./_nativeKeysIn */ 60567);

/** Used for built-in method references. */
var objectProto = Object.prototype;

/** Used to check objects for own properties. */
var hasOwnProperty = objectProto.hasOwnProperty;

/**
 * The base implementation of `_.keysIn` which doesn't treat sparse arrays as dense.
 *
 * @private
 * @param {Object} object The object to query.
 * @returns {Array} Returns the array of property names.
 */
function baseKeysIn(object) {
  if (!isObject(object)) {
    return nativeKeysIn(object);
  }
  var isProto = isPrototype(object),
    result = [];
  for (var key in object) {
    if (!(key == 'constructor' && (isProto || !hasOwnProperty.call(object, key)))) {
      result.push(key);
    }
  }
  return result;
}
module.exports = baseKeysIn;

/***/ }),

/***/ 21588:
/*!************************************************************************************!*\
  !*** ./node_modules/.pnpm/lodash@4.17.21/node_modules/lodash/_cloneArrayBuffer.js ***!
  \************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var Uint8Array = __webpack_require__(/*! ./_Uint8Array */ 48339);

/**
 * Creates a clone of `arrayBuffer`.
 *
 * @private
 * @param {ArrayBuffer} arrayBuffer The array buffer to clone.
 * @returns {ArrayBuffer} Returns the cloned array buffer.
 */
function cloneArrayBuffer(arrayBuffer) {
  var result = new arrayBuffer.constructor(arrayBuffer.byteLength);
  new Uint8Array(result).set(new Uint8Array(arrayBuffer));
  return result;
}
module.exports = cloneArrayBuffer;

/***/ }),

/***/ 88284:
/*!*******************************************************************************!*\
  !*** ./node_modules/.pnpm/lodash@4.17.21/node_modules/lodash/_cloneBuffer.js ***!
  \*******************************************************************************/
/***/ ((module, exports, __webpack_require__) => {

/* module decorator */ module = __webpack_require__.nmd(module);
var root = __webpack_require__(/*! ./_root */ 16293);

/** Detect free variable `exports`. */
var freeExports =  true && exports && !exports.nodeType && exports;

/** Detect free variable `module`. */
var freeModule = freeExports && "object" == 'object' && module && !module.nodeType && module;

/** Detect the popular CommonJS extension `module.exports`. */
var moduleExports = freeModule && freeModule.exports === freeExports;

/** Built-in value references. */
var Buffer = moduleExports ? root.Buffer : undefined,
  allocUnsafe = Buffer ? Buffer.allocUnsafe : undefined;

/**
 * Creates a clone of  `buffer`.
 *
 * @private
 * @param {Buffer} buffer The buffer to clone.
 * @param {boolean} [isDeep] Specify a deep clone.
 * @returns {Buffer} Returns the cloned buffer.
 */
function cloneBuffer(buffer, isDeep) {
  if (isDeep) {
    return buffer.slice();
  }
  var length = buffer.length,
    result = allocUnsafe ? allocUnsafe(length) : new buffer.constructor(length);
  buffer.copy(result);
  return result;
}
module.exports = cloneBuffer;

/***/ }),

/***/ 82171:
/*!*********************************************************************************!*\
  !*** ./node_modules/.pnpm/lodash@4.17.21/node_modules/lodash/_cloneDataView.js ***!
  \*********************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var cloneArrayBuffer = __webpack_require__(/*! ./_cloneArrayBuffer */ 21588);

/**
 * Creates a clone of `dataView`.
 *
 * @private
 * @param {Object} dataView The data view to clone.
 * @param {boolean} [isDeep] Specify a deep clone.
 * @returns {Object} Returns the cloned data view.
 */
function cloneDataView(dataView, isDeep) {
  var buffer = isDeep ? cloneArrayBuffer(dataView.buffer) : dataView.buffer;
  return new dataView.constructor(buffer, dataView.byteOffset, dataView.byteLength);
}
module.exports = cloneDataView;

/***/ }),

/***/ 57503:
/*!*******************************************************************************!*\
  !*** ./node_modules/.pnpm/lodash@4.17.21/node_modules/lodash/_cloneRegExp.js ***!
  \*******************************************************************************/
/***/ ((module) => {

/** Used to match `RegExp` flags from their coerced string values. */
var reFlags = /\w*$/;

/**
 * Creates a clone of `regexp`.
 *
 * @private
 * @param {Object} regexp The regexp to clone.
 * @returns {Object} Returns the cloned regexp.
 */
function cloneRegExp(regexp) {
  var result = new regexp.constructor(regexp.source, reFlags.exec(regexp));
  result.lastIndex = regexp.lastIndex;
  return result;
}
module.exports = cloneRegExp;

/***/ }),

/***/ 44578:
/*!*******************************************************************************!*\
  !*** ./node_modules/.pnpm/lodash@4.17.21/node_modules/lodash/_cloneSymbol.js ***!
  \*******************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var Symbol = __webpack_require__(/*! ./_Symbol */ 19621);

/** Used to convert symbols to primitives and strings. */
var symbolProto = Symbol ? Symbol.prototype : undefined,
  symbolValueOf = symbolProto ? symbolProto.valueOf : undefined;

/**
 * Creates a clone of the `symbol` object.
 *
 * @private
 * @param {Object} symbol The symbol object to clone.
 * @returns {Object} Returns the cloned symbol object.
 */
function cloneSymbol(symbol) {
  return symbolValueOf ? Object(symbolValueOf.call(symbol)) : {};
}
module.exports = cloneSymbol;

/***/ }),

/***/ 41881:
/*!***********************************************************************************!*\
  !*** ./node_modules/.pnpm/lodash@4.17.21/node_modules/lodash/_cloneTypedArray.js ***!
  \***********************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var cloneArrayBuffer = __webpack_require__(/*! ./_cloneArrayBuffer */ 21588);

/**
 * Creates a clone of `typedArray`.
 *
 * @private
 * @param {Object} typedArray The typed array to clone.
 * @param {boolean} [isDeep] Specify a deep clone.
 * @returns {Object} Returns the cloned typed array.
 */
function cloneTypedArray(typedArray, isDeep) {
  var buffer = isDeep ? cloneArrayBuffer(typedArray.buffer) : typedArray.buffer;
  return new typedArray.constructor(buffer, typedArray.byteOffset, typedArray.length);
}
module.exports = cloneTypedArray;

/***/ }),

/***/ 5517:
/*!*****************************************************************************!*\
  !*** ./node_modules/.pnpm/lodash@4.17.21/node_modules/lodash/_copyArray.js ***!
  \*****************************************************************************/
/***/ ((module) => {

/**
 * Copies the values of `source` to `array`.
 *
 * @private
 * @param {Array} source The array to copy values from.
 * @param {Array} [array=[]] The array to copy values to.
 * @returns {Array} Returns `array`.
 */
function copyArray(source, array) {
  var index = -1,
    length = source.length;
  array || (array = Array(length));
  while (++index < length) {
    array[index] = source[index];
  }
  return array;
}
module.exports = copyArray;

/***/ }),

/***/ 80706:
/*!******************************************************************************!*\
  !*** ./node_modules/.pnpm/lodash@4.17.21/node_modules/lodash/_copyObject.js ***!
  \******************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var assignValue = __webpack_require__(/*! ./_assignValue */ 81884),
  baseAssignValue = __webpack_require__(/*! ./_baseAssignValue */ 86087);

/**
 * Copies properties of `source` to `object`.
 *
 * @private
 * @param {Object} source The object to copy properties from.
 * @param {Array} props The property identifiers to copy.
 * @param {Object} [object={}] The object to copy properties to.
 * @param {Function} [customizer] The function to customize copied values.
 * @returns {Object} Returns `object`.
 */
function copyObject(source, props, object, customizer) {
  var isNew = !object;
  object || (object = {});
  var index = -1,
    length = props.length;
  while (++index < length) {
    var key = props[index];
    var newValue = customizer ? customizer(object[key], source[key], key, object, source) : undefined;
    if (newValue === undefined) {
      newValue = source[key];
    }
    if (isNew) {
      baseAssignValue(object, key, newValue);
    } else {
      assignValue(object, key, newValue);
    }
  }
  return object;
}
module.exports = copyObject;

/***/ }),

/***/ 36929:
/*!*******************************************************************************!*\
  !*** ./node_modules/.pnpm/lodash@4.17.21/node_modules/lodash/_copySymbols.js ***!
  \*******************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var copyObject = __webpack_require__(/*! ./_copyObject */ 80706),
  getSymbols = __webpack_require__(/*! ./_getSymbols */ 29423);

/**
 * Copies own symbols of `source` to `object`.
 *
 * @private
 * @param {Object} source The object to copy symbols from.
 * @param {Object} [object={}] The object to copy symbols to.
 * @returns {Object} Returns `object`.
 */
function copySymbols(source, object) {
  return copyObject(source, getSymbols(source), object);
}
module.exports = copySymbols;

/***/ }),

/***/ 18229:
/*!*********************************************************************************!*\
  !*** ./node_modules/.pnpm/lodash@4.17.21/node_modules/lodash/_copySymbolsIn.js ***!
  \*********************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var copyObject = __webpack_require__(/*! ./_copyObject */ 80706),
  getSymbolsIn = __webpack_require__(/*! ./_getSymbolsIn */ 77842);

/**
 * Copies own and inherited symbols of `source` to `object`.
 *
 * @private
 * @param {Object} source The object to copy symbols from.
 * @param {Object} [object={}] The object to copy symbols to.
 * @returns {Object} Returns `object`.
 */
function copySymbolsIn(source, object) {
  return copyObject(source, getSymbolsIn(source), object);
}
module.exports = copySymbolsIn;

/***/ }),

/***/ 17839:
/*!********************************************************************************!*\
  !*** ./node_modules/.pnpm/lodash@4.17.21/node_modules/lodash/_getAllKeysIn.js ***!
  \********************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var baseGetAllKeys = __webpack_require__(/*! ./_baseGetAllKeys */ 96609),
  getSymbolsIn = __webpack_require__(/*! ./_getSymbolsIn */ 77842),
  keysIn = __webpack_require__(/*! ./keysIn */ 28101);

/**
 * Creates an array of own and inherited enumerable property names and
 * symbols of `object`.
 *
 * @private
 * @param {Object} object The object to query.
 * @returns {Array} Returns the array of property names and symbols.
 */
function getAllKeysIn(object) {
  return baseGetAllKeys(object, keysIn, getSymbolsIn);
}
module.exports = getAllKeysIn;

/***/ }),

/***/ 38710:
/*!********************************************************************************!*\
  !*** ./node_modules/.pnpm/lodash@4.17.21/node_modules/lodash/_getPrototype.js ***!
  \********************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var overArg = __webpack_require__(/*! ./_overArg */ 86478);

/** Built-in value references. */
var getPrototype = overArg(Object.getPrototypeOf, Object);
module.exports = getPrototype;

/***/ }),

/***/ 77842:
/*!********************************************************************************!*\
  !*** ./node_modules/.pnpm/lodash@4.17.21/node_modules/lodash/_getSymbolsIn.js ***!
  \********************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var arrayPush = __webpack_require__(/*! ./_arrayPush */ 8937),
  getPrototype = __webpack_require__(/*! ./_getPrototype */ 38710),
  getSymbols = __webpack_require__(/*! ./_getSymbols */ 29423),
  stubArray = __webpack_require__(/*! ./stubArray */ 32538);

/* Built-in method references for those with the same name as other `lodash` methods. */
var nativeGetSymbols = Object.getOwnPropertySymbols;

/**
 * Creates an array of the own and inherited enumerable symbols of `object`.
 *
 * @private
 * @param {Object} object The object to query.
 * @returns {Array} Returns the array of symbols.
 */
var getSymbolsIn = !nativeGetSymbols ? stubArray : function (object) {
  var result = [];
  while (object) {
    arrayPush(result, getSymbols(object));
    object = getPrototype(object);
  }
  return result;
};
module.exports = getSymbolsIn;

/***/ }),

/***/ 74567:
/*!**********************************************************************************!*\
  !*** ./node_modules/.pnpm/lodash@4.17.21/node_modules/lodash/_initCloneArray.js ***!
  \**********************************************************************************/
/***/ ((module) => {

/** Used for built-in method references. */
var objectProto = Object.prototype;

/** Used to check objects for own properties. */
var hasOwnProperty = objectProto.hasOwnProperty;

/**
 * Initializes an array clone.
 *
 * @private
 * @param {Array} array The array to clone.
 * @returns {Array} Returns the initialized clone.
 */
function initCloneArray(array) {
  var length = array.length,
    result = new array.constructor(length);

  // Add properties assigned by `RegExp#exec`.
  if (length && typeof array[0] == 'string' && hasOwnProperty.call(array, 'index')) {
    result.index = array.index;
    result.input = array.input;
  }
  return result;
}
module.exports = initCloneArray;

/***/ }),

/***/ 86237:
/*!**********************************************************************************!*\
  !*** ./node_modules/.pnpm/lodash@4.17.21/node_modules/lodash/_initCloneByTag.js ***!
  \**********************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var cloneArrayBuffer = __webpack_require__(/*! ./_cloneArrayBuffer */ 21588),
  cloneDataView = __webpack_require__(/*! ./_cloneDataView */ 82171),
  cloneRegExp = __webpack_require__(/*! ./_cloneRegExp */ 57503),
  cloneSymbol = __webpack_require__(/*! ./_cloneSymbol */ 44578),
  cloneTypedArray = __webpack_require__(/*! ./_cloneTypedArray */ 41881);

/** `Object#toString` result references. */
var boolTag = '[object Boolean]',
  dateTag = '[object Date]',
  mapTag = '[object Map]',
  numberTag = '[object Number]',
  regexpTag = '[object RegExp]',
  setTag = '[object Set]',
  stringTag = '[object String]',
  symbolTag = '[object Symbol]';
var arrayBufferTag = '[object ArrayBuffer]',
  dataViewTag = '[object DataView]',
  float32Tag = '[object Float32Array]',
  float64Tag = '[object Float64Array]',
  int8Tag = '[object Int8Array]',
  int16Tag = '[object Int16Array]',
  int32Tag = '[object Int32Array]',
  uint8Tag = '[object Uint8Array]',
  uint8ClampedTag = '[object Uint8ClampedArray]',
  uint16Tag = '[object Uint16Array]',
  uint32Tag = '[object Uint32Array]';

/**
 * Initializes an object clone based on its `toStringTag`.
 *
 * **Note:** This function only supports cloning values with tags of
 * `Boolean`, `Date`, `Error`, `Map`, `Number`, `RegExp`, `Set`, or `String`.
 *
 * @private
 * @param {Object} object The object to clone.
 * @param {string} tag The `toStringTag` of the object to clone.
 * @param {boolean} [isDeep] Specify a deep clone.
 * @returns {Object} Returns the initialized clone.
 */
function initCloneByTag(object, tag, isDeep) {
  var Ctor = object.constructor;
  switch (tag) {
    case arrayBufferTag:
      return cloneArrayBuffer(object);
    case boolTag:
    case dateTag:
      return new Ctor(+object);
    case dataViewTag:
      return cloneDataView(object, isDeep);
    case float32Tag:
    case float64Tag:
    case int8Tag:
    case int16Tag:
    case int32Tag:
    case uint8Tag:
    case uint8ClampedTag:
    case uint16Tag:
    case uint32Tag:
      return cloneTypedArray(object, isDeep);
    case mapTag:
      return new Ctor();
    case numberTag:
    case stringTag:
      return new Ctor(object);
    case regexpTag:
      return cloneRegExp(object);
    case setTag:
      return new Ctor();
    case symbolTag:
      return cloneSymbol(object);
  }
}
module.exports = initCloneByTag;

/***/ }),

/***/ 61052:
/*!***********************************************************************************!*\
  !*** ./node_modules/.pnpm/lodash@4.17.21/node_modules/lodash/_initCloneObject.js ***!
  \***********************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var baseCreate = __webpack_require__(/*! ./_baseCreate */ 42250),
  getPrototype = __webpack_require__(/*! ./_getPrototype */ 38710),
  isPrototype = __webpack_require__(/*! ./_isPrototype */ 79253);

/**
 * Initializes an object clone.
 *
 * @private
 * @param {Object} object The object to clone.
 * @returns {Object} Returns the initialized clone.
 */
function initCloneObject(object) {
  return typeof object.constructor == 'function' && !isPrototype(object) ? baseCreate(getPrototype(object)) : {};
}
module.exports = initCloneObject;

/***/ }),

/***/ 60567:
/*!********************************************************************************!*\
  !*** ./node_modules/.pnpm/lodash@4.17.21/node_modules/lodash/_nativeKeysIn.js ***!
  \********************************************************************************/
/***/ ((module) => {

/**
 * This function is like
 * [`Object.keys`](http://ecma-international.org/ecma-262/7.0/#sec-object.keys)
 * except that it includes inherited enumerable properties.
 *
 * @private
 * @param {Object} object The object to query.
 * @returns {Array} Returns the array of property names.
 */
function nativeKeysIn(object) {
  var result = [];
  if (object != null) {
    for (var key in Object(object)) {
      result.push(key);
    }
  }
  return result;
}
module.exports = nativeKeysIn;

/***/ }),

/***/ 14405:
/*!****************************************************************************!*\
  !*** ./node_modules/.pnpm/lodash@4.17.21/node_modules/lodash/cloneDeep.js ***!
  \****************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var baseClone = __webpack_require__(/*! ./_baseClone */ 17766);

/** Used to compose bitmasks for cloning. */
var CLONE_DEEP_FLAG = 1,
  CLONE_SYMBOLS_FLAG = 4;

/**
 * This method is like `_.clone` except that it recursively clones `value`.
 *
 * @static
 * @memberOf _
 * @since 1.0.0
 * @category Lang
 * @param {*} value The value to recursively clone.
 * @returns {*} Returns the deep cloned value.
 * @see _.clone
 * @example
 *
 * var objects = [{ 'a': 1 }, { 'b': 2 }];
 *
 * var deep = _.cloneDeep(objects);
 * console.log(deep[0] === objects[0]);
 * // => false
 */
function cloneDeep(value) {
  return baseClone(value, CLONE_DEEP_FLAG | CLONE_SYMBOLS_FLAG);
}
module.exports = cloneDeep;

/***/ }),

/***/ 92785:
/*!************************************************************************!*\
  !*** ./node_modules/.pnpm/lodash@4.17.21/node_modules/lodash/isMap.js ***!
  \************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var baseIsMap = __webpack_require__(/*! ./_baseIsMap */ 7308),
  baseUnary = __webpack_require__(/*! ./_baseUnary */ 22981),
  nodeUtil = __webpack_require__(/*! ./_nodeUtil */ 56801);

/* Node.js helper references. */
var nodeIsMap = nodeUtil && nodeUtil.isMap;

/**
 * Checks if `value` is classified as a `Map` object.
 *
 * @static
 * @memberOf _
 * @since 4.3.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is a map, else `false`.
 * @example
 *
 * _.isMap(new Map);
 * // => true
 *
 * _.isMap(new WeakMap);
 * // => false
 */
var isMap = nodeIsMap ? baseUnary(nodeIsMap) : baseIsMap;
module.exports = isMap;

/***/ }),

/***/ 67925:
/*!************************************************************************!*\
  !*** ./node_modules/.pnpm/lodash@4.17.21/node_modules/lodash/isSet.js ***!
  \************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var baseIsSet = __webpack_require__(/*! ./_baseIsSet */ 91107),
  baseUnary = __webpack_require__(/*! ./_baseUnary */ 22981),
  nodeUtil = __webpack_require__(/*! ./_nodeUtil */ 56801);

/* Node.js helper references. */
var nodeIsSet = nodeUtil && nodeUtil.isSet;

/**
 * Checks if `value` is classified as a `Set` object.
 *
 * @static
 * @memberOf _
 * @since 4.3.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is a set, else `false`.
 * @example
 *
 * _.isSet(new Set);
 * // => true
 *
 * _.isSet(new WeakSet);
 * // => false
 */
var isSet = nodeIsSet ? baseUnary(nodeIsSet) : baseIsSet;
module.exports = isSet;

/***/ }),

/***/ 28101:
/*!*************************************************************************!*\
  !*** ./node_modules/.pnpm/lodash@4.17.21/node_modules/lodash/keysIn.js ***!
  \*************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var arrayLikeKeys = __webpack_require__(/*! ./_arrayLikeKeys */ 56928),
  baseKeysIn = __webpack_require__(/*! ./_baseKeysIn */ 74320),
  isArrayLike = __webpack_require__(/*! ./isArrayLike */ 14256);

/**
 * Creates an array of the own and inherited enumerable property names of `object`.
 *
 * **Note:** Non-object values are coerced to objects.
 *
 * @static
 * @memberOf _
 * @since 3.0.0
 * @category Object
 * @param {Object} object The object to query.
 * @returns {Array} Returns the array of property names.
 * @example
 *
 * function Foo() {
 *   this.a = 1;
 *   this.b = 2;
 * }
 *
 * Foo.prototype.c = 3;
 *
 * _.keysIn(new Foo);
 * // => ['a', 'b', 'c'] (iteration order is not guaranteed)
 */
function keysIn(object) {
  return isArrayLike(object) ? arrayLikeKeys(object, true) : baseKeysIn(object);
}
module.exports = keysIn;

/***/ }),

/***/ 83402:
/*!********************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/.pnpm/@angular+material@17.0.1_@angular+animations@17.0.4_@angular+cdk@17.0.1_@angular+common@17.0._hy563qbtslkxwdplpakghctooa/node_modules/@angular/material/fesm2022/slider.mjs ***!
  \********************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   MatSlider: () => (/* binding */ MatSlider),
/* harmony export */   MatSliderChange: () => (/* binding */ MatSliderChange),
/* harmony export */   MatSliderModule: () => (/* binding */ MatSliderModule),
/* harmony export */   MatSliderRangeThumb: () => (/* binding */ MatSliderRangeThumb),
/* harmony export */   MatSliderThumb: () => (/* binding */ MatSliderThumb),
/* harmony export */   MatSliderVisualThumb: () => (/* binding */ MatSliderVisualThumb)
/* harmony export */ });
/* harmony import */ var _angular_cdk_bidi__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/cdk/bidi */ 80779);
/* harmony import */ var _angular_cdk_coercion__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/cdk/coercion */ 40559);
/* harmony import */ var _angular_cdk_platform__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/cdk/platform */ 10181);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/platform-browser/animations */ 61039);
/* harmony import */ var _angular_material_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/material/core */ 95906);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 7820);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs */ 19177);
var _class, _class2, _class3, _class4, _class5;











/**
 * Injection token that can be used for a `MatSlider` to provide itself as a
 * parent to the `MatSliderThumb` and `MatSliderRangeThumb`.
 * Used primarily to avoid circular imports.
 * @docs-private
 */
const _c0 = ["knob"];
const _c1 = ["valueIndicatorContainer"];
function _class_Conditional_0_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 4, 5)(2, "div", 6)(3, "span", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](ctx_r0.valueIndicatorText);
  }
}
const _c2 = ["trackActive"];
function _class2_Conditional_6_Conditional_2_For_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "div");
  }
  if (rf & 2) {
    const tickMark_r6 = ctx.$implicit;
    const i_r7 = ctx.$index;
    const ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵclassMap"](tickMark_r6 === 0 ? "mdc-slider__tick-mark--active" : "mdc-slider__tick-mark--inactive");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵstyleProp"]("transform", ctx_r5._calcTickMarkTransform(i_r7));
  }
}
function _class2_Conditional_6_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrepeaterCreate"](0, _class2_Conditional_6_Conditional_2_For_1_Template, 1, 4, "div", 9, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrepeaterTrackByIdentity"]);
  }
  if (rf & 2) {
    const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrepeater"](ctx_r4._tickMarks);
  }
}
function _class2_Conditional_6_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 7, 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](2, _class2_Conditional_6_Conditional_2_Template, 2, 0);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵconditional"](2, ctx_r1._cachedWidth ? 2 : -1);
  }
}
function _class2_Conditional_7_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "mat-slider-visual-thumb", 6);
  }
  if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("discrete", ctx_r2.discrete)("thumbPosition", 1)("valueIndicatorText", ctx_r2.startValueIndicatorText);
  }
}
const _c3 = ["*"];
const MAT_SLIDER = new _angular_core__WEBPACK_IMPORTED_MODULE_0__.InjectionToken('_MatSlider');
/**
 * Injection token that can be used to query for a `MatSliderThumb`.
 * Used primarily to avoid circular imports.
 * @docs-private
 */
const MAT_SLIDER_THUMB = new _angular_core__WEBPACK_IMPORTED_MODULE_0__.InjectionToken('_MatSliderThumb');
/**
 * Injection token that can be used to query for a `MatSliderRangeThumb`.
 * Used primarily to avoid circular imports.
 * @docs-private
 */
const MAT_SLIDER_RANGE_THUMB = new _angular_core__WEBPACK_IMPORTED_MODULE_0__.InjectionToken('_MatSliderRangeThumb');
/**
 * Injection token that can be used to query for a `MatSliderVisualThumb`.
 * Used primarily to avoid circular imports.
 * @docs-private
 */
const MAT_SLIDER_VISUAL_THUMB = new _angular_core__WEBPACK_IMPORTED_MODULE_0__.InjectionToken('_MatSliderVisualThumb');
/**
 * A simple change event emitted by the MatSlider component.
 * @deprecated Use event bindings directly on the MatSliderThumbs for `change` and `input` events. See https://material.angular.io/guide/mdc-migration for information about migrating.
 * @breaking-change 17.0.0
 */
class MatSliderChange {}

/**
 * The visual slider thumb.
 *
 * Handles the slider thumb ripple states (hover, focus, and active),
 * and displaying the value tooltip on discrete sliders.
 * @docs-private
 */
class MatSliderVisualThumb {
  constructor(_cdr, _ngZone, _elementRef, _slider) {
    this._cdr = _cdr;
    this._ngZone = _ngZone;
    this._slider = _slider;
    /** Whether the slider thumb is currently being hovered. */
    this._isHovered = false;
    /** Whether the slider thumb is currently being pressed. */
    this._isActive = false;
    /** Whether the value indicator tooltip is visible. */
    this._isValueIndicatorVisible = false;
    this._onPointerMove = event => {
      if (this._sliderInput._isFocused) {
        return;
      }
      const rect = this._hostElement.getBoundingClientRect();
      const isHovered = this._slider._isCursorOnSliderThumb(event, rect);
      this._isHovered = isHovered;
      if (isHovered) {
        this._showHoverRipple();
      } else {
        this._hideRipple(this._hoverRippleRef);
      }
    };
    this._onMouseLeave = () => {
      this._isHovered = false;
      this._hideRipple(this._hoverRippleRef);
    };
    this._onFocus = () => {
      // We don't want to show the hover ripple on top of the focus ripple.
      // Happen when the users cursor is over a thumb and then the user tabs to it.
      this._hideRipple(this._hoverRippleRef);
      this._showFocusRipple();
      this._hostElement.classList.add('mdc-slider__thumb--focused');
    };
    this._onBlur = () => {
      // Happens when the user tabs away while still dragging a thumb.
      if (!this._isActive) {
        this._hideRipple(this._focusRippleRef);
      }
      // Happens when the user tabs away from a thumb but their cursor is still over it.
      if (this._isHovered) {
        this._showHoverRipple();
      }
      this._hostElement.classList.remove('mdc-slider__thumb--focused');
    };
    this._onDragStart = event => {
      if (event.button !== 0) {
        return;
      }
      this._isActive = true;
      this._showActiveRipple();
    };
    this._onDragEnd = () => {
      this._isActive = false;
      this._hideRipple(this._activeRippleRef);
      // Happens when the user starts dragging a thumb, tabs away, and then stops dragging.
      if (!this._sliderInput._isFocused) {
        this._hideRipple(this._focusRippleRef);
      }
    };
    this._hostElement = _elementRef.nativeElement;
  }
  ngAfterViewInit() {
    this._ripple.radius = 24;
    this._sliderInput = this._slider._getInput(this.thumbPosition);
    this._sliderInputEl = this._sliderInput._hostElement;
    const input = this._sliderInputEl;
    // These listeners don't update any data bindings so we bind them outside
    // of the NgZone to prevent Angular from needlessly running change detection.
    this._ngZone.runOutsideAngular(() => {
      input.addEventListener('pointermove', this._onPointerMove);
      input.addEventListener('pointerdown', this._onDragStart);
      input.addEventListener('pointerup', this._onDragEnd);
      input.addEventListener('pointerleave', this._onMouseLeave);
      input.addEventListener('focus', this._onFocus);
      input.addEventListener('blur', this._onBlur);
    });
  }
  ngOnDestroy() {
    const input = this._sliderInputEl;
    input.removeEventListener('pointermove', this._onPointerMove);
    input.removeEventListener('pointerdown', this._onDragStart);
    input.removeEventListener('pointerup', this._onDragEnd);
    input.removeEventListener('pointerleave', this._onMouseLeave);
    input.removeEventListener('focus', this._onFocus);
    input.removeEventListener('blur', this._onBlur);
  }
  /** Handles displaying the hover ripple. */
  _showHoverRipple() {
    if (!this._isShowingRipple(this._hoverRippleRef)) {
      var _this$_hoverRippleRef;
      this._hoverRippleRef = this._showRipple({
        enterDuration: 0,
        exitDuration: 0
      });
      (_this$_hoverRippleRef = this._hoverRippleRef) === null || _this$_hoverRippleRef === void 0 || _this$_hoverRippleRef.element.classList.add('mat-mdc-slider-hover-ripple');
    }
  }
  /** Handles displaying the focus ripple. */
  _showFocusRipple() {
    // Show the focus ripple event if noop animations are enabled.
    if (!this._isShowingRipple(this._focusRippleRef)) {
      var _this$_focusRippleRef;
      this._focusRippleRef = this._showRipple({
        enterDuration: 0,
        exitDuration: 0
      }, true);
      (_this$_focusRippleRef = this._focusRippleRef) === null || _this$_focusRippleRef === void 0 || _this$_focusRippleRef.element.classList.add('mat-mdc-slider-focus-ripple');
    }
  }
  /** Handles displaying the active ripple. */
  _showActiveRipple() {
    if (!this._isShowingRipple(this._activeRippleRef)) {
      var _this$_activeRippleRe;
      this._activeRippleRef = this._showRipple({
        enterDuration: 225,
        exitDuration: 400
      });
      (_this$_activeRippleRe = this._activeRippleRef) === null || _this$_activeRippleRe === void 0 || _this$_activeRippleRe.element.classList.add('mat-mdc-slider-active-ripple');
    }
  }
  /** Whether the given rippleRef is currently fading in or visible. */
  _isShowingRipple(rippleRef) {
    return (rippleRef === null || rippleRef === void 0 ? void 0 : rippleRef.state) === 0 /* RippleState.FADING_IN */ || (rippleRef === null || rippleRef === void 0 ? void 0 : rippleRef.state) === 1 /* RippleState.VISIBLE */;
  }
  /** Manually launches the slider thumb ripple using the specified ripple animation config. */
  _showRipple(animation, ignoreGlobalRippleConfig) {
    var _this$_slider$_global;
    if (this._slider.disabled) {
      return;
    }
    this._showValueIndicator();
    if (this._slider._isRange) {
      const sibling = this._slider._getThumb(this.thumbPosition === 1 /* _MatThumb.START */ ? 2 /* _MatThumb.END */ : 1 /* _MatThumb.START */);
      sibling._showValueIndicator();
    }
    if ((_this$_slider$_global = this._slider._globalRippleOptions) !== null && _this$_slider$_global !== void 0 && _this$_slider$_global.disabled && !ignoreGlobalRippleConfig) {
      return;
    }
    return this._ripple.launch({
      animation: this._slider._noopAnimations ? {
        enterDuration: 0,
        exitDuration: 0
      } : animation,
      centered: true,
      persistent: true
    });
  }
  /**
   * Fades out the given ripple.
   * Also hides the value indicator if no ripple is showing.
   */
  _hideRipple(rippleRef) {
    rippleRef === null || rippleRef === void 0 || rippleRef.fadeOut();
    if (this._isShowingAnyRipple()) {
      return;
    }
    if (!this._slider._isRange) {
      this._hideValueIndicator();
    }
    const sibling = this._getSibling();
    if (!sibling._isShowingAnyRipple()) {
      this._hideValueIndicator();
      sibling._hideValueIndicator();
    }
  }
  /** Shows the value indicator ui. */
  _showValueIndicator() {
    this._hostElement.classList.add('mdc-slider__thumb--with-indicator');
  }
  /** Hides the value indicator ui. */
  _hideValueIndicator() {
    this._hostElement.classList.remove('mdc-slider__thumb--with-indicator');
  }
  _getSibling() {
    return this._slider._getThumb(this.thumbPosition === 1 /* _MatThumb.START */ ? 2 /* _MatThumb.END */ : 1 /* _MatThumb.START */);
  }
  /** Gets the value indicator container's native HTML element. */
  _getValueIndicatorContainer() {
    var _this$_valueIndicator;
    return (_this$_valueIndicator = this._valueIndicatorContainer) === null || _this$_valueIndicator === void 0 ? void 0 : _this$_valueIndicator.nativeElement;
  }
  /** Gets the native HTML element of the slider thumb knob. */
  _getKnob() {
    return this._knob.nativeElement;
  }
  _isShowingAnyRipple() {
    return this._isShowingRipple(this._hoverRippleRef) || this._isShowingRipple(this._focusRippleRef) || this._isShowingRipple(this._activeRippleRef);
  }
}
_class = MatSliderVisualThumb;
_class.ɵfac = function _class_Factory(t) {
  return new (t || _class)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_0__.ChangeDetectorRef), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_0__.NgZone), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_0__.ElementRef), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](MAT_SLIDER));
};
_class.ɵcmp = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
  type: _class,
  selectors: [["mat-slider-visual-thumb"]],
  viewQuery: function _class_Query(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵviewQuery"](_angular_material_core__WEBPACK_IMPORTED_MODULE_1__.MatRipple, 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵviewQuery"](_c0, 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵviewQuery"](_c1, 5);
    }
    if (rf & 2) {
      let _t;
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵloadQuery"]()) && (ctx._ripple = _t.first);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵloadQuery"]()) && (ctx._knob = _t.first);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵloadQuery"]()) && (ctx._valueIndicatorContainer = _t.first);
    }
  },
  hostAttrs: [1, "mdc-slider__thumb", "mat-mdc-slider-visual-thumb"],
  inputs: {
    discrete: "discrete",
    thumbPosition: "thumbPosition",
    valueIndicatorText: "valueIndicatorText"
  },
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵProvidersFeature"]([{
    provide: MAT_SLIDER_VISUAL_THUMB,
    useExisting: _class
  }])],
  decls: 4,
  vars: 2,
  consts: [["class", "mdc-slider__value-indicator-container"], [1, "mdc-slider__thumb-knob"], ["knob", ""], ["matRipple", "", 1, "mat-mdc-focus-indicator", 3, "matRippleDisabled"], [1, "mdc-slider__value-indicator-container"], ["valueIndicatorContainer", ""], [1, "mdc-slider__value-indicator"], [1, "mdc-slider__value-indicator-text"]],
  template: function _class_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](0, _class_Conditional_0_Template, 5, 1, "div", 0);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](1, "div", 1, 2)(3, "div", 3);
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵconditional"](0, ctx.discrete ? 0 : -1);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("matRippleDisabled", true);
    }
  },
  dependencies: [_angular_material_core__WEBPACK_IMPORTED_MODULE_1__.MatRipple],
  styles: [".mat-mdc-slider-visual-thumb .mat-ripple{height:100%;width:100%}.mat-mdc-slider .mdc-slider__tick-marks{justify-content:start}.mat-mdc-slider .mdc-slider__tick-marks .mdc-slider__tick-mark--active,.mat-mdc-slider .mdc-slider__tick-marks .mdc-slider__tick-mark--inactive{position:absolute;left:2px}"],
  encapsulation: 2,
  changeDetection: 0
});
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](MatSliderVisualThumb, [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Component,
    args: [{
      selector: 'mat-slider-visual-thumb',
      host: {
        'class': 'mdc-slider__thumb mat-mdc-slider-visual-thumb'
      },
      changeDetection: _angular_core__WEBPACK_IMPORTED_MODULE_0__.ChangeDetectionStrategy.OnPush,
      encapsulation: _angular_core__WEBPACK_IMPORTED_MODULE_0__.ViewEncapsulation.None,
      providers: [{
        provide: MAT_SLIDER_VISUAL_THUMB,
        useExisting: MatSliderVisualThumb
      }],
      template: "@if (discrete) {\n  <div class=\"mdc-slider__value-indicator-container\" #valueIndicatorContainer>\n    <div class=\"mdc-slider__value-indicator\">\n      <span class=\"mdc-slider__value-indicator-text\">{{valueIndicatorText}}</span>\n    </div>\n  </div>\n}\n<div class=\"mdc-slider__thumb-knob\" #knob></div>\n<div matRipple class=\"mat-mdc-focus-indicator\" [matRippleDisabled]=\"true\"></div>\n",
      styles: [".mat-mdc-slider-visual-thumb .mat-ripple{height:100%;width:100%}.mat-mdc-slider .mdc-slider__tick-marks{justify-content:start}.mat-mdc-slider .mdc-slider__tick-marks .mdc-slider__tick-mark--active,.mat-mdc-slider .mdc-slider__tick-marks .mdc-slider__tick-mark--inactive{position:absolute;left:2px}"]
    }]
  }], () => [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.ChangeDetectorRef
  }, {
    type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.NgZone
  }, {
    type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.ElementRef
  }, {
    type: undefined,
    decorators: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Inject,
      args: [MAT_SLIDER]
    }]
  }], {
    discrete: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    thumbPosition: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    valueIndicatorText: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    _ripple: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.ViewChild,
      args: [_angular_material_core__WEBPACK_IMPORTED_MODULE_1__.MatRipple]
    }],
    _knob: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.ViewChild,
      args: ['knob']
    }],
    _valueIndicatorContainer: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.ViewChild,
      args: ['valueIndicatorContainer']
    }]
  });
})();

// TODO(wagnermaciel): maybe handle the following edge case:
// 1. start dragging discrete slider
// 2. tab to disable checkbox
// 3. without ending drag, disable the slider
// Boilerplate for applying mixins to MatSlider.
const _MatSliderMixinBase = (0,_angular_material_core__WEBPACK_IMPORTED_MODULE_1__.mixinColor)((0,_angular_material_core__WEBPACK_IMPORTED_MODULE_1__.mixinDisableRipple)(class {
  constructor(_elementRef) {
    this._elementRef = _elementRef;
  }
}), 'primary');
/**
 * Allows users to select from a range of values by moving the slider thumb. It is similar in
 * behavior to the native `<input type="range">` element.
 */
class MatSlider extends _MatSliderMixinBase {
  /** Whether the slider is disabled. */
  get disabled() {
    return this._disabled;
  }
  set disabled(v) {
    this._disabled = (0,_angular_cdk_coercion__WEBPACK_IMPORTED_MODULE_2__.coerceBooleanProperty)(v);
    const endInput = this._getInput(2 /* _MatThumb.END */);
    const startInput = this._getInput(1 /* _MatThumb.START */);
    if (endInput) {
      endInput.disabled = this._disabled;
    }
    if (startInput) {
      startInput.disabled = this._disabled;
    }
  }
  /** Whether the slider displays a numeric value label upon pressing the thumb. */
  get discrete() {
    return this._discrete;
  }
  set discrete(v) {
    this._discrete = (0,_angular_cdk_coercion__WEBPACK_IMPORTED_MODULE_2__.coerceBooleanProperty)(v);
    this._updateValueIndicatorUIs();
  }
  /** Whether the slider displays tick marks along the slider track. */
  get showTickMarks() {
    return this._showTickMarks;
  }
  set showTickMarks(v) {
    this._showTickMarks = (0,_angular_cdk_coercion__WEBPACK_IMPORTED_MODULE_2__.coerceBooleanProperty)(v);
  }
  /** The minimum value that the slider can have. */
  get min() {
    return this._min;
  }
  set min(v) {
    const min = (0,_angular_cdk_coercion__WEBPACK_IMPORTED_MODULE_2__.coerceNumberProperty)(v, this._min);
    if (this._min !== min) {
      this._updateMin(min);
    }
  }
  _updateMin(min) {
    const prevMin = this._min;
    this._min = min;
    this._isRange ? this._updateMinRange({
      old: prevMin,
      new: min
    }) : this._updateMinNonRange(min);
    this._onMinMaxOrStepChange();
  }
  _updateMinRange(min) {
    const endInput = this._getInput(2 /* _MatThumb.END */);
    const startInput = this._getInput(1 /* _MatThumb.START */);
    const oldEndValue = endInput.value;
    const oldStartValue = startInput.value;
    startInput.min = min.new;
    endInput.min = Math.max(min.new, startInput.value);
    startInput.max = Math.min(endInput.max, endInput.value);
    startInput._updateWidthInactive();
    endInput._updateWidthInactive();
    min.new < min.old ? this._onTranslateXChangeBySideEffect(endInput, startInput) : this._onTranslateXChangeBySideEffect(startInput, endInput);
    if (oldEndValue !== endInput.value) {
      this._onValueChange(endInput);
    }
    if (oldStartValue !== startInput.value) {
      this._onValueChange(startInput);
    }
  }
  _updateMinNonRange(min) {
    const input = this._getInput(2 /* _MatThumb.END */);
    if (input) {
      const oldValue = input.value;
      input.min = min;
      input._updateThumbUIByValue();
      this._updateTrackUI(input);
      if (oldValue !== input.value) {
        this._onValueChange(input);
      }
    }
  }
  /** The maximum value that the slider can have. */
  get max() {
    return this._max;
  }
  set max(v) {
    const max = (0,_angular_cdk_coercion__WEBPACK_IMPORTED_MODULE_2__.coerceNumberProperty)(v, this._max);
    if (this._max !== max) {
      this._updateMax(max);
    }
  }
  _updateMax(max) {
    const prevMax = this._max;
    this._max = max;
    this._isRange ? this._updateMaxRange({
      old: prevMax,
      new: max
    }) : this._updateMaxNonRange(max);
    this._onMinMaxOrStepChange();
  }
  _updateMaxRange(max) {
    const endInput = this._getInput(2 /* _MatThumb.END */);
    const startInput = this._getInput(1 /* _MatThumb.START */);
    const oldEndValue = endInput.value;
    const oldStartValue = startInput.value;
    endInput.max = max.new;
    startInput.max = Math.min(max.new, endInput.value);
    endInput.min = startInput.value;
    endInput._updateWidthInactive();
    startInput._updateWidthInactive();
    max.new > max.old ? this._onTranslateXChangeBySideEffect(startInput, endInput) : this._onTranslateXChangeBySideEffect(endInput, startInput);
    if (oldEndValue !== endInput.value) {
      this._onValueChange(endInput);
    }
    if (oldStartValue !== startInput.value) {
      this._onValueChange(startInput);
    }
  }
  _updateMaxNonRange(max) {
    const input = this._getInput(2 /* _MatThumb.END */);
    if (input) {
      const oldValue = input.value;
      input.max = max;
      input._updateThumbUIByValue();
      this._updateTrackUI(input);
      if (oldValue !== input.value) {
        this._onValueChange(input);
      }
    }
  }
  /** The values at which the thumb will snap. */
  get step() {
    return this._step;
  }
  set step(v) {
    const step = (0,_angular_cdk_coercion__WEBPACK_IMPORTED_MODULE_2__.coerceNumberProperty)(v, this._step);
    if (this._step !== step) {
      this._updateStep(step);
    }
  }
  _updateStep(step) {
    this._step = step;
    this._isRange ? this._updateStepRange() : this._updateStepNonRange();
    this._onMinMaxOrStepChange();
  }
  _updateStepRange() {
    const endInput = this._getInput(2 /* _MatThumb.END */);
    const startInput = this._getInput(1 /* _MatThumb.START */);
    const oldEndValue = endInput.value;
    const oldStartValue = startInput.value;
    const prevStartValue = startInput.value;
    endInput.min = this._min;
    startInput.max = this._max;
    endInput.step = this._step;
    startInput.step = this._step;
    if (this._platform.SAFARI) {
      endInput.value = endInput.value;
      startInput.value = startInput.value;
    }
    endInput.min = Math.max(this._min, startInput.value);
    startInput.max = Math.min(this._max, endInput.value);
    startInput._updateWidthInactive();
    endInput._updateWidthInactive();
    endInput.value < prevStartValue ? this._onTranslateXChangeBySideEffect(startInput, endInput) : this._onTranslateXChangeBySideEffect(endInput, startInput);
    if (oldEndValue !== endInput.value) {
      this._onValueChange(endInput);
    }
    if (oldStartValue !== startInput.value) {
      this._onValueChange(startInput);
    }
  }
  _updateStepNonRange() {
    const input = this._getInput(2 /* _MatThumb.END */);
    if (input) {
      const oldValue = input.value;
      input.step = this._step;
      if (this._platform.SAFARI) {
        input.value = input.value;
      }
      input._updateThumbUIByValue();
      if (oldValue !== input.value) {
        this._onValueChange(input);
      }
    }
  }
  constructor(_ngZone, _cdr, elementRef, _dir, _globalRippleOptions, animationMode) {
    super(elementRef);
    this._ngZone = _ngZone;
    this._cdr = _cdr;
    this._dir = _dir;
    this._globalRippleOptions = _globalRippleOptions;
    this._disabled = false;
    this._discrete = false;
    this._showTickMarks = false;
    this._min = 0;
    this._max = 100;
    this._step = 1;
    /**
     * Function that will be used to format the value before it is displayed
     * in the thumb label. Can be used to format very large number in order
     * for them to fit into the slider thumb.
     */
    this.displayWith = value => `${value}`;
    this._rippleRadius = 24;
    // The value indicator tooltip text for the visual slider thumb(s).
    /** @docs-private */
    this.startValueIndicatorText = '';
    /** @docs-private */
    this.endValueIndicatorText = '';
    this._isRange = false;
    /** Whether the slider is rtl. */
    this._isRtl = false;
    this._hasViewInitialized = false;
    /**
     * The width of the tick mark track.
     * The tick mark track width is different from full track width
     */
    this._tickMarkTrackWidth = 0;
    this._hasAnimation = false;
    this._resizeTimer = null;
    this._platform = (0,_angular_core__WEBPACK_IMPORTED_MODULE_0__.inject)(_angular_cdk_platform__WEBPACK_IMPORTED_MODULE_3__.Platform);
    /** The radius of the native slider's knob. AFAIK there is no way to avoid hardcoding this. */
    this._knobRadius = 8;
    /** Whether or not the slider thumbs overlap. */
    this._thumbsOverlap = false;
    this._noopAnimations = animationMode === 'NoopAnimations';
    this._dirChangeSubscription = this._dir.change.subscribe(() => this._onDirChange());
    this._isRtl = this._dir.value === 'rtl';
  }
  ngAfterViewInit() {
    if (this._platform.isBrowser) {
      this._updateDimensions();
    }
    const eInput = this._getInput(2 /* _MatThumb.END */);
    const sInput = this._getInput(1 /* _MatThumb.START */);
    this._isRange = !!eInput && !!sInput;
    this._cdr.detectChanges();
    if (typeof ngDevMode === 'undefined' || ngDevMode) {
      _validateInputs(this._isRange, this._getInput(2 /* _MatThumb.END */), this._getInput(1 /* _MatThumb.START */));
    }

    const thumb = this._getThumb(2 /* _MatThumb.END */);
    this._rippleRadius = thumb._ripple.radius;
    this._inputPadding = this._rippleRadius - this._knobRadius;
    this._inputOffset = this._knobRadius;
    this._isRange ? this._initUIRange(eInput, sInput) : this._initUINonRange(eInput);
    this._updateTrackUI(eInput);
    this._updateTickMarkUI();
    this._updateTickMarkTrackUI();
    this._observeHostResize();
    this._cdr.detectChanges();
  }
  _initUINonRange(eInput) {
    eInput.initProps();
    eInput.initUI();
    this._updateValueIndicatorUI(eInput);
    this._hasViewInitialized = true;
    eInput._updateThumbUIByValue();
  }
  _initUIRange(eInput, sInput) {
    eInput.initProps();
    eInput.initUI();
    sInput.initProps();
    sInput.initUI();
    eInput._updateMinMax();
    sInput._updateMinMax();
    eInput._updateStaticStyles();
    sInput._updateStaticStyles();
    this._updateValueIndicatorUIs();
    this._hasViewInitialized = true;
    eInput._updateThumbUIByValue();
    sInput._updateThumbUIByValue();
  }
  ngOnDestroy() {
    var _this$_resizeObserver;
    this._dirChangeSubscription.unsubscribe();
    (_this$_resizeObserver = this._resizeObserver) === null || _this$_resizeObserver === void 0 || _this$_resizeObserver.disconnect();
    this._resizeObserver = null;
  }
  /** Handles updating the slider ui after a dir change. */
  _onDirChange() {
    this._isRtl = this._dir.value === 'rtl';
    this._isRange ? this._onDirChangeRange() : this._onDirChangeNonRange();
    this._updateTickMarkUI();
  }
  _onDirChangeRange() {
    const endInput = this._getInput(2 /* _MatThumb.END */);
    const startInput = this._getInput(1 /* _MatThumb.START */);
    endInput._setIsLeftThumb();
    startInput._setIsLeftThumb();
    endInput.translateX = endInput._calcTranslateXByValue();
    startInput.translateX = startInput._calcTranslateXByValue();
    endInput._updateStaticStyles();
    startInput._updateStaticStyles();
    endInput._updateWidthInactive();
    startInput._updateWidthInactive();
    endInput._updateThumbUIByValue();
    startInput._updateThumbUIByValue();
  }
  _onDirChangeNonRange() {
    const input = this._getInput(2 /* _MatThumb.END */);
    input._updateThumbUIByValue();
  }
  /** Starts observing and updating the slider if the host changes its size. */
  _observeHostResize() {
    if (typeof ResizeObserver === 'undefined' || !ResizeObserver) {
      return;
    }
    this._ngZone.runOutsideAngular(() => {
      this._resizeObserver = new ResizeObserver(() => {
        if (this._isActive()) {
          return;
        }
        if (this._resizeTimer) {
          clearTimeout(this._resizeTimer);
        }
        this._onResize();
      });
      this._resizeObserver.observe(this._elementRef.nativeElement);
    });
  }
  /** Whether any of the thumbs are currently active. */
  _isActive() {
    return this._getThumb(1 /* _MatThumb.START */)._isActive || this._getThumb(2 /* _MatThumb.END */)._isActive;
  }
  _getValue(thumbPosition = 2 /* _MatThumb.END */) {
    const input = this._getInput(thumbPosition);
    if (!input) {
      return this.min;
    }
    return input.value;
  }
  _skipUpdate() {
    var _this$_getInput, _this$_getInput2;
    return !!((_this$_getInput = this._getInput(1 /* _MatThumb.START */)) !== null && _this$_getInput !== void 0 && _this$_getInput._skipUIUpdate || (_this$_getInput2 = this._getInput(2 /* _MatThumb.END */)) !== null && _this$_getInput2 !== void 0 && _this$_getInput2._skipUIUpdate);
  }
  /** Stores the slider dimensions. */
  _updateDimensions() {
    this._cachedWidth = this._elementRef.nativeElement.offsetWidth;
    this._cachedLeft = this._elementRef.nativeElement.getBoundingClientRect().left;
  }
  /** Sets the styles for the active portion of the track. */
  _setTrackActiveStyles(styles) {
    const trackStyle = this._trackActive.nativeElement.style;
    trackStyle.left = styles.left;
    trackStyle.right = styles.right;
    trackStyle.transformOrigin = styles.transformOrigin;
    trackStyle.transform = styles.transform;
  }
  /** Returns the translateX positioning for a tick mark based on it's index. */
  _calcTickMarkTransform(index) {
    // TODO(wagnermaciel): See if we can avoid doing this and just using flex to position these.
    const translateX = index * (this._tickMarkTrackWidth / (this._tickMarks.length - 1));
    return `translateX(${translateX}px`;
  }
  // Handlers for updating the slider ui.
  _onTranslateXChange(source) {
    if (!this._hasViewInitialized) {
      return;
    }
    this._updateThumbUI(source);
    this._updateTrackUI(source);
    this._updateOverlappingThumbUI(source);
  }
  _onTranslateXChangeBySideEffect(input1, input2) {
    if (!this._hasViewInitialized) {
      return;
    }
    input1._updateThumbUIByValue();
    input2._updateThumbUIByValue();
  }
  _onValueChange(source) {
    if (!this._hasViewInitialized) {
      return;
    }
    this._updateValueIndicatorUI(source);
    this._updateTickMarkUI();
    this._cdr.detectChanges();
  }
  _onMinMaxOrStepChange() {
    if (!this._hasViewInitialized) {
      return;
    }
    this._updateTickMarkUI();
    this._updateTickMarkTrackUI();
    this._cdr.markForCheck();
  }
  _onResize() {
    if (!this._hasViewInitialized) {
      return;
    }
    this._updateDimensions();
    if (this._isRange) {
      const eInput = this._getInput(2 /* _MatThumb.END */);
      const sInput = this._getInput(1 /* _MatThumb.START */);
      eInput._updateThumbUIByValue();
      sInput._updateThumbUIByValue();
      eInput._updateStaticStyles();
      sInput._updateStaticStyles();
      eInput._updateMinMax();
      sInput._updateMinMax();
      eInput._updateWidthInactive();
      sInput._updateWidthInactive();
    } else {
      const eInput = this._getInput(2 /* _MatThumb.END */);
      if (eInput) {
        eInput._updateThumbUIByValue();
      }
    }
    this._updateTickMarkUI();
    this._updateTickMarkTrackUI();
    this._cdr.detectChanges();
  }
  /** Returns true if the slider knobs are overlapping one another. */
  _areThumbsOverlapping() {
    const startInput = this._getInput(1 /* _MatThumb.START */);
    const endInput = this._getInput(2 /* _MatThumb.END */);
    if (!startInput || !endInput) {
      return false;
    }
    return endInput.translateX - startInput.translateX < 20;
  }
  /**
   * Updates the class names of overlapping slider thumbs so
   * that the current active thumb is styled to be on "top".
   */
  _updateOverlappingThumbClassNames(source) {
    const sibling = source.getSibling();
    const sourceThumb = this._getThumb(source.thumbPosition);
    const siblingThumb = this._getThumb(sibling.thumbPosition);
    siblingThumb._hostElement.classList.remove('mdc-slider__thumb--top');
    sourceThumb._hostElement.classList.toggle('mdc-slider__thumb--top', this._thumbsOverlap);
  }
  /** Updates the UI of slider thumbs when they begin or stop overlapping. */
  _updateOverlappingThumbUI(source) {
    if (!this._isRange || this._skipUpdate()) {
      return;
    }
    if (this._thumbsOverlap !== this._areThumbsOverlapping()) {
      this._thumbsOverlap = !this._thumbsOverlap;
      this._updateOverlappingThumbClassNames(source);
    }
  }
  // _MatThumb styles update conditions
  //
  // 1. TranslateX, resize, or dir change
  //    - Reason: The thumb styles need to be updated according to the new translateX.
  // 2. Min, max, or step
  //    - Reason: The value may have silently changed.
  /** Updates the translateX of the given thumb. */
  _updateThumbUI(source) {
    if (this._skipUpdate()) {
      return;
    }
    const thumb = this._getThumb(source.thumbPosition === 2 /* _MatThumb.END */ ? 2 /* _MatThumb.END */ : 1 /* _MatThumb.START */);
    thumb._hostElement.style.transform = `translateX(${source.translateX}px)`;
  }
  // Value indicator text update conditions
  //
  // 1. Value
  //    - Reason: The value displayed needs to be updated.
  // 2. Min, max, or step
  //    - Reason: The value may have silently changed.
  /** Updates the value indicator tooltip ui for the given thumb. */
  _updateValueIndicatorUI(source) {
    if (this._skipUpdate()) {
      return;
    }
    const valuetext = this.displayWith(source.value);
    this._hasViewInitialized ? source._valuetext = valuetext : source._hostElement.setAttribute('aria-valuetext', valuetext);
    if (this.discrete) {
      source.thumbPosition === 1 /* _MatThumb.START */ ? this.startValueIndicatorText = valuetext : this.endValueIndicatorText = valuetext;
      const visualThumb = this._getThumb(source.thumbPosition);
      valuetext.length < 3 ? visualThumb._hostElement.classList.add('mdc-slider__thumb--short-value') : visualThumb._hostElement.classList.remove('mdc-slider__thumb--short-value');
    }
  }
  /** Updates all value indicator UIs in the slider. */
  _updateValueIndicatorUIs() {
    const eInput = this._getInput(2 /* _MatThumb.END */);
    const sInput = this._getInput(1 /* _MatThumb.START */);
    if (eInput) {
      this._updateValueIndicatorUI(eInput);
    }
    if (sInput) {
      this._updateValueIndicatorUI(sInput);
    }
  }
  // Update Tick Mark Track Width
  //
  // 1. Min, max, or step
  //    - Reason: The maximum reachable value may have changed.
  //    - Side note: The maximum reachable value is different from the maximum value set by the
  //      user. For example, a slider with [min: 5, max: 100, step: 10] would have a maximum
  //      reachable value of 95.
  // 2. Resize
  //    - Reason: The position for the maximum reachable value needs to be recalculated.
  /** Updates the width of the tick mark track. */
  _updateTickMarkTrackUI() {
    if (!this.showTickMarks || this._skipUpdate()) {
      return;
    }
    const step = this._step && this._step > 0 ? this._step : 1;
    const maxValue = Math.floor(this.max / step) * step;
    const percentage = (maxValue - this.min) / (this.max - this.min);
    this._tickMarkTrackWidth = this._cachedWidth * percentage - 6;
  }
  // Track active update conditions
  //
  // 1. TranslateX
  //    - Reason: The track active should line up with the new thumb position.
  // 2. Min or max
  //    - Reason #1: The 'active' percentage needs to be recalculated.
  //    - Reason #2: The value may have silently changed.
  // 3. Step
  //    - Reason: The value may have silently changed causing the thumb(s) to shift.
  // 4. Dir change
  //    - Reason: The track active will need to be updated according to the new thumb position(s).
  // 5. Resize
  //    - Reason: The total width the 'active' tracks translateX is based on has changed.
  /** Updates the scale on the active portion of the track. */
  _updateTrackUI(source) {
    if (this._skipUpdate()) {
      return;
    }
    this._isRange ? this._updateTrackUIRange(source) : this._updateTrackUINonRange(source);
  }
  _updateTrackUIRange(source) {
    const sibling = source.getSibling();
    if (!sibling || !this._cachedWidth) {
      return;
    }
    const activePercentage = Math.abs(sibling.translateX - source.translateX) / this._cachedWidth;
    if (source._isLeftThumb && this._cachedWidth) {
      this._setTrackActiveStyles({
        left: 'auto',
        right: `${this._cachedWidth - sibling.translateX}px`,
        transformOrigin: 'right',
        transform: `scaleX(${activePercentage})`
      });
    } else {
      this._setTrackActiveStyles({
        left: `${sibling.translateX}px`,
        right: 'auto',
        transformOrigin: 'left',
        transform: `scaleX(${activePercentage})`
      });
    }
  }
  _updateTrackUINonRange(source) {
    this._isRtl ? this._setTrackActiveStyles({
      left: 'auto',
      right: '0px',
      transformOrigin: 'right',
      transform: `scaleX(${1 - source.fillPercentage})`
    }) : this._setTrackActiveStyles({
      left: '0px',
      right: 'auto',
      transformOrigin: 'left',
      transform: `scaleX(${source.fillPercentage})`
    });
  }
  // Tick mark update conditions
  //
  // 1. Value
  //    - Reason: a tick mark which was once active might now be inactive or vice versa.
  // 2. Min, max, or step
  //    - Reason #1: the number of tick marks may have changed.
  //    - Reason #2: The value may have silently changed.
  /** Updates the dots along the slider track. */
  _updateTickMarkUI() {
    if (!this.showTickMarks || this.step === undefined || this.min === undefined || this.max === undefined) {
      return;
    }
    const step = this.step > 0 ? this.step : 1;
    this._isRange ? this._updateTickMarkUIRange(step) : this._updateTickMarkUINonRange(step);
    if (this._isRtl) {
      this._tickMarks.reverse();
    }
  }
  _updateTickMarkUINonRange(step) {
    const value = this._getValue();
    let numActive = Math.max(Math.round((value - this.min) / step), 0);
    let numInactive = Math.max(Math.round((this.max - value) / step), 0);
    this._isRtl ? numActive++ : numInactive++;
    this._tickMarks = Array(numActive).fill(0 /* _MatTickMark.ACTIVE */).concat(Array(numInactive).fill(1 /* _MatTickMark.INACTIVE */));
  }

  _updateTickMarkUIRange(step) {
    const endValue = this._getValue();
    const startValue = this._getValue(1 /* _MatThumb.START */);
    const numInactiveBeforeStartThumb = Math.max(Math.floor((startValue - this.min) / step), 0);
    const numActive = Math.max(Math.floor((endValue - startValue) / step) + 1, 0);
    const numInactiveAfterEndThumb = Math.max(Math.floor((this.max - endValue) / step), 0);
    this._tickMarks = Array(numInactiveBeforeStartThumb).fill(1 /* _MatTickMark.INACTIVE */).concat(Array(numActive).fill(0 /* _MatTickMark.ACTIVE */), Array(numInactiveAfterEndThumb).fill(1 /* _MatTickMark.INACTIVE */));
  }
  /** Gets the slider thumb input of the given thumb position. */
  _getInput(thumbPosition) {
    var _this$_inputs;
    if (thumbPosition === 2 /* _MatThumb.END */ && this._input) {
      return this._input;
    }
    if ((_this$_inputs = this._inputs) !== null && _this$_inputs !== void 0 && _this$_inputs.length) {
      return thumbPosition === 1 /* _MatThumb.START */ ? this._inputs.first : this._inputs.last;
    }
    return;
  }
  /** Gets the slider thumb HTML input element of the given thumb position. */
  _getThumb(thumbPosition) {
    var _this$_thumbs, _this$_thumbs2;
    return thumbPosition === 2 /* _MatThumb.END */ ? (_this$_thumbs = this._thumbs) === null || _this$_thumbs === void 0 ? void 0 : _this$_thumbs.last : (_this$_thumbs2 = this._thumbs) === null || _this$_thumbs2 === void 0 ? void 0 : _this$_thumbs2.first;
  }
  _setTransition(withAnimation) {
    this._hasAnimation = !this._platform.IOS && withAnimation && !this._noopAnimations;
    this._elementRef.nativeElement.classList.toggle('mat-mdc-slider-with-animation', this._hasAnimation);
  }
  /** Whether the given pointer event occurred within the bounds of the slider pointer's DOM Rect. */
  _isCursorOnSliderThumb(event, rect) {
    const radius = rect.width / 2;
    const centerX = rect.x + radius;
    const centerY = rect.y + radius;
    const dx = event.clientX - centerX;
    const dy = event.clientY - centerY;
    return Math.pow(dx, 2) + Math.pow(dy, 2) < Math.pow(radius, 2);
  }
}
_class2 = MatSlider;
_class2.ɵfac = function _class2_Factory(t) {
  return new (t || _class2)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_0__.NgZone), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_0__.ChangeDetectorRef), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_0__.ElementRef), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_cdk_bidi__WEBPACK_IMPORTED_MODULE_4__.Directionality, 8), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_material_core__WEBPACK_IMPORTED_MODULE_1__.MAT_RIPPLE_GLOBAL_OPTIONS, 8), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_0__.ANIMATION_MODULE_TYPE, 8));
};
_class2.ɵcmp = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
  type: _class2,
  selectors: [["mat-slider"]],
  contentQueries: function _class2_ContentQueries(rf, ctx, dirIndex) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵcontentQuery"](dirIndex, MAT_SLIDER_THUMB, 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵcontentQuery"](dirIndex, MAT_SLIDER_RANGE_THUMB, 4);
    }
    if (rf & 2) {
      let _t;
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵloadQuery"]()) && (ctx._input = _t.first);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵloadQuery"]()) && (ctx._inputs = _t);
    }
  },
  viewQuery: function _class2_Query(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵviewQuery"](_c2, 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵviewQuery"](MAT_SLIDER_VISUAL_THUMB, 5);
    }
    if (rf & 2) {
      let _t;
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵloadQuery"]()) && (ctx._trackActive = _t.first);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵloadQuery"]()) && (ctx._thumbs = _t);
    }
  },
  hostAttrs: [1, "mat-mdc-slider", "mdc-slider"],
  hostVars: 10,
  hostBindings: function _class2_HostBindings(rf, ctx) {
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵclassProp"]("mdc-slider--range", ctx._isRange)("mdc-slider--disabled", ctx.disabled)("mdc-slider--discrete", ctx.discrete)("mdc-slider--tick-marks", ctx.showTickMarks)("_mat-animation-noopable", ctx._noopAnimations);
    }
  },
  inputs: {
    color: "color",
    disableRipple: "disableRipple",
    disabled: "disabled",
    discrete: "discrete",
    showTickMarks: "showTickMarks",
    min: "min",
    max: "max",
    step: "step",
    displayWith: "displayWith"
  },
  exportAs: ["matSlider"],
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵProvidersFeature"]([{
    provide: MAT_SLIDER,
    useExisting: _class2
  }]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵInheritDefinitionFeature"]],
  ngContentSelectors: _c3,
  decls: 9,
  vars: 5,
  consts: [[1, "mdc-slider__track"], [1, "mdc-slider__track--inactive"], [1, "mdc-slider__track--active"], [1, "mdc-slider__track--active_fill"], ["trackActive", ""], ["class", "mdc-slider__tick-marks"], [3, "discrete", "thumbPosition", "valueIndicatorText"], [1, "mdc-slider__tick-marks"], ["tickMarkContainer", ""], [3, "class", "transform"]],
  template: function _class2_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵprojectionDef"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵprojection"](0);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "div", 0);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](2, "div", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "div", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](4, "div", 3, 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](6, _class2_Conditional_6_Template, 3, 1, "div", 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](7, _class2_Conditional_7_Template, 1, 3, "mat-slider-visual-thumb", 6);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](8, "mat-slider-visual-thumb", 6);
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](6);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵconditional"](6, ctx.showTickMarks ? 6 : -1);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵconditional"](7, ctx._isRange ? 7 : -1);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("discrete", ctx.discrete)("thumbPosition", 2)("valueIndicatorText", ctx.endValueIndicatorText);
    }
  },
  dependencies: [MatSliderVisualThumb],
  styles: [".mdc-slider{cursor:pointer;height:48px;margin:0 24px;position:relative;touch-action:pan-y}.mdc-slider .mdc-slider__track{position:absolute;top:50%;transform:translateY(-50%);width:100%}.mdc-slider .mdc-slider__track--active,.mdc-slider .mdc-slider__track--inactive{display:flex;height:100%;position:absolute;width:100%}.mdc-slider .mdc-slider__track--active{overflow:hidden}.mdc-slider .mdc-slider__track--active_fill{border-top-style:solid;box-sizing:border-box;height:100%;width:100%;position:relative;-webkit-transform-origin:left;transform-origin:left}[dir=rtl] .mdc-slider .mdc-slider__track--active_fill,.mdc-slider .mdc-slider__track--active_fill[dir=rtl]{-webkit-transform-origin:right;transform-origin:right}.mdc-slider .mdc-slider__track--inactive{left:0;top:0}.mdc-slider .mdc-slider__track--inactive::before{position:absolute;box-sizing:border-box;width:100%;height:100%;top:0;left:0;border:1px solid rgba(0,0,0,0);border-radius:inherit;content:\"\";pointer-events:none}@media screen and (forced-colors: active){.mdc-slider .mdc-slider__track--inactive::before{border-color:CanvasText}}.mdc-slider .mdc-slider__value-indicator-container{bottom:44px;left:50%;left:var(--slider-value-indicator-container-left, 50%);pointer-events:none;position:absolute;right:var(--slider-value-indicator-container-right);transform:translateX(-50%);transform:var(--slider-value-indicator-container-transform, translateX(-50%))}.mdc-slider .mdc-slider__value-indicator{transition:transform 100ms 0ms cubic-bezier(0.4, 0, 1, 1);align-items:center;border-radius:4px;display:flex;height:32px;padding:0 12px;transform:scale(0);transform-origin:bottom}.mdc-slider .mdc-slider__value-indicator::before{border-left:6px solid rgba(0,0,0,0);border-right:6px solid rgba(0,0,0,0);border-top:6px solid;bottom:-5px;content:\"\";height:0;left:50%;left:var(--slider-value-indicator-caret-left, 50%);position:absolute;right:var(--slider-value-indicator-caret-right);transform:translateX(-50%);transform:var(--slider-value-indicator-caret-transform, translateX(-50%));width:0}.mdc-slider .mdc-slider__value-indicator::after{position:absolute;box-sizing:border-box;width:100%;height:100%;top:0;left:0;border:1px solid rgba(0,0,0,0);border-radius:inherit;content:\"\";pointer-events:none}@media screen and (forced-colors: active){.mdc-slider .mdc-slider__value-indicator::after{border-color:CanvasText}}.mdc-slider .mdc-slider__thumb--with-indicator .mdc-slider__value-indicator-container{pointer-events:auto}.mdc-slider .mdc-slider__thumb--with-indicator .mdc-slider__value-indicator{transition:transform 100ms 0ms cubic-bezier(0, 0, 0.2, 1);transform:scale(1)}@media(prefers-reduced-motion){.mdc-slider .mdc-slider__value-indicator,.mdc-slider .mdc-slider__thumb--with-indicator .mdc-slider__value-indicator{transition:none}}.mdc-slider .mdc-slider__thumb{display:flex;left:-24px;outline:none;position:absolute;user-select:none;height:48px;width:48px}.mdc-slider .mdc-slider__thumb--top{z-index:1}.mdc-slider .mdc-slider__thumb--top .mdc-slider__thumb-knob,.mdc-slider .mdc-slider__thumb--top.mdc-slider__thumb:hover .mdc-slider__thumb-knob,.mdc-slider .mdc-slider__thumb--top.mdc-slider__thumb--focused .mdc-slider__thumb-knob{border-style:solid;border-width:1px;box-sizing:content-box}.mdc-slider .mdc-slider__thumb-knob{box-sizing:border-box;left:50%;position:absolute;top:50%;transform:translate(-50%, -50%)}.mdc-slider .mdc-slider__tick-marks{align-items:center;box-sizing:border-box;display:flex;height:100%;justify-content:space-between;padding:0 1px;position:absolute;width:100%}.mdc-slider--discrete .mdc-slider__thumb,.mdc-slider--discrete .mdc-slider__track--active_fill{transition:transform 80ms ease}@media(prefers-reduced-motion){.mdc-slider--discrete .mdc-slider__thumb,.mdc-slider--discrete .mdc-slider__track--active_fill{transition:none}}.mdc-slider--disabled{cursor:auto}.mdc-slider--disabled .mdc-slider__thumb{pointer-events:none}.mdc-slider__input{cursor:pointer;left:2px;margin:0;height:44px;opacity:0;pointer-events:none;position:absolute;top:2px;width:44px}.mat-mdc-slider{display:inline-block;box-sizing:border-box;outline:none;vertical-align:middle;margin-left:8px;margin-right:8px;width:auto;min-width:112px;-webkit-tap-highlight-color:rgba(0,0,0,0)}.mat-mdc-slider .mdc-slider__thumb-knob{background-color:var(--mdc-slider-handle-color);border-color:var(--mdc-slider-handle-color)}.mat-mdc-slider .mdc-slider__thumb--top .mdc-slider__thumb-knob,.mat-mdc-slider .mdc-slider__thumb--top.mdc-slider__thumb:hover .mdc-slider__thumb-knob,.mat-mdc-slider .mdc-slider__thumb--top.mdc-slider__thumb--focused .mdc-slider__thumb-knob{border-color:#fff}.mat-mdc-slider.mdc-slider--disabled .mdc-slider__thumb-knob{background-color:var(--mdc-slider-disabled-handle-color);border-color:var(--mdc-slider-disabled-handle-color)}.mat-mdc-slider.mdc-slider--disabled .mdc-slider__thumb--top .mdc-slider__thumb-knob,.mat-mdc-slider.mdc-slider--disabled .mdc-slider__thumb--top.mdc-slider__thumb:hover .mdc-slider__thumb-knob,.mat-mdc-slider.mdc-slider--disabled .mdc-slider__thumb--top.mdc-slider__thumb--focused .mdc-slider__thumb-knob{border-color:#fff}.mat-mdc-slider .mdc-slider__thumb::before,.mat-mdc-slider .mdc-slider__thumb::after{background-color:var(--mdc-slider-handle-color)}.mat-mdc-slider .mdc-slider__thumb:hover::before,.mat-mdc-slider .mdc-slider__thumb.mdc-ripple-surface--hover::before{opacity:var(--mdc-ripple-hover-opacity)}.mat-mdc-slider .mdc-slider__thumb.mdc-ripple-upgraded--background-focused::before,.mat-mdc-slider .mdc-slider__thumb:not(.mdc-ripple-upgraded):focus::before{transition-duration:75ms;opacity:var(--mdc-ripple-focus-opacity)}.mat-mdc-slider .mdc-slider__thumb:not(.mdc-ripple-upgraded)::after{transition:opacity 150ms linear}.mat-mdc-slider .mdc-slider__thumb:not(.mdc-ripple-upgraded):active::after{transition-duration:75ms;opacity:var(--mdc-ripple-press-opacity)}.mat-mdc-slider .mdc-slider__thumb.mdc-ripple-upgraded{--mdc-ripple-fg-opacity:var(--mdc-ripple-press-opacity)}.mat-mdc-slider .mdc-slider__track--active_fill{border-color:var(--mdc-slider-active-track-color)}.mat-mdc-slider.mdc-slider--disabled .mdc-slider__track--active_fill{border-color:var(--mdc-slider-disabled-active-track-color)}.mat-mdc-slider .mdc-slider__track--inactive{background-color:var(--mdc-slider-inactive-track-color);opacity:.24}.mat-mdc-slider.mdc-slider--disabled .mdc-slider__track--inactive{background-color:var(--mdc-slider-disabled-inactive-track-color);opacity:.24}.mat-mdc-slider .mdc-slider__tick-mark--active{background-color:var(--mdc-slider-with-tick-marks-active-container-color);opacity:var(--mdc-slider-with-tick-marks-active-container-opacity)}.mat-mdc-slider.mdc-slider--disabled .mdc-slider__tick-mark--active{background-color:var(--mdc-slider-with-tick-marks-active-container-color);opacity:var(--mdc-slider-with-tick-marks-active-container-opacity)}.mat-mdc-slider .mdc-slider__tick-mark--inactive{background-color:var(--mdc-slider-with-tick-marks-inactive-container-color);opacity:var(--mdc-slider-with-tick-marks-inactive-container-opacity)}.mat-mdc-slider.mdc-slider--disabled .mdc-slider__tick-mark--inactive{background-color:var(--mdc-slider-with-tick-marks-disabled-container-color);opacity:var(--mdc-slider-with-tick-marks-inactive-container-opacity)}.mat-mdc-slider .mdc-slider__value-indicator{background-color:var(--mdc-slider-label-container-color);opacity:1}.mat-mdc-slider .mdc-slider__value-indicator::before{border-top-color:var(--mdc-slider-label-container-color)}.mat-mdc-slider .mdc-slider__value-indicator{color:var(--mdc-slider-label-label-text-color)}.mat-mdc-slider .mdc-slider__track{height:var(--mdc-slider-inactive-track-height)}.mat-mdc-slider .mdc-slider__track--active{height:var(--mdc-slider-active-track-height);top:calc((var(--mdc-slider-inactive-track-height) - var(--mdc-slider-active-track-height)) / 2)}.mat-mdc-slider .mdc-slider__track--active_fill{border-top-width:var(--mdc-slider-active-track-height)}.mat-mdc-slider .mdc-slider__track--inactive{height:var(--mdc-slider-inactive-track-height)}.mat-mdc-slider .mdc-slider__tick-mark--active,.mat-mdc-slider .mdc-slider__tick-mark--inactive{height:var(--mdc-slider-with-tick-marks-container-size);width:var(--mdc-slider-with-tick-marks-container-size)}.mat-mdc-slider.mdc-slider--disabled{opacity:0.38}.mat-mdc-slider .mdc-slider__value-indicator-text{letter-spacing:var(--mdc-slider-label-label-text-tracking);font-size:var(--mdc-slider-label-label-text-size);font-family:var(--mdc-slider-label-label-text-font);font-weight:var(--mdc-slider-label-label-text-weight);line-height:var(--mdc-slider-label-label-text-line-height)}.mat-mdc-slider .mdc-slider__track--active{border-radius:var(--mdc-slider-active-track-shape)}.mat-mdc-slider .mdc-slider__track--inactive{border-radius:var(--mdc-slider-inactive-track-shape)}.mat-mdc-slider .mdc-slider__thumb-knob{border-radius:var(--mdc-slider-handle-shape);width:var(--mdc-slider-handle-width);height:var(--mdc-slider-handle-height);border-style:solid;border-width:calc(var(--mdc-slider-handle-height) / 2) calc(var(--mdc-slider-handle-width) / 2)}.mat-mdc-slider .mdc-slider__tick-mark--active,.mat-mdc-slider .mdc-slider__tick-mark--inactive{border-radius:var(--mdc-slider-with-tick-marks-container-shape)}.mat-mdc-slider .mdc-slider__thumb:hover .mdc-slider__thumb-knob{background-color:var(--mdc-slider-hover-handle-color);border-color:var(--mdc-slider-hover-handle-color)}.mat-mdc-slider .mdc-slider__thumb:hover .mdc-slider__thumb--top .mdc-slider__thumb-knob,.mat-mdc-slider .mdc-slider__thumb:hover .mdc-slider__thumb--top.mdc-slider__thumb:hover .mdc-slider__thumb-knob,.mat-mdc-slider .mdc-slider__thumb:hover .mdc-slider__thumb--top.mdc-slider__thumb--focused .mdc-slider__thumb-knob{border-color:#fff}.mat-mdc-slider .mdc-slider__thumb--focused .mdc-slider__thumb-knob{background-color:var(--mdc-slider-focus-handle-color);border-color:var(--mdc-slider-focus-handle-color)}.mat-mdc-slider .mdc-slider__thumb--focused .mdc-slider__thumb--top .mdc-slider__thumb-knob,.mat-mdc-slider .mdc-slider__thumb--focused .mdc-slider__thumb--top.mdc-slider__thumb:hover .mdc-slider__thumb-knob,.mat-mdc-slider .mdc-slider__thumb--focused .mdc-slider__thumb--top.mdc-slider__thumb--focused .mdc-slider__thumb-knob{border-color:#fff}.mat-mdc-slider .mdc-slider__thumb:not(:disabled):active .mdc-slider__thumb--top .mdc-slider__thumb-knob,.mat-mdc-slider .mdc-slider__thumb:not(:disabled):active .mdc-slider__thumb--top.mdc-slider__thumb:hover .mdc-slider__thumb-knob,.mat-mdc-slider .mdc-slider__thumb:not(:disabled):active .mdc-slider__thumb--top.mdc-slider__thumb--focused .mdc-slider__thumb-knob{border-color:#fff}.mat-mdc-slider .mdc-slider__thumb--top .mdc-slider__thumb-knob,.mat-mdc-slider .mdc-slider__thumb--top.mdc-slider__thumb:hover .mdc-slider__thumb-knob,.mat-mdc-slider .mdc-slider__thumb--top.mdc-slider__thumb--focused .mdc-slider__thumb-knob{border-color:var(--mdc-slider-with-overlap-handle-outline-color);border-width:var(--mdc-slider-with-overlap-handle-outline-width)}.mat-mdc-slider .mdc-slider__thumb-knob{box-shadow:var(--mdc-slider-handle-elevation)}.mat-mdc-slider .mdc-slider__input{box-sizing:content-box;pointer-events:auto}.mat-mdc-slider .mdc-slider__input.mat-mdc-slider-input-no-pointer-events{pointer-events:none}.mat-mdc-slider .mdc-slider__input.mat-slider__right-input{left:auto;right:0}.mat-mdc-slider .mdc-slider__thumb,.mat-mdc-slider .mdc-slider__track--active_fill{transition-duration:0ms}.mat-mdc-slider.mat-mdc-slider-with-animation .mdc-slider__thumb,.mat-mdc-slider.mat-mdc-slider-with-animation .mdc-slider__track--active_fill{transition-duration:80ms}.mat-mdc-slider.mdc-slider--discrete .mdc-slider__thumb,.mat-mdc-slider.mdc-slider--discrete .mdc-slider__track--active_fill{transition-duration:0ms}.mat-mdc-slider.mat-mdc-slider-with-animation .mdc-slider__thumb,.mat-mdc-slider.mat-mdc-slider-with-animation .mdc-slider__track--active_fill{transition-duration:80ms}.mat-mdc-slider .mdc-slider__track,.mat-mdc-slider .mdc-slider__thumb{pointer-events:none}.mat-mdc-slider .mdc-slider__value-indicator{opacity:var(--mat-slider-value-indicator-opacity)}.mat-mdc-slider .mat-ripple .mat-ripple-element{background-color:var(--mat-mdc-slider-ripple-color, transparent)}.mat-mdc-slider .mat-ripple .mat-mdc-slider-hover-ripple{background-color:var(--mat-mdc-slider-hover-ripple-color, transparent)}.mat-mdc-slider .mat-ripple .mat-mdc-slider-focus-ripple,.mat-mdc-slider .mat-ripple .mat-mdc-slider-active-ripple{background-color:var(--mat-mdc-slider-focus-ripple-color, transparent)}.mat-mdc-slider._mat-animation-noopable.mdc-slider--discrete .mdc-slider__thumb,.mat-mdc-slider._mat-animation-noopable.mdc-slider--discrete .mdc-slider__track--active_fill,.mat-mdc-slider._mat-animation-noopable .mdc-slider__value-indicator{transition:none}.mat-mdc-slider .mat-mdc-focus-indicator::before{border-radius:50%}.mat-mdc-slider .mdc-slider__value-indicator{word-break:normal}.mdc-slider__thumb--focused .mat-mdc-focus-indicator::before{content:\"\"}"],
  encapsulation: 2,
  changeDetection: 0
});
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](MatSlider, [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Component,
    args: [{
      selector: 'mat-slider',
      host: {
        'class': 'mat-mdc-slider mdc-slider',
        '[class.mdc-slider--range]': '_isRange',
        '[class.mdc-slider--disabled]': 'disabled',
        '[class.mdc-slider--discrete]': 'discrete',
        '[class.mdc-slider--tick-marks]': 'showTickMarks',
        '[class._mat-animation-noopable]': '_noopAnimations'
      },
      exportAs: 'matSlider',
      changeDetection: _angular_core__WEBPACK_IMPORTED_MODULE_0__.ChangeDetectionStrategy.OnPush,
      encapsulation: _angular_core__WEBPACK_IMPORTED_MODULE_0__.ViewEncapsulation.None,
      inputs: ['color', 'disableRipple'],
      providers: [{
        provide: MAT_SLIDER,
        useExisting: MatSlider
      }],
      template: "<!-- Inputs -->\n<ng-content></ng-content>\n\n<!-- Track -->\n<div class=\"mdc-slider__track\">\n  <div class=\"mdc-slider__track--inactive\"></div>\n  <div class=\"mdc-slider__track--active\">\n    <div #trackActive class=\"mdc-slider__track--active_fill\"></div>\n  </div>\n  @if (showTickMarks) {\n    <div class=\"mdc-slider__tick-marks\" #tickMarkContainer>\n      @if (_cachedWidth) {\n        @for (tickMark of _tickMarks; track tickMark; let i = $index) {\n          <div\n            [class]=\"tickMark === 0 ? 'mdc-slider__tick-mark--active' : 'mdc-slider__tick-mark--inactive'\"\n            [style.transform]=\"_calcTickMarkTransform(i)\"></div>\n        }\n      }\n    </div>\n  }\n</div>\n\n<!-- Thumbs -->\n@if (_isRange) {\n  <mat-slider-visual-thumb\n    [discrete]=\"discrete\"\n    [thumbPosition]=\"1\"\n    [valueIndicatorText]=\"startValueIndicatorText\">\n  </mat-slider-visual-thumb>\n}\n\n<mat-slider-visual-thumb\n  [discrete]=\"discrete\"\n  [thumbPosition]=\"2\"\n  [valueIndicatorText]=\"endValueIndicatorText\">\n</mat-slider-visual-thumb>\n",
      styles: [".mdc-slider{cursor:pointer;height:48px;margin:0 24px;position:relative;touch-action:pan-y}.mdc-slider .mdc-slider__track{position:absolute;top:50%;transform:translateY(-50%);width:100%}.mdc-slider .mdc-slider__track--active,.mdc-slider .mdc-slider__track--inactive{display:flex;height:100%;position:absolute;width:100%}.mdc-slider .mdc-slider__track--active{overflow:hidden}.mdc-slider .mdc-slider__track--active_fill{border-top-style:solid;box-sizing:border-box;height:100%;width:100%;position:relative;-webkit-transform-origin:left;transform-origin:left}[dir=rtl] .mdc-slider .mdc-slider__track--active_fill,.mdc-slider .mdc-slider__track--active_fill[dir=rtl]{-webkit-transform-origin:right;transform-origin:right}.mdc-slider .mdc-slider__track--inactive{left:0;top:0}.mdc-slider .mdc-slider__track--inactive::before{position:absolute;box-sizing:border-box;width:100%;height:100%;top:0;left:0;border:1px solid rgba(0,0,0,0);border-radius:inherit;content:\"\";pointer-events:none}@media screen and (forced-colors: active){.mdc-slider .mdc-slider__track--inactive::before{border-color:CanvasText}}.mdc-slider .mdc-slider__value-indicator-container{bottom:44px;left:50%;left:var(--slider-value-indicator-container-left, 50%);pointer-events:none;position:absolute;right:var(--slider-value-indicator-container-right);transform:translateX(-50%);transform:var(--slider-value-indicator-container-transform, translateX(-50%))}.mdc-slider .mdc-slider__value-indicator{transition:transform 100ms 0ms cubic-bezier(0.4, 0, 1, 1);align-items:center;border-radius:4px;display:flex;height:32px;padding:0 12px;transform:scale(0);transform-origin:bottom}.mdc-slider .mdc-slider__value-indicator::before{border-left:6px solid rgba(0,0,0,0);border-right:6px solid rgba(0,0,0,0);border-top:6px solid;bottom:-5px;content:\"\";height:0;left:50%;left:var(--slider-value-indicator-caret-left, 50%);position:absolute;right:var(--slider-value-indicator-caret-right);transform:translateX(-50%);transform:var(--slider-value-indicator-caret-transform, translateX(-50%));width:0}.mdc-slider .mdc-slider__value-indicator::after{position:absolute;box-sizing:border-box;width:100%;height:100%;top:0;left:0;border:1px solid rgba(0,0,0,0);border-radius:inherit;content:\"\";pointer-events:none}@media screen and (forced-colors: active){.mdc-slider .mdc-slider__value-indicator::after{border-color:CanvasText}}.mdc-slider .mdc-slider__thumb--with-indicator .mdc-slider__value-indicator-container{pointer-events:auto}.mdc-slider .mdc-slider__thumb--with-indicator .mdc-slider__value-indicator{transition:transform 100ms 0ms cubic-bezier(0, 0, 0.2, 1);transform:scale(1)}@media(prefers-reduced-motion){.mdc-slider .mdc-slider__value-indicator,.mdc-slider .mdc-slider__thumb--with-indicator .mdc-slider__value-indicator{transition:none}}.mdc-slider .mdc-slider__thumb{display:flex;left:-24px;outline:none;position:absolute;user-select:none;height:48px;width:48px}.mdc-slider .mdc-slider__thumb--top{z-index:1}.mdc-slider .mdc-slider__thumb--top .mdc-slider__thumb-knob,.mdc-slider .mdc-slider__thumb--top.mdc-slider__thumb:hover .mdc-slider__thumb-knob,.mdc-slider .mdc-slider__thumb--top.mdc-slider__thumb--focused .mdc-slider__thumb-knob{border-style:solid;border-width:1px;box-sizing:content-box}.mdc-slider .mdc-slider__thumb-knob{box-sizing:border-box;left:50%;position:absolute;top:50%;transform:translate(-50%, -50%)}.mdc-slider .mdc-slider__tick-marks{align-items:center;box-sizing:border-box;display:flex;height:100%;justify-content:space-between;padding:0 1px;position:absolute;width:100%}.mdc-slider--discrete .mdc-slider__thumb,.mdc-slider--discrete .mdc-slider__track--active_fill{transition:transform 80ms ease}@media(prefers-reduced-motion){.mdc-slider--discrete .mdc-slider__thumb,.mdc-slider--discrete .mdc-slider__track--active_fill{transition:none}}.mdc-slider--disabled{cursor:auto}.mdc-slider--disabled .mdc-slider__thumb{pointer-events:none}.mdc-slider__input{cursor:pointer;left:2px;margin:0;height:44px;opacity:0;pointer-events:none;position:absolute;top:2px;width:44px}.mat-mdc-slider{display:inline-block;box-sizing:border-box;outline:none;vertical-align:middle;margin-left:8px;margin-right:8px;width:auto;min-width:112px;-webkit-tap-highlight-color:rgba(0,0,0,0)}.mat-mdc-slider .mdc-slider__thumb-knob{background-color:var(--mdc-slider-handle-color);border-color:var(--mdc-slider-handle-color)}.mat-mdc-slider .mdc-slider__thumb--top .mdc-slider__thumb-knob,.mat-mdc-slider .mdc-slider__thumb--top.mdc-slider__thumb:hover .mdc-slider__thumb-knob,.mat-mdc-slider .mdc-slider__thumb--top.mdc-slider__thumb--focused .mdc-slider__thumb-knob{border-color:#fff}.mat-mdc-slider.mdc-slider--disabled .mdc-slider__thumb-knob{background-color:var(--mdc-slider-disabled-handle-color);border-color:var(--mdc-slider-disabled-handle-color)}.mat-mdc-slider.mdc-slider--disabled .mdc-slider__thumb--top .mdc-slider__thumb-knob,.mat-mdc-slider.mdc-slider--disabled .mdc-slider__thumb--top.mdc-slider__thumb:hover .mdc-slider__thumb-knob,.mat-mdc-slider.mdc-slider--disabled .mdc-slider__thumb--top.mdc-slider__thumb--focused .mdc-slider__thumb-knob{border-color:#fff}.mat-mdc-slider .mdc-slider__thumb::before,.mat-mdc-slider .mdc-slider__thumb::after{background-color:var(--mdc-slider-handle-color)}.mat-mdc-slider .mdc-slider__thumb:hover::before,.mat-mdc-slider .mdc-slider__thumb.mdc-ripple-surface--hover::before{opacity:var(--mdc-ripple-hover-opacity)}.mat-mdc-slider .mdc-slider__thumb.mdc-ripple-upgraded--background-focused::before,.mat-mdc-slider .mdc-slider__thumb:not(.mdc-ripple-upgraded):focus::before{transition-duration:75ms;opacity:var(--mdc-ripple-focus-opacity)}.mat-mdc-slider .mdc-slider__thumb:not(.mdc-ripple-upgraded)::after{transition:opacity 150ms linear}.mat-mdc-slider .mdc-slider__thumb:not(.mdc-ripple-upgraded):active::after{transition-duration:75ms;opacity:var(--mdc-ripple-press-opacity)}.mat-mdc-slider .mdc-slider__thumb.mdc-ripple-upgraded{--mdc-ripple-fg-opacity:var(--mdc-ripple-press-opacity)}.mat-mdc-slider .mdc-slider__track--active_fill{border-color:var(--mdc-slider-active-track-color)}.mat-mdc-slider.mdc-slider--disabled .mdc-slider__track--active_fill{border-color:var(--mdc-slider-disabled-active-track-color)}.mat-mdc-slider .mdc-slider__track--inactive{background-color:var(--mdc-slider-inactive-track-color);opacity:.24}.mat-mdc-slider.mdc-slider--disabled .mdc-slider__track--inactive{background-color:var(--mdc-slider-disabled-inactive-track-color);opacity:.24}.mat-mdc-slider .mdc-slider__tick-mark--active{background-color:var(--mdc-slider-with-tick-marks-active-container-color);opacity:var(--mdc-slider-with-tick-marks-active-container-opacity)}.mat-mdc-slider.mdc-slider--disabled .mdc-slider__tick-mark--active{background-color:var(--mdc-slider-with-tick-marks-active-container-color);opacity:var(--mdc-slider-with-tick-marks-active-container-opacity)}.mat-mdc-slider .mdc-slider__tick-mark--inactive{background-color:var(--mdc-slider-with-tick-marks-inactive-container-color);opacity:var(--mdc-slider-with-tick-marks-inactive-container-opacity)}.mat-mdc-slider.mdc-slider--disabled .mdc-slider__tick-mark--inactive{background-color:var(--mdc-slider-with-tick-marks-disabled-container-color);opacity:var(--mdc-slider-with-tick-marks-inactive-container-opacity)}.mat-mdc-slider .mdc-slider__value-indicator{background-color:var(--mdc-slider-label-container-color);opacity:1}.mat-mdc-slider .mdc-slider__value-indicator::before{border-top-color:var(--mdc-slider-label-container-color)}.mat-mdc-slider .mdc-slider__value-indicator{color:var(--mdc-slider-label-label-text-color)}.mat-mdc-slider .mdc-slider__track{height:var(--mdc-slider-inactive-track-height)}.mat-mdc-slider .mdc-slider__track--active{height:var(--mdc-slider-active-track-height);top:calc((var(--mdc-slider-inactive-track-height) - var(--mdc-slider-active-track-height)) / 2)}.mat-mdc-slider .mdc-slider__track--active_fill{border-top-width:var(--mdc-slider-active-track-height)}.mat-mdc-slider .mdc-slider__track--inactive{height:var(--mdc-slider-inactive-track-height)}.mat-mdc-slider .mdc-slider__tick-mark--active,.mat-mdc-slider .mdc-slider__tick-mark--inactive{height:var(--mdc-slider-with-tick-marks-container-size);width:var(--mdc-slider-with-tick-marks-container-size)}.mat-mdc-slider.mdc-slider--disabled{opacity:0.38}.mat-mdc-slider .mdc-slider__value-indicator-text{letter-spacing:var(--mdc-slider-label-label-text-tracking);font-size:var(--mdc-slider-label-label-text-size);font-family:var(--mdc-slider-label-label-text-font);font-weight:var(--mdc-slider-label-label-text-weight);line-height:var(--mdc-slider-label-label-text-line-height)}.mat-mdc-slider .mdc-slider__track--active{border-radius:var(--mdc-slider-active-track-shape)}.mat-mdc-slider .mdc-slider__track--inactive{border-radius:var(--mdc-slider-inactive-track-shape)}.mat-mdc-slider .mdc-slider__thumb-knob{border-radius:var(--mdc-slider-handle-shape);width:var(--mdc-slider-handle-width);height:var(--mdc-slider-handle-height);border-style:solid;border-width:calc(var(--mdc-slider-handle-height) / 2) calc(var(--mdc-slider-handle-width) / 2)}.mat-mdc-slider .mdc-slider__tick-mark--active,.mat-mdc-slider .mdc-slider__tick-mark--inactive{border-radius:var(--mdc-slider-with-tick-marks-container-shape)}.mat-mdc-slider .mdc-slider__thumb:hover .mdc-slider__thumb-knob{background-color:var(--mdc-slider-hover-handle-color);border-color:var(--mdc-slider-hover-handle-color)}.mat-mdc-slider .mdc-slider__thumb:hover .mdc-slider__thumb--top .mdc-slider__thumb-knob,.mat-mdc-slider .mdc-slider__thumb:hover .mdc-slider__thumb--top.mdc-slider__thumb:hover .mdc-slider__thumb-knob,.mat-mdc-slider .mdc-slider__thumb:hover .mdc-slider__thumb--top.mdc-slider__thumb--focused .mdc-slider__thumb-knob{border-color:#fff}.mat-mdc-slider .mdc-slider__thumb--focused .mdc-slider__thumb-knob{background-color:var(--mdc-slider-focus-handle-color);border-color:var(--mdc-slider-focus-handle-color)}.mat-mdc-slider .mdc-slider__thumb--focused .mdc-slider__thumb--top .mdc-slider__thumb-knob,.mat-mdc-slider .mdc-slider__thumb--focused .mdc-slider__thumb--top.mdc-slider__thumb:hover .mdc-slider__thumb-knob,.mat-mdc-slider .mdc-slider__thumb--focused .mdc-slider__thumb--top.mdc-slider__thumb--focused .mdc-slider__thumb-knob{border-color:#fff}.mat-mdc-slider .mdc-slider__thumb:not(:disabled):active .mdc-slider__thumb--top .mdc-slider__thumb-knob,.mat-mdc-slider .mdc-slider__thumb:not(:disabled):active .mdc-slider__thumb--top.mdc-slider__thumb:hover .mdc-slider__thumb-knob,.mat-mdc-slider .mdc-slider__thumb:not(:disabled):active .mdc-slider__thumb--top.mdc-slider__thumb--focused .mdc-slider__thumb-knob{border-color:#fff}.mat-mdc-slider .mdc-slider__thumb--top .mdc-slider__thumb-knob,.mat-mdc-slider .mdc-slider__thumb--top.mdc-slider__thumb:hover .mdc-slider__thumb-knob,.mat-mdc-slider .mdc-slider__thumb--top.mdc-slider__thumb--focused .mdc-slider__thumb-knob{border-color:var(--mdc-slider-with-overlap-handle-outline-color);border-width:var(--mdc-slider-with-overlap-handle-outline-width)}.mat-mdc-slider .mdc-slider__thumb-knob{box-shadow:var(--mdc-slider-handle-elevation)}.mat-mdc-slider .mdc-slider__input{box-sizing:content-box;pointer-events:auto}.mat-mdc-slider .mdc-slider__input.mat-mdc-slider-input-no-pointer-events{pointer-events:none}.mat-mdc-slider .mdc-slider__input.mat-slider__right-input{left:auto;right:0}.mat-mdc-slider .mdc-slider__thumb,.mat-mdc-slider .mdc-slider__track--active_fill{transition-duration:0ms}.mat-mdc-slider.mat-mdc-slider-with-animation .mdc-slider__thumb,.mat-mdc-slider.mat-mdc-slider-with-animation .mdc-slider__track--active_fill{transition-duration:80ms}.mat-mdc-slider.mdc-slider--discrete .mdc-slider__thumb,.mat-mdc-slider.mdc-slider--discrete .mdc-slider__track--active_fill{transition-duration:0ms}.mat-mdc-slider.mat-mdc-slider-with-animation .mdc-slider__thumb,.mat-mdc-slider.mat-mdc-slider-with-animation .mdc-slider__track--active_fill{transition-duration:80ms}.mat-mdc-slider .mdc-slider__track,.mat-mdc-slider .mdc-slider__thumb{pointer-events:none}.mat-mdc-slider .mdc-slider__value-indicator{opacity:var(--mat-slider-value-indicator-opacity)}.mat-mdc-slider .mat-ripple .mat-ripple-element{background-color:var(--mat-mdc-slider-ripple-color, transparent)}.mat-mdc-slider .mat-ripple .mat-mdc-slider-hover-ripple{background-color:var(--mat-mdc-slider-hover-ripple-color, transparent)}.mat-mdc-slider .mat-ripple .mat-mdc-slider-focus-ripple,.mat-mdc-slider .mat-ripple .mat-mdc-slider-active-ripple{background-color:var(--mat-mdc-slider-focus-ripple-color, transparent)}.mat-mdc-slider._mat-animation-noopable.mdc-slider--discrete .mdc-slider__thumb,.mat-mdc-slider._mat-animation-noopable.mdc-slider--discrete .mdc-slider__track--active_fill,.mat-mdc-slider._mat-animation-noopable .mdc-slider__value-indicator{transition:none}.mat-mdc-slider .mat-mdc-focus-indicator::before{border-radius:50%}.mat-mdc-slider .mdc-slider__value-indicator{word-break:normal}.mdc-slider__thumb--focused .mat-mdc-focus-indicator::before{content:\"\"}"]
    }]
  }], () => [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.NgZone
  }, {
    type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.ChangeDetectorRef
  }, {
    type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.ElementRef
  }, {
    type: _angular_cdk_bidi__WEBPACK_IMPORTED_MODULE_4__.Directionality,
    decorators: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Optional
    }]
  }, {
    type: undefined,
    decorators: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Optional
    }, {
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Inject,
      args: [_angular_material_core__WEBPACK_IMPORTED_MODULE_1__.MAT_RIPPLE_GLOBAL_OPTIONS]
    }]
  }, {
    type: undefined,
    decorators: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Optional
    }, {
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Inject,
      args: [_angular_core__WEBPACK_IMPORTED_MODULE_0__.ANIMATION_MODULE_TYPE]
    }]
  }], {
    _trackActive: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.ViewChild,
      args: ['trackActive']
    }],
    _thumbs: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.ViewChildren,
      args: [MAT_SLIDER_VISUAL_THUMB]
    }],
    _input: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.ContentChild,
      args: [MAT_SLIDER_THUMB]
    }],
    _inputs: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.ContentChildren,
      args: [MAT_SLIDER_RANGE_THUMB, {
        descendants: false
      }]
    }],
    disabled: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    discrete: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    showTickMarks: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    min: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    max: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    step: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    displayWith: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }]
  });
})();
/** Ensures that there is not an invalid configuration for the slider thumb inputs. */
function _validateInputs(isRange, endInputElement, startInputElement) {
  const startValid = !isRange || (startInputElement === null || startInputElement === void 0 ? void 0 : startInputElement._hostElement.hasAttribute('matSliderStartThumb'));
  const endValid = endInputElement._hostElement.hasAttribute(isRange ? 'matSliderEndThumb' : 'matSliderThumb');
  if (!startValid || !endValid) {
    _throwInvalidInputConfigurationError();
  }
}
function _throwInvalidInputConfigurationError() {
  throw Error(`Invalid slider thumb input configuration!

   Valid configurations are as follows:

     <mat-slider>
       <input matSliderThumb>
     </mat-slider>

     or

     <mat-slider>
       <input matSliderStartThumb>
       <input matSliderEndThumb>
     </mat-slider>
   `);
}

/**
 * Provider that allows the slider thumb to register as a ControlValueAccessor.
 * @docs-private
 */
const MAT_SLIDER_THUMB_VALUE_ACCESSOR = {
  provide: _angular_forms__WEBPACK_IMPORTED_MODULE_5__.NG_VALUE_ACCESSOR,
  useExisting: (0,_angular_core__WEBPACK_IMPORTED_MODULE_0__.forwardRef)(() => MatSliderThumb),
  multi: true
};
/**
 * Provider that allows the range slider thumb to register as a ControlValueAccessor.
 * @docs-private
 */
const MAT_SLIDER_RANGE_THUMB_VALUE_ACCESSOR = {
  provide: _angular_forms__WEBPACK_IMPORTED_MODULE_5__.NG_VALUE_ACCESSOR,
  useExisting: (0,_angular_core__WEBPACK_IMPORTED_MODULE_0__.forwardRef)(() => MatSliderRangeThumb),
  multi: true
};
/**
 * Directive that adds slider-specific behaviors to an input element inside `<mat-slider>`.
 * Up to two may be placed inside of a `<mat-slider>`.
 *
 * If one is used, the selector `matSliderThumb` must be used, and the outcome will be a normal
 * slider. If two are used, the selectors `matSliderStartThumb` and `matSliderEndThumb` must be
 * used, and the outcome will be a range slider with two slider thumbs.
 */
class MatSliderThumb {
  get value() {
    return (0,_angular_cdk_coercion__WEBPACK_IMPORTED_MODULE_2__.coerceNumberProperty)(this._hostElement.value);
  }
  set value(v) {
    const val = (0,_angular_cdk_coercion__WEBPACK_IMPORTED_MODULE_2__.coerceNumberProperty)(v).toString();
    if (!this._hasSetInitialValue) {
      this._initialValue = val;
      return;
    }
    if (this._isActive) {
      return;
    }
    this._hostElement.value = val;
    this._updateThumbUIByValue();
    this._slider._onValueChange(this);
    this._cdr.detectChanges();
    this._slider._cdr.markForCheck();
  }
  /**
   * The current translateX in px of the slider visual thumb.
   * @docs-private
   */
  get translateX() {
    if (this._slider.min >= this._slider.max) {
      this._translateX = 0;
      return this._translateX;
    }
    if (this._translateX === undefined) {
      this._translateX = this._calcTranslateXByValue();
    }
    return this._translateX;
  }
  set translateX(v) {
    this._translateX = v;
  }
  /** @docs-private */
  get min() {
    return (0,_angular_cdk_coercion__WEBPACK_IMPORTED_MODULE_2__.coerceNumberProperty)(this._hostElement.min);
  }
  set min(v) {
    this._hostElement.min = (0,_angular_cdk_coercion__WEBPACK_IMPORTED_MODULE_2__.coerceNumberProperty)(v).toString();
    this._cdr.detectChanges();
  }
  /** @docs-private */
  get max() {
    return (0,_angular_cdk_coercion__WEBPACK_IMPORTED_MODULE_2__.coerceNumberProperty)(this._hostElement.max);
  }
  set max(v) {
    this._hostElement.max = (0,_angular_cdk_coercion__WEBPACK_IMPORTED_MODULE_2__.coerceNumberProperty)(v).toString();
    this._cdr.detectChanges();
  }
  get step() {
    return (0,_angular_cdk_coercion__WEBPACK_IMPORTED_MODULE_2__.coerceNumberProperty)(this._hostElement.step);
  }
  set step(v) {
    this._hostElement.step = (0,_angular_cdk_coercion__WEBPACK_IMPORTED_MODULE_2__.coerceNumberProperty)(v).toString();
    this._cdr.detectChanges();
  }
  /** @docs-private */
  get disabled() {
    return (0,_angular_cdk_coercion__WEBPACK_IMPORTED_MODULE_2__.coerceBooleanProperty)(this._hostElement.disabled);
  }
  set disabled(v) {
    this._hostElement.disabled = (0,_angular_cdk_coercion__WEBPACK_IMPORTED_MODULE_2__.coerceBooleanProperty)(v);
    this._cdr.detectChanges();
    if (this._slider.disabled !== this.disabled) {
      this._slider.disabled = this.disabled;
    }
  }
  /** The percentage of the slider that coincides with the value. */
  get percentage() {
    if (this._slider.min >= this._slider.max) {
      return this._slider._isRtl ? 1 : 0;
    }
    return (this.value - this._slider.min) / (this._slider.max - this._slider.min);
  }
  /** @docs-private */
  get fillPercentage() {
    if (!this._slider._cachedWidth) {
      return this._slider._isRtl ? 1 : 0;
    }
    if (this._translateX === 0) {
      return 0;
    }
    return this.translateX / this._slider._cachedWidth;
  }
  /** Used to relay updates to _isFocused to the slider visual thumbs. */
  _setIsFocused(v) {
    this._isFocused = v;
  }
  constructor(_ngZone, _elementRef, _cdr, _slider) {
    this._ngZone = _ngZone;
    this._elementRef = _elementRef;
    this._cdr = _cdr;
    this._slider = _slider;
    /** Event emitted when the `value` is changed. */
    this.valueChange = new _angular_core__WEBPACK_IMPORTED_MODULE_0__.EventEmitter();
    /** Event emitted when the slider thumb starts being dragged. */
    this.dragStart = new _angular_core__WEBPACK_IMPORTED_MODULE_0__.EventEmitter();
    /** Event emitted when the slider thumb stops being dragged. */
    this.dragEnd = new _angular_core__WEBPACK_IMPORTED_MODULE_0__.EventEmitter();
    /**
     * Indicates whether this thumb is the start or end thumb.
     * @docs-private
     */
    this.thumbPosition = 2 /* _MatThumb.END */;
    /** The radius of a native html slider's knob. */
    this._knobRadius = 8;
    /** Whether user's cursor is currently in a mouse down state on the input. */
    this._isActive = false;
    /** Whether the input is currently focused (either by tab or after clicking). */
    this._isFocused = false;
    /**
     * Whether the initial value has been set.
     * This exists because the initial value cannot be immediately set because the min and max
     * must first be relayed from the parent MatSlider component, which can only happen later
     * in the component lifecycle.
     */
    this._hasSetInitialValue = false;
    /** Emits when the component is destroyed. */
    this._destroyed = new rxjs__WEBPACK_IMPORTED_MODULE_6__.Subject();
    /**
     * Indicates whether UI updates should be skipped.
     *
     * This flag is used to avoid flickering
     * when correcting values on pointer up/down.
     */
    this._skipUIUpdate = false;
    /** Callback called when the slider input has been touched. */
    this._onTouchedFn = () => {};
    /**
     * Whether the NgModel has been initialized.
     *
     * This flag is used to ignore ghost null calls to
     * writeValue which can break slider initialization.
     *
     * See https://github.com/angular/angular/issues/14988.
     */
    this._isControlInitialized = false;
    this._platform = (0,_angular_core__WEBPACK_IMPORTED_MODULE_0__.inject)(_angular_cdk_platform__WEBPACK_IMPORTED_MODULE_3__.Platform);
    this._hostElement = _elementRef.nativeElement;
    this._ngZone.runOutsideAngular(() => {
      this._hostElement.addEventListener('pointerdown', this._onPointerDown.bind(this));
      this._hostElement.addEventListener('pointermove', this._onPointerMove.bind(this));
      this._hostElement.addEventListener('pointerup', this._onPointerUp.bind(this));
    });
  }
  ngOnDestroy() {
    this._hostElement.removeEventListener('pointerdown', this._onPointerDown);
    this._hostElement.removeEventListener('pointermove', this._onPointerMove);
    this._hostElement.removeEventListener('pointerup', this._onPointerUp);
    this._destroyed.next();
    this._destroyed.complete();
    this.dragStart.complete();
    this.dragEnd.complete();
  }
  /** @docs-private */
  initProps() {
    this._updateWidthInactive();
    // If this or the parent slider is disabled, just make everything disabled.
    if (this.disabled !== this._slider.disabled) {
      // The MatSlider setter for disabled will relay this and disable both inputs.
      this._slider.disabled = true;
    }
    this.step = this._slider.step;
    this.min = this._slider.min;
    this.max = this._slider.max;
    this._initValue();
  }
  /** @docs-private */
  initUI() {
    this._updateThumbUIByValue();
  }
  _initValue() {
    this._hasSetInitialValue = true;
    if (this._initialValue === undefined) {
      this.value = this._getDefaultValue();
    } else {
      this._hostElement.value = this._initialValue;
      this._updateThumbUIByValue();
      this._slider._onValueChange(this);
      this._cdr.detectChanges();
    }
  }
  _getDefaultValue() {
    return this.min;
  }
  _onBlur() {
    this._setIsFocused(false);
    this._onTouchedFn();
  }
  _onFocus() {
    this._setIsFocused(true);
  }
  _onChange() {
    this.valueChange.emit(this.value);
    // only used to handle the edge case where user
    // mousedown on the slider then uses arrow keys.
    if (this._isActive) {
      this._updateThumbUIByValue({
        withAnimation: true
      });
    }
  }
  _onInput() {
    var _this$_onChangeFn;
    (_this$_onChangeFn = this._onChangeFn) === null || _this$_onChangeFn === void 0 || _this$_onChangeFn.call(this, this.value);
    // handles arrowing and updating the value when
    // a step is defined.
    if (this._slider.step || !this._isActive) {
      this._updateThumbUIByValue({
        withAnimation: true
      });
    }
    this._slider._onValueChange(this);
  }
  _onNgControlValueChange() {
    // only used to handle when the value change
    // originates outside of the slider.
    if (!this._isActive || !this._isFocused) {
      this._slider._onValueChange(this);
      this._updateThumbUIByValue();
    }
    this._slider.disabled = this._formControl.disabled;
  }
  _onPointerDown(event) {
    if (this.disabled || event.button !== 0) {
      return;
    }
    // On IOS, dragging only works if the pointer down happens on the
    // slider thumb and the slider does not receive focus from pointer events.
    if (this._platform.IOS) {
      const isCursorOnSliderThumb = this._slider._isCursorOnSliderThumb(event, this._slider._getThumb(this.thumbPosition)._hostElement.getBoundingClientRect());
      this._isActive = isCursorOnSliderThumb;
      this._updateWidthActive();
      this._slider._updateDimensions();
      return;
    }
    this._isActive = true;
    this._setIsFocused(true);
    this._updateWidthActive();
    this._slider._updateDimensions();
    // Does nothing if a step is defined because we
    // want the value to snap to the values on input.
    if (!this._slider.step) {
      this._updateThumbUIByPointerEvent(event, {
        withAnimation: true
      });
    }
    if (!this.disabled) {
      this._handleValueCorrection(event);
      this.dragStart.emit({
        source: this,
        parent: this._slider,
        value: this.value
      });
    }
  }
  /**
   * Corrects the value of the slider on pointer up/down.
   *
   * Called on pointer down and up because the value is set based
   * on the inactive width instead of the active width.
   */
  _handleValueCorrection(event) {
    // Don't update the UI with the current value! The value on pointerdown
    // and pointerup is calculated in the split second before the input(s)
    // resize. See _updateWidthInactive() and _updateWidthActive() for more
    // details.
    this._skipUIUpdate = true;
    // Note that this function gets triggered before the actual value of the
    // slider is updated. This means if we were to set the value here, it
    // would immediately be overwritten. Using setTimeout ensures the setting
    // of the value happens after the value has been updated by the
    // pointerdown event.
    setTimeout(() => {
      this._skipUIUpdate = false;
      this._fixValue(event);
    }, 0);
  }
  /** Corrects the value of the slider based on the pointer event's position. */
  _fixValue(event) {
    var _this$_onChangeFn2;
    const xPos = event.clientX - this._slider._cachedLeft;
    const width = this._slider._cachedWidth;
    const step = this._slider.step === 0 ? 1 : this._slider.step;
    const numSteps = Math.floor((this._slider.max - this._slider.min) / step);
    const percentage = this._slider._isRtl ? 1 - xPos / width : xPos / width;
    // To ensure the percentage is rounded to the necessary number of decimals.
    const fixedPercentage = Math.round(percentage * numSteps) / numSteps;
    const impreciseValue = fixedPercentage * (this._slider.max - this._slider.min) + this._slider.min;
    const value = Math.round(impreciseValue / step) * step;
    const prevValue = this.value;
    if (value === prevValue) {
      // Because we prevented UI updates, if it turns out that the race
      // condition didn't happen and the value is already correct, we
      // have to apply the ui updates now.
      this._slider._onValueChange(this);
      this._slider.step > 0 ? this._updateThumbUIByValue() : this._updateThumbUIByPointerEvent(event, {
        withAnimation: this._slider._hasAnimation
      });
      return;
    }
    this.value = value;
    this.valueChange.emit(this.value);
    (_this$_onChangeFn2 = this._onChangeFn) === null || _this$_onChangeFn2 === void 0 || _this$_onChangeFn2.call(this, this.value);
    this._slider._onValueChange(this);
    this._slider.step > 0 ? this._updateThumbUIByValue() : this._updateThumbUIByPointerEvent(event, {
      withAnimation: this._slider._hasAnimation
    });
  }
  _onPointerMove(event) {
    // Again, does nothing if a step is defined because
    // we want the value to snap to the values on input.
    if (!this._slider.step && this._isActive) {
      this._updateThumbUIByPointerEvent(event);
    }
  }
  _onPointerUp() {
    if (this._isActive) {
      this._isActive = false;
      this.dragEnd.emit({
        source: this,
        parent: this._slider,
        value: this.value
      });
      // This setTimeout is to prevent the pointerup from triggering a value
      // change on the input based on the inactive width. It's not clear why
      // but for some reason on IOS this race condition is even more common so
      // the timeout needs to be increased.
      setTimeout(() => this._updateWidthInactive(), this._platform.IOS ? 10 : 0);
    }
  }
  _clamp(v) {
    return Math.max(Math.min(v, this._slider._cachedWidth), 0);
  }
  _calcTranslateXByValue() {
    if (this._slider._isRtl) {
      return (1 - this.percentage) * this._slider._cachedWidth;
    }
    return this.percentage * this._slider._cachedWidth;
  }
  _calcTranslateXByPointerEvent(event) {
    return event.clientX - this._slider._cachedLeft;
  }
  /**
   * Used to set the slider width to the correct
   * dimensions while the user is dragging.
   */
  _updateWidthActive() {
    this._hostElement.style.padding = `0 ${this._slider._inputPadding}px`;
    this._hostElement.style.width = `calc(100% + ${this._slider._inputPadding}px)`;
  }
  /**
   * Sets the slider input to disproportionate dimensions to allow for touch
   * events to be captured on touch devices.
   */
  _updateWidthInactive() {
    this._hostElement.style.padding = '0px';
    this._hostElement.style.width = 'calc(100% + 48px)';
    this._hostElement.style.left = '-24px';
  }
  _updateThumbUIByValue(options) {
    this.translateX = this._clamp(this._calcTranslateXByValue());
    this._updateThumbUI(options);
  }
  _updateThumbUIByPointerEvent(event, options) {
    this.translateX = this._clamp(this._calcTranslateXByPointerEvent(event));
    this._updateThumbUI(options);
  }
  _updateThumbUI(options) {
    this._slider._setTransition(!!(options !== null && options !== void 0 && options.withAnimation));
    this._slider._onTranslateXChange(this);
  }
  /**
   * Sets the input's value.
   * @param value The new value of the input
   * @docs-private
   */
  writeValue(value) {
    if (this._isControlInitialized || value !== null) {
      this.value = value;
    }
  }
  /**
   * Registers a callback to be invoked when the input's value changes from user input.
   * @param fn The callback to register
   * @docs-private
   */
  registerOnChange(fn) {
    this._onChangeFn = fn;
    this._isControlInitialized = true;
  }
  /**
   * Registers a callback to be invoked when the input is blurred by the user.
   * @param fn The callback to register
   * @docs-private
   */
  registerOnTouched(fn) {
    this._onTouchedFn = fn;
  }
  /**
   * Sets the disabled state of the slider.
   * @param isDisabled The new disabled state
   * @docs-private
   */
  setDisabledState(isDisabled) {
    this.disabled = isDisabled;
  }
  focus() {
    this._hostElement.focus();
  }
  blur() {
    this._hostElement.blur();
  }
}
_class3 = MatSliderThumb;
_class3.ɵfac = function _class3_Factory(t) {
  return new (t || _class3)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_0__.NgZone), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_0__.ElementRef), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_0__.ChangeDetectorRef), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](MAT_SLIDER));
};
_class3.ɵdir = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineDirective"]({
  type: _class3,
  selectors: [["input", "matSliderThumb", ""]],
  hostAttrs: ["type", "range", 1, "mdc-slider__input"],
  hostVars: 1,
  hostBindings: function _class3_HostBindings(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("change", function _class3_change_HostBindingHandler() {
        return ctx._onChange();
      })("input", function _class3_input_HostBindingHandler() {
        return ctx._onInput();
      })("blur", function _class3_blur_HostBindingHandler() {
        return ctx._onBlur();
      })("focus", function _class3_focus_HostBindingHandler() {
        return ctx._onFocus();
      });
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵattribute"]("aria-valuetext", ctx._valuetext);
    }
  },
  inputs: {
    value: "value"
  },
  outputs: {
    valueChange: "valueChange",
    dragStart: "dragStart",
    dragEnd: "dragEnd"
  },
  exportAs: ["matSliderThumb"],
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵProvidersFeature"]([MAT_SLIDER_THUMB_VALUE_ACCESSOR, {
    provide: MAT_SLIDER_THUMB,
    useExisting: _class3
  }])]
});
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](MatSliderThumb, [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Directive,
    args: [{
      selector: 'input[matSliderThumb]',
      exportAs: 'matSliderThumb',
      host: {
        'class': 'mdc-slider__input',
        'type': 'range',
        '[attr.aria-valuetext]': '_valuetext',
        '(change)': '_onChange()',
        '(input)': '_onInput()',
        // TODO(wagnermaciel): Consider using a global event listener instead.
        // Reason: I have found a semi-consistent way to mouse up without triggering this event.
        '(blur)': '_onBlur()',
        '(focus)': '_onFocus()'
      },
      providers: [MAT_SLIDER_THUMB_VALUE_ACCESSOR, {
        provide: MAT_SLIDER_THUMB,
        useExisting: MatSliderThumb
      }]
    }]
  }], () => [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.NgZone
  }, {
    type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.ElementRef
  }, {
    type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.ChangeDetectorRef
  }, {
    type: undefined,
    decorators: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Inject,
      args: [MAT_SLIDER]
    }]
  }], {
    value: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    valueChange: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Output
    }],
    dragStart: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Output
    }],
    dragEnd: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Output
    }]
  });
})();
class MatSliderRangeThumb extends MatSliderThumb {
  /** @docs-private */
  getSibling() {
    if (!this._sibling) {
      this._sibling = this._slider._getInput(this._isEndThumb ? 1 /* _MatThumb.START */ : 2 /* _MatThumb.END */);
    }

    return this._sibling;
  }
  /**
   * Returns the minimum translateX position allowed for this slider input's visual thumb.
   * @docs-private
   */
  getMinPos() {
    const sibling = this.getSibling();
    if (!this._isLeftThumb && sibling) {
      return sibling.translateX;
    }
    return 0;
  }
  /**
   * Returns the maximum translateX position allowed for this slider input's visual thumb.
   * @docs-private
   */
  getMaxPos() {
    const sibling = this.getSibling();
    if (this._isLeftThumb && sibling) {
      return sibling.translateX;
    }
    return this._slider._cachedWidth;
  }
  _setIsLeftThumb() {
    this._isLeftThumb = this._isEndThumb && this._slider._isRtl || !this._isEndThumb && !this._slider._isRtl;
  }
  constructor(_ngZone, _slider, _elementRef, _cdr) {
    super(_ngZone, _elementRef, _cdr, _slider);
    this._cdr = _cdr;
    this._isEndThumb = this._hostElement.hasAttribute('matSliderEndThumb');
    this._setIsLeftThumb();
    this.thumbPosition = this._isEndThumb ? 2 /* _MatThumb.END */ : 1 /* _MatThumb.START */;
  }

  _getDefaultValue() {
    return this._isEndThumb && this._slider._isRange ? this.max : this.min;
  }
  _onInput() {
    super._onInput();
    this._updateSibling();
    if (!this._isActive) {
      this._updateWidthInactive();
    }
  }
  _onNgControlValueChange() {
    var _this$getSibling;
    super._onNgControlValueChange();
    (_this$getSibling = this.getSibling()) === null || _this$getSibling === void 0 || _this$getSibling._updateMinMax();
  }
  _onPointerDown(event) {
    if (this.disabled || event.button !== 0) {
      return;
    }
    if (this._sibling) {
      this._sibling._updateWidthActive();
      this._sibling._hostElement.classList.add('mat-mdc-slider-input-no-pointer-events');
    }
    super._onPointerDown(event);
  }
  _onPointerUp() {
    super._onPointerUp();
    if (this._sibling) {
      setTimeout(() => {
        this._sibling._updateWidthInactive();
        this._sibling._hostElement.classList.remove('mat-mdc-slider-input-no-pointer-events');
      });
    }
  }
  _onPointerMove(event) {
    super._onPointerMove(event);
    if (!this._slider.step && this._isActive) {
      this._updateSibling();
    }
  }
  _fixValue(event) {
    var _this$_sibling;
    super._fixValue(event);
    (_this$_sibling = this._sibling) === null || _this$_sibling === void 0 || _this$_sibling._updateMinMax();
  }
  _clamp(v) {
    return Math.max(Math.min(v, this.getMaxPos()), this.getMinPos());
  }
  _updateMinMax() {
    const sibling = this.getSibling();
    if (!sibling) {
      return;
    }
    if (this._isEndThumb) {
      this.min = Math.max(this._slider.min, sibling.value);
      this.max = this._slider.max;
    } else {
      this.min = this._slider.min;
      this.max = Math.min(this._slider.max, sibling.value);
    }
  }
  _updateWidthActive() {
    const minWidth = this._slider._rippleRadius * 2 - this._slider._inputPadding * 2;
    const maxWidth = this._slider._cachedWidth + this._slider._inputPadding - minWidth;
    const percentage = this._slider.min < this._slider.max ? (this.max - this.min) / (this._slider.max - this._slider.min) : 1;
    const width = maxWidth * percentage + minWidth;
    this._hostElement.style.width = `${width}px`;
    this._hostElement.style.padding = `0 ${this._slider._inputPadding}px`;
  }
  _updateWidthInactive() {
    const sibling = this.getSibling();
    if (!sibling) {
      return;
    }
    const maxWidth = this._slider._cachedWidth;
    const midValue = this._isEndThumb ? this.value - (this.value - sibling.value) / 2 : this.value + (sibling.value - this.value) / 2;
    const _percentage = this._isEndThumb ? (this.max - midValue) / (this._slider.max - this._slider.min) : (midValue - this.min) / (this._slider.max - this._slider.min);
    const percentage = this._slider.min < this._slider.max ? _percentage : 1;
    // Extend the native input width by the radius of the ripple
    let ripplePadding = this._slider._rippleRadius;
    // If one of the inputs is maximally sized (the value of both thumbs is
    // equal to the min or max), make that input take up all of the width and
    // make the other unselectable.
    if (percentage === 1) {
      ripplePadding = 48;
    } else if (percentage === 0) {
      ripplePadding = 0;
    }
    const width = maxWidth * percentage + ripplePadding;
    this._hostElement.style.width = `${width}px`;
    this._hostElement.style.padding = '0px';
    if (this._isLeftThumb) {
      this._hostElement.style.left = '-24px';
      this._hostElement.style.right = 'auto';
    } else {
      this._hostElement.style.left = 'auto';
      this._hostElement.style.right = '-24px';
    }
  }
  _updateStaticStyles() {
    this._hostElement.classList.toggle('mat-slider__right-input', !this._isLeftThumb);
  }
  _updateSibling() {
    const sibling = this.getSibling();
    if (!sibling) {
      return;
    }
    sibling._updateMinMax();
    if (this._isActive) {
      sibling._updateWidthActive();
    } else {
      sibling._updateWidthInactive();
    }
  }
  /**
   * Sets the input's value.
   * @param value The new value of the input
   * @docs-private
   */
  writeValue(value) {
    if (this._isControlInitialized || value !== null) {
      this.value = value;
      this._updateWidthInactive();
      this._updateSibling();
    }
  }
}
_class4 = MatSliderRangeThumb;
_class4.ɵfac = function _class4_Factory(t) {
  return new (t || _class4)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_0__.NgZone), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](MAT_SLIDER), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_0__.ElementRef), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_0__.ChangeDetectorRef));
};
_class4.ɵdir = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineDirective"]({
  type: _class4,
  selectors: [["input", "matSliderStartThumb", ""], ["input", "matSliderEndThumb", ""]],
  exportAs: ["matSliderRangeThumb"],
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵProvidersFeature"]([MAT_SLIDER_RANGE_THUMB_VALUE_ACCESSOR, {
    provide: MAT_SLIDER_RANGE_THUMB,
    useExisting: _class4
  }]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵInheritDefinitionFeature"]]
});
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](MatSliderRangeThumb, [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Directive,
    args: [{
      selector: 'input[matSliderStartThumb], input[matSliderEndThumb]',
      exportAs: 'matSliderRangeThumb',
      providers: [MAT_SLIDER_RANGE_THUMB_VALUE_ACCESSOR, {
        provide: MAT_SLIDER_RANGE_THUMB,
        useExisting: MatSliderRangeThumb
      }]
    }]
  }], () => [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.NgZone
  }, {
    type: undefined,
    decorators: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Inject,
      args: [MAT_SLIDER]
    }]
  }, {
    type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.ElementRef
  }, {
    type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.ChangeDetectorRef
  }], null);
})();
class MatSliderModule {}
_class5 = MatSliderModule;
_class5.ɵfac = function _class5_Factory(t) {
  return new (t || _class5)();
};
_class5.ɵmod = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineNgModule"]({
  type: _class5
});
_class5.ɵinj = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjector"]({
  imports: [_angular_material_core__WEBPACK_IMPORTED_MODULE_1__.MatCommonModule, _angular_material_core__WEBPACK_IMPORTED_MODULE_1__.MatRippleModule]
});
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](MatSliderModule, [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.NgModule,
    args: [{
      imports: [_angular_material_core__WEBPACK_IMPORTED_MODULE_1__.MatCommonModule, _angular_material_core__WEBPACK_IMPORTED_MODULE_1__.MatRippleModule],
      exports: [MatSlider, MatSliderThumb, MatSliderRangeThumb],
      declarations: [MatSlider, MatSliderThumb, MatSliderRangeThumb, MatSliderVisualThumb]
    }]
  }], null, null);
})();

/**
 * Generated bundle index. Do not edit.
 */



/***/ })

}]);
//# sourceMappingURL=apps_bfswap_src_app_tabs_tabs_component_ts.js.map