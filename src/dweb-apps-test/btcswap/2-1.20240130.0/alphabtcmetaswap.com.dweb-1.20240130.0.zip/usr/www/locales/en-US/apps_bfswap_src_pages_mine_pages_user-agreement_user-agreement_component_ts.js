"use strict";
(self["webpackChunkbfswap"] = self["webpackChunkbfswap"] || []).push([["apps_bfswap_src_pages_mine_pages_user-agreement_user-agreement_component_ts"],{

/***/ 20070:
/*!*************************************************************************************!*\
  !*** ./apps/bfswap/src/pages/mine/pages/user-agreement/user-agreement.component.ts ***!
  \*************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   UserAgreementPage: () => (/* binding */ UserAgreementPage),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 52542);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! tslib */ 90505);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 6729);
/* harmony import */ var _modules_page_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ~modules/page.module */ 16381);
/* harmony import */ var showdown__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! showdown */ 52161);
/* harmony import */ var showdown__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(showdown__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 61039);
/* harmony import */ var _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../../../../libs/bnf/modules/page/common-page/common-page.component */ 62052);

var _class;






/** 用户协议 */
class UserAgreementPage extends _modules_page_module__WEBPACK_IMPORTED_MODULE_1__.CommonPageBase {
  constructor() {
    super(...arguments);
    /** 解析用户协议 */
    this.makeHtml = '';
  }
  /** 加载内容 */
  /**
   * 用户协议初始化
   */
  init() {
    var _this = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const content = yield fetch('./assets/user-agreement-cn.md').then(res => res.text());
      const converter = new (showdown__WEBPACK_IMPORTED_MODULE_2___default().Converter)();
      _this.makeHtml = converter.makeHtml(content);
    })();
  }
}
_class = UserAgreementPage;
_class.ɵfac = /*@__PURE__*/(() => {
  let ɵUserAgreementPage_BaseFactory;
  return function UserAgreementPage_Factory(t) {
    return (ɵUserAgreementPage_BaseFactory || (ɵUserAgreementPage_BaseFactory = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵgetInheritedFactory"](_class)))(t || _class);
  };
})();
_class.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineComponent"]({
  type: _class,
  selectors: [["bs-mine-user-agreement"]],
  standalone: true,
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵInheritDefinitionFeature"], _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵStandaloneFeature"]],
  decls: 2,
  vars: 2,
  consts: [[3, "contentBackground"], [1, "markdowm-view", 3, "innerHtml"]],
  template: function UserAgreementPage_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "common-page", 0);
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](1, "div", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("contentBackground", "env");
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("innerHtml", ctx.makeHtml, _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵsanitizeHtml"]);
    }
  },
  dependencies: [_modules_page_module__WEBPACK_IMPORTED_MODULE_1__.CommonPageModule, _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_3__.CommonPageComponent, _angular_common__WEBPACK_IMPORTED_MODULE_5__.CommonModule],
  styles: [".markdowm-view[_ngcontent-%COMP%]     {\n    word-break: break-all\n}\n.markdowm-view[_ngcontent-%COMP%]     h1 {\n    margin-top: 2rem;\n    text-align: center;\n    font-size: 1rem;\n    font-weight: 600;\n    font-style: italic;\n    line-height: 2.5rem;\n    --tw-text-opacity: 1;\n    color: rgb(34 34 34 / var(--tw-text-opacity))\n}\n.markdowm-view[_ngcontent-%COMP%]     blockquote p {\n    margin-bottom: 1.5rem;\n    text-align: center;\n    font-size: 0.75rem;\n    line-height: 1rem;\n    --tw-text-opacity: 1;\n    color: rgb(193 193 193 / var(--tw-text-opacity))\n}\n.markdowm-view[_ngcontent-%COMP%]     p {\n    margin-left: 1.25rem;\n    margin-right: 1.25rem;\n    text-align: left;\n    font-size: 0.75rem;\n    line-height: 1.5rem;\n    --tw-text-opacity: 1;\n    color: rgb(124 124 124 / var(--tw-text-opacity))\n}\n.markdowm-view[_ngcontent-%COMP%]     h2 {\n    margin-left: 1.25rem;\n    margin-right: 1.25rem;\n    margin-bottom: 0.5rem;\n    margin-top: 1.5rem;\n    font-size: 0.875rem;\n    line-height: 1.25rem;\n    font-weight: 600;\n    --tw-text-opacity: 1;\n    color: rgb(34 34 34 / var(--tw-text-opacity))\n}\n.markdowm-view[_ngcontent-%COMP%]     h3, .markdowm-view[_ngcontent-%COMP%]     h4 {\n    margin-left: 1.25rem;\n    margin-right: 1.25rem;\n    margin-bottom: 0.5rem;\n    margin-top: 1.5rem;\n    font-size: 0.875rem;\n    line-height: 1.25rem;\n    font-weight: 600;\n    --tw-text-opacity: 1;\n    color: rgb(34 34 34 / var(--tw-text-opacity))\n}\n.markdowm-view[_ngcontent-%COMP%]     ol {\n    margin-left: 1.25rem;\n    margin-right: 1.25rem;\n    --tw-text-opacity: 1;\n    color: rgb(124 124 124 / var(--tw-text-opacity))\n}\n.markdowm-view[_ngcontent-%COMP%]     ul {\n    margin-bottom: 0.5rem;\n    margin-left: 2.5rem;\n    margin-right: 1.25rem;\n    margin-top: 1.5rem;\n    list-style-type: disc;\n    text-align: left;\n    font-size: 0.75rem;\n    line-height: 1.5rem;\n    --tw-text-opacity: 1;\n    color: rgb(124 124 124 / var(--tw-text-opacity))\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL2FwcHMvYmZzd2FwL3NyYy9wYWdlcy9taW5lL3BhZ2VzL3VzZXItYWdyZWVtZW50L3VzZXItYWdyZWVtZW50LmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUNFO0lBQUE7QUFBQTtBQUdFO0lBQUEsZ0JBQUE7SUFBQSxrQkFBQTtJQUFBLGVBQUE7SUFBQSxnQkFBQTtJQUFBLGtCQUFBO0lBQUEsbUJBQUE7SUFBQSxvQkFBQTtJQUFBO0FBQUE7QUFJQTtJQUFBLHFCQUFBO0lBQUEsa0JBQUE7SUFBQSxrQkFBQTtJQUFBLGlCQUFBO0lBQUEsb0JBQUE7SUFBQTtBQUFBO0FBSUE7SUFBQSxvQkFBQTtJQUFBLHFCQUFBO0lBQUEsZ0JBQUE7SUFBQSxrQkFBQTtJQUFBLG1CQUFBO0lBQUEsb0JBQUE7SUFBQTtBQUFBO0FBSUE7SUFBQSxvQkFBQTtJQUFBLHFCQUFBO0lBQUEscUJBQUE7SUFBQSxrQkFBQTtJQUFBLG1CQUFBO0lBQUEsb0JBQUE7SUFBQSxnQkFBQTtJQUFBLG9CQUFBO0lBQUE7QUFBQTtBQUtBOztJQUFBLG9CQUFBO0lBQUEscUJBQUE7SUFBQSxxQkFBQTtJQUFBLGtCQUFBO0lBQUEsbUJBQUE7SUFBQSxvQkFBQTtJQUFBLGdCQUFBO0lBQUEsb0JBQUE7SUFBQTtBQUFBO0FBSUE7SUFBQSxvQkFBQTtJQUFBLHFCQUFBO0lBQUEsb0JBQUE7SUFBQTtBQUFBO0FBSUE7SUFBQSxxQkFBQTtJQUFBLG1CQUFBO0lBQUEscUJBQUE7SUFBQSxrQkFBQTtJQUFBLHFCQUFBO0lBQUEsZ0JBQUE7SUFBQSxrQkFBQTtJQUFBLG1CQUFBO0lBQUEsb0JBQUE7SUFBQTtBQUFBIiwic291cmNlc0NvbnRlbnQiOlsiLm1hcmtkb3dtLXZpZXcgOjpuZy1kZWVwIHtcclxuICBAYXBwbHkgYnJlYWstYWxsO1xyXG5cclxuICBoMSB7XHJcbiAgICBAYXBwbHkgdGV4dC10aXRsZSBtdC04IHRleHQtY2VudGVyIHRleHQtYmFzZSBmb250LXNlbWlib2xkIGl0YWxpYyBsZWFkaW5nLTEwO1xyXG4gIH1cclxuXHJcbiAgYmxvY2txdW90ZSBwIHtcclxuICAgIEBhcHBseSB0ZXh0LXN1YnRleHQgbWItNiB0ZXh0LWNlbnRlciB0ZXh0LXhzO1xyXG4gIH1cclxuXHJcbiAgcCB7XHJcbiAgICBAYXBwbHkgdGV4dC10ZXh0IG14LTUgdGV4dC1sZWZ0IHRleHQteHMgbGVhZGluZy02O1xyXG4gIH1cclxuXHJcbiAgaDIge1xyXG4gICAgQGFwcGx5IHRleHQtdGl0bGUgbXgtNSBtYi0yIG10LTYgdGV4dC1zbSBmb250LXNlbWlib2xkO1xyXG4gIH1cclxuXHJcbiAgaDMsXHJcbiAgaDQge1xyXG4gICAgQGFwcGx5IHRleHQtdGl0bGUgbXgtNSBtYi0yIG10LTYgdGV4dC1zbSBmb250LXNlbWlib2xkO1xyXG4gIH1cclxuXHJcbiAgb2wge1xyXG4gICAgQGFwcGx5IHRleHQtdGV4dCBteC01O1xyXG4gIH1cclxuXHJcbiAgdWwge1xyXG4gICAgQGFwcGx5IHRleHQtdGV4dCBtYi0yIG1sLTEwIG1yLTUgbXQtNiBsaXN0LWRpc2MgdGV4dC1sZWZ0IHRleHQteHMgbGVhZGluZy02O1xyXG4gIH1cclxufVxyXG4iXSwic291cmNlUm9vdCI6IiJ9 */"],
  changeDetection: 0
});
(0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([UserAgreementPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__metadata)("design:type", Object)], UserAgreementPage.prototype, "makeHtml", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([UserAgreementPage.OnInit(), (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__metadata)("design:returntype", Promise)], UserAgreementPage.prototype, "init", null);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (UserAgreementPage);

/***/ })

}]);
//# sourceMappingURL=apps_bfswap_src_pages_mine_pages_user-agreement_user-agreement_component_ts.js.map