"use strict";
(self["webpackChunkbfswap"] = self["webpackChunkbfswap"] || []).push([["apps_bfswap_src_pages_mine_pages_my-record-swap-detail_my-record-swap-detail_component_ts"],{

/***/ 11342:
/*!*********************************************************************************************!*\
  !*** ./apps/bfswap/src/components/token-with-chain-icon/token-with-chain-icon.component.ts ***!
  \*********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   TokenWithnChainIconComponent: () => (/* binding */ TokenWithnChainIconComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! tslib */ 90505);
/* harmony import */ var _bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @bnqkl/bnqkl-swap-core */ 70195);
/* harmony import */ var _services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ~services/wallet/wallet.helper */ 84813);
/* harmony import */ var _modules_comp_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ~modules/comp.module */ 58281);
/* harmony import */ var _modules_page_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ~modules/page.module */ 16381);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 61039);
/* harmony import */ var _icon_icon_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../icon/icon.component */ 18840);
var _class;







function TokenWithnChainIconComponent_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](1, "bs-icon", 1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵstyleMap"](ctx_r0.sizeClass.chainTranslate);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵstyleMap"](ctx_r0.sizeClass.chainSize);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("name", ctx_r0.chainName);
  }
}
/** Token和chain组合图标 */
class TokenWithnChainIconComponent extends _modules_comp_module__WEBPACK_IMPORTED_MODULE_2__.CommonCompBase {
  constructor() {
    super(...arguments);
    /** token的大小 */
    this.tokenSize = 'icon-8';
    /** chain的大小 */
    this.chainSize = 'icon-4';
    /** 尺寸默认32 */
    this.size = 0;
    /** 尺寸样式 */
    this.sizeClass = {
      chainSize: 'font-size:1rem',
      coinSize: 'font-size:2rem',
      chainTranslate: 'transform: translate(6px,8px)'
    };
  }
  /** 初始化参数 */
  init() {
    this.handleIcon();
    this.handleSize();
  }
  /** 处理尺寸 */
  handleSize() {
    const {
      size
    } = this;
    if (size > 0) {
      const CHAINSIZE = 16;
      const COINSIZE = 32;
      const TRANSLATEX = 6;
      const TRANSLATEY = 8;
      const times = size / COINSIZE;
      this.sizeClass.chainSize = `font-size:${CHAINSIZE * times}px`;
      this.sizeClass.coinSize = `font-size:${COINSIZE * times}px`;
      this.sizeClass.chainTranslate = `transform: translate(${TRANSLATEX * times}px,${TRANSLATEY * times}px)`;
    }
  }
  /** 处理图标名称 */
  handleIcon() {
    const {
      swapChainName,
      swapCoinName
    } = this;
    if (swapChainName) {
      const chainName = swapChainName in _bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_0__.BNQKL_SWAP_CHAIN_NAME ? _services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_1__.NODE_CHAIN_NAME_TRANSFER[swapChainName] : swapChainName;
      const chainIcon = (0,_services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_1__.transferToChainIcon)(chainName);
      this.chainName = chainIcon;
      if (swapCoinName) {
        const coinIcon = (0,_services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_1__.transferToTokenIconBychainName)(chainName, swapCoinName);
        this.tokenName = coinIcon;
      }
    }
  }
}
_class = TokenWithnChainIconComponent;
_class.ɵfac = /*@__PURE__*/(() => {
  let ɵTokenWithnChainIconComponent_BaseFactory;
  return function TokenWithnChainIconComponent_Factory(t) {
    return (ɵTokenWithnChainIconComponent_BaseFactory || (ɵTokenWithnChainIconComponent_BaseFactory = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵgetInheritedFactory"](_class)))(t || _class);
  };
})();
_class.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineComponent"]({
  type: _class,
  selectors: [["bs-token-with-chain-icon"]],
  inputs: {
    tokenSize: "tokenSize",
    tokenName: "tokenName",
    chainSize: "chainSize",
    chainName: "chainName",
    size: "size",
    swapChainName: "swapChainName",
    swapCoinName: "swapCoinName"
  },
  standalone: true,
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵInheritDefinitionFeature"], _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵStandaloneFeature"]],
  decls: 3,
  vars: 4,
  consts: [[1, "relative", "flex", "items-center", "justify-center"], [3, "name"], ["class", "bg-blue-10 rounded-1 absolute bottom-0 right-0 flex  items-center justify-center border-[2px] border-white", 3, "style"], [1, "bg-blue-10", "rounded-1", "absolute", "bottom-0", "right-0", "flex", "items-center", "justify-center", "border-[2px]", "border-white"]],
  template: function TokenWithnChainIconComponent_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 0);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](1, "bs-icon", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](2, TokenWithnChainIconComponent_Conditional_2_Template, 2, 5, "div", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵstyleMap"](ctx.sizeClass.coinSize);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("name", ctx.tokenName);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵconditional"](2, ctx.chainName ? 2 : -1);
    }
  },
  dependencies: [_modules_page_module__WEBPACK_IMPORTED_MODULE_3__.CommonPageModule, _icon_icon_component__WEBPACK_IMPORTED_MODULE_4__.IconComponent],
  encapsulation: 2,
  changeDetection: 0
});
(0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([TokenWithnChainIconComponent.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__metadata)("design:type", Object)], TokenWithnChainIconComponent.prototype, "sizeClass", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([TokenWithnChainIconComponent.OnChanges(), (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__metadata)("design:returntype", void 0)], TokenWithnChainIconComponent.prototype, "init", null);

/***/ }),

/***/ 53505:
/*!***************************************************************************************************!*\
  !*** ./apps/bfswap/src/pages/mine/pages/my-record-swap-detail/my-record-swap-detail.component.ts ***!
  \***************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   MyRecordSwapDetailPage: () => (/* binding */ MyRecordSwapDetailPage),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 52542);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! tslib */ 90505);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! @angular/common */ 6729);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! @angular/core */ 61039);
/* harmony import */ var _components_token_with_chain_icon_token_with_chain_icon_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ~components/token-with-chain-icon/token-with-chain-icon.component */ 11342);
/* harmony import */ var _modules_page_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ~modules/page.module */ 16381);
/* harmony import */ var _services_liquidity_order_liquidity_order_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ~services/liquidity-order/liquidity-order.service */ 84435);
/* harmony import */ var _services_transaction_settings_transaction_settings_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ~services/transaction-settings/transaction-settings.service */ 80348);
/* harmony import */ var _services_wallet_wallet_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ~services/wallet/wallet.service */ 54275);
/* harmony import */ var _bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @bnqkl/bnqkl-swap-core */ 70195);
/* harmony import */ var _pipes_chain_name_transfer_chain_name_transfer_pipe__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ~pipes/chain-name-transfer/chain-name-transfer.pipe */ 37514);
/* harmony import */ var _pipes_record_state_record_state_img_pipe__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ~pipes/record-state/record-state-img.pipe */ 24787);
/* harmony import */ var _components_related_events_related_events_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ~components/related-events/related-events.component */ 40941);
/* harmony import */ var _services_liquidity_order_lquidity_order_type__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ~services/liquidity-order/lquidity-order.type */ 84601);
/* harmony import */ var _services_liquidity_pool_liquidity_pool_helper__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ~services/liquidity-pool/liquidity-pool.helper */ 17827);
/* harmony import */ var _bnqkl_framework_pipes__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @bnqkl/framework/pipes */ 80909);
/* harmony import */ var _pipes_record_state_record_state_pipe__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ~pipes/record-state/record-state.pipe */ 7372);
/* harmony import */ var _pipes_percentage_transfer_percentage_transfer_pipe__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ~pipes/percentage-transfer/percentage-transfer.pipe */ 1726);
/* harmony import */ var _components_swap_token_chain_icon_swap_token_chain_icon_component__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ~components/swap-token-chain-icon/swap-token-chain-icon.component */ 26193);
/* harmony import */ var _libs_bnf_directives_click_to_copy_directive__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ../../../../../../../libs/bnf/directives/click-to-copy.directive */ 46413);
/* harmony import */ var _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ../../../../../../../libs/bnf/modules/page/common-page/common-page.component */ 62052);
/* harmony import */ var _components_icon_icon_component__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ../../../../components/icon/icon.component */ 18840);
/* harmony import */ var _libs_bnf_pipes_amountFixed_amount_fixed_pipe__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ../../../../../../../libs/bnf/pipes/amountFixed/amount-fixed.pipe */ 44070);

var _class;
























function MyRecordSwapDetailPage_Conditional_2_Conditional_14_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](0, "div", 38)(1, "div", 39);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵi18n"](2, 40);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](3, "div", 41);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtextInterpolate"](ctx_r2.detail == null ? null : ctx_r2.detail.failureReason);
  }
}
const _c26 = () => ({
  removeZero: true
});
function MyRecordSwapDetailPage_Conditional_2_Conditional_42_Template(rf, ctx) {
  if (rf & 1) {
    const _r7 = _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](0, "div", 42)(1, "div", 43)(2, "div", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelement"](3, "bs-swap-token-chain-icon", 44);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](4, "span", 45);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtext"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](6, "div", 46);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelement"](7, "bs-swap-token-chain-icon", 47);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](8, "span", 48);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtext"](9);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵpipe"](10, "chainNameTransfer");
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](11, "div", 49);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtext"](12);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵpipe"](13, "amountFixed");
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](14, "div", 50);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelement"](15, "bs-icon", 51);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](16, "div", 43);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelement"](17, "bs-swap-token-chain-icon", 44);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](18, "span", 45);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtext"](19);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](20, "div", 46);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelement"](21, "bs-swap-token-chain-icon", 47);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](22, "span", 48);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtext"](23);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵpipe"](24, "chainNameTransfer");
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](25, "div", 49);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtext"](26);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵpipe"](27, "amountFixed");
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](28, "div", 52)(29, "div", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵi18n"](30, 53);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](31, "div", 54);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtext"](32);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](33, "bs-icon", 55);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵlistener"]("click", function MyRecordSwapDetailPage_Conditional_2_Conditional_42_Template_bs_icon_click_33_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵrestoreView"](_r7);
      const ctx_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵresetView"](ctx_r6.handleReversePrice(ctx_r6.PRICE_TYPE.EXPECT));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](34, "div", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵi18n"](35, 56);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵpipe"](36, "percentageTransfer");
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](37, "div", 57);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtext"](38);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵpipe"](39, "amountFixed");
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](40, "div", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵi18n"](41, 58);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](42, "div", 57);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtext"](43);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](44, "div", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵi18n"](45, 59);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](46, "div", 57);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵi18n"](47, 60);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵproperty"]("swapCoinName", ctx_r3.anchorTran == null ? null : ctx_r3.anchorTran.coinName)("swapChainName", ctx_r3.anchorTran == null ? null : ctx_r3.anchorTran.chainName);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtextInterpolate1"](" ", ctx_r3.anchorTran == null ? null : ctx_r3.anchorTran.coinName, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵproperty"]("swapChainName", ctx_r3.anchorTran == null ? null : ctx_r3.anchorTran.chainName);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵpipeBind1"](10, 20, ctx_r3.anchorTran == null ? null : ctx_r3.anchorTran.chainName), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵpipeBind3"](13, 22, ctx_r3.anchorTran == null ? null : ctx_r3.anchorTran.amount, 8, _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵpureFunction0"](38, _c26)), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵproperty"]("swapCoinName", ctx_r3.quoteTran == null ? null : ctx_r3.quoteTran.coinName)("swapChainName", ctx_r3.quoteTran == null ? null : ctx_r3.quoteTran.chainName);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtextInterpolate1"](" ", ctx_r3.quoteTran == null ? null : ctx_r3.quoteTran.coinName, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵproperty"]("swapChainName", ctx_r3.quoteTran == null ? null : ctx_r3.quoteTran.chainName);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵpipeBind1"](24, 26, ctx_r3.quoteTran == null ? null : ctx_r3.quoteTran.chainName), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵpipeBind3"](27, 28, ctx_r3.detail == null ? null : ctx_r3.detail.quoteCoinsAmount, 8, _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵpureFunction0"](39, _c26)), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtextInterpolate3"](" 1 ", ctx_r3.expectPrice.leftCoin, " = ", ctx_r3.expectPrice.showPrice, " ", ctx_r3.expectPrice.rightCoin, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵi18nExp"](_angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵpipeBind1"](36, 32, ctx_r3.detail == null ? null : ctx_r3.detail.feeRatio1));
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵi18nApply"](35);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtextInterpolate2"](" ", (ctx_r3.detail == null ? null : ctx_r3.detail.platformFee1) ? _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵpipeBind3"](39, 34, ctx_r3.detail == null ? null : ctx_r3.detail.platformFee1, 8, _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵpureFunction0"](40, _c26)) : "", " ", ctx_r3.anchorTran == null ? null : ctx_r3.anchorTran.coinName, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtextInterpolate1"]("", ctx_r3.slippage, "%");
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵi18nExp"](ctx_r3.endTime);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵi18nApply"](47);
  }
}
function MyRecordSwapDetailPage_Conditional_2_Conditional_48_For_5_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](0, "div", 67);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵpipe"](2, "amountFixed");
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelement"](3, "bs-token-with-chain-icon", 68)(4, "bs-token-with-chain-icon", 68);
  }
  if (rf & 2) {
    const item_r9 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵpipeBind3"](2, 7, item_r9.expectLpCoinsAmount, 8, _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵpureFunction0"](11, _c26)), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵproperty"]("size", 24)("swapChainName", item_r9.anchorCoinsChainName)("swapCoinName", item_r9.anchorCoinsName);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵproperty"]("size", 24)("swapChainName", item_r9.quoteCoinsChainName)("swapCoinName", item_r9.quoteCoinsName);
  }
}
function MyRecordSwapDetailPage_Conditional_2_Conditional_48_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](0, "div", 61)(1, "div", 62);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵi18n"](2, 63);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](3, "div", 64);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵrepeaterCreate"](4, MyRecordSwapDetailPage_Conditional_2_Conditional_48_For_5_Template, 5, 12, null, null, _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵrepeaterTrackByIndex"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](6, "div", 65)(7, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵi18n"](8, 66);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](9, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtext"](10);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵpipe"](11, "percentageTransfer");
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵrepeater"](ctx_r4.detail == null ? null : ctx_r4.detail.increasedLiquidityList);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵpipeBind1"](11, 1, ctx_r4.detail == null ? null : ctx_r4.detail.increasedLiquidityRatio));
  }
}
function MyRecordSwapDetailPage_Conditional_2_Conditional_49_Conditional_27_Template(rf, ctx) {
  if (rf & 1) {
    const _r18 = _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](0, "div", 42)(1, "div", 43)(2, "div", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelement"](3, "bs-swap-token-chain-icon", 44);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](4, "span", 45);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtext"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](6, "div", 46);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelement"](7, "bs-swap-token-chain-icon", 47);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](8, "span", 48);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtext"](9);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵpipe"](10, "chainNameTransfer");
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](11, "div", 49);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtext"](12);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵpipe"](13, "amountFixed");
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](14, "div", 50);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelement"](15, "bs-icon", 51);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](16, "div", 43);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelement"](17, "bs-swap-token-chain-icon", 44);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](18, "span", 45);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtext"](19);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](20, "div", 46);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelement"](21, "bs-swap-token-chain-icon", 47);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](22, "span", 48);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtext"](23);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵpipe"](24, "chainNameTransfer");
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](25, "div", 49);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtext"](26);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵpipe"](27, "amountFixed");
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](28, "div", 52)(29, "div", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵi18n"](30, 76);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](31, "div", 54);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtext"](32);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](33, "bs-icon", 55);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵlistener"]("click", function MyRecordSwapDetailPage_Conditional_2_Conditional_49_Conditional_27_Template_bs_icon_click_33_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵrestoreView"](_r18);
      const ctx_r17 = _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵnextContext"](3);
      return _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵresetView"](ctx_r17.handleReversePrice(ctx_r17.PRICE_TYPE.EXPECT));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](34, "div", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵi18n"](35, 77);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵpipe"](36, "percentageTransfer");
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](37, "div", 57);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtext"](38);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵpipe"](39, "amountFixed");
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r14 = _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵproperty"]("swapCoinName", ctx_r14.anchorTran == null ? null : ctx_r14.anchorTran.coinName)("swapChainName", ctx_r14.anchorTran == null ? null : ctx_r14.anchorTran.chainName);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtextInterpolate1"](" ", ctx_r14.anchorTran == null ? null : ctx_r14.anchorTran.coinName, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵproperty"]("swapChainName", ctx_r14.anchorTran == null ? null : ctx_r14.anchorTran.chainName);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵpipeBind1"](10, 18, ctx_r14.anchorTran == null ? null : ctx_r14.anchorTran.chainName), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵpipeBind3"](13, 20, ctx_r14.anchorTran == null ? null : ctx_r14.anchorTran.amount, 8, _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵpureFunction0"](36, _c26)), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵproperty"]("swapCoinName", ctx_r14.quoteTran == null ? null : ctx_r14.quoteTran.coinName)("swapChainName", ctx_r14.quoteTran == null ? null : ctx_r14.quoteTran.chainName);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtextInterpolate1"](" ", ctx_r14.quoteTran == null ? null : ctx_r14.quoteTran.coinName, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵproperty"]("swapChainName", ctx_r14.quoteTran == null ? null : ctx_r14.quoteTran.chainName);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵpipeBind1"](24, 24, ctx_r14.quoteTran == null ? null : ctx_r14.quoteTran.chainName), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵpipeBind3"](27, 26, ctx_r14.quoteTran == null ? null : ctx_r14.quoteTran.amount, 8, _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵpureFunction0"](37, _c26)), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtextInterpolate3"](" 1 ", ctx_r14.expectPrice.leftCoin, " = ", ctx_r14.expectPrice.showPrice, " ", ctx_r14.expectPrice.rightCoin, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵi18nExp"](_angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵpipeBind1"](36, 30, ctx_r14.detail == null ? null : ctx_r14.detail.feeRatio1));
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵi18nApply"](35);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtextInterpolate2"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵpipeBind3"](39, 32, ctx_r14.detail == null ? null : ctx_r14.detail.platformFee1, 8, _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵpureFunction0"](38, _c26)), " ", ctx_r14.anchorTran == null ? null : ctx_r14.anchorTran.coinName, " ");
  }
}
function MyRecordSwapDetailPage_Conditional_2_Conditional_49_For_38_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](0, "div", 67);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵpipe"](2, "amountFixed");
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelement"](3, "bs-token-with-chain-icon", 24)(4, "bs-token-with-chain-icon", 24);
  }
  if (rf & 2) {
    const item_r19 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵpipeBind3"](2, 7, item_r19.lpCoinsAmount, 8, _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵpureFunction0"](11, _c26)));
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵproperty"]("size", 24)("swapCoinName", item_r19.anchorCoinsName)("swapChainName", item_r19.anchorCoinsChainName);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵproperty"]("size", 24)("swapCoinName", item_r19.quoteCoinsName)("swapChainName", item_r19.quoteCoinsChainName);
  }
}
function MyRecordSwapDetailPage_Conditional_2_Conditional_49_Conditional_39_For_7_Conditional_17_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](0, "div", 87);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelement"](1, "bs-swap-token-chain-icon", 47);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](2, "span", 88);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵpipe"](4, "chainNameTransfer");
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const increasedLiquidity_r25 = _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵproperty"]("swapChainName", increasedLiquidity_r25.quoteCoinsChainName);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵpipeBind1"](4, 2, increasedLiquidity_r25.quoteCoinsChainName), " ");
  }
}
const _c49 = a0 => ({
  "mb-1": a0
});
function MyRecordSwapDetailPage_Conditional_2_Conditional_49_Conditional_39_For_7_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](0, "div", 80)(1, "div", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelement"](2, "bs-swap-token-chain-icon", 44);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](3, "span", 81);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](5, "div", 46);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelement"](6, "bs-swap-token-chain-icon", 47);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](7, "span", 48);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtext"](8);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵpipe"](9, "chainNameTransfer");
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](10, "div", 82);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtext"](11);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵpipe"](12, "amountFixed");
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](13, "div", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelement"](14, "bs-swap-token-chain-icon", 44);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](15, "span", 81);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtext"](16);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtemplate"](17, MyRecordSwapDetailPage_Conditional_2_Conditional_49_Conditional_39_For_7_Conditional_17_Template, 5, 4, "div", 83);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](18, "div", 82);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtext"](19);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵpipe"](20, "amountFixed");
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](21, "div", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵi18n"](22, 84);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelement"](23, "bs-icon", 85);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](24, "div", 86);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtext"](25);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](26, "div", 82);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtext"](27);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵpipe"](28, "amountFixed");
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const increasedLiquidity_r25 = ctx.$implicit;
    const index_r26 = ctx.$index;
    const ctx_r24 = _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵnextContext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵclassMap"](_angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵpureFunction1"](30, _c49, index_r26 === 0));
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵproperty"]("swapCoinName", increasedLiquidity_r25.anchorCoinsName)("swapChainName", increasedLiquidity_r25.anchorCoinsChainName);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtextInterpolate1"](" ", increasedLiquidity_r25.anchorCoinsName, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵproperty"]("swapChainName", increasedLiquidity_r25.anchorCoinsChainName);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵpipeBind1"](9, 16, increasedLiquidity_r25.anchorCoinsChainName), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtextInterpolate1"](" - ", _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵpipeBind3"](12, 18, increasedLiquidity_r25.anchorCoinsAmount, 8, _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵpureFunction0"](32, _c26)), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵproperty"]("swapCoinName", increasedLiquidity_r25.quoteCoinsName)("swapChainName", increasedLiquidity_r25.quoteCoinsChainName);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtextInterpolate1"](" ", increasedLiquidity_r25.quoteCoinsName, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵconditional"](17, ctx_r24.noBigU(increasedLiquidity_r25.quoteCoinsChainName, increasedLiquidity_r25.quoteCoinsName) ? 17 : -1);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtextInterpolate1"](" - ", _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵpipeBind3"](20, 22, increasedLiquidity_r25.quoteCoinsAmount, 8, _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵpureFunction0"](33, _c26)), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtextInterpolate2"]("", increasedLiquidity_r25.anchorCoinsName, " - ", increasedLiquidity_r25.quoteCoinsName, "");
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtextInterpolate1"]("+", _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵpipeBind3"](28, 26, increasedLiquidity_r25.lpCoinsAmount, 8, _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵpureFunction0"](34, _c26)), "");
  }
}
function MyRecordSwapDetailPage_Conditional_2_Conditional_49_Conditional_39_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](0, "div", 78)(1, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵi18n"](2, 79);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](3, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵpipe"](5, "percentageTransfer");
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵrepeaterCreate"](6, MyRecordSwapDetailPage_Conditional_2_Conditional_49_Conditional_39_For_7_Template, 29, 35, "div", 89, _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵrepeaterTrackByIndex"]);
  }
  if (rf & 2) {
    const ctx_r16 = _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵpipeBind1"](5, 1, ctx_r16.detail == null ? null : ctx_r16.detail.increasedLiquidityRatio));
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵrepeater"](ctx_r16.detail == null ? null : ctx_r16.detail.increasedLiquidityList);
  }
}
function MyRecordSwapDetailPage_Conditional_2_Conditional_49_Template(rf, ctx) {
  if (rf & 1) {
    const _r33 = _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](0, "div", 14)(1, "div", 15)(2, "div", 69);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵi18n"](3, 70);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](4, "div", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtext"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵpipe"](6, "date");
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](7, "div", 19)(8, "div", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵi18n"](9, 71);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](10, "div", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtext"](11);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵpipe"](12, "amountFixed");
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](13, "div", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtext"](14);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelement"](15, "bs-token-with-chain-icon", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](16, "div", 25)(17, "div", 26);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵlistener"]("click", function MyRecordSwapDetailPage_Conditional_2_Conditional_49_Template_div_click_17_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵrestoreView"](_r33);
      const ctx_r32 = _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵresetView"](ctx_r32.showActualGainOne = !ctx_r32.showActualGainOne);
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](18, "div", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵi18n"](19, 72);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](20, "div", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtext"](21);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵpipe"](22, "amountFixed");
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](23, "div", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtext"](24);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelement"](25, "bs-token-with-chain-icon", 24)(26, "bs-icon", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtemplate"](27, MyRecordSwapDetailPage_Conditional_2_Conditional_49_Conditional_27_Template, 40, 39);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](28, "div", 29)(29, "div", 73);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵlistener"]("click", function MyRecordSwapDetailPage_Conditional_2_Conditional_49_Template_div_click_29_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵrestoreView"](_r33);
      const ctx_r34 = _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵresetView"](ctx_r34.showActualGainTwo = !ctx_r34.showActualGainTwo);
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](30, "div", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵi18n"](31, 74);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelement"](32, "bs-icon", 32);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](33, "div", 8)(34, "div", 62);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵi18n"](35, 75);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](36, "div", 64);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵrepeaterCreate"](37, MyRecordSwapDetailPage_Conditional_2_Conditional_49_For_38_Template, 5, 12, null, null, _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵrepeaterTrackByIndex"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtemplate"](39, MyRecordSwapDetailPage_Conditional_2_Conditional_49_Conditional_39_Template, 8, 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵpipeBind2"](6, 15, ctx_r5.detail == null ? null : ctx_r5.detail.finishTime, "yyyy.MM.dd HH:mm"));
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵpipeBind3"](12, 18, ctx_r5.anchorTran == null ? null : ctx_r5.anchorTran.amount, 8, _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵpureFunction0"](26, _c26)), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtextInterpolate"](ctx_r5.anchorTran == null ? null : ctx_r5.anchorTran.coinName);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵproperty"]("size", 24)("swapCoinName", ctx_r5.anchorTran == null ? null : ctx_r5.anchorTran.coinName)("swapChainName", ctx_r5.anchorTran == null ? null : ctx_r5.anchorTran.chainName);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵpipeBind3"](22, 22, ctx_r5.quoteTran == null ? null : ctx_r5.quoteTran.amount, 8, _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵpureFunction0"](27, _c26)), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtextInterpolate"](ctx_r5.quoteTran == null ? null : ctx_r5.quoteTran.coinName);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵproperty"]("size", 24)("swapCoinName", ctx_r5.quoteTran == null ? null : ctx_r5.quoteTran.coinName)("swapChainName", ctx_r5.quoteTran == null ? null : ctx_r5.quoteTran.chainName);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵproperty"]("name", ctx_r5.showActualGainOne ? "icon-chevron-down-small" : "icon-chevron-up-small");
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵconditional"](27, ctx_r5.showActualGainOne ? 27 : -1);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵproperty"]("name", ctx_r5.showActualGainTwo ? "icon-chevron-down-small" : "icon-chevron-up-small");
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵrepeater"](ctx_r5.detail == null ? null : ctx_r5.detail.increasedLiquidityList);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵconditional"](39, ctx_r5.showActualGainTwo ? 39 : -1);
  }
}
function MyRecordSwapDetailPage_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r36 = _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](0, "div", 3)(1, "div", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵi18n"](2, 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵpipe"](3, "recordState");
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelement"](4, "img", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵpipe"](5, "recordStateImage");
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](6, "div", 7)(7, "div", 8)(8, "div", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵi18n"](9, 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](10, "div", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtext"](11);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵpipe"](12, "addressHidden");
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelement"](13, "bs-icon", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtemplate"](14, MyRecordSwapDetailPage_Conditional_2_Conditional_14_Template, 5, 1, "div", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](15, "div", 14)(16, "div", 15)(17, "div", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵi18n"](18, 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](19, "div", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtext"](20);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵpipe"](21, "date");
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](22, "div", 19)(23, "div", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵi18n"](24, 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](25, "div", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtext"](26);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵpipe"](27, "amountFixed");
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](28, "div", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtext"](29);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelement"](30, "bs-token-with-chain-icon", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](31, "div", 25)(32, "div", 26);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵlistener"]("click", function MyRecordSwapDetailPage_Conditional_2_Template_div_click_32_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵrestoreView"](_r36);
      const ctx_r35 = _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵresetView"](ctx_r35.showExpectGainOne = !ctx_r35.showExpectGainOne);
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](33, "div", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵi18n"](34, 27);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](35, "div", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtext"](36);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵpipe"](37, "amountFixed");
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](38, "div", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtext"](39);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelement"](40, "bs-token-with-chain-icon", 24)(41, "bs-icon", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtemplate"](42, MyRecordSwapDetailPage_Conditional_2_Conditional_42_Template, 48, 41);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](43, "div", 29)(44, "div", 30);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵlistener"]("click", function MyRecordSwapDetailPage_Conditional_2_Template_div_click_44_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵrestoreView"](_r36);
      const ctx_r37 = _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵresetView"](ctx_r37.showExpectGainTwo = !ctx_r37.showExpectGainTwo);
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](45, "div", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵi18n"](46, 31);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelement"](47, "bs-icon", 32);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtemplate"](48, MyRecordSwapDetailPage_Conditional_2_Conditional_48_Template, 12, 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtemplate"](49, MyRecordSwapDetailPage_Conditional_2_Conditional_49_Template, 40, 28, "div", 33);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](50, "div", 34)(51, "div", 35);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵi18n"](52, 36);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelement"](53, "bs-related-events-component", 37);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵi18nExp"](_angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵpipeBind2"](3, 22, ctx_r0.detail == null ? null : ctx_r0.detail.state, ctx_r0.RECORDTYPE));
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵi18nApply"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵproperty"]("src", _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵpipeBind1"](5, 25, ctx_r0.detail == null ? null : ctx_r0.detail.state), _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵsanitizeUrl"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](7);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵpipeBind1"](12, 27, ctx_r0.detail == null ? null : ctx_r0.detail.orderId));
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵproperty"]("wClickToCopy", ctx_r0.detail == null ? null : ctx_r0.detail.orderId);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵconditional"](14, ctx_r0.orderState === ctx_r0.ORDER_STATE.FAIL ? 14 : -1);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵpipeBind2"](21, 29, ctx_r0.detail == null ? null : ctx_r0.detail.startTime, "yyyy.MM.dd HH:mm"));
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵpipeBind3"](27, 32, ctx_r0.anchorTran == null ? null : ctx_r0.anchorTran.amount, 8, _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵpureFunction0"](40, _c26)), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtextInterpolate"](ctx_r0.anchorTran == null ? null : ctx_r0.anchorTran.coinName);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵproperty"]("size", 24)("swapCoinName", ctx_r0.anchorTran == null ? null : ctx_r0.anchorTran.coinName)("swapChainName", ctx_r0.anchorTran == null ? null : ctx_r0.anchorTran.chainName);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵpipeBind3"](37, 36, ctx_r0.detail == null ? null : ctx_r0.detail.quoteCoinsAmount, 8, _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵpureFunction0"](41, _c26)), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtextInterpolate"](ctx_r0.quoteTran == null ? null : ctx_r0.quoteTran.coinName);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵproperty"]("size", 24)("swapCoinName", ctx_r0.quoteTran == null ? null : ctx_r0.quoteTran.coinName)("swapChainName", ctx_r0.quoteTran == null ? null : ctx_r0.quoteTran.chainName);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵproperty"]("name", ctx_r0.showExpectGainOne ? "icon-chevron-down-small" : "icon-chevron-up-small");
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵconditional"](42, ctx_r0.showExpectGainOne ? 42 : -1);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵproperty"]("name", ctx_r0.showExpectGainTwo ? "icon-chevron-down-small" : "icon-chevron-up-small");
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵconditional"](48, ctx_r0.showExpectGainTwo ? 48 : -1);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵconditional"](49, ctx_r0.orderState === ctx_r0.ORDER_STATE.SUCCESS ? 49 : -1);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵproperty"]("eventList", ctx_r0.eventList);
  }
}
function MyRecordSwapDetailPage_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](0, "div", 90);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelement"](1, "img", 91);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](2, "div", 92);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵi18n"](3, 93);
    _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]()();
  }
}
/** 交易详情页面 */
class MyRecordSwapDetailPage extends _modules_page_module__WEBPACK_IMPORTED_MODULE_2__.CommonPageBase {
  constructor() {
    super(...arguments);
    /** 订单服务 */
    this.orderService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_20__.inject)(_services_liquidity_order_liquidity_order_service__WEBPACK_IMPORTED_MODULE_3__.LiquidityOrderService);
    /** 钱包服务 */
    this.walletService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_20__.inject)(_services_wallet_wallet_service__WEBPACK_IMPORTED_MODULE_5__.WalletService);
    /** 记录的类型 */
    this.RECORDTYPE = _bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_6__.ORDER_RECORD_TYPES.EXCHANGE_COINS;
    /** 展示预期获得一 */
    this.showExpectGainOne = false;
    /** 展示预期获得二 */
    this.showExpectGainTwo = false;
    /** 展示实际获得一 */
    this.showActualGainOne = false;
    /** 展示预期获得二 */
    this.showActualGainTwo = false;
    /** 订单状态 */
    this.ORDER_STATE = _services_liquidity_order_lquidity_order_type__WEBPACK_IMPORTED_MODULE_10__.$ORDER_STATE;
    /** 价格枚举 */
    this.PRICE_TYPE = _services_liquidity_order_lquidity_order_type__WEBPACK_IMPORTED_MODULE_10__.$PRICE_TYPE;
    /** 已连接钱包 */
    this.connectedWallet = this.walletService.connectedWallet;
    /** 页面loading */
    this.loadingPage = true;
    /** 高级设置服务 */
    this.settingsService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_20__.inject)(_services_transaction_settings_transaction_settings_service__WEBPACK_IMPORTED_MODULE_4__.TransactionSettingsService);
    /** 滑点 */
    this.slippage = 0;
    /** 预计/实际 固定增流比例 */
    this.increasedLiquidityRatio = 0;
    /** 是否展开期望增流 */
    this.isDeployExpecteList = true;
    /** 是否展开实际增流 */
    this.isDeployActualList = true;
    /** 过期时间 */
    this.endTime = 0;
    /** 相关事件列表 */
    this.eventList = [];
    /** 期望价格 */
    this.expectPrice = {
      forwordPrice: '1',
      leftCoin: undefined,
      backwordPirce: '1',
      showPrice: '1',
      rightCoin: undefined
    };
    /** 实际价格 */
    this.actualPrice = {
      forwordPrice: '1',
      leftCoin: undefined,
      backwordPirce: '1',
      showPrice: '1',
      rightCoin: undefined
    };
    /** 订单的状态 */
    this.orderState = _services_liquidity_order_lquidity_order_type__WEBPACK_IMPORTED_MODULE_10__.$ORDER_STATE.FAIL;
  }
  /** 初始化 */
  iniParams() {
    const {
      params
    } = this;
    if (params) {
      const {
        orderId
      } = params;
      this.getDetail(orderId);
    }
  }
  /** 获取详情 */
  getDetail(orderId) {
    var _this = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const result = yield _this.orderService.getPoolOrderInfo(orderId);
      if (result) {
        _this.slippage = _this.settingsService.getSlippageLabelByValue(result.slippageTolerance);
        _this.endTime = _this.settingsService.getEndTimeLabelByValue(result.expirationTime - result.startTime);
        _this.increasedLiquidityRatio = _this.settingsService.getIncreasedLiquidityRatioByValue(result.increasedLiquidityRatio);
        _this.detail = result;
        _this.handleTran();
        _this.generateActualPrice();
        _this.generateExpectPrice();
        _this.handleOrderState();
        _this.handleOrderEvent(result);
        _this.loadingPage = false;
      }
    })();
  }
  /** 判断是不是USDM SWAP链 */
  noBigU(chainName, tokenName) {
    return chainName !== _bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_6__.BNQKL_SWAP_CHAIN_NAME.SWAP || tokenName !== _bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_6__.BNQKL_SWAP_COIN_NAME.USDM;
  }
  /** 生成预期价格 */
  generateExpectPrice() {
    const {
      detail
    } = this;
    if (detail === undefined) return;
    const {
      quoteCoinsAmount
    } = detail;
    const {
      anchorTran,
      quoteTran
    } = this;
    if (anchorTran === undefined || quoteTran === undefined) return;
    const {
      coinName: anchorCoinName,
      amount: anchorAmount
    } = anchorTran;
    const {
      coinName: quoteCoinName
    } = quoteTran;
    const price = (0,_services_liquidity_pool_liquidity_pool_helper__WEBPACK_IMPORTED_MODULE_11__.generatePriceUtil)(anchorCoinName, anchorAmount, quoteCoinName, quoteCoinsAmount);
    this.expectPrice = price;
  }
  /** 生成实际价格 */
  generateActualPrice() {
    const {
      anchorTran,
      quoteTran
    } = this;
    if (anchorTran === undefined || quoteTran === undefined) return;
    const {
      coinName: anchorCoinName,
      amount: anchorAmount
    } = anchorTran;
    const {
      coinName: quoteCoinName,
      amount: quoteAmount
    } = quoteTran;
    const price = (0,_services_liquidity_pool_liquidity_pool_helper__WEBPACK_IMPORTED_MODULE_11__.generatePriceUtil)(anchorCoinName, anchorAmount, quoteCoinName, quoteAmount);
    this.actualPrice = price;
  }
  /** 处理交易的数据 */
  handleTran() {
    const {
      detail
    } = this;
    if (detail === undefined) return;
    const {
      orderTransactionList,
      anchorTxId,
      quoteTxId
    } = detail;
    this.anchorTran = orderTransactionList.find(order => {
      return order.transactionId === anchorTxId;
    });
    this.quoteTran = orderTransactionList.find(order => {
      return order.transactionId === quoteTxId;
    });
  }
  /** 反转价格 */
  handleReversePrice(type) {
    const price = type === _services_liquidity_order_lquidity_order_type__WEBPACK_IMPORTED_MODULE_10__.$PRICE_TYPE.EXPECT ? this.expectPrice : this.actualPrice;
    const updatePrice = (0,_services_liquidity_pool_liquidity_pool_helper__WEBPACK_IMPORTED_MODULE_11__.reversePriceUtil)(price);
    Object.assign(price, updatePrice);
  }
  /** 订单的状态 */
  handleOrderState() {
    const {
      detail
    } = this;
    if (detail === undefined) return;
    const {
      state
    } = detail;
    const fail = _bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_6__.ORDER_RECORD_STATUS.RETURN_COMPLETE;
    const success = _bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_6__.ORDER_RECORD_STATUS.SUCCESS;
    if (state === success) {
      this.orderState = _services_liquidity_order_lquidity_order_type__WEBPACK_IMPORTED_MODULE_10__.$ORDER_STATE.SUCCESS;
      this.generateActualPrice();
    } else if (fail === state) {
      this.orderState = _services_liquidity_order_lquidity_order_type__WEBPACK_IMPORTED_MODULE_10__.$ORDER_STATE.FAIL;
    } else {
      this.orderState = _services_liquidity_order_lquidity_order_type__WEBPACK_IMPORTED_MODULE_10__.$ORDER_STATE.ING;
    }
  }
  /** 相关事件处理 */
  handleOrderEvent(detail) {
    const {
      state,
      orderTransactionList,
      anchorTxId,
      quoteTxId,
      returnAnchorTxId,
      increasedLiquidityList
    } = detail;
    const anchorTran = orderTransactionList.find(order => order.transactionId === anchorTxId);
    const quoteTran = orderTransactionList.find(order => order.transactionId === quoteTxId);
    const list = [];
    if (anchorTran) {
      list.push({
        leftName: anchorTran.coinName,
        rightName: " Liquidity pool infor ",
        txHash: anchorTran.txHash,
        state: anchorTran.state,
        chainName: anchorTran.chainName,
        isRetrun: anchorTran.type === _bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_6__.TRANSACTION_TYPE.RETURN
      });
    }
    if (quoteTran) {
      list.push({
        leftName: " Liquidity pool infor ",
        rightName: quoteTran.coinName,
        txHash: quoteTran.txHash,
        state: quoteTran.state,
        chainName: quoteTran.chainName,
        isRetrun: quoteTran.type === _bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_6__.TRANSACTION_TYPE.RETURN
      });
    }
    if (state === _bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_6__.ORDER_RECORD_STATUS.RETURN_COMPLETE || state === _bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_6__.ORDER_RECORD_STATUS.RETURN_TX_WAIT_ON_CHAIN) {
      const returnAnchorTran = orderTransactionList.find(order => order.transactionId === returnAnchorTxId);
      if (returnAnchorTran) {
        list.push({
          leftName: " Liquidity pool infor ",
          rightName: returnAnchorTran.coinName,
          txHash: returnAnchorTran.txHash,
          state: returnAnchorTran.state,
          chainName: returnAnchorTran.chainName,
          isRetrun: true
        });
      }
    }
    this.eventList = list;
  }
}
_class = MyRecordSwapDetailPage;
_class.ɵfac = /*@__PURE__*/(() => {
  let ɵMyRecordSwapDetailPage_BaseFactory;
  return function MyRecordSwapDetailPage_Factory(t) {
    return (ɵMyRecordSwapDetailPage_BaseFactory || (ɵMyRecordSwapDetailPage_BaseFactory = _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵgetInheritedFactory"](_class)))(t || _class);
  };
})();
_class.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵdefineComponent"]({
  type: _class,
  selectors: [["bs-my-record-swap-detail"]],
  standalone: true,
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵInheritDefinitionFeature"], _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵStandaloneFeature"]],
  decls: 4,
  vars: 4,
  consts: () => {
    let i18n_0;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_7130242044355020058$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_RECORD_SWAP_DETAIL_MY_RECORD_SWAP_DETAIL_COMPONENT_TS__1 = goog.getMsg(" {$interpolation} ", {
        "interpolation": "\uFFFD0\uFFFD"
      }, {
        original_code: {
          "interpolation": "{{ detail?.state | recordState : RECORDTYPE }}"
        }
      });
      i18n_0 = MSG_EXTERNAL_7130242044355020058$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_RECORD_SWAP_DETAIL_MY_RECORD_SWAP_DETAIL_COMPONENT_TS__1;
    } else {
      i18n_0 = " " + "\uFFFD0\uFFFD" + " ";
    }
    let i18n_2;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_ORDER_ID$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_RECORD_SWAP_DETAIL_MY_RECORD_SWAP_DETAIL_COMPONENT_TS__3 = goog.getMsg("Order ID");
      i18n_2 = MSG_EXTERNAL_ORDER_ID$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_RECORD_SWAP_DETAIL_MY_RECORD_SWAP_DETAIL_COMPONENT_TS__3;
    } else {
      i18n_2 = "Order ID";
    }
    let i18n_4;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_SEND_TRANSACTION$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_RECORD_SWAP_DETAIL_MY_RECORD_SWAP_DETAIL_COMPONENT_TS__5 = goog.getMsg("\u53D1\u8D77\u4EA4\u6613");
      i18n_4 = MSG_EXTERNAL_SEND_TRANSACTION$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_RECORD_SWAP_DETAIL_MY_RECORD_SWAP_DETAIL_COMPONENT_TS__5;
    } else {
      i18n_4 = "Initiated transaction";
    }
    let i18n_6;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_3863181258168496688$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_RECORD_SWAP_DETAIL_MY_RECORD_SWAP_DETAIL_COMPONENT_TS__7 = goog.getMsg("\u652F\u4ED8");
      i18n_6 = MSG_EXTERNAL_3863181258168496688$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_RECORD_SWAP_DETAIL_MY_RECORD_SWAP_DETAIL_COMPONENT_TS__7;
    } else {
      i18n_6 = "\u652F\u4ED8";
    }
    let i18n_8;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_7873689962789072606$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_RECORD_SWAP_DETAIL_MY_RECORD_SWAP_DETAIL_COMPONENT_TS__9 = goog.getMsg("\u83B7\u5F97\u4E00\uFF1A");
      i18n_8 = MSG_EXTERNAL_7873689962789072606$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_RECORD_SWAP_DETAIL_MY_RECORD_SWAP_DETAIL_COMPONENT_TS__9;
    } else {
      i18n_8 = "\u83B7\u5F97\u4E00\uFF1A";
    }
    let i18n_10;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_8333618867862558530$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_RECORD_SWAP_DETAIL_MY_RECORD_SWAP_DETAIL_COMPONENT_TS__11 = goog.getMsg("\u83B7\u5F97\u4E8C\uFF1A");
      i18n_10 = MSG_EXTERNAL_8333618867862558530$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_RECORD_SWAP_DETAIL_MY_RECORD_SWAP_DETAIL_COMPONENT_TS__11;
    } else {
      i18n_10 = "\u83B7\u5F97\u4E8C\uFF1A";
    }
    let i18n_12;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_RELATED_EVENT$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_RECORD_SWAP_DETAIL_MY_RECORD_SWAP_DETAIL_COMPONENT_TS__13 = goog.getMsg("Related events");
      i18n_12 = MSG_EXTERNAL_RELATED_EVENT$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_RECORD_SWAP_DETAIL_MY_RECORD_SWAP_DETAIL_COMPONENT_TS__13;
    } else {
      i18n_12 = "Related events";
    }
    let i18n_14;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_FAILURE_REASON$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_RECORD_SWAP_DETAIL_MY_RECORD_SWAP_DETAIL_COMPONENT_TS___15 = goog.getMsg("Failure reason");
      i18n_14 = MSG_EXTERNAL_FAILURE_REASON$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_RECORD_SWAP_DETAIL_MY_RECORD_SWAP_DETAIL_COMPONENT_TS___15;
    } else {
      i18n_14 = "Failure reason";
    }
    let i18n_16;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_SEND_PRICE$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_RECORD_SWAP_DETAIL_MY_RECORD_SWAP_DETAIL_COMPONENT_TS___17 = goog.getMsg("\u53D1\u8D77\u4EF7\u683C");
      i18n_16 = MSG_EXTERNAL_SEND_PRICE$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_RECORD_SWAP_DETAIL_MY_RECORD_SWAP_DETAIL_COMPONENT_TS___17;
    } else {
      i18n_16 = "Initiated price";
    }
    let i18n_18;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_660373910768452550$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_RECORD_SWAP_DETAIL_MY_RECORD_SWAP_DETAIL_COMPONENT_TS___19 = goog.getMsg("\u5408\u7EA6\u6C60\u624B\u7EED\u8D39({$interpolation})", {
        "interpolation": "\uFFFD0\uFFFD"
      }, {
        original_code: {
          "interpolation": "{{ detail?.feeRatio1 | percentageTransfer }}"
        }
      });
      i18n_18 = MSG_EXTERNAL_660373910768452550$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_RECORD_SWAP_DETAIL_MY_RECORD_SWAP_DETAIL_COMPONENT_TS___19;
    } else {
      i18n_18 = "\u5408\u7EA6\u6C60\u624B\u7EED\u8D39(" + "\uFFFD0\uFFFD" + ")";
    }
    let i18n_20;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_SLIPPAGE_TOLERANCE$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_RECORD_SWAP_DETAIL_MY_RECORD_SWAP_DETAIL_COMPONENT_TS___21 = goog.getMsg("Slippage Tolerance");
      i18n_20 = MSG_EXTERNAL_SLIPPAGE_TOLERANCE$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_RECORD_SWAP_DETAIL_MY_RECORD_SWAP_DETAIL_COMPONENT_TS___21;
    } else {
      i18n_20 = "Slippage Tolerance";
    }
    let i18n_22;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_DEADLINE$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_RECORD_SWAP_DETAIL_MY_RECORD_SWAP_DETAIL_COMPONENT_TS___23 = goog.getMsg("Deadline");
      i18n_22 = MSG_EXTERNAL_DEADLINE$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_RECORD_SWAP_DETAIL_MY_RECORD_SWAP_DETAIL_COMPONENT_TS___23;
    } else {
      i18n_22 = "Deadline";
    }
    let i18n_24;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_MINUTE$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_RECORD_SWAP_DETAIL_MY_RECORD_SWAP_DETAIL_COMPONENT_TS___25 = goog.getMsg("{$interpolation} Minute", {
        "interpolation": "\uFFFD0\uFFFD"
      }, {
        original_code: {
          "interpolation": "{{ endTime }}"
        }
      });
      i18n_24 = MSG_EXTERNAL_MINUTE$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_RECORD_SWAP_DETAIL_MY_RECORD_SWAP_DETAIL_COMPONENT_TS___25;
    } else {
      i18n_24 = "" + "\uFFFD0\uFFFD" + "Minute";
    }
    let i18n_27;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_2160098162517155843$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_RECORD_SWAP_DETAIL_MY_RECORD_SWAP_DETAIL_COMPONENT_TS___28 = goog.getMsg("\u5408\u7EA6\u6C60\u6743\u76CA");
      i18n_27 = MSG_EXTERNAL_2160098162517155843$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_RECORD_SWAP_DETAIL_MY_RECORD_SWAP_DETAIL_COMPONENT_TS___28;
    } else {
      i18n_27 = "\u5408\u7EA6\u6C60\u6743\u76CA";
    }
    let i18n_29;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_1203469798003655104$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_RECORD_SWAP_DETAIL_MY_RECORD_SWAP_DETAIL_COMPONENT_TS___30 = goog.getMsg("\u56FA\u5B9A\u589E\u6D41\u6BD4\u4F8B");
      i18n_29 = MSG_EXTERNAL_1203469798003655104$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_RECORD_SWAP_DETAIL_MY_RECORD_SWAP_DETAIL_COMPONENT_TS___30;
    } else {
      i18n_29 = "\u56FA\u5B9A\u589E\u6D41\u6BD4\u4F8B";
    }
    let i18n_31;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_221549116557531032$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_RECORD_SWAP_DETAIL_MY_RECORD_SWAP_DETAIL_COMPONENT_TS___32 = goog.getMsg("\u5B9E\u9645\u4EA4\u6613");
      i18n_31 = MSG_EXTERNAL_221549116557531032$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_RECORD_SWAP_DETAIL_MY_RECORD_SWAP_DETAIL_COMPONENT_TS___32;
    } else {
      i18n_31 = "\u5B9E\u9645\u4EA4\u6613";
    }
    let i18n_33;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_3863181258168496688$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_RECORD_SWAP_DETAIL_MY_RECORD_SWAP_DETAIL_COMPONENT_TS___34 = goog.getMsg("\u652F\u4ED8");
      i18n_33 = MSG_EXTERNAL_3863181258168496688$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_RECORD_SWAP_DETAIL_MY_RECORD_SWAP_DETAIL_COMPONENT_TS___34;
    } else {
      i18n_33 = "\u652F\u4ED8";
    }
    let i18n_35;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_7873689962789072606$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_RECORD_SWAP_DETAIL_MY_RECORD_SWAP_DETAIL_COMPONENT_TS___36 = goog.getMsg("\u83B7\u5F97\u4E00\uFF1A");
      i18n_35 = MSG_EXTERNAL_7873689962789072606$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_RECORD_SWAP_DETAIL_MY_RECORD_SWAP_DETAIL_COMPONENT_TS___36;
    } else {
      i18n_35 = "\u83B7\u5F97\u4E00\uFF1A";
    }
    let i18n_37;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_8333618867862558530$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_RECORD_SWAP_DETAIL_MY_RECORD_SWAP_DETAIL_COMPONENT_TS___38 = goog.getMsg("\u83B7\u5F97\u4E8C\uFF1A");
      i18n_37 = MSG_EXTERNAL_8333618867862558530$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_RECORD_SWAP_DETAIL_MY_RECORD_SWAP_DETAIL_COMPONENT_TS___38;
    } else {
      i18n_37 = "\u83B7\u5F97\u4E8C\uFF1A";
    }
    let i18n_39;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_2160098162517155843$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_RECORD_SWAP_DETAIL_MY_RECORD_SWAP_DETAIL_COMPONENT_TS___40 = goog.getMsg("\u5408\u7EA6\u6C60\u6743\u76CA");
      i18n_39 = MSG_EXTERNAL_2160098162517155843$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_RECORD_SWAP_DETAIL_MY_RECORD_SWAP_DETAIL_COMPONENT_TS___40;
    } else {
      i18n_39 = "\u5408\u7EA6\u6C60\u6743\u76CA";
    }
    let i18n_41;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_3945429615803372141$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_RECORD_SWAP_DETAIL_MY_RECORD_SWAP_DETAIL_COMPONENT_TS____42 = goog.getMsg("\u6210\u4EA4\u4EF7\u683C");
      i18n_41 = MSG_EXTERNAL_3945429615803372141$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_RECORD_SWAP_DETAIL_MY_RECORD_SWAP_DETAIL_COMPONENT_TS____42;
    } else {
      i18n_41 = "\u6210\u4EA4\u4EF7\u683C";
    }
    let i18n_43;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_660373910768452550$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_RECORD_SWAP_DETAIL_MY_RECORD_SWAP_DETAIL_COMPONENT_TS____44 = goog.getMsg("\u5408\u7EA6\u6C60\u624B\u7EED\u8D39({$interpolation})", {
        "interpolation": "\uFFFD0\uFFFD"
      }, {
        original_code: {
          "interpolation": "{{ detail?.feeRatio1 | percentageTransfer }}"
        }
      });
      i18n_43 = MSG_EXTERNAL_660373910768452550$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_RECORD_SWAP_DETAIL_MY_RECORD_SWAP_DETAIL_COMPONENT_TS____44;
    } else {
      i18n_43 = "\u5408\u7EA6\u6C60\u624B\u7EED\u8D39(" + "\uFFFD0\uFFFD" + ")";
    }
    let i18n_45;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_1203469798003655104$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_RECORD_SWAP_DETAIL_MY_RECORD_SWAP_DETAIL_COMPONENT_TS____46 = goog.getMsg("\u56FA\u5B9A\u589E\u6D41\u6BD4\u4F8B");
      i18n_45 = MSG_EXTERNAL_1203469798003655104$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_RECORD_SWAP_DETAIL_MY_RECORD_SWAP_DETAIL_COMPONENT_TS____46;
    } else {
      i18n_45 = "\u56FA\u5B9A\u589E\u6D41\u6BD4\u4F8B";
    }
    let i18n_47;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_LIQUIDITY_POOL_TOKEN$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_RECORD_SWAP_DETAIL_MY_RECORD_SWAP_DETAIL_COMPONENT_TS_____48 = goog.getMsg("\u5408\u7EA6\u6C60\u6743\u76CA");
      i18n_47 = MSG_EXTERNAL_LIQUIDITY_POOL_TOKEN$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_RECORD_SWAP_DETAIL_MY_RECORD_SWAP_DETAIL_COMPONENT_TS_____48;
    } else {
      i18n_47 = "LPcoin";
    }
    let i18n_50;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_7825757923954104189$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_RECORD_SWAP_DETAIL_MY_RECORD_SWAP_DETAIL_COMPONENT_TS__51 = goog.getMsg("\u83B7\u53D6\u6570\u636E\u4E2D");
      i18n_50 = MSG_EXTERNAL_7825757923954104189$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_RECORD_SWAP_DETAIL_MY_RECORD_SWAP_DETAIL_COMPONENT_TS__51;
    } else {
      i18n_50 = "\u83B7\u53D6\u6570\u636E\u4E2D";
    }
    return [[3, "contentBackground", "headerTranslucent", "headerBackground"], [1, "h-75", "bg-linear-page-top", "absolute", "top-0", "w-full"], ["class", "relative z-10 px-2"], [1, "relative", "z-10", "px-2"], [1, "text-title-10", "pb-8", "pl-4", "pt-4", "text-2xl", "font-semibold"], i18n_0, [1, "h-29", "absolute", "-top-10", "right-0", "w-40", 3, "src"], [1, "rounded-4", "mb-2", "bg-white", "p-3", "text-xs"], [1, "flex", "items-center"], [1, "text-subtitle-2"], i18n_2, [1, "text-subtitle", "ml-auto", "text-right"], ["name", "icon-copy", 1, "ml-2", "text-base", 3, "wClickToCopy"], ["class", "rounded-2 bg-base-300 mt-3 flex justify-between p-3"], [1, "rounded-4", "mb-2", "bg-white", "px-3", "pb-4", "pt-6"], [1, "mb-2", "flex", "items-center", "justify-between"], [1, "text-primary", "text-sm", "font-medium"], i18n_4, [1, "text-base-200", "text-right", "text-xs"], [1, "rounded-2", "bg-base-300", "mb-1", "flex", "items-center", "p-3"], [1, "text-black-10", "font-semibold"], i18n_6, [1, "text-black-10", "ml-auto", "font-semibold"], [1, "text-gray-10", "mx-1", "text-xs"], [3, "size", "swapCoinName", "swapChainName"], [1, "rounded-2", "bg-base-300", "mb-1", "p-3"], [1, "flex", "items-center", 3, "click"], i18n_8, [1, "icon-5", "ml-2", 3, "name"], [1, "rounded-2", "bg-base-300", "p-3"], [1, "flex", "items-center", "justify-between", 3, "click"], i18n_10, [1, "icon-5", 3, "name"], ["class", "rounded-4 mb-2 bg-white px-3 pb-4 pt-6"], [1, "rounded-4", "mb-2", "bg-white", "p-4"], [1, "text-subtitle-2", "mb-2", "text-xs"], i18n_12, [3, "eventList"], [1, "rounded-2", "bg-base-300", "mt-3", "flex", "justify-between", "p-3"], [1, "text-subtitle-2", "min-w-20"], i18n_14, [1, "text-red-10", "ml-auto", "text-right"], [1, "rounded-2", "bg-gray-30", "mb-2", "mt-3", "p-2"], [1, "flex", "items-center", "text-xs"], [3, "swapCoinName", "swapChainName"], [1, "text-base-gray", "mx-1", "text-xs"], [1, "rounded-1", "bg-blue-10", "flex", "items-center", "border", "border-white", "pr-1"], [3, "swapChainName"], [1, "text-primary", "text-xxxs"], [1, "text-gray-10", "ml-auto"], [1, "my-1", "flex", "justify-end"], ["name", "icon-arrow-down", 1, "icon-5", "text-gray-10"], [1, "grid", "grid-cols-[1fr,auto]", "gap-y-3", "text-xs"], i18n_16, [1, "text-subtitle", "flex", "items-center", "justify-end"], ["name", "icon-swap-horizonal-small", 1, "text-black-10", "ml-1", "text-base", 3, "click"], i18n_18, [1, "text-subtitle", "text-right"], i18n_20, i18n_22, i18n_24, [1, "mb-4", "mt-3", "flex", "items-center"], [1, "text-title-10"], i18n_27, [1, "ml-auto", "grid", "grid-cols-[auto,1.5rem,1.5rem]", "items-center", "gap-1"], [1, "text-base-200", "flex", "items-center", "justify-between", "text-xs"], i18n_29, [1, "text-title-10", "font-bold"], [3, "size", "swapChainName", "swapCoinName"], [1, "text-green-20", "text-sm", "font-medium"], i18n_31, i18n_33, i18n_35, [1, "mb-2", "flex", "items-center", "justify-between", 3, "click"], i18n_37, i18n_39, i18n_41, i18n_43, [1, "text-base-200", "mb-2", "mt-3", "flex", "items-center", "justify-between", "text-xs"], i18n_45, [1, "bg-gray-30", "rounded-2", "text-subtitle", "grid", "grid-cols-2", "items-center", "gap-y-1", "p-2", "text-xs"], [1, "mx-1"], [1, "text-right"], ["class", "rounded-1 bg-blue-10 flex items-center border border-white py-0.5 pr-1"], i18n_47, ["name", "icon-arrow-down", 1, "icon-5", "ml-auto"], [1, ""], [1, "rounded-1", "bg-blue-10", "flex", "items-center", "border", "border-white", "py-0.5", "pr-1"], [1, "text-primary", "text-xxxs", "ml-0.5"], ["class", "bg-gray-30 rounded-2 text-subtitle grid grid-cols-2 items-center gap-y-1 p-2 text-xs", 3, "class"], [1, "absolute", "top-1/2", "flex", "w-full", "-translate-y-1/2", "flex-col", "items-center", "justify-center"], ["src", "./assets/images/order-ing.png", 1, "h-45", "w-60"], [1, "text-base-200"], i18n_50];
  },
  template: function MyRecordSwapDetailPage_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementStart"](0, "common-page", 0);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelement"](1, "div", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵtemplate"](2, MyRecordSwapDetailPage_Conditional_2_Template, 54, 42, "div", 2)(3, MyRecordSwapDetailPage_Conditional_3_Template, 4, 0);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵelementEnd"]();
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵproperty"]("contentBackground", "#f6f7fc")("headerTranslucent", false)("headerBackground", "transparent");
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵconditional"](2, ctx.loadingPage === false ? 2 : 3);
    }
  },
  dependencies: [_components_swap_token_chain_icon_swap_token_chain_icon_component__WEBPACK_IMPORTED_MODULE_15__.SwapTokenChainIconComponent, _pipes_percentage_transfer_percentage_transfer_pipe__WEBPACK_IMPORTED_MODULE_14__.PercentageTransferPipe, _bnqkl_framework_pipes__WEBPACK_IMPORTED_MODULE_12__.AddressHiddenPipe, _modules_page_module__WEBPACK_IMPORTED_MODULE_2__.CommonPageModule, _libs_bnf_directives_click_to_copy_directive__WEBPACK_IMPORTED_MODULE_16__.ClickToCopyDirective, _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_17__.CommonPageComponent, _components_icon_icon_component__WEBPACK_IMPORTED_MODULE_18__.IconComponent, _angular_common__WEBPACK_IMPORTED_MODULE_21__.DatePipe, _libs_bnf_pipes_amountFixed_amount_fixed_pipe__WEBPACK_IMPORTED_MODULE_19__.AmountFixedPipe, _angular_common__WEBPACK_IMPORTED_MODULE_21__.CommonModule, _components_token_with_chain_icon_token_with_chain_icon_component__WEBPACK_IMPORTED_MODULE_1__.TokenWithnChainIconComponent, _components_related_events_related_events_component__WEBPACK_IMPORTED_MODULE_9__["default"], _pipes_record_state_record_state_pipe__WEBPACK_IMPORTED_MODULE_13__.RecordStatePipe, _pipes_record_state_record_state_img_pipe__WEBPACK_IMPORTED_MODULE_8__.RecordStateImagePipe, _pipes_chain_name_transfer_chain_name_transfer_pipe__WEBPACK_IMPORTED_MODULE_7__.ChainNameTransferPipe],
  styles: ["/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsInNvdXJjZVJvb3QiOiIifQ== */"],
  changeDetection: 0
});
(0,tslib__WEBPACK_IMPORTED_MODULE_22__.__decorate)([MyRecordSwapDetailPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_22__.__metadata)("design:type", Object)], MyRecordSwapDetailPage.prototype, "showExpectGainOne", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_22__.__decorate)([MyRecordSwapDetailPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_22__.__metadata)("design:type", Object)], MyRecordSwapDetailPage.prototype, "showExpectGainTwo", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_22__.__decorate)([MyRecordSwapDetailPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_22__.__metadata)("design:type", Object)], MyRecordSwapDetailPage.prototype, "showActualGainOne", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_22__.__decorate)([MyRecordSwapDetailPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_22__.__metadata)("design:type", Object)], MyRecordSwapDetailPage.prototype, "showActualGainTwo", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_22__.__decorate)([MyRecordSwapDetailPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_22__.__metadata)("design:type", Object)], MyRecordSwapDetailPage.prototype, "ORDER_STATE", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_22__.__decorate)([MyRecordSwapDetailPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_22__.__metadata)("design:type", Object)], MyRecordSwapDetailPage.prototype, "PRICE_TYPE", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_22__.__decorate)([MyRecordSwapDetailPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_22__.__metadata)("design:type", Object)], MyRecordSwapDetailPage.prototype, "connectedWallet", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_22__.__decorate)([MyRecordSwapDetailPage.QueryParams(), (0,tslib__WEBPACK_IMPORTED_MODULE_22__.__metadata)("design:type", Object)], MyRecordSwapDetailPage.prototype, "params", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_22__.__decorate)([MyRecordSwapDetailPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_22__.__metadata)("design:type", Boolean)], MyRecordSwapDetailPage.prototype, "loadingPage", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_22__.__decorate)([MyRecordSwapDetailPage.OnReady(), (0,tslib__WEBPACK_IMPORTED_MODULE_22__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_22__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_22__.__metadata)("design:returntype", void 0)], MyRecordSwapDetailPage.prototype, "iniParams", null);
(0,tslib__WEBPACK_IMPORTED_MODULE_22__.__decorate)([MyRecordSwapDetailPage.States(1), (0,tslib__WEBPACK_IMPORTED_MODULE_22__.__metadata)("design:type", Object)], MyRecordSwapDetailPage.prototype, "detail", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_22__.__decorate)([MyRecordSwapDetailPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_22__.__metadata)("design:type", Object)], MyRecordSwapDetailPage.prototype, "slippage", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_22__.__decorate)([MyRecordSwapDetailPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_22__.__metadata)("design:type", Number)], MyRecordSwapDetailPage.prototype, "increasedLiquidityRatio", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_22__.__decorate)([MyRecordSwapDetailPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_22__.__metadata)("design:type", Object)], MyRecordSwapDetailPage.prototype, "isDeployExpecteList", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_22__.__decorate)([MyRecordSwapDetailPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_22__.__metadata)("design:type", Object)], MyRecordSwapDetailPage.prototype, "isDeployActualList", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_22__.__decorate)([MyRecordSwapDetailPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_22__.__metadata)("design:type", Object)], MyRecordSwapDetailPage.prototype, "endTime", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_22__.__decorate)([MyRecordSwapDetailPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_22__.__metadata)("design:type", Object)], MyRecordSwapDetailPage.prototype, "anchorTran", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_22__.__decorate)([MyRecordSwapDetailPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_22__.__metadata)("design:type", Object)], MyRecordSwapDetailPage.prototype, "quoteTran", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_22__.__decorate)([MyRecordSwapDetailPage.States(1), (0,tslib__WEBPACK_IMPORTED_MODULE_22__.__metadata)("design:type", Array)], MyRecordSwapDetailPage.prototype, "eventList", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_22__.__decorate)([MyRecordSwapDetailPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_22__.__metadata)("design:type", Object)], MyRecordSwapDetailPage.prototype, "expectPrice", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_22__.__decorate)([MyRecordSwapDetailPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_22__.__metadata)("design:type", Object)], MyRecordSwapDetailPage.prototype, "actualPrice", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_22__.__decorate)([MyRecordSwapDetailPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_22__.__metadata)("design:type", String)], MyRecordSwapDetailPage.prototype, "orderState", void 0);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MyRecordSwapDetailPage);

/***/ }),

/***/ 1726:
/*!*******************************************************************************!*\
  !*** ./apps/bfswap/src/pipes/percentage-transfer/percentage-transfer.pipe.ts ***!
  \*******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   PercentageTransferPipe: () => (/* binding */ PercentageTransferPipe)
/* harmony export */ });
/* harmony import */ var bignumber_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! bignumber.js */ 61994);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 61039);
var _class;


/** 百分比转换小数 */
class PercentageTransferPipe {
  constructor() {
    this.transform = PercentageTransferPipe.transform;
  }
  /** 转换函数 */
  static transform(value) {
    if (Boolean(value) === false || value === undefined) {
      return 0;
    }
    const v = new bignumber_js__WEBPACK_IMPORTED_MODULE_0__["default"](value).multipliedBy(1e2);
    if (v.isLessThan(0.01)) {
      return '<0.01%';
    } else {
      return Number(v.toFixed(2, 1)).toString() + '%';
    }
  }
}
_class = PercentageTransferPipe;
_class.ɵfac = function PercentageTransferPipe_Factory(t) {
  return new (t || _class)();
};
_class.ɵpipe = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefinePipe"]({
  name: "percentageTransfer",
  type: _class,
  pure: true,
  standalone: true
});

/***/ })

}]);
//# sourceMappingURL=apps_bfswap_src_pages_mine_pages_my-record-swap-detail_my-record-swap-detail_component_ts.js.map