"use strict";
(self["webpackChunkbfswap"] = self["webpackChunkbfswap"] || []).push([["apps_bfswap_src_assets_wallet-util_index-6cad83d0_mjs"],{

/***/ 98361:
/*!***************************************************************!*\
  !*** ./apps/bfswap/src/assets/wallet-util/index-6cad83d0.mjs ***!
  \***************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   embed: () => (/* binding */ u),
/* harmony export */   p2ms: () => (/* reexport safe */ _p2pk_2e124d52_mjs__WEBPACK_IMPORTED_MODULE_4__.p),
/* harmony export */   p2pk: () => (/* reexport safe */ _p2pk_2e124d52_mjs__WEBPACK_IMPORTED_MODULE_4__.a),
/* harmony export */   p2pkh: () => (/* reexport safe */ _p2wsh_046e722b_mjs__WEBPACK_IMPORTED_MODULE_2__.p),
/* harmony export */   p2sh: () => (/* reexport safe */ _p2wsh_046e722b_mjs__WEBPACK_IMPORTED_MODULE_2__.c),
/* harmony export */   p2wpkh: () => (/* reexport safe */ _p2wsh_046e722b_mjs__WEBPACK_IMPORTED_MODULE_2__.d),
/* harmony export */   p2wsh: () => (/* reexport safe */ _p2wsh_046e722b_mjs__WEBPACK_IMPORTED_MODULE_2__.e)
/* harmony export */ });
/* harmony import */ var _networks_0de0aba6_mjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./networks-0de0aba6.mjs */ 30274);
/* harmony import */ var _script_c688360e_mjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./script-c688360e.mjs */ 97370);
/* harmony import */ var _p2wsh_046e722b_mjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./p2wsh-046e722b.mjs */ 11051);
/* harmony import */ var _typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./typeforce-a57e57b8.mjs */ 75473);
/* harmony import */ var _p2pk_2e124d52_mjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./p2pk-2e124d52.mjs */ 51236);
/* harmony import */ var _index_d96f2042_mjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./index-d96f2042.mjs */ 99449);
/* harmony import */ var _index_4062991a_mjs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./index-4062991a.mjs */ 22269);
/* harmony import */ var _sha256_d88873b6_mjs__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./sha256-d88873b6.mjs */ 98080);
/* harmony import */ var _WASMInterface_4e8d37b8_mjs__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./WASMInterface-4e8d37b8.mjs */ 18047);
/* harmony import */ var _crypto_4198e1c6_mjs__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./crypto-4198e1c6.mjs */ 99920);
/* harmony import */ var _ripemd160_fdc485e7_mjs__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./ripemd160-fdc485e7.mjs */ 10918);












const n = _script_c688360e_mjs__WEBPACK_IMPORTED_MODULE_1__.O;
function u(e, a) {
  if (!e.data && !e.output) throw new TypeError("Not enough data");
  a = Object.assign({
    validate: !0
  }, a || {}), (0,_typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_3__.t)({
    network: _typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_3__.t.maybe(_typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_3__.t.Object),
    output: _typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_3__.t.maybe(_typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_3__.t.Buffer),
    data: _typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_3__.t.maybe(_typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_3__.t.arrayOf(_typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_3__.t.Buffer))
  }, e);
  const o = {
    name: "embed",
    network: e.network || _networks_0de0aba6_mjs__WEBPACK_IMPORTED_MODULE_0__.b
  };
  if ((0,_p2wsh_046e722b_mjs__WEBPACK_IMPORTED_MODULE_2__.f)(o, "output", () => {
    if (e.data) return (0,_script_c688360e_mjs__WEBPACK_IMPORTED_MODULE_1__.c)([n.OP_RETURN].concat(e.data));
  }), (0,_p2wsh_046e722b_mjs__WEBPACK_IMPORTED_MODULE_2__.f)(o, "data", () => {
    if (e.output) return (0,_script_c688360e_mjs__WEBPACK_IMPORTED_MODULE_1__.e)(e.output).slice(1);
  }), a.validate && e.output) {
    const t = (0,_script_c688360e_mjs__WEBPACK_IMPORTED_MODULE_1__.e)(e.output);
    if (t[0] !== n.OP_RETURN) throw new TypeError("Output is invalid");
    if (!t.slice(1).every(_typeforce_a57e57b8_mjs__WEBPACK_IMPORTED_MODULE_3__.t.Buffer)) throw new TypeError("Output is invalid");
    if (e.data && !function (t, r) {
      return t.length === r.length && t.every((t, e) => t.equals(r[e]));
    }(e.data, o.data)) throw new TypeError("Data mismatch");
  }
  return Object.assign(o, e);
}


/***/ })

}]);
//# sourceMappingURL=apps_bfswap_src_assets_wallet-util_index-6cad83d0_mjs.js.map