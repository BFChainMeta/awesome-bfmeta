"use strict";
(self["webpackChunkbfswap"] = self["webpackChunkbfswap"] || []).push([["apps_bfswap_src_pages_mine_pages_my-holdings-detail_my-holdings-detail_component_ts"],{

/***/ 11342:
/*!*********************************************************************************************!*\
  !*** ./apps/bfswap/src/components/token-with-chain-icon/token-with-chain-icon.component.ts ***!
  \*********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   TokenWithnChainIconComponent: () => (/* binding */ TokenWithnChainIconComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! tslib */ 90505);
/* harmony import */ var _bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @bnqkl/bnqkl-swap-core */ 70195);
/* harmony import */ var _services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ~services/wallet/wallet.helper */ 84813);
/* harmony import */ var _modules_comp_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ~modules/comp.module */ 58281);
/* harmony import */ var _modules_page_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ~modules/page.module */ 16381);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 61039);
/* harmony import */ var _icon_icon_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../icon/icon.component */ 18840);
var _class;







function TokenWithnChainIconComponent_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](1, "bs-icon", 1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵstyleMap"](ctx_r0.sizeClass.chainTranslate);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵstyleMap"](ctx_r0.sizeClass.chainSize);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("name", ctx_r0.chainName);
  }
}
/** Token和chain组合图标 */
class TokenWithnChainIconComponent extends _modules_comp_module__WEBPACK_IMPORTED_MODULE_2__.CommonCompBase {
  constructor() {
    super(...arguments);
    /** token的大小 */
    this.tokenSize = 'icon-8';
    /** chain的大小 */
    this.chainSize = 'icon-4';
    /** 尺寸默认32 */
    this.size = 0;
    /** 尺寸样式 */
    this.sizeClass = {
      chainSize: 'font-size:1rem',
      coinSize: 'font-size:2rem',
      chainTranslate: 'transform: translate(6px,8px)'
    };
  }
  /** 初始化参数 */
  init() {
    this.handleIcon();
    this.handleSize();
  }
  /** 处理尺寸 */
  handleSize() {
    const {
      size
    } = this;
    if (size > 0) {
      const CHAINSIZE = 16;
      const COINSIZE = 32;
      const TRANSLATEX = 6;
      const TRANSLATEY = 8;
      const times = size / COINSIZE;
      this.sizeClass.chainSize = `font-size:${CHAINSIZE * times}px`;
      this.sizeClass.coinSize = `font-size:${COINSIZE * times}px`;
      this.sizeClass.chainTranslate = `transform: translate(${TRANSLATEX * times}px,${TRANSLATEY * times}px)`;
    }
  }
  /** 处理图标名称 */
  handleIcon() {
    const {
      swapChainName,
      swapCoinName
    } = this;
    if (swapChainName) {
      const chainName = swapChainName in _bnqkl_bnqkl_swap_core__WEBPACK_IMPORTED_MODULE_0__.BNQKL_SWAP_CHAIN_NAME ? _services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_1__.NODE_CHAIN_NAME_TRANSFER[swapChainName] : swapChainName;
      const chainIcon = (0,_services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_1__.transferToChainIcon)(chainName);
      this.chainName = chainIcon;
      if (swapCoinName) {
        const coinIcon = (0,_services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_1__.transferToTokenIconBychainName)(chainName, swapCoinName);
        this.tokenName = coinIcon;
      }
    }
  }
}
_class = TokenWithnChainIconComponent;
_class.ɵfac = /*@__PURE__*/(() => {
  let ɵTokenWithnChainIconComponent_BaseFactory;
  return function TokenWithnChainIconComponent_Factory(t) {
    return (ɵTokenWithnChainIconComponent_BaseFactory || (ɵTokenWithnChainIconComponent_BaseFactory = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵgetInheritedFactory"](_class)))(t || _class);
  };
})();
_class.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineComponent"]({
  type: _class,
  selectors: [["bs-token-with-chain-icon"]],
  inputs: {
    tokenSize: "tokenSize",
    tokenName: "tokenName",
    chainSize: "chainSize",
    chainName: "chainName",
    size: "size",
    swapChainName: "swapChainName",
    swapCoinName: "swapCoinName"
  },
  standalone: true,
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵInheritDefinitionFeature"], _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵStandaloneFeature"]],
  decls: 3,
  vars: 4,
  consts: [[1, "relative", "flex", "items-center", "justify-center"], [3, "name"], ["class", "bg-blue-10 rounded-1 absolute bottom-0 right-0 flex  items-center justify-center border-[2px] border-white", 3, "style"], [1, "bg-blue-10", "rounded-1", "absolute", "bottom-0", "right-0", "flex", "items-center", "justify-center", "border-[2px]", "border-white"]],
  template: function TokenWithnChainIconComponent_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 0);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](1, "bs-icon", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](2, TokenWithnChainIconComponent_Conditional_2_Template, 2, 5, "div", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵstyleMap"](ctx.sizeClass.coinSize);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("name", ctx.tokenName);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵconditional"](2, ctx.chainName ? 2 : -1);
    }
  },
  dependencies: [_modules_page_module__WEBPACK_IMPORTED_MODULE_3__.CommonPageModule, _icon_icon_component__WEBPACK_IMPORTED_MODULE_4__.IconComponent],
  encapsulation: 2,
  changeDetection: 0
});
(0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([TokenWithnChainIconComponent.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__metadata)("design:type", Object)], TokenWithnChainIconComponent.prototype, "sizeClass", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([TokenWithnChainIconComponent.OnChanges(), (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__metadata)("design:returntype", void 0)], TokenWithnChainIconComponent.prototype, "init", null);

/***/ }),

/***/ 59817:
/*!*********************************************************************************************!*\
  !*** ./apps/bfswap/src/pages/mine/pages/my-holdings-detail/my-holdings-detail.component.ts ***!
  \*********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   MyHoldingsDetailPage: () => (/* binding */ MyHoldingsDetailPage),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 52542);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! tslib */ 90505);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @angular/core */ 61039);
/* harmony import */ var _components_token_with_chain_icon_token_with_chain_icon_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ~components/token-with-chain-icon/token-with-chain-icon.component */ 11342);
/* harmony import */ var _modules_page_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ~modules/page.module */ 16381);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @angular/common */ 6729);
/* harmony import */ var _services_liquidity_pool_liquidity_pool_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ~services/liquidity-pool/liquidity-pool.service */ 20213);
/* harmony import */ var _pipes_chain_name_transfer_chain_name_transfer_pipe__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ~pipes/chain-name-transfer/chain-name-transfer.pipe */ 37514);
/* harmony import */ var _pipes_percentage_transfer_percentage_transfer_pipe__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ~pipes/percentage-transfer/percentage-transfer.pipe */ 1726);
/* harmony import */ var _pipes_amount_format_amount_format_pipe__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ~pipes/amount-format/amount-format.pipe */ 23377);
/* harmony import */ var bignumber_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! bignumber.js */ 61994);
/* harmony import */ var _services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ~services/wallet/wallet.helper */ 84813);
/* harmony import */ var _bnqkl_framework_pipes__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @bnqkl/framework/pipes */ 80909);
/* harmony import */ var _services_liquidity_user_liquidity_user_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ~services/liquidity-user/liquidity-user.service */ 34913);
/* harmony import */ var _libs_bnf_directives_click_to_copy_directive__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../../../../../../libs/bnf/directives/click-to-copy.directive */ 46413);
/* harmony import */ var _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../../../../../../libs/bnf/modules/page/common-page/common-page.component */ 62052);
/* harmony import */ var _components_icon_icon_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../../../../components/icon/icon.component */ 18840);
/* harmony import */ var _pipes_color_color_pipe__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../../../../pipes/color/color.pipe */ 67481);
/* harmony import */ var _libs_bnf_pipes_amountFixed_amount_fixed_pipe__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ../../../../../../../libs/bnf/pipes/amountFixed/amount-fixed.pipe */ 44070);

var _class;



















function MyHoldingsDetailPage_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    const _r3 = _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](0, "div", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelement"](1, "bs-token-with-chain-icon", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](2, "div", 15)(3, "div", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](5, "div", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtext"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipe"](7, "chainNameTransfer");
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelement"](8, "div", 18)(9, "bs-icon", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](10, "div", 15)(11, "div", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtext"](12);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](13, "div", 21)(14, "div", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵi18n"](15, 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](16, "div", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtext"](17);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipe"](18, "addressHidden");
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelement"](19, "bs-icon", 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](20, "div", 26)(21, "div", 27)(22, "div", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵi18n"](23, 29);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](24, "div", 30);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtext"](25);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipe"](26, "amountFormat");
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipe"](27, "amountFixed");
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](28, "div", 31)(29, "div", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelement"](30, "bs-icon", 32);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](31, "div", 33);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtext"](32);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](33, "div", 34);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelement"](34, "bs-icon", 32);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](35, "div", 35);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtext"](36);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipe"](37, "chainNameTransfer");
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](38, "div", 36);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtext"](39);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipe"](40, "amountFormat");
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipe"](41, "amountFixed");
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](42, "div", 37);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelement"](43, "bs-icon", 32);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](44, "div", 33);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtext"](45);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](46, "div", 36);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtext"](47);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipe"](48, "amountFormat");
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipe"](49, "amountFixed");
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](50, "div", 38)(51, "div", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵi18n"](52, 39);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](53, "div", 40);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtext"](54);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipe"](55, "amountFormat");
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipe"](56, "amountFixed");
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](57, "div", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵi18n"](58, 41);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](59, "div", 40);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtext"](60);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipe"](61, "percentageTransfer");
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](62, "div", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵi18n"](63, 42);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](64, "div", 43);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵlistener"]("click", function MyHoldingsDetailPage_Conditional_3_Template_div_click_64_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵrestoreView"](_r3);
      const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵresetView"](ctx_r2.jumpRecord());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](65, "div", 44);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtext"](66);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipe"](67, "amountFormat");
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipe"](68, "amountFixed");
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelement"](69, "bs-icon", 45);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](70, "div", 46);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵi18n"](71, 47);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](72, "div", 48)(73, "div", 49);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵi18n"](74, 50);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](75, "div", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelement"](76, "bs-icon", 32);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](77, "div", 33);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtext"](78);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](79, "div", 34);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelement"](80, "bs-icon", 32);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](81, "div", 35);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtext"](82);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipe"](83, "chainNameTransfer");
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](84, "div", 36);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtext"](85);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipe"](86, "amountFormat");
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipe"](87, "amountFixed");
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](88, "div", 37);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelement"](89, "bs-icon", 32);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](90, "div", 33);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtext"](91);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](92, "div", 51);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtext"](93);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipe"](94, "amountFormat");
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipe"](95, "amountFixed");
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](96, "div", 52)(97, "div", 53);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵi18n"](98, 54);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](99, "div", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelement"](100, "bs-icon", 32);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](101, "div", 33);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtext"](102);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](103, "div", 34);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelement"](104, "bs-icon", 32);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](105, "div", 35);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtext"](106);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipe"](107, "chainNameTransfer");
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](108, "div", 51);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtext"](109);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipe"](110, "amountFormat");
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipe"](111, "amountFixed");
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](112, "div", 37);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelement"](113, "bs-icon", 32);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](114, "div", 33);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtext"](115);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](116, "div", 36);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtext"](117);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipe"](118, "amountFormat");
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipe"](119, "amountFixed");
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵproperty"]("chainName", ctx_r0.anchorChainIcon)("tokenName", ctx_r0.anchorCoinIcon);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtextInterpolate"](ctx_r0.pageData == null ? null : ctx_r0.pageData.anchorCoinsName);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipeBind1"](7, 36, ctx_r0.pageData == null ? null : ctx_r0.pageData.anchorCoinsChainName));
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵproperty"]("name", ctx_r0.quoteCoinIcon);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtextInterpolate"](ctx_r0.pageData == null ? null : ctx_r0.pageData.quoteCoinsName);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipeBind1"](18, 38, ctx_r0.userId));
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵproperty"]("wClickToCopy", ctx_r0.userId);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtextInterpolate1"]("$", _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipeBind1"](26, 40, _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipeBind2"](27, 42, ctx_r0.holdUAmount, 8)), "");
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵproperty"]("name", ctx_r0.anchorCoinIcon);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtextInterpolate"](ctx_r0.pageData == null ? null : ctx_r0.pageData.anchorCoinsName);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵproperty"]("name", ctx_r0.anchorChainIcon);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipeBind1"](37, 45, ctx_r0.pageData == null ? null : ctx_r0.pageData.anchorCoinsChainName));
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipeBind1"](40, 47, _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipeBind2"](41, 49, ctx_r0.pageData == null ? null : ctx_r0.pageData.userRedeemableAnchorCoinsAmount, 8)), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵproperty"]("name", ctx_r0.quoteCoinIcon);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtextInterpolate"](ctx_r0.pageData == null ? null : ctx_r0.pageData.quoteCoinsName);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipeBind1"](48, 52, _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipeBind2"](49, 54, ctx_r0.pageData == null ? null : ctx_r0.pageData.userRedeemableQuoteCoinsAmount, 8)), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](7);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipeBind1"](55, 57, _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipeBind2"](56, 59, ctx_r0.pageData == null ? null : ctx_r0.pageData.userLPCoinsAmount, 8)));
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipeBind1"](61, 62, ctx_r0.pageData == null ? null : ctx_r0.pageData.percent));
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipeBind1"](67, 64, _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipeBind2"](68, 66, ctx_r0.pageData == null ? null : ctx_r0.pageData.userFrozenLpCoinsAmount, 8)), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](10);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵproperty"]("name", ctx_r0.anchorCoinIcon);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtextInterpolate"](ctx_r0.pageData == null ? null : ctx_r0.pageData.anchorCoinsName);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵproperty"]("name", ctx_r0.anchorChainIcon);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipeBind1"](83, 69, ctx_r0.pageData == null ? null : ctx_r0.pageData.anchorCoinsChainName));
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipeBind1"](86, 71, _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipeBind2"](87, 73, ctx_r0.pageData == null ? null : ctx_r0.pageData.userAnchorCoinsTotalProfits, 8)), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵproperty"]("name", ctx_r0.quoteCoinIcon);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtextInterpolate"](ctx_r0.pageData == null ? null : ctx_r0.pageData.quoteCoinsName);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipeBind1"](94, 76, _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipeBind2"](95, 78, ctx_r0.pageData == null ? null : ctx_r0.pageData.userQuoteCoinsTotalProfits, 8)), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](7);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵproperty"]("name", ctx_r0.anchorCoinIcon);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtextInterpolate"](ctx_r0.pageData == null ? null : ctx_r0.pageData.anchorCoinsName);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵproperty"]("name", ctx_r0.anchorChainIcon);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipeBind1"](107, 81, ctx_r0.pageData == null ? null : ctx_r0.pageData.anchorCoinsChainName));
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipeBind1"](110, 83, _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipeBind2"](111, 85, ctx_r0.pageData == null ? null : ctx_r0.pageData.userAnchorCoinsUnreceivedProfits, 8)), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵproperty"]("name", ctx_r0.quoteCoinIcon);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtextInterpolate"](ctx_r0.pageData == null ? null : ctx_r0.pageData.quoteCoinsName);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipeBind1"](118, 88, _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipeBind2"](119, 90, ctx_r0.pageData == null ? null : ctx_r0.pageData.userQuoteCoinsUnReceivedProfits, 8)), " ");
  }
}
function MyHoldingsDetailPage_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](0, "div", 55);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelement"](1, "img", 56);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](2, "div", 57);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵi18n"](3, 58);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]()();
  }
}
const _c24 = a0 => ({
  "--color-1": a0
});
/** 持仓详情 */
class MyHoldingsDetailPage extends _modules_page_module__WEBPACK_IMPORTED_MODULE_2__.CommonPageBase {
  constructor() {
    super(...arguments);
    /** 地址 */
    this.userId = '';
    /** 页面初始化 */
    this.init = false;
    /** 合约池服务 */
    this.poolService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_16__.inject)(_services_liquidity_pool_liquidity_pool_service__WEBPACK_IMPORTED_MODULE_3__.LiquidityPoolService);
    /** 用户服务 */
    this.userService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_16__.inject)(_services_liquidity_user_liquidity_user_service__WEBPACK_IMPORTED_MODULE_10__.LiquidityUserService);
    /** anchor币图标 */
    this.anchorCoinIcon = undefined;
    /** anchor链图标 */
    this.anchorChainIcon = undefined;
    /** quote币图标 */
    this.quoteCoinIcon = undefined;
    this.holdUAmount = '';
  }
  /** 跳转记录页面 */
  jumpRecord() {
    const {
      params
    } = this;
    if (params && params.userId && params.poolId) {
      this.nav.routeTo('./mine/add-liquidity-record', params);
    }
  }
  /** 获取数据 */
  getData() {
    var _this = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const {
        params
      } = _this;
      if (params && params.userId && params.poolId) {
        _this.userId = params.userId;
        const result = yield _this.userService.getUserPositionDetail(params);
        if (result) {
          _this.anchorChainIcon = (0,_services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_8__.transferToChainIcon)(_services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_8__.NODE_CHAIN_NAME_TRANSFER[result.anchorCoinsChainName] || 'Default');
          _this.anchorCoinIcon = (0,_services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_8__.transferToTokenIcon)(result.anchorCoinsChainName, result.anchorCoinsName);
          _this.quoteCoinIcon = (0,_services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_8__.transferToTokenIcon)(result.quoteCoinsChainName, result.quoteCoinsName);
          _this.holdUAmount = new bignumber_js__WEBPACK_IMPORTED_MODULE_7__["default"](result.userRedeemableQuoteCoinsAmount).multipliedBy(2).toString();
          _this.pageData = result;
          _this.init = true;
        }
      }
    })();
  }
  /** 跳转添加流动性 */
  jumpAddLiquidityPage() {
    const {
      pageData
    } = this;
    if (pageData === undefined) {
      this.console.error('数据异常');
      return;
    }
    const {
      anchorCoinsName,
      quoteCoinsName,
      anchorCoinsChainName,
      quoteCoinsChainName
    } = pageData;
    this.nav.routeTo('/add-liquidity', {
      anchorCoinName: anchorCoinsName,
      anchorChainName: anchorCoinsChainName,
      quoteCoinName: quoteCoinsName,
      quoteChainName: quoteCoinsChainName
    });
  }
  /** 跳转移除流动性 */
  jumpRemoveLiquidityPage() {
    const {
      pageData
    } = this;
    if (pageData === undefined) {
      this.console.error('数据异常');
      return;
    }
    this.nav.routeTo('/remove-liquidity', {
      hold: JSON.stringify(pageData)
    });
  }
  /** 跳转首页合约池 */
  jumpTabLiquidityPage() {
    //
    const {
      pageData
    } = this;
    if (pageData) {
      this.nav.routeTo('liquidity-detail', {
        poolDetailstring: JSON.stringify(pageData)
      });
    }
  }
}
_class = MyHoldingsDetailPage;
_class.ɵfac = /*@__PURE__*/(() => {
  let ɵMyHoldingsDetailPage_BaseFactory;
  return function MyHoldingsDetailPage_Factory(t) {
    return (ɵMyHoldingsDetailPage_BaseFactory || (ɵMyHoldingsDetailPage_BaseFactory = _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵgetInheritedFactory"](_class)))(t || _class);
  };
})();
_class.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵdefineComponent"]({
  type: _class,
  selectors: [["bs-mine-my-holdings-detal"]],
  standalone: true,
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵInheritDefinitionFeature"], _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵStandaloneFeature"]],
  decls: 16,
  vars: 11,
  consts: () => {
    let i18n_0;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_5147646579214356822$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_HOLDINGS_DETAIL_MY_HOLDINGS_DETAIL_COMPONENT_TS_1 = goog.getMsg("\u5408\u7EA6\u6C60");
      i18n_0 = MSG_EXTERNAL_5147646579214356822$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_HOLDINGS_DETAIL_MY_HOLDINGS_DETAIL_COMPONENT_TS_1;
    } else {
      i18n_0 = "\u5408\u7EA6\u6C60";
    }
    let i18n_2;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_8897095733372765865$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_HOLDINGS_DETAIL_MY_HOLDINGS_DETAIL_COMPONENT_TS_3 = goog.getMsg(" \u79FB\u9664 ");
      i18n_2 = MSG_EXTERNAL_8897095733372765865$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_HOLDINGS_DETAIL_MY_HOLDINGS_DETAIL_COMPONENT_TS_3;
    } else {
      i18n_2 = " \u79FB\u9664 ";
    }
    let i18n_4;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_6980394572016816086$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_HOLDINGS_DETAIL_MY_HOLDINGS_DETAIL_COMPONENT_TS_5 = goog.getMsg(" \u589E\u52A0 ");
      i18n_4 = MSG_EXTERNAL_6980394572016816086$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_HOLDINGS_DETAIL_MY_HOLDINGS_DETAIL_COMPONENT_TS_5;
    } else {
      i18n_4 = " \u589E\u52A0 ";
    }
    let i18n_6;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_5469377262532830686$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_HOLDINGS_DETAIL_MY_HOLDINGS_DETAIL_COMPONENT_TS__7 = goog.getMsg("\u5730\u5740");
      i18n_6 = MSG_EXTERNAL_5469377262532830686$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_HOLDINGS_DETAIL_MY_HOLDINGS_DETAIL_COMPONENT_TS__7;
    } else {
      i18n_6 = "\u5730\u5740";
    }
    let i18n_8;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_2331511577836506527$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_HOLDINGS_DETAIL_MY_HOLDINGS_DETAIL_COMPONENT_TS__9 = goog.getMsg("\u6301\u6709\u5E02\u503C");
      i18n_8 = MSG_EXTERNAL_2331511577836506527$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_HOLDINGS_DETAIL_MY_HOLDINGS_DETAIL_COMPONENT_TS__9;
    } else {
      i18n_8 = "\u6301\u6709\u5E02\u503C";
    }
    let i18n_10;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_2160098162517155843$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_HOLDINGS_DETAIL_MY_HOLDINGS_DETAIL_COMPONENT_TS__11 = goog.getMsg("\u5408\u7EA6\u6C60\u6743\u76CA");
      i18n_10 = MSG_EXTERNAL_2160098162517155843$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_HOLDINGS_DETAIL_MY_HOLDINGS_DETAIL_COMPONENT_TS__11;
    } else {
      i18n_10 = "\u5408\u7EA6\u6C60\u6743\u76CA";
    }
    let i18n_12;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_5643882418894981747$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_HOLDINGS_DETAIL_MY_HOLDINGS_DETAIL_COMPONENT_TS__13 = goog.getMsg("\u5360\u5408\u7EA6\u6C60\u4EFD\u989D");
      i18n_12 = MSG_EXTERNAL_5643882418894981747$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_HOLDINGS_DETAIL_MY_HOLDINGS_DETAIL_COMPONENT_TS__13;
    } else {
      i18n_12 = "\u5360\u5408\u7EA6\u6C60\u4EFD\u989D";
    }
    let i18n_14;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_2529818047838713135$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_HOLDINGS_DETAIL_MY_HOLDINGS_DETAIL_COMPONENT_TS__15 = goog.getMsg("\u6743\u76CA\u9501\u5B9A\u91CF");
      i18n_14 = MSG_EXTERNAL_2529818047838713135$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_HOLDINGS_DETAIL_MY_HOLDINGS_DETAIL_COMPONENT_TS__15;
    } else {
      i18n_14 = "\u6743\u76CA\u9501\u5B9A\u91CF";
    }
    let i18n_16;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_3890728303609724223$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_HOLDINGS_DETAIL_MY_HOLDINGS_DETAIL_COMPONENT_TS__17 = goog.getMsg("\u589E\u6D41\u6536\u76CA");
      i18n_16 = MSG_EXTERNAL_3890728303609724223$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_HOLDINGS_DETAIL_MY_HOLDINGS_DETAIL_COMPONENT_TS__17;
    } else {
      i18n_16 = "\u589E\u6D41\u6536\u76CA";
    }
    let i18n_18;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_6994879308449779328$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_HOLDINGS_DETAIL_MY_HOLDINGS_DETAIL_COMPONENT_TS__19 = goog.getMsg("\u589E\u6D41\u6536\u76CA\u603B\u548C");
      i18n_18 = MSG_EXTERNAL_6994879308449779328$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_HOLDINGS_DETAIL_MY_HOLDINGS_DETAIL_COMPONENT_TS__19;
    } else {
      i18n_18 = "\u589E\u6D41\u6536\u76CA\u603B\u548C";
    }
    let i18n_20;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_460550010082710603$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_HOLDINGS_DETAIL_MY_HOLDINGS_DETAIL_COMPONENT_TS__21 = goog.getMsg("\u672A\u9886\u53D6\u7684\u6536\u76CA");
      i18n_20 = MSG_EXTERNAL_460550010082710603$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_HOLDINGS_DETAIL_MY_HOLDINGS_DETAIL_COMPONENT_TS__21;
    } else {
      i18n_20 = "\u672A\u9886\u53D6\u7684\u6536\u76CA";
    }
    let i18n_22;
    if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
      /**
       * @suppress {msgDescriptions}
       */
      const MSG_EXTERNAL_7825757923954104189$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_HOLDINGS_DETAIL_MY_HOLDINGS_DETAIL_COMPONENT_TS__23 = goog.getMsg("\u83B7\u53D6\u6570\u636E\u4E2D");
      i18n_22 = MSG_EXTERNAL_7825757923954104189$$APPS_BFSWAP_SRC_PAGES_MINE_PAGES_MY_HOLDINGS_DETAIL_MY_HOLDINGS_DETAIL_COMPONENT_TS__23;
    } else {
      i18n_22 = "\u83B7\u53D6\u6570\u636E\u4E2D";
    }
    return [[3, "headerBackground", "footerClass", "contentBackground", "titleClass"], [1, "_bginner", "h-100", "absolute", "left-0", "top-0", "w-full"], [1, "relative", "z-10", "px-3"], ["footer", ""], [1, "flex", "items-center"], [1, "h-12.5", "min-w-20", "ml-1", "flex", "w-20", "flex-col", "items-center", "justify-center", 3, "click"], ["name", "icon-pools-normal", 1, "text-3xl"], [1, "text-title-10", "text-xs"], i18n_0, [1, "text-primary", "border-primary", "mr-3", "flex", "h-12", "w-full", "items-center", "justify-center", "rounded-full", "border", "text-lg", "font-semibold", 3, "click"], i18n_2, [1, "bg-primary", "border-primary", "flex", "h-12", "w-full", "items-center", "justify-center", "rounded-full", "border", "text-lg", "text-white", 3, "click"], i18n_4, [1, "flex", "items-center", "pl-9", "pt-6", "mb-4"], [3, "chainName", "tokenName"], [1, "ml-2"], [1, "text-black-10", "text-[1rem]", "font-bold"], [1, "text-subtitle-2", "text-xs", "leading-3"], [1, "bg-text-input", "mx-4", "h-8", "w-[1px]"], [1, "text-3xl", 3, "name"], [1, "text-black-10", "text-base", "font-bold", "leading-4"], [1, "rounded-4", "mb-2", "flex", "items-center", "bg-white", "p-3", "text-xs"], [1, "text-subtitle-2"], i18n_6, [1, "text-subtitle", "ml-auto", "text-right"], ["name", "icon-copy", 1, "ml-2", "text-base", 3, "wClickToCopy"], [1, "rounded-5", "text-title-10", "mt-4", "bg-white", "p-4"], [1, "mb-3", "flex", "items-center", "justify-between"], [1, "text-base"], i18n_8, [1, "text-xl", "font-extrabold"], [1, "rounded-2", "bg-base-300", "mb-4", "px-2", "py-3"], [1, "text-base", 3, "name"], [1, "text-subtitle", "ml-1", "mr-2", "text-xs"], [1, "bg-blue-10", "rounded-1", "flex", "items-center", "border", "border-white", "pl-1", "pr-1.5"], [1, "text-xxs", "text-primary", "ml-1"], [1, "text-title-10", "ml-auto", "text-xs"], [1, "mt-2", "flex", "items-center"], [1, "grid", "grid-cols-2", "gap-3", "text-sm"], i18n_10, [1, "text-title-10", "text-right"], i18n_12, i18n_14, [1, "flex", "items-center", "justify-end", 3, "click"], [1, "text-title-10"], ["name", "icon-chevron-right", 1, "bg-base-300", "rounded-1", "ml-1", "text-xl"], [1, "text-black-10", "mt-4", "mb-2", "pl-4", "text-base", "font-semibold"], i18n_16, [1, "rounded-4", "_bg-total", "_bg-img", "bg-white", "p-4"], [1, "text-title-10", "mb-4", "text-sm"], i18n_18, [1, "text-title-10", "ml-auto", "text-xs", "font-medium"], [1, "rounded-4", "_bg-lock", "_bg-img", "mb-10", "mt-2", "bg-white", "p-4"], [1, "mb-4", "text-title-10", "text-sm"], i18n_20, [1, "absolute", "left-1/2", "top-1/2", "flex", "w-full", "-translate-x-1/2", "-translate-y-1/2", "flex-col", "items-center", "justify-center"], ["src", "./assets/images/order-ing.png", 1, "h-45", "w-60"], [1, "text-base-200"], i18n_22];
  },
  template: function MyHoldingsDetailPage_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](0, "common-page", 0);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelement"](1, "div", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](2, "div", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtemplate"](3, MyHoldingsDetailPage_Conditional_3_Template, 120, 93)(4, MyHoldingsDetailPage_Conditional_4_Template, 4, 0);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementContainerStart"](5, 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](6, "div", 4)(7, "div", 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵlistener"]("click", function MyHoldingsDetailPage_Template_div_click_7_listener() {
        return ctx.jumpTabLiquidityPage();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelement"](8, "bs-icon", 6);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipe"](9, "color");
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](10, "div", 7);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵi18n"](11, 8);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](12, "div", 9);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵlistener"]("click", function MyHoldingsDetailPage_Template_div_click_12_listener() {
        return ctx.jumpRemoveLiquidityPage();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵi18n"](13, 10);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](14, "div", 11);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵlistener"]("click", function MyHoldingsDetailPage_Template_div_click_14_listener() {
        return ctx.jumpAddLiquidityPage();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵi18n"](15, 12);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementContainerEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵproperty"]("headerBackground", "transparent")("footerClass", "pb-0 pl-1 pr-4")("contentBackground", "#f6f7fc")("titleClass", "!justify-start text-xl !text-title-10 font-extrabold ");
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵconditional"](3, ctx.init ? 3 : 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](5);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpureFunction1"](9, _c24, _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipeBind1"](9, 7, "black-10")));
    }
  },
  dependencies: [_bnqkl_framework_pipes__WEBPACK_IMPORTED_MODULE_9__.AddressHiddenPipe, _pipes_percentage_transfer_percentage_transfer_pipe__WEBPACK_IMPORTED_MODULE_5__.PercentageTransferPipe, _pipes_amount_format_amount_format_pipe__WEBPACK_IMPORTED_MODULE_6__.AmountFormatPipe, _modules_page_module__WEBPACK_IMPORTED_MODULE_2__.CommonPageModule, _libs_bnf_directives_click_to_copy_directive__WEBPACK_IMPORTED_MODULE_11__.ClickToCopyDirective, _libs_bnf_modules_page_common_page_common_page_component__WEBPACK_IMPORTED_MODULE_12__.CommonPageComponent, _components_icon_icon_component__WEBPACK_IMPORTED_MODULE_13__.IconComponent, _pipes_color_color_pipe__WEBPACK_IMPORTED_MODULE_14__.ColorPipe, _libs_bnf_pipes_amountFixed_amount_fixed_pipe__WEBPACK_IMPORTED_MODULE_15__.AmountFixedPipe, _angular_common__WEBPACK_IMPORTED_MODULE_17__.CommonModule, _components_token_with_chain_icon_token_with_chain_icon_component__WEBPACK_IMPORTED_MODULE_1__.TokenWithnChainIconComponent, _pipes_chain_name_transfer_chain_name_transfer_pipe__WEBPACK_IMPORTED_MODULE_4__.ChainNameTransferPipe],
  styles: ["[_nghost-%COMP%]   ._bginner[_ngcontent-%COMP%] {\n  background: linear-gradient(180deg, #e3e0f8 0%, #e6e0f8 15%, #faf3f7 45%, #f6f7fc 100%);\n}\n[_nghost-%COMP%]   ._bg-img[_ngcontent-%COMP%] {\n  background-position: right top;\n  background-repeat: no-repeat;\n  background-size: 6.5rem 4rem;\n}\n[_nghost-%COMP%]   ._bg-lock[_ngcontent-%COMP%] {\n  background-image: url('bg-lock.png');\n}\n[_nghost-%COMP%]   ._bg-total[_ngcontent-%COMP%] {\n  background-image: url('bg-total.png');\n}\n[_nghost-%COMP%]   .bottom-width[_ngcontent-%COMP%] {\n  width: calc(100% - 1.5rem);\n  background: #F6F7FC;\n  padding: 4px 0;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL2FwcHMvYmZzd2FwL3NyYy9wYWdlcy9taW5lL3BhZ2VzL215LWhvbGRpbmdzLWRldGFpbC9teS1ob2xkaW5ncy1kZXRhaWwuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQ0U7RUFDRSx1RkFBQTtBQUFKO0FBR0U7RUFDRSw4QkFBQTtFQUNBLDRCQUFBO0VBQ0EsNEJBQUE7QUFESjtBQUlFO0VBQ0Usb0NBQUE7QUFGSjtBQUtFO0VBQ0UscUNBQUE7QUFISjtBQU1FO0VBQ0UsMEJBQUE7RUFDQSxtQkFBQTtFQUNBLGNBQUE7QUFKSiIsInNvdXJjZXNDb250ZW50IjpbIjpob3N0IHtcclxuICAuX2JnaW5uZXIge1xyXG4gICAgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDE4MGRlZywgI2UzZTBmOCAwJSwgI2U2ZTBmOCAxNSUsICNmYWYzZjcgNDUlLCAjZjZmN2ZjIDEwMCUpO1xyXG4gIH1cclxuXHJcbiAgLl9iZy1pbWcge1xyXG4gICAgYmFja2dyb3VuZC1wb3NpdGlvbjogcmlnaHQgdG9wO1xyXG4gICAgYmFja2dyb3VuZC1yZXBlYXQ6IG5vLXJlcGVhdDtcclxuICAgIGJhY2tncm91bmQtc2l6ZTogNi41cmVtIDRyZW07XHJcbiAgfVxyXG5cclxuICAuX2JnLWxvY2sge1xyXG4gICAgYmFja2dyb3VuZC1pbWFnZTogdXJsKCcuL2Fzc2V0cy9iZy1sb2NrLnBuZycpO1xyXG4gIH1cclxuXHJcbiAgLl9iZy10b3RhbCB7XHJcbiAgICBiYWNrZ3JvdW5kLWltYWdlOiB1cmwoJy4vYXNzZXRzL2JnLXRvdGFsLnBuZycpO1xyXG4gIH1cclxuXHJcbiAgLmJvdHRvbS13aWR0aCB7XHJcbiAgICB3aWR0aDogY2FsYygxMDAlIC0gMS41cmVtKTtcclxuICAgIGJhY2tncm91bmQ6ICNGNkY3RkM7XHJcbiAgICBwYWRkaW5nOiA0cHggMDtcclxuICB9XHJcbn0iXSwic291cmNlUm9vdCI6IiJ9 */"],
  changeDetection: 0
});
(0,tslib__WEBPACK_IMPORTED_MODULE_18__.__decorate)([MyHoldingsDetailPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_18__.__metadata)("design:type", Object)], MyHoldingsDetailPage.prototype, "init", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_18__.__decorate)([MyHoldingsDetailPage.QueryParams(), (0,tslib__WEBPACK_IMPORTED_MODULE_18__.__metadata)("design:type", Object)], MyHoldingsDetailPage.prototype, "params", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_18__.__decorate)([MyHoldingsDetailPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_18__.__metadata)("design:type", Object)], MyHoldingsDetailPage.prototype, "pageData", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_18__.__decorate)([MyHoldingsDetailPage.State(), (0,tslib__WEBPACK_IMPORTED_MODULE_18__.__metadata)("design:type", Object)], MyHoldingsDetailPage.prototype, "holdUAmount", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_18__.__decorate)([MyHoldingsDetailPage.OnInit(), (0,tslib__WEBPACK_IMPORTED_MODULE_18__.__metadata)("design:type", Function), (0,tslib__WEBPACK_IMPORTED_MODULE_18__.__metadata)("design:paramtypes", []), (0,tslib__WEBPACK_IMPORTED_MODULE_18__.__metadata)("design:returntype", Promise)], MyHoldingsDetailPage.prototype, "getData", null);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MyHoldingsDetailPage);

/***/ }),

/***/ 23377:
/*!*******************************************************************!*\
  !*** ./apps/bfswap/src/pipes/amount-format/amount-format.pipe.ts ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AmountFormatPipe: () => (/* binding */ AmountFormatPipe)
/* harmony export */ });
/* harmony import */ var bignumber_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! bignumber.js */ 61994);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 61039);
var _class;


/** 数值转换小数 */
class AmountFormatPipe {
  constructor() {
    this.transform = AmountFormatPipe.transform;
  }
  /** 转换函数 */
  static transform(value) {
    if (value === undefined) {
      return 0;
    }
    const v = new bignumber_js__WEBPACK_IMPORTED_MODULE_0__["default"](value).toFormat();
    return v;
  }
}
_class = AmountFormatPipe;
_class.ɵfac = function AmountFormatPipe_Factory(t) {
  return new (t || _class)();
};
_class.ɵpipe = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefinePipe"]({
  name: "amountFormat",
  type: _class,
  pure: true,
  standalone: true
});

/***/ }),

/***/ 37514:
/*!*******************************************************************************!*\
  !*** ./apps/bfswap/src/pipes/chain-name-transfer/chain-name-transfer.pipe.ts ***!
  \*******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ChainNameTransferPipe: () => (/* binding */ ChainNameTransferPipe)
/* harmony export */ });
/* harmony import */ var _services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ~services/wallet/wallet.helper */ 84813);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 61039);
var _class;


/** 链名换小写 */
class ChainNameTransferPipe {
  constructor() {
    this.transform = ChainNameTransferPipe.transform;
  }
  /** 转换函数 */
  static transform(chainName) {
    if (chainName === undefined) return '';
    return _services_wallet_wallet_helper__WEBPACK_IMPORTED_MODULE_0__.NODE_CHAIN_NAME_TRANSFER[chainName];
  }
}
_class = ChainNameTransferPipe;
_class.ɵfac = function ChainNameTransferPipe_Factory(t) {
  return new (t || _class)();
};
_class.ɵpipe = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefinePipe"]({
  name: "chainNameTransfer",
  type: _class,
  pure: true,
  standalone: true
});

/***/ }),

/***/ 1726:
/*!*******************************************************************************!*\
  !*** ./apps/bfswap/src/pipes/percentage-transfer/percentage-transfer.pipe.ts ***!
  \*******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   PercentageTransferPipe: () => (/* binding */ PercentageTransferPipe)
/* harmony export */ });
/* harmony import */ var bignumber_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! bignumber.js */ 61994);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 61039);
var _class;


/** 百分比转换小数 */
class PercentageTransferPipe {
  constructor() {
    this.transform = PercentageTransferPipe.transform;
  }
  /** 转换函数 */
  static transform(value) {
    if (Boolean(value) === false || value === undefined) {
      return 0;
    }
    const v = new bignumber_js__WEBPACK_IMPORTED_MODULE_0__["default"](value).multipliedBy(1e2);
    if (v.isLessThan(0.01)) {
      return '<0.01%';
    } else {
      return Number(v.toFixed(2, 1)).toString() + '%';
    }
  }
}
_class = PercentageTransferPipe;
_class.ɵfac = function PercentageTransferPipe_Factory(t) {
  return new (t || _class)();
};
_class.ɵpipe = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefinePipe"]({
  name: "percentageTransfer",
  type: _class,
  pure: true,
  standalone: true
});

/***/ }),

/***/ 34913:
/*!***************************************************************************!*\
  !*** ./apps/bfswap/src/services/liquidity-user/liquidity-user.service.ts ***!
  \***************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   LiquidityUserService: () => (/* binding */ LiquidityUserService)
/* harmony export */ });
/* harmony import */ var D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/.pnpm/@babel+runtime@7.23.2/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 52542);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 61039);
/* harmony import */ var _services_bs_fetch_bs_fetch_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ~services/bs-fetch/bs-fetch.service */ 92925);
/* harmony import */ var _bnqkl_framework_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @bnqkl/framework/core */ 63563);

var _class;




/** 池子相关接口 */
class LiquidityUserService {
  constructor() {
    /** 日志 */
    this.console = (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.inject)(_bnqkl_framework_core__WEBPACK_IMPORTED_MODULE_2__.LoggerService).createLoggerForService(this, 'liquidity-user-service');
    /** fetch服务 */
    this.fetch = (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.inject)(_services_bs_fetch_bs_fetch_service__WEBPACK_IMPORTED_MODULE_1__.SwapFetch);
    /** 后端接口 */
    this.SERVER_API = {
      /** 获取用户持仓列表 POST */
      getLiquidityUserPositionList: this.fetch.APP_URL('/bnqklswap/liquidity/user/position/list'),
      /** 获取用户资产列表 POST */
      getLiquidityUserAssetsList: this.fetch.APP_URL('/bnqklswap/liquidity/user/assets/list'),
      /** 获取用户流动性持仓 */
      getUserLiquidityHolding: this.fetch.APP_URL('/bnqklswap/liquidity/user/position/list'),
      /** 获取用户持仓详情 */
      getUserPositionDetail: this.fetch.APP_URL('/bnqklswap/liquidity/user/position/details'),
      /** 获取用户持仓比例 */
      getUserPositionPercent: this.fetch.APP_URL('/bnqklswap/liquidity/user/position/percent'),
      /** 获取用户流动性持仓冻结数量 */
      getUserLiquidityLocked: this.fetch.APP_URL('/bnqklswap/liquidity/user/position/locked'),
      /** 获取用户流动性持仓冻结列表 */
      getUserLiquidityLockedList: this.fetch.APP_URL('/bnqklswap/liquidity/user/position/locked/list')
    };
  }
  /** 获取用户锁仓量列表 */
  getUserLiquidityLockedList(options) {
    var _this = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      try {
        return _this.fetch.post(_this.SERVER_API.getUserLiquidityLockedList, options);
        // 默认数据
      } catch (error) {
        _this.console.log('getUserLiquidityLockedList', error);
        return;
      }
    })();
  }
  /** 获取用户持仓详情 */
  getUserPositionDetail(options) {
    try {
      return this.fetch.post(this.SERVER_API.getUserPositionDetail, options);
      // 默认数据
    } catch (error) {
      this.console.log('getUserPositionDetail', error);
      return;
    }
  }
  /** 获取用户锁仓量 */
  getUserLiquidityLocked(options) {
    var _this2 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      try {
        return _this2.fetch.post(_this2.SERVER_API.getUserLiquidityLocked, options);
        // 默认数据
      } catch (error) {
        _this2.console.log('getUserLiquidityLocked', error);
        return;
      }
    })();
  }
  /** 获取用户持仓比例 */
  getUserPositionPercent(options) {
    try {
      return this.fetch.post(this.SERVER_API.getUserPositionPercent, options);
      // 默认数据
    } catch (error) {
      this.console.log('getUserPositionPercent', error);
      return;
    }
  }
  /** 获取用户持仓列表 */
  getLiquidityUserPostionList(options) {
    try {
      return this.fetch.post(this.SERVER_API.getLiquidityUserPositionList, options);
      // 默认数据
    } catch (error) {
      this.console.log('getLiquidityUserPostionList', error);
      return;
    }
  }
  /** 获取用户资产列表 */
  getLiquidityUserAssetsList(options) {
    try {
      return this.fetch.post(this.SERVER_API.getLiquidityUserAssetsList, options);
      // 默认数据
    } catch (error) {
      this.console.log('getLiquidityUserPostionList', error);
      return;
    }
  }
  /** 获取用户流动性持仓 */
  getUserLiquidityHolding(options) {
    var _this3 = this;
    return (0,D_bfm_node_modules_pnpm_babel_runtime_7_23_2_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      try {
        return _this3.fetch.post(_this3.SERVER_API.getUserLiquidityHolding, options);
        // 默认数据
      } catch (error) {
        _this3.console.log('getUserLiquidityHolding', error);
        return;
      }
    })();
  }
}
_class = LiquidityUserService;
_class.ɵfac = function LiquidityUserService_Factory(t) {
  return new (t || _class)();
};
_class.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineInjectable"]({
  token: _class,
  factory: _class.ɵfac,
  providedIn: 'root'
});

/***/ })

}]);
//# sourceMappingURL=apps_bfswap_src_pages_mine_pages_my-holdings-detail_my-holdings-detail_component_ts.js.map