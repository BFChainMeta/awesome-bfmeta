// https://esm.sh/v135/@dweb-browser/js-process@0.1.7/denonext/js-process.mjs
var x = new TextEncoder();
var O = new TextDecoder();
var b;
(function(e2) {
  e2.GET = "GET", e2.POST = "POST", e2.PUT = "PUT", e2.DELETE = "DELETE", e2.OPTIONS = "OPTIONS", e2.TRACE = "TRACE", e2.PATCH = "PATCH", e2.PURGE = "PURGE", e2.HEAD = "HEAD";
})(b || (b = {}));
var y;
(function(e2) {
  e2[e2.REQUEST = 0] = "REQUEST", e2[e2.RESPONSE = 1] = "RESPONSE", e2[e2.STREAM_DATA = 2] = "STREAM_DATA", e2[e2.STREAM_PULLING = 3] = "STREAM_PULLING", e2[e2.STREAM_PAUSED = 4] = "STREAM_PAUSED", e2[e2.STREAM_END = 5] = "STREAM_END", e2[e2.STREAM_ABORT = 6] = "STREAM_ABORT", e2[e2.EVENT = 7] = "EVENT";
})(y || (y = {}));
var w;
(function(e2) {
  e2[e2.UTF8 = 2] = "UTF8", e2[e2.BASE64 = 4] = "BASE64", e2[e2.BINARY = 8] = "BINARY";
})(w || (w = {}));
var g;
(function(e2) {
  e2.SERVER = "server", e2.CLIENT = "client";
})(g || (g = {}));
var m = (e2, t2) => e2 === "GET" && t2.get("Upgrade")?.toLowerCase() === "websocket";
var E = (e2) => e2 instanceof Object && typeof e2.then == "function";
var u = class e {
  static resolve(t2) {
    let r = new e();
    return r.resolve(t2), r;
  }
  static reject(t2) {
    let r = new e();
    return r.reject(t2), r;
  }
  static sleep(t2) {
    let r = new e(), n2 = setTimeout(() => {
      n2 = void 0, r.resolve();
    }, t2);
    return r.onFinished(() => n2 !== void 0 && clearTimeout(n2)), r;
  }
  constructor() {
    Object.defineProperty(this, "promise", { enumerable: true, configurable: true, writable: true, value: void 0 }), Object.defineProperty(this, "is_resolved", { enumerable: true, configurable: true, writable: true, value: false }), Object.defineProperty(this, "is_rejected", { enumerable: true, configurable: true, writable: true, value: false }), Object.defineProperty(this, "is_finished", { enumerable: true, configurable: true, writable: true, value: false }), Object.defineProperty(this, "value", { enumerable: true, configurable: true, writable: true, value: void 0 }), Object.defineProperty(this, "reason", { enumerable: true, configurable: true, writable: true, value: void 0 }), Object.defineProperty(this, "resolve", { enumerable: true, configurable: true, writable: true, value: void 0 }), Object.defineProperty(this, "reject", { enumerable: true, configurable: true, writable: true, value: void 0 }), Object.defineProperty(this, "_innerFinally", { enumerable: true, configurable: true, writable: true, value: void 0 }), Object.defineProperty(this, "_innerFinallyArg", { enumerable: true, configurable: true, writable: true, value: void 0 }), Object.defineProperty(this, "_innerThen", { enumerable: true, configurable: true, writable: true, value: void 0 }), Object.defineProperty(this, "_innerCatch", { enumerable: true, configurable: true, writable: true, value: void 0 }), this.promise = new Promise((t2, r) => {
      this.resolve = (n2) => {
        try {
          E(n2) ? n2.then(this.resolve, this.reject) : (this.is_resolved = true, this.is_finished = true, t2(this.value = n2), this._runThen(), this._innerFinallyArg = Object.freeze({ status: "resolved", result: this.value }), this._runFinally());
        } catch (s2) {
          this.reject(s2);
        }
      }, this.reject = (n2) => {
        this.is_rejected = true, this.is_finished = true, r(this.reason = n2), this._runCatch(), this._innerFinallyArg = Object.freeze({ status: "rejected", reason: this.reason }), this._runFinally();
      };
    });
  }
  onSuccess(t2) {
    this.is_resolved ? this.__callInnerThen(t2) : (this._innerThen || (this._innerThen = [])).push(t2);
  }
  onError(t2) {
    this.is_rejected ? this.__callInnerCatch(t2) : (this._innerCatch || (this._innerCatch = [])).push(t2);
  }
  onFinished(t2) {
    this.is_finished ? this.__callInnerFinally(t2) : (this._innerFinally || (this._innerFinally = [])).push(t2);
  }
  _runFinally() {
    if (this._innerFinally) {
      for (let t2 of this._innerFinally)
        this.__callInnerFinally(t2);
      this._innerFinally = void 0;
    }
  }
  __callInnerFinally(t2) {
    queueMicrotask(async () => {
      try {
        await t2(this._innerFinallyArg);
      } catch (r) {
        console.error("Unhandled promise rejection when running onFinished", t2, r);
      }
    });
  }
  _runThen() {
    if (this._innerThen) {
      for (let t2 of this._innerThen)
        this.__callInnerThen(t2);
      this._innerThen = void 0;
    }
  }
  _runCatch() {
    if (this._innerCatch) {
      for (let t2 of this._innerCatch)
        this.__callInnerCatch(t2);
      this._innerCatch = void 0;
    }
  }
  __callInnerThen(t2) {
    queueMicrotask(async () => {
      try {
        await t2(this.value);
      } catch (r) {
        console.error("Unhandled promise rejection when running onSuccess", t2, r);
      }
    });
  }
  __callInnerCatch(t2) {
    queueMicrotask(async () => {
      try {
        await t2(this.value);
      } catch (r) {
        console.error("Unhandled promise rejection when running onError", t2, r);
      }
    });
  }
};
var P = (e2) => new d(e2);
var d = class {
  constructor(t2 = true) {
    Object.defineProperty(this, "_cbs", { enumerable: true, configurable: true, writable: true, value: /* @__PURE__ */ new Set() }), Object.defineProperty(this, "_started", { enumerable: true, configurable: true, writable: true, value: false }), Object.defineProperty(this, "_cachedEmits", { enumerable: true, configurable: true, writable: true, value: [] }), Object.defineProperty(this, "start", { enumerable: true, configurable: true, writable: true, value: () => {
      if (!this._started && (this._started = true, this._cachedEmits.length)) {
        for (let r of this._cachedEmits)
          this._emit(r, this._cbs);
        this._cachedEmits.length = 0;
      }
    } }), Object.defineProperty(this, "listen", { enumerable: true, configurable: true, writable: true, value: (r) => (this._cbs.add(r), this.start(), () => this._cbs.delete(r)) }), Object.defineProperty(this, "emit", { enumerable: true, configurable: true, writable: true, value: (...r) => {
      this._started ? this._emit(r, this._cbs) : this._cachedEmits.push(r);
    } }), Object.defineProperty(this, "emitAndClear", { enumerable: true, configurable: true, writable: true, value: (...r) => {
      if (this._started) {
        let n2 = [...this._cbs];
        this._cbs.clear(), this._emit(r, n2);
      } else
        this._cachedEmits.push(r);
    } }), Object.defineProperty(this, "_emit", { enumerable: true, configurable: true, writable: true, value: (r, n2) => {
      for (let s2 of n2)
        try {
          s2.apply(null, r);
        } catch (o) {
          console.warn(o);
        }
    } }), Object.defineProperty(this, "clear", { enumerable: true, configurable: true, writable: true, value: () => {
      this._cbs.clear();
    } }), t2 && this.start();
  }
};
var ee = new class {
  getOrPut(e2, t2, r) {
    if (e2.has(t2))
      return e2.get(t2);
    let n2 = r(t2);
    return e2.set(t2, n2), n2;
  }
  getAndRemove(e2, t2) {
    let r = e2.get(t2);
    if (e2.delete(t2))
      return r;
  }
}();
var { jsProcess: he, http: F, ipc: L, core: be } = navigator.dweb;
var { FetchError: de, IPC_METHOD: pe, IPC_ROLE: me, Ipc: ye, IpcBodySender: we, IpcEvent: ge, IpcHeaders: ve, IpcRequest: _e, IpcResponse: Te, ReadableStreamIpc: Re, ReadableStreamOut: xe } = L;
var { ServerUrlInfo: je, ServerStartResult: Oe } = F;

// helper/polyfill.ts
if (typeof Response.json !== "function") {
  Response.json = (data, init = {}) => {
    const headers = new Headers(init.headers);
    headers.set("Content-Type", "application/json");
    return new Response(JSON.stringify(data), { ...init, headers });
  };
}
(async () => {
  if (typeof URLPattern === "undefined") {
    await import("./urlpattern.polyfill.js");
  }
})();

// helper/http-helper.ts
var cors = (headers) => {
  headers.init("Access-Control-Allow-Origin", "*");
  headers.init("Access-Control-Allow-Headers", "*");
  headers.init("Access-Control-Allow-Methods", "*");
  return headers;
};
var HttpServer = class {
  constructor() {
    this._serverP = F.createHttpDwebServer(he, this._getOptions());
    this._listener = this.getServer().then((server) => server.listen());
  }
  getServer() {
    return this._serverP;
  }
  async getStartResult() {
    return this._serverP.then((server) => server.startResult);
  }
  async stop() {
    const server = await this._serverP;
    return await server.close();
  }
};

// https://esm.sh/v126/deep-object-diff@1.1.9/denonext/deep-object-diff.mjs
var u2 = (t2) => t2 instanceof Date;
var m2 = (t2) => Object.keys(t2).length === 0;
var i = (t2) => t2 != null && typeof t2 == "object";
var n = (t2, ...e2) => Object.prototype.hasOwnProperty.call(t2, ...e2);
var d2 = (t2) => i(t2) && m2(t2);
var p = () => /* @__PURE__ */ Object.create(null);
var D = (t2, e2) => t2 === e2 || !i(t2) || !i(e2) ? {} : Object.keys(e2).reduce((o, r) => {
  if (n(t2, r)) {
    let f2 = D(t2[r], e2[r]);
    return i(f2) && m2(f2) || (o[r] = f2), o;
  }
  return o[r] = e2[r], o;
}, p());
var a = D;
var x2 = (t2, e2) => t2 === e2 || !i(t2) || !i(e2) ? {} : Object.keys(t2).reduce((o, r) => {
  if (n(e2, r)) {
    let f2 = x2(t2[r], e2[r]);
    return i(f2) && m2(f2) || (o[r] = f2), o;
  }
  return o[r] = void 0, o;
}, p());
var b2 = x2;
var P2 = (t2, e2) => t2 === e2 ? {} : !i(t2) || !i(e2) ? e2 : u2(t2) || u2(e2) ? t2.valueOf() == e2.valueOf() ? {} : e2 : Object.keys(e2).reduce((o, r) => {
  if (n(t2, r)) {
    let f2 = P2(t2[r], e2[r]);
    return d2(f2) && !u2(f2) && (d2(t2[r]) || !d2(e2[r])) || (o[r] = f2), o;
  }
  return o;
}, p());
var j = P2;
var E2 = (t2, e2) => ({ added: a(t2, e2), deleted: b2(t2, e2), updated: j(t2, e2) });
var W = E2;

// helper/mwebview-helper.ts
var mwebview_open = async (wid, url) => {
  const openUrl = new URL(`file://mwebview.browser.dweb/open`);
  openUrl.searchParams.set("wid", wid);
  openUrl.searchParams.set("url", url);
  const state = await he.nativeFetch(openUrl).object();
  all_webview_status.diffState(state);
  return state;
};
var mwebview_activate = async (wid) => {
  const activateUrl = new URL(`file://mwebview.browser.dweb/activate`);
  activateUrl.searchParams.set("wid", wid);
  return await he.nativeFetch(activateUrl).text();
};
var mwebview_destroy = async () => {
  return await he.nativeFetch(`file://mwebview.browser.dweb/close/app`).boolean();
};
var AllWebviewStatus = class extends Map {
  constructor() {
    super(...arguments);
    this.signal = P();
    this.oldWebviewState = {};
  }
  last() {
    return [...this.entries()].at(-1);
  }
  /**
   * 对比状态的更新
   * @param diff
   */
  diffFactory(diff) {
    for (const id in diff.added) {
      this.set(id, diff.added[id]);
    }
    for (const id in diff.deleted) {
      this.delete(id);
    }
    for (const id in diff.updated) {
      this.set(id, diff.updated[id]);
    }
    this.signal.emit(this.size);
  }
  diffState(newState) {
    const diff = W(this.oldWebviewState, newState.views);
    this.oldWebviewState = newState.views;
    this.diffFactory(diff);
  }
};
var all_webview_status = new AllWebviewStatus();
var _false = true;
var sync_mwebview_status = async () => {
  if (_false === false) {
    return;
  }
  _false = false;
  const ipc = await navigator.dweb.jsProcess.connect("mwebview.browser.dweb");
  ipc.onEvent((ipcEvent) => {
    if (ipcEvent.name === "state") {
      const newState = JSON.parse(ipcEvent.text);
      all_webview_status.diffState(newState);
    }
  });
};

// http-api-server.ts
var DNS_PREFIX = "/dns.std.dweb/";
var INTERNAL_PREFIX = "/internal/";
var Server_api = class extends HttpServer {
  constructor(widPo, handlers = []) {
    super();
    this.widPo = widPo;
    this.handlers = handlers;
    this.callbacks = /* @__PURE__ */ new Map();
  }
  _getOptions() {
    return {
      subdomain: "api"
    };
  }
  async start() {
    const serverIpc = await this._listener;
    return serverIpc.onFetch(...this.handlers, this._provider.bind(this)).internalServerError().cors();
  }
  async _provider(event) {
    if (event.pathname.startsWith(DNS_PREFIX)) {
      return this._onDns(event);
    } else if (event.pathname.startsWith(INTERNAL_PREFIX)) {
      return this._onInternal(event);
    }
    return this._onApi(event);
  }
  async _onDns(event) {
    const url = new URL("file:/" + event.pathname + event.search);
    const pathname = url.pathname;
    const result = async () => {
      if (pathname === "/restart") {
        setTimeout(() => {
          he.restart();
        }, 200);
        return Response.json({ success: true, message: "restart ok" });
      }
      if (pathname === "/close") {
        const bool = await mwebview_destroy();
        return Response.json({ success: bool, message: "window close" });
      }
      if (pathname === "/query") {
        const mmid = event.searchParams.get("mmid");
        const res = await he.nativeFetch(`file://dns.std.dweb/query?app_id=${mmid}`);
        return res;
      }
      return Response.json({ success: false, message: "no action for serviceWorker Factory !!!" });
    };
    return await result();
  }
  async _onInternal(event) {
    const pathname = event.pathname.slice(INTERNAL_PREFIX.length);
    if (pathname === "window-info") {
      return Response.json({ wid: await this.widPo.promise });
    }
    if (pathname === "callback") {
      const id = event.searchParams.get("id");
      if (!id) {
        return Te.fromText(event.req_id, 500, new ve(), "invalid search params, miss 'id'", event.ipc);
      }
      const ipc = await ee.getOrPut(this.callbacks, id, () => new u()).promise;
      const response = await ipc.request(event.url.href, event.ipcRequest.toRequest());
      return response.toResponse();
    }
    if (pathname === "registry-callback") {
      const id = event.searchParams.get("id");
      if (!id) {
        return Te.fromText(event.req_id, 500, new ve(), "invalid search params, miss 'id'", event.ipc);
      }
      const readableStreamIpc = new Re(
        {
          mmid: "localhost.dweb",
          ipc_support_protocols: { cbor: false, protobuf: false, raw: false },
          dweb_deeplinks: [],
          categories: [],
          name: ""
        },
        //@ts-ignore
        me.SERVER
      );
      readableStreamIpc.bindIncomeStream(event.request.body);
      ee.getOrPut(this.callbacks, id, () => new u()).resolve(readableStreamIpc);
      return Te.fromStream(event.req_id, 200, void 0, readableStreamIpc.stream, event.ipc);
    }
    if (pathname.startsWith("/usr")) {
      const response = await he.nativeRequest(`file://${pathname}`);
      return new Te(event.req_id, response.statusCode, response.headers, response.body, event.ipc);
    }
  }
  /**
   * request 事件处理器
   */
  async _onApi(event, connect = (mmid) => he.connect(mmid), useIpcBody = true) {
    const { pathname, search } = event;
    const path = `file:/${pathname}${search}`;
    const mmid = new URL(path).host;
    const targetIpc = await connect(mmid);
    const ipcProxyRequest = useIpcBody ? new _e(
      //
      targetIpc.allocReqId(),
      path,
      event.method,
      event.headers,
      event.ipcRequest.body,
      targetIpc
    ) : _e.fromStream(
      targetIpc.allocReqId(),
      path,
      event.method,
      event.headers,
      await event.ipcRequest.body.stream(),
      targetIpc
    );
    targetIpc.postMessage(ipcProxyRequest);
    const ipcProxyResponse = await targetIpc.registerReqId(ipcProxyRequest.req_id).promise;
    return ipcProxyResponse.toResponse();
  }
};

// helper/promise-toggle.ts
var PromiseToggle = class {
  constructor(initState) {
    this._open = new u();
    this._close = new u();
    if (initState.type === "open") {
      this.toggleOpen(initState.value);
    } else {
      this.toggleClose(initState.value);
    }
  }
  waitOpen() {
    return this._open.promise;
  }
  waitClose() {
    return this._close.promise;
  }
  get isOpen() {
    return this._open.is_resolved;
  }
  get isClose() {
    return this._close.is_resolved;
  }
  get openValue() {
    return this._open.value;
  }
  get closeValue() {
    return this._close.value;
  }
  /**
   * 切换到开的状态
   * @param value
   * @returns
   */
  toggleOpen(value) {
    if (this._open.is_resolved) {
      return;
    }
    this._open.resolve(value);
    if (this._close.is_resolved) {
      this._close = new u();
    }
  }
  /**
   * 切换到开的状态
   * @param value
   * @returns
   */
  toggleClose(value) {
    if (this._close.is_resolved) {
      return;
    }
    this._close.resolve(value);
    if (this._open.is_resolved) {
      this._open = new u();
    }
  }
};

// http-external-server.ts
var Server_external = class extends HttpServer {
  constructor(handlers = []) {
    super();
    this.handlers = handlers;
    this.token = crypto.randomUUID();
    this.ipcPo = new PromiseToggle({ type: "close", value: void 0 });
    this.externalWaitters = /* @__PURE__ */ new Map();
    // 是否需要激活
    this.needActivity = true;
    he.onFetch(async (event) => {
      if (event.pathname == "/wait-external-ready" /* WAIT_EXTERNAL_READY */) {
        await this.ipcPo.waitOpen();
      }
      return { status: 200 };
    });
  }
  /**
   * 这个token是内部使用的，就作为 特殊的 url.pathname 来处理内部操作
   */
  _getOptions() {
    return {
      subdomain: "external"
    };
  }
  async start() {
    const serverIpc = await this._listener;
    return serverIpc.onFetch(...this.handlers, this._provider.bind(this)).internalServerError().cors();
  }
  //窗口关闭的时候需要重新等待连接
  closeRegisterIpc() {
    this.ipcPo.toggleClose();
  }
  async _provider(event) {
    const { pathname } = event;
    if (pathname.startsWith(`/${this.token}`)) {
      if (m(event.method, event.headers)) {
        if (this.ipcPo.isOpen) {
          this.ipcPo.openValue.close();
          this.ipcPo.toggleClose();
        }
        const streamIpc = new Re(
          {
            mmid: he.mmid,
            name: he.mmid,
            ipc_support_protocols: {
              cbor: false,
              protobuf: false,
              raw: false
            },
            dweb_deeplinks: [],
            categories: []
          },
          //@ts-ignore
          me.SERVER
        );
        this.ipcPo.toggleOpen(streamIpc);
        void streamIpc.bindIncomeStream(event.body).finally(() => {
          this.ipcPo.toggleClose();
        });
        streamIpc.onFetch(async (event2) => {
          const mmid = event2.headers.get("mmid");
          if (!mmid) {
            return new Response(null, { status: 502 });
          }
          this.needActivity = true;
          await ee.getOrPut(this.externalWaitters, mmid, async (_key) => {
            let ipc2;
            try {
              ipc2 = await he.connect(mmid);
              const deleteCache = () => {
                this.externalWaitters.delete(mmid);
                off1();
              };
              const off1 = ipc2.onClose(deleteCache);
            } catch (err) {
              this.externalWaitters.delete(mmid);
              throw err;
            }
            ipc2.postMessage(ge.fromText("renderer" /* RENDERER */, "renderer" /* RENDERER */));
            this.needActivity = false;
            await ipc2.request(`file://${mmid}${"/wait-external-ready" /* WAIT_EXTERNAL_READY */}`);
            return ipc2;
          });
          const ipc = await this.externalWaitters.get(mmid);
          if (ipc && this.needActivity) {
            ipc.postMessage(ge.fromText("renderer" /* RENDERER */, "renderer" /* RENDERER */));
          }
          const ext_options = this._getOptions();
          event2.headers.append("X-Dweb-Host", he.mmid);
          return await he.nativeFetch(
            `https://${ext_options.subdomain}.${mmid}${event2.pathname}${event2.search}`,
            {
              method: event2.method,
              headers: event2.headers,
              body: event2.body
            }
          );
        });
        return { body: streamIpc.stream };
      }
      return { status: 500 };
    } else {
      const ipc = await this.ipcPo.waitOpen();
      const response = (await ipc.request(event.request.url, event.request)).toResponse();
      return Te.fromResponse(event.ipcRequest.req_id, response, event.ipc);
    }
  }
};

// shim/db.shim.ts
var setupDB = async (sessionId) => {
  const KEY = "--plaoc-session-id--";
  if (localStorage.getItem(KEY) !== sessionId) {
    localStorage.clear();
    localStorage.setItem(KEY, sessionId);
    sessionStorage.clear();
    const tasks = [];
    const t1 = indexedDB.databases().then((dbs) => {
      for (const db of dbs) {
        if (db.name) {
          indexedDB.deleteDatabase(db.name);
        }
      }
    });
    tasks.push(t1.catch(console.error));
    if (typeof cookieStore === "object") {
      const t2 = cookieStore.getAll().then((cookies) => {
        for (const c2 of cookies) {
          cookieStore.delete(c2.name);
        }
      });
      tasks.push(t2.catch(console.error));
    }
    await Promise.all(tasks);
    location.replace(location.href);
  }
};

// shim/fetch.shim.ts
var setupFetch = () => {
  const nativeFetch = fetch;
  const dwebFetch = (input, init) => {
    return nativeFetch(new DwebRequest(input, init));
  };
  const getBaseUrl = typeof document === "object" ? () => document.baseURI : () => location.href;
  const NativeRequest = Request;
  class DwebRequest extends NativeRequest {
    constructor(input, init) {
      let inputUrl;
      if (input instanceof URL) {
        inputUrl = input;
      } else if (typeof input === "string") {
        inputUrl = new URL(input, getBaseUrl());
      }
      if (inputUrl !== void 0) {
        if (inputUrl.username) {
          const dwebHeaders = new Headers(init?.headers);
          dwebHeaders.set("X-Dweb-Host", decodeURIComponent(inputUrl.username));
          init = {
            ...init,
            headers: dwebHeaders
          };
        }
        inputUrl.username = "";
        input = inputUrl;
      }
      super(input, init);
    }
  }
  const G = typeof globalThis === "object" ? globalThis : self;
  Object.assign(G, {
    fetch: dwebFetch,
    Request: DwebRequest,
    dwebShim: { nativeFetch, NativeRequest }
  });
};

// https://esm.sh/v128/is-mobile@4.0.0/denonext/is-mobile.mjs
var c = Object.create;
var l = Object.defineProperty;
var g2 = Object.getOwnPropertyDescriptor;
var x3 = Object.getOwnPropertyNames;
var h = Object.getPrototypeOf;
var k = Object.prototype.hasOwnProperty;
var v = (i2, e2) => () => (e2 || i2((e2 = { exports: {} }).exports, e2), e2.exports);
var y2 = (i2, e2) => {
  for (var o in e2)
    l(i2, o, { get: e2[o], enumerable: true });
};
var s = (i2, e2, o, p2) => {
  if (e2 && typeof e2 == "object" || typeof e2 == "function")
    for (let r of x3(e2))
      !k.call(i2, r) && r !== o && l(i2, r, { get: () => e2[r], enumerable: !(p2 = g2(e2, r)) || p2.enumerable });
  return i2;
};
var a2 = (i2, e2, o) => (s(i2, e2, "default"), o && s(o, e2, "default"));
var b3 = (i2, e2, o) => (o = i2 != null ? c(h(i2)) : {}, s(e2 || !i2 || !i2.__esModule ? l(o, "default", { value: i2, enumerable: true }) : o, i2));
var f = v((z, n2) => {
  "use strict";
  n2.exports = d3;
  n2.exports.isMobile = d3;
  n2.exports.default = d3;
  var _ = /(android|bb\d+|meego).+mobile|armv7l|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|mobile.+firefox|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series[46]0|samsungbrowser.*mobile|symbian|treo|up\.(browser|link)|vodafone|wap|windows (ce|phone)|xda|xiino/i, w2 = /CrOS/, M = /android|ipad|playbook|silk/i;
  function d3(i2) {
    i2 || (i2 = {});
    let e2 = i2.ua;
    if (!e2 && typeof navigator < "u" && (e2 = navigator.userAgent), e2 && e2.headers && typeof e2.headers["user-agent"] == "string" && (e2 = e2.headers["user-agent"]), typeof e2 != "string")
      return false;
    let o = _.test(e2) && !w2.test(e2) || !!i2.tablet && M.test(e2);
    return !o && i2.tablet && i2.featureDetect && navigator && navigator.maxTouchPoints > 1 && e2.indexOf("Macintosh") !== -1 && e2.indexOf("Safari") !== -1 && (o = true), o;
  }
});
var t = {};
y2(t, { default: () => R, isMobile: () => E3 });
var m3 = b3(f());
a2(t, b3(f()));
var { isMobile: E3 } = m3;
var { default: u3, ...O2 } = m3;
var R = u3 !== void 0 ? u3 : O2;

// http-www-server.ts
var CONFIG_PREFIX = "/config.sys.dweb/";
var Server_www = class extends HttpServer {
  constructor(plaocConfig, handlers = []) {
    super();
    this.plaocConfig = plaocConfig;
    this.handlers = handlers;
    this.lang = null;
    this.sessionInfo = he.nativeFetch("file:///usr/sys/session.json").then((res) => res.json());
  }
  get jsonPlaoc() {
    return this.plaocConfig.config;
  }
  _getOptions() {
    return {
      subdomain: "www"
    };
  }
  async start() {
    const lang = await he.nativeFetch("file://config.sys.dweb/getLang").text();
    if (lang) {
      this.lang = lang;
    } else if (this.jsonPlaoc) {
      this.lang = this.jsonPlaoc.defaultConfig.lang;
    }
    const serverIpc = await this._listener;
    return serverIpc.onFetch(...this.handlers, this._provider.bind(this)).noFound();
  }
  async _provider(request, root = "www") {
    let { pathname } = request;
    if (pathname.startsWith(CONFIG_PREFIX)) {
      return this._config(request);
    }
    let remoteIpcResponse;
    if (this.jsonPlaoc) {
      const proxyRequest = await this._plaocForwarder(request, this.jsonPlaoc);
      pathname = proxyRequest.url.pathname;
      const plaocShims = new Set((proxyRequest.url.searchParams.get("plaoc-shim") ?? "").split(",").filter(Boolean));
      if (plaocShims.has("fetch")) {
        remoteIpcResponse = await he.nativeRequest(`file:///usr/${root}${pathname}`, {
          headers: proxyRequest.headers
        });
        const rawText = await remoteIpcResponse.toResponse().text();
        remoteIpcResponse = Te.fromText(
          remoteIpcResponse.req_id,
          remoteIpcResponse.statusCode,
          remoteIpcResponse.headers,
          `;(${setupFetch.toString()})();${rawText}`,
          remoteIpcResponse.ipc
        );
      } else {
        remoteIpcResponse = await he.nativeRequest(`file:///usr/${root}${pathname}?mode=stream`, {
          headers: proxyRequest.headers
        });
        if (remoteIpcResponse.headers.get("Content-Type")?.includes("text/html") && !plaocShims.has("raw") && E3()) {
          const rawText = await remoteIpcResponse.toResponse().text();
          const text = `<script>(${setupDB.toString()})("${(await this.sessionInfo).installTime}");<\/script>${rawText}`;
          remoteIpcResponse = Te.fromText(
            remoteIpcResponse.req_id,
            remoteIpcResponse.statusCode,
            remoteIpcResponse.headers,
            text,
            remoteIpcResponse.ipc
          );
        }
      }
    } else {
      remoteIpcResponse = await he.nativeRequest(`file:///usr/${root}${pathname}?mode=stream`);
    }
    const ipcResponse = new Te(
      request.req_id,
      remoteIpcResponse.statusCode,
      cors(remoteIpcResponse.headers),
      remoteIpcResponse.body,
      request.ipc
    );
    return ipcResponse;
  }
  async _config(event) {
    const pathname = event.pathname.slice(CONFIG_PREFIX.length);
    if (pathname.startsWith("/setLang")) {
      const lang = event.searchParams.get("lang");
      this.lang = lang;
    }
    return he.nativeFetch(`file:/${event.pathname}${event.search}`);
  }
  /**
   * 转发plaoc.json请求
   * @param request
   * @param config
   */
  async _plaocForwarder(request, config) {
    const redirects = config.redirect;
    for (const redirect of redirects) {
      if (!this._matchMethod(request.method, redirect.matchMethod)) {
        continue;
      }
      const urlPattern = new URLPattern({
        pathname: redirect.matchUrl.pathname,
        search: redirect.matchUrl.search
      });
      const pattern = urlPattern.exec(request.url);
      if (!pattern)
        continue;
      const url = redirect.to.url.replace(/\{\{\s*(.*?)\s*\}\}/g, (_exp, match) => {
        const func = new Function("pattern", "lang", "config", `return ${match}`);
        return func(pattern, this.lang, config);
      }).replace(/\\/g, "/").replace(/\/\//g, "/");
      const newUrl = new URL(url, request.url);
      request.url.hash = newUrl.hash;
      request.url.host = newUrl.host;
      request.url.hostname = newUrl.hostname;
      request.url.href = newUrl.href;
      request.url.password = newUrl.password;
      request.url.pathname = newUrl.pathname;
      request.url.port = newUrl.port;
      request.url.protocol = newUrl.protocol;
      request.url.search = newUrl.search;
      request.url.username = newUrl.username;
      const appendHeaders = redirect.to.appendHeaders;
      if (appendHeaders && Object.keys(appendHeaders).length !== 0) {
        for (const header of Object.entries(appendHeaders)) {
          request.headers.append(header[0], header[1]);
        }
      }
      const removeHeaders = redirect.to.removeHeaders;
      if (removeHeaders && Object.keys(removeHeaders).length !== 0) {
        for (const header of Object.keys(removeHeaders)) {
          request.headers.delete(header[0]);
        }
      }
      return request;
    }
    return request;
  }
  /**
   * 匹配 * 和 method
   * @param method
   * @param methods
   * @returns
   */
  _matchMethod(method, methods) {
    if (!methods)
      return true;
    if (methods.join().indexOf("*") !== -1)
      return true;
    for (const me2 in methods) {
      if (me2.toLocaleUpperCase() === method) {
        return true;
      }
    }
    return false;
  }
};

// shim/crypto.shims.ts
if (typeof crypto.randomUUID !== "function") {
  crypto.randomUUID = function randomUUID() {
    return "10000000-1000-4000-8000-100000000000".replace(/[018]/g, (_c) => {
      const c2 = +_c;
      return (c2 ^ crypto.getRandomValues(new Uint8Array(1))[0] & 15 >> c2 / 4).toString(16);
    });
  };
}

// helper/queue.ts
var queue = (fun) => {
  let queuer = Promise.resolve();
  return function(...args) {
    return queuer = queuer.finally(() => fun(...args));
  };
};

// middleware-importer.ts
var MiddlewareImporter = class {
  static async init(path) {
    if (!path) {
      return [];
    }
    try {
      const middleware = await import(join("./middleware", path));
      console.log("middleware=>", middleware);
      return middleware.default.handlers;
    } catch (e2) {
      console.log("MiddlewareConfig=>", e2);
    }
  }
};
function join(...paths) {
  let joinedPath = paths[0];
  for (let i2 = 1; i2 < paths.length; i2++) {
    let path = paths[i2];
    if (path.startsWith(".")) {
      path = path.substring(1);
    }
    const precededBySlash = joinedPath.endsWith("/");
    const followedBySlash = path.startsWith("/");
    if (precededBySlash && followedBySlash) {
      joinedPath += path.substring(1);
    } else if (!precededBySlash && !followedBySlash) {
      joinedPath += "/" + path;
    } else {
      joinedPath += path;
    }
  }
  return joinedPath;
}

// plaoc-config.ts
var PlaocConfig = class {
  constructor(config) {
    this.config = config;
  }
  static async init() {
    try {
      const readPlaoc = await he.nativeRequest(`file:///usr/www/plaoc.json`);
      return new PlaocConfig(JSON.parse(await readPlaoc.body.text()));
    } catch {
      return new PlaocConfig({ redirect: [], defaultConfig: { lang: "en" } });
    }
  }
};

// main.ts
var main = async () => {
  const indexUrlPo = new u();
  const widPo = new u();
  const tryOpenView = queue(async () => {
    const url = await indexUrlPo.promise;
    const wid = await widPo.promise;
    if (all_webview_status.size === 0) {
      await sync_mwebview_status();
      console.log("mwebview_open=>", url, wid);
      await mwebview_open(wid, url);
    } else {
      console.log("mwebview_activate=>", url, wid);
      await mwebview_activate(wid);
    }
  });
  he.onActivity(async (_ipcEvent) => {
    console.log(`${he.mmid} onActivity`);
  });
  he.onRenderer((ipcEvent) => {
    console.log(`${he.mmid} onRenderer`);
    widPo.resolve(ipcEvent.text);
    tryOpenView();
  });
  he.onClose(() => {
    console.log("app\u540E\u53F0\u88AB\u5173\u95ED\u3002");
  });
  const plaocConfig = await PlaocConfig.init();
  const wwwServer = new Server_www(plaocConfig, await MiddlewareImporter.init(plaocConfig.config.middlewares?.www));
  const externalServer = new Server_external(await MiddlewareImporter.init(plaocConfig.config.middlewares?.external));
  const apiServer = new Server_api(widPo, await MiddlewareImporter.init(plaocConfig.config.middlewares?.api));
  const wwwListenerTask = wwwServer.start().finally(() => console.log("wwwServer started"));
  const externalListenerTask = externalServer.start().finally(() => console.log("externalServer started"));
  const apiListenerTask = apiServer.start().finally(() => console.log("apiServer started"));
  all_webview_status.signal.listen((size) => {
    if (size === 0) {
      externalServer.closeRegisterIpc();
    }
  });
  const wwwStartResult = await wwwServer.getStartResult();
  await apiServer.getStartResult();
  const indexUrl = wwwStartResult.urlInfo.buildHtmlUrl(false, (url) => {
    url.pathname = "/index.html";
    url.searchParams.set("X-Plaoc-External-Url" /* EXTERNAL_URL */, externalServer.token);
  });
  console.log("open in browser:", indexUrl.href);
  await Promise.all([wwwListenerTask, externalListenerTask, apiListenerTask]);
  indexUrlPo.resolve(indexUrl.href);
  widPo.resolve("renderer");
  tryOpenView();
};
main();

// middlewares/base-router.ts
var BaseRouter = class {
};

// middlewares/router.ts
var Router = class extends BaseRouter {
  constructor() {
    super();
    this.handlers = [];
  }
  use(...handlers) {
    this.handlers.push(...handlers);
  }
};
export {
  Router
};
//!此处为js ipc特有垫片，防止有些webview版本过低，出现无法支持的函数
