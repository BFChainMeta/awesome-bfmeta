var __defProp = Object.defineProperty;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __esm = (fn, res) => function __init() {
  return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
};
var __export = (target2, all) => {
  for (var name in all)
    __defProp(target2, name, { get: all[name], enumerable: true });
};
var __accessCheck = (obj, member, msg) => {
  if (!member.has(obj))
    throw TypeError("Cannot " + msg);
};
var __privateGet = (obj, member, getter) => {
  __accessCheck(obj, member, "read from private field");
  return getter ? getter.call(obj) : member.get(obj);
};
var __privateAdd = (obj, member, value) => {
  if (member.has(obj))
    throw TypeError("Cannot add the same private member more than once");
  member instanceof WeakSet ? member.add(obj) : member.set(obj, value);
};

// https://esm.sh/v131/urlpattern-polyfill@9.0.0/denonext/urlpattern-polyfill.mjs
function et2(t2, e) {
  return (e ? /^[\x00-\xFF]*$/ : /^[\x00-\x7F]*$/).test(t2);
}
function M2(t2, e = false) {
  let s2 = [], i2 = 0;
  for (; i2 < t2.length; ) {
    let o = t2[i2], u4 = function(h3) {
      if (!e)
        throw new TypeError(h3);
      s2.push({ type: "INVALID_CHAR", index: i2, value: t2[i2++] });
    };
    if (o === "*") {
      s2.push({ type: "ASTERISK", index: i2, value: t2[i2++] });
      continue;
    }
    if (o === "+" || o === "?") {
      s2.push({ type: "OTHER_MODIFIER", index: i2, value: t2[i2++] });
      continue;
    }
    if (o === "\\") {
      s2.push({ type: "ESCAPED_CHAR", index: i2++, value: t2[i2++] });
      continue;
    }
    if (o === "{") {
      s2.push({ type: "OPEN", index: i2, value: t2[i2++] });
      continue;
    }
    if (o === "}") {
      s2.push({ type: "CLOSE", index: i2, value: t2[i2++] });
      continue;
    }
    if (o === ":") {
      let h3 = "", r = i2 + 1;
      for (; r < t2.length; ) {
        let a3 = t2.substr(r, 1);
        if (r === i2 + 1 && Y2.test(a3) || r !== i2 + 1 && tt2.test(a3)) {
          h3 += t2[r++];
          continue;
        }
        break;
      }
      if (!h3) {
        u4(`Missing parameter name at ${i2}`);
        continue;
      }
      s2.push({ type: "NAME", index: i2, value: h3 }), i2 = r;
      continue;
    }
    if (o === "(") {
      let h3 = 1, r = "", a3 = i2 + 1, n2 = false;
      if (t2[a3] === "?") {
        u4(`Pattern cannot start with "?" at ${a3}`);
        continue;
      }
      for (; a3 < t2.length; ) {
        if (!et2(t2[a3], false)) {
          u4(`Invalid character '${t2[a3]}' at ${a3}.`), n2 = true;
          break;
        }
        if (t2[a3] === "\\") {
          r += t2[a3++] + t2[a3++];
          continue;
        }
        if (t2[a3] === ")") {
          if (h3--, h3 === 0) {
            a3++;
            break;
          }
        } else if (t2[a3] === "(" && (h3++, t2[a3 + 1] !== "?")) {
          u4(`Capturing groups are not allowed at ${a3}`), n2 = true;
          break;
        }
        r += t2[a3++];
      }
      if (n2)
        continue;
      if (h3) {
        u4(`Unbalanced pattern at ${i2}`);
        continue;
      }
      if (!r) {
        u4(`Missing pattern at ${i2}`);
        continue;
      }
      s2.push({ type: "REGEX", index: i2, value: r }), i2 = a3;
      continue;
    }
    s2.push({ type: "CHAR", index: i2, value: t2[i2++] });
  }
  return s2.push({ type: "END", index: i2, value: "" }), s2;
}
function F(t2, e = {}) {
  let s2 = M2(t2);
  e.delimiter ??= "/#?", e.prefixes ??= "./";
  let i2 = `[^${g3(e.delimiter)}]+?`, o = [], u4 = 0, h3 = 0, r = "", a3 = /* @__PURE__ */ new Set(), n2 = (p3) => {
    if (h3 < s2.length && s2[h3].type === p3)
      return s2[h3++].value;
  }, f2 = () => n2("OTHER_MODIFIER") ?? n2("ASTERISK"), w2 = (p3) => {
    let c3 = n2(p3);
    if (c3 !== void 0)
      return c3;
    let { type: l2, index: v3 } = s2[h3];
    throw new TypeError(`Unexpected ${l2} at ${v3}, expected ${p3}`);
  }, R3 = () => {
    let p3 = "", c3;
    for (; c3 = n2("CHAR") ?? n2("ESCAPED_CHAR"); )
      p3 += c3;
    return p3;
  }, Q2 = (p3) => p3, U2 = e.encodePart || Q2, O3 = "", T2 = (p3) => {
    O3 += p3;
  }, I2 = () => {
    O3.length && (o.push(new P3(3, "", "", U2(O3), "", 3)), O3 = "");
  }, _ = (p3, c3, l2, v3, b4) => {
    let d3 = 3;
    switch (b4) {
      case "?":
        d3 = 1;
        break;
      case "*":
        d3 = 0;
        break;
      case "+":
        d3 = 2;
        break;
    }
    if (!c3 && !l2 && d3 === 3) {
      T2(p3);
      return;
    }
    if (I2(), !c3 && !l2) {
      if (!p3)
        return;
      o.push(new P3(3, "", "", U2(p3), "", d3));
      return;
    }
    let m4;
    l2 ? l2 === "*" ? m4 = D3 : m4 = l2 : m4 = i2;
    let C2 = 2;
    m4 === i2 ? (C2 = 1, m4 = "") : m4 === D3 && (C2 = 0, m4 = "");
    let x4;
    if (c3 ? x4 = c3 : l2 && (x4 = u4++), a3.has(x4))
      throw new TypeError(`Duplicate name '${x4}'.`);
    a3.add(x4), o.push(new P3(C2, x4, U2(p3), m4, U2(v3), d3));
  };
  for (; h3 < s2.length; ) {
    let p3 = n2("CHAR"), c3 = n2("NAME"), l2 = n2("REGEX");
    if (!c3 && !l2 && (l2 = n2("ASTERISK")), c3 || l2) {
      let b4 = p3 ?? "";
      e.prefixes.indexOf(b4) === -1 && (T2(b4), b4 = ""), I2();
      let d3 = f2();
      _(b4, c3, l2, "", d3);
      continue;
    }
    let v3 = p3 ?? n2("ESCAPED_CHAR");
    if (v3) {
      T2(v3);
      continue;
    }
    if (n2("OPEN")) {
      let b4 = R3(), d3 = n2("NAME"), m4 = n2("REGEX");
      !d3 && !m4 && (m4 = n2("ASTERISK"));
      let C2 = R3();
      w2("CLOSE");
      let x4 = f2();
      _(b4, d3, m4, C2, x4);
      continue;
    }
    I2(), w2("END");
  }
  return o;
}
function g3(t2) {
  return t2.replace(/([.+*?^${}()[\]|/\\])/g, "\\$1");
}
function j3(t2) {
  return t2 && t2.ignoreCase ? "ui" : "u";
}
function st2(t2, e, s2) {
  return W3(F(t2, s2), e, s2);
}
function k3(t2) {
  switch (t2) {
    case 0:
      return "*";
    case 1:
      return "?";
    case 2:
      return "+";
    case 3:
      return "";
  }
}
function W3(t2, e, s2 = {}) {
  s2.delimiter ??= "/#?", s2.prefixes ??= "./", s2.sensitive ??= false, s2.strict ??= false, s2.end ??= true, s2.start ??= true, s2.endsWith = "";
  let i2 = s2.start ? "^" : "";
  for (let r of t2) {
    if (r.type === 3) {
      r.modifier === 3 ? i2 += g3(r.value) : i2 += `(?:${g3(r.value)})${k3(r.modifier)}`;
      continue;
    }
    e && e.push(r.name);
    let a3 = `[^${g3(s2.delimiter)}]+?`, n2 = r.value;
    if (r.type === 1 ? n2 = a3 : r.type === 0 && (n2 = D3), !r.prefix.length && !r.suffix.length) {
      r.modifier === 3 || r.modifier === 1 ? i2 += `(${n2})${k3(r.modifier)}` : i2 += `((?:${n2})${k3(r.modifier)})`;
      continue;
    }
    if (r.modifier === 3 || r.modifier === 1) {
      i2 += `(?:${g3(r.prefix)}(${n2})${g3(r.suffix)})`, i2 += k3(r.modifier);
      continue;
    }
    i2 += `(?:${g3(r.prefix)}`, i2 += `((?:${n2})(?:`, i2 += g3(r.suffix), i2 += g3(r.prefix), i2 += `(?:${n2}))*)${g3(r.suffix)})`, r.modifier === 0 && (i2 += "?");
  }
  let o = `[${g3(s2.endsWith)}]|$`, u4 = `[${g3(s2.delimiter)}]`;
  if (s2.end)
    return s2.strict || (i2 += `${u4}?`), s2.endsWith.length ? i2 += `(?=${o})` : i2 += "$", new RegExp(i2, j3(s2));
  s2.strict || (i2 += `(?:${u4}(?=${o}))?`);
  let h3 = false;
  if (t2.length) {
    let r = t2[t2.length - 1];
    r.type === 3 && r.modifier === 3 && (h3 = s2.delimiter.indexOf(r) > -1);
  }
  return h3 || (i2 += `(?=${u4}|${o})`), new RegExp(i2, j3(s2));
}
function nt2(t2, e) {
  return t2.length ? t2[0] === "/" ? true : !e || t2.length < 2 ? false : (t2[0] == "\\" || t2[0] == "{") && t2[1] == "/" : false;
}
function K2(t2, e) {
  return t2.startsWith(e) ? t2.substring(e.length, t2.length) : t2;
}
function ht2(t2, e) {
  return t2.endsWith(e) ? t2.substr(0, t2.length - e.length) : t2;
}
function G2(t2) {
  return !t2 || t2.length < 2 ? false : t2[0] === "[" || (t2[0] === "\\" || t2[0] === "{") && t2[1] === "[";
}
function V2(t2) {
  if (!t2)
    return true;
  for (let e of X2)
    if (t2.test(e))
      return true;
  return false;
}
function at2(t2, e) {
  if (t2 = K2(t2, "#"), e || t2 === "")
    return t2;
  let s2 = new URL("https://example.com");
  return s2.hash = t2, s2.hash ? s2.hash.substring(1, s2.hash.length) : "";
}
function ot2(t2, e) {
  if (t2 = K2(t2, "?"), e || t2 === "")
    return t2;
  let s2 = new URL("https://example.com");
  return s2.search = t2, s2.search ? s2.search.substring(1, s2.search.length) : "";
}
function ut2(t2, e) {
  return e || t2 === "" ? t2 : G2(t2) ? q2(t2) : Z2(t2);
}
function pt2(t2, e) {
  if (e || t2 === "")
    return t2;
  let s2 = new URL("https://example.com");
  return s2.password = t2, s2.password;
}
function ct2(t2, e) {
  if (e || t2 === "")
    return t2;
  let s2 = new URL("https://example.com");
  return s2.username = t2, s2.username;
}
function ft2(t2, e, s2) {
  if (s2 || t2 === "")
    return t2;
  if (e && !X2.includes(e))
    return new URL(`${e}:${t2}`).pathname;
  let i2 = t2[0] == "/";
  return t2 = new URL(i2 ? t2 : "/-" + t2, "https://example.com").pathname, i2 || (t2 = t2.substring(2, t2.length)), t2;
}
function lt2(t2, e, s2) {
  return z2(e) === t2 && (t2 = ""), s2 || t2 === "" ? t2 : B2(t2);
}
function mt2(t2, e) {
  return t2 = ht2(t2, ":"), e || t2 === "" ? t2 : N2(t2);
}
function z2(t2) {
  switch (t2) {
    case "ws":
    case "http":
      return "80";
    case "wws":
    case "https":
      return "443";
    case "ftp":
      return "21";
    default:
      return "";
  }
}
function N2(t2) {
  if (t2 === "")
    return t2;
  if (/^[-+.A-Za-z0-9]*$/.test(t2))
    return t2.toLowerCase();
  throw new TypeError(`Invalid protocol '${t2}'.`);
}
function gt2(t2) {
  if (t2 === "")
    return t2;
  let e = new URL("https://example.com");
  return e.username = t2, e.username;
}
function dt2(t2) {
  if (t2 === "")
    return t2;
  let e = new URL("https://example.com");
  return e.password = t2, e.password;
}
function Z2(t2) {
  if (t2 === "")
    return t2;
  if (/[\t\n\r #%/:<>?@[\]^\\|]/g.test(t2))
    throw new TypeError(`Invalid hostname '${t2}'`);
  let e = new URL("https://example.com");
  return e.hostname = t2, e.hostname;
}
function q2(t2) {
  if (t2 === "")
    return t2;
  if (/[^0-9a-fA-F[\]:]/g.test(t2))
    throw new TypeError(`Invalid IPv6 hostname '${t2}'`);
  return t2.toLowerCase();
}
function B2(t2) {
  if (t2 === "" || /^[0-9]*$/.test(t2) && parseInt(t2) <= 65535)
    return t2;
  throw new TypeError(`Invalid port '${t2}'.`);
}
function wt2(t2) {
  if (t2 === "")
    return t2;
  let e = new URL("https://example.com");
  return e.pathname = t2[0] !== "/" ? "/-" + t2 : t2, t2[0] !== "/" ? e.pathname.substring(2, e.pathname.length) : e.pathname;
}
function yt2(t2) {
  return t2 === "" ? t2 : new URL(`data:${t2}`).pathname;
}
function bt2(t2) {
  if (t2 === "")
    return t2;
  let e = new URL("https://example.com");
  return e.search = t2, e.search.substring(1, e.search.length);
}
function xt2(t2) {
  if (t2 === "")
    return t2;
  let e = new URL("https://example.com");
  return e.hash = t2, e.hash.substring(1, e.hash.length);
}
function H2(t2, e) {
  if (typeof t2 != "string")
    throw new TypeError("parameter 1 is not of type 'string'.");
  let s2 = new URL(t2, e);
  return { protocol: s2.protocol.substring(0, s2.protocol.length - 1), username: s2.username, password: s2.password, hostname: s2.hostname, port: s2.port, pathname: s2.pathname, search: s2.search !== "" ? s2.search.substring(1, s2.search.length) : void 0, hash: s2.hash !== "" ? s2.hash.substring(1, s2.hash.length) : void 0 };
}
function y3(t2, e) {
  return e ? A2(t2) : t2;
}
function L2(t2, e, s2) {
  let i2;
  if (typeof e.baseURL == "string")
    try {
      i2 = new URL(e.baseURL), t2.protocol = y3(i2.protocol.substring(0, i2.protocol.length - 1), s2), t2.username = y3(i2.username, s2), t2.password = y3(i2.password, s2), t2.hostname = y3(i2.hostname, s2), t2.port = y3(i2.port, s2), t2.pathname = y3(i2.pathname, s2), t2.search = y3(i2.search.substring(1, i2.search.length), s2), t2.hash = y3(i2.hash.substring(1, i2.hash.length), s2);
    } catch {
      throw new TypeError(`invalid baseURL '${e.baseURL}'.`);
    }
  if (typeof e.protocol == "string" && (t2.protocol = mt2(e.protocol, s2)), typeof e.username == "string" && (t2.username = ct2(e.username, s2)), typeof e.password == "string" && (t2.password = pt2(e.password, s2)), typeof e.hostname == "string" && (t2.hostname = ut2(e.hostname, s2)), typeof e.port == "string" && (t2.port = lt2(e.port, t2.protocol, s2)), typeof e.pathname == "string") {
    if (t2.pathname = e.pathname, i2 && !nt2(t2.pathname, s2)) {
      let o = i2.pathname.lastIndexOf("/");
      o >= 0 && (t2.pathname = y3(i2.pathname.substring(0, o + 1), s2) + t2.pathname);
    }
    t2.pathname = ft2(t2.pathname, t2.protocol, s2);
  }
  return typeof e.search == "string" && (t2.search = ot2(e.search, s2)), typeof e.hash == "string" && (t2.hash = at2(e.hash, s2)), t2;
}
function A2(t2) {
  return t2.replace(/([+*?:{}()\\])/g, "\\$1");
}
function Et(t2) {
  return t2.replace(/([.+*?^${}()[\]|/\\])/g, "\\$1");
}
function Rt(t2, e) {
  e.delimiter ??= "/#?", e.prefixes ??= "./", e.sensitive ??= false, e.strict ??= false, e.end ??= true, e.start ??= true, e.endsWith = "";
  let s2 = ".*", i2 = `[^${Et(e.delimiter)}]+?`, o = /[$_\u200C\u200D\p{ID_Continue}]/u, u4 = "";
  for (let h3 = 0; h3 < t2.length; ++h3) {
    let r = t2[h3];
    if (r.type === 3) {
      if (r.modifier === 3) {
        u4 += A2(r.value);
        continue;
      }
      u4 += `{${A2(r.value)}}${k3(r.modifier)}`;
      continue;
    }
    let a3 = r.hasCustomName(), n2 = !!r.suffix.length || !!r.prefix.length && (r.prefix.length !== 1 || !e.prefixes.includes(r.prefix)), f2 = h3 > 0 ? t2[h3 - 1] : null, w2 = h3 < t2.length - 1 ? t2[h3 + 1] : null;
    if (!n2 && a3 && r.type === 1 && r.modifier === 3 && w2 && !w2.prefix.length && !w2.suffix.length)
      if (w2.type === 3) {
        let R3 = w2.value.length > 0 ? w2.value[0] : "";
        n2 = o.test(R3);
      } else
        n2 = !w2.hasCustomName();
    if (!n2 && !r.prefix.length && f2 && f2.type === 3) {
      let R3 = f2.value[f2.value.length - 1];
      n2 = e.prefixes.includes(R3);
    }
    n2 && (u4 += "{"), u4 += A2(r.prefix), a3 && (u4 += `:${r.name}`), r.type === 2 ? u4 += `(${r.value})` : r.type === 1 ? a3 || (u4 += `(${i2})`) : r.type === 0 && (!a3 && (!f2 || f2.type === 3 || f2.modifier !== 3 || n2 || r.prefix !== "") ? u4 += "*" : u4 += `(${s2})`), r.type === 1 && a3 && r.suffix.length && o.test(r.suffix[0]) && (u4 += "\\"), u4 += A2(r.suffix), n2 && (u4 += "}"), r.modifier !== 3 && (u4 += k3(r.modifier));
  }
  return u4;
}
var P3, Y2, tt2, D3, E4, rt2, it2, X2, $t, S2, $2, J2;
var init_urlpattern_polyfill = __esm({
  "https://esm.sh/v131/urlpattern-polyfill@9.0.0/denonext/urlpattern-polyfill.mjs"() {
    P3 = class {
      type = 3;
      name = "";
      prefix = "";
      value = "";
      suffix = "";
      modifier = 3;
      constructor(t2, e, s2, i2, o, u4) {
        this.type = t2, this.name = e, this.prefix = s2, this.value = i2, this.suffix = o, this.modifier = u4;
      }
      hasCustomName() {
        return this.name !== "" && typeof this.name != "number";
      }
    };
    Y2 = /[$_\p{ID_Start}]/u;
    tt2 = /[$_\u200C\u200D\p{ID_Continue}]/u;
    D3 = ".*";
    E4 = { delimiter: "", prefixes: "", sensitive: true, strict: true };
    rt2 = { delimiter: ".", prefixes: "", sensitive: true, strict: true };
    it2 = { delimiter: "/", prefixes: "/", sensitive: true, strict: true };
    X2 = ["ftp", "file", "http", "https", "ws", "wss"];
    $t = class {
      #n;
      #r = [];
      #e = {};
      #t = 0;
      #i = 1;
      #f = 0;
      #o = 0;
      #l = 0;
      #m = 0;
      #g = false;
      constructor(t2) {
        this.#n = t2;
      }
      get result() {
        return this.#e;
      }
      parse() {
        for (this.#r = M2(this.#n, true); this.#t < this.#r.length; this.#t += this.#i) {
          if (this.#i = 1, this.#r[this.#t].type === "END") {
            if (this.#o === 0) {
              this.#b(), this.#u() ? this.#s(9, 1) : this.#p() ? (this.#s(8, 1), this.#e.hash = "") : (this.#s(7, 0), this.#e.search = "", this.#e.hash = "");
              continue;
            } else if (this.#o === 2) {
              this.#c(5);
              continue;
            }
            this.#s(10, 0);
            break;
          }
          if (this.#l > 0)
            if (this.#C())
              this.#l -= 1;
            else
              continue;
          if (this.#k()) {
            this.#l += 1;
            continue;
          }
          switch (this.#o) {
            case 0:
              this.#x() && (this.#e.username = "", this.#e.password = "", this.#e.hostname = "", this.#e.port = "", this.#e.pathname = "", this.#e.search = "", this.#e.hash = "", this.#c(1));
              break;
            case 1:
              if (this.#x()) {
                this.#P();
                let t2 = 7, e = 1;
                this.#g && (this.#e.pathname = "/"), this.#E() ? (t2 = 2, e = 3) : this.#g && (t2 = 2), this.#s(t2, e);
              }
              break;
            case 2:
              this.#w() ? this.#c(3) : (this.#y() || this.#p() || this.#u()) && this.#c(5);
              break;
            case 3:
              this.#R() ? this.#s(4, 1) : this.#w() && this.#s(5, 1);
              break;
            case 4:
              this.#w() && this.#s(5, 1);
              break;
            case 5:
              this.#L() ? this.#m += 1 : this.#A() && (this.#m -= 1), this.#v() && !this.#m ? this.#s(6, 1) : this.#y() ? this.#s(7, 0) : this.#p() ? this.#s(8, 1) : this.#u() && this.#s(9, 1);
              break;
            case 6:
              this.#y() ? this.#s(7, 0) : this.#p() ? this.#s(8, 1) : this.#u() && this.#s(9, 1);
              break;
            case 7:
              this.#p() ? this.#s(8, 1) : this.#u() && this.#s(9, 1);
              break;
            case 8:
              this.#u() && this.#s(9, 1);
              break;
            case 9:
              break;
            case 10:
              break;
          }
        }
      }
      #s(t2, e) {
        switch (this.#o) {
          case 0:
            break;
          case 1:
            this.#e.protocol = this.#a();
            break;
          case 2:
            break;
          case 3:
            this.#e.username = this.#a();
            break;
          case 4:
            this.#e.password = this.#a();
            break;
          case 5:
            this.#e.hostname = this.#a();
            break;
          case 6:
            this.#e.port = this.#a();
            break;
          case 7:
            this.#e.pathname = this.#a();
            break;
          case 8:
            this.#e.search = this.#a();
            break;
          case 9:
            this.#e.hash = this.#a();
            break;
          case 10:
            break;
        }
        this.#$(t2, e);
      }
      #$(t2, e) {
        this.#o = t2, this.#f = this.#t + e, this.#t += e, this.#i = 0;
      }
      #b() {
        this.#t = this.#f, this.#i = 0;
      }
      #c(t2) {
        this.#b(), this.#o = t2;
      }
      #d(t2) {
        return t2 < 0 && (t2 = this.#r.length - t2), t2 < this.#r.length ? this.#r[t2] : this.#r[this.#r.length - 1];
      }
      #h(t2, e) {
        let s2 = this.#d(t2);
        return s2.value === e && (s2.type === "CHAR" || s2.type === "ESCAPED_CHAR" || s2.type === "INVALID_CHAR");
      }
      #x() {
        return this.#h(this.#t, ":");
      }
      #E() {
        return this.#h(this.#t + 1, "/") && this.#h(this.#t + 2, "/");
      }
      #w() {
        return this.#h(this.#t, "@");
      }
      #R() {
        return this.#h(this.#t, ":");
      }
      #v() {
        return this.#h(this.#t, ":");
      }
      #y() {
        return this.#h(this.#t, "/");
      }
      #p() {
        if (this.#h(this.#t, "?"))
          return true;
        if (this.#r[this.#t].value !== "?")
          return false;
        let t2 = this.#d(this.#t - 1);
        return t2.type !== "NAME" && t2.type !== "REGEX" && t2.type !== "CLOSE" && t2.type !== "ASTERISK";
      }
      #u() {
        return this.#h(this.#t, "#");
      }
      #k() {
        return this.#r[this.#t].type == "OPEN";
      }
      #C() {
        return this.#r[this.#t].type == "CLOSE";
      }
      #L() {
        return this.#h(this.#t, "[");
      }
      #A() {
        return this.#h(this.#t, "]");
      }
      #a() {
        let t2 = this.#r[this.#t], e = this.#d(this.#f).index;
        return this.#n.substring(e, t2.index);
      }
      #P() {
        let t2 = {};
        Object.assign(t2, E4), t2.encodePart = N2;
        let e = st2(this.#a(), void 0, t2);
        this.#g = V2(e);
      }
    };
    S2 = ["protocol", "username", "password", "hostname", "port", "pathname", "search", "hash"];
    $2 = "*";
    J2 = class {
      #n;
      #r = {};
      #e = {};
      #t = {};
      #i = {};
      constructor(t2 = {}, e, s2) {
        try {
          let i2;
          if (typeof e == "string" ? i2 = e : s2 = e, typeof t2 == "string") {
            let r = new $t(t2);
            if (r.parse(), t2 = r.result, i2 === void 0 && typeof t2.protocol != "string")
              throw new TypeError("A base URL must be provided for a relative constructor string.");
            t2.baseURL = i2;
          } else {
            if (!t2 || typeof t2 != "object")
              throw new TypeError("parameter 1 is not of type 'string' and cannot convert to dictionary.");
            if (i2)
              throw new TypeError("parameter 1 is not of type 'string'.");
          }
          typeof s2 > "u" && (s2 = { ignoreCase: false });
          let o = { ignoreCase: s2.ignoreCase === true }, u4 = { pathname: $2, protocol: $2, username: $2, password: $2, hostname: $2, port: $2, search: $2, hash: $2 };
          this.#n = L2(u4, t2, true), z2(this.#n.protocol) === this.#n.port && (this.#n.port = "");
          let h3;
          for (h3 of S2) {
            if (!(h3 in this.#n))
              continue;
            let r = {}, a3 = this.#n[h3];
            switch (this.#e[h3] = [], h3) {
              case "protocol":
                Object.assign(r, E4), r.encodePart = N2;
                break;
              case "username":
                Object.assign(r, E4), r.encodePart = gt2;
                break;
              case "password":
                Object.assign(r, E4), r.encodePart = dt2;
                break;
              case "hostname":
                Object.assign(r, rt2), G2(a3) ? r.encodePart = q2 : r.encodePart = Z2;
                break;
              case "port":
                Object.assign(r, E4), r.encodePart = B2;
                break;
              case "pathname":
                V2(this.#r.protocol) ? (Object.assign(r, it2, o), r.encodePart = wt2) : (Object.assign(r, E4, o), r.encodePart = yt2);
                break;
              case "search":
                Object.assign(r, E4, o), r.encodePart = bt2;
                break;
              case "hash":
                Object.assign(r, E4, o), r.encodePart = xt2;
                break;
            }
            try {
              this.#i[h3] = F(a3, r), this.#r[h3] = W3(this.#i[h3], this.#e[h3], r), this.#t[h3] = Rt(this.#i[h3], r);
            } catch {
              throw new TypeError(`invalid ${h3} pattern '${this.#n[h3]}'.`);
            }
          }
        } catch (i2) {
          throw new TypeError(`Failed to construct 'URLPattern': ${i2.message}`);
        }
      }
      test(t2 = {}, e) {
        let s2 = { pathname: "", protocol: "", username: "", password: "", hostname: "", port: "", search: "", hash: "" };
        if (typeof t2 != "string" && e)
          throw new TypeError("parameter 1 is not of type 'string'.");
        if (typeof t2 > "u")
          return false;
        try {
          typeof t2 == "object" ? s2 = L2(s2, t2, false) : s2 = L2(s2, H2(t2, e), false);
        } catch {
          return false;
        }
        let i2;
        for (i2 of S2)
          if (!this.#r[i2].exec(s2[i2]))
            return false;
        return true;
      }
      exec(t2 = {}, e) {
        let s2 = { pathname: "", protocol: "", username: "", password: "", hostname: "", port: "", search: "", hash: "" };
        if (typeof t2 != "string" && e)
          throw new TypeError("parameter 1 is not of type 'string'.");
        if (typeof t2 > "u")
          return;
        try {
          typeof t2 == "object" ? s2 = L2(s2, t2, false) : s2 = L2(s2, H2(t2, e), false);
        } catch {
          return null;
        }
        let i2 = {};
        e ? i2.inputs = [t2, e] : i2.inputs = [t2];
        let o;
        for (o of S2) {
          let u4 = this.#r[o].exec(s2[o]);
          if (!u4)
            return null;
          let h3 = {};
          for (let [r, a3] of this.#e[o].entries())
            if (typeof a3 == "string" || typeof a3 == "number") {
              let n2 = u4[r + 1];
              h3[a3] = n2;
            }
          i2[o] = { input: s2[o] ?? "", groups: h3 };
        }
        return i2;
      }
      static compareComponent(t2, e, s2) {
        let i2 = (r, a3) => {
          for (let n2 of ["type", "modifier", "prefix", "value", "suffix"]) {
            if (r[n2] < a3[n2])
              return -1;
            if (r[n2] !== a3[n2])
              return 1;
          }
          return 0;
        }, o = new P3(3, "", "", "", "", 3), u4 = new P3(0, "", "", "", "", 3), h3 = (r, a3) => {
          let n2 = 0;
          for (; n2 < Math.min(r.length, a3.length); ++n2) {
            let f2 = i2(r[n2], a3[n2]);
            if (f2)
              return f2;
          }
          return r.length === a3.length ? 0 : i2(r[n2] ?? o, a3[n2] ?? o);
        };
        return !e.#t[t2] && !s2.#t[t2] ? 0 : e.#t[t2] && !s2.#t[t2] ? h3(e.#i[t2], [u4]) : !e.#t[t2] && s2.#t[t2] ? h3([u4], s2.#i[t2]) : h3(e.#i[t2], s2.#i[t2]);
      }
      get protocol() {
        return this.#t.protocol;
      }
      get username() {
        return this.#t.username;
      }
      get password() {
        return this.#t.password;
      }
      get hostname() {
        return this.#t.hostname;
      }
      get port() {
        return this.#t.port;
      }
      get pathname() {
        return this.#t.pathname;
      }
      get search() {
        return this.#t.search;
      }
      get hash() {
        return this.#t.hash;
      }
    };
    globalThis.URLPattern || (globalThis.URLPattern = J2);
  }
});

// https://esm.sh/urlpattern-polyfill
var urlpattern_polyfill_exports = {};
__export(urlpattern_polyfill_exports, {
  URLPattern: () => J2
});
var init_urlpattern_polyfill2 = __esm({
  "https://esm.sh/urlpattern-polyfill"() {
    init_urlpattern_polyfill();
  }
});

// ../desktop-dev/src/core/helper/crypto.shims.ts
if (typeof crypto.randomUUID !== "function") {
  crypto.randomUUID = function randomUUID() {
    return "10000000-1000-4000-8000-100000000000".replace(/[018]/g, (_c) => {
      const c3 = +_c;
      return (c3 ^ crypto.getRandomValues(new Uint8Array(1))[0] & 15 >> c3 / 4).toString(16);
    });
  };
}

// https://esm.sh/v128/is-mobile@4.0.0/denonext/is-mobile.mjs
var c = Object.create;
var l = Object.defineProperty;
var g = Object.getOwnPropertyDescriptor;
var x = Object.getOwnPropertyNames;
var h = Object.getPrototypeOf;
var k = Object.prototype.hasOwnProperty;
var v = (i2, e) => () => (e || i2((e = { exports: {} }).exports, e), e.exports);
var y = (i2, e) => {
  for (var o in e)
    l(i2, o, { get: e[o], enumerable: true });
};
var s = (i2, e, o, p3) => {
  if (e && typeof e == "object" || typeof e == "function")
    for (let r of x(e))
      !k.call(i2, r) && r !== o && l(i2, r, { get: () => e[r], enumerable: !(p3 = g(e, r)) || p3.enumerable });
  return i2;
};
var a = (i2, e, o) => (s(i2, e, "default"), o && s(o, e, "default"));
var b = (i2, e, o) => (o = i2 != null ? c(h(i2)) : {}, s(e || !i2 || !i2.__esModule ? l(o, "default", { value: i2, enumerable: true }) : o, i2));
var f = v((z3, n2) => {
  "use strict";
  n2.exports = d3;
  n2.exports.isMobile = d3;
  n2.exports.default = d3;
  var _ = /(android|bb\d+|meego).+mobile|armv7l|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|mobile.+firefox|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series[46]0|samsungbrowser.*mobile|symbian|treo|up\.(browser|link)|vodafone|wap|windows (ce|phone)|xda|xiino/i, w2 = /CrOS/, M3 = /android|ipad|playbook|silk/i;
  function d3(i2) {
    i2 || (i2 = {});
    let e = i2.ua;
    if (!e && typeof navigator < "u" && (e = navigator.userAgent), e && e.headers && typeof e.headers["user-agent"] == "string" && (e = e.headers["user-agent"]), typeof e != "string")
      return false;
    let o = _.test(e) && !w2.test(e) || !!i2.tablet && M3.test(e);
    return !o && i2.tablet && i2.featureDetect && navigator && navigator.maxTouchPoints > 1 && e.indexOf("Macintosh") !== -1 && e.indexOf("Safari") !== -1 && (o = true), o;
  }
});
var t = {};
y(t, { default: () => R, isMobile: () => E });
var m = b(f());
a(t, b(f()));
var { isMobile: E } = m;
var { default: u, ...O } = m;
var R = u !== void 0 ? u : O;

// ../desktop-dev/src/helper/$queue.ts
var queue = (fun) => {
  let queuer = Promise.resolve();
  return function(...args) {
    return queuer = queuer.finally(() => fun(...args));
  };
};

// ../desktop-dev/src/helper/PromiseOut.ts
var isPromiseLike = (value) => {
  return value instanceof Object && typeof value.then === "function";
};
var PromiseOut = class {
  constructor() {
    this.is_resolved = false;
    this.is_rejected = false;
    this.is_finished = false;
    this.promise = new Promise((resolve, reject) => {
      this.resolve = (value) => {
        try {
          if (isPromiseLike(value)) {
            value.then(this.resolve, this.reject);
          } else {
            this.is_resolved = true;
            this.is_finished = true;
            resolve(this.value = value);
            this._runThen();
            this._innerFinallyArg = Object.freeze({
              status: "resolved",
              result: this.value
            });
            this._runFinally();
          }
        } catch (err) {
          this.reject(err);
        }
      };
      this.reject = (reason) => {
        this.is_rejected = true;
        this.is_finished = true;
        reject(this.reason = reason);
        this._runCatch();
        this._innerFinallyArg = Object.freeze({
          status: "rejected",
          reason: this.reason
        });
        this._runFinally();
      };
    });
  }
  static resolve(v3) {
    const po = new PromiseOut();
    po.resolve(v3);
    return po;
  }
  static reject(reason) {
    const po = new PromiseOut();
    po.reject(reason);
    return po;
  }
  static sleep(ms) {
    const po = new PromiseOut();
    let ti = setTimeout(() => {
      ti = void 0;
      po.resolve();
    }, ms);
    po.onFinished(() => ti !== void 0 && clearTimeout(ti));
    return po;
  }
  onSuccess(innerThen) {
    if (this.is_resolved) {
      this.__callInnerThen(innerThen);
    } else {
      (this._innerThen || (this._innerThen = [])).push(innerThen);
    }
  }
  onError(innerCatch) {
    if (this.is_rejected) {
      this.__callInnerCatch(innerCatch);
    } else {
      (this._innerCatch || (this._innerCatch = [])).push(innerCatch);
    }
  }
  onFinished(innerFinally) {
    if (this.is_finished) {
      this.__callInnerFinally(innerFinally);
    } else {
      (this._innerFinally || (this._innerFinally = [])).push(innerFinally);
    }
  }
  _runFinally() {
    if (this._innerFinally) {
      for (const innerFinally of this._innerFinally) {
        this.__callInnerFinally(innerFinally);
      }
      this._innerFinally = void 0;
    }
  }
  __callInnerFinally(innerFinally) {
    queueMicrotask(async () => {
      try {
        await innerFinally(this._innerFinallyArg);
      } catch (err) {
        console.error("Unhandled promise rejection when running onFinished", innerFinally, err);
      }
    });
  }
  _runThen() {
    if (this._innerThen) {
      for (const innerThen of this._innerThen) {
        this.__callInnerThen(innerThen);
      }
      this._innerThen = void 0;
    }
  }
  _runCatch() {
    if (this._innerCatch) {
      for (const innerCatch of this._innerCatch) {
        this.__callInnerCatch(innerCatch);
      }
      this._innerCatch = void 0;
    }
  }
  __callInnerThen(innerThen) {
    queueMicrotask(async () => {
      try {
        await innerThen(this.value);
      } catch (err) {
        console.error("Unhandled promise rejection when running onSuccess", innerThen, err);
      }
    });
  }
  __callInnerCatch(innerCatch) {
    queueMicrotask(async () => {
      try {
        await innerCatch(this.value);
      } catch (err) {
        console.error("Unhandled promise rejection when running onError", innerCatch, err);
      }
    });
  }
};

// ../desktop-dev/src/helper/binaryHelper.ts
var isBinary = (data) => data instanceof ArrayBuffer || ArrayBuffer.isView(data) || typeof SharedArrayBuffer === "function" && data instanceof SharedArrayBuffer;
var binaryToU8a = (binary) => {
  if (binary instanceof Uint8Array) {
    return binary;
  }
  if (ArrayBuffer.isView(binary)) {
    return new Uint8Array(binary.buffer, binary.byteOffset, binary.byteLength);
  }
  return new Uint8Array(binary);
};
var u8aConcat = (binaryList) => {
  let totalLength = 0;
  for (const binary of binaryList) {
    totalLength += binary.byteLength;
  }
  const result = new Uint8Array(totalLength);
  let offset = 0;
  for (const binary of binaryList) {
    result.set(binary, offset);
    offset += binary.byteLength;
  }
  return result;
};

// ../desktop-dev/src/helper/createSignal.ts
var createSignal = (autoStart) => {
  return new Signal(autoStart);
};
var Signal = class {
  constructor(autoStart = true) {
    this._cbs = /* @__PURE__ */ new Set();
    this._started = false;
    this._cachedEmits = [];
    this.start = () => {
      if (this._started) {
        return;
      }
      this._started = true;
      if (this._cachedEmits.length) {
        for (const args of this._cachedEmits) {
          this._emit(args, this._cbs);
        }
        this._cachedEmits.length = 0;
      }
    };
    this.listen = (cb) => {
      this._cbs.add(cb);
      this.start();
      return () => this._cbs.delete(cb);
    };
    this.emit = (...args) => {
      if (this._started) {
        this._emit(args, this._cbs);
      } else {
        this._cachedEmits.push(args);
      }
    };
    this.emitAndClear = (...args) => {
      if (this._started) {
        const cbs = [...this._cbs];
        this._cbs.clear();
        this._emit(args, cbs);
      } else {
        this._cachedEmits.push(args);
      }
    };
    this._emit = (args, cbs) => {
      for (const cb of cbs) {
        try {
          cb.apply(null, args);
        } catch (reason) {
          console.warn(reason);
        }
      }
    };
    this.clear = () => {
      this._cbs.clear();
    };
    if (autoStart) {
      this.start();
    }
  }
};

// ../desktop-dev/src/helper/encoding.ts
var textEncoder = new TextEncoder();
var simpleEncoder = (data, encoding) => {
  if (encoding === "base64") {
    const byteCharacters = atob(data);
    const binary = new Uint8Array(byteCharacters.length);
    for (let i2 = 0; i2 < byteCharacters.length; i2++) {
      binary[i2] = byteCharacters.charCodeAt(i2);
    }
    return binary;
  } else if (encoding === "hex") {
    const binary = new Uint8Array(data.length / 2);
    for (let i2 = 0; i2 < binary.length; i2++) {
      const start = i2 + i2;
      binary[i2] = parseInt(data.slice(start, start + 2), 16);
    }
    return binary;
  }
  return textEncoder.encode(data);
};
var textDecoder = new TextDecoder();
var simpleDecoder = (data, encoding) => {
  if (encoding === "base64") {
    let binary = "";
    const bytes = binaryToU8a(data);
    for (const byte of bytes) {
      binary += String.fromCharCode(byte);
    }
    return btoa(binary);
  } else if (encoding === "hex") {
    let hex = "";
    const bytes = binaryToU8a(data);
    for (const byte of bytes) {
      hex += byte.toString(16).padStart(2, "0");
    }
    return hex;
  }
  return textDecoder.decode(data);
};

// ../desktop-dev/src/helper/mapHelper.ts
var mapHelper = new class {
  getOrPut(map, key, putter) {
    if (map.has(key)) {
      return map.get(key);
    }
    const put = putter(key);
    map.set(key, put);
    return put;
  }
  getAndRemove(map, key) {
    const val = map.get(key);
    if (map.delete(key)) {
      return val;
    }
  }
}();

// ../desktop-dev/src/helper/stream/readableStreamHelper.ts
async function* _doRead(reader, options) {
  const signal = options?.signal;
  if (signal !== void 0) {
    signal.addEventListener("abort", (reason) => reader.cancel(reason));
  }
  try {
    while (true) {
      const item = await reader.read();
      if (item.done) {
        break;
      }
      yield item.value;
    }
  } catch (err) {
    reader.cancel(err);
  } finally {
    reader.releaseLock();
  }
}
var streamRead = (stream, options) => {
  return _doRead(stream.getReader(), options);
};
var binaryStreamRead = (stream, options) => {
  const reader = streamRead(stream, options);
  let done = false;
  let cache = new Uint8Array(0);
  const appendToCache = async () => {
    const item = await reader.next();
    if (item.done) {
      done = true;
      return false;
    } else {
      cache = u8aConcat([cache, item.value]);
      return true;
    }
  };
  const available = async () => {
    if (cache.length > 0) {
      return cache.length;
    }
    if (done) {
      return -1;
    }
    await appendToCache();
    return available();
  };
  const readBinary = async (size) => {
    if (cache.length >= size) {
      const result = cache.subarray(0, size);
      cache = cache.subarray(size);
      return result;
    }
    if (await appendToCache()) {
      return readBinary(size);
    } else {
      throw new Error(`fail to read bytes(${cache.length}/${size} byte) in stream`);
    }
  };
  const u32 = new Uint32Array(1);
  const u32_u8 = new Uint8Array(u32.buffer);
  const readInt = async () => {
    const intBuf = await readBinary(4);
    u32_u8.set(intBuf);
    return u32[0];
  };
  return Object.assign(reader, {
    available,
    readBinary,
    readInt
  });
};
var streamReadAll = async (stream, options = {}) => {
  const maps = [];
  for await (const item of _doRead(stream.getReader())) {
    if (options.map) {
      maps.push(options.map(item));
    }
  }
  const result = options.complete?.(maps);
  return {
    maps,
    result
  };
};
var streamReadAllBuffer = async (stream) => {
  return (await streamReadAll(stream, {
    map(chunk) {
      return chunk;
    },
    complete(chunks) {
      return u8aConcat(chunks);
    }
  })).result;
};
var ReadableStreamOut = class {
  constructor(strategy) {
    this.strategy = strategy;
    this.stream = new ReadableStream(
      {
        cancel: (reason) => {
          this._on_cancel_signal?.emit(reason);
        },
        start: (controller) => {
          this.controller = controller;
        },
        pull: () => {
          this._on_pull_signal?.emit();
        }
      },
      this.strategy
    );
  }
  get onCancel() {
    return (this._on_cancel_signal ??= createSignal()).listen;
  }
  get onPull() {
    return (this._on_pull_signal ??= createSignal()).listen;
  }
};

// src/server/deps.ts
var { jsProcess, http, ipc, core } = navigator.dweb;
var { ServerUrlInfo, ServerStartResult } = http;
var {
  //
  IpcHeaders,
  IpcResponse,
  Ipc,
  IpcRequest,
  IpcEvent,
  IPC_METHOD,
  ReadableStreamIpc,
  ReadableStreamOut: ReadableStreamOut2,
  IpcBodySender
} = ipc;
var { FetchError, IPC_ROLE } = core;

// src/server/http-helper.ts
var { IpcHeaders: IpcHeaders2 } = navigator.dweb.ipc;
var cors = (headers) => {
  headers.init("Access-Control-Allow-Origin", "*");
  headers.init("Access-Control-Allow-Headers", "*");
  headers.init("Access-Control-Allow-Methods", "*");
  return headers;
};
var HttpServer = class {
  constructor() {
    this._serverP = http.createHttpDwebServer(jsProcess, this._getOptions());
    this._listener = this.getServer().then((server) => server.listen());
  }
  getServer() {
    return this._serverP;
  }
  getStartResult() {
    return this._serverP.then((server) => server.startResult);
  }
  async stop() {
    const server = await this._serverP;
    return await server.close();
  }
};

// https://esm.sh/v126/deep-object-diff@1.1.9/denonext/deep-object-diff.mjs
var u2 = (t2) => t2 instanceof Date;
var m2 = (t2) => Object.keys(t2).length === 0;
var i = (t2) => t2 != null && typeof t2 == "object";
var n = (t2, ...e) => Object.prototype.hasOwnProperty.call(t2, ...e);
var d = (t2) => i(t2) && m2(t2);
var p = () => /* @__PURE__ */ Object.create(null);
var D = (t2, e) => t2 === e || !i(t2) || !i(e) ? {} : Object.keys(e).reduce((o, r) => {
  if (n(t2, r)) {
    let f2 = D(t2[r], e[r]);
    return i(f2) && m2(f2) || (o[r] = f2), o;
  }
  return o[r] = e[r], o;
}, p());
var a2 = D;
var x2 = (t2, e) => t2 === e || !i(t2) || !i(e) ? {} : Object.keys(t2).reduce((o, r) => {
  if (n(e, r)) {
    let f2 = x2(t2[r], e[r]);
    return i(f2) && m2(f2) || (o[r] = f2), o;
  }
  return o[r] = void 0, o;
}, p());
var b2 = x2;
var P = (t2, e) => t2 === e ? {} : !i(t2) || !i(e) ? e : u2(t2) || u2(e) ? t2.valueOf() == e.valueOf() ? {} : e : Object.keys(e).reduce((o, r) => {
  if (n(t2, r)) {
    let f2 = P(t2[r], e[r]);
    return d(f2) && !u2(f2) && (d(t2[r]) || !d(e[r])) || (o[r] = f2), o;
  }
  return o;
}, p());
var j = P;
var E2 = (t2, e) => ({ added: a2(t2, e), deleted: b2(t2, e), updated: j(t2, e) });
var W = E2;

// src/server/mwebview-helper.ts
var mwebview_open = async (url) => {
  const state = await jsProcess.nativeFetch(`file://mwebview.browser.dweb/open?url=${encodeURIComponent(url)}`).object();
  all_webview_status.diffState(state);
  return state;
};
var mwebview_activate = async () => {
  return await jsProcess.nativeFetch(`file://mwebview.browser.dweb/activate`).text();
};
var mwebview_destroy = async () => {
  return await jsProcess.nativeFetch(`file://mwebview.browser.dweb/close/app`).boolean();
};
var all_webview_status = new class extends Map {
  constructor() {
    super(...arguments);
    this.signal = createSignal();
    this.oldWebviewState = {};
  }
  last() {
    return [...this.entries()].at(-1);
  }
  /**
   * 对比状态的更新
   * @param diff
   */
  diffFactory(diff) {
    for (const id in diff.added) {
      this.set(id, diff.added[id]);
    }
    for (const id in diff.deleted) {
      this.delete(id);
    }
    for (const id in diff.updated) {
      this.set(id, diff.updated[id]);
    }
    this.signal.emit(this.size);
  }
  diffState(newState) {
    const diff = W(this.oldWebviewState, newState.views);
    this.oldWebviewState = newState.views;
    this.diffFactory(diff);
  }
}();
var _false = true;
var sync_mwebview_status = async () => {
  if (_false === false) {
    return;
  }
  _false = false;
  const ipc2 = await navigator.dweb.jsProcess.connect("mwebview.browser.dweb");
  ipc2.onEvent((ipcEvent) => {
    if (ipcEvent.name === "state") {
      const newState = JSON.parse(ipcEvent.text);
      all_webview_status.diffState(newState);
    }
  });
};

// src/server/http-api-server.ts
var DNS_PREFIX = "/dns.std.dweb/";
var INTERNAL_PREFIX = "/internal/";
var Server_api = class extends HttpServer {
  constructor(widPo) {
    super();
    this.widPo = widPo;
  }
  _getOptions() {
    return {
      subdomain: "api",
      port: 443
    };
  }
  async start() {
    const serverIpc = await this._listener;
    return serverIpc.onFetch(this._provider.bind(this)).internalServerError().cors();
  }
  async _provider(event) {
    if (event.pathname.startsWith(DNS_PREFIX)) {
      return this._onDns(event);
    } else if (event.pathname.startsWith(INTERNAL_PREFIX)) {
      return this._onInternal(event);
    }
    return this._onApi(event);
  }
  async _onDns(event) {
    const url = new URL("file:/" + event.pathname + event.search);
    const pathname = url.pathname;
    const result = async () => {
      if (pathname === "/restart") {
        setTimeout(() => {
          jsProcess.restart();
        }, 200);
        return Response.json({ success: true, message: "restart ok" });
      }
      if (pathname === "/close") {
        const bool = await mwebview_destroy();
        return Response.json({ success: bool, message: "window close" });
      }
      if (pathname === "/query") {
        const mmid = event.searchParams.get("mmid");
        const res = await jsProcess.nativeFetch(`file://dns.std.dweb/query?app_id=${mmid}`);
        return res;
      }
      return Response.json({ success: false, message: "no action for serviceWorker Factory !!!" });
    };
    return await result();
  }
  async _onInternal(event) {
    const pathname = event.pathname.slice(INTERNAL_PREFIX.length);
    if (pathname === "window-info") {
      return Response.json({ wid: await this.widPo.promise });
    }
  }
  /**
   * request 事件处理器
   */
  async _onApi(event, connect = (mmid) => jsProcess.connect(mmid), useIpcBody = true) {
    const { pathname, search } = event;
    const path = `file:/${pathname}${search}`;
    const mmid = new URL(path).host;
    const targetIpc = await connect(mmid);
    const ipcProxyRequest = useIpcBody ? new IpcRequest(
      //
      targetIpc.allocReqId(),
      path,
      event.method,
      event.headers,
      event.ipcRequest.body,
      targetIpc
    ) : IpcRequest.fromStream(
      targetIpc.allocReqId(),
      path,
      event.method,
      event.headers,
      await event.ipcRequest.body.stream(),
      targetIpc
    );
    targetIpc.postMessage(ipcProxyRequest);
    const ipcProxyResponse = await targetIpc.registerReqId(ipcProxyRequest.req_id).promise;
    return ipcProxyResponse.toResponse();
  }
};

// ../desktop-dev/src/core/ipc/IpcBody.ts
var _IpcBody = class {
  get raw() {
    return this._bodyHub.data;
  }
  async u8a() {
    const bodyHub = this._bodyHub;
    let body_u8a = bodyHub.u8a;
    if (body_u8a === void 0) {
      if (bodyHub.stream) {
        body_u8a = await streamReadAllBuffer(bodyHub.stream);
      } else if (bodyHub.text !== void 0) {
        body_u8a = simpleEncoder(bodyHub.text, "utf8");
      } else {
        throw new Error(`invalid body type`);
      }
      bodyHub.u8a = body_u8a;
      _IpcBody.CACHE.raw_ipcBody_WMap.set(body_u8a, this);
    }
    return body_u8a;
  }
  async stream() {
    const bodyHub = this._bodyHub;
    let body_stream = bodyHub.stream;
    if (body_stream === void 0) {
      body_stream = new Blob([await this.u8a()]).stream();
      bodyHub.stream = body_stream;
      _IpcBody.CACHE.raw_ipcBody_WMap.set(body_stream, this);
    }
    return body_stream;
  }
  async text() {
    const bodyHub = this._bodyHub;
    let body_text = bodyHub.text;
    if (body_text === void 0) {
      body_text = simpleDecoder(await this.u8a(), "utf8");
      bodyHub.text = body_text;
    }
    return body_text;
  }
};
var IpcBody = _IpcBody;
IpcBody.CACHE = new class {
  constructor() {
    /**
     * 任意的 RAW 背后都会有一个 IpcBodySender/IpcBodyReceiver
     * 将它们缓存起来，那么使用这些 RAW 确保只拿到同一个 IpcBody，这对 RAW-Stream 很重要，流不可以被多次打开读取
     */
    this.raw_ipcBody_WMap = /* @__PURE__ */ new WeakMap();
    /**
     * 每一个 metaBody 背后，都会有第一个 接收者IPC，这直接定义了它的应该由谁来接收这个数据，
     * 其它的 IPC 即便拿到了这个 metaBody 也是没有意义的，除非它是 INLINE
     */
    this.metaId_receiverIpc_Map = /* @__PURE__ */ new Map();
    /**
     * 每一个 metaBody 背后，都会有一个 IpcBodySender,
     * 这里主要是存储 流，因为它有明确的 open/close 生命周期
     */
    this.metaId_ipcBodySender_Map = /* @__PURE__ */ new Map();
  }
}();
var BodyHub = class {
  constructor(data) {
    this.data = data;
    if (typeof data === "string") {
      this.text = data;
    } else if (data instanceof ReadableStream) {
      this.stream = data;
    } else {
      this.u8a = data;
    }
  }
};

// ../desktop-dev/src/core/ipc/const.ts
var toIpcMethod = (method) => {
  if (method == null) {
    return "GET" /* GET */;
  }
  switch (method.toUpperCase()) {
    case "GET" /* GET */: {
      return "GET" /* GET */;
    }
    case "POST" /* POST */: {
      return "POST" /* POST */;
    }
    case "PUT" /* PUT */: {
      return "PUT" /* PUT */;
    }
    case "DELETE" /* DELETE */: {
      return "DELETE" /* DELETE */;
    }
    case "OPTIONS" /* OPTIONS */: {
      return "OPTIONS" /* OPTIONS */;
    }
    case "TRACE" /* TRACE */: {
      return "TRACE" /* TRACE */;
    }
    case "PATCH" /* PATCH */: {
      return "PATCH" /* PATCH */;
    }
    case "PURGE" /* PURGE */: {
      return "PURGE" /* PURGE */;
    }
    case "HEAD" /* HEAD */: {
      return "HEAD" /* HEAD */;
    }
  }
  throw new Error(`invalid method: ${method}`);
};
var IpcMessage = class {
  constructor(type) {
    this.type = type;
  }
};
var $dataToBinary = (data, encoding) => {
  switch (encoding) {
    case 8 /* BINARY */: {
      return data;
    }
    case 4 /* BASE64 */: {
      return simpleEncoder(data, "base64");
    }
    case 2 /* UTF8 */: {
      return simpleEncoder(data, "utf8");
    }
  }
  throw new Error(`unknown encoding: ${encoding}`);
};
var $dataToText = (data, encoding) => {
  switch (encoding) {
    case 8 /* BINARY */: {
      return simpleDecoder(data, "utf8");
    }
    case 4 /* BASE64 */: {
      return simpleDecoder(simpleEncoder(data, "base64"), "utf8");
    }
    case 2 /* UTF8 */: {
      return data;
    }
  }
  throw new Error(`unknown encoding: ${encoding}`);
};

// ../desktop-dev/src/core/ipc/IpcStreamAbort.ts
var IpcStreamAbort = class extends IpcMessage {
  constructor(stream_id) {
    super(6 /* STREAM_ABORT */);
    this.stream_id = stream_id;
  }
};

// ../desktop-dev/src/core/ipc/IpcStreamPulling.ts
var IpcStreamPulling = class extends IpcMessage {
  constructor(stream_id, bandwidth) {
    super(3 /* STREAM_PULLING */);
    this.stream_id = stream_id;
    this.bandwidth = bandwidth ?? 0;
  }
};

// ../desktop-dev/src/core/ipc/IpcBodyReceiver.ts
var IpcBodyReceiver = class extends IpcBody {
  constructor(metaBody, ipc2) {
    super();
    this.metaBody = metaBody;
    if (metaBody.type_isStream) {
      const streamId = metaBody.streamId;
      const senderIpcUid = metaBody.senderUid;
      const metaId = `${senderIpcUid}/${streamId}`;
      if (IpcBodyReceiver.CACHE.metaId_receiverIpc_Map.has(metaId) === false) {
        ipc2.onClose(() => {
          IpcBodyReceiver.CACHE.metaId_receiverIpc_Map.delete(metaId);
        });
        IpcBodyReceiver.CACHE.metaId_receiverIpc_Map.set(metaId, ipc2);
        metaBody.receiverUid = ipc2.uid;
      }
      const receiver = IpcBodyReceiver.CACHE.metaId_receiverIpc_Map.get(metaId);
      if (receiver === void 0) {
        throw new Error(`no found ipc by metaId:${metaId}`);
      }
      ipc2 = receiver;
      this._bodyHub = new BodyHub($metaToStream(this.metaBody, ipc2));
    } else
      switch (metaBody.type_encoding) {
        case 2 /* UTF8 */:
          this._bodyHub = new BodyHub(metaBody.data);
          break;
        case 4 /* BASE64 */:
          this._bodyHub = new BodyHub(simpleEncoder(metaBody.data, "base64"));
          break;
        case 8 /* BINARY */:
          this._bodyHub = new BodyHub(metaBody.data);
          break;
        default:
          throw new Error(`invalid metaBody type: ${metaBody.type}`);
      }
  }
  /**
   * 基于 metaBody 还原 IpcBodyReceiver
   */
  static from(metaBody, ipc2) {
    return IpcBodyReceiver.CACHE.metaId_ipcBodySender_Map.get(metaBody.metaId) ?? new IpcBodyReceiver(metaBody, ipc2);
  }
};
var $metaToStream = (metaBody, ipc2) => {
  if (ipc2 == null) {
    throw new Error(`miss ipc when ipc-response has stream-body`);
  }
  const stream_ipc = ipc2;
  const stream_id = metaBody.streamId;
  let paused = true;
  const stream = new ReadableStream(
    {
      start(controller) {
        ipc2.onClose(() => {
          try {
            controller.close();
          } catch {
          }
        });
        let firstData;
        switch (metaBody.type_encoding) {
          case 2 /* UTF8 */:
            firstData = simpleEncoder(metaBody.data, "utf8");
            break;
          case 4 /* BASE64 */:
            firstData = simpleEncoder(metaBody.data, "base64");
            break;
          case 8 /* BINARY */:
            firstData = metaBody.data;
            break;
        }
        if (firstData) {
          controller.enqueue(firstData);
        }
        const off = ipc2.onStream((message) => {
          if (message.stream_id === stream_id) {
            switch (message.type) {
              case 2 /* STREAM_DATA */:
                controller.enqueue(message.binary);
                break;
              case 5 /* STREAM_END */:
                controller.close();
                off();
                break;
            }
          }
        });
      },
      pull(_controller) {
        if (paused) {
          paused = false;
          stream_ipc.postMessage(new IpcStreamPulling(stream_id));
        }
      },
      cancel() {
        stream_ipc.postMessage(new IpcStreamAbort(stream_id));
      }
    },
    {
      /// 按需 pull, 不可以0以上。否则一开始的时候就会发送pull指令，会导致远方直接把流给读取出来。
      /// 这会导致一些优化的行为异常，有些时候流一旦开始读取了，其他读取者就不能再进入读取了。那么流转发就不能工作了
      highWaterMark: 0
    }
  );
  return stream;
};
new WritableStream({});

// ../desktop-dev/src/helper/cacheGetter.ts
var CacheGetter = class {
  constructor(getter) {
    this.getter = getter;
    this._first = true;
  }
  get value() {
    if (this._first) {
      this._first = false;
      this._value = this.getter();
    }
    return this._value;
  }
  reset() {
    this._first = true;
    this._value = void 0;
  }
};

// ../desktop-dev/src/core/ipc/IpcStreamData.ts
var IpcStreamData = class extends IpcMessage {
  constructor(stream_id, data, encoding) {
    super(2 /* STREAM_DATA */);
    this.stream_id = stream_id;
    this.data = data;
    this.encoding = encoding;
  }
  static fromBase64(stream_id, data) {
    return new IpcStreamData(stream_id, simpleDecoder(data, "base64"), 4 /* BASE64 */);
  }
  static fromBinary(stream_id, data) {
    return new IpcStreamData(stream_id, data, 8 /* BINARY */);
  }
  static fromUtf8(stream_id, data) {
    return new IpcStreamData(stream_id, simpleDecoder(data, "utf8"), 2 /* UTF8 */);
  }
  #binary = new CacheGetter(() => $dataToBinary(this.data, this.encoding));
  get binary() {
    return this.#binary.value;
  }
  #text = new CacheGetter(() => $dataToText(this.data, this.encoding));
  get text() {
    return this.#text.value;
  }
  #jsonAble = new CacheGetter(() => {
    if (this.encoding === 8 /* BINARY */) {
      return IpcStreamData.fromBase64(this.stream_id, this.data);
    }
    return this;
  });
  get jsonAble() {
    return this.#jsonAble.value;
  }
  toJSON() {
    return { ...this.jsonAble };
  }
};

// ../desktop-dev/src/core/ipc/IpcStreamEnd.ts
var IpcStreamEnd = class extends IpcMessage {
  constructor(stream_id) {
    super(5 /* STREAM_END */);
    this.stream_id = stream_id;
  }
};

// ../desktop-dev/src/core/ipc/MetaBody.ts
var MetaBody = class {
  constructor(type, senderUid, data, streamId, receiverUid, metaId = simpleDecoder(crypto.getRandomValues(new Uint8Array(8)), "base64")) {
    this.type = type;
    this.senderUid = senderUid;
    this.data = data;
    this.streamId = streamId;
    this.receiverUid = receiverUid;
    this.metaId = metaId;
  }
  static fromJSON(metaBody) {
    if (metaBody instanceof MetaBody === false) {
      metaBody = new MetaBody(
        metaBody.type,
        metaBody.senderUid,
        metaBody.data,
        metaBody.streamId,
        metaBody.receiverUid,
        metaBody.metaId
      );
    }
    return metaBody;
  }
  static fromText(senderUid, data, streamId, receiverUid) {
    return new MetaBody(
      streamId == null ? IPC_META_BODY_TYPE.INLINE_TEXT : IPC_META_BODY_TYPE.STREAM_WITH_TEXT,
      senderUid,
      data,
      streamId,
      receiverUid
    );
  }
  static fromBase64(senderUid, data, streamId, receiverUid) {
    return new MetaBody(
      streamId == null ? IPC_META_BODY_TYPE.INLINE_BASE64 : IPC_META_BODY_TYPE.STREAM_WITH_BASE64,
      senderUid,
      data,
      streamId,
      receiverUid
    );
  }
  static fromBinary(sender, data, streamId, receiverUid) {
    if (typeof sender === "number") {
      return new MetaBody(
        streamId == null ? IPC_META_BODY_TYPE.INLINE_BINARY : IPC_META_BODY_TYPE.STREAM_WITH_BINARY,
        sender,
        data,
        streamId,
        receiverUid
      );
    }
    if (sender.support_binary) {
      return this.fromBinary(sender.uid, data, streamId, receiverUid);
    }
    return this.fromBase64(sender.uid, simpleDecoder(data, "base64"), streamId, receiverUid);
  }
  #type_encoding = new CacheGetter(() => {
    const encoding = this.type & 254;
    switch (encoding) {
      case 2 /* UTF8 */:
        return 2 /* UTF8 */;
      case 4 /* BASE64 */:
        return 4 /* BASE64 */;
      case 8 /* BINARY */:
        return 8 /* BINARY */;
      default:
        return 2 /* UTF8 */;
    }
  });
  get type_encoding() {
    return this.#type_encoding.value;
  }
  #type_isInline = new CacheGetter(() => (this.type & 1 /* INLINE */) !== 0);
  get type_isInline() {
    return this.#type_isInline.value;
  }
  #type_isStream = new CacheGetter(() => (this.type & 1 /* INLINE */) === 0);
  get type_isStream() {
    return this.#type_isStream.value;
  }
  #jsonAble = new CacheGetter(() => {
    if (this.type_encoding === 8 /* BINARY */) {
      return MetaBody.fromBase64(
        this.senderUid,
        simpleDecoder(this.data, "base64"),
        this.streamId,
        this.receiverUid
      );
    }
    return this;
  });
  get jsonAble() {
    return this.#jsonAble.value;
  }
  toJSON() {
    return { ...this.jsonAble };
  }
};
var IPC_META_BODY_TYPE = ((IPC_META_BODY_TYPE2) => {
  IPC_META_BODY_TYPE2[IPC_META_BODY_TYPE2["STREAM_ID"] = 0] = "STREAM_ID";
  IPC_META_BODY_TYPE2[IPC_META_BODY_TYPE2["INLINE"] = 1] = "INLINE";
  IPC_META_BODY_TYPE2[IPC_META_BODY_TYPE2["STREAM_WITH_TEXT"] = 0 /* STREAM_ID */ | 2 /* UTF8 */] = "STREAM_WITH_TEXT";
  IPC_META_BODY_TYPE2[IPC_META_BODY_TYPE2["STREAM_WITH_BASE64"] = 0 /* STREAM_ID */ | 4 /* BASE64 */] = "STREAM_WITH_BASE64";
  IPC_META_BODY_TYPE2[IPC_META_BODY_TYPE2["STREAM_WITH_BINARY"] = 0 /* STREAM_ID */ | 8 /* BINARY */] = "STREAM_WITH_BINARY";
  IPC_META_BODY_TYPE2[IPC_META_BODY_TYPE2["INLINE_TEXT"] = 1 /* INLINE */ | 2 /* UTF8 */] = "INLINE_TEXT";
  IPC_META_BODY_TYPE2[IPC_META_BODY_TYPE2["INLINE_BASE64"] = 1 /* INLINE */ | 4 /* BASE64 */] = "INLINE_BASE64";
  IPC_META_BODY_TYPE2[IPC_META_BODY_TYPE2["INLINE_BINARY"] = 1 /* INLINE */ | 8 /* BINARY */] = "INLINE_BINARY";
  return IPC_META_BODY_TYPE2;
})(IPC_META_BODY_TYPE || {});

// ../desktop-dev/src/core/ipc/IpcBodySender.ts
var _IpcBodySender = class extends IpcBody {
  constructor(data, ipc2) {
    super();
    this.data = data;
    this.ipc = ipc2;
    this.streamCtorSignal = createSignal();
    /**
     * 被哪些 ipc 所真正使用，使用的进度分别是多少
     *
     * 这个进度 用于 类似流的 多发
     */
    this.usedIpcMap = /* @__PURE__ */ new Map();
    this.UsedIpcInfo = class UsedIpcInfo {
      constructor(ipcBody, ipc2, bandwidth = 0, fuse = 0) {
        this.ipcBody = ipcBody;
        this.ipc = ipc2;
        this.bandwidth = bandwidth;
        this.fuse = fuse;
      }
      emitStreamPull(message) {
        return this.ipcBody.emitStreamPull(this, message);
      }
      emitStreamPaused(message) {
        return this.ipcBody.emitStreamPaused(this, message);
      }
      emitStreamAborted() {
        return this.ipcBody.emitStreamAborted(this);
      }
    };
    this.closeSignal = createSignal();
    this.openSignal = createSignal();
    this._isStreamOpened = false;
    this._isStreamClosed = false;
    this._bodyHub = new BodyHub(data);
    this.metaBody = this.$bodyAsMeta(data, ipc2);
    this.isStream = data instanceof ReadableStream;
    if (typeof data !== "string") {
      _IpcBodySender.CACHE.raw_ipcBody_WMap.set(data, this);
    }
    _IpcBodySender.$usableByIpc(ipc2, this);
  }
  static fromAny(data, ipc2) {
    if (typeof data !== "string") {
      const cache = _IpcBodySender.CACHE.raw_ipcBody_WMap.get(data);
      if (cache !== void 0) {
        return cache;
      }
    }
    return new _IpcBodySender(data, ipc2);
  }
  static fromText(raw, ipc2) {
    return this.fromAny(raw, ipc2);
  }
  static fromBinary(raw, ipc2) {
    return this.fromAny(raw, ipc2);
  }
  static fromStream(raw, ipc2) {
    return this.fromAny(raw, ipc2);
  }
  /**
   * 绑定使用
   */
  useByIpc(ipc2) {
    const info = this.usedIpcMap.get(ipc2);
    if (info !== void 0) {
      return info;
    }
    if (this.isStream && !this._isStreamOpened) {
      const info2 = new this.UsedIpcInfo(this, ipc2);
      this.usedIpcMap.set(ipc2, info2);
      this.closeSignal.listen(() => {
        this.emitStreamAborted(info2);
      });
      return info2;
    }
  }
  /**
   * 拉取数据
   */
  emitStreamPull(info, message) {
    info.bandwidth = message.bandwidth;
    this.streamCtorSignal.emit(0 /* PULLING */);
  }
  /**
   * 暂停数据
   */
  emitStreamPaused(info, message) {
    info.bandwidth = -1;
    info.fuse = message.fuse;
    let paused = true;
    for (const info2 of this.usedIpcMap.values()) {
      if (info2.bandwidth >= 0) {
        paused = false;
        break;
      }
    }
    if (paused) {
      this.streamCtorSignal.emit(1 /* PAUSED */);
    }
  }
  /**
   * 解绑使用
   */
  emitStreamAborted(info) {
    if (this.usedIpcMap.delete(info.ipc) != null) {
      if (this.usedIpcMap.size === 0) {
        this.streamCtorSignal.emit(2 /* ABORTED */);
      }
    }
  }
  onStreamClose(cb) {
    return this.closeSignal.listen(cb);
  }
  onStreamOpen(cb) {
    return this.openSignal.listen(cb);
  }
  get isStreamOpened() {
    return this._isStreamOpened;
  }
  set isStreamOpened(value) {
    if (this._isStreamOpened !== value) {
      this._isStreamOpened = value;
      if (value) {
        this.openSignal.emitAndClear();
      }
    }
  }
  get isStreamClosed() {
    return this._isStreamClosed;
  }
  set isStreamClosed(value) {
    if (this._isStreamClosed !== value) {
      this._isStreamClosed = value;
      if (value) {
        this.closeSignal.emitAndClear();
      }
    }
  }
  emitStreamClose() {
    this.isStreamOpened = true;
    this.isStreamClosed = true;
  }
  $bodyAsMeta(body, ipc2) {
    if (typeof body === "string") {
      return MetaBody.fromText(ipc2.uid, body);
    }
    if (body instanceof ReadableStream) {
      return this.$streamAsMeta(body, ipc2);
    }
    return MetaBody.fromBinary(ipc2, body);
  }
  /**
   * 如果 rawData 是流模式，需要提供数据发送服务
   *
   * 这里不会一直无脑发，而是对方有需要的时候才发
   * @param stream_id
   * @param stream
   * @param ipc
   */
  $streamAsMeta(stream, ipc2) {
    const stream_id = getStreamId(stream);
    let _reader;
    const getReader = () => _reader ??= binaryStreamRead(stream);
    (async () => {
      let pullingLock = new PromiseOut();
      this.streamCtorSignal.listen(async (signal) => {
        switch (signal) {
          case 0 /* PULLING */: {
            pullingLock.resolve();
            break;
          }
          case 1 /* PAUSED */: {
            if (pullingLock.is_finished) {
              pullingLock = new PromiseOut();
            }
            break;
          }
          case 2 /* ABORTED */: {
            await getReader().return();
            await stream.cancel();
            this.emitStreamClose();
          }
        }
      });
      while (true) {
        await pullingLock.promise;
        const reader = getReader();
        const availableLen = await reader.available();
        if (availableLen > 0) {
          this.isStreamOpened = true;
          const message = IpcStreamData.fromBinary(stream_id, await reader.readBinary(availableLen));
          for (const ipc3 of this.usedIpcMap.keys()) {
            ipc3.postMessage(message);
          }
        } else if (availableLen === -1) {
          const message = new IpcStreamEnd(stream_id);
          for (const ipc3 of this.usedIpcMap.keys()) {
            ipc3.postMessage(message);
          }
          await stream.cancel();
          this.emitStreamClose();
          break;
        }
      }
    })().catch(console.error);
    const streamType = 0 /* STREAM_ID */;
    const streamFirstData = "";
    if ("preReadableSize" in stream && typeof stream.preReadableSize === "number" && stream.preReadableSize > 0) {
    }
    const metaBody = new MetaBody(streamType, ipc2.uid, streamFirstData, stream_id);
    _IpcBodySender.CACHE.metaId_ipcBodySender_Map.set(metaBody.metaId, this);
    this.streamCtorSignal.listen((signal) => {
      if (signal == 2 /* ABORTED */) {
        _IpcBodySender.CACHE.metaId_ipcBodySender_Map.delete(metaBody.metaId);
      }
    });
    return metaBody;
  }
};
var IpcBodySender2 = _IpcBodySender;
/**
 * ipc 将会使用它
 */
IpcBodySender2.$usableByIpc = (ipc2, ipcBody) => {
  if (ipcBody.isStream && !ipcBody._isStreamOpened) {
    const streamId = ipcBody.metaBody.streamId;
    let usableIpcBodyMapper = IpcUsableIpcBodyMap.get(ipc2);
    if (usableIpcBodyMapper === void 0) {
      const mapper = new UsableIpcBodyMapper();
      IpcUsableIpcBodyMap.set(ipc2, mapper);
      mapper.onDestroy(
        ipc2.onStream((message) => {
          switch (message.type) {
            case 3 /* STREAM_PULLING */:
              mapper.get(message.stream_id)?.useByIpc(ipc2)?.emitStreamPull(message);
              break;
            case 4 /* STREAM_PAUSED */:
              mapper.get(message.stream_id)?.useByIpc(ipc2)?.emitStreamPaused(message);
              break;
            case 6 /* STREAM_ABORT */:
              mapper.get(message.stream_id)?.useByIpc(ipc2)?.emitStreamAborted();
              break;
          }
        })
      );
      mapper.onDestroy(() => IpcUsableIpcBodyMap.delete(ipc2));
      usableIpcBodyMapper = mapper;
    }
    if (usableIpcBodyMapper.add(streamId, ipcBody)) {
      ipcBody.onStreamClose(() => usableIpcBodyMapper.remove(streamId));
    }
  }
};
var streamIdWM = /* @__PURE__ */ new WeakMap();
var streamRealmId = crypto.randomUUID();
var stream_id_acc = 0;
var getStreamId = (stream) => {
  let id = streamIdWM.get(stream);
  if (id === void 0) {
    id = `${streamRealmId}-${stream_id_acc++}`;
    streamIdWM.set(stream, id);
  }
  return id;
};
var setStreamId = (stream, cid) => {
  let id = streamIdWM.get(stream);
  if (id === void 0) {
    streamIdWM.set(stream, id = `${streamRealmId}-${stream_id_acc++}[${cid}]`);
  }
  return id;
};
var UsableIpcBodyMapper = class {
  constructor() {
    this.map = /* @__PURE__ */ new Map();
    this.destroySignal = createSignal();
  }
  add(streamId, ipcBody) {
    if (this.map.has(streamId)) {
      return false;
    }
    this.map.set(streamId, ipcBody);
    return true;
  }
  get(streamId) {
    return this.map.get(streamId);
  }
  remove(streamId) {
    const ipcBody = this.map.get(streamId);
    if (ipcBody !== void 0) {
      this.map.delete(streamId);
      if (this.map.size === 0) {
        this.destroySignal.emitAndClear();
      }
    }
  }
  onDestroy(cb) {
    this.destroySignal.listen(cb);
  }
};
var IpcUsableIpcBodyMap = /* @__PURE__ */ new WeakMap();

// ../desktop-dev/src/core/ipc/IpcEvent.ts
var IpcEvent2 = class extends IpcMessage {
  constructor(name, data, encoding) {
    super(7 /* EVENT */);
    this.name = name;
    this.data = data;
    this.encoding = encoding;
  }
  static fromBase64(name, data) {
    return new IpcEvent2(name, simpleDecoder(data, "base64"), 4 /* BASE64 */);
  }
  static fromBinary(name, data) {
    return new IpcEvent2(name, data, 8 /* BINARY */);
  }
  static fromUtf8(name, data) {
    return new IpcEvent2(name, simpleDecoder(data, "utf8"), 2 /* UTF8 */);
  }
  static fromText(name, data) {
    return new IpcEvent2(name, data, 2 /* UTF8 */);
  }
  #binary = new CacheGetter(() => $dataToBinary(this.data, this.encoding));
  get binary() {
    return this.#binary.value;
  }
  #text = new CacheGetter(() => $dataToText(this.data, this.encoding));
  get text() {
    return this.#text.value;
  }
  #jsonAble = new CacheGetter(() => {
    if (this.encoding === 8 /* BINARY */) {
      return IpcEvent2.fromBase64(this.name, this.data);
    }
    return this;
  });
  get jsonAble() {
    return this.#jsonAble.value;
  }
  toJSON() {
    return { ...this.jsonAble };
  }
};

// ../desktop-dev/src/core/ipc/IpcHeaders.ts
var IpcHeaders3 = class extends Headers {
  init(key, value) {
    if (this.has(key) === false) {
      this.set(key, value);
    }
    return this;
  }
  toJSON() {
    const record = {};
    this.forEach((value, key) => {
      record[key.replace(/\w+/g, (w2) => w2[0].toUpperCase() + w2.slice(1))] = value;
    });
    return record;
  }
};

// ../desktop-dev/src/helper/$once.ts
var once = (fn) => {
  let first = true;
  let resolved;
  let rejected;
  let success = false;
  return function(...args) {
    if (first) {
      first = false;
      try {
        resolved = fn.apply(this, args);
        success = true;
      } catch (err) {
        rejected = err;
      }
    }
    if (success) {
      return resolved;
    }
    throw rejected;
  };
};

// ../desktop-dev/src/helper/urlHelper.ts
var getBaseUrl = () => URL_BASE ??= "document" in globalThis ? document.baseURI : "location" in globalThis && (location.protocol === "http:" || location.protocol === "https:" || location.protocol === "file:" || location.protocol === "chrome-extension:") ? location.href : "file:///";
var URL_BASE;
var parseUrl = (url, base = getBaseUrl()) => {
  return new URL(url, base);
};

// ../desktop-dev/src/helper/httpHelper.ts
var httpMethodCanOwnBody = (method, headers) => {
  if (headers !== void 0) {
    return isWebSocket(method, headers instanceof Headers ? headers : new Headers(headers));
  }
  return method !== "GET" && method !== "HEAD" && method !== "TRACE" && method !== "OPTIONS";
};

// ../desktop-dev/src/core/helper/ipcRequestHelper.ts
var $bodyInitToIpcBodyArgs = async (bodyInit, onUnknown) => {
  let body = "";
  if (bodyInit instanceof FormData || bodyInit instanceof URLSearchParams) {
    bodyInit = await new Request("", {
      body: bodyInit
    }).blob();
  }
  if (bodyInit instanceof ReadableStream) {
    body = bodyInit;
  } else if (bodyInit instanceof Blob) {
    if (bodyInit.size >= 16 * 1024 * 1024) {
      body = bodyInit?.stream() || "";
    }
    if (body === "") {
      body = new Uint8Array(await bodyInit.arrayBuffer());
    }
  } else if (isBinary(bodyInit)) {
    body = binaryToU8a(bodyInit);
  } else if (typeof bodyInit === "string") {
    body = bodyInit;
  } else if (bodyInit) {
    if (onUnknown) {
      bodyInit = onUnknown(bodyInit);
    } else {
      throw new Error(`unsupport body type: ${bodyInit?.constructor.name}`);
    }
  }
  return body;
};
var isWebSocket = (method, headers) => {
  return method === "GET" && headers.get("Upgrade")?.toLowerCase() === "websocket";
};
var buildRequestX = (url, init = {}) => {
  let method = init.method ?? "GET" /* GET */;
  const headers = init.headers instanceof Headers ? init.headers : new Headers(init.headers);
  const isWs = isWebSocket(method, headers);
  let body;
  if (isWs) {
    method = "POST" /* POST */;
    body = init.body;
  } else if (httpMethodCanOwnBody(method)) {
    body = init.body;
  }
  const request_init = {
    method,
    headers,
    body,
    duplex: body instanceof ReadableStream ? "half" : void 0
  };
  const request = new Request(url, request_init);
  if (isWs) {
    Object.defineProperty(request, "method", {
      configurable: true,
      enumerable: true,
      writable: false,
      value: "GET"
    });
  }
  if (request_init.body instanceof ReadableStream && request.body != request_init.body) {
    Object.defineProperty(request, "body", {
      configurable: true,
      enumerable: true,
      writable: false,
      value: request_init.body
    });
  }
  return request;
};

// ../desktop-dev/src/core/ipc/IpcRequest.ts
var IpcRequest2 = class extends IpcMessage {
  constructor(req_id, url, method, headers, body, ipc2) {
    super(0 /* REQUEST */);
    this.req_id = req_id;
    this.url = url;
    this.method = method;
    this.headers = headers;
    this.body = body;
    this.ipc = ipc2;
    this.ipcReqMessage = once(
      () => new IpcReqMessage(this.req_id, this.method, this.url, this.headers.toJSON(), this.body.metaBody)
    );
    if (body instanceof IpcBodySender2) {
      IpcBodySender2.$usableByIpc(ipc2, body);
    }
  }
  get parsed_url() {
    return this._parsed_url ??= parseUrl(this.url);
  }
  static fromText(req_id, url, method = "GET" /* GET */, headers = new IpcHeaders3(), text, ipc2) {
    return new IpcRequest2(req_id, url, method, headers, IpcBodySender2.fromText(text, ipc2), ipc2);
  }
  static fromBinary(req_id, url, method = "GET" /* GET */, headers = new IpcHeaders3(), binary, ipc2) {
    headers.init("Content-Type", "application/octet-stream");
    headers.init("Content-Length", binary.byteLength + "");
    return new IpcRequest2(req_id, url, method, headers, IpcBodySender2.fromBinary(binaryToU8a(binary), ipc2), ipc2);
  }
  // 如果需要发送stream数据 一定要使用这个方法才可以传递数据否则数据无法传递
  static fromStream(req_id, url, method = "GET" /* GET */, headers = new IpcHeaders3(), stream, ipc2) {
    headers.init("Content-Type", "application/octet-stream");
    return new IpcRequest2(req_id, url, method, headers, IpcBodySender2.fromStream(stream, ipc2), ipc2);
  }
  static fromRequest(req_id, ipc2, url, init = {}) {
    const method = toIpcMethod(init.method);
    const headers = init.headers instanceof IpcHeaders3 ? init.headers : new IpcHeaders3(init.headers);
    let ipcBody;
    if (isBinary(init.body)) {
      ipcBody = IpcBodySender2.fromBinary(init.body, ipc2);
    } else if (init.body instanceof ReadableStream) {
      ipcBody = IpcBodySender2.fromStream(init.body, ipc2);
    } else if (init.body instanceof Blob) {
      ipcBody = IpcBodySender2.fromStream(init.body.stream(), ipc2);
    } else {
      ipcBody = IpcBodySender2.fromText(init.body ?? "", ipc2);
    }
    return new IpcRequest2(req_id, url, method, headers, ipcBody, ipc2);
  }
  /**
   * 判断是否是双工协议
   *
   * 比如目前双工协议可以由 WebSocket 来提供支持
   */
  get isDuplex() {
    return isWebSocket(this.method, this.headers);
  }
  toRequest() {
    return buildRequestX(this.url, { method: this.method, headers: this.headers, body: this.body.raw });
  }
  toJSON() {
    const { method } = this;
    if ((method === "GET" /* GET */ || method === "HEAD" /* HEAD */) === false) {
      return new IpcReqMessage(this.req_id, this.method, this.url, this.headers.toJSON(), this.body.metaBody);
    }
    return this.ipcReqMessage();
  }
};
var IpcReqMessage = class extends IpcMessage {
  constructor(req_id, method, url, headers, metaBody) {
    super(0 /* REQUEST */);
    this.req_id = req_id;
    this.method = method;
    this.url = url;
    this.headers = headers;
    this.metaBody = metaBody;
  }
};

// ../desktop-dev/src/core/ipc/IpcResponse.ts
var IpcResponse2 = class extends IpcMessage {
  constructor(req_id, statusCode, headers, body, ipc2) {
    super(1 /* RESPONSE */);
    this.req_id = req_id;
    this.statusCode = statusCode;
    this.headers = headers;
    this.body = body;
    this.ipc = ipc2;
    this.ipcResMessage = once(
      () => new IpcResMessage(this.req_id, this.statusCode, this.headers.toJSON(), this.body.metaBody)
    );
    if (body instanceof IpcBodySender2) {
      IpcBodySender2.$usableByIpc(ipc2, body);
    }
  }
  #ipcHeaders;
  get ipcHeaders() {
    return this.#ipcHeaders ??= new IpcHeaders3(this.headers);
  }
  toResponse(url) {
    const body = this.body.raw;
    if (body instanceof Uint8Array) {
      this.headers.init("Content-Length", body.length + "");
    }
    const response = new Response(body, {
      headers: this.headers,
      status: this.statusCode
    });
    if (url) {
      Object.defineProperty(response, "url", {
        value: url,
        enumerable: true,
        configurable: true,
        writable: false
      });
    }
    return response;
  }
  /** 将 response 对象进行转码变成 ipcResponse */
  static async fromResponse(req_id, response, ipc2, asBinary = false) {
    if (response.bodyUsed) {
      throw new Error("body used");
    }
    let ipcBody;
    if (asBinary || response.body == void 0 || parseInt(response.headers.get("Content-Length") || "NaN") < 16 * 1024 * 1024) {
      ipcBody = IpcBodySender2.fromBinary(binaryToU8a(await response.arrayBuffer()), ipc2);
    } else {
      setStreamId(response.body, response.url);
      ipcBody = IpcBodySender2.fromStream(response.body, ipc2);
    }
    const ipcHeaders = new IpcHeaders3(response.headers);
    return new IpcResponse2(req_id, response.status, ipcHeaders, ipcBody, ipc2);
  }
  static fromJson(req_id, statusCode, headers = new IpcHeaders3(), jsonable, ipc2) {
    headers.init("Content-Type", "application/json");
    return this.fromText(req_id, statusCode, headers, JSON.stringify(jsonable), ipc2);
  }
  static fromText(req_id, statusCode, headers = new IpcHeaders3(), text, ipc2) {
    headers.init("Content-Type", "text/plain");
    return new IpcResponse2(req_id, statusCode, headers, IpcBodySender2.fromText(text, ipc2), ipc2);
  }
  static fromBinary(req_id, statusCode, headers = new IpcHeaders3(), binary, ipc2) {
    headers.init("Content-Type", "application/octet-stream");
    headers.init("Content-Length", binary.byteLength + "");
    return new IpcResponse2(req_id, statusCode, headers, IpcBodySender2.fromBinary(binaryToU8a(binary), ipc2), ipc2);
  }
  static fromStream(req_id, statusCode, headers = new IpcHeaders3(), stream, ipc2) {
    headers.init("Content-Type", "application/octet-stream");
    const ipcResponse = new IpcResponse2(req_id, statusCode, headers, IpcBodySender2.fromStream(stream, ipc2), ipc2);
    return ipcResponse;
  }
  toJSON() {
    return this.ipcResMessage();
  }
};
var IpcResMessage = class extends IpcMessage {
  constructor(req_id, statusCode, headers, metaBody) {
    super(1 /* RESPONSE */);
    this.req_id = req_id;
    this.statusCode = statusCode;
    this.headers = headers;
    this.metaBody = metaBody;
  }
};

// ../desktop-dev/src/core/ipc/IpcStreamPaused.ts
var IpcStreamPaused = class extends IpcMessage {
  constructor(stream_id, fuse) {
    super(4 /* STREAM_PAUSED */);
    this.stream_id = stream_id;
    this.fuse = fuse ?? 1;
  }
};

// ../desktop-dev/src/helper/fetchExtends/$makeFetchBaseExtends.ts
var $makeFetchExtends = (exts) => {
  return exts;
};
var fetchBaseExtends = $makeFetchExtends({
  async number() {
    const text = await this.text();
    return +text;
  },
  async ok() {
    const response = await this;
    if (response.status >= 400) {
      throw response.statusText || await response.text();
    } else {
      return response;
    }
  },
  async text() {
    const ok = await this.ok();
    return ok.text();
  },
  async binary() {
    const ok = await this.ok();
    return ok.arrayBuffer();
  },
  async boolean() {
    const text = await this.text();
    return text === "true";
  },
  async object() {
    const ok = await this.ok();
    try {
      return await ok.json();
    } catch (err) {
      debugger;
      throw err;
    }
  }
});

// ../desktop-dev/src/helper/stream/JsonlinesStream.ts
var JsonlinesStream = class extends TransformStream {
  constructor(onError) {
    let json = "";
    const try_enqueue = (controller, jsonline) => {
      try {
        controller.enqueue(JSON.parse(jsonline));
      } catch (err) {
        onError ? onError(err, controller) : controller.error(err);
        return true;
      }
    };
    super({
      transform: (chunk, controller) => {
        json += chunk;
        let line_break_index;
        while ((line_break_index = json.indexOf("\n")) !== -1) {
          const jsonline = json.slice(0, line_break_index);
          json = json.slice(jsonline.length + 1);
          if (try_enqueue(controller, jsonline)) {
            break;
          }
        }
      },
      flush: (controller) => {
        json = json.trim();
        if (json.length > 0) {
          try_enqueue(controller, json);
        }
        controller.terminate();
      }
    });
  }
};

// ../desktop-dev/src/helper/stream/jsonlinesStreamHelper.ts
var toJsonlinesStream = (stream) => {
  return stream.pipeThrough(new TextDecoderStream()).pipeThrough(new JsonlinesStream());
};

// ../desktop-dev/src/helper/fetchExtends/$makeFetchStreamExtends.ts
var $makeFetchExtends2 = (exts) => {
  return exts;
};
var fetchStreamExtends = $makeFetchExtends2({
  /** 将响应的内容解码成 jsonlines 格式 */
  async jsonlines() {
    return (
      // 首先要能拿到数据流
      toJsonlinesStream(await this.stream())
    );
  },
  /** 获取 Response 的 body 为 ReadableStream */
  stream() {
    return this.then((res) => {
      const stream = res.body;
      if (stream == null) {
        throw new Error(`request ${res.url} could not by stream.`);
      }
      return stream;
    });
  }
});

// ../desktop-dev/src/helper/fetchExtends/index.ts
var fetchExtends = {
  ...fetchBaseExtends,
  ...fetchStreamExtends
};

// ../desktop-dev/src/helper/normalizeFetchArgs.ts
var normalizeFetchArgs = (url, init) => {
  let _parsed_url;
  let _request_init = init;
  if (typeof url === "string") {
    _parsed_url = parseUrl(url);
  } else if (url instanceof Request) {
    _parsed_url = parseUrl(url.url);
    _request_init = url;
  } else if (url instanceof URL) {
    _parsed_url = url;
  }
  if (_parsed_url === void 0) {
    throw new Error(`no found url for fetch`);
  }
  const parsed_url = _parsed_url;
  const request_init = _request_init ?? {};
  return {
    parsed_url,
    request_init
  };
};

// ../desktop-dev/src/helper/AdaptersManager.ts
var AdaptersManager = class {
  constructor() {
    this.adapterOrderMap = /* @__PURE__ */ new Map();
    this.orderdAdapters = [];
  }
  _reorder() {
    this.orderdAdapters = [...this.adapterOrderMap].sort((a3, b4) => b4[1] - a3[1]).map((a3) => a3[0]);
  }
  get adapters() {
    return this.orderdAdapters;
  }
  /**
   *
   * @param adapter
   * @param order 越大优先级越高
   * @returns
   */
  append(adapter, order = 0) {
    this.adapterOrderMap.set(adapter, order);
    this._reorder();
    return () => this.remove(adapter);
  }
  remove(adapter) {
    if (this.adapterOrderMap.delete(adapter) != null) {
      this._reorder();
      return true;
    }
    return false;
  }
};

// ../desktop-dev/src/sys/dns/nativeFetch.ts
var nativeFetchAdaptersManager = new AdaptersManager();

// ../desktop-dev/src/core/micro-module.ts
var MicroModule = class {
  constructor() {
    this._running_state_lock = PromiseOut.resolve(false);
    this._after_shutdown_signal = createSignal();
    this.onAfterShutdown = this._after_shutdown_signal.listen;
    this._ipcSet = /* @__PURE__ */ new Set();
    /**
     * 内部程序与外部程序通讯的方法
     * TODO 这里应该是可以是多个
     */
    this._connectSignal = createSignal();
    this._activitySignal = createSignal();
    this.onActivity = this._activitySignal.listen;
    this.#manifest = new CacheGetter(() => {
      return {
        mmid: this.mmid,
        name: this.name,
        short_name: this.short_name,
        ipc_support_protocols: this.ipc_support_protocols,
        dweb_deeplinks: this.dweb_deeplinks,
        categories: this.categories,
        dir: this.dir,
        lang: this.lang,
        description: this.description,
        icons: this.icons,
        screenshots: this.screenshots,
        display: this.display,
        orientation: this.orientation,
        theme_color: this.theme_color,
        background_color: this.background_color,
        shortcuts: this.shortcuts
      };
    });
  }
  addToIpcSet(ipc2) {
    if (this._running_state_lock.value === true) {
      void ipc2.ready();
    }
    this._ipcSet.add(ipc2);
    ipc2.onClose(() => {
      this._ipcSet.delete(ipc2);
    });
  }
  get isRunning() {
    return this._running_state_lock.promise;
  }
  async before_bootstrap(context) {
    if (await this._running_state_lock.promise) {
      throw new Error(`module ${this.mmid} alreay running`);
    }
    this._running_state_lock = new PromiseOut();
    this.context = context;
  }
  after_bootstrap(_context) {
    this._running_state_lock.resolve(true);
    this.onConnect((ipc2) => {
      void ipc2.ready();
    });
    for (const ipc2 of this._ipcSet) {
      void ipc2.ready();
    }
  }
  async bootstrap(context) {
    await this.before_bootstrap(context);
    try {
      await this._bootstrap(context);
    } finally {
      this.after_bootstrap(context);
    }
  }
  async before_shutdown() {
    if (false === await this._running_state_lock.promise) {
      throw new Error(`module ${this.mmid} already shutdown`);
    }
    this._running_state_lock = new PromiseOut();
    this.context = void 0;
    for (const ipc2 of this._ipcSet) {
      ipc2.close();
    }
    this._ipcSet.clear();
  }
  after_shutdown() {
    this._after_shutdown_signal.emitAndClear();
    this._activitySignal.clear();
    this._connectSignal.clear();
    this._running_state_lock.resolve(false);
  }
  async shutdown() {
    await this.before_shutdown();
    try {
      await this._shutdown();
    } finally {
      this.after_shutdown();
    }
  }
  /**
   * 给内部程序自己使用的 onConnect，外部与内部建立连接时使用
   * 因为 NativeMicroModule 的内部程序在这里编写代码，所以这里会提供 onConnect 方法
   * 如果时 JsMicroModule 这个 onConnect 就是写在 WebWorker 那边了
   */
  onConnect(cb) {
    return this._connectSignal.listen(cb);
  }
  /**
   * 尝试连接到指定对象
   */
  async connect(mmid) {
    if (this.context) {
      const [ipc2] = await this.context.dns.connect(mmid);
      return ipc2;
    }
  }
  /**
   * 收到一个连接，触发相关事件
   */
  beConnect(ipc2, reason) {
    this.addToIpcSet(ipc2);
    ipc2.onEvent((event, ipc3) => {
      if (event.name == "activity" /* Activity */) {
        this._activitySignal.emit(event, ipc3);
      }
    });
    this._connectSignal.emit(ipc2, reason);
  }
  async _nativeFetch(url, init) {
    const args = normalizeFetchArgs(url, init);
    for (const adapter of nativeFetchAdaptersManager.adapters) {
      const response = await adapter(this, args.parsed_url, args.request_init);
      if (response !== void 0) {
        return response;
      }
    }
    return fetch(args.parsed_url, args.request_init);
  }
  nativeFetch(url, init) {
    if (init?.body instanceof ReadableStream) {
      Reflect.set(init, "duplex", "half");
    }
    return Object.assign(this._nativeFetch(url, init), fetchExtends);
  }
  #manifest;
  toManifest() {
    return this.#manifest.value;
  }
};

// ../desktop-dev/src/helper/helper.ts
function once2(func) {
  let result;
  let called = false;
  return function(...args) {
    if (!called) {
      result = func(...args);
      called = true;
    }
    return result;
  };
}

// ../desktop-dev/src/core/ipc/ipc.ts
var ipc_uid_acc = 0;
var Ipc2 = class {
  constructor() {
    this.uid = ipc_uid_acc++;
    this._support_cbor = false;
    this._support_protobuf = false;
    this._support_raw = false;
    this._support_binary = false;
    this._closeSignal = createSignal(false);
    this.onClose = this._closeSignal.listen;
    this._messageSignal = this._createSignal(false);
    this.onMessage = this._messageSignal.listen;
    /**
     * 强制触发消息传入，而不是依赖远端的 postMessage
     */
    this.emitMessage = (args) => this._messageSignal.emit(args, this);
    this.__onRequestSignal = new CacheGetter(() => {
      const signal = this._createSignal(false);
      this.onMessage((request, ipc2) => {
        if (request.type === 0 /* REQUEST */) {
          signal.emit(request, ipc2);
        }
      });
      return signal;
    });
    this.__onStreamSignal = new CacheGetter(() => {
      const signal = this._createSignal(false);
      this.onMessage((request, ipc2) => {
        if ("stream_id" in request) {
          signal.emit(request, ipc2);
        }
      });
      return signal;
    });
    this.__onEventSignal = new CacheGetter(() => {
      const signal = this._createSignal(false);
      this.onMessage((event, ipc2) => {
        if (event.type === 7 /* EVENT */) {
          signal.emit(event, ipc2);
        }
      });
      return signal;
    });
    this._closed = false;
    this._req_id_acc = 0;
    this.__reqresMap = new CacheGetter(() => {
      const reqresMap = /* @__PURE__ */ new Map();
      this.onMessage((message) => {
        if (message.type === 1 /* RESPONSE */) {
          const response_po = reqresMap.get(message.req_id);
          if (response_po) {
            reqresMap.delete(message.req_id);
            response_po.resolve(message);
          } else {
            throw new Error(`no found response by req_id: ${message.req_id}`);
          }
        }
      });
      return reqresMap;
    });
    this.readyListener = once2(async () => {
      const ready = new PromiseOut();
      this.onEvent((event, ipc2) => {
        if (event.name === "ping") {
          ipc2.postMessage(new IpcEvent2("pong", event.data, event.encoding));
        } else if (event.name === "pong") {
          ready.resolve(event);
        }
      });
      (async () => {
        let timeDelay = 50;
        while (!ready.is_resolved && !this.isClosed && timeDelay < 5e3) {
          this.postMessage(IpcEvent2.fromText("ping", ""));
          await PromiseOut.sleep(timeDelay).promise;
          timeDelay *= 3;
        }
      })();
      return await ready.promise;
    });
  }
  /**
   * 是否支持使用 MessagePack 直接传输二进制
   * 在一些特殊的场景下支持字符串传输，比如与webview的通讯
   * 二进制传输在网络相关的服务里被支持，里效率会更高，但前提是对方有 MessagePack 的编解码能力
   * 否则 JSON 是通用的传输协议
   */
  get support_cbor() {
    return this._support_cbor;
  }
  /**
   * 是否支持使用 Protobuf 直接传输二进制
   * 在网络环境里，protobuf 是更加高效的协议
   */
  get support_protobuf() {
    return this._support_protobuf;
  }
  /**
   * 是否支持结构化内存协议传输：
   * 就是说不需要对数据手动序列化反序列化，可以直接传输内存对象
   */
  get support_raw() {
    return this._support_raw;
  }
  /**
   * 是否支持二进制传输
   */
  get support_binary() {
    return this._support_binary ?? (this.support_cbor || this.support_protobuf || this.support_raw);
  }
  asRemoteInstance() {
    if (this.remote instanceof MicroModule) {
      return this.remote;
    }
  }
  // deno-lint-ignore no-explicit-any
  _createSignal(autoStart) {
    const signal = createSignal(autoStart);
    this.onClose(() => signal.clear());
    return signal;
  }
  postMessage(message) {
    if (this._closed) {
      return;
    }
    this._doPostMessage(message);
  }
  get _onRequestSignal() {
    return this.__onRequestSignal.value;
  }
  onRequest(cb) {
    return this._onRequestSignal.listen(cb);
  }
  onFetch(...handlers) {
    const onRequest = createFetchHandler(handlers);
    return onRequest.extendsTo(this.onRequest(onRequest));
  }
  get _onStreamSignal() {
    return this.__onStreamSignal.value;
  }
  onStream(cb) {
    return this._onStreamSignal.listen(cb);
  }
  get _onEventSignal() {
    return this.__onEventSignal.value;
  }
  onEvent(cb) {
    return this._onEventSignal.listen(cb);
  }
  close() {
    if (this._closed) {
      return;
    }
    this._closed = true;
    this._doClose();
    this._closeSignal.emitAndClear();
  }
  get isClosed() {
    return this._closed;
  }
  allocReqId(_url) {
    return this._req_id_acc++;
  }
  get _reqresMap() {
    return this.__reqresMap.value;
  }
  _buildIpcRequest(url, init) {
    const req_id = this.allocReqId();
    const ipcRequest = IpcRequest2.fromRequest(req_id, this, url, init);
    return ipcRequest;
  }
  request(input, init) {
    const ipcRequest = input instanceof IpcRequest2 ? input : this._buildIpcRequest(input, init);
    const result = this.registerReqId(ipcRequest.req_id);
    this.postMessage(ipcRequest);
    return result.promise;
  }
  /** 自定义注册 请求与响应 的id */
  registerReqId(req_id = this.allocReqId()) {
    return mapHelper.getOrPut(this._reqresMap, req_id, () => new PromiseOut());
  }
  ready() {
    return this.readyListener();
  }
};

// ../desktop-dev/src/core/helper/ipcFetchHelper.ts
var fetchMid = (handler) => Object.assign(handler, { [FETCH_MID_SYMBOL]: true });
var FETCH_MID_SYMBOL = Symbol("fetch.middleware");
var fetchEnd = (handler) => Object.assign(handler, { [FETCH_END_SYMBOL]: true });
var FETCH_END_SYMBOL = Symbol("fetch.end");
var FETCH_WS_SYMBOL = Symbol("fetch.websocket");
var $throw = (err) => {
  throw err;
};
var fetchHanlderFactory = {
  NoFound: () => fetchEnd((_event, res) => res ?? $throw(new FetchError2("No Found", { status: 404 }))),
  Forbidden: () => fetchEnd((_event, res) => res ?? $throw(new FetchError2("Forbidden", { status: 403 }))),
  BadRequest: () => fetchEnd((_event, res) => res ?? $throw(new FetchError2("Bad Request", { status: 400 }))),
  InternalServerError: (message = "Internal Server Error") => fetchEnd((_event, res) => res ?? $throw(new FetchError2(message, { status: 500 })))
  // deno-lint-ignore no-explicit-any
};
var createFetchHandler = (onFetchs) => {
  const onFetchHanlders = [...onFetchs];
  const extendsTo = (_to) => {
    const wrapFactory = (factory) => {
      return (...args) => {
        onFetchHanlders.push(factory(...args));
        return to;
      };
    };
    const EXT = {
      onFetch: (handler) => {
        onFetchHanlders.push(handler);
        return to;
      },
      onWebSocket: (hanlder) => {
        onFetchHanlders.push(hanlder);
        return to;
      },
      mid: (handler) => {
        onFetchHanlders.push(fetchMid(handler));
        return to;
      },
      end: (handler) => {
        onFetchHanlders.push(fetchEnd(handler));
        return to;
      },
      /**
       * 配置跨域，一般是最后调用
       * @param config
       */
      cors: (config = {}) => {
        onFetchHanlders.unshift((event) => {
          if (event.method === "OPTIONS") {
            return { body: "" };
          }
        });
        onFetchHanlders.push(
          fetchMid((res) => {
            res?.headers.init("Access-Control-Allow-Origin", config.origin ?? "*").init("Access-Control-Allow-Headers", config.headers ?? "*").init("Access-Control-Allow-Methods", config.methods ?? "*");
            return res;
          })
        );
        return to;
      },
      noFound: wrapFactory(fetchHanlderFactory.NoFound),
      forbidden: wrapFactory(fetchHanlderFactory.Forbidden),
      badRequest: wrapFactory(fetchHanlderFactory.BadRequest),
      internalServerError: wrapFactory(fetchHanlderFactory.InternalServerError),
      extendsTo
    };
    const to = _to;
    Object.assign(to, EXT);
    return to;
  };
  const onRequest = async (request, ipc2) => {
    const event = new FetchEvent2(request, ipc2);
    let res;
    for (const handler of onFetchHanlders) {
      try {
        let result = void 0;
        if (FETCH_MID_SYMBOL in handler) {
          if (res !== void 0) {
            result = await handler(res, event);
          }
        } else if (FETCH_END_SYMBOL in handler) {
          result = await handler(event, res);
        } else {
          if (res === void 0) {
            result = await handler(event);
          }
        }
        if (result instanceof IpcResponse2) {
          res = result;
        } else if (result instanceof Response) {
          res = await IpcResponse2.fromResponse(request.req_id, result, ipc2);
        } else if (typeof result === "object") {
          const req_id = request.req_id;
          const status = result.status ?? 200;
          const headers = new IpcHeaders3(result.headers);
          if (result.body instanceof IpcBody) {
            res = new IpcResponse2(req_id, status, headers, result.body, ipc2);
          } else {
            const body = await $bodyInitToIpcBodyArgs(result.body, (bodyInit) => {
              if (headers.has("Content-Type") === false || headers.get("Content-Type").startsWith("application/javascript")) {
                headers.init("Content-Type", "application/javascript,charset=utf8");
                return JSON.stringify(bodyInit);
              }
              return String(bodyInit);
            });
            if (typeof body === "string") {
              res = IpcResponse2.fromText(req_id, status, headers, body, ipc2);
            } else if (isBinary(body)) {
              res = IpcResponse2.fromBinary(req_id, status, headers, body, ipc2);
            } else if (body instanceof ReadableStream) {
              res = IpcResponse2.fromStream(req_id, status, headers, body, ipc2);
            }
          }
        }
      } catch (err) {
        if (err instanceof Response) {
          res = await IpcResponse2.fromResponse(request.req_id, err, ipc2);
        } else {
          let err_code = 500;
          let err_message = "";
          let err_detail = "";
          if (err instanceof Error) {
            err_message = err.message;
            err_detail = err.stack ?? err.name;
            if (err instanceof FetchError2) {
              err_code = err.code;
            }
          } else {
            err_message = String(err);
          }
          if (request.headers.get("Accept") === "application/json") {
            res = IpcResponse2.fromJson(
              request.req_id,
              err_code,
              new IpcHeaders3().init("Content-Type", "text/html,charset=utf8"),
              { message: err_message, detail: err_detail },
              ipc2
            );
          } else {
            res = IpcResponse2.fromText(
              request.req_id,
              err_code,
              new IpcHeaders3().init("Content-Type", "text/html,charset=utf8"),
              err instanceof Error ? `<h1>${err.message}</h1><hr/><pre>${err.stack}</pre>` : String(err),
              ipc2
            );
          }
        }
      }
    }
    if (res) {
      ipc2.postMessage(res);
      return res;
    }
  };
  return extendsTo(onRequest);
};
var FetchEvent2 = class {
  constructor(ipcRequest, ipc2) {
    this.ipcRequest = ipcRequest;
    this.ipc = ipc2;
  }
  get url() {
    return this.ipcRequest.parsed_url;
  }
  get pathname() {
    return this.url.pathname;
  }
  get search() {
    return this.url.search;
  }
  get searchParams() {
    return this.url.searchParams;
  }
  #request;
  get request() {
    return this.#request ??= this.ipcRequest.toRequest();
  }
  //#region Body 相关的属性与方法
  /** A simple getter used to expose a `ReadableStream` of the body contents. */
  get body() {
    return this.request.body;
  }
  /** Stores a `Boolean` that declares whether the body has been used in a
   * response yet.
   */
  get bodyUsed() {
    return this.request.bodyUsed;
  }
  /** Takes a `Response` stream and reads it to completion. It returns a promise
   * that resolves with an `ArrayBuffer`.
   */
  arrayBuffer() {
    return this.request.arrayBuffer();
  }
  async typedArray() {
    return new Uint8Array(await this.request.arrayBuffer());
  }
  /** Takes a `Response` stream and reads it to completion. It returns a promise
   * that resolves with a `Blob`.
   */
  blob() {
    return this.request.blob();
  }
  /** Takes a `Response` stream and reads it to completion. It returns a promise
   * that resolves with a `FormData` object.
   */
  formData() {
    return this.request.formData();
  }
  /** Takes a `Response` stream and reads it to completion. It returns a promise
   * that resolves with the result of parsing the body text as JSON.
   */
  // deno-lint-ignore no-explicit-any
  json() {
    return this.request.json();
  }
  /** Takes a `Response` stream and reads it to completion. It returns a promise
   * that resolves with a `USVString` (text).
   */
  text() {
    return this.request.text();
  }
  //#endregion
  /** Returns a Headers object consisting of the headers associated with request. Note that headers added in the network layer by the user agent will not be accounted for in this object, e.g., the "Host" header. */
  get headers() {
    return this.ipcRequest.headers;
  }
  /** Returns request's HTTP method, which is "GET" by default. */
  get method() {
    return this.ipcRequest.method;
  }
  /** Returns the URL of request as a string. */
  get href() {
    return this.url.href;
  }
  get req_id() {
    return this.ipcRequest.req_id;
  }
};
var FetchError2 = class extends Error {
  constructor(message, options) {
    super(message, options);
    this.code = options?.status ?? 500;
  }
};

// https://deno.land/x/cbor@v1.5.4/decode.js
var decoder;
try {
  decoder = new TextDecoder();
} catch (error) {
}
var src;
var srcEnd;
var position = 0;
var EMPTY_ARRAY = [];
var LEGACY_RECORD_INLINE_ID = 105;
var RECORD_DEFINITIONS_ID = 57342;
var RECORD_INLINE_ID = 57343;
var BUNDLED_STRINGS_ID = 57337;
var PACKED_REFERENCE_TAG_ID = 6;
var STOP_CODE = {};
var strings = EMPTY_ARRAY;
var stringPosition = 0;
var currentDecoder = {};
var currentStructures;
var srcString;
var srcStringStart = 0;
var srcStringEnd = 0;
var bundledStrings;
var referenceMap;
var currentExtensions = [];
var currentExtensionRanges = [];
var packedValues;
var dataView;
var restoreMapsAsObject;
var defaultOptions = {
  useRecords: false,
  mapsAsObjects: true
};
var sequentialMode = false;
var inlineObjectReadThreshold = 2;
try {
  new Function("");
} catch (error) {
  inlineObjectReadThreshold = Infinity;
}
var Decoder = class {
  constructor(options) {
    if (options) {
      if ((options.keyMap || options._keyMap) && !options.useRecords) {
        options.useRecords = false;
        options.mapsAsObjects = true;
      }
      if (options.useRecords === false && options.mapsAsObjects === void 0)
        options.mapsAsObjects = true;
      if (options.getStructures)
        options.getShared = options.getStructures;
      if (options.getShared && !options.structures)
        (options.structures = []).uninitialized = true;
      if (options.keyMap) {
        this.mapKey = /* @__PURE__ */ new Map();
        for (let [k4, v3] of Object.entries(options.keyMap))
          this.mapKey.set(v3, k4);
      }
    }
    Object.assign(this, options);
  }
  /*
  decodeKey(key) {
  	return this.keyMap
  		? Object.keys(this.keyMap)[Object.values(this.keyMap).indexOf(key)] || key
  		: key
  }
  */
  decodeKey(key) {
    return this.keyMap ? this.mapKey.get(key) || key : key;
  }
  encodeKey(key) {
    return this.keyMap && this.keyMap.hasOwnProperty(key) ? this.keyMap[key] : key;
  }
  encodeKeys(rec) {
    if (!this._keyMap)
      return rec;
    let map = /* @__PURE__ */ new Map();
    for (let [k4, v3] of Object.entries(rec))
      map.set(this._keyMap.hasOwnProperty(k4) ? this._keyMap[k4] : k4, v3);
    return map;
  }
  decodeKeys(map) {
    if (!this._keyMap || map.constructor.name != "Map")
      return map;
    if (!this._mapKey) {
      this._mapKey = /* @__PURE__ */ new Map();
      for (let [k4, v3] of Object.entries(this._keyMap))
        this._mapKey.set(v3, k4);
    }
    let res = {};
    map.forEach((v3, k4) => res[safeKey(this._mapKey.has(k4) ? this._mapKey.get(k4) : k4)] = v3);
    return res;
  }
  mapDecode(source, end) {
    let res = this.decode(source);
    if (this._keyMap) {
      switch (res.constructor.name) {
        case "Array":
          return res.map((r) => this.decodeKeys(r));
      }
    }
    return res;
  }
  decode(source, end) {
    if (src) {
      return saveState(() => {
        clearSource();
        return this ? this.decode(source, end) : Decoder.prototype.decode.call(defaultOptions, source, end);
      });
    }
    srcEnd = end > -1 ? end : source.length;
    position = 0;
    stringPosition = 0;
    srcStringEnd = 0;
    srcString = null;
    strings = EMPTY_ARRAY;
    bundledStrings = null;
    src = source;
    try {
      dataView = source.dataView || (source.dataView = new DataView(source.buffer, source.byteOffset, source.byteLength));
    } catch (error) {
      src = null;
      if (source instanceof Uint8Array)
        throw error;
      throw new Error("Source must be a Uint8Array or Buffer but was a " + (source && typeof source == "object" ? source.constructor.name : typeof source));
    }
    if (this instanceof Decoder) {
      currentDecoder = this;
      packedValues = this.sharedValues && (this.pack ? new Array(this.maxPrivatePackedValues || 16).concat(this.sharedValues) : this.sharedValues);
      if (this.structures) {
        currentStructures = this.structures;
        return checkedRead();
      } else if (!currentStructures || currentStructures.length > 0) {
        currentStructures = [];
      }
    } else {
      currentDecoder = defaultOptions;
      if (!currentStructures || currentStructures.length > 0)
        currentStructures = [];
      packedValues = null;
    }
    return checkedRead();
  }
  decodeMultiple(source, forEach) {
    let values, lastPosition = 0;
    try {
      let size = source.length;
      sequentialMode = true;
      let value = this ? this.decode(source, size) : defaultDecoder.decode(source, size);
      if (forEach) {
        if (forEach(value) === false) {
          return;
        }
        while (position < size) {
          lastPosition = position;
          if (forEach(checkedRead()) === false) {
            return;
          }
        }
      } else {
        values = [value];
        while (position < size) {
          lastPosition = position;
          values.push(checkedRead());
        }
        return values;
      }
    } catch (error) {
      error.lastPosition = lastPosition;
      error.values = values;
      throw error;
    } finally {
      sequentialMode = false;
      clearSource();
    }
  }
};
function checkedRead() {
  try {
    let result = read();
    if (bundledStrings) {
      if (position >= bundledStrings.postBundlePosition) {
        let error = new Error("Unexpected bundle position");
        error.incomplete = true;
        throw error;
      }
      position = bundledStrings.postBundlePosition;
      bundledStrings = null;
    }
    if (position == srcEnd) {
      currentStructures = null;
      src = null;
      if (referenceMap)
        referenceMap = null;
    } else if (position > srcEnd) {
      let error = new Error("Unexpected end of CBOR data");
      error.incomplete = true;
      throw error;
    } else if (!sequentialMode) {
      throw new Error("Data read, but end of buffer not reached");
    }
    return result;
  } catch (error) {
    clearSource();
    if (error instanceof RangeError || error.message.startsWith("Unexpected end of buffer")) {
      error.incomplete = true;
    }
    throw error;
  }
}
function read() {
  let token = src[position++];
  let majorType = token >> 5;
  token = token & 31;
  if (token > 23) {
    switch (token) {
      case 24:
        token = src[position++];
        break;
      case 25:
        if (majorType == 7) {
          return getFloat16();
        }
        token = dataView.getUint16(position);
        position += 2;
        break;
      case 26:
        if (majorType == 7) {
          let value = dataView.getFloat32(position);
          if (currentDecoder.useFloat32 > 2) {
            let multiplier = mult10[(src[position] & 127) << 1 | src[position + 1] >> 7];
            position += 4;
            return (multiplier * value + (value > 0 ? 0.5 : -0.5) >> 0) / multiplier;
          }
          position += 4;
          return value;
        }
        token = dataView.getUint32(position);
        position += 4;
        break;
      case 27:
        if (majorType == 7) {
          let value = dataView.getFloat64(position);
          position += 8;
          return value;
        }
        if (majorType > 1) {
          if (dataView.getUint32(position) > 0)
            throw new Error("JavaScript does not support arrays, maps, or strings with length over 4294967295");
          token = dataView.getUint32(position + 4);
        } else if (currentDecoder.int64AsNumber) {
          token = dataView.getUint32(position) * 4294967296;
          token += dataView.getUint32(position + 4);
        } else
          token = dataView.getBigUint64(position);
        position += 8;
        break;
      case 31:
        switch (majorType) {
          case 2:
          case 3:
            throw new Error("Indefinite length not supported for byte or text strings");
          case 4:
            let array = [];
            let value, i2 = 0;
            while ((value = read()) != STOP_CODE) {
              array[i2++] = value;
            }
            return majorType == 4 ? array : majorType == 3 ? array.join("") : Buffer.concat(array);
          case 5:
            let key;
            if (currentDecoder.mapsAsObjects) {
              let object = {};
              if (currentDecoder.keyMap)
                while ((key = read()) != STOP_CODE)
                  object[safeKey(currentDecoder.decodeKey(key))] = read();
              else
                while ((key = read()) != STOP_CODE)
                  object[safeKey(key)] = read();
              return object;
            } else {
              if (restoreMapsAsObject) {
                currentDecoder.mapsAsObjects = true;
                restoreMapsAsObject = false;
              }
              let map = /* @__PURE__ */ new Map();
              if (currentDecoder.keyMap)
                while ((key = read()) != STOP_CODE)
                  map.set(currentDecoder.decodeKey(key), read());
              else
                while ((key = read()) != STOP_CODE)
                  map.set(key, read());
              return map;
            }
          case 7:
            return STOP_CODE;
          default:
            throw new Error("Invalid major type for indefinite length " + majorType);
        }
      default:
        throw new Error("Unknown token " + token);
    }
  }
  switch (majorType) {
    case 0:
      return token;
    case 1:
      return ~token;
    case 2:
      return readBin(token);
    case 3:
      if (srcStringEnd >= position) {
        return srcString.slice(position - srcStringStart, (position += token) - srcStringStart);
      }
      if (srcStringEnd == 0 && srcEnd < 140 && token < 32) {
        let string = token < 16 ? shortStringInJS(token) : longStringInJS(token);
        if (string != null)
          return string;
      }
      return readFixedString(token);
    case 4:
      let array = new Array(token);
      for (let i2 = 0; i2 < token; i2++)
        array[i2] = read();
      return array;
    case 5:
      if (currentDecoder.mapsAsObjects) {
        let object = {};
        if (currentDecoder.keyMap)
          for (let i2 = 0; i2 < token; i2++)
            object[safeKey(currentDecoder.decodeKey(read()))] = read();
        else
          for (let i2 = 0; i2 < token; i2++)
            object[safeKey(read())] = read();
        return object;
      } else {
        if (restoreMapsAsObject) {
          currentDecoder.mapsAsObjects = true;
          restoreMapsAsObject = false;
        }
        let map = /* @__PURE__ */ new Map();
        if (currentDecoder.keyMap)
          for (let i2 = 0; i2 < token; i2++)
            map.set(currentDecoder.decodeKey(read()), read());
        else
          for (let i2 = 0; i2 < token; i2++)
            map.set(read(), read());
        return map;
      }
    case 6:
      if (token >= BUNDLED_STRINGS_ID) {
        let structure = currentStructures[token & 8191];
        if (structure) {
          if (!structure.read)
            structure.read = createStructureReader(structure);
          return structure.read();
        }
        if (token < 65536) {
          if (token == RECORD_INLINE_ID) {
            let length = readJustLength();
            let id = read();
            let structure2 = read();
            recordDefinition(id, structure2);
            let object = {};
            if (currentDecoder.keyMap)
              for (let i2 = 2; i2 < length; i2++) {
                let key = currentDecoder.decodeKey(structure2[i2 - 2]);
                object[safeKey(key)] = read();
              }
            else
              for (let i2 = 2; i2 < length; i2++) {
                let key = structure2[i2 - 2];
                object[safeKey(key)] = read();
              }
            return object;
          } else if (token == RECORD_DEFINITIONS_ID) {
            let length = readJustLength();
            let id = read();
            for (let i2 = 2; i2 < length; i2++) {
              recordDefinition(id++, read());
            }
            return read();
          } else if (token == BUNDLED_STRINGS_ID) {
            return readBundleExt();
          }
          if (currentDecoder.getShared) {
            loadShared();
            structure = currentStructures[token & 8191];
            if (structure) {
              if (!structure.read)
                structure.read = createStructureReader(structure);
              return structure.read();
            }
          }
        }
      }
      let extension = currentExtensions[token];
      if (extension) {
        if (extension.handlesRead)
          return extension(read);
        else
          return extension(read());
      } else {
        let input = read();
        for (let i2 = 0; i2 < currentExtensionRanges.length; i2++) {
          let value = currentExtensionRanges[i2](token, input);
          if (value !== void 0)
            return value;
        }
        return new Tag(input, token);
      }
    case 7:
      switch (token) {
        case 20:
          return false;
        case 21:
          return true;
        case 22:
          return null;
        case 23:
          return;
        case 31:
        default:
          let packedValue = (packedValues || getPackedValues())[token];
          if (packedValue !== void 0)
            return packedValue;
          throw new Error("Unknown token " + token);
      }
    default:
      if (isNaN(token)) {
        let error = new Error("Unexpected end of CBOR data");
        error.incomplete = true;
        throw error;
      }
      throw new Error("Unknown CBOR token " + token);
  }
}
var validName = /^[a-zA-Z_$][a-zA-Z\d_$]*$/;
function createStructureReader(structure) {
  function readObject() {
    let length = src[position++];
    length = length & 31;
    if (length > 23) {
      switch (length) {
        case 24:
          length = src[position++];
          break;
        case 25:
          length = dataView.getUint16(position);
          position += 2;
          break;
        case 26:
          length = dataView.getUint32(position);
          position += 4;
          break;
        default:
          throw new Error("Expected array header, but got " + src[position - 1]);
      }
    }
    let compiledReader = this.compiledReader;
    while (compiledReader) {
      if (compiledReader.propertyCount === length)
        return compiledReader(read);
      compiledReader = compiledReader.next;
    }
    if (this.slowReads++ >= inlineObjectReadThreshold) {
      let array = this.length == length ? this : this.slice(0, length);
      compiledReader = currentDecoder.keyMap ? new Function("r", "return {" + array.map((k4) => currentDecoder.decodeKey(k4)).map((k4) => validName.test(k4) ? safeKey(k4) + ":r()" : "[" + JSON.stringify(k4) + "]:r()").join(",") + "}") : new Function("r", "return {" + array.map((key) => validName.test(key) ? safeKey(key) + ":r()" : "[" + JSON.stringify(key) + "]:r()").join(",") + "}");
      if (this.compiledReader)
        compiledReader.next = this.compiledReader;
      compiledReader.propertyCount = length;
      this.compiledReader = compiledReader;
      return compiledReader(read);
    }
    let object = {};
    if (currentDecoder.keyMap)
      for (let i2 = 0; i2 < length; i2++)
        object[safeKey(currentDecoder.decodeKey(this[i2]))] = read();
    else
      for (let i2 = 0; i2 < length; i2++) {
        object[safeKey(this[i2])] = read();
      }
    return object;
  }
  structure.slowReads = 0;
  return readObject;
}
function safeKey(key) {
  return key === "__proto__" ? "__proto_" : key;
}
var readFixedString = readStringJS;
function readStringJS(length) {
  let result;
  if (length < 16) {
    if (result = shortStringInJS(length))
      return result;
  }
  if (length > 64 && decoder)
    return decoder.decode(src.subarray(position, position += length));
  const end = position + length;
  const units = [];
  result = "";
  while (position < end) {
    const byte1 = src[position++];
    if ((byte1 & 128) === 0) {
      units.push(byte1);
    } else if ((byte1 & 224) === 192) {
      const byte2 = src[position++] & 63;
      units.push((byte1 & 31) << 6 | byte2);
    } else if ((byte1 & 240) === 224) {
      const byte2 = src[position++] & 63;
      const byte3 = src[position++] & 63;
      units.push((byte1 & 31) << 12 | byte2 << 6 | byte3);
    } else if ((byte1 & 248) === 240) {
      const byte2 = src[position++] & 63;
      const byte3 = src[position++] & 63;
      const byte4 = src[position++] & 63;
      let unit = (byte1 & 7) << 18 | byte2 << 12 | byte3 << 6 | byte4;
      if (unit > 65535) {
        unit -= 65536;
        units.push(unit >>> 10 & 1023 | 55296);
        unit = 56320 | unit & 1023;
      }
      units.push(unit);
    } else {
      units.push(byte1);
    }
    if (units.length >= 4096) {
      result += fromCharCode.apply(String, units);
      units.length = 0;
    }
  }
  if (units.length > 0) {
    result += fromCharCode.apply(String, units);
  }
  return result;
}
var fromCharCode = String.fromCharCode;
function longStringInJS(length) {
  let start = position;
  let bytes = new Array(length);
  for (let i2 = 0; i2 < length; i2++) {
    const byte = src[position++];
    if ((byte & 128) > 0) {
      position = start;
      return;
    }
    bytes[i2] = byte;
  }
  return fromCharCode.apply(String, bytes);
}
function shortStringInJS(length) {
  if (length < 4) {
    if (length < 2) {
      if (length === 0)
        return "";
      else {
        let a3 = src[position++];
        if ((a3 & 128) > 1) {
          position -= 1;
          return;
        }
        return fromCharCode(a3);
      }
    } else {
      let a3 = src[position++];
      let b4 = src[position++];
      if ((a3 & 128) > 0 || (b4 & 128) > 0) {
        position -= 2;
        return;
      }
      if (length < 3)
        return fromCharCode(a3, b4);
      let c3 = src[position++];
      if ((c3 & 128) > 0) {
        position -= 3;
        return;
      }
      return fromCharCode(a3, b4, c3);
    }
  } else {
    let a3 = src[position++];
    let b4 = src[position++];
    let c3 = src[position++];
    let d3 = src[position++];
    if ((a3 & 128) > 0 || (b4 & 128) > 0 || (c3 & 128) > 0 || (d3 & 128) > 0) {
      position -= 4;
      return;
    }
    if (length < 6) {
      if (length === 4)
        return fromCharCode(a3, b4, c3, d3);
      else {
        let e = src[position++];
        if ((e & 128) > 0) {
          position -= 5;
          return;
        }
        return fromCharCode(a3, b4, c3, d3, e);
      }
    } else if (length < 8) {
      let e = src[position++];
      let f2 = src[position++];
      if ((e & 128) > 0 || (f2 & 128) > 0) {
        position -= 6;
        return;
      }
      if (length < 7)
        return fromCharCode(a3, b4, c3, d3, e, f2);
      let g4 = src[position++];
      if ((g4 & 128) > 0) {
        position -= 7;
        return;
      }
      return fromCharCode(a3, b4, c3, d3, e, f2, g4);
    } else {
      let e = src[position++];
      let f2 = src[position++];
      let g4 = src[position++];
      let h3 = src[position++];
      if ((e & 128) > 0 || (f2 & 128) > 0 || (g4 & 128) > 0 || (h3 & 128) > 0) {
        position -= 8;
        return;
      }
      if (length < 10) {
        if (length === 8)
          return fromCharCode(a3, b4, c3, d3, e, f2, g4, h3);
        else {
          let i2 = src[position++];
          if ((i2 & 128) > 0) {
            position -= 9;
            return;
          }
          return fromCharCode(a3, b4, c3, d3, e, f2, g4, h3, i2);
        }
      } else if (length < 12) {
        let i2 = src[position++];
        let j4 = src[position++];
        if ((i2 & 128) > 0 || (j4 & 128) > 0) {
          position -= 10;
          return;
        }
        if (length < 11)
          return fromCharCode(a3, b4, c3, d3, e, f2, g4, h3, i2, j4);
        let k4 = src[position++];
        if ((k4 & 128) > 0) {
          position -= 11;
          return;
        }
        return fromCharCode(a3, b4, c3, d3, e, f2, g4, h3, i2, j4, k4);
      } else {
        let i2 = src[position++];
        let j4 = src[position++];
        let k4 = src[position++];
        let l2 = src[position++];
        if ((i2 & 128) > 0 || (j4 & 128) > 0 || (k4 & 128) > 0 || (l2 & 128) > 0) {
          position -= 12;
          return;
        }
        if (length < 14) {
          if (length === 12)
            return fromCharCode(a3, b4, c3, d3, e, f2, g4, h3, i2, j4, k4, l2);
          else {
            let m4 = src[position++];
            if ((m4 & 128) > 0) {
              position -= 13;
              return;
            }
            return fromCharCode(a3, b4, c3, d3, e, f2, g4, h3, i2, j4, k4, l2, m4);
          }
        } else {
          let m4 = src[position++];
          let n2 = src[position++];
          if ((m4 & 128) > 0 || (n2 & 128) > 0) {
            position -= 14;
            return;
          }
          if (length < 15)
            return fromCharCode(a3, b4, c3, d3, e, f2, g4, h3, i2, j4, k4, l2, m4, n2);
          let o = src[position++];
          if ((o & 128) > 0) {
            position -= 15;
            return;
          }
          return fromCharCode(a3, b4, c3, d3, e, f2, g4, h3, i2, j4, k4, l2, m4, n2, o);
        }
      }
    }
  }
}
function readBin(length) {
  return currentDecoder.copyBuffers ? (
    // specifically use the copying slice (not the node one)
    Uint8Array.prototype.slice.call(src, position, position += length)
  ) : src.subarray(position, position += length);
}
var f32Array = new Float32Array(1);
var u8Array = new Uint8Array(f32Array.buffer, 0, 4);
function getFloat16() {
  let byte0 = src[position++];
  let byte1 = src[position++];
  let exponent = (byte0 & 127) >> 2;
  if (exponent === 31) {
    if (byte1 || byte0 & 3)
      return NaN;
    return byte0 & 128 ? -Infinity : Infinity;
  }
  if (exponent === 0) {
    let abs = ((byte0 & 3) << 8 | byte1) / (1 << 24);
    return byte0 & 128 ? -abs : abs;
  }
  u8Array[3] = byte0 & 128 | // sign bit
  (exponent >> 1) + 56;
  u8Array[2] = (byte0 & 7) << 5 | // last exponent bit and first two mantissa bits
  byte1 >> 3;
  u8Array[1] = byte1 << 5;
  u8Array[0] = 0;
  return f32Array[0];
}
var keyCache = new Array(4096);
var Tag = class {
  constructor(value, tag) {
    this.value = value;
    this.tag = tag;
  }
};
currentExtensions[0] = (dateString) => {
  return new Date(dateString);
};
currentExtensions[1] = (epochSec) => {
  return new Date(Math.round(epochSec * 1e3));
};
currentExtensions[2] = (buffer) => {
  let value = BigInt(0);
  for (let i2 = 0, l2 = buffer.byteLength; i2 < l2; i2++) {
    value = BigInt(buffer[i2]) + value << BigInt(8);
  }
  return value;
};
currentExtensions[3] = (buffer) => {
  return BigInt(-1) - currentExtensions[2](buffer);
};
currentExtensions[4] = (fraction) => {
  return +(fraction[1] + "e" + fraction[0]);
};
currentExtensions[5] = (fraction) => {
  return fraction[1] * Math.exp(fraction[0] * Math.log(2));
};
var recordDefinition = (id, structure) => {
  id = id - 57344;
  let existingStructure = currentStructures[id];
  if (existingStructure && existingStructure.isShared) {
    (currentStructures.restoreStructures || (currentStructures.restoreStructures = []))[id] = existingStructure;
  }
  currentStructures[id] = structure;
  structure.read = createStructureReader(structure);
};
currentExtensions[LEGACY_RECORD_INLINE_ID] = (data) => {
  let length = data.length;
  let structure = data[1];
  recordDefinition(data[0], structure);
  let object = {};
  for (let i2 = 2; i2 < length; i2++) {
    let key = structure[i2 - 2];
    object[safeKey(key)] = data[i2];
  }
  return object;
};
currentExtensions[14] = (value) => {
  if (bundledStrings)
    return bundledStrings[0].slice(bundledStrings.position0, bundledStrings.position0 += value);
  return new Tag(value, 14);
};
currentExtensions[15] = (value) => {
  if (bundledStrings)
    return bundledStrings[1].slice(bundledStrings.position1, bundledStrings.position1 += value);
  return new Tag(value, 15);
};
var glbl = { Error, RegExp };
currentExtensions[27] = (data) => {
  return (glbl[data[0]] || Error)(data[1], data[2]);
};
var packedTable = (read2) => {
  if (src[position++] != 132)
    throw new Error("Packed values structure must be followed by a 4 element array");
  let newPackedValues = read2();
  packedValues = packedValues ? newPackedValues.concat(packedValues.slice(newPackedValues.length)) : newPackedValues;
  packedValues.prefixes = read2();
  packedValues.suffixes = read2();
  return read2();
};
packedTable.handlesRead = true;
currentExtensions[51] = packedTable;
currentExtensions[PACKED_REFERENCE_TAG_ID] = (data) => {
  if (!packedValues) {
    if (currentDecoder.getShared)
      loadShared();
    else
      return new Tag(data, PACKED_REFERENCE_TAG_ID);
  }
  if (typeof data == "number")
    return packedValues[16 + (data >= 0 ? 2 * data : -2 * data - 1)];
  throw new Error("No support for non-integer packed references yet");
};
currentExtensions[28] = (read2) => {
  if (!referenceMap) {
    referenceMap = /* @__PURE__ */ new Map();
    referenceMap.id = 0;
  }
  let id = referenceMap.id++;
  let token = src[position];
  let target2;
  if (token >> 5 == 4)
    target2 = [];
  else
    target2 = {};
  let refEntry = { target: target2 };
  referenceMap.set(id, refEntry);
  let targetProperties = read2();
  if (refEntry.used)
    return Object.assign(target2, targetProperties);
  refEntry.target = targetProperties;
  return targetProperties;
};
currentExtensions[28].handlesRead = true;
currentExtensions[29] = (id) => {
  let refEntry = referenceMap.get(id);
  refEntry.used = true;
  return refEntry.target;
};
currentExtensions[258] = (array) => new Set(array);
(currentExtensions[259] = (read2) => {
  if (currentDecoder.mapsAsObjects) {
    currentDecoder.mapsAsObjects = false;
    restoreMapsAsObject = true;
  }
  return read2();
}).handlesRead = true;
function combine(a3, b4) {
  if (typeof a3 === "string")
    return a3 + b4;
  if (a3 instanceof Array)
    return a3.concat(b4);
  return Object.assign({}, a3, b4);
}
function getPackedValues() {
  if (!packedValues) {
    if (currentDecoder.getShared)
      loadShared();
    else
      throw new Error("No packed values available");
  }
  return packedValues;
}
var SHARED_DATA_TAG_ID = 1399353956;
currentExtensionRanges.push((tag, input) => {
  if (tag >= 225 && tag <= 255)
    return combine(getPackedValues().prefixes[tag - 224], input);
  if (tag >= 28704 && tag <= 32767)
    return combine(getPackedValues().prefixes[tag - 28672], input);
  if (tag >= 1879052288 && tag <= 2147483647)
    return combine(getPackedValues().prefixes[tag - 1879048192], input);
  if (tag >= 216 && tag <= 223)
    return combine(input, getPackedValues().suffixes[tag - 216]);
  if (tag >= 27647 && tag <= 28671)
    return combine(input, getPackedValues().suffixes[tag - 27639]);
  if (tag >= 1811940352 && tag <= 1879048191)
    return combine(input, getPackedValues().suffixes[tag - 1811939328]);
  if (tag == SHARED_DATA_TAG_ID) {
    return {
      packedValues,
      structures: currentStructures.slice(0),
      version: input
    };
  }
  if (tag == 55799)
    return input;
});
var isLittleEndianMachine = new Uint8Array(new Uint16Array([1]).buffer)[0] == 1;
var typedArrays = [
  Uint8Array,
  Uint8ClampedArray,
  Uint16Array,
  Uint32Array,
  typeof BigUint64Array == "undefined" ? { name: "BigUint64Array" } : BigUint64Array,
  Int8Array,
  Int16Array,
  Int32Array,
  typeof BigInt64Array == "undefined" ? { name: "BigInt64Array" } : BigInt64Array,
  Float32Array,
  Float64Array
];
var typedArrayTags = [64, 68, 69, 70, 71, 72, 77, 78, 79, 85, 86];
for (let i2 = 0; i2 < typedArrays.length; i2++) {
  registerTypedArray(typedArrays[i2], typedArrayTags[i2]);
}
function registerTypedArray(TypedArray, tag) {
  let dvMethod = "get" + TypedArray.name.slice(0, -5);
  let bytesPerElement;
  if (typeof TypedArray === "function")
    bytesPerElement = TypedArray.BYTES_PER_ELEMENT;
  else
    TypedArray = null;
  for (let littleEndian = 0; littleEndian < 2; littleEndian++) {
    if (!littleEndian && bytesPerElement == 1)
      continue;
    let sizeShift = bytesPerElement == 2 ? 1 : bytesPerElement == 4 ? 2 : 3;
    currentExtensions[littleEndian ? tag : tag - 4] = bytesPerElement == 1 || littleEndian == isLittleEndianMachine ? (buffer) => {
      if (!TypedArray)
        throw new Error("Could not find typed array for code " + tag);
      return new TypedArray(Uint8Array.prototype.slice.call(buffer, 0).buffer);
    } : (buffer) => {
      if (!TypedArray)
        throw new Error("Could not find typed array for code " + tag);
      let dv = new DataView(buffer.buffer, buffer.byteOffset, buffer.byteLength);
      let elements = buffer.length >> sizeShift;
      let ta = new TypedArray(elements);
      let method = dv[dvMethod];
      for (let i2 = 0; i2 < elements; i2++) {
        ta[i2] = method.call(dv, i2 << sizeShift, littleEndian);
      }
      return ta;
    };
  }
}
function readBundleExt() {
  let length = readJustLength();
  let bundlePosition = position + read();
  for (let i2 = 2; i2 < length; i2++) {
    let bundleLength = readJustLength();
    position += bundleLength;
  }
  let dataPosition = position;
  position = bundlePosition;
  bundledStrings = [readStringJS(readJustLength()), readStringJS(readJustLength())];
  bundledStrings.position0 = 0;
  bundledStrings.position1 = 0;
  bundledStrings.postBundlePosition = position;
  position = dataPosition;
  return read();
}
function readJustLength() {
  let token = src[position++] & 31;
  if (token > 23) {
    switch (token) {
      case 24:
        token = src[position++];
        break;
      case 25:
        token = dataView.getUint16(position);
        position += 2;
        break;
      case 26:
        token = dataView.getUint32(position);
        position += 4;
        break;
    }
  }
  return token;
}
function loadShared() {
  if (currentDecoder.getShared) {
    let sharedData = saveState(() => {
      src = null;
      return currentDecoder.getShared();
    }) || {};
    let updatedStructures = sharedData.structures || [];
    currentDecoder.sharedVersion = sharedData.version;
    packedValues = currentDecoder.sharedValues = sharedData.packedValues;
    if (currentStructures === true)
      currentDecoder.structures = currentStructures = updatedStructures;
    else
      currentStructures.splice.apply(currentStructures, [0, updatedStructures.length].concat(updatedStructures));
  }
}
function saveState(callback) {
  let savedSrcEnd = srcEnd;
  let savedPosition = position;
  let savedStringPosition = stringPosition;
  let savedSrcStringStart = srcStringStart;
  let savedSrcStringEnd = srcStringEnd;
  let savedSrcString = srcString;
  let savedStrings = strings;
  let savedReferenceMap = referenceMap;
  let savedBundledStrings = bundledStrings;
  let savedSrc = new Uint8Array(src.slice(0, srcEnd));
  let savedStructures = currentStructures;
  let savedDecoder = currentDecoder;
  let savedSequentialMode = sequentialMode;
  let value = callback();
  srcEnd = savedSrcEnd;
  position = savedPosition;
  stringPosition = savedStringPosition;
  srcStringStart = savedSrcStringStart;
  srcStringEnd = savedSrcStringEnd;
  srcString = savedSrcString;
  strings = savedStrings;
  referenceMap = savedReferenceMap;
  bundledStrings = savedBundledStrings;
  src = savedSrc;
  sequentialMode = savedSequentialMode;
  currentStructures = savedStructures;
  currentDecoder = savedDecoder;
  dataView = new DataView(src.buffer, src.byteOffset, src.byteLength);
  return value;
}
function clearSource() {
  src = null;
  referenceMap = null;
  currentStructures = null;
}
var mult10 = new Array(147);
for (let i2 = 0; i2 < 256; i2++) {
  mult10[i2] = +("1e" + Math.floor(45.15 - i2 * 0.30103));
}
var defaultDecoder = new Decoder({ useRecords: false });
var decode = defaultDecoder.decode;
var decodeMultiple = defaultDecoder.decodeMultiple;
var FLOAT32_OPTIONS = {
  NEVER: 0,
  ALWAYS: 1,
  DECIMAL_ROUND: 3,
  DECIMAL_FIT: 4
};

// https://deno.land/x/cbor@v1.5.4/encode.js
var textEncoder2;
try {
  textEncoder2 = new TextEncoder();
} catch (error) {
}
var extensions;
var extensionClasses;
var Buffer2 = typeof globalThis === "object" && globalThis.Buffer;
var hasNodeBuffer = typeof Buffer2 !== "undefined";
var ByteArrayAllocate = hasNodeBuffer ? Buffer2.allocUnsafeSlow : Uint8Array;
var ByteArray = hasNodeBuffer ? Buffer2 : Uint8Array;
var MAX_STRUCTURES = 256;
var MAX_BUFFER_SIZE = hasNodeBuffer ? 4294967296 : 2144337920;
var throwOnIterable;
var target;
var targetView;
var position2 = 0;
var safeEnd;
var bundledStrings2 = null;
var MAX_BUNDLE_SIZE = 61440;
var hasNonLatin = /[\u0080-\uFFFF]/;
var RECORD_SYMBOL = Symbol("record-id");
var Encoder = class extends Decoder {
  constructor(options) {
    super(options);
    this.offset = 0;
    let typeBuffer;
    let start;
    let sharedStructures;
    let hasSharedUpdate;
    let structures;
    let referenceMap2;
    options = options || {};
    let encodeUtf8 = ByteArray.prototype.utf8Write ? function(string, position3, maxBytes) {
      return target.utf8Write(string, position3, maxBytes);
    } : textEncoder2 && textEncoder2.encodeInto ? function(string, position3) {
      return textEncoder2.encodeInto(string, target.subarray(position3)).written;
    } : false;
    let encoder = this;
    let hasSharedStructures = options.structures || options.saveStructures;
    let maxSharedStructures = options.maxSharedStructures;
    if (maxSharedStructures == null)
      maxSharedStructures = hasSharedStructures ? 128 : 0;
    if (maxSharedStructures > 8190)
      throw new Error("Maximum maxSharedStructure is 8190");
    let isSequential = options.sequential;
    if (isSequential) {
      maxSharedStructures = 0;
    }
    if (!this.structures)
      this.structures = [];
    if (this.saveStructures)
      this.saveShared = this.saveStructures;
    let samplingPackedValues, packedObjectMap2, sharedValues = options.sharedValues;
    let sharedPackedObjectMap2;
    if (sharedValues) {
      sharedPackedObjectMap2 = /* @__PURE__ */ Object.create(null);
      for (let i2 = 0, l2 = sharedValues.length; i2 < l2; i2++) {
        sharedPackedObjectMap2[sharedValues[i2]] = i2;
      }
    }
    let recordIdsToRemove = [];
    let transitionsCount = 0;
    let serializationsSinceTransitionRebuild = 0;
    this.mapEncode = function(value, encodeOptions) {
      if (this._keyMap && !this._mapped) {
        switch (value.constructor.name) {
          case "Array":
            value = value.map((r) => this.encodeKeys(r));
            break;
        }
      }
      return this.encode(value, encodeOptions);
    };
    this.encode = function(value, encodeOptions) {
      if (!target) {
        target = new ByteArrayAllocate(8192);
        targetView = new DataView(target.buffer, 0, 8192);
        position2 = 0;
      }
      safeEnd = target.length - 10;
      if (safeEnd - position2 < 2048) {
        target = new ByteArrayAllocate(target.length);
        targetView = new DataView(target.buffer, 0, target.length);
        safeEnd = target.length - 10;
        position2 = 0;
      } else if (encodeOptions === REUSE_BUFFER_MODE)
        position2 = position2 + 7 & 2147483640;
      start = position2;
      if (encoder.useSelfDescribedHeader) {
        targetView.setUint32(position2, 3654940416);
        position2 += 3;
      }
      referenceMap2 = encoder.structuredClone ? /* @__PURE__ */ new Map() : null;
      if (encoder.bundleStrings && typeof value !== "string") {
        bundledStrings2 = [];
        bundledStrings2.size = Infinity;
      } else
        bundledStrings2 = null;
      sharedStructures = encoder.structures;
      if (sharedStructures) {
        if (sharedStructures.uninitialized) {
          let sharedData = encoder.getShared() || {};
          encoder.structures = sharedStructures = sharedData.structures || [];
          encoder.sharedVersion = sharedData.version;
          let sharedValues2 = encoder.sharedValues = sharedData.packedValues;
          if (sharedValues2) {
            sharedPackedObjectMap2 = {};
            for (let i2 = 0, l2 = sharedValues2.length; i2 < l2; i2++)
              sharedPackedObjectMap2[sharedValues2[i2]] = i2;
          }
        }
        let sharedStructuresLength = sharedStructures.length;
        if (sharedStructuresLength > maxSharedStructures && !isSequential)
          sharedStructuresLength = maxSharedStructures;
        if (!sharedStructures.transitions) {
          sharedStructures.transitions = /* @__PURE__ */ Object.create(null);
          for (let i2 = 0; i2 < sharedStructuresLength; i2++) {
            let keys = sharedStructures[i2];
            if (!keys)
              continue;
            let nextTransition, transition = sharedStructures.transitions;
            for (let j4 = 0, l2 = keys.length; j4 < l2; j4++) {
              if (transition[RECORD_SYMBOL] === void 0)
                transition[RECORD_SYMBOL] = i2;
              let key = keys[j4];
              nextTransition = transition[key];
              if (!nextTransition) {
                nextTransition = transition[key] = /* @__PURE__ */ Object.create(null);
              }
              transition = nextTransition;
            }
            transition[RECORD_SYMBOL] = i2 | 1048576;
          }
        }
        if (!isSequential)
          sharedStructures.nextId = sharedStructuresLength;
      }
      if (hasSharedUpdate)
        hasSharedUpdate = false;
      structures = sharedStructures || [];
      packedObjectMap2 = sharedPackedObjectMap2;
      if (options.pack) {
        let packedValues2 = /* @__PURE__ */ new Map();
        packedValues2.values = [];
        packedValues2.encoder = encoder;
        packedValues2.maxValues = options.maxPrivatePackedValues || (sharedPackedObjectMap2 ? 16 : Infinity);
        packedValues2.objectMap = sharedPackedObjectMap2 || false;
        packedValues2.samplingPackedValues = samplingPackedValues;
        findRepetitiveStrings(value, packedValues2);
        if (packedValues2.values.length > 0) {
          target[position2++] = 216;
          target[position2++] = 51;
          writeArrayHeader(4);
          let valuesArray = packedValues2.values;
          encode2(valuesArray);
          writeArrayHeader(0);
          writeArrayHeader(0);
          packedObjectMap2 = Object.create(sharedPackedObjectMap2 || null);
          for (let i2 = 0, l2 = valuesArray.length; i2 < l2; i2++) {
            packedObjectMap2[valuesArray[i2]] = i2;
          }
        }
      }
      throwOnIterable = encodeOptions & THROW_ON_ITERABLE;
      try {
        if (throwOnIterable)
          return;
        encode2(value);
        if (bundledStrings2) {
          writeBundles(start, encode2);
        }
        encoder.offset = position2;
        if (referenceMap2 && referenceMap2.idsToInsert) {
          position2 += referenceMap2.idsToInsert.length * 2;
          if (position2 > safeEnd)
            makeRoom(position2);
          encoder.offset = position2;
          let serialized = insertIds(target.subarray(start, position2), referenceMap2.idsToInsert);
          referenceMap2 = null;
          return serialized;
        }
        if (encodeOptions & REUSE_BUFFER_MODE) {
          target.start = start;
          target.end = position2;
          return target;
        }
        return target.subarray(start, position2);
      } finally {
        if (sharedStructures) {
          if (serializationsSinceTransitionRebuild < 10)
            serializationsSinceTransitionRebuild++;
          if (sharedStructures.length > maxSharedStructures)
            sharedStructures.length = maxSharedStructures;
          if (transitionsCount > 1e4) {
            sharedStructures.transitions = null;
            serializationsSinceTransitionRebuild = 0;
            transitionsCount = 0;
            if (recordIdsToRemove.length > 0)
              recordIdsToRemove = [];
          } else if (recordIdsToRemove.length > 0 && !isSequential) {
            for (let i2 = 0, l2 = recordIdsToRemove.length; i2 < l2; i2++) {
              recordIdsToRemove[i2][RECORD_SYMBOL] = void 0;
            }
            recordIdsToRemove = [];
          }
        }
        if (hasSharedUpdate && encoder.saveShared) {
          if (encoder.structures.length > maxSharedStructures) {
            encoder.structures = encoder.structures.slice(0, maxSharedStructures);
          }
          let returnBuffer = target.subarray(start, position2);
          if (encoder.updateSharedData() === false)
            return encoder.encode(value);
          return returnBuffer;
        }
        if (encodeOptions & RESET_BUFFER_MODE)
          position2 = start;
      }
    };
    this.findCommonStringsToPack = () => {
      samplingPackedValues = /* @__PURE__ */ new Map();
      if (!sharedPackedObjectMap2)
        sharedPackedObjectMap2 = /* @__PURE__ */ Object.create(null);
      return (options2) => {
        let threshold = options2 && options2.threshold || 4;
        let position3 = this.pack ? options2.maxPrivatePackedValues || 16 : 0;
        if (!sharedValues)
          sharedValues = this.sharedValues = [];
        for (let [key, status] of samplingPackedValues) {
          if (status.count > threshold) {
            sharedPackedObjectMap2[key] = position3++;
            sharedValues.push(key);
            hasSharedUpdate = true;
          }
        }
        while (this.saveShared && this.updateSharedData() === false) {
        }
        samplingPackedValues = null;
      };
    };
    const encode2 = (value) => {
      if (position2 > safeEnd)
        target = makeRoom(position2);
      var type = typeof value;
      var length;
      if (type === "string") {
        if (packedObjectMap2) {
          let packedPosition = packedObjectMap2[value];
          if (packedPosition >= 0) {
            if (packedPosition < 16)
              target[position2++] = packedPosition + 224;
            else {
              target[position2++] = 198;
              if (packedPosition & 1)
                encode2(15 - packedPosition >> 1);
              else
                encode2(packedPosition - 16 >> 1);
            }
            return;
          } else if (samplingPackedValues && !options.pack) {
            let status = samplingPackedValues.get(value);
            if (status)
              status.count++;
            else
              samplingPackedValues.set(value, {
                count: 1
              });
          }
        }
        let strLength = value.length;
        if (bundledStrings2 && strLength >= 4 && strLength < 1024) {
          if ((bundledStrings2.size += strLength) > MAX_BUNDLE_SIZE) {
            let extStart;
            let maxBytes2 = (bundledStrings2[0] ? bundledStrings2[0].length * 3 + bundledStrings2[1].length : 0) + 10;
            if (position2 + maxBytes2 > safeEnd)
              target = makeRoom(position2 + maxBytes2);
            target[position2++] = 217;
            target[position2++] = 223;
            target[position2++] = 249;
            target[position2++] = bundledStrings2.position ? 132 : 130;
            target[position2++] = 26;
            extStart = position2 - start;
            position2 += 4;
            if (bundledStrings2.position) {
              writeBundles(start, encode2);
            }
            bundledStrings2 = ["", ""];
            bundledStrings2.size = 0;
            bundledStrings2.position = extStart;
          }
          let twoByte = hasNonLatin.test(value);
          bundledStrings2[twoByte ? 0 : 1] += value;
          target[position2++] = twoByte ? 206 : 207;
          encode2(strLength);
          return;
        }
        let headerSize;
        if (strLength < 32) {
          headerSize = 1;
        } else if (strLength < 256) {
          headerSize = 2;
        } else if (strLength < 65536) {
          headerSize = 3;
        } else {
          headerSize = 5;
        }
        let maxBytes = strLength * 3;
        if (position2 + maxBytes > safeEnd)
          target = makeRoom(position2 + maxBytes);
        if (strLength < 64 || !encodeUtf8) {
          let i2, c1, c22, strPosition = position2 + headerSize;
          for (i2 = 0; i2 < strLength; i2++) {
            c1 = value.charCodeAt(i2);
            if (c1 < 128) {
              target[strPosition++] = c1;
            } else if (c1 < 2048) {
              target[strPosition++] = c1 >> 6 | 192;
              target[strPosition++] = c1 & 63 | 128;
            } else if ((c1 & 64512) === 55296 && ((c22 = value.charCodeAt(i2 + 1)) & 64512) === 56320) {
              c1 = 65536 + ((c1 & 1023) << 10) + (c22 & 1023);
              i2++;
              target[strPosition++] = c1 >> 18 | 240;
              target[strPosition++] = c1 >> 12 & 63 | 128;
              target[strPosition++] = c1 >> 6 & 63 | 128;
              target[strPosition++] = c1 & 63 | 128;
            } else {
              target[strPosition++] = c1 >> 12 | 224;
              target[strPosition++] = c1 >> 6 & 63 | 128;
              target[strPosition++] = c1 & 63 | 128;
            }
          }
          length = strPosition - position2 - headerSize;
        } else {
          length = encodeUtf8(value, position2 + headerSize, maxBytes);
        }
        if (length < 24) {
          target[position2++] = 96 | length;
        } else if (length < 256) {
          if (headerSize < 2) {
            target.copyWithin(position2 + 2, position2 + 1, position2 + 1 + length);
          }
          target[position2++] = 120;
          target[position2++] = length;
        } else if (length < 65536) {
          if (headerSize < 3) {
            target.copyWithin(position2 + 3, position2 + 2, position2 + 2 + length);
          }
          target[position2++] = 121;
          target[position2++] = length >> 8;
          target[position2++] = length & 255;
        } else {
          if (headerSize < 5) {
            target.copyWithin(position2 + 5, position2 + 3, position2 + 3 + length);
          }
          target[position2++] = 122;
          targetView.setUint32(position2, length);
          position2 += 4;
        }
        position2 += length;
      } else if (type === "number") {
        if (!this.alwaysUseFloat && value >>> 0 === value) {
          if (value < 24) {
            target[position2++] = value;
          } else if (value < 256) {
            target[position2++] = 24;
            target[position2++] = value;
          } else if (value < 65536) {
            target[position2++] = 25;
            target[position2++] = value >> 8;
            target[position2++] = value & 255;
          } else {
            target[position2++] = 26;
            targetView.setUint32(position2, value);
            position2 += 4;
          }
        } else if (!this.alwaysUseFloat && value >> 0 === value) {
          if (value >= -24) {
            target[position2++] = 31 - value;
          } else if (value >= -256) {
            target[position2++] = 56;
            target[position2++] = ~value;
          } else if (value >= -65536) {
            target[position2++] = 57;
            targetView.setUint16(position2, ~value);
            position2 += 2;
          } else {
            target[position2++] = 58;
            targetView.setUint32(position2, ~value);
            position2 += 4;
          }
        } else {
          let useFloat32;
          if ((useFloat32 = this.useFloat32) > 0 && value < 4294967296 && value >= -2147483648) {
            target[position2++] = 250;
            targetView.setFloat32(position2, value);
            let xShifted;
            if (useFloat32 < 4 || // this checks for rounding of numbers that were encoded in 32-bit float to nearest significant decimal digit that could be preserved
            (xShifted = value * mult10[(target[position2] & 127) << 1 | target[position2 + 1] >> 7]) >> 0 === xShifted) {
              position2 += 4;
              return;
            } else
              position2--;
          }
          target[position2++] = 251;
          targetView.setFloat64(position2, value);
          position2 += 8;
        }
      } else if (type === "object") {
        if (!value)
          target[position2++] = 246;
        else {
          if (referenceMap2) {
            let referee = referenceMap2.get(value);
            if (referee) {
              target[position2++] = 216;
              target[position2++] = 29;
              target[position2++] = 25;
              if (!referee.references) {
                let idsToInsert = referenceMap2.idsToInsert || (referenceMap2.idsToInsert = []);
                referee.references = [];
                idsToInsert.push(referee);
              }
              referee.references.push(position2 - start);
              position2 += 2;
              return;
            } else
              referenceMap2.set(value, { offset: position2 - start });
          }
          let constructor = value.constructor;
          if (constructor === Object) {
            writeObject(value, true);
          } else if (constructor === Array) {
            length = value.length;
            if (length < 24) {
              target[position2++] = 128 | length;
            } else {
              writeArrayHeader(length);
            }
            for (let i2 = 0; i2 < length; i2++) {
              encode2(value[i2]);
            }
          } else if (constructor === Map) {
            if (this.mapsAsObjects ? this.useTag259ForMaps !== false : this.useTag259ForMaps) {
              target[position2++] = 217;
              target[position2++] = 1;
              target[position2++] = 3;
            }
            length = value.size;
            if (length < 24) {
              target[position2++] = 160 | length;
            } else if (length < 256) {
              target[position2++] = 184;
              target[position2++] = length;
            } else if (length < 65536) {
              target[position2++] = 185;
              target[position2++] = length >> 8;
              target[position2++] = length & 255;
            } else {
              target[position2++] = 186;
              targetView.setUint32(position2, length);
              position2 += 4;
            }
            if (encoder.keyMap) {
              for (let [key, entryValue] of value) {
                encode2(encoder.encodeKey(key));
                encode2(entryValue);
              }
            } else {
              for (let [key, entryValue] of value) {
                encode2(key);
                encode2(entryValue);
              }
            }
          } else {
            for (let i2 = 0, l2 = extensions.length; i2 < l2; i2++) {
              let extensionClass = extensionClasses[i2];
              if (value instanceof extensionClass) {
                let extension = extensions[i2];
                let tag = extension.tag;
                if (tag == void 0)
                  tag = extension.getTag && extension.getTag.call(this, value);
                if (tag < 24) {
                  target[position2++] = 192 | tag;
                } else if (tag < 256) {
                  target[position2++] = 216;
                  target[position2++] = tag;
                } else if (tag < 65536) {
                  target[position2++] = 217;
                  target[position2++] = tag >> 8;
                  target[position2++] = tag & 255;
                } else if (tag > -1) {
                  target[position2++] = 218;
                  targetView.setUint32(position2, tag);
                  position2 += 4;
                }
                extension.encode.call(this, value, encode2, makeRoom);
                return;
              }
            }
            if (value[Symbol.iterator]) {
              if (throwOnIterable) {
                let error = new Error("Iterable should be serialized as iterator");
                error.iteratorNotHandled = true;
                throw error;
              }
              target[position2++] = 159;
              for (let entry of value) {
                encode2(entry);
              }
              target[position2++] = 255;
              return;
            }
            if (value[Symbol.asyncIterator] || isBlob(value)) {
              let error = new Error("Iterable/blob should be serialized as iterator");
              error.iteratorNotHandled = true;
              throw error;
            }
            if (this.useToJSON && value.toJSON) {
              const json = value.toJSON();
              if (json !== value)
                return encode2(json);
            }
            writeObject(value, !value.hasOwnProperty);
          }
        }
      } else if (type === "boolean") {
        target[position2++] = value ? 245 : 244;
      } else if (type === "bigint") {
        if (value < BigInt(1) << BigInt(64) && value >= 0) {
          target[position2++] = 27;
          targetView.setBigUint64(position2, value);
        } else if (value > -(BigInt(1) << BigInt(64)) && value < 0) {
          target[position2++] = 59;
          targetView.setBigUint64(position2, -value - BigInt(1));
        } else {
          if (this.largeBigIntToFloat) {
            target[position2++] = 251;
            targetView.setFloat64(position2, Number(value));
          } else {
            throw new RangeError(value + " was too large to fit in CBOR 64-bit integer format, set largeBigIntToFloat to convert to float-64");
          }
        }
        position2 += 8;
      } else if (type === "undefined") {
        target[position2++] = 247;
      } else {
        throw new Error("Unknown type: " + type);
      }
    };
    const writeObject = this.useRecords === false ? this.variableMapSize ? (object) => {
      let keys = Object.keys(object);
      let vals = Object.values(object);
      let length = keys.length;
      if (length < 24) {
        target[position2++] = 160 | length;
      } else if (length < 256) {
        target[position2++] = 184;
        target[position2++] = length;
      } else if (length < 65536) {
        target[position2++] = 185;
        target[position2++] = length >> 8;
        target[position2++] = length & 255;
      } else {
        target[position2++] = 186;
        targetView.setUint32(position2, length);
        position2 += 4;
      }
      let key;
      if (encoder.keyMap) {
        for (let i2 = 0; i2 < length; i2++) {
          encode2(encoder.encodeKey(keys[i2]));
          encode2(vals[i2]);
        }
      } else {
        for (let i2 = 0; i2 < length; i2++) {
          encode2(keys[i2]);
          encode2(vals[i2]);
        }
      }
    } : (object, safePrototype) => {
      target[position2++] = 185;
      let objectOffset = position2 - start;
      position2 += 2;
      let size = 0;
      if (encoder.keyMap) {
        for (let key in object)
          if (safePrototype || object.hasOwnProperty(key)) {
            encode2(encoder.encodeKey(key));
            encode2(object[key]);
            size++;
          }
      } else {
        for (let key in object)
          if (safePrototype || object.hasOwnProperty(key)) {
            encode2(key);
            encode2(object[key]);
            size++;
          }
      }
      target[objectOffset++ + start] = size >> 8;
      target[objectOffset + start] = size & 255;
    } : (object, safePrototype) => {
      let nextTransition, transition = structures.transitions || (structures.transitions = /* @__PURE__ */ Object.create(null));
      let newTransitions = 0;
      let length = 0;
      let parentRecordId;
      let keys;
      if (this.keyMap) {
        keys = Object.keys(object).map((k4) => this.encodeKey(k4));
        length = keys.length;
        for (let i2 = 0; i2 < length; i2++) {
          let key = keys[i2];
          nextTransition = transition[key];
          if (!nextTransition) {
            nextTransition = transition[key] = /* @__PURE__ */ Object.create(null);
            newTransitions++;
          }
          transition = nextTransition;
        }
      } else {
        for (let key in object)
          if (safePrototype || object.hasOwnProperty(key)) {
            nextTransition = transition[key];
            if (!nextTransition) {
              if (transition[RECORD_SYMBOL] & 1048576) {
                parentRecordId = transition[RECORD_SYMBOL] & 65535;
              }
              nextTransition = transition[key] = /* @__PURE__ */ Object.create(null);
              newTransitions++;
            }
            transition = nextTransition;
            length++;
          }
      }
      let recordId = transition[RECORD_SYMBOL];
      if (recordId !== void 0) {
        recordId &= 65535;
        target[position2++] = 217;
        target[position2++] = recordId >> 8 | 224;
        target[position2++] = recordId & 255;
      } else {
        if (!keys)
          keys = transition.__keys__ || (transition.__keys__ = Object.keys(object));
        if (parentRecordId === void 0) {
          recordId = structures.nextId++;
          if (!recordId) {
            recordId = 0;
            structures.nextId = 1;
          }
          if (recordId >= MAX_STRUCTURES) {
            structures.nextId = (recordId = maxSharedStructures) + 1;
          }
        } else {
          recordId = parentRecordId;
        }
        structures[recordId] = keys;
        if (recordId < maxSharedStructures) {
          target[position2++] = 217;
          target[position2++] = recordId >> 8 | 224;
          target[position2++] = recordId & 255;
          transition = structures.transitions;
          for (let i2 = 0; i2 < length; i2++) {
            if (transition[RECORD_SYMBOL] === void 0 || transition[RECORD_SYMBOL] & 1048576)
              transition[RECORD_SYMBOL] = recordId;
            transition = transition[keys[i2]];
          }
          transition[RECORD_SYMBOL] = recordId | 1048576;
          hasSharedUpdate = true;
        } else {
          transition[RECORD_SYMBOL] = recordId;
          targetView.setUint32(position2, 3655335680);
          position2 += 3;
          if (newTransitions)
            transitionsCount += serializationsSinceTransitionRebuild * newTransitions;
          if (recordIdsToRemove.length >= MAX_STRUCTURES - maxSharedStructures)
            recordIdsToRemove.shift()[RECORD_SYMBOL] = void 0;
          recordIdsToRemove.push(transition);
          writeArrayHeader(length + 2);
          encode2(57344 + recordId);
          encode2(keys);
          if (safePrototype === null)
            return;
          for (let key in object)
            if (safePrototype || object.hasOwnProperty(key))
              encode2(object[key]);
          return;
        }
      }
      if (length < 24) {
        target[position2++] = 128 | length;
      } else {
        writeArrayHeader(length);
      }
      if (safePrototype === null)
        return;
      for (let key in object)
        if (safePrototype || object.hasOwnProperty(key))
          encode2(object[key]);
    };
    const makeRoom = (end) => {
      let newSize;
      if (end > 16777216) {
        if (end - start > MAX_BUFFER_SIZE)
          throw new Error("Encoded buffer would be larger than maximum buffer size");
        newSize = Math.min(
          MAX_BUFFER_SIZE,
          Math.round(Math.max((end - start) * (end > 67108864 ? 1.25 : 2), 4194304) / 4096) * 4096
        );
      } else
        newSize = (Math.max(end - start << 2, target.length - 1) >> 12) + 1 << 12;
      let newBuffer = new ByteArrayAllocate(newSize);
      targetView = new DataView(newBuffer.buffer, 0, newSize);
      if (target.copy)
        target.copy(newBuffer, 0, start, end);
      else
        newBuffer.set(target.slice(start, end));
      position2 -= start;
      start = 0;
      safeEnd = newBuffer.length - 10;
      return target = newBuffer;
    };
    let chunkThreshold = 100;
    let continuedChunkThreshold = 1e3;
    this.encodeAsIterable = function(value, options2) {
      return startEncoding(value, options2, encodeObjectAsIterable);
    };
    this.encodeAsAsyncIterable = function(value, options2) {
      return startEncoding(value, options2, encodeObjectAsAsyncIterable);
    };
    function* encodeObjectAsIterable(object, iterateProperties, finalIterable) {
      let constructor = object.constructor;
      if (constructor === Object) {
        let useRecords = encoder.useRecords !== false;
        if (useRecords)
          writeObject(object, null);
        else
          writeEntityLength(Object.keys(object).length, 160);
        for (let key in object) {
          let value = object[key];
          if (!useRecords)
            encode2(key);
          if (value && typeof value === "object") {
            if (iterateProperties[key])
              yield* encodeObjectAsIterable(value, iterateProperties[key]);
            else
              yield* tryEncode(value, iterateProperties, key);
          } else
            encode2(value);
        }
      } else if (constructor === Array) {
        let length = object.length;
        writeArrayHeader(length);
        for (let i2 = 0; i2 < length; i2++) {
          let value = object[i2];
          if (value && (typeof value === "object" || position2 - start > chunkThreshold)) {
            if (iterateProperties.element)
              yield* encodeObjectAsIterable(value, iterateProperties.element);
            else
              yield* tryEncode(value, iterateProperties, "element");
          } else
            encode2(value);
        }
      } else if (object[Symbol.iterator]) {
        target[position2++] = 159;
        for (let value of object) {
          if (value && (typeof value === "object" || position2 - start > chunkThreshold)) {
            if (iterateProperties.element)
              yield* encodeObjectAsIterable(value, iterateProperties.element);
            else
              yield* tryEncode(value, iterateProperties, "element");
          } else
            encode2(value);
        }
        target[position2++] = 255;
      } else if (isBlob(object)) {
        writeEntityLength(object.size, 64);
        yield target.subarray(start, position2);
        yield object;
        restartEncoding();
      } else if (object[Symbol.asyncIterator]) {
        target[position2++] = 159;
        yield target.subarray(start, position2);
        yield object;
        restartEncoding();
        target[position2++] = 255;
      } else {
        encode2(object);
      }
      if (finalIterable && position2 > start)
        yield target.subarray(start, position2);
      else if (position2 - start > chunkThreshold) {
        yield target.subarray(start, position2);
        restartEncoding();
      }
    }
    function* tryEncode(value, iterateProperties, key) {
      let restart = position2 - start;
      try {
        encode2(value);
        if (position2 - start > chunkThreshold) {
          yield target.subarray(start, position2);
          restartEncoding();
        }
      } catch (error) {
        if (error.iteratorNotHandled) {
          iterateProperties[key] = {};
          position2 = start + restart;
          yield* encodeObjectAsIterable.call(this, value, iterateProperties[key]);
        } else
          throw error;
      }
    }
    function restartEncoding() {
      chunkThreshold = continuedChunkThreshold;
      encoder.encode(null, THROW_ON_ITERABLE);
    }
    function startEncoding(value, options2, encodeIterable) {
      if (options2 && options2.chunkThreshold)
        chunkThreshold = continuedChunkThreshold = options2.chunkThreshold;
      else
        chunkThreshold = 100;
      if (value && typeof value === "object") {
        encoder.encode(null, THROW_ON_ITERABLE);
        return encodeIterable(value, encoder.iterateProperties || (encoder.iterateProperties = {}), true);
      }
      return [encoder.encode(value)];
    }
    async function* encodeObjectAsAsyncIterable(value, iterateProperties) {
      for (let encodedValue of encodeObjectAsIterable(value, iterateProperties, true)) {
        let constructor = encodedValue.constructor;
        if (constructor === ByteArray || constructor === Uint8Array)
          yield encodedValue;
        else if (isBlob(encodedValue)) {
          let reader = encodedValue.stream().getReader();
          let next;
          while (!(next = await reader.read()).done) {
            yield next.value;
          }
        } else if (encodedValue[Symbol.asyncIterator]) {
          for await (let asyncValue of encodedValue) {
            restartEncoding();
            if (asyncValue)
              yield* encodeObjectAsAsyncIterable(asyncValue, iterateProperties.async || (iterateProperties.async = {}));
            else
              yield encoder.encode(asyncValue);
          }
        } else {
          yield encodedValue;
        }
      }
    }
  }
  useBuffer(buffer) {
    target = buffer;
    targetView = new DataView(target.buffer, target.byteOffset, target.byteLength);
    position2 = 0;
  }
  clearSharedData() {
    if (this.structures)
      this.structures = [];
    if (this.sharedValues)
      this.sharedValues = void 0;
  }
  updateSharedData() {
    let lastVersion = this.sharedVersion || 0;
    this.sharedVersion = lastVersion + 1;
    let structuresCopy = this.structures.slice(0);
    let sharedData = new SharedData(structuresCopy, this.sharedValues, this.sharedVersion);
    let saveResults = this.saveShared(
      sharedData,
      (existingShared) => (existingShared && existingShared.version || 0) == lastVersion
    );
    if (saveResults === false) {
      sharedData = this.getShared() || {};
      this.structures = sharedData.structures || [];
      this.sharedValues = sharedData.packedValues;
      this.sharedVersion = sharedData.version;
      this.structures.nextId = this.structures.length;
    } else {
      structuresCopy.forEach((structure, i2) => this.structures[i2] = structure);
    }
    return saveResults;
  }
};
function writeEntityLength(length, majorValue) {
  if (length < 24)
    target[position2++] = majorValue | length;
  else if (length < 256) {
    target[position2++] = majorValue | 24;
    target[position2++] = length;
  } else if (length < 65536) {
    target[position2++] = majorValue | 25;
    target[position2++] = length >> 8;
    target[position2++] = length & 255;
  } else {
    target[position2++] = majorValue | 26;
    targetView.setUint32(position2, length);
    position2 += 4;
  }
}
var SharedData = class {
  constructor(structures, values, version) {
    this.structures = structures;
    this.packedValues = values;
    this.version = version;
  }
};
function writeArrayHeader(length) {
  if (length < 24)
    target[position2++] = 128 | length;
  else if (length < 256) {
    target[position2++] = 152;
    target[position2++] = length;
  } else if (length < 65536) {
    target[position2++] = 153;
    target[position2++] = length >> 8;
    target[position2++] = length & 255;
  } else {
    target[position2++] = 154;
    targetView.setUint32(position2, length);
    position2 += 4;
  }
}
var BlobConstructor = typeof Blob === "undefined" ? function() {
} : Blob;
function isBlob(object) {
  if (object instanceof BlobConstructor)
    return true;
  let tag = object[Symbol.toStringTag];
  return tag === "Blob" || tag === "File";
}
function findRepetitiveStrings(value, packedValues2) {
  switch (typeof value) {
    case "string":
      if (value.length > 3) {
        if (packedValues2.objectMap[value] > -1 || packedValues2.values.length >= packedValues2.maxValues)
          return;
        let packedStatus = packedValues2.get(value);
        if (packedStatus) {
          if (++packedStatus.count == 2) {
            packedValues2.values.push(value);
          }
        } else {
          packedValues2.set(value, {
            count: 1
          });
          if (packedValues2.samplingPackedValues) {
            let status = packedValues2.samplingPackedValues.get(value);
            if (status)
              status.count++;
            else
              packedValues2.samplingPackedValues.set(value, {
                count: 1
              });
          }
        }
      }
      break;
    case "object":
      if (value) {
        if (value instanceof Array) {
          for (let i2 = 0, l2 = value.length; i2 < l2; i2++) {
            findRepetitiveStrings(value[i2], packedValues2);
          }
        } else {
          let includeKeys = !packedValues2.encoder.useRecords;
          for (var key in value) {
            if (value.hasOwnProperty(key)) {
              if (includeKeys)
                findRepetitiveStrings(key, packedValues2);
              findRepetitiveStrings(value[key], packedValues2);
            }
          }
        }
      }
      break;
    case "function":
      console.log(value);
  }
}
var isLittleEndianMachine2 = new Uint8Array(new Uint16Array([1]).buffer)[0] == 1;
extensionClasses = [
  Date,
  Set,
  Error,
  RegExp,
  Tag,
  ArrayBuffer,
  Uint8Array,
  Uint8ClampedArray,
  Uint16Array,
  Uint32Array,
  typeof BigUint64Array == "undefined" ? function() {
  } : BigUint64Array,
  Int8Array,
  Int16Array,
  Int32Array,
  typeof BigInt64Array == "undefined" ? function() {
  } : BigInt64Array,
  Float32Array,
  Float64Array,
  SharedData
];
extensions = [
  {
    // Date
    tag: 1,
    encode(date, encode2) {
      let seconds = date.getTime() / 1e3;
      if ((this.useTimestamp32 || date.getMilliseconds() === 0) && seconds >= 0 && seconds < 4294967296) {
        target[position2++] = 26;
        targetView.setUint32(position2, seconds);
        position2 += 4;
      } else {
        target[position2++] = 251;
        targetView.setFloat64(position2, seconds);
        position2 += 8;
      }
    }
  },
  {
    // Set
    tag: 258,
    // https://github.com/input-output-hk/cbor-sets-spec/blob/master/CBOR_SETS.md
    encode(set, encode2) {
      let array = Array.from(set);
      encode2(array);
    }
  },
  {
    // Error
    tag: 27,
    // http://cbor.schmorp.de/generic-object
    encode(error, encode2) {
      encode2([error.name, error.message]);
    }
  },
  {
    // RegExp
    tag: 27,
    // http://cbor.schmorp.de/generic-object
    encode(regex, encode2) {
      encode2(["RegExp", regex.source, regex.flags]);
    }
  },
  {
    // Tag
    getTag(tag) {
      return tag.tag;
    },
    encode(tag, encode2) {
      encode2(tag.value);
    }
  },
  {
    // ArrayBuffer
    encode(arrayBuffer, encode2, makeRoom) {
      writeBuffer(arrayBuffer, makeRoom);
    }
  },
  {
    // Uint8Array
    getTag(typedArray) {
      if (typedArray.constructor === Uint8Array) {
        if (this.tagUint8Array || hasNodeBuffer && this.tagUint8Array !== false)
          return 64;
      }
    },
    encode(typedArray, encode2, makeRoom) {
      writeBuffer(typedArray, makeRoom);
    }
  },
  typedArrayEncoder(68, 1),
  typedArrayEncoder(69, 2),
  typedArrayEncoder(70, 4),
  typedArrayEncoder(71, 8),
  typedArrayEncoder(72, 1),
  typedArrayEncoder(77, 2),
  typedArrayEncoder(78, 4),
  typedArrayEncoder(79, 8),
  typedArrayEncoder(85, 4),
  typedArrayEncoder(86, 8),
  {
    encode(sharedData, encode2) {
      let packedValues2 = sharedData.packedValues || [];
      let sharedStructures = sharedData.structures || [];
      if (packedValues2.values.length > 0) {
        target[position2++] = 216;
        target[position2++] = 51;
        writeArrayHeader(4);
        let valuesArray = packedValues2.values;
        encode2(valuesArray);
        writeArrayHeader(0);
        writeArrayHeader(0);
        packedObjectMap = Object.create(sharedPackedObjectMap || null);
        for (let i2 = 0, l2 = valuesArray.length; i2 < l2; i2++) {
          packedObjectMap[valuesArray[i2]] = i2;
        }
      }
      if (sharedStructures) {
        targetView.setUint32(position2, 3655335424);
        position2 += 3;
        let definitions = sharedStructures.slice(0);
        definitions.unshift(57344);
        definitions.push(new Tag(sharedData.version, 1399353956));
        encode2(definitions);
      } else
        encode2(new Tag(sharedData.version, 1399353956));
    }
  }
];
function typedArrayEncoder(tag, size) {
  if (!isLittleEndianMachine2 && size > 1)
    tag -= 4;
  return {
    tag,
    encode: function writeExtBuffer(typedArray, encode2) {
      let length = typedArray.byteLength;
      let offset = typedArray.byteOffset || 0;
      let buffer = typedArray.buffer || typedArray;
      encode2(hasNodeBuffer ? Buffer2.from(buffer, offset, length) : new Uint8Array(buffer, offset, length));
    }
  };
}
function writeBuffer(buffer, makeRoom) {
  let length = buffer.byteLength;
  if (length < 24) {
    target[position2++] = 64 + length;
  } else if (length < 256) {
    target[position2++] = 88;
    target[position2++] = length;
  } else if (length < 65536) {
    target[position2++] = 89;
    target[position2++] = length >> 8;
    target[position2++] = length & 255;
  } else {
    target[position2++] = 90;
    targetView.setUint32(position2, length);
    position2 += 4;
  }
  if (position2 + length >= target.length) {
    makeRoom(position2 + length);
  }
  target.set(buffer.buffer ? buffer : new Uint8Array(buffer), position2);
  position2 += length;
}
function insertIds(serialized, idsToInsert) {
  let nextId;
  let distanceToMove = idsToInsert.length * 2;
  let lastEnd = serialized.length - distanceToMove;
  idsToInsert.sort((a3, b4) => a3.offset > b4.offset ? 1 : -1);
  for (let id = 0; id < idsToInsert.length; id++) {
    let referee = idsToInsert[id];
    referee.id = id;
    for (let position3 of referee.references) {
      serialized[position3++] = id >> 8;
      serialized[position3] = id & 255;
    }
  }
  while (nextId = idsToInsert.pop()) {
    let offset = nextId.offset;
    serialized.copyWithin(offset + distanceToMove, offset, lastEnd);
    distanceToMove -= 2;
    let position3 = offset + distanceToMove;
    serialized[position3++] = 216;
    serialized[position3++] = 28;
    lastEnd = offset;
  }
  return serialized;
}
function writeBundles(start, encode2) {
  targetView.setUint32(bundledStrings2.position + start, position2 - bundledStrings2.position - start + 1);
  let writeStrings = bundledStrings2;
  bundledStrings2 = null;
  encode2(writeStrings[0]);
  encode2(writeStrings[1]);
}
var defaultEncoder = new Encoder({ useRecords: false });
var encode = defaultEncoder.encode;
var encodeAsIterable = defaultEncoder.encodeAsIterable;
var encodeAsAsyncIterable = defaultEncoder.encodeAsAsyncIterable;
var { NEVER, ALWAYS, DECIMAL_ROUND, DECIMAL_FIT } = FLOAT32_OPTIONS;
var REUSE_BUFFER_MODE = 512;
var RESET_BUFFER_MODE = 1024;
var THROW_ON_ITERABLE = 2048;

// ../desktop-dev/src/core/ipc-web/$messageToIpcMessage.ts
var $isIpcSignalMessage = (msg) => msg === "close" || msg === "ping" || msg === "pong";
var $objectToIpcMessage = (data, ipc2) => {
  let message;
  if (data.type === 0 /* REQUEST */) {
    message = new IpcRequest2(
      data.req_id,
      data.url,
      data.method,
      new IpcHeaders3(data.headers),
      IpcBodyReceiver.from(MetaBody.fromJSON(data.metaBody), ipc2),
      ipc2
    );
  } else if (data.type === 1 /* RESPONSE */) {
    message = new IpcResponse2(
      data.req_id,
      data.statusCode,
      new IpcHeaders3(data.headers),
      IpcBodyReceiver.from(MetaBody.fromJSON(data.metaBody), ipc2),
      ipc2
    );
  } else if (data.type === 7 /* EVENT */) {
    message = new IpcEvent2(data.name, data.data, data.encoding);
  } else if (data.type === 2 /* STREAM_DATA */) {
    message = new IpcStreamData(data.stream_id, data.data, data.encoding);
  } else if (data.type === 3 /* STREAM_PULLING */) {
    message = new IpcStreamPulling(data.stream_id, data.bandwidth);
  } else if (data.type === 4 /* STREAM_PAUSED */) {
    message = new IpcStreamPaused(data.stream_id, data.fuse);
  } else if (data.type === 6 /* STREAM_ABORT */) {
    message = new IpcStreamAbort(data.stream_id);
  } else if (data.type === 5 /* STREAM_END */) {
    message = new IpcStreamEnd(data.stream_id);
  }
  return message;
};
var $messageToIpcMessage = (data, ipc2) => {
  if ($isIpcSignalMessage(data)) {
    return data;
  }
  return $objectToIpcMessage(data, ipc2);
};
var $jsonToIpcMessage = (data, ipc2) => {
  if ($isIpcSignalMessage(data)) {
    return data;
  }
  return $objectToIpcMessage(JSON.parse(data), ipc2);
};
var textDecoder2 = new TextDecoder();

// ../desktop-dev/src/core/ipc-web/$messagePackToIpcMessage.ts
var $messagePackToIpcMessage = (data, ipc2) => {
  return $messageToIpcMessage(decode(data), ipc2);
};

// ../desktop-dev/src/core/ipc-web/ReadableStreamIpc.ts
var _rso;
var _ReadableStreamIpc = class extends Ipc2 {
  constructor(remote, role, self_support_protocols = {
    raw: false,
    cbor: true,
    protobuf: false
  }) {
    super();
    this.remote = remote;
    this.role = role;
    this.self_support_protocols = self_support_protocols;
    __privateAdd(this, _rso, new ReadableStreamOut());
    this.PONG_DATA = once(() => {
      const pong = encode("pong");
      return _ReadableStreamIpc.concatLen(pong);
    });
    this.CLOSE_DATA = once(() => {
      const close = encode("close");
      return _ReadableStreamIpc.concatLen(close);
    });
    this._support_cbor = self_support_protocols.cbor && remote.ipc_support_protocols.cbor;
  }
  /** 这是输出流，给外部读取用的 */
  get stream() {
    return __privateGet(this, _rso).stream;
  }
  get controller() {
    return __privateGet(this, _rso).controller;
  }
  /**
   * 输入流要额外绑定
   * 注意，非必要不要 await 这个promise
   */
  async bindIncomeStream(stream, options = {}) {
    if (this._incomne_stream !== void 0) {
      throw new Error("in come stream alreay binded.");
    }
    this._incomne_stream = await stream;
    const { signal } = options;
    const reader = binaryStreamRead(this._incomne_stream, { signal });
    this.onClose(() => {
      reader.throw("output stream closed");
    });
    while (await reader.available() > 0) {
      const size = await reader.readInt();
      const data = await reader.readBinary(size);
      const message = this.support_cbor ? $messagePackToIpcMessage(data, this) : $jsonToIpcMessage(simpleDecoder(data, "utf8"), this);
      if (message === void 0) {
        console.error("unkonwn message", data);
        return;
      }
      if (message === "pong") {
        return;
      }
      if (message === "close") {
        this.close();
        return;
      }
      if (message === "ping") {
        this.controller.enqueue(this.PONG_DATA());
        return;
      }
      this._messageSignal.emit(message, this);
    }
    this.close();
  }
  _doPostMessage(message) {
    let message_raw;
    if (message.type === 0 /* REQUEST */) {
      message_raw = message.ipcReqMessage();
    } else if (message.type === 1 /* RESPONSE */) {
      message_raw = message.ipcResMessage();
    } else {
      message_raw = message;
    }
    const message_data = this.support_cbor ? encode(message_raw) : simpleEncoder(JSON.stringify(message_raw), "utf8");
    const chunk = _ReadableStreamIpc.concatLen(message_data);
    this.controller.enqueue(chunk);
  }
  _doClose() {
    this.controller.enqueue(this.CLOSE_DATA());
    this.controller.close();
  }
};
var ReadableStreamIpc2 = _ReadableStreamIpc;
_rso = new WeakMap();
ReadableStreamIpc2._len = new Uint32Array(1);
ReadableStreamIpc2._len_u8a = new Uint8Array(_ReadableStreamIpc._len.buffer);
ReadableStreamIpc2.concatLen = (data) => {
  _ReadableStreamIpc._len[0] = data.length;
  return u8aConcat([_ReadableStreamIpc._len_u8a, data]);
};

// https://esm.sh/v124/zod@3.21.4/denonext/zod.mjs
var g2;
(function(s2) {
  s2.assertEqual = (n2) => n2;
  function e(n2) {
  }
  s2.assertIs = e;
  function t2(n2) {
    throw new Error();
  }
  s2.assertNever = t2, s2.arrayToEnum = (n2) => {
    let a3 = {};
    for (let i2 of n2)
      a3[i2] = i2;
    return a3;
  }, s2.getValidEnumValues = (n2) => {
    let a3 = s2.objectKeys(n2).filter((o) => typeof n2[n2[o]] != "number"), i2 = {};
    for (let o of a3)
      i2[o] = n2[o];
    return s2.objectValues(i2);
  }, s2.objectValues = (n2) => s2.objectKeys(n2).map(function(a3) {
    return n2[a3];
  }), s2.objectKeys = typeof Object.keys == "function" ? (n2) => Object.keys(n2) : (n2) => {
    let a3 = [];
    for (let i2 in n2)
      Object.prototype.hasOwnProperty.call(n2, i2) && a3.push(i2);
    return a3;
  }, s2.find = (n2, a3) => {
    for (let i2 of n2)
      if (a3(i2))
        return i2;
  }, s2.isInteger = typeof Number.isInteger == "function" ? (n2) => Number.isInteger(n2) : (n2) => typeof n2 == "number" && isFinite(n2) && Math.floor(n2) === n2;
  function r(n2, a3 = " | ") {
    return n2.map((i2) => typeof i2 == "string" ? `'${i2}'` : i2).join(a3);
  }
  s2.joinValues = r, s2.jsonStringifyReplacer = (n2, a3) => typeof a3 == "bigint" ? a3.toString() : a3;
})(g2 || (g2 = {}));
var me;
(function(s2) {
  s2.mergeShapes = (e, t2) => ({ ...e, ...t2 });
})(me || (me = {}));
var d2 = g2.arrayToEnum(["string", "nan", "number", "integer", "float", "boolean", "date", "bigint", "symbol", "function", "undefined", "null", "array", "object", "unknown", "promise", "void", "never", "map", "set"]);
var P2 = (s2) => {
  switch (typeof s2) {
    case "undefined":
      return d2.undefined;
    case "string":
      return d2.string;
    case "number":
      return isNaN(s2) ? d2.nan : d2.number;
    case "boolean":
      return d2.boolean;
    case "function":
      return d2.function;
    case "bigint":
      return d2.bigint;
    case "symbol":
      return d2.symbol;
    case "object":
      return Array.isArray(s2) ? d2.array : s2 === null ? d2.null : s2.then && typeof s2.then == "function" && s2.catch && typeof s2.catch == "function" ? d2.promise : typeof Map < "u" && s2 instanceof Map ? d2.map : typeof Set < "u" && s2 instanceof Set ? d2.set : typeof Date < "u" && s2 instanceof Date ? d2.date : d2.object;
    default:
      return d2.unknown;
  }
};
var c2 = g2.arrayToEnum(["invalid_type", "invalid_literal", "custom", "invalid_union", "invalid_union_discriminator", "invalid_enum_value", "unrecognized_keys", "invalid_arguments", "invalid_return_type", "invalid_date", "invalid_string", "too_small", "too_big", "invalid_intersection_types", "not_multiple_of", "not_finite"]);
var Ne = (s2) => JSON.stringify(s2, null, 2).replace(/"([^"]+)":/g, "$1:");
var T = class extends Error {
  constructor(e) {
    super(), this.issues = [], this.addIssue = (r) => {
      this.issues = [...this.issues, r];
    }, this.addIssues = (r = []) => {
      this.issues = [...this.issues, ...r];
    };
    let t2 = new.target.prototype;
    Object.setPrototypeOf ? Object.setPrototypeOf(this, t2) : this.__proto__ = t2, this.name = "ZodError", this.issues = e;
  }
  get errors() {
    return this.issues;
  }
  format(e) {
    let t2 = e || function(a3) {
      return a3.message;
    }, r = { _errors: [] }, n2 = (a3) => {
      for (let i2 of a3.issues)
        if (i2.code === "invalid_union")
          i2.unionErrors.map(n2);
        else if (i2.code === "invalid_return_type")
          n2(i2.returnTypeError);
        else if (i2.code === "invalid_arguments")
          n2(i2.argumentsError);
        else if (i2.path.length === 0)
          r._errors.push(t2(i2));
        else {
          let o = r, f2 = 0;
          for (; f2 < i2.path.length; ) {
            let l2 = i2.path[f2];
            f2 === i2.path.length - 1 ? (o[l2] = o[l2] || { _errors: [] }, o[l2]._errors.push(t2(i2))) : o[l2] = o[l2] || { _errors: [] }, o = o[l2], f2++;
          }
        }
    };
    return n2(this), r;
  }
  toString() {
    return this.message;
  }
  get message() {
    return JSON.stringify(this.issues, g2.jsonStringifyReplacer, 2);
  }
  get isEmpty() {
    return this.issues.length === 0;
  }
  flatten(e = (t2) => t2.message) {
    let t2 = {}, r = [];
    for (let n2 of this.issues)
      n2.path.length > 0 ? (t2[n2.path[0]] = t2[n2.path[0]] || [], t2[n2.path[0]].push(e(n2))) : r.push(e(n2));
    return { formErrors: r, fieldErrors: t2 };
  }
  get formErrors() {
    return this.flatten();
  }
};
T.create = (s2) => new T(s2);
var oe = (s2, e) => {
  let t2;
  switch (s2.code) {
    case c2.invalid_type:
      s2.received === d2.undefined ? t2 = "Required" : t2 = `Expected ${s2.expected}, received ${s2.received}`;
      break;
    case c2.invalid_literal:
      t2 = `Invalid literal value, expected ${JSON.stringify(s2.expected, g2.jsonStringifyReplacer)}`;
      break;
    case c2.unrecognized_keys:
      t2 = `Unrecognized key(s) in object: ${g2.joinValues(s2.keys, ", ")}`;
      break;
    case c2.invalid_union:
      t2 = "Invalid input";
      break;
    case c2.invalid_union_discriminator:
      t2 = `Invalid discriminator value. Expected ${g2.joinValues(s2.options)}`;
      break;
    case c2.invalid_enum_value:
      t2 = `Invalid enum value. Expected ${g2.joinValues(s2.options)}, received '${s2.received}'`;
      break;
    case c2.invalid_arguments:
      t2 = "Invalid function arguments";
      break;
    case c2.invalid_return_type:
      t2 = "Invalid function return type";
      break;
    case c2.invalid_date:
      t2 = "Invalid date";
      break;
    case c2.invalid_string:
      typeof s2.validation == "object" ? "includes" in s2.validation ? (t2 = `Invalid input: must include "${s2.validation.includes}"`, typeof s2.validation.position == "number" && (t2 = `${t2} at one or more positions greater than or equal to ${s2.validation.position}`)) : "startsWith" in s2.validation ? t2 = `Invalid input: must start with "${s2.validation.startsWith}"` : "endsWith" in s2.validation ? t2 = `Invalid input: must end with "${s2.validation.endsWith}"` : g2.assertNever(s2.validation) : s2.validation !== "regex" ? t2 = `Invalid ${s2.validation}` : t2 = "Invalid";
      break;
    case c2.too_small:
      s2.type === "array" ? t2 = `Array must contain ${s2.exact ? "exactly" : s2.inclusive ? "at least" : "more than"} ${s2.minimum} element(s)` : s2.type === "string" ? t2 = `String must contain ${s2.exact ? "exactly" : s2.inclusive ? "at least" : "over"} ${s2.minimum} character(s)` : s2.type === "number" ? t2 = `Number must be ${s2.exact ? "exactly equal to " : s2.inclusive ? "greater than or equal to " : "greater than "}${s2.minimum}` : s2.type === "date" ? t2 = `Date must be ${s2.exact ? "exactly equal to " : s2.inclusive ? "greater than or equal to " : "greater than "}${new Date(Number(s2.minimum))}` : t2 = "Invalid input";
      break;
    case c2.too_big:
      s2.type === "array" ? t2 = `Array must contain ${s2.exact ? "exactly" : s2.inclusive ? "at most" : "less than"} ${s2.maximum} element(s)` : s2.type === "string" ? t2 = `String must contain ${s2.exact ? "exactly" : s2.inclusive ? "at most" : "under"} ${s2.maximum} character(s)` : s2.type === "number" ? t2 = `Number must be ${s2.exact ? "exactly" : s2.inclusive ? "less than or equal to" : "less than"} ${s2.maximum}` : s2.type === "bigint" ? t2 = `BigInt must be ${s2.exact ? "exactly" : s2.inclusive ? "less than or equal to" : "less than"} ${s2.maximum}` : s2.type === "date" ? t2 = `Date must be ${s2.exact ? "exactly" : s2.inclusive ? "smaller than or equal to" : "smaller than"} ${new Date(Number(s2.maximum))}` : t2 = "Invalid input";
      break;
    case c2.custom:
      t2 = "Invalid input";
      break;
    case c2.invalid_intersection_types:
      t2 = "Intersection results could not be merged";
      break;
    case c2.not_multiple_of:
      t2 = `Number must be a multiple of ${s2.multipleOf}`;
      break;
    case c2.not_finite:
      t2 = "Number must be finite";
      break;
    default:
      t2 = e.defaultError, g2.assertNever(s2);
  }
  return { message: t2 };
};
var ke = oe;
function Ee(s2) {
  ke = s2;
}
function de() {
  return ke;
}
var ue = (s2) => {
  let { data: e, path: t2, errorMaps: r, issueData: n2 } = s2, a3 = [...t2, ...n2.path || []], i2 = { ...n2, path: a3 }, o = "", f2 = r.filter((l2) => !!l2).slice().reverse();
  for (let l2 of f2)
    o = l2(i2, { data: e, defaultError: o }).message;
  return { ...n2, path: a3, message: n2.message || o };
};
var Ie = [];
function u3(s2, e) {
  let t2 = ue({ issueData: e, data: s2.data, path: s2.path, errorMaps: [s2.common.contextualErrorMap, s2.schemaErrorMap, de(), oe].filter((r) => !!r) });
  s2.common.issues.push(t2);
}
var k2 = class {
  constructor() {
    this.value = "valid";
  }
  dirty() {
    this.value === "valid" && (this.value = "dirty");
  }
  abort() {
    this.value !== "aborted" && (this.value = "aborted");
  }
  static mergeArray(e, t2) {
    let r = [];
    for (let n2 of t2) {
      if (n2.status === "aborted")
        return m3;
      n2.status === "dirty" && e.dirty(), r.push(n2.value);
    }
    return { status: e.value, value: r };
  }
  static async mergeObjectAsync(e, t2) {
    let r = [];
    for (let n2 of t2)
      r.push({ key: await n2.key, value: await n2.value });
    return k2.mergeObjectSync(e, r);
  }
  static mergeObjectSync(e, t2) {
    let r = {};
    for (let n2 of t2) {
      let { key: a3, value: i2 } = n2;
      if (a3.status === "aborted" || i2.status === "aborted")
        return m3;
      a3.status === "dirty" && e.dirty(), i2.status === "dirty" && e.dirty(), (typeof i2.value < "u" || n2.alwaysSet) && (r[a3.value] = i2.value);
    }
    return { status: e.value, value: r };
  }
};
var m3 = Object.freeze({ status: "aborted" });
var be = (s2) => ({ status: "dirty", value: s2 });
var b3 = (s2) => ({ status: "valid", value: s2 });
var ye = (s2) => s2.status === "aborted";
var ve = (s2) => s2.status === "dirty";
var le = (s2) => s2.status === "valid";
var fe = (s2) => typeof Promise < "u" && s2 instanceof Promise;
var h2;
(function(s2) {
  s2.errToObj = (e) => typeof e == "string" ? { message: e } : e || {}, s2.toString = (e) => typeof e == "string" ? e : e?.message;
})(h2 || (h2 = {}));
var O2 = class {
  constructor(e, t2, r, n2) {
    this._cachedPath = [], this.parent = e, this.data = t2, this._path = r, this._key = n2;
  }
  get path() {
    return this._cachedPath.length || (this._key instanceof Array ? this._cachedPath.push(...this._path, ...this._key) : this._cachedPath.push(...this._path, this._key)), this._cachedPath;
  }
};
var ge = (s2, e) => {
  if (le(e))
    return { success: true, data: e.value };
  if (!s2.common.issues.length)
    throw new Error("Validation failed but no issues detected.");
  return { success: false, get error() {
    if (this._error)
      return this._error;
    let t2 = new T(s2.common.issues);
    return this._error = t2, this._error;
  } };
};
function y2(s2) {
  if (!s2)
    return {};
  let { errorMap: e, invalid_type_error: t2, required_error: r, description: n2 } = s2;
  if (e && (t2 || r))
    throw new Error(`Can't use "invalid_type_error" or "required_error" in conjunction with custom error map.`);
  return e ? { errorMap: e, description: n2 } : { errorMap: (i2, o) => i2.code !== "invalid_type" ? { message: o.defaultError } : typeof o.data > "u" ? { message: r ?? o.defaultError } : { message: t2 ?? o.defaultError }, description: n2 };
}
var v2 = class {
  constructor(e) {
    this.spa = this.safeParseAsync, this._def = e, this.parse = this.parse.bind(this), this.safeParse = this.safeParse.bind(this), this.parseAsync = this.parseAsync.bind(this), this.safeParseAsync = this.safeParseAsync.bind(this), this.spa = this.spa.bind(this), this.refine = this.refine.bind(this), this.refinement = this.refinement.bind(this), this.superRefine = this.superRefine.bind(this), this.optional = this.optional.bind(this), this.nullable = this.nullable.bind(this), this.nullish = this.nullish.bind(this), this.array = this.array.bind(this), this.promise = this.promise.bind(this), this.or = this.or.bind(this), this.and = this.and.bind(this), this.transform = this.transform.bind(this), this.brand = this.brand.bind(this), this.default = this.default.bind(this), this.catch = this.catch.bind(this), this.describe = this.describe.bind(this), this.pipe = this.pipe.bind(this), this.isNullable = this.isNullable.bind(this), this.isOptional = this.isOptional.bind(this);
  }
  get description() {
    return this._def.description;
  }
  _getType(e) {
    return P2(e.data);
  }
  _getOrReturnCtx(e, t2) {
    return t2 || { common: e.parent.common, data: e.data, parsedType: P2(e.data), schemaErrorMap: this._def.errorMap, path: e.path, parent: e.parent };
  }
  _processInputParams(e) {
    return { status: new k2(), ctx: { common: e.parent.common, data: e.data, parsedType: P2(e.data), schemaErrorMap: this._def.errorMap, path: e.path, parent: e.parent } };
  }
  _parseSync(e) {
    let t2 = this._parse(e);
    if (fe(t2))
      throw new Error("Synchronous parse encountered promise.");
    return t2;
  }
  _parseAsync(e) {
    let t2 = this._parse(e);
    return Promise.resolve(t2);
  }
  parse(e, t2) {
    let r = this.safeParse(e, t2);
    if (r.success)
      return r.data;
    throw r.error;
  }
  safeParse(e, t2) {
    var r;
    let n2 = { common: { issues: [], async: (r = t2?.async) !== null && r !== void 0 ? r : false, contextualErrorMap: t2?.errorMap }, path: t2?.path || [], schemaErrorMap: this._def.errorMap, parent: null, data: e, parsedType: P2(e) }, a3 = this._parseSync({ data: e, path: n2.path, parent: n2 });
    return ge(n2, a3);
  }
  async parseAsync(e, t2) {
    let r = await this.safeParseAsync(e, t2);
    if (r.success)
      return r.data;
    throw r.error;
  }
  async safeParseAsync(e, t2) {
    let r = { common: { issues: [], contextualErrorMap: t2?.errorMap, async: true }, path: t2?.path || [], schemaErrorMap: this._def.errorMap, parent: null, data: e, parsedType: P2(e) }, n2 = this._parse({ data: e, path: r.path, parent: r }), a3 = await (fe(n2) ? n2 : Promise.resolve(n2));
    return ge(r, a3);
  }
  refine(e, t2) {
    let r = (n2) => typeof t2 == "string" || typeof t2 > "u" ? { message: t2 } : typeof t2 == "function" ? t2(n2) : t2;
    return this._refinement((n2, a3) => {
      let i2 = e(n2), o = () => a3.addIssue({ code: c2.custom, ...r(n2) });
      return typeof Promise < "u" && i2 instanceof Promise ? i2.then((f2) => f2 ? true : (o(), false)) : i2 ? true : (o(), false);
    });
  }
  refinement(e, t2) {
    return this._refinement((r, n2) => e(r) ? true : (n2.addIssue(typeof t2 == "function" ? t2(r, n2) : t2), false));
  }
  _refinement(e) {
    return new C({ schema: this, typeName: p2.ZodEffects, effect: { type: "refinement", refinement: e } });
  }
  superRefine(e) {
    return this._refinement(e);
  }
  optional() {
    return E3.create(this, this._def);
  }
  nullable() {
    return $.create(this, this._def);
  }
  nullish() {
    return this.nullable().optional();
  }
  array() {
    return S.create(this, this._def);
  }
  promise() {
    return D2.create(this, this._def);
  }
  or(e) {
    return q.create([this, e], this._def);
  }
  and(e) {
    return J.create(this, e, this._def);
  }
  transform(e) {
    return new C({ ...y2(this._def), schema: this, typeName: p2.ZodEffects, effect: { type: "transform", transform: e } });
  }
  default(e) {
    let t2 = typeof e == "function" ? e : () => e;
    return new K({ ...y2(this._def), innerType: this, defaultValue: t2, typeName: p2.ZodDefault });
  }
  brand() {
    return new he({ typeName: p2.ZodBranded, type: this, ...y2(this._def) });
  }
  catch(e) {
    let t2 = typeof e == "function" ? e : () => e;
    return new ae({ ...y2(this._def), innerType: this, catchValue: t2, typeName: p2.ZodCatch });
  }
  describe(e) {
    let t2 = this.constructor;
    return new t2({ ...this._def, description: e });
  }
  pipe(e) {
    return Q.create(this, e);
  }
  isOptional() {
    return this.safeParse(void 0).success;
  }
  isNullable() {
    return this.safeParse(null).success;
  }
};
var je = /^c[^\s-]{8,}$/i;
var Re = /^[a-z][a-z0-9]*$/;
var Ae = /[0-9A-HJKMNP-TV-Z]{26}/;
var Ze = /^([a-f0-9]{8}-[a-f0-9]{4}-[1-5][a-f0-9]{3}-[a-f0-9]{4}-[a-f0-9]{12}|00000000-0000-0000-0000-000000000000)$/i;
var Me = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[(((25[0-5])|(2[0-4][0-9])|(1[0-9]{2})|([0-9]{1,2}))\.){3}((25[0-5])|(2[0-4][0-9])|(1[0-9]{2})|([0-9]{1,2}))\])|(\[IPv6:(([a-f0-9]{1,4}:){7}|::([a-f0-9]{1,4}:){0,6}|([a-f0-9]{1,4}:){1}:([a-f0-9]{1,4}:){0,5}|([a-f0-9]{1,4}:){2}:([a-f0-9]{1,4}:){0,4}|([a-f0-9]{1,4}:){3}:([a-f0-9]{1,4}:){0,3}|([a-f0-9]{1,4}:){4}:([a-f0-9]{1,4}:){0,2}|([a-f0-9]{1,4}:){5}:([a-f0-9]{1,4}:){0,1})([a-f0-9]{1,4}|(((25[0-5])|(2[0-4][0-9])|(1[0-9]{2})|([0-9]{1,2}))\.){3}((25[0-5])|(2[0-4][0-9])|(1[0-9]{2})|([0-9]{1,2})))\])|([A-Za-z0-9]([A-Za-z0-9-]*[A-Za-z0-9])*(\.[A-Za-z]{2,})+))$/;
var Ve = /^(\p{Extended_Pictographic}|\p{Emoji_Component})+$/u;
var $e = /^(((25[0-5])|(2[0-4][0-9])|(1[0-9]{2})|([0-9]{1,2}))\.){3}((25[0-5])|(2[0-4][0-9])|(1[0-9]{2})|([0-9]{1,2}))$/;
var Pe = /^(([a-f0-9]{1,4}:){7}|::([a-f0-9]{1,4}:){0,6}|([a-f0-9]{1,4}:){1}:([a-f0-9]{1,4}:){0,5}|([a-f0-9]{1,4}:){2}:([a-f0-9]{1,4}:){0,4}|([a-f0-9]{1,4}:){3}:([a-f0-9]{1,4}:){0,3}|([a-f0-9]{1,4}:){4}:([a-f0-9]{1,4}:){0,2}|([a-f0-9]{1,4}:){5}:([a-f0-9]{1,4}:){0,1})([a-f0-9]{1,4}|(((25[0-5])|(2[0-4][0-9])|(1[0-9]{2})|([0-9]{1,2}))\.){3}((25[0-5])|(2[0-4][0-9])|(1[0-9]{2})|([0-9]{1,2})))$/;
var Le = (s2) => s2.precision ? s2.offset ? new RegExp(`^\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}:\\d{2}\\.\\d{${s2.precision}}(([+-]\\d{2}(:?\\d{2})?)|Z)$`) : new RegExp(`^\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}:\\d{2}\\.\\d{${s2.precision}}Z$`) : s2.precision === 0 ? s2.offset ? new RegExp("^\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}:\\d{2}(([+-]\\d{2}(:?\\d{2})?)|Z)$") : new RegExp("^\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}:\\d{2}Z$") : s2.offset ? new RegExp("^\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}:\\d{2}(\\.\\d+)?(([+-]\\d{2}(:?\\d{2})?)|Z)$") : new RegExp("^\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}:\\d{2}(\\.\\d+)?Z$");
function ze(s2, e) {
  return !!((e === "v4" || !e) && $e.test(s2) || (e === "v6" || !e) && Pe.test(s2));
}
var w = class extends v2 {
  constructor() {
    super(...arguments), this._regex = (e, t2, r) => this.refinement((n2) => e.test(n2), { validation: t2, code: c2.invalid_string, ...h2.errToObj(r) }), this.nonempty = (e) => this.min(1, h2.errToObj(e)), this.trim = () => new w({ ...this._def, checks: [...this._def.checks, { kind: "trim" }] }), this.toLowerCase = () => new w({ ...this._def, checks: [...this._def.checks, { kind: "toLowerCase" }] }), this.toUpperCase = () => new w({ ...this._def, checks: [...this._def.checks, { kind: "toUpperCase" }] });
  }
  _parse(e) {
    if (this._def.coerce && (e.data = String(e.data)), this._getType(e) !== d2.string) {
      let a3 = this._getOrReturnCtx(e);
      return u3(a3, { code: c2.invalid_type, expected: d2.string, received: a3.parsedType }), m3;
    }
    let r = new k2(), n2;
    for (let a3 of this._def.checks)
      if (a3.kind === "min")
        e.data.length < a3.value && (n2 = this._getOrReturnCtx(e, n2), u3(n2, { code: c2.too_small, minimum: a3.value, type: "string", inclusive: true, exact: false, message: a3.message }), r.dirty());
      else if (a3.kind === "max")
        e.data.length > a3.value && (n2 = this._getOrReturnCtx(e, n2), u3(n2, { code: c2.too_big, maximum: a3.value, type: "string", inclusive: true, exact: false, message: a3.message }), r.dirty());
      else if (a3.kind === "length") {
        let i2 = e.data.length > a3.value, o = e.data.length < a3.value;
        (i2 || o) && (n2 = this._getOrReturnCtx(e, n2), i2 ? u3(n2, { code: c2.too_big, maximum: a3.value, type: "string", inclusive: true, exact: true, message: a3.message }) : o && u3(n2, { code: c2.too_small, minimum: a3.value, type: "string", inclusive: true, exact: true, message: a3.message }), r.dirty());
      } else if (a3.kind === "email")
        Me.test(e.data) || (n2 = this._getOrReturnCtx(e, n2), u3(n2, { validation: "email", code: c2.invalid_string, message: a3.message }), r.dirty());
      else if (a3.kind === "emoji")
        Ve.test(e.data) || (n2 = this._getOrReturnCtx(e, n2), u3(n2, { validation: "emoji", code: c2.invalid_string, message: a3.message }), r.dirty());
      else if (a3.kind === "uuid")
        Ze.test(e.data) || (n2 = this._getOrReturnCtx(e, n2), u3(n2, { validation: "uuid", code: c2.invalid_string, message: a3.message }), r.dirty());
      else if (a3.kind === "cuid")
        je.test(e.data) || (n2 = this._getOrReturnCtx(e, n2), u3(n2, { validation: "cuid", code: c2.invalid_string, message: a3.message }), r.dirty());
      else if (a3.kind === "cuid2")
        Re.test(e.data) || (n2 = this._getOrReturnCtx(e, n2), u3(n2, { validation: "cuid2", code: c2.invalid_string, message: a3.message }), r.dirty());
      else if (a3.kind === "ulid")
        Ae.test(e.data) || (n2 = this._getOrReturnCtx(e, n2), u3(n2, { validation: "ulid", code: c2.invalid_string, message: a3.message }), r.dirty());
      else if (a3.kind === "url")
        try {
          new URL(e.data);
        } catch {
          n2 = this._getOrReturnCtx(e, n2), u3(n2, { validation: "url", code: c2.invalid_string, message: a3.message }), r.dirty();
        }
      else
        a3.kind === "regex" ? (a3.regex.lastIndex = 0, a3.regex.test(e.data) || (n2 = this._getOrReturnCtx(e, n2), u3(n2, { validation: "regex", code: c2.invalid_string, message: a3.message }), r.dirty())) : a3.kind === "trim" ? e.data = e.data.trim() : a3.kind === "includes" ? e.data.includes(a3.value, a3.position) || (n2 = this._getOrReturnCtx(e, n2), u3(n2, { code: c2.invalid_string, validation: { includes: a3.value, position: a3.position }, message: a3.message }), r.dirty()) : a3.kind === "toLowerCase" ? e.data = e.data.toLowerCase() : a3.kind === "toUpperCase" ? e.data = e.data.toUpperCase() : a3.kind === "startsWith" ? e.data.startsWith(a3.value) || (n2 = this._getOrReturnCtx(e, n2), u3(n2, { code: c2.invalid_string, validation: { startsWith: a3.value }, message: a3.message }), r.dirty()) : a3.kind === "endsWith" ? e.data.endsWith(a3.value) || (n2 = this._getOrReturnCtx(e, n2), u3(n2, { code: c2.invalid_string, validation: { endsWith: a3.value }, message: a3.message }), r.dirty()) : a3.kind === "datetime" ? Le(a3).test(e.data) || (n2 = this._getOrReturnCtx(e, n2), u3(n2, { code: c2.invalid_string, validation: "datetime", message: a3.message }), r.dirty()) : a3.kind === "ip" ? ze(e.data, a3.version) || (n2 = this._getOrReturnCtx(e, n2), u3(n2, { validation: "ip", code: c2.invalid_string, message: a3.message }), r.dirty()) : g2.assertNever(a3);
    return { status: r.value, value: e.data };
  }
  _addCheck(e) {
    return new w({ ...this._def, checks: [...this._def.checks, e] });
  }
  email(e) {
    return this._addCheck({ kind: "email", ...h2.errToObj(e) });
  }
  url(e) {
    return this._addCheck({ kind: "url", ...h2.errToObj(e) });
  }
  emoji(e) {
    return this._addCheck({ kind: "emoji", ...h2.errToObj(e) });
  }
  uuid(e) {
    return this._addCheck({ kind: "uuid", ...h2.errToObj(e) });
  }
  cuid(e) {
    return this._addCheck({ kind: "cuid", ...h2.errToObj(e) });
  }
  cuid2(e) {
    return this._addCheck({ kind: "cuid2", ...h2.errToObj(e) });
  }
  ulid(e) {
    return this._addCheck({ kind: "ulid", ...h2.errToObj(e) });
  }
  ip(e) {
    return this._addCheck({ kind: "ip", ...h2.errToObj(e) });
  }
  datetime(e) {
    var t2;
    return typeof e == "string" ? this._addCheck({ kind: "datetime", precision: null, offset: false, message: e }) : this._addCheck({ kind: "datetime", precision: typeof e?.precision > "u" ? null : e?.precision, offset: (t2 = e?.offset) !== null && t2 !== void 0 ? t2 : false, ...h2.errToObj(e?.message) });
  }
  regex(e, t2) {
    return this._addCheck({ kind: "regex", regex: e, ...h2.errToObj(t2) });
  }
  includes(e, t2) {
    return this._addCheck({ kind: "includes", value: e, position: t2?.position, ...h2.errToObj(t2?.message) });
  }
  startsWith(e, t2) {
    return this._addCheck({ kind: "startsWith", value: e, ...h2.errToObj(t2) });
  }
  endsWith(e, t2) {
    return this._addCheck({ kind: "endsWith", value: e, ...h2.errToObj(t2) });
  }
  min(e, t2) {
    return this._addCheck({ kind: "min", value: e, ...h2.errToObj(t2) });
  }
  max(e, t2) {
    return this._addCheck({ kind: "max", value: e, ...h2.errToObj(t2) });
  }
  length(e, t2) {
    return this._addCheck({ kind: "length", value: e, ...h2.errToObj(t2) });
  }
  get isDatetime() {
    return !!this._def.checks.find((e) => e.kind === "datetime");
  }
  get isEmail() {
    return !!this._def.checks.find((e) => e.kind === "email");
  }
  get isURL() {
    return !!this._def.checks.find((e) => e.kind === "url");
  }
  get isEmoji() {
    return !!this._def.checks.find((e) => e.kind === "emoji");
  }
  get isUUID() {
    return !!this._def.checks.find((e) => e.kind === "uuid");
  }
  get isCUID() {
    return !!this._def.checks.find((e) => e.kind === "cuid");
  }
  get isCUID2() {
    return !!this._def.checks.find((e) => e.kind === "cuid2");
  }
  get isULID() {
    return !!this._def.checks.find((e) => e.kind === "ulid");
  }
  get isIP() {
    return !!this._def.checks.find((e) => e.kind === "ip");
  }
  get minLength() {
    let e = null;
    for (let t2 of this._def.checks)
      t2.kind === "min" && (e === null || t2.value > e) && (e = t2.value);
    return e;
  }
  get maxLength() {
    let e = null;
    for (let t2 of this._def.checks)
      t2.kind === "max" && (e === null || t2.value < e) && (e = t2.value);
    return e;
  }
};
w.create = (s2) => {
  var e;
  return new w({ checks: [], typeName: p2.ZodString, coerce: (e = s2?.coerce) !== null && e !== void 0 ? e : false, ...y2(s2) });
};
function De(s2, e) {
  let t2 = (s2.toString().split(".")[1] || "").length, r = (e.toString().split(".")[1] || "").length, n2 = t2 > r ? t2 : r, a3 = parseInt(s2.toFixed(n2).replace(".", "")), i2 = parseInt(e.toFixed(n2).replace(".", ""));
  return a3 % i2 / Math.pow(10, n2);
}
var j2 = class extends v2 {
  constructor() {
    super(...arguments), this.min = this.gte, this.max = this.lte, this.step = this.multipleOf;
  }
  _parse(e) {
    if (this._def.coerce && (e.data = Number(e.data)), this._getType(e) !== d2.number) {
      let a3 = this._getOrReturnCtx(e);
      return u3(a3, { code: c2.invalid_type, expected: d2.number, received: a3.parsedType }), m3;
    }
    let r, n2 = new k2();
    for (let a3 of this._def.checks)
      a3.kind === "int" ? g2.isInteger(e.data) || (r = this._getOrReturnCtx(e, r), u3(r, { code: c2.invalid_type, expected: "integer", received: "float", message: a3.message }), n2.dirty()) : a3.kind === "min" ? (a3.inclusive ? e.data < a3.value : e.data <= a3.value) && (r = this._getOrReturnCtx(e, r), u3(r, { code: c2.too_small, minimum: a3.value, type: "number", inclusive: a3.inclusive, exact: false, message: a3.message }), n2.dirty()) : a3.kind === "max" ? (a3.inclusive ? e.data > a3.value : e.data >= a3.value) && (r = this._getOrReturnCtx(e, r), u3(r, { code: c2.too_big, maximum: a3.value, type: "number", inclusive: a3.inclusive, exact: false, message: a3.message }), n2.dirty()) : a3.kind === "multipleOf" ? De(e.data, a3.value) !== 0 && (r = this._getOrReturnCtx(e, r), u3(r, { code: c2.not_multiple_of, multipleOf: a3.value, message: a3.message }), n2.dirty()) : a3.kind === "finite" ? Number.isFinite(e.data) || (r = this._getOrReturnCtx(e, r), u3(r, { code: c2.not_finite, message: a3.message }), n2.dirty()) : g2.assertNever(a3);
    return { status: n2.value, value: e.data };
  }
  gte(e, t2) {
    return this.setLimit("min", e, true, h2.toString(t2));
  }
  gt(e, t2) {
    return this.setLimit("min", e, false, h2.toString(t2));
  }
  lte(e, t2) {
    return this.setLimit("max", e, true, h2.toString(t2));
  }
  lt(e, t2) {
    return this.setLimit("max", e, false, h2.toString(t2));
  }
  setLimit(e, t2, r, n2) {
    return new j2({ ...this._def, checks: [...this._def.checks, { kind: e, value: t2, inclusive: r, message: h2.toString(n2) }] });
  }
  _addCheck(e) {
    return new j2({ ...this._def, checks: [...this._def.checks, e] });
  }
  int(e) {
    return this._addCheck({ kind: "int", message: h2.toString(e) });
  }
  positive(e) {
    return this._addCheck({ kind: "min", value: 0, inclusive: false, message: h2.toString(e) });
  }
  negative(e) {
    return this._addCheck({ kind: "max", value: 0, inclusive: false, message: h2.toString(e) });
  }
  nonpositive(e) {
    return this._addCheck({ kind: "max", value: 0, inclusive: true, message: h2.toString(e) });
  }
  nonnegative(e) {
    return this._addCheck({ kind: "min", value: 0, inclusive: true, message: h2.toString(e) });
  }
  multipleOf(e, t2) {
    return this._addCheck({ kind: "multipleOf", value: e, message: h2.toString(t2) });
  }
  finite(e) {
    return this._addCheck({ kind: "finite", message: h2.toString(e) });
  }
  safe(e) {
    return this._addCheck({ kind: "min", inclusive: true, value: Number.MIN_SAFE_INTEGER, message: h2.toString(e) })._addCheck({ kind: "max", inclusive: true, value: Number.MAX_SAFE_INTEGER, message: h2.toString(e) });
  }
  get minValue() {
    let e = null;
    for (let t2 of this._def.checks)
      t2.kind === "min" && (e === null || t2.value > e) && (e = t2.value);
    return e;
  }
  get maxValue() {
    let e = null;
    for (let t2 of this._def.checks)
      t2.kind === "max" && (e === null || t2.value < e) && (e = t2.value);
    return e;
  }
  get isInt() {
    return !!this._def.checks.find((e) => e.kind === "int" || e.kind === "multipleOf" && g2.isInteger(e.value));
  }
  get isFinite() {
    let e = null, t2 = null;
    for (let r of this._def.checks) {
      if (r.kind === "finite" || r.kind === "int" || r.kind === "multipleOf")
        return true;
      r.kind === "min" ? (t2 === null || r.value > t2) && (t2 = r.value) : r.kind === "max" && (e === null || r.value < e) && (e = r.value);
    }
    return Number.isFinite(t2) && Number.isFinite(e);
  }
};
j2.create = (s2) => new j2({ checks: [], typeName: p2.ZodNumber, coerce: s2?.coerce || false, ...y2(s2) });
var R2 = class extends v2 {
  constructor() {
    super(...arguments), this.min = this.gte, this.max = this.lte;
  }
  _parse(e) {
    if (this._def.coerce && (e.data = BigInt(e.data)), this._getType(e) !== d2.bigint) {
      let a3 = this._getOrReturnCtx(e);
      return u3(a3, { code: c2.invalid_type, expected: d2.bigint, received: a3.parsedType }), m3;
    }
    let r, n2 = new k2();
    for (let a3 of this._def.checks)
      a3.kind === "min" ? (a3.inclusive ? e.data < a3.value : e.data <= a3.value) && (r = this._getOrReturnCtx(e, r), u3(r, { code: c2.too_small, type: "bigint", minimum: a3.value, inclusive: a3.inclusive, message: a3.message }), n2.dirty()) : a3.kind === "max" ? (a3.inclusive ? e.data > a3.value : e.data >= a3.value) && (r = this._getOrReturnCtx(e, r), u3(r, { code: c2.too_big, type: "bigint", maximum: a3.value, inclusive: a3.inclusive, message: a3.message }), n2.dirty()) : a3.kind === "multipleOf" ? e.data % a3.value !== BigInt(0) && (r = this._getOrReturnCtx(e, r), u3(r, { code: c2.not_multiple_of, multipleOf: a3.value, message: a3.message }), n2.dirty()) : g2.assertNever(a3);
    return { status: n2.value, value: e.data };
  }
  gte(e, t2) {
    return this.setLimit("min", e, true, h2.toString(t2));
  }
  gt(e, t2) {
    return this.setLimit("min", e, false, h2.toString(t2));
  }
  lte(e, t2) {
    return this.setLimit("max", e, true, h2.toString(t2));
  }
  lt(e, t2) {
    return this.setLimit("max", e, false, h2.toString(t2));
  }
  setLimit(e, t2, r, n2) {
    return new R2({ ...this._def, checks: [...this._def.checks, { kind: e, value: t2, inclusive: r, message: h2.toString(n2) }] });
  }
  _addCheck(e) {
    return new R2({ ...this._def, checks: [...this._def.checks, e] });
  }
  positive(e) {
    return this._addCheck({ kind: "min", value: BigInt(0), inclusive: false, message: h2.toString(e) });
  }
  negative(e) {
    return this._addCheck({ kind: "max", value: BigInt(0), inclusive: false, message: h2.toString(e) });
  }
  nonpositive(e) {
    return this._addCheck({ kind: "max", value: BigInt(0), inclusive: true, message: h2.toString(e) });
  }
  nonnegative(e) {
    return this._addCheck({ kind: "min", value: BigInt(0), inclusive: true, message: h2.toString(e) });
  }
  multipleOf(e, t2) {
    return this._addCheck({ kind: "multipleOf", value: e, message: h2.toString(t2) });
  }
  get minValue() {
    let e = null;
    for (let t2 of this._def.checks)
      t2.kind === "min" && (e === null || t2.value > e) && (e = t2.value);
    return e;
  }
  get maxValue() {
    let e = null;
    for (let t2 of this._def.checks)
      t2.kind === "max" && (e === null || t2.value < e) && (e = t2.value);
    return e;
  }
};
R2.create = (s2) => {
  var e;
  return new R2({ checks: [], typeName: p2.ZodBigInt, coerce: (e = s2?.coerce) !== null && e !== void 0 ? e : false, ...y2(s2) });
};
var U = class extends v2 {
  _parse(e) {
    if (this._def.coerce && (e.data = !!e.data), this._getType(e) !== d2.boolean) {
      let r = this._getOrReturnCtx(e);
      return u3(r, { code: c2.invalid_type, expected: d2.boolean, received: r.parsedType }), m3;
    }
    return b3(e.data);
  }
};
U.create = (s2) => new U({ typeName: p2.ZodBoolean, coerce: s2?.coerce || false, ...y2(s2) });
var M = class extends v2 {
  _parse(e) {
    if (this._def.coerce && (e.data = new Date(e.data)), this._getType(e) !== d2.date) {
      let a3 = this._getOrReturnCtx(e);
      return u3(a3, { code: c2.invalid_type, expected: d2.date, received: a3.parsedType }), m3;
    }
    if (isNaN(e.data.getTime())) {
      let a3 = this._getOrReturnCtx(e);
      return u3(a3, { code: c2.invalid_date }), m3;
    }
    let r = new k2(), n2;
    for (let a3 of this._def.checks)
      a3.kind === "min" ? e.data.getTime() < a3.value && (n2 = this._getOrReturnCtx(e, n2), u3(n2, { code: c2.too_small, message: a3.message, inclusive: true, exact: false, minimum: a3.value, type: "date" }), r.dirty()) : a3.kind === "max" ? e.data.getTime() > a3.value && (n2 = this._getOrReturnCtx(e, n2), u3(n2, { code: c2.too_big, message: a3.message, inclusive: true, exact: false, maximum: a3.value, type: "date" }), r.dirty()) : g2.assertNever(a3);
    return { status: r.value, value: new Date(e.data.getTime()) };
  }
  _addCheck(e) {
    return new M({ ...this._def, checks: [...this._def.checks, e] });
  }
  min(e, t2) {
    return this._addCheck({ kind: "min", value: e.getTime(), message: h2.toString(t2) });
  }
  max(e, t2) {
    return this._addCheck({ kind: "max", value: e.getTime(), message: h2.toString(t2) });
  }
  get minDate() {
    let e = null;
    for (let t2 of this._def.checks)
      t2.kind === "min" && (e === null || t2.value > e) && (e = t2.value);
    return e != null ? new Date(e) : null;
  }
  get maxDate() {
    let e = null;
    for (let t2 of this._def.checks)
      t2.kind === "max" && (e === null || t2.value < e) && (e = t2.value);
    return e != null ? new Date(e) : null;
  }
};
M.create = (s2) => new M({ checks: [], coerce: s2?.coerce || false, typeName: p2.ZodDate, ...y2(s2) });
var te = class extends v2 {
  _parse(e) {
    if (this._getType(e) !== d2.symbol) {
      let r = this._getOrReturnCtx(e);
      return u3(r, { code: c2.invalid_type, expected: d2.symbol, received: r.parsedType }), m3;
    }
    return b3(e.data);
  }
};
te.create = (s2) => new te({ typeName: p2.ZodSymbol, ...y2(s2) });
var B = class extends v2 {
  _parse(e) {
    if (this._getType(e) !== d2.undefined) {
      let r = this._getOrReturnCtx(e);
      return u3(r, { code: c2.invalid_type, expected: d2.undefined, received: r.parsedType }), m3;
    }
    return b3(e.data);
  }
};
B.create = (s2) => new B({ typeName: p2.ZodUndefined, ...y2(s2) });
var W2 = class extends v2 {
  _parse(e) {
    if (this._getType(e) !== d2.null) {
      let r = this._getOrReturnCtx(e);
      return u3(r, { code: c2.invalid_type, expected: d2.null, received: r.parsedType }), m3;
    }
    return b3(e.data);
  }
};
W2.create = (s2) => new W2({ typeName: p2.ZodNull, ...y2(s2) });
var z = class extends v2 {
  constructor() {
    super(...arguments), this._any = true;
  }
  _parse(e) {
    return b3(e.data);
  }
};
z.create = (s2) => new z({ typeName: p2.ZodAny, ...y2(s2) });
var Z = class extends v2 {
  constructor() {
    super(...arguments), this._unknown = true;
  }
  _parse(e) {
    return b3(e.data);
  }
};
Z.create = (s2) => new Z({ typeName: p2.ZodUnknown, ...y2(s2) });
var I = class extends v2 {
  _parse(e) {
    let t2 = this._getOrReturnCtx(e);
    return u3(t2, { code: c2.invalid_type, expected: d2.never, received: t2.parsedType }), m3;
  }
};
I.create = (s2) => new I({ typeName: p2.ZodNever, ...y2(s2) });
var se = class extends v2 {
  _parse(e) {
    if (this._getType(e) !== d2.undefined) {
      let r = this._getOrReturnCtx(e);
      return u3(r, { code: c2.invalid_type, expected: d2.void, received: r.parsedType }), m3;
    }
    return b3(e.data);
  }
};
se.create = (s2) => new se({ typeName: p2.ZodVoid, ...y2(s2) });
var S = class extends v2 {
  _parse(e) {
    let { ctx: t2, status: r } = this._processInputParams(e), n2 = this._def;
    if (t2.parsedType !== d2.array)
      return u3(t2, { code: c2.invalid_type, expected: d2.array, received: t2.parsedType }), m3;
    if (n2.exactLength !== null) {
      let i2 = t2.data.length > n2.exactLength.value, o = t2.data.length < n2.exactLength.value;
      (i2 || o) && (u3(t2, { code: i2 ? c2.too_big : c2.too_small, minimum: o ? n2.exactLength.value : void 0, maximum: i2 ? n2.exactLength.value : void 0, type: "array", inclusive: true, exact: true, message: n2.exactLength.message }), r.dirty());
    }
    if (n2.minLength !== null && t2.data.length < n2.minLength.value && (u3(t2, { code: c2.too_small, minimum: n2.minLength.value, type: "array", inclusive: true, exact: false, message: n2.minLength.message }), r.dirty()), n2.maxLength !== null && t2.data.length > n2.maxLength.value && (u3(t2, { code: c2.too_big, maximum: n2.maxLength.value, type: "array", inclusive: true, exact: false, message: n2.maxLength.message }), r.dirty()), t2.common.async)
      return Promise.all([...t2.data].map((i2, o) => n2.type._parseAsync(new O2(t2, i2, t2.path, o)))).then((i2) => k2.mergeArray(r, i2));
    let a3 = [...t2.data].map((i2, o) => n2.type._parseSync(new O2(t2, i2, t2.path, o)));
    return k2.mergeArray(r, a3);
  }
  get element() {
    return this._def.type;
  }
  min(e, t2) {
    return new S({ ...this._def, minLength: { value: e, message: h2.toString(t2) } });
  }
  max(e, t2) {
    return new S({ ...this._def, maxLength: { value: e, message: h2.toString(t2) } });
  }
  length(e, t2) {
    return new S({ ...this._def, exactLength: { value: e, message: h2.toString(t2) } });
  }
  nonempty(e) {
    return this.min(1, e);
  }
};
S.create = (s2, e) => new S({ type: s2, minLength: null, maxLength: null, exactLength: null, typeName: p2.ZodArray, ...y2(e) });
function ee(s2) {
  if (s2 instanceof x3) {
    let e = {};
    for (let t2 in s2.shape) {
      let r = s2.shape[t2];
      e[t2] = E3.create(ee(r));
    }
    return new x3({ ...s2._def, shape: () => e });
  } else
    return s2 instanceof S ? new S({ ...s2._def, type: ee(s2.element) }) : s2 instanceof E3 ? E3.create(ee(s2.unwrap())) : s2 instanceof $ ? $.create(ee(s2.unwrap())) : s2 instanceof N ? N.create(s2.items.map((e) => ee(e))) : s2;
}
var x3 = class extends v2 {
  constructor() {
    super(...arguments), this._cached = null, this.nonstrict = this.passthrough, this.augment = this.extend;
  }
  _getCached() {
    if (this._cached !== null)
      return this._cached;
    let e = this._def.shape(), t2 = g2.objectKeys(e);
    return this._cached = { shape: e, keys: t2 };
  }
  _parse(e) {
    if (this._getType(e) !== d2.object) {
      let l2 = this._getOrReturnCtx(e);
      return u3(l2, { code: c2.invalid_type, expected: d2.object, received: l2.parsedType }), m3;
    }
    let { status: r, ctx: n2 } = this._processInputParams(e), { shape: a3, keys: i2 } = this._getCached(), o = [];
    if (!(this._def.catchall instanceof I && this._def.unknownKeys === "strip"))
      for (let l2 in n2.data)
        i2.includes(l2) || o.push(l2);
    let f2 = [];
    for (let l2 of i2) {
      let _ = a3[l2], F2 = n2.data[l2];
      f2.push({ key: { status: "valid", value: l2 }, value: _._parse(new O2(n2, F2, n2.path, l2)), alwaysSet: l2 in n2.data });
    }
    if (this._def.catchall instanceof I) {
      let l2 = this._def.unknownKeys;
      if (l2 === "passthrough")
        for (let _ of o)
          f2.push({ key: { status: "valid", value: _ }, value: { status: "valid", value: n2.data[_] } });
      else if (l2 === "strict")
        o.length > 0 && (u3(n2, { code: c2.unrecognized_keys, keys: o }), r.dirty());
      else if (l2 !== "strip")
        throw new Error("Internal ZodObject error: invalid unknownKeys value.");
    } else {
      let l2 = this._def.catchall;
      for (let _ of o) {
        let F2 = n2.data[_];
        f2.push({ key: { status: "valid", value: _ }, value: l2._parse(new O2(n2, F2, n2.path, _)), alwaysSet: _ in n2.data });
      }
    }
    return n2.common.async ? Promise.resolve().then(async () => {
      let l2 = [];
      for (let _ of f2) {
        let F2 = await _.key;
        l2.push({ key: F2, value: await _.value, alwaysSet: _.alwaysSet });
      }
      return l2;
    }).then((l2) => k2.mergeObjectSync(r, l2)) : k2.mergeObjectSync(r, f2);
  }
  get shape() {
    return this._def.shape();
  }
  strict(e) {
    return h2.errToObj, new x3({ ...this._def, unknownKeys: "strict", ...e !== void 0 ? { errorMap: (t2, r) => {
      var n2, a3, i2, o;
      let f2 = (i2 = (a3 = (n2 = this._def).errorMap) === null || a3 === void 0 ? void 0 : a3.call(n2, t2, r).message) !== null && i2 !== void 0 ? i2 : r.defaultError;
      return t2.code === "unrecognized_keys" ? { message: (o = h2.errToObj(e).message) !== null && o !== void 0 ? o : f2 } : { message: f2 };
    } } : {} });
  }
  strip() {
    return new x3({ ...this._def, unknownKeys: "strip" });
  }
  passthrough() {
    return new x3({ ...this._def, unknownKeys: "passthrough" });
  }
  extend(e) {
    return new x3({ ...this._def, shape: () => ({ ...this._def.shape(), ...e }) });
  }
  merge(e) {
    return new x3({ unknownKeys: e._def.unknownKeys, catchall: e._def.catchall, shape: () => ({ ...this._def.shape(), ...e._def.shape() }), typeName: p2.ZodObject });
  }
  setKey(e, t2) {
    return this.augment({ [e]: t2 });
  }
  catchall(e) {
    return new x3({ ...this._def, catchall: e });
  }
  pick(e) {
    let t2 = {};
    return g2.objectKeys(e).forEach((r) => {
      e[r] && this.shape[r] && (t2[r] = this.shape[r]);
    }), new x3({ ...this._def, shape: () => t2 });
  }
  omit(e) {
    let t2 = {};
    return g2.objectKeys(this.shape).forEach((r) => {
      e[r] || (t2[r] = this.shape[r]);
    }), new x3({ ...this._def, shape: () => t2 });
  }
  deepPartial() {
    return ee(this);
  }
  partial(e) {
    let t2 = {};
    return g2.objectKeys(this.shape).forEach((r) => {
      let n2 = this.shape[r];
      e && !e[r] ? t2[r] = n2 : t2[r] = n2.optional();
    }), new x3({ ...this._def, shape: () => t2 });
  }
  required(e) {
    let t2 = {};
    return g2.objectKeys(this.shape).forEach((r) => {
      if (e && !e[r])
        t2[r] = this.shape[r];
      else {
        let a3 = this.shape[r];
        for (; a3 instanceof E3; )
          a3 = a3._def.innerType;
        t2[r] = a3;
      }
    }), new x3({ ...this._def, shape: () => t2 });
  }
  keyof() {
    return we(g2.objectKeys(this.shape));
  }
};
x3.create = (s2, e) => new x3({ shape: () => s2, unknownKeys: "strip", catchall: I.create(), typeName: p2.ZodObject, ...y2(e) });
x3.strictCreate = (s2, e) => new x3({ shape: () => s2, unknownKeys: "strict", catchall: I.create(), typeName: p2.ZodObject, ...y2(e) });
x3.lazycreate = (s2, e) => new x3({ shape: s2, unknownKeys: "strip", catchall: I.create(), typeName: p2.ZodObject, ...y2(e) });
var q = class extends v2 {
  _parse(e) {
    let { ctx: t2 } = this._processInputParams(e), r = this._def.options;
    function n2(a3) {
      for (let o of a3)
        if (o.result.status === "valid")
          return o.result;
      for (let o of a3)
        if (o.result.status === "dirty")
          return t2.common.issues.push(...o.ctx.common.issues), o.result;
      let i2 = a3.map((o) => new T(o.ctx.common.issues));
      return u3(t2, { code: c2.invalid_union, unionErrors: i2 }), m3;
    }
    if (t2.common.async)
      return Promise.all(r.map(async (a3) => {
        let i2 = { ...t2, common: { ...t2.common, issues: [] }, parent: null };
        return { result: await a3._parseAsync({ data: t2.data, path: t2.path, parent: i2 }), ctx: i2 };
      })).then(n2);
    {
      let a3, i2 = [];
      for (let f2 of r) {
        let l2 = { ...t2, common: { ...t2.common, issues: [] }, parent: null }, _ = f2._parseSync({ data: t2.data, path: t2.path, parent: l2 });
        if (_.status === "valid")
          return _;
        _.status === "dirty" && !a3 && (a3 = { result: _, ctx: l2 }), l2.common.issues.length && i2.push(l2.common.issues);
      }
      if (a3)
        return t2.common.issues.push(...a3.ctx.common.issues), a3.result;
      let o = i2.map((f2) => new T(f2));
      return u3(t2, { code: c2.invalid_union, unionErrors: o }), m3;
    }
  }
  get options() {
    return this._def.options;
  }
};
q.create = (s2, e) => new q({ options: s2, typeName: p2.ZodUnion, ...y2(e) });
var ce = (s2) => s2 instanceof H ? ce(s2.schema) : s2 instanceof C ? ce(s2.innerType()) : s2 instanceof G ? [s2.value] : s2 instanceof A ? s2.options : s2 instanceof X ? Object.keys(s2.enum) : s2 instanceof K ? ce(s2._def.innerType) : s2 instanceof B ? [void 0] : s2 instanceof W2 ? [null] : null;
var re = class extends v2 {
  _parse(e) {
    let { ctx: t2 } = this._processInputParams(e);
    if (t2.parsedType !== d2.object)
      return u3(t2, { code: c2.invalid_type, expected: d2.object, received: t2.parsedType }), m3;
    let r = this.discriminator, n2 = t2.data[r], a3 = this.optionsMap.get(n2);
    return a3 ? t2.common.async ? a3._parseAsync({ data: t2.data, path: t2.path, parent: t2 }) : a3._parseSync({ data: t2.data, path: t2.path, parent: t2 }) : (u3(t2, { code: c2.invalid_union_discriminator, options: Array.from(this.optionsMap.keys()), path: [r] }), m3);
  }
  get discriminator() {
    return this._def.discriminator;
  }
  get options() {
    return this._def.options;
  }
  get optionsMap() {
    return this._def.optionsMap;
  }
  static create(e, t2, r) {
    let n2 = /* @__PURE__ */ new Map();
    for (let a3 of t2) {
      let i2 = ce(a3.shape[e]);
      if (!i2)
        throw new Error(`A discriminator value for key \`${e}\` could not be extracted from all schema options`);
      for (let o of i2) {
        if (n2.has(o))
          throw new Error(`Discriminator property ${String(e)} has duplicate value ${String(o)}`);
        n2.set(o, a3);
      }
    }
    return new re({ typeName: p2.ZodDiscriminatedUnion, discriminator: e, options: t2, optionsMap: n2, ...y2(r) });
  }
};
function _e(s2, e) {
  let t2 = P2(s2), r = P2(e);
  if (s2 === e)
    return { valid: true, data: s2 };
  if (t2 === d2.object && r === d2.object) {
    let n2 = g2.objectKeys(e), a3 = g2.objectKeys(s2).filter((o) => n2.indexOf(o) !== -1), i2 = { ...s2, ...e };
    for (let o of a3) {
      let f2 = _e(s2[o], e[o]);
      if (!f2.valid)
        return { valid: false };
      i2[o] = f2.data;
    }
    return { valid: true, data: i2 };
  } else if (t2 === d2.array && r === d2.array) {
    if (s2.length !== e.length)
      return { valid: false };
    let n2 = [];
    for (let a3 = 0; a3 < s2.length; a3++) {
      let i2 = s2[a3], o = e[a3], f2 = _e(i2, o);
      if (!f2.valid)
        return { valid: false };
      n2.push(f2.data);
    }
    return { valid: true, data: n2 };
  } else
    return t2 === d2.date && r === d2.date && +s2 == +e ? { valid: true, data: s2 } : { valid: false };
}
var J = class extends v2 {
  _parse(e) {
    let { status: t2, ctx: r } = this._processInputParams(e), n2 = (a3, i2) => {
      if (ye(a3) || ye(i2))
        return m3;
      let o = _e(a3.value, i2.value);
      return o.valid ? ((ve(a3) || ve(i2)) && t2.dirty(), { status: t2.value, value: o.data }) : (u3(r, { code: c2.invalid_intersection_types }), m3);
    };
    return r.common.async ? Promise.all([this._def.left._parseAsync({ data: r.data, path: r.path, parent: r }), this._def.right._parseAsync({ data: r.data, path: r.path, parent: r })]).then(([a3, i2]) => n2(a3, i2)) : n2(this._def.left._parseSync({ data: r.data, path: r.path, parent: r }), this._def.right._parseSync({ data: r.data, path: r.path, parent: r }));
  }
};
J.create = (s2, e, t2) => new J({ left: s2, right: e, typeName: p2.ZodIntersection, ...y2(t2) });
var N = class extends v2 {
  _parse(e) {
    let { status: t2, ctx: r } = this._processInputParams(e);
    if (r.parsedType !== d2.array)
      return u3(r, { code: c2.invalid_type, expected: d2.array, received: r.parsedType }), m3;
    if (r.data.length < this._def.items.length)
      return u3(r, { code: c2.too_small, minimum: this._def.items.length, inclusive: true, exact: false, type: "array" }), m3;
    !this._def.rest && r.data.length > this._def.items.length && (u3(r, { code: c2.too_big, maximum: this._def.items.length, inclusive: true, exact: false, type: "array" }), t2.dirty());
    let a3 = [...r.data].map((i2, o) => {
      let f2 = this._def.items[o] || this._def.rest;
      return f2 ? f2._parse(new O2(r, i2, r.path, o)) : null;
    }).filter((i2) => !!i2);
    return r.common.async ? Promise.all(a3).then((i2) => k2.mergeArray(t2, i2)) : k2.mergeArray(t2, a3);
  }
  get items() {
    return this._def.items;
  }
  rest(e) {
    return new N({ ...this._def, rest: e });
  }
};
N.create = (s2, e) => {
  if (!Array.isArray(s2))
    throw new Error("You must pass an array of schemas to z.tuple([ ... ])");
  return new N({ items: s2, typeName: p2.ZodTuple, rest: null, ...y2(e) });
};
var Y = class extends v2 {
  get keySchema() {
    return this._def.keyType;
  }
  get valueSchema() {
    return this._def.valueType;
  }
  _parse(e) {
    let { status: t2, ctx: r } = this._processInputParams(e);
    if (r.parsedType !== d2.object)
      return u3(r, { code: c2.invalid_type, expected: d2.object, received: r.parsedType }), m3;
    let n2 = [], a3 = this._def.keyType, i2 = this._def.valueType;
    for (let o in r.data)
      n2.push({ key: a3._parse(new O2(r, o, r.path, o)), value: i2._parse(new O2(r, r.data[o], r.path, o)) });
    return r.common.async ? k2.mergeObjectAsync(t2, n2) : k2.mergeObjectSync(t2, n2);
  }
  get element() {
    return this._def.valueType;
  }
  static create(e, t2, r) {
    return t2 instanceof v2 ? new Y({ keyType: e, valueType: t2, typeName: p2.ZodRecord, ...y2(r) }) : new Y({ keyType: w.create(), valueType: e, typeName: p2.ZodRecord, ...y2(t2) });
  }
};
var ne = class extends v2 {
  _parse(e) {
    let { status: t2, ctx: r } = this._processInputParams(e);
    if (r.parsedType !== d2.map)
      return u3(r, { code: c2.invalid_type, expected: d2.map, received: r.parsedType }), m3;
    let n2 = this._def.keyType, a3 = this._def.valueType, i2 = [...r.data.entries()].map(([o, f2], l2) => ({ key: n2._parse(new O2(r, o, r.path, [l2, "key"])), value: a3._parse(new O2(r, f2, r.path, [l2, "value"])) }));
    if (r.common.async) {
      let o = /* @__PURE__ */ new Map();
      return Promise.resolve().then(async () => {
        for (let f2 of i2) {
          let l2 = await f2.key, _ = await f2.value;
          if (l2.status === "aborted" || _.status === "aborted")
            return m3;
          (l2.status === "dirty" || _.status === "dirty") && t2.dirty(), o.set(l2.value, _.value);
        }
        return { status: t2.value, value: o };
      });
    } else {
      let o = /* @__PURE__ */ new Map();
      for (let f2 of i2) {
        let l2 = f2.key, _ = f2.value;
        if (l2.status === "aborted" || _.status === "aborted")
          return m3;
        (l2.status === "dirty" || _.status === "dirty") && t2.dirty(), o.set(l2.value, _.value);
      }
      return { status: t2.value, value: o };
    }
  }
};
ne.create = (s2, e, t2) => new ne({ valueType: e, keyType: s2, typeName: p2.ZodMap, ...y2(t2) });
var V = class extends v2 {
  _parse(e) {
    let { status: t2, ctx: r } = this._processInputParams(e);
    if (r.parsedType !== d2.set)
      return u3(r, { code: c2.invalid_type, expected: d2.set, received: r.parsedType }), m3;
    let n2 = this._def;
    n2.minSize !== null && r.data.size < n2.minSize.value && (u3(r, { code: c2.too_small, minimum: n2.minSize.value, type: "set", inclusive: true, exact: false, message: n2.minSize.message }), t2.dirty()), n2.maxSize !== null && r.data.size > n2.maxSize.value && (u3(r, { code: c2.too_big, maximum: n2.maxSize.value, type: "set", inclusive: true, exact: false, message: n2.maxSize.message }), t2.dirty());
    let a3 = this._def.valueType;
    function i2(f2) {
      let l2 = /* @__PURE__ */ new Set();
      for (let _ of f2) {
        if (_.status === "aborted")
          return m3;
        _.status === "dirty" && t2.dirty(), l2.add(_.value);
      }
      return { status: t2.value, value: l2 };
    }
    let o = [...r.data.values()].map((f2, l2) => a3._parse(new O2(r, f2, r.path, l2)));
    return r.common.async ? Promise.all(o).then((f2) => i2(f2)) : i2(o);
  }
  min(e, t2) {
    return new V({ ...this._def, minSize: { value: e, message: h2.toString(t2) } });
  }
  max(e, t2) {
    return new V({ ...this._def, maxSize: { value: e, message: h2.toString(t2) } });
  }
  size(e, t2) {
    return this.min(e, t2).max(e, t2);
  }
  nonempty(e) {
    return this.min(1, e);
  }
};
V.create = (s2, e) => new V({ valueType: s2, minSize: null, maxSize: null, typeName: p2.ZodSet, ...y2(e) });
var L = class extends v2 {
  constructor() {
    super(...arguments), this.validate = this.implement;
  }
  _parse(e) {
    let { ctx: t2 } = this._processInputParams(e);
    if (t2.parsedType !== d2.function)
      return u3(t2, { code: c2.invalid_type, expected: d2.function, received: t2.parsedType }), m3;
    function r(o, f2) {
      return ue({ data: o, path: t2.path, errorMaps: [t2.common.contextualErrorMap, t2.schemaErrorMap, de(), oe].filter((l2) => !!l2), issueData: { code: c2.invalid_arguments, argumentsError: f2 } });
    }
    function n2(o, f2) {
      return ue({ data: o, path: t2.path, errorMaps: [t2.common.contextualErrorMap, t2.schemaErrorMap, de(), oe].filter((l2) => !!l2), issueData: { code: c2.invalid_return_type, returnTypeError: f2 } });
    }
    let a3 = { errorMap: t2.common.contextualErrorMap }, i2 = t2.data;
    return this._def.returns instanceof D2 ? b3(async (...o) => {
      let f2 = new T([]), l2 = await this._def.args.parseAsync(o, a3).catch((pe) => {
        throw f2.addIssue(r(o, pe)), f2;
      }), _ = await i2(...l2);
      return await this._def.returns._def.type.parseAsync(_, a3).catch((pe) => {
        throw f2.addIssue(n2(_, pe)), f2;
      });
    }) : b3((...o) => {
      let f2 = this._def.args.safeParse(o, a3);
      if (!f2.success)
        throw new T([r(o, f2.error)]);
      let l2 = i2(...f2.data), _ = this._def.returns.safeParse(l2, a3);
      if (!_.success)
        throw new T([n2(l2, _.error)]);
      return _.data;
    });
  }
  parameters() {
    return this._def.args;
  }
  returnType() {
    return this._def.returns;
  }
  args(...e) {
    return new L({ ...this._def, args: N.create(e).rest(Z.create()) });
  }
  returns(e) {
    return new L({ ...this._def, returns: e });
  }
  implement(e) {
    return this.parse(e);
  }
  strictImplement(e) {
    return this.parse(e);
  }
  static create(e, t2, r) {
    return new L({ args: e || N.create([]).rest(Z.create()), returns: t2 || Z.create(), typeName: p2.ZodFunction, ...y2(r) });
  }
};
var H = class extends v2 {
  get schema() {
    return this._def.getter();
  }
  _parse(e) {
    let { ctx: t2 } = this._processInputParams(e);
    return this._def.getter()._parse({ data: t2.data, path: t2.path, parent: t2 });
  }
};
H.create = (s2, e) => new H({ getter: s2, typeName: p2.ZodLazy, ...y2(e) });
var G = class extends v2 {
  _parse(e) {
    if (e.data !== this._def.value) {
      let t2 = this._getOrReturnCtx(e);
      return u3(t2, { received: t2.data, code: c2.invalid_literal, expected: this._def.value }), m3;
    }
    return { status: "valid", value: e.data };
  }
  get value() {
    return this._def.value;
  }
};
G.create = (s2, e) => new G({ value: s2, typeName: p2.ZodLiteral, ...y2(e) });
function we(s2, e) {
  return new A({ values: s2, typeName: p2.ZodEnum, ...y2(e) });
}
var A = class extends v2 {
  _parse(e) {
    if (typeof e.data != "string") {
      let t2 = this._getOrReturnCtx(e), r = this._def.values;
      return u3(t2, { expected: g2.joinValues(r), received: t2.parsedType, code: c2.invalid_type }), m3;
    }
    if (this._def.values.indexOf(e.data) === -1) {
      let t2 = this._getOrReturnCtx(e), r = this._def.values;
      return u3(t2, { received: t2.data, code: c2.invalid_enum_value, options: r }), m3;
    }
    return b3(e.data);
  }
  get options() {
    return this._def.values;
  }
  get enum() {
    let e = {};
    for (let t2 of this._def.values)
      e[t2] = t2;
    return e;
  }
  get Values() {
    let e = {};
    for (let t2 of this._def.values)
      e[t2] = t2;
    return e;
  }
  get Enum() {
    let e = {};
    for (let t2 of this._def.values)
      e[t2] = t2;
    return e;
  }
  extract(e) {
    return A.create(e);
  }
  exclude(e) {
    return A.create(this.options.filter((t2) => !e.includes(t2)));
  }
};
A.create = we;
var X = class extends v2 {
  _parse(e) {
    let t2 = g2.getValidEnumValues(this._def.values), r = this._getOrReturnCtx(e);
    if (r.parsedType !== d2.string && r.parsedType !== d2.number) {
      let n2 = g2.objectValues(t2);
      return u3(r, { expected: g2.joinValues(n2), received: r.parsedType, code: c2.invalid_type }), m3;
    }
    if (t2.indexOf(e.data) === -1) {
      let n2 = g2.objectValues(t2);
      return u3(r, { received: r.data, code: c2.invalid_enum_value, options: n2 }), m3;
    }
    return b3(e.data);
  }
  get enum() {
    return this._def.values;
  }
};
X.create = (s2, e) => new X({ values: s2, typeName: p2.ZodNativeEnum, ...y2(e) });
var D2 = class extends v2 {
  unwrap() {
    return this._def.type;
  }
  _parse(e) {
    let { ctx: t2 } = this._processInputParams(e);
    if (t2.parsedType !== d2.promise && t2.common.async === false)
      return u3(t2, { code: c2.invalid_type, expected: d2.promise, received: t2.parsedType }), m3;
    let r = t2.parsedType === d2.promise ? t2.data : Promise.resolve(t2.data);
    return b3(r.then((n2) => this._def.type.parseAsync(n2, { path: t2.path, errorMap: t2.common.contextualErrorMap })));
  }
};
D2.create = (s2, e) => new D2({ type: s2, typeName: p2.ZodPromise, ...y2(e) });
var C = class extends v2 {
  innerType() {
    return this._def.schema;
  }
  sourceType() {
    return this._def.schema._def.typeName === p2.ZodEffects ? this._def.schema.sourceType() : this._def.schema;
  }
  _parse(e) {
    let { status: t2, ctx: r } = this._processInputParams(e), n2 = this._def.effect || null;
    if (n2.type === "preprocess") {
      let i2 = n2.transform(r.data);
      return r.common.async ? Promise.resolve(i2).then((o) => this._def.schema._parseAsync({ data: o, path: r.path, parent: r })) : this._def.schema._parseSync({ data: i2, path: r.path, parent: r });
    }
    let a3 = { addIssue: (i2) => {
      u3(r, i2), i2.fatal ? t2.abort() : t2.dirty();
    }, get path() {
      return r.path;
    } };
    if (a3.addIssue = a3.addIssue.bind(a3), n2.type === "refinement") {
      let i2 = (o) => {
        let f2 = n2.refinement(o, a3);
        if (r.common.async)
          return Promise.resolve(f2);
        if (f2 instanceof Promise)
          throw new Error("Async refinement encountered during synchronous parse operation. Use .parseAsync instead.");
        return o;
      };
      if (r.common.async === false) {
        let o = this._def.schema._parseSync({ data: r.data, path: r.path, parent: r });
        return o.status === "aborted" ? m3 : (o.status === "dirty" && t2.dirty(), i2(o.value), { status: t2.value, value: o.value });
      } else
        return this._def.schema._parseAsync({ data: r.data, path: r.path, parent: r }).then((o) => o.status === "aborted" ? m3 : (o.status === "dirty" && t2.dirty(), i2(o.value).then(() => ({ status: t2.value, value: o.value }))));
    }
    if (n2.type === "transform")
      if (r.common.async === false) {
        let i2 = this._def.schema._parseSync({ data: r.data, path: r.path, parent: r });
        if (!le(i2))
          return i2;
        let o = n2.transform(i2.value, a3);
        if (o instanceof Promise)
          throw new Error("Asynchronous transform encountered during synchronous parse operation. Use .parseAsync instead.");
        return { status: t2.value, value: o };
      } else
        return this._def.schema._parseAsync({ data: r.data, path: r.path, parent: r }).then((i2) => le(i2) ? Promise.resolve(n2.transform(i2.value, a3)).then((o) => ({ status: t2.value, value: o })) : i2);
    g2.assertNever(n2);
  }
};
C.create = (s2, e, t2) => new C({ schema: s2, typeName: p2.ZodEffects, effect: e, ...y2(t2) });
C.createWithPreprocess = (s2, e, t2) => new C({ schema: e, effect: { type: "preprocess", transform: s2 }, typeName: p2.ZodEffects, ...y2(t2) });
var E3 = class extends v2 {
  _parse(e) {
    return this._getType(e) === d2.undefined ? b3(void 0) : this._def.innerType._parse(e);
  }
  unwrap() {
    return this._def.innerType;
  }
};
E3.create = (s2, e) => new E3({ innerType: s2, typeName: p2.ZodOptional, ...y2(e) });
var $ = class extends v2 {
  _parse(e) {
    return this._getType(e) === d2.null ? b3(null) : this._def.innerType._parse(e);
  }
  unwrap() {
    return this._def.innerType;
  }
};
$.create = (s2, e) => new $({ innerType: s2, typeName: p2.ZodNullable, ...y2(e) });
var K = class extends v2 {
  _parse(e) {
    let { ctx: t2 } = this._processInputParams(e), r = t2.data;
    return t2.parsedType === d2.undefined && (r = this._def.defaultValue()), this._def.innerType._parse({ data: r, path: t2.path, parent: t2 });
  }
  removeDefault() {
    return this._def.innerType;
  }
};
K.create = (s2, e) => new K({ innerType: s2, typeName: p2.ZodDefault, defaultValue: typeof e.default == "function" ? e.default : () => e.default, ...y2(e) });
var ae = class extends v2 {
  _parse(e) {
    let { ctx: t2 } = this._processInputParams(e), r = { ...t2, common: { ...t2.common, issues: [] } }, n2 = this._def.innerType._parse({ data: r.data, path: r.path, parent: { ...r } });
    return fe(n2) ? n2.then((a3) => ({ status: "valid", value: a3.status === "valid" ? a3.value : this._def.catchValue({ get error() {
      return new T(r.common.issues);
    }, input: r.data }) })) : { status: "valid", value: n2.status === "valid" ? n2.value : this._def.catchValue({ get error() {
      return new T(r.common.issues);
    }, input: r.data }) };
  }
  removeCatch() {
    return this._def.innerType;
  }
};
ae.create = (s2, e) => new ae({ innerType: s2, typeName: p2.ZodCatch, catchValue: typeof e.catch == "function" ? e.catch : () => e.catch, ...y2(e) });
var ie = class extends v2 {
  _parse(e) {
    if (this._getType(e) !== d2.nan) {
      let r = this._getOrReturnCtx(e);
      return u3(r, { code: c2.invalid_type, expected: d2.nan, received: r.parsedType }), m3;
    }
    return { status: "valid", value: e.data };
  }
};
ie.create = (s2) => new ie({ typeName: p2.ZodNaN, ...y2(s2) });
var Ue = Symbol("zod_brand");
var he = class extends v2 {
  _parse(e) {
    let { ctx: t2 } = this._processInputParams(e), r = t2.data;
    return this._def.type._parse({ data: r, path: t2.path, parent: t2 });
  }
  unwrap() {
    return this._def.type;
  }
};
var Q = class extends v2 {
  _parse(e) {
    let { status: t2, ctx: r } = this._processInputParams(e);
    if (r.common.async)
      return (async () => {
        let a3 = await this._def.in._parseAsync({ data: r.data, path: r.path, parent: r });
        return a3.status === "aborted" ? m3 : a3.status === "dirty" ? (t2.dirty(), be(a3.value)) : this._def.out._parseAsync({ data: a3.value, path: r.path, parent: r });
      })();
    {
      let n2 = this._def.in._parseSync({ data: r.data, path: r.path, parent: r });
      return n2.status === "aborted" ? m3 : n2.status === "dirty" ? (t2.dirty(), { status: "dirty", value: n2.value }) : this._def.out._parseSync({ data: n2.value, path: r.path, parent: r });
    }
  }
  static create(e, t2) {
    return new Q({ in: e, out: t2, typeName: p2.ZodPipeline });
  }
};
var Te = (s2, e = {}, t2) => s2 ? z.create().superRefine((r, n2) => {
  var a3, i2;
  if (!s2(r)) {
    let o = typeof e == "function" ? e(r) : typeof e == "string" ? { message: e } : e, f2 = (i2 = (a3 = o.fatal) !== null && a3 !== void 0 ? a3 : t2) !== null && i2 !== void 0 ? i2 : true, l2 = typeof o == "string" ? { message: o } : o;
    n2.addIssue({ code: "custom", ...l2, fatal: f2 });
  }
}) : z.create();
var Be = { object: x3.lazycreate };
var p2;
(function(s2) {
  s2.ZodString = "ZodString", s2.ZodNumber = "ZodNumber", s2.ZodNaN = "ZodNaN", s2.ZodBigInt = "ZodBigInt", s2.ZodBoolean = "ZodBoolean", s2.ZodDate = "ZodDate", s2.ZodSymbol = "ZodSymbol", s2.ZodUndefined = "ZodUndefined", s2.ZodNull = "ZodNull", s2.ZodAny = "ZodAny", s2.ZodUnknown = "ZodUnknown", s2.ZodNever = "ZodNever", s2.ZodVoid = "ZodVoid", s2.ZodArray = "ZodArray", s2.ZodObject = "ZodObject", s2.ZodUnion = "ZodUnion", s2.ZodDiscriminatedUnion = "ZodDiscriminatedUnion", s2.ZodIntersection = "ZodIntersection", s2.ZodTuple = "ZodTuple", s2.ZodRecord = "ZodRecord", s2.ZodMap = "ZodMap", s2.ZodSet = "ZodSet", s2.ZodFunction = "ZodFunction", s2.ZodLazy = "ZodLazy", s2.ZodLiteral = "ZodLiteral", s2.ZodEnum = "ZodEnum", s2.ZodEffects = "ZodEffects", s2.ZodNativeEnum = "ZodNativeEnum", s2.ZodOptional = "ZodOptional", s2.ZodNullable = "ZodNullable", s2.ZodDefault = "ZodDefault", s2.ZodCatch = "ZodCatch", s2.ZodPromise = "ZodPromise", s2.ZodBranded = "ZodBranded", s2.ZodPipeline = "ZodPipeline";
})(p2 || (p2 = {}));
var We = (s2, e = { message: `Input not instance of ${s2.name}` }) => Te((t2) => t2 instanceof s2, e);
var Se = w.create;
var Ce = j2.create;
var qe = ie.create;
var Je = R2.create;
var Oe = U.create;
var Ye = M.create;
var He = te.create;
var Ge = B.create;
var Xe = W2.create;
var Ke = z.create;
var Qe = Z.create;
var Fe = I.create;
var et = se.create;
var tt = S.create;
var st = x3.create;
var rt = x3.strictCreate;
var nt = q.create;
var at = re.create;
var it = J.create;
var ot = N.create;
var ct = Y.create;
var dt = ne.create;
var ut = V.create;
var lt = L.create;
var ft = H.create;
var ht = G.create;
var pt = A.create;
var mt = X.create;
var yt = D2.create;
var xe = C.create;
var vt = E3.create;
var _t = $.create;
var gt = C.createWithPreprocess;
var xt = Q.create;
var kt = () => Se().optional();
var bt = () => Ce().optional();
var wt = () => Oe().optional();
var Tt = { string: (s2) => w.create({ ...s2, coerce: true }), number: (s2) => j2.create({ ...s2, coerce: true }), boolean: (s2) => U.create({ ...s2, coerce: true }), bigint: (s2) => R2.create({ ...s2, coerce: true }), date: (s2) => M.create({ ...s2, coerce: true }) };
var St = m3;
var Ct = Object.freeze({ __proto__: null, defaultErrorMap: oe, setErrorMap: Ee, getErrorMap: de, makeIssue: ue, EMPTY_PATH: Ie, addIssueToContext: u3, ParseStatus: k2, INVALID: m3, DIRTY: be, OK: b3, isAborted: ye, isDirty: ve, isValid: le, isAsync: fe, get util() {
  return g2;
}, get objectUtil() {
  return me;
}, ZodParsedType: d2, getParsedType: P2, ZodType: v2, ZodString: w, ZodNumber: j2, ZodBigInt: R2, ZodBoolean: U, ZodDate: M, ZodSymbol: te, ZodUndefined: B, ZodNull: W2, ZodAny: z, ZodUnknown: Z, ZodNever: I, ZodVoid: se, ZodArray: S, ZodObject: x3, ZodUnion: q, ZodDiscriminatedUnion: re, ZodIntersection: J, ZodTuple: N, ZodRecord: Y, ZodMap: ne, ZodSet: V, ZodFunction: L, ZodLazy: H, ZodLiteral: G, ZodEnum: A, ZodNativeEnum: X, ZodPromise: D2, ZodEffects: C, ZodTransformer: C, ZodOptional: E3, ZodNullable: $, ZodDefault: K, ZodCatch: ae, ZodNaN: ie, BRAND: Ue, ZodBranded: he, ZodPipeline: Q, custom: Te, Schema: v2, ZodSchema: v2, late: Be, get ZodFirstPartyTypeKind() {
  return p2;
}, coerce: Tt, any: Ke, array: tt, bigint: Je, boolean: Oe, date: Ye, discriminatedUnion: at, effect: xe, enum: pt, function: lt, instanceof: We, intersection: it, lazy: ft, literal: ht, map: dt, nan: qe, nativeEnum: mt, never: Fe, null: Xe, nullable: _t, number: Ce, object: st, oboolean: wt, onumber: bt, optional: vt, ostring: kt, pipeline: xt, preprocess: gt, promise: yt, record: ct, set: ut, strictObject: rt, string: Se, symbol: He, transformer: xe, tuple: ot, undefined: Ge, union: nt, unknown: Qe, void: et, NEVER: St, ZodIssueCode: c2, quotelessJson: Ne, ZodError: T });

// src/server/http-external-server.ts
var PromiseToggle = class {
  constructor(initState) {
    this._open = new PromiseOut();
    this._close = new PromiseOut();
    if (initState.type === "open") {
      this.toggleOpen(initState.value);
    } else {
      this.toggleClose(initState.value);
    }
  }
  waitOpen() {
    return this._open.promise;
  }
  waitClose() {
    return this._close.promise;
  }
  get isOpen() {
    return this._open.is_resolved;
  }
  get isClose() {
    return this._close.is_resolved;
  }
  get openValue() {
    return this._open.value;
  }
  get closeValue() {
    return this._close.value;
  }
  /**
   * 切换到开的状态
   * @param value
   * @returns
   */
  toggleOpen(value) {
    if (this._open.is_resolved) {
      return;
    }
    this._open.resolve(value);
    if (this._close.is_resolved) {
      this._close = new PromiseOut();
    }
  }
  /**
   * 切换到开的状态
   * @param value
   * @returns
   */
  toggleClose(value) {
    if (this._close.is_resolved) {
      return;
    }
    this._close.resolve(value);
    if (this._open.is_resolved) {
      this._open = new PromiseOut();
    }
  }
};
var Server_external = class extends HttpServer {
  constructor() {
    super();
    this.token = crypto.randomUUID();
    this.ipcPo = new PromiseToggle({ type: "close", value: void 0 });
    this.externalWaitters = /* @__PURE__ */ new Map();
    // 是否需要激活
    this.needActivity = true;
    jsProcess.onFetch(async (event) => {
      if (event.pathname == "/wait-external-ready" /* WAIT_EXTERNAL_READY */) {
        await this.ipcPo.waitOpen();
      }
      return { status: 200 };
    });
  }
  /**
   * 这个token是内部使用的，就作为 特殊的 url.pathname 来处理内部操作
   */
  _getOptions() {
    return {
      subdomain: "external",
      port: 443
    };
  }
  async start() {
    const serverIpc = await this._listener;
    return serverIpc.onFetch(this._provider.bind(this)).internalServerError().cors();
  }
  //窗口关闭的时候需要重新等待连接
  closeRegisterIpc() {
    this.ipcPo.toggleClose();
  }
  async _provider(event) {
    const { pathname } = event;
    if (pathname.startsWith(`/${this.token}`)) {
      if (isWebSocket(event.method, event.headers)) {
        if (this.ipcPo.isOpen) {
          this.ipcPo.openValue.close();
          this.ipcPo.toggleClose();
        }
        const streamIpc = new ReadableStreamIpc(
          {
            mmid: jsProcess.mmid,
            name: jsProcess.mmid,
            ipc_support_protocols: {
              cbor: false,
              protobuf: false,
              raw: false
            },
            dweb_deeplinks: [],
            categories: []
          },
          IPC_ROLE.SERVER
        );
        this.ipcPo.toggleOpen(streamIpc);
        void streamIpc.bindIncomeStream(event.body).finally(() => {
          this.ipcPo.toggleClose();
        });
        streamIpc.onFetch(async (event2) => {
          const mmid = event2.headers.get("mmid");
          if (!mmid) {
            return new Response(null, { status: 502 });
          }
          this.needActivity = true;
          await mapHelper.getOrPut(this.externalWaitters, mmid, async (_key) => {
            let ipc3;
            try {
              ipc3 = await jsProcess.connect(mmid);
              const deleteCache = () => {
                this.externalWaitters.delete(mmid);
                off1();
              };
              const off1 = ipc3.onClose(deleteCache);
            } catch (err) {
              this.externalWaitters.delete(mmid);
              throw err;
            }
            ipc3.postMessage(IpcEvent.fromText("activity" /* ACTIVITY */, "activity" /* ACTIVITY */));
            this.needActivity = false;
            await ipc3.request(`file://${mmid}${"/wait-external-ready" /* WAIT_EXTERNAL_READY */}`);
            return ipc3;
          });
          const ipc2 = await this.externalWaitters.get(mmid);
          if (ipc2 && this.needActivity) {
            ipc2.postMessage(IpcEvent.fromText("activity" /* ACTIVITY */, "activity" /* ACTIVITY */));
          }
          const ext_options = this._getOptions();
          return await jsProcess.nativeFetch(
            `http://${ext_options.subdomain}.${mmid}:${ext_options.port}${event2.pathname}${event2.search}`,
            {
              method: event2.method,
              headers: event2.headers,
              body: event2.body
            }
          );
        });
        return { body: streamIpc.stream };
      }
      return { status: 500 };
    } else {
      const ipc2 = await this.ipcPo.waitOpen();
      const response = (await ipc2.request(event.request.url, event.request)).toResponse();
      return IpcResponse.fromResponse(event.ipcRequest.req_id, response, event.ipc);
    }
  }
};

// src/server/shim/fetch.shim.ts
var setupFetch = () => {
  const nativeFetch = fetch;
  const dwebFetch = (input, init) => {
    return nativeFetch(new DwebRequest(input, init));
  };
  const getBaseUrl2 = typeof document === "object" ? () => document.baseURI : () => location.href;
  const NativeRequest = Request;
  class DwebRequest extends NativeRequest {
    constructor(input, init) {
      let inputUrl;
      if (input instanceof URL) {
        inputUrl = input;
      } else if (typeof input === "string") {
        inputUrl = new URL(input, getBaseUrl2());
      }
      if (inputUrl !== void 0) {
        if (inputUrl.username) {
          const dwebHeaders = new Headers(init?.headers);
          dwebHeaders.set("X-Dweb-Host", decodeURIComponent(inputUrl.username));
          init = {
            ...init,
            headers: dwebHeaders
          };
        }
        inputUrl.username = "";
        input = inputUrl;
      }
      super(input, init);
    }
  }
  const G3 = typeof globalThis === "object" ? globalThis : self;
  Object.assign(G3, {
    fetch: dwebFetch,
    Request: DwebRequest,
    dwebShim: { nativeFetch, NativeRequest }
  });
};

// src/server/http-www-server.ts
var CONFIG_PREFIX = "/config.sys.dweb/";
var Server_www = class extends HttpServer {
  constructor(plaocConfig) {
    super();
    this.plaocConfig = plaocConfig;
    this.lang = null;
  }
  get jsonPlaoc() {
    return this.plaocConfig.config;
  }
  _getOptions() {
    return {
      subdomain: "www",
      port: 443
    };
  }
  async start() {
    const lang = await jsProcess.nativeFetch("file://config.sys.dweb/getLang").text();
    if (lang) {
      this.lang = lang;
    } else if (this.jsonPlaoc) {
      this.lang = this.jsonPlaoc.defaultConfig.lang;
    }
    const serverIpc = await this._listener;
    return serverIpc.onFetch(this._provider.bind(this)).noFound();
  }
  async _provider(request, root = "www") {
    let { pathname } = request;
    if (pathname.startsWith(CONFIG_PREFIX)) {
      return this._config(request);
    }
    let remoteIpcResponse;
    if (this.jsonPlaoc && root !== "server/emulator") {
      const proxyRequest = await this._plaocForwarder(request, this.jsonPlaoc);
      pathname = proxyRequest.url.pathname;
      const plaocShims = new Set((proxyRequest.url.searchParams.get("plaoc-shim") ?? "").split(",").filter(Boolean));
      if (plaocShims.has("fetch")) {
        remoteIpcResponse = await jsProcess.nativeRequest(`file:///usr/${root}${pathname}`, {
          headers: proxyRequest.headers
        });
        const rawText = await remoteIpcResponse.toResponse().text();
        remoteIpcResponse = IpcResponse.fromText(
          remoteIpcResponse.req_id,
          remoteIpcResponse.statusCode,
          remoteIpcResponse.headers,
          `;(${setupFetch.toString()})();${rawText}`,
          remoteIpcResponse.ipc
        );
      } else {
        remoteIpcResponse = await jsProcess.nativeRequest(`file:///usr/${root}${pathname}?mode=stream`, {
          headers: proxyRequest.headers
        });
      }
    } else {
      remoteIpcResponse = await jsProcess.nativeRequest(`file:///usr/${root}${pathname}?mode=stream`);
    }
    const ipcResponse = new IpcResponse(
      request.req_id,
      remoteIpcResponse.statusCode,
      cors(remoteIpcResponse.headers),
      remoteIpcResponse.body,
      request.ipc
    );
    return ipcResponse;
  }
  async _config(event) {
    const pathname = event.pathname.slice(CONFIG_PREFIX.length);
    if (pathname.startsWith("/setLang")) {
      const lang = event.searchParams.get("lang");
      this.lang = lang;
    }
    return jsProcess.nativeFetch(`file:/${event.pathname}${event.search}`);
  }
  /**
   * 转发plaoc.json请求
   * @param request
   * @param config
   */
  async _plaocForwarder(request, config) {
    const redirects = config.redirect;
    for (const redirect of redirects) {
      if (!this._matchMethod(request.method, redirect.matchMethod)) {
        continue;
      }
      const urlPattern = new URLPattern({
        pathname: redirect.matchUrl.pathname,
        search: redirect.matchUrl.search
      });
      const pattern = urlPattern.exec(request.url);
      if (!pattern)
        continue;
      const url = redirect.to.url.replace(/\{\{\s*(.*?)\s*\}\}/g, (_exp, match) => {
        const func = new Function("pattern", "lang", "config", `return ${match}`);
        return func(pattern, this.lang, config);
      }).replace(/\\/g, "/").replace(/\/\//g, "/");
      const newUrl = new URL(url, request.url);
      request.url.hash = newUrl.hash;
      request.url.host = newUrl.host;
      request.url.hostname = newUrl.hostname;
      request.url.href = newUrl.href;
      request.url.password = newUrl.password;
      request.url.pathname = newUrl.pathname;
      request.url.port = newUrl.port;
      request.url.protocol = newUrl.protocol;
      request.url.search = newUrl.search;
      request.url.username = newUrl.username;
      const appendHeaders = redirect.to.appendHeaders;
      if (appendHeaders && Object.keys(appendHeaders).length !== 0) {
        for (const header of Object.entries(appendHeaders)) {
          request.headers.append(header[0], header[1]);
        }
      }
      const removeHeaders = redirect.to.removeHeaders;
      if (removeHeaders && Object.keys(removeHeaders).length !== 0) {
        for (const header of Object.keys(removeHeaders)) {
          request.headers.delete(header[0]);
        }
      }
      return request;
    }
    return request;
  }
  /**
   * 匹配 * 和 method
   * @param method
   * @param methods
   * @returns
   */
  _matchMethod(method, methods) {
    if (!methods)
      return true;
    if (methods.join().indexOf("*") !== -1)
      return true;
    for (const me2 in methods) {
      if (me2.toLocaleUpperCase() === method) {
        return true;
      }
    }
    return false;
  }
};

// src/server/polyfill.ts
if (typeof Response.json !== "function") {
  Response.json = (data, init = {}) => {
    const headers = new Headers(init.headers);
    headers.set("Content-Type", "application/json");
    return new Response(JSON.stringify(data), { ...init, headers });
  };
}
if (!globalThis.URLPattern) {
  await Promise.resolve().then(() => (init_urlpattern_polyfill2(), urlpattern_polyfill_exports));
}

// src/server/plaoc-config.ts
var PlaocConfig = class {
  constructor(config) {
    this.config = config;
  }
  static async init() {
    try {
      const readPlaoc = await jsProcess.nativeRequest(`file:///usr/www/plaoc.json`);
      return new PlaocConfig(JSON.parse(await readPlaoc.body.text()));
    } catch {
      return new PlaocConfig({ redirect: [], defaultConfig: { lang: "en" } });
    }
  }
};

// src/server/index.ts
var main = async () => {
  const indexUrlPo = new PromiseOut();
  let widPo = new PromiseOut();
  const tryOpenView = queue(async () => {
    const url = await indexUrlPo.promise;
    if (all_webview_status.size === 0) {
      await sync_mwebview_status();
      console.log("mwebview_open=>", url);
      if (widPo.is_resolved) {
        apiServer.widPo = widPo = new PromiseOut();
      }
      const { wid } = await mwebview_open(url);
      widPo.resolve(wid);
    } else {
      console.log("mwebview_activate=>", url);
      await mwebview_activate();
    }
  });
  jsProcess.onActivity(async (_ipcEvent) => {
    console.log(`${jsProcess.mmid} onActivity`);
    tryOpenView();
  });
  jsProcess.onClose(() => {
    console.log("app\u540E\u53F0\u88AB\u5173\u95ED\u3002");
  });
  const plaocConfig = await PlaocConfig.init();
  const wwwServer = new Server_www(plaocConfig);
  const externalServer = new Server_external();
  const apiServer = new Server_api(widPo);
  const wwwListenerTask = wwwServer.start().finally(() => console.log("wwwServer started"));
  const externalListenerTask = externalServer.start().finally(() => console.log("externalServer started"));
  const apiListenerTask = apiServer.start().finally(() => console.log("apiServer started"));
  all_webview_status.signal.listen((size) => {
    if (size === 0) {
      externalServer.closeRegisterIpc();
    }
  });
  const wwwStartResult = await wwwServer.getStartResult();
  const apiStartResult = await apiServer.getStartResult();
  const usePublic = plaocConfig.config.usePublicUrl ?? (R.isMobile() ? navigator.userAgent.includes("Android") ? false : true : true);
  const indexUrl = wwwStartResult.urlInfo.buildHtmlUrl(usePublic, (url) => {
    url.pathname = "/index.html";
    url.searchParams.set("X-Plaoc-Internal-Url" /* API_INTERNAL_URL */, apiStartResult.urlInfo.buildUrl(usePublic).href);
    url.searchParams.set("X-Plaoc-Public-Url" /* API_PUBLIC_URL */, apiStartResult.urlInfo.buildPublicUrl().href);
    url.searchParams.set("X-Plaoc-External-Url" /* EXTERNAL_URL */, externalServer.token);
  });
  console.log("open in browser:", indexUrl.href);
  await Promise.all([wwwListenerTask, externalListenerTask, apiListenerTask]);
  indexUrlPo.resolve(indexUrl.href);
  tryOpenView();
};
main();
export {
  main
};
//!此处为js ipc特有垫片，防止有些webview版本过低，出现无法支持的函数
//! use zod error: Relative import path "zod" not prefixed with / or ./ or ../ only remote
//! https://github.com/denoland/deno/issues/17598
