import {
  __commonJS,
  __toESM
} from "./chunk-YSQDPG26.js";

// ../../../../../../../../Users/bfs/Library/Caches/deno/deno_esbuild/is-mobile@4.0.0/node_modules/is-mobile/index.js
var require_is_mobile = __commonJS({
  "../../../../../../../../Users/bfs/Library/Caches/deno/deno_esbuild/is-mobile@4.0.0/node_modules/is-mobile/index.js"(exports, module) {
    "use strict";
    module.exports = isMobile2;
    module.exports.isMobile = isMobile2;
    module.exports.default = isMobile2;
    var mobileRE = /(android|bb\d+|meego).+mobile|armv7l|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|mobile.+firefox|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series[46]0|samsungbrowser.*mobile|symbian|treo|up\.(browser|link)|vodafone|wap|windows (ce|phone)|xda|xiino/i;
    var notMobileRE = /CrOS/;
    var tabletRE = /android|ipad|playbook|silk/i;
    function isMobile2(opts) {
      if (!opts)
        opts = {};
      let ua = opts.ua;
      if (!ua && typeof navigator !== "undefined")
        ua = navigator.userAgent;
      if (ua && ua.headers && typeof ua.headers["user-agent"] === "string") {
        ua = ua.headers["user-agent"];
      }
      if (typeof ua !== "string")
        return false;
      let result = mobileRE.test(ua) && !notMobileRE.test(ua) || !!opts.tablet && tabletRE.test(ua);
      if (!result && opts.tablet && opts.featureDetect && navigator && navigator.maxTouchPoints > 1 && ua.indexOf("Macintosh") !== -1 && ua.indexOf("Safari") !== -1) {
        result = true;
      }
      return result;
    }
  }
});

// helper/response-json.polyfill.ts
if (typeof Response.json !== "function") {
  Response.json = (data, init = {}) => {
    const headers = new Headers(init.headers);
    headers.set("Content-Type", "application/json");
    return new Response(JSON.stringify(data), { ...init, headers });
  };
}

// helper/urlpattern.polyfill.ts
if (typeof URLPattern === "undefined") {
  await import("./urlpattern-polyfill-XK7YRBE2.js");
}

// ../../dweb-helper/src/PromiseOut.ts
var isPromiseLike = (value) => {
  return value instanceof Object && typeof value.then === "function";
};
var PromiseOut = class _PromiseOut {
  static resolve(v) {
    const po = new _PromiseOut();
    po.resolve(v);
    return po;
  }
  static reject(reason) {
    const po = new _PromiseOut();
    po.reject(reason);
    return po;
  }
  static sleep(ms) {
    const po = new _PromiseOut();
    let ti = setTimeout(() => {
      ti = void 0;
      po.resolve();
    }, ms);
    po.onFinished(() => ti !== void 0 && clearTimeout(ti));
    return po;
  }
  promise;
  is_resolved = false;
  is_rejected = false;
  is_finished = false;
  value;
  reason;
  resolve;
  reject;
  _innerFinally;
  _innerFinallyArg;
  _innerThen;
  _innerCatch;
  constructor() {
    this.promise = new Promise((resolve, reject) => {
      this.resolve = (value) => {
        try {
          if (isPromiseLike(value)) {
            value.then(this.resolve, this.reject);
          } else {
            this.is_resolved = true;
            this.is_finished = true;
            resolve(this.value = value);
            this._runThen();
            this._innerFinallyArg = Object.freeze({
              status: "resolved",
              result: this.value
            });
            this._runFinally();
          }
        } catch (err) {
          this.reject(err);
        }
      };
      this.reject = (reason) => {
        this.is_rejected = true;
        this.is_finished = true;
        reject(this.reason = reason);
        this._runCatch();
        this._innerFinallyArg = Object.freeze({
          status: "rejected",
          reason: this.reason
        });
        this._runFinally();
      };
    });
  }
  onSuccess(innerThen) {
    if (this.is_resolved) {
      this.__callInnerThen(innerThen);
    } else {
      (this._innerThen || (this._innerThen = [])).push(innerThen);
    }
  }
  onError(innerCatch) {
    if (this.is_rejected) {
      this.__callInnerCatch(innerCatch);
    } else {
      (this._innerCatch || (this._innerCatch = [])).push(innerCatch);
    }
  }
  onFinished(innerFinally) {
    if (this.is_finished) {
      this.__callInnerFinally(innerFinally);
    } else {
      (this._innerFinally || (this._innerFinally = [])).push(innerFinally);
    }
  }
  _runFinally() {
    if (this._innerFinally) {
      for (const innerFinally of this._innerFinally) {
        this.__callInnerFinally(innerFinally);
      }
      this._innerFinally = void 0;
    }
  }
  __callInnerFinally(innerFinally) {
    queueMicrotask(async () => {
      try {
        await innerFinally(this._innerFinallyArg);
      } catch (err) {
        console.error("Unhandled promise rejection when running onFinished", innerFinally, err);
      }
    });
  }
  _runThen() {
    if (this._innerThen) {
      for (const innerThen of this._innerThen) {
        this.__callInnerThen(innerThen);
      }
      this._innerThen = void 0;
    }
  }
  _runCatch() {
    if (this._innerCatch) {
      for (const innerCatch of this._innerCatch) {
        this.__callInnerCatch(innerCatch);
      }
      this._innerCatch = void 0;
    }
  }
  __callInnerThen(innerThen) {
    queueMicrotask(async () => {
      try {
        await innerThen(this.value);
      } catch (err) {
        console.error("Unhandled promise rejection when running onSuccess", innerThen, err);
      }
    });
  }
  __callInnerCatch(innerCatch) {
    queueMicrotask(async () => {
      try {
        await innerCatch(this.value);
      } catch (err) {
        console.error("Unhandled promise rejection when running onError", innerCatch, err);
      }
    });
  }
};

// ../../dweb-helper/src/createSignal.ts
var createSignal = (autoStart) => {
  return new Signal(autoStart);
};
var Signal = class {
  constructor(autoStart = true) {
    if (autoStart) {
      this._start();
    }
  }
  _cbs = /* @__PURE__ */ new Set();
  #started = false;
  _cachedActions = [];
  _start() {
    if (this.#started) {
      return;
    }
    this.#started = true;
    if (this._cachedActions.length) {
      for (const action of this._cachedActions) {
        action();
      }
      this._cachedActions.length = 0;
    }
  }
  _startAction(action) {
    if (this.#started) {
      action();
    } else {
      this._cachedActions.push(action);
    }
  }
  listen = (cb) => {
    this._cbs.add(cb);
    this._start();
    return () => this._cbs.delete(cb);
  };
  emit = (...args) => {
    this._startAction(() => {
      this._emit(args, this._cbs);
    });
  };
  emitAndClear = (...args) => {
    this._startAction(() => {
      const cbs = [...this._cbs];
      this._cbs.clear();
      this._emit(args, cbs);
    });
  };
  _emit(args, cbs) {
    for (const cb of cbs) {
      try {
        cb.apply(null, args);
      } catch (reason) {
        console.warn(reason);
      }
    }
  }
  clear = () => {
    this._startAction(() => {
      this._cbs.clear();
    });
  };
};

// ../../dweb-helper/src/decorator/$once.ts
var $once = (fn) => {
  let first = true;
  let resolved;
  let rejected;
  let success = false;
  return Object.defineProperties(
    function(...args) {
      if (first) {
        first = false;
        try {
          resolved = fn.apply(this, args);
          success = true;
        } catch (err) {
          rejected = err;
        }
      }
      if (success) {
        return resolved;
      }
      throw rejected;
    },
    {
      hasRun: {
        get() {
          return !first;
        }
      },
      result: {
        get() {
          if (success) {
            return resolved;
          } else {
            throw rejected;
          }
        }
      },
      reset: {
        configurable: true,
        writable: true,
        value: () => {
          first = true;
          resolved = void 0;
          rejected = void 0;
          success = false;
        }
      }
    }
  );
};

// ../../dweb-helper/src/encoding.ts
var textEncoder = new TextEncoder();
var textDecoder = new TextDecoder();

// ../../dweb-helper/src/fun/mapHelper.ts
var mapHelper = new class {
  getOrPut(map, key, putter) {
    if (map.has(key)) {
      return map.get(key);
    }
    const put = putter(key);
    map.set(key, put);
    return put;
  }
  getAndRemove(map, key) {
    const val = map.get(key);
    if (map.delete(key)) {
      return val;
    }
  }
}();

// ../../dweb-helper/src/stream/readableStreamHelper.ts
async function* _doRead(reader, options) {
  const signal = options?.signal;
  if (signal !== void 0) {
    signal.addEventListener("abort", (reason) => reader.cancel(reason));
  }
  try {
    while (true) {
      const item = await reader.read();
      if (item.done) {
        break;
      }
      yield item.value;
    }
  } catch (err) {
    reader.cancel(err);
  } finally {
    reader.releaseLock();
  }
}
var streamRead = (stream, options) => {
  return _doRead(stream.getReader(), options);
};

// deps.ts
var { jsProcess, http, ipc, core } = navigator.dweb;
var {
  IpcFetchError,
  Ipc,
  IpcBodySender,
  IpcEvent,
  IpcError,
  IpcRequest,
  IpcRawResponse,
  IpcStreamData,
  IpcStreamEnd,
  IpcStreamPaused,
  IpcStreamPulling,
  IpcServerRequest,
  IpcRawRequest,
  //
  IpcHeaders,
  IpcClientRequest,
  IpcResponse,
  ReadableStreamOut,
  //
  PureChannel,
  PureFrameType,
  PureFrame,
  PureTextFrame,
  PureBinaryFrame
} = ipc;
var { IpcFetchEvent, ReadableStreamEndpoint } = core;
var { ServerUrlInfo, ServerStartResult } = http;

// helper/http-helper.ts
var HttpServer = class {
  constructor(channelId) {
    this.channelId = channelId;
    this.init(channelId);
  }
  _serverP = new PromiseOut();
  // deno-lint-ignore require-await
  async init(channelId) {
    const target = `http-server-${channelId}`;
    this._serverP.resolve(http.createHttpDwebServer(jsProcess, this._getOptions(), target));
  }
  getServer() {
    return this._serverP.promise;
  }
  async getStartResult() {
    const server = await this.getServer();
    return server.startResult;
  }
  async stop() {
    const server = await this._serverP.promise;
    return await server.close();
  }
  listen = $once(async (...onFetchs) => {
    const server = await this.getServer();
    return server.listen(...onFetchs);
  });
};

// ../../../../../../../../Users/bfs/Library/Caches/deno/deno_esbuild/deep-object-diff@1.1.9/node_modules/deep-object-diff/mjs/utils.js
var isDate = (d) => d instanceof Date;
var isEmpty = (o) => Object.keys(o).length === 0;
var isObject = (o) => o != null && typeof o === "object";
var hasOwnProperty = (o, ...args) => Object.prototype.hasOwnProperty.call(o, ...args);
var isEmptyObject = (o) => isObject(o) && isEmpty(o);
var makeObjectWithoutPrototype = () => /* @__PURE__ */ Object.create(null);

// ../../../../../../../../Users/bfs/Library/Caches/deno/deno_esbuild/deep-object-diff@1.1.9/node_modules/deep-object-diff/mjs/added.js
var addedDiff = (lhs, rhs) => {
  if (lhs === rhs || !isObject(lhs) || !isObject(rhs))
    return {};
  return Object.keys(rhs).reduce((acc, key) => {
    if (hasOwnProperty(lhs, key)) {
      const difference = addedDiff(lhs[key], rhs[key]);
      if (isObject(difference) && isEmpty(difference))
        return acc;
      acc[key] = difference;
      return acc;
    }
    acc[key] = rhs[key];
    return acc;
  }, makeObjectWithoutPrototype());
};
var added_default = addedDiff;

// ../../../../../../../../Users/bfs/Library/Caches/deno/deno_esbuild/deep-object-diff@1.1.9/node_modules/deep-object-diff/mjs/deleted.js
var deletedDiff = (lhs, rhs) => {
  if (lhs === rhs || !isObject(lhs) || !isObject(rhs))
    return {};
  return Object.keys(lhs).reduce((acc, key) => {
    if (hasOwnProperty(rhs, key)) {
      const difference = deletedDiff(lhs[key], rhs[key]);
      if (isObject(difference) && isEmpty(difference))
        return acc;
      acc[key] = difference;
      return acc;
    }
    acc[key] = void 0;
    return acc;
  }, makeObjectWithoutPrototype());
};
var deleted_default = deletedDiff;

// ../../../../../../../../Users/bfs/Library/Caches/deno/deno_esbuild/deep-object-diff@1.1.9/node_modules/deep-object-diff/mjs/updated.js
var updatedDiff = (lhs, rhs) => {
  if (lhs === rhs)
    return {};
  if (!isObject(lhs) || !isObject(rhs))
    return rhs;
  if (isDate(lhs) || isDate(rhs)) {
    if (lhs.valueOf() == rhs.valueOf())
      return {};
    return rhs;
  }
  return Object.keys(rhs).reduce((acc, key) => {
    if (hasOwnProperty(lhs, key)) {
      const difference = updatedDiff(lhs[key], rhs[key]);
      if (isEmptyObject(difference) && !isDate(difference) && (isEmptyObject(lhs[key]) || !isEmptyObject(rhs[key])))
        return acc;
      acc[key] = difference;
      return acc;
    }
    return acc;
  }, makeObjectWithoutPrototype());
};
var updated_default = updatedDiff;

// ../../../../../../../../Users/bfs/Library/Caches/deno/deno_esbuild/deep-object-diff@1.1.9/node_modules/deep-object-diff/mjs/detailed.js
var detailedDiff = (lhs, rhs) => ({
  added: added_default(lhs, rhs),
  deleted: deleted_default(lhs, rhs),
  updated: updated_default(lhs, rhs)
});
var detailed_default = detailedDiff;

// helper/mwebview-helper.ts
var apply_window = () => {
  return jsProcess.nativeFetch("file://window.sys.dweb/mainWindow").text();
};
var open_main_window = () => {
  return jsProcess.nativeFetch("file://window.sys.dweb/openMainWindow").text();
};
var close_window = (wid) => {
  return jsProcess.nativeFetch(`file://window.sys.dweb/closeWindow?wid=${wid}`);
};
var mwebview_open = async (wid, url) => {
  const openUrl = new URL(`file://mwebview.browser.dweb/open`);
  openUrl.searchParams.set("wid", wid);
  openUrl.searchParams.set("url", url);
  const state = await jsProcess.nativeFetch(openUrl).object();
  all_webview_status.diffState(state);
  return state;
};
var mwebview_activate = (wid) => {
  const activateUrl = new URL(`file://mwebview.browser.dweb/activate`);
  activateUrl.searchParams.set("wid", wid);
  return jsProcess.nativeFetch(activateUrl).text();
};
var mwebview_destroy = () => {
  return jsProcess.nativeFetch(`file://mwebview.browser.dweb/close/app`).boolean();
};
var AllWebviewStatus = class extends Map {
  last() {
    return [...this.entries()].at(-1);
  }
  signal = createSignal();
  /**
   * 对比状态的更新
   * @param diff
   */
  diffFactory(diff) {
    for (const id in diff.added) {
      this.set(id, diff.added[id]);
    }
    for (const id in diff.deleted) {
      this.delete(id);
    }
    for (const id in diff.updated) {
      this.set(id, diff.updated[id]);
    }
    this.signal.emit(this.size);
  }
  oldWebviewState = {};
  diffState(newState) {
    const diff = detailed_default(this.oldWebviewState, newState.views);
    this.oldWebviewState = newState.views;
    this.diffFactory(diff);
  }
};
var all_webview_status = new AllWebviewStatus();
var _false = true;
var sync_mwebview_status = async () => {
  if (_false === false) {
    return;
  }
  _false = false;
  const ipc2 = await navigator.dweb.jsProcess.connect("mwebview.browser.dweb");
  ipc2.onEvent("ovserver-mwebiew-state").collect((ipcEvent) => {
    const event = ipcEvent.data;
    if (event.name === "state") {
      const newState = JSON.parse(IpcEvent.text(event));
      all_webview_status.diffState(newState);
    }
  });
};

// http-api-server.ts
var DNS_PREFIX = "/dns.std.dweb/";
var INTERNAL_PREFIX = "/internal/";
var Server_api = class extends HttpServer {
  constructor(getWid, handlers = []) {
    super("api");
    this.getWid = getWid;
    this.handlers = handlers;
  }
  jsRuntime = jsProcess.bootstrapContext;
  _getOptions() {
    return {
      subdomain: "api"
    };
  }
  async start() {
    const serverIpc = await this.listen(...this.handlers, this._provider.bind(this));
    return serverIpc.internalServerError().cors();
  }
  // deno-lint-ignore require-await
  async _provider(event) {
    if (event.pathname.startsWith(DNS_PREFIX)) {
      return this._onDns(event);
    } else if (event.pathname.startsWith(INTERNAL_PREFIX)) {
      return this._onInternal(event);
    }
    return this._onApi(event);
  }
  async _onDns(event) {
    const url = new URL("file:/" + event.pathname + event.search);
    const pathname = url.pathname;
    const result = async () => {
      if (pathname === "/restart") {
        setTimeout(async () => {
          const winId = await this.getWid();
          close_window(winId);
          this.jsRuntime.dns.restart(jsProcess.mmid);
        }, 200);
        return Response.json({ success: true, message: "restart ok" });
      }
      if (pathname === "/close") {
        const bool = await mwebview_destroy();
        return Response.json({ success: bool, message: "window close" });
      }
      if (pathname === "/query") {
        const mmid = event.searchParams.get("mmid");
        const res = await jsProcess.nativeFetch(`file://dns.std.dweb/query?app_id=${mmid}`);
        return res;
      }
      return Response.json({
        success: false,
        message: "no action for serviceWorker Factory !!!"
      });
    };
    return await result();
  }
  callbacks = /* @__PURE__ */ new Map();
  #remote = {
    mmid: "localhost.dweb",
    ipc_support_protocols: { cbor: false, protobuf: false, json: false },
    dweb_deeplinks: [],
    categories: [],
    name: ""
  };
  async _onInternal(event) {
    const pathname = event.pathname.slice(INTERNAL_PREFIX.length);
    if (pathname === "window-info") {
      return Response.json({ wid: await this.getWid() });
    }
    if (pathname === "callback") {
      const id = event.searchParams.get("id");
      if (!id) {
        return IpcResponse.fromText(event.reqId, 500, new IpcHeaders(), "invalid search params, miss 'id'", event.ipc);
      }
      const ipc2 = await mapHelper.getOrPut(this.callbacks, id, () => new PromiseOut()).promise;
      const response = await ipc2.request(event.url.href, event.ipcRequest.toRequest());
      return response.toResponse();
    }
    if (pathname === "registry-callback") {
      const id = event.searchParams.get("id");
      if (!id) {
        return IpcResponse.fromText(event.reqId, 500, new IpcHeaders(), "invalid search params, miss 'id'", event.ipc);
      }
      const endpoint = new ReadableStreamEndpoint(`${jsProcess.mmid}-api-server`);
      const readableStreamIpc = jsProcess.ipcPool.createIpc(endpoint, 0, this.#remote, this.#remote);
      endpoint.bindIncomeStream(event.request.body);
      mapHelper.getOrPut(this.callbacks, id, () => new PromiseOut()).resolve(readableStreamIpc);
      return IpcResponse.fromStream(event.reqId, 200, void 0, endpoint.stream, event.ipc);
    }
    if (pathname.startsWith("/usr")) {
      const response = await jsProcess.nativeRequest(`file://${pathname}`);
      return new IpcResponse(event.reqId, response.statusCode, response.headers, response.body, event.ipc);
    }
  }
  /**
   * request 事件处理器
   */
  async _onApi(event) {
    const { pathname, search } = event;
    const path = `file:/${pathname}${search}`;
    const mmid = new URL(path).host;
    const targetIpc = await jsProcess.connect(mmid);
    const { ipcRequest } = event;
    let ipcProxyRequest = new IpcClientRequest(0, path, event.method, event.headers, ipcRequest.body, targetIpc);
    targetIpc.postMessage(ipcProxyRequest);
    let ipcProxyResponse = await targetIpc.request(ipcProxyRequest);
    if (ipcProxyResponse.statusCode === 401) {
      if (await jsProcess.requestDwebPermissions(await ipcProxyResponse.body.text())) {
        ipcProxyRequest = new IpcClientRequest(0, path, event.method, event.headers, ipcRequest.body, targetIpc);
        ipcProxyResponse = await targetIpc.request(ipcProxyRequest);
      }
    }
    if (ipcRequest.hasDuplex) {
      await ipcRequest.client.enableChannel();
    }
    return ipcProxyResponse.toResponse();
  }
};

// helper/merge.ts
function merge(...buf) {
  let totalLength = buf.reduce((total, arr) => total + arr.length, 0);
  let merged = new Uint8Array(totalLength);
  let offset = 0;
  for (let arr of buf) {
    merged.set(arr, offset);
    offset += arr.length;
  }
  return merged;
}

// helper/duplexIpc.ts
var createDuplexIpc = (ipcPool, subdomain, mmid, ipcRequest) => {
  const remote = {
    mmid,
    name: `${subdomain}.${mmid}`,
    ipc_support_protocols: {
      cbor: false,
      protobuf: false,
      json: false
    },
    dweb_deeplinks: [],
    categories: []
  };
  const endpoint = new ReadableStreamEndpoint(`${mmid}-plaoc-external-duplex`);
  const streamIpc = ipcPool.createIpc(endpoint, 0, remote, remote, true);
  const incomeStream = new ReadableStreamOut();
  const pureServerChannel = ipcRequest.getChannel();
  pureServerChannel.start();
  void (async () => {
    for await (const chunk of streamRead(endpoint.stream)) {
      pureServerChannel.outgoing.controller.enqueue(new PureBinaryFrame(merge(chunk)));
    }
  })();
  void (async () => {
    for await (const pureFrame of streamRead(pureServerChannel.income.stream)) {
      if (pureFrame instanceof PureBinaryFrame) {
        incomeStream.controller.enqueue(pureFrame.data);
      }
    }
  })();
  void endpoint.bindIncomeStream(incomeStream.stream);
  return streamIpc;
};

// helper/promise-toggle.ts
var PromiseToggle = class {
  constructor(initState) {
    if (initState.type === "open") {
      this.toggleOpen(initState.value);
    } else {
      this.toggleClose(initState.value);
    }
  }
  _open = new PromiseOut();
  _close = new PromiseOut();
  waitOpen() {
    return this._open.promise;
  }
  waitClose() {
    return this._close.promise;
  }
  get isOpen() {
    return this._open.is_resolved;
  }
  get isClose() {
    return this._close.is_resolved;
  }
  get openValue() {
    return this._open.value;
  }
  get closeValue() {
    return this._close.value;
  }
  /**
   * 切换到开的状态
   * @param value
   * @returns
   */
  toggleOpen(value) {
    if (this._open.is_resolved) {
      return;
    }
    this._open.resolve(value);
    if (this._close.is_resolved) {
      this._close = new PromiseOut();
    }
  }
  /**
   * 切换到开的状态
   * @param value
   * @returns
   */
  toggleClose(value) {
    if (this._close.is_resolved) {
      return;
    }
    this._close.resolve(value);
    if (this._open.is_resolved) {
      this._open = new PromiseOut();
    }
  }
};

// http-external-server.ts
var Server_external = class extends HttpServer {
  constructor(handlers = []) {
    super("external");
    this.handlers = handlers;
    jsProcess.fetchIpc.onRequest("external").collect(async (event) => {
      if (event.data.parsed_url.pathname == "/wait-external-ready" /* WAIT_EXTERNAL_READY */) {
        await this.ipcPo.waitOpen();
      }
      return { status: 200 };
    });
  }
  /**
   * 这个token是内部使用的，就作为 特殊的 url.pathname 来处理内部操作
   */
  _getOptions() {
    return {
      subdomain: "external"
    };
  }
  token = crypto.randomUUID();
  async start() {
    const serverIpc = await this.listen(...this.handlers, this._provider.bind(this));
    return serverIpc.internalServerError().cors();
  }
  ipcPo = new PromiseToggle({
    type: "close",
    value: void 0
  });
  //窗口关闭的时候需要重新等待连接
  closeRegisterIpc() {
    this.ipcPo.toggleClose();
  }
  externalWaitters = /* @__PURE__ */ new Map();
  // 是否需要激活
  needActivity = true;
  async _provider(event) {
    const { pathname } = event;
    if (pathname.startsWith(`/${this.token}`)) {
      if (!event.ipcRequest.hasDuplex) {
        return { status: 500 };
      }
      if (this.ipcPo.isOpen) {
        this.ipcPo.toggleClose();
      }
      const streamIpc = createDuplexIpc(
        jsProcess.ipcPool,
        this._getOptions().subdomain,
        jsProcess.mmid,
        event.ipcRequest
      );
      streamIpc.onClosed(() => {
        this.ipcPo.toggleClose();
      });
      this.ipcPo.toggleOpen(streamIpc);
      streamIpc.onRequest("get-external-fetch").collect(async (event2) => {
        const IpcServerRequest2 = event2.data;
        const mmid = IpcServerRequest2.headers.get("mmid");
        if (!mmid) {
          return new Response(null, { status: 502 });
        }
        this.needActivity = true;
        await mapHelper.getOrPut(this.externalWaitters, mmid, async (_key) => {
          let ipc3;
          try {
            ipc3 = await jsProcess.connect(mmid);
            const deleteCache = () => {
              this.externalWaitters.delete(mmid);
            };
            ipc3.onClosed(deleteCache);
          } catch (err) {
            this.externalWaitters.delete(mmid);
            throw err;
          }
          ipc3.postMessage(IpcEvent.fromText("activity" /* ACTIVITY */, "renderer" /* RENDERER */));
          this.needActivity = false;
          await ipc3.request(`file://${mmid}${"/wait-external-ready" /* WAIT_EXTERNAL_READY */}`);
          return ipc3;
        });
        const ipc2 = await this.externalWaitters.get(mmid);
        if (ipc2 && this.needActivity) {
          ipc2.postMessage(IpcEvent.fromText("activity" /* ACTIVITY */, "renderer" /* RENDERER */));
        }
        const ext_options = this._getOptions();
        IpcServerRequest2.headers.append("X-External-Dweb-Host", jsProcess.mmid);
        return await jsProcess.nativeFetch(
          `https://${ext_options.subdomain}.${mmid}${IpcServerRequest2.parsed_url.pathname}${IpcServerRequest2.parsed_url.search}`,
          {
            method: IpcServerRequest2.method,
            headers: IpcServerRequest2.headers,
            body: await IpcServerRequest2.body.stream()
          }
        );
      });
      return { status: 101 };
    } else {
      const ipc2 = await this.ipcPo.waitOpen();
      const response = (await ipc2.request(event.request.url, event.request)).toResponse();
      return IpcResponse.fromResponse(event.ipcRequest.reqId, response, event.ipc);
    }
  }
};

// http-www-server.ts
var import_is_mobile = __toESM(require_is_mobile());

// shim/db.shim.ts
var setupDB = async (sessionId) => {
  document.currentScript?.parentElement?.removeChild(document.currentScript);
  const KEY = "--plaoc-session-id--";
  if (localStorage.getItem(KEY) !== sessionId) {
    console.log("\u89E6\u53D1\u6E05\u7A7A", sessionId);
    localStorage.clear();
    localStorage.setItem(KEY, sessionId);
    sessionStorage.clear();
    const tasks = [];
    const t1 = indexedDB.databases().then((dbs) => {
      for (const db of dbs) {
        if (db.name) {
          indexedDB.deleteDatabase(db.name);
        }
      }
    });
    tasks.push(t1.catch(console.error));
    if (typeof cookieStore === "object") {
      const t2 = cookieStore.getAll().then((cookies) => {
        for (const c of cookies) {
          cookieStore.delete(c.name);
        }
      });
      tasks.push(t2.catch(console.error));
    }
    await Promise.all(tasks);
    location.replace(location.href);
  }
};

// shim/fetch.shim.ts
var setupFetch = () => {
  const nativeFetch = fetch;
  const dwebFetch = (input, init) => {
    return nativeFetch(new DwebRequest(input, init));
  };
  const getBaseUrl = typeof document === "object" ? () => document.baseURI : () => location.href;
  const NativeRequest = Request;
  class DwebRequest extends NativeRequest {
    constructor(input, init) {
      let inputUrl;
      if (input instanceof URL) {
        inputUrl = input;
      } else if (typeof input === "string") {
        inputUrl = new URL(input, getBaseUrl());
      }
      if (inputUrl !== void 0) {
        if (inputUrl.username) {
          const dwebHeaders = new Headers(init?.headers);
          dwebHeaders.set("X-Dweb-Host", decodeURIComponent(inputUrl.username));
          init = {
            ...init,
            headers: dwebHeaders
          };
        }
        inputUrl.username = "";
        input = inputUrl;
      }
      super(input, init);
    }
  }
  const G = typeof globalThis === "object" ? globalThis : self;
  Object.assign(G, {
    fetch: dwebFetch,
    Request: DwebRequest,
    dwebShim: { nativeFetch, NativeRequest }
  });
};

// http-www-server.ts
var CONFIG_PREFIX = "/config.sys.dweb/";
var Server_www = class extends HttpServer {
  constructor(plaocConfig, handlers = []) {
    super("wwww");
    this.plaocConfig = plaocConfig;
    this.handlers = handlers;
  }
  get jsonPlaoc() {
    return this.plaocConfig.config;
  }
  lang = null;
  sessionInfo = jsProcess.nativeFetch("file:///usr/sys/session.json").then((res) => res.json());
  _getOptions() {
    return {
      subdomain: "www"
    };
  }
  encoder = new TextEncoder();
  async start() {
    const lang = await jsProcess.nativeFetch("file://config.sys.dweb/getLang").text();
    if (lang) {
      this.lang = lang;
    } else if (this.jsonPlaoc) {
      this.lang = this.jsonPlaoc.defaultConfig.lang;
    }
    const serverIpc = await this.listen(...this.handlers, this._provider.bind(this));
    return serverIpc.noFound();
  }
  async _provider(request, root = "www") {
    let { pathname } = request;
    if (pathname.startsWith(CONFIG_PREFIX)) {
      return this._config(request);
    }
    let remoteIpcResponse;
    if (this.jsonPlaoc) {
      const proxyRequest = await this._plaocForwarder(request, this.jsonPlaoc);
      pathname = proxyRequest.url.pathname;
      const plaocShims = new Set((proxyRequest.url.searchParams.get("plaoc-shim") ?? "").split(",").filter(Boolean));
      if (plaocShims.has("fetch")) {
        remoteIpcResponse = await jsProcess.nativeRequest(`file:///usr/${root}${pathname}`, {
          headers: proxyRequest.headers
        });
        const rawText = await remoteIpcResponse.toResponse().text();
        remoteIpcResponse = IpcResponse.fromText(
          remoteIpcResponse.reqId,
          remoteIpcResponse.statusCode,
          remoteIpcResponse.headers,
          `;(${setupFetch.toString()})();${rawText}`,
          remoteIpcResponse.ipc
        );
      } else {
        remoteIpcResponse = await jsProcess.nativeRequest(`file:///usr/${root}${pathname}?mode=stream`, {
          headers: proxyRequest.headers
        });
        if (remoteIpcResponse.headers.get("Content-Type")?.includes("text/html") && !plaocShims.has("raw") && (0, import_is_mobile.isMobile)()) {
          const rawText = await remoteIpcResponse.toResponse().text();
          const text = `<script>(${setupDB.toString()})("${(await this.sessionInfo).installTime}");<\/script>${rawText}`;
          const binary = this.encoder.encode(text);
          remoteIpcResponse.headers.set("Content-Length", binary.length + "");
          remoteIpcResponse = IpcResponse.fromBinary(
            remoteIpcResponse.reqId,
            remoteIpcResponse.statusCode,
            remoteIpcResponse.headers,
            binary,
            remoteIpcResponse.ipc
          );
        }
      }
    } else {
      remoteIpcResponse = await jsProcess.nativeRequest(`file:///usr/${root}${pathname}?mode=stream`);
    }
    const ipcResponse = new IpcResponse(
      request.reqId,
      remoteIpcResponse.statusCode,
      remoteIpcResponse.headers,
      remoteIpcResponse.body,
      request.ipc
    );
    return ipcResponse;
  }
  _config(event) {
    const pathname = event.pathname.slice(CONFIG_PREFIX.length);
    if (pathname.startsWith("/setLang")) {
      const lang = event.searchParams.get("lang");
      this.lang = lang;
    }
    return jsProcess.nativeFetch(`file:/${event.pathname}${event.search}`);
  }
  /**
   * 转发plaoc.json请求
   * @param request
   * @param config
   */
  _plaocForwarder(request, config) {
    const redirects = config.redirect;
    for (const redirect of redirects) {
      if (!this._matchMethod(request.method, redirect.matchMethod)) {
        continue;
      }
      const urlPattern = new URLPattern({
        pathname: redirect.matchUrl.pathname,
        search: redirect.matchUrl.search
      });
      const pattern = urlPattern.exec(request.url);
      if (!pattern)
        continue;
      const url = redirect.to.url.replace(/\{\{\s*(.*?)\s*\}\}/g, (_exp, match) => {
        const func = new Function("pattern", "lang", "config", `return ${match}`);
        return func(pattern, this.lang, config);
      }).replace(/\\/g, "/").replace(/\/\//g, "/");
      const newUrl = new URL(url, request.url);
      request.url.hash = newUrl.hash;
      request.url.host = newUrl.host;
      request.url.hostname = newUrl.hostname;
      request.url.href = newUrl.href;
      request.url.password = newUrl.password;
      request.url.pathname = newUrl.pathname;
      request.url.port = newUrl.port;
      request.url.protocol = newUrl.protocol;
      request.url.search = newUrl.search;
      request.url.username = newUrl.username;
      const appendHeaders = redirect.to.appendHeaders;
      if (appendHeaders && Object.keys(appendHeaders).length !== 0) {
        for (const header of Object.entries(appendHeaders)) {
          request.headers.append(header[0], header[1]);
        }
      }
      const removeHeaders = redirect.to.removeHeaders;
      if (removeHeaders && Object.keys(removeHeaders).length !== 0) {
        for (const header of Object.keys(removeHeaders)) {
          request.headers.delete(header[0]);
        }
      }
      return request;
    }
    return request;
  }
  /**
   * 匹配 * 和 method
   * @param method
   * @param methods
   * @returns
   */
  _matchMethod(method, methods) {
    if (!methods)
      return true;
    if (methods.join().indexOf("*") !== -1)
      return true;
    for (const me in methods) {
      if (me.toLocaleUpperCase() === method) {
        return true;
      }
    }
    return false;
  }
};

// helper/queue.ts
var queue = (fun) => {
  let queuer = Promise.resolve();
  return function(...args) {
    return queuer = queuer.finally(() => fun(...args));
  };
};

// middleware-importer.ts
var MiddlewareImporter = class {
  static async init(path) {
    if (!path) {
      return [];
    }
    try {
      const middleware = await import(join("./middleware", path));
      console.log("middleware=>", middleware);
      return middleware.default.handlers;
    } catch (_e) {
    }
  }
};
function join(...paths) {
  let joinedPath = paths[0];
  for (let i = 1; i < paths.length; i++) {
    let path = paths[i];
    if (path.startsWith(".")) {
      path = path.substring(1);
    }
    const precededBySlash = joinedPath.endsWith("/");
    const followedBySlash = path.startsWith("/");
    if (precededBySlash && followedBySlash) {
      joinedPath += path.substring(1);
    } else if (!precededBySlash && !followedBySlash) {
      joinedPath += "/" + path;
    } else {
      joinedPath += path;
    }
  }
  return joinedPath;
}

// plaoc-config.ts
var PlaocConfig = class _PlaocConfig {
  constructor(config) {
    this.config = config;
  }
  static async init() {
    try {
      const readPlaoc = await jsProcess.nativeRequest(`file:///usr/www/plaoc.json`);
      return new _PlaocConfig(JSON.parse(await readPlaoc.body.text()));
    } catch {
      return new _PlaocConfig({ redirect: [], defaultConfig: { lang: "en" } });
    }
  }
};

// main.ts
var main = async () => {
  console.log("start main");
  const indexHrefPo = new PromiseOut();
  let wid_po = new PromiseOut();
  const getWinId = () => wid_po.promise;
  const setWinId = (win_id) => {
    if (wid_po.is_finished) {
      wid_po = PromiseOut.resolve(win_id);
    } else {
      wid_po.resolve(win_id);
    }
  };
  const delWinId = (win_id) => {
    if (wid_po.value === win_id) {
      wid_po = new PromiseOut();
    }
  };
  const tryOpenView = queue(async () => {
    const url = await indexHrefPo.promise;
    const wid = await getWinId();
    if (all_webview_status.size === 0) {
      await sync_mwebview_status();
      console.log("mwebview_open=>", url, wid);
      await mwebview_open(wid, url);
    } else {
      console.log("mwebview_activate=>", url, wid);
      await mwebview_activate(wid);
    }
  });
  jsProcess.onActivity(async (ipcEvent) => {
    console.log(`${jsProcess.mmid} onActivity`, ipcEvent.data);
    const win_id = await apply_window();
    console.log("win_id=>", win_id);
    setWinId(win_id);
  });
  jsProcess.onRenderer((ipcEvent) => {
    const text = IpcEvent.text(ipcEvent);
    console.log(`${jsProcess.mmid} onRenderer`, text);
    setWinId(text);
    tryOpenView();
  });
  jsProcess.onRendererDestroy?.((ipcEvent) => {
    const text = IpcEvent.text(ipcEvent);
    console.log(`${jsProcess.mmid} onRendererDestroy`, text);
    delWinId(text);
  });
  jsProcess.onShortcut?.(async (ipcEvent) => {
    console.log(`${jsProcess.mmid} onShortcut`, ipcEvent.data);
    const ipc2 = await externalServer.ipcPo.waitOpen();
    ipc2.postMessage(ipcEvent);
  });
  const plaocConfig = await PlaocConfig.init();
  const wwwServer = new Server_www(plaocConfig, await MiddlewareImporter.init(plaocConfig.config.middlewares?.www));
  const externalServer = new Server_external(await MiddlewareImporter.init(plaocConfig.config.middlewares?.external));
  const apiServer = new Server_api(getWinId, await MiddlewareImporter.init(plaocConfig.config.middlewares?.api));
  const wwwListenerTask = wwwServer.start().finally(() => console.log("wwwServer started"));
  const externalListenerTask = externalServer.start().finally(() => console.log("externalServer started"));
  const apiListenerTask = apiServer.start().finally(() => console.log("apiServer started"));
  all_webview_status.signal.listen((size) => {
    if (size === 0) {
      externalServer.closeRegisterIpc();
    }
  });
  const wwwStartResult = await wwwServer.getStartResult();
  await apiServer.getStartResult();
  const indexHref = wwwStartResult.urlInfo.buildHtmlUrl(false, (url) => {
    url.pathname = "/index.html";
    url.searchParams.set("X-Plaoc-External-Url" /* EXTERNAL_URL */, externalServer.token);
  }).href;
  console.log("open in browser:", indexHref);
  await Promise.all([wwwListenerTask, externalListenerTask, apiListenerTask]);
  indexHrefPo.resolve(indexHref);
  console.log("indexUrl.href", indexHref);
  setWinId(await open_main_window());
};
try {
  void main();
} catch (e) {
  jsProcess.close(`\u540E\u7AEF\u9519\u8BEF\uFF1A${e}`);
}

// shim/crypto.shims.ts
if (typeof crypto.randomUUID !== "function") {
  crypto.randomUUID = function randomUUID() {
    return "10000000-1000-4000-8000-100000000000".replace(/[018]/g, (_c) => {
      const c = +_c;
      return (c ^ crypto.getRandomValues(new Uint8Array(1))[0] & 15 >> c / 4).toString(16);
    });
  };
}

// middlewares/base-router.ts
var BaseRouter = class {
};

// middlewares/router.ts
var Router = class extends BaseRouter {
  constructor() {
    super();
  }
  handlers = [];
  use(...handlers) {
    this.handlers.push(...handlers);
  }
};
export {
  Router
};
//!此处为js ipc特有垫片，防止有些webview版本过低，出现无法支持的函数
