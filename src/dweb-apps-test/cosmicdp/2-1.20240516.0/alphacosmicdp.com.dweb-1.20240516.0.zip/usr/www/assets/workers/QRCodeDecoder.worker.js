var bfchainZxingqr = (function (exports) {
    'use strict';

    typeof global==='undefined'&&(self.global = self);
    typeof globalThis==='undefined'&&(self.globalThis = self);
    if(!Symbol.asyncIterator){Symbol.asyncIterator=Symbol.for("asyncIterator")};

    const ANY_TRANSFER_TYPES = ["deserialize", "serialize", "both"];
    const DESERIALIZABLE_TRANSFER_TYPES = ["deserialize", "both"];
    const SERIALIZABLE_TRANSFER_TYPES = ["serialize", "both"];
    const DESERIALIZEONLY_TRANSFER_TYPES = ["deserialize"];
    const SERIALIZEONLY_TRANSFER_TYPES = ["serialize"];
    const BOTHONLY_TRANSFER_TYPES = ["both"];
    const MODE_TRANSFER_TYPES_MAP = {
        any: ANY_TRANSFER_TYPES,
        deserializable: DESERIALIZABLE_TRANSFER_TYPES,
        serializable: SERIALIZABLE_TRANSFER_TYPES,
        deserializeonly: DESERIALIZEONLY_TRANSFER_TYPES,
        serializeonly: SERIALIZEONLY_TRANSFER_TYPES,
        bothonly: BOTHONLY_TRANSFER_TYPES,
    };
    class TransferHandlerMap {
        constructor(entries) {
            /**
             * TransferType and TransferHandlers mapping.
             */
            /* private */ this._map = {
                both: new Map(),
                serialize: new Map(),
                deserialize: new Map(),
            };
            /**
             * TransferName and TransferType mapping
             */
            this._nameTypeMap = new Map();
            if (entries) {
                for (const item of entries) {
                    this.set(item[0], item[1]);
                }
            }
        }
        set(name, transferHandler) {
            /// try remove old one first. ensure transferHandler exists in one map only
            this.delete(name);
            let type;
            if ("canHandle" in transferHandler) {
                if ("deserialize" in transferHandler) {
                    type = "both";
                    this._map[type].set(name, {
                        type,
                        canHandle: transferHandler.canHandle,
                        serialize: transferHandler.serialize,
                        deserialize: transferHandler.deserialize,
                    });
                }
                else {
                    type = "serialize";
                    this._map[type].set(name, {
                        type,
                        canHandle: transferHandler.canHandle,
                        serialize: transferHandler.serialize,
                    });
                }
            }
            else {
                type = "deserialize";
                this._map[type].set(name, {
                    type,
                    deserialize: transferHandler.deserialize,
                });
            }
            /// falg the TransferName's TransferType
            this._nameTypeMap.set(name, type);
        }
        get(name, mode = "any") {
            for (const type of MODE_TRANSFER_TYPES_MAP[mode]) {
                const transferHandler = this._map[type].get(name);
                if (transferHandler) {
                    return transferHandler;
                }
            }
        }
        has(name, mode = "any") {
            return MODE_TRANSFER_TYPES_MAP[mode].some((type) => this._map[type].has(name));
        }
        delete(name) {
            const oldType = this._nameTypeMap.get(name);
            if (oldType) {
                return this._map[oldType].delete(name);
            }
            return false;
        }
        clear() {
            for (const type of ANY_TRANSFER_TYPES) {
                this._map[type].clear();
            }
        }
        forEach(callbackfn, thisArg, mode = "any") {
            for (const type of MODE_TRANSFER_TYPES_MAP[mode]) {
                this._map[type].forEach(callbackfn, thisArg);
            }
        }
        get size() {
            return ANY_TRANSFER_TYPES.reduce((size, type) => size + this._map[type].size, 0);
        }
        getSize(mode = "any") {
            let size = 0;
            for (const type of MODE_TRANSFER_TYPES_MAP[mode]) {
                size = +this._map[type].size;
            }
            return size;
        }
        /** Returns an iterable of entries in the map. */
        [Symbol.iterator](mode = "any") {
            return this.entries(mode);
        }
        /**
         * Returns an iterable of key, value pairs for every entry in the map.
         */
        *entries(mode = "any") {
            for (const type of MODE_TRANSFER_TYPES_MAP[mode]) {
                yield* this._map[type].entries();
            }
        }
        /**
         * Returns an iterable of keys in the map
         */
        *keys(mode = "any") {
            for (const type of MODE_TRANSFER_TYPES_MAP[mode]) {
                yield* this._map[type].keys();
            }
        }
        /**
         * Returns an iterable of values in the map
         */
        *values(mode = "any") {
            for (const type of MODE_TRANSFER_TYPES_MAP[mode]) {
                yield* this._map[type].values();
            }
        }
    }

    /**
     * Copyright 2019 Google Inc. All Rights Reserved.
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *     http://www.apache.org/licenses/LICENSE-2.0
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */
    const proxyMarker = Symbol("Comlink.proxy");
    const createEndpoint = Symbol("Comlink.endpoint");
    const releaseProxy = Symbol("Comlink.releaseProxy");
    const throwMarker = Symbol("Comlink.thrown");
    const isObject = (val) => (typeof val === "object" && val !== null) || typeof val === "function";
    /**
     * Internal transfer handle to handle objects marked to proxy.
     */
    const proxyTransferHandler = {
        canHandle: (val) => isObject(val) && val[proxyMarker],
        serialize(obj) {
            const { port1, port2 } = new MessageChannel();
            expose(obj, port1);
            return [port2, [port2]];
        },
        deserialize(port) {
            port.start();
            return wrap(port);
        },
    };
    /**
     * Internal transfer handler to handle thrown exceptions.
     */
    const throwTransferHandler = {
        canHandle: (value) => isObject(value) && throwMarker in value,
        serialize({ value }) {
            let serialized;
            if (value instanceof Error) {
                serialized = {
                    isError: true,
                    value: {
                        message: value.message,
                        name: value.name,
                        stack: value.stack,
                    },
                };
            }
            else {
                serialized = { isError: false, value };
            }
            return [serialized, []];
        },
        deserialize(serialized) {
            if (serialized.isError) {
                throw Object.assign(new Error(serialized.value.message), serialized.value);
            }
            throw serialized.value;
        },
    };
    /**
     * Allows customizing the serialization of certain values.
     */
    const transferHandlers = new TransferHandlerMap([
        ["proxy", proxyTransferHandler],
        ["throw", throwTransferHandler],
    ]);
    function expose(obj, ep = self) {
        ep.addEventListener("message", function callback(ev) {
            if (!ev || !ev.data) {
                return;
            }
            const { id, type, path } = Object.assign({ path: [] }, ev.data);
            const argumentList = (ev.data.argumentList || []).map(fromWireValue);
            let returnValue;
            try {
                const parent = path.slice(0, -1).reduce((obj, prop) => obj[prop], obj);
                const rawValue = path.reduce((obj, prop) => obj[prop], obj);
                switch (type) {
                    case 0 /* GET */:
                        {
                            returnValue = rawValue;
                        }
                        break;
                    case 1 /* SET */:
                        {
                            parent[path.slice(-1)[0]] = fromWireValue(ev.data.value);
                            returnValue = true;
                        }
                        break;
                    case 2 /* APPLY */:
                        {
                            returnValue = rawValue.apply(parent, argumentList);
                        }
                        break;
                    case 3 /* CONSTRUCT */:
                        {
                            const value = new rawValue(...argumentList);
                            returnValue = proxy(value);
                        }
                        break;
                    case 4 /* ENDPOINT */:
                        {
                            const { port1, port2 } = new MessageChannel();
                            expose(obj, port2);
                            returnValue = transfer(port1, [port1]);
                        }
                        break;
                    case 5 /* RELEASE */:
                        {
                            returnValue = undefined;
                        }
                        break;
                }
            }
            catch (value) {
                returnValue = { value, [throwMarker]: 0 };
            }
            Promise.resolve(returnValue)
                .catch((value) => {
                return { value, [throwMarker]: 0 };
            })
                .then((returnValue) => {
                const [wireValue, transferables] = toWireValue(returnValue);
                ep.postMessage(Object.assign(Object.assign({}, wireValue), { id }), transferables);
                if (type === 5 /* RELEASE */) {
                    // detach and deactive after sending release response above.
                    ep.removeEventListener("message", callback);
                    closeEndPoint(ep);
                }
            });
        });
        if (ep.start) {
            ep.start();
        }
    }
    function isMessagePort(endpoint) {
        return endpoint.constructor.name === "MessagePort";
    }
    function closeEndPoint(endpoint) {
        if (isMessagePort(endpoint))
            endpoint.close();
    }
    function wrap(ep, target) {
        return createProxy(ep, [], target);
    }
    function throwIfProxyReleased(isReleased) {
        if (isReleased) {
            throw new Error("Proxy has been released and is not useable");
        }
    }
    function createProxy(ep, path = [], target = function () { }) {
        let isProxyReleased = false;
        const proxy = new Proxy(target, {
            get(_target, prop) {
                throwIfProxyReleased(isProxyReleased);
                if (prop === releaseProxy) {
                    return () => {
                        return requestResponseMessage(ep, {
                            type: 5 /* RELEASE */,
                            path: path.map((p) => p.toString()),
                        }).then(() => {
                            closeEndPoint(ep);
                            isProxyReleased = true;
                        });
                    };
                }
                if (prop === "then") {
                    if (path.length === 0) {
                        return { then: () => proxy };
                    }
                    const r = requestResponseMessage(ep, {
                        type: 0 /* GET */,
                        path: path.map((p) => p.toString()),
                    }).then(fromWireValue);
                    return r.then.bind(r);
                }
                return createProxy(ep, [...path, prop]);
            },
            set(_target, prop, rawValue) {
                throwIfProxyReleased(isProxyReleased);
                // FIXME: ES6 Proxy Handler `set` methods are supposed to return a
                // boolean. To show good will, we return true asynchronously ¯\_(ツ)_/¯
                const [value, transferables] = toWireValue(rawValue);
                return requestResponseMessage(ep, {
                    type: 1 /* SET */,
                    path: [...path, prop].map((p) => p.toString()),
                    value,
                }, transferables).then(fromWireValue);
            },
            apply(_target, _thisArg, rawArgumentList) {
                throwIfProxyReleased(isProxyReleased);
                const last = path[path.length - 1];
                if (last === createEndpoint) {
                    return requestResponseMessage(ep, {
                        type: 4 /* ENDPOINT */,
                    }).then(fromWireValue);
                }
                // We just pretend that `bind()` didn’t happen.
                if (last === "bind") {
                    return createProxy(ep, path.slice(0, -1));
                }
                let argumentList;
                let transferables;
                if (last === "apply") {
                    const applyThisInfo = toWireValue(rawArgumentList[0]);
                    const applyArgsInfo = processArguments(rawArgumentList[1]);
                    argumentList = [
                        applyThisInfo[0],
                        { type: 4 /* RAW_ARRAY */, value: applyArgsInfo[0] },
                    ];
                    transferables = applyArgsInfo[1].concat(applyThisInfo[1]);
                }
                else {
                    [argumentList, transferables] = processArguments(rawArgumentList);
                }
                return requestResponseMessage(ep, {
                    type: 2 /* APPLY */,
                    path: path.map((p) => p.toString()),
                    argumentList,
                }, transferables).then(fromWireValue);
            },
            construct(_target, rawArgumentList) {
                throwIfProxyReleased(isProxyReleased);
                const [argumentList, transferables] = processArguments(rawArgumentList);
                return requestResponseMessage(ep, {
                    type: 3 /* CONSTRUCT */,
                    path: path.map((p) => p.toString()),
                    argumentList,
                }, transferables).then(fromWireValue);
            },
        });
        return proxy;
    }
    function myFlat(arr) {
        return Array.prototype.concat.apply([], arr);
    }
    function processArguments(argumentList) {
        const processed = argumentList.map(toWireValue);
        return [processed.map((v) => v[0]), myFlat(processed.map((v) => v[1]))];
    }
    const transferCache = new WeakMap();
    function transfer(obj, transfers) {
        transferCache.set(obj, transfers);
        return obj;
    }
    function proxy(obj) {
        return Object.assign(obj, { [proxyMarker]: true });
    }
    function toWireValue(value) {
        for (const [name, handler] of transferHandlers.entries("serializable")) {
            if (handler.canHandle(value)) {
                const [serializedValue, transferables] = handler.serialize(value);
                return [
                    {
                        type: 3 /* HANDLER */,
                        name,
                        value: serializedValue,
                    },
                    transferables,
                ];
            }
        }
        return [
            {
                type: 0 /* RAW */,
                value,
            },
            transferCache.get(value) || [],
        ];
    }
    function fromWireValue(value) {
        switch (value.type) {
            case 3 /* HANDLER */:
                return transferHandlers
                    .get(value.name, "deserializable")
                    .deserialize(value.value);
            case 0 /* RAW */:
                return value.value;
            case 4 /* RAW_ARRAY */:
                return value.value.map(fromWireValue);
        }
    }
    function requestResponseMessage(ep, msg, transfers) {
        return new Promise((resolve) => {
            const id = generateUUID();
            ep.addEventListener("message", function l(ev) {
                if (!ev.data || !ev.data.id || ev.data.id !== id) {
                    return;
                }
                ep.removeEventListener("message", l);
                resolve(ev.data);
            });
            if (ep.start) {
                ep.start();
            }
            ep.postMessage(Object.assign({ id }, msg), transfers);
        });
    }
    function generateUUID() {
        return new Array(4)
            .fill(0)
            .map(() => Math.floor(Math.random() * Number.MAX_SAFE_INTEGER).toString(16))
            .join("-");
    }

    /*
     * Copyright 2009 ZXing authors
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *      http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */
    /**
     * This class hierarchy provides a set of methods to convert luminance data to 1 bit data.
     * It allows the algorithm to vary polymorphically, for example allowing a very expensive
     * thresholding technique for servers and a fast one for mobile. It also permits the implementation
     * to vary, e.g. a JNI version for Android and a Java fallback version for other platforms.
     *
     * @author dswitkin@google.com (Daniel Switkin)
     */
    class Binarizer {
        constructor(source) {
            this.source = source;
        }
        getLuminanceSource() {
            return this.source;
        }
        getWidth() {
            return this.source.getWidth();
        }
        getHeight() {
            return this.source.getHeight();
        }
    }

    /**
     * 从堆栈中一个函数的获取调用者的信息
     * @param caller 如果支持`Error.captureStackTrace`，则使用caller定位
     * @param deep 否则直接使用手动计数定位
     */
    const GetCallerInfo = Error.captureStackTrace
        ? (caller) => {
            const stackInfo = { stack: "" };
            Error.captureStackTrace(stackInfo, caller);
            return stackInfo.stack;
        }
        : /**使用Function动态生成来规避严格模式的代码解析 */
            Function("f", `
    let deep = 0;
    let caller = arguments.callee;
    do {
      if (caller.caller === f) {
        break;
      }
      deep += 1;
      caller = caller.caller;
      if (caller === null) {
        break;
      }
    } while (true);
    const stack = new Error().stack || "";
    const stackLineLine = stack.split('\\n');
    stackLineLine.splice(1, deep);
    return stackLineLine.join('\\n');
  `);
    class CustomError extends Error {
        get name() {
            return this.constructor.name;
        }
        static call(_this, message) {
            if (!(_this instanceof CustomError)) {
                throw new TypeError("please use new keyword to create CustomError instance.");
            }
            _this.stack = GetCallerInfo(_this.constructor);
            _this.message = message || "";
            return _this;
        }
    }

    /**
     * Custom Error class of type Exception.
     */
    class ArgumentException extends CustomError {
    }

    /**
     * Custom Error class of type Exception.
     */
    class ArithmeticException extends CustomError {
    }

    /**
     * Custom Error class of type Exception.
     */
    class ChecksumException extends CustomError {
    }

    /**
     * Custom Error class of type Exception.
     */
    class FormatException extends CustomError {
    }

    /**
     * Custom Error class of type Exception.
     */
    class IllegalArgumentException extends CustomError {
    }

    /**
     * Custom Error class of type Exception.
     */
    class IllegalStateException extends CustomError {
    }

    /**
     * Custom Error class of type Exception.
     */
    class NotFoundException extends CustomError {
    }

    /**
     * Custom Error class of type Exception.
     */
    class ReedSolomonException extends CustomError {
    }

    /**
     * Custom Error class of type Exception.
     */
    class UnsupportedOperationException extends CustomError {
    }

    /*
     * Copyright 2009 ZXing authors
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *      http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */
    class BinaryBitmap {
        constructor(binarizer) {
            this.binarizer = binarizer;
            if (binarizer === null) {
                throw new IllegalArgumentException("Binarizer must be non-null.");
            }
        }
        /**
         * @return The width of the bitmap.
         */
        getWidth() {
            return this.binarizer.getWidth();
        }
        /**
         * @return The height of the bitmap.
         */
        getHeight() {
            return this.binarizer.getHeight();
        }
        /**
         * Converts one row of luminance data to 1 bit data. May actually do the conversion, or return
         * cached data. Callers should assume this method is expensive and call it as seldom as possible.
         * This method is intended for decoding 1D barcodes and may choose to apply sharpening.
         *
         * @param y The row to fetch, which must be in [0, bitmap height)
         * @param row An optional preallocated array. If null or too small, it will be ignored.
         *            If used, the Binarizer will call BitArray.clear(). Always use the returned object.
         * @return The array of bits for this row (true means black).
         * @throws NotFoundException if row can't be binarized
         */
        getBlackRow(y /*int*/, row) {
            return this.binarizer.getBlackRow(y, row);
        }
        /**
         * Converts a 2D array of luminance data to 1 bit. As above, assume this method is expensive
         * and do not call it repeatedly. This method is intended for decoding 2D barcodes and may or
         * may not apply sharpening. Therefore, a row from this matrix may not be identical to one
         * fetched using getBlackRow(), so don't mix and match between them.
         *
         * @return The 2D array of bits for the image (true means black).
         * @throws NotFoundException if image can't be binarized to make a matrix
         */
        getBlackMatrix() {
            // The matrix is created on demand the first time it is requested, then cached. There are two
            // reasons for this:
            // 1. This work will never be done if the caller only installs 1D Reader objects, or if a
            //    1D Reader finds a barcode before the 2D Readers run.
            // 2. This work will only be done once even if the caller installs multiple 2D Readers.
            if (this.matrix === null || this.matrix === undefined) {
                this.matrix = this.binarizer.getBlackMatrix();
            }
            return this.matrix;
        }
        /**
         * @return Whether this bitmap can be cropped.
         */
        isCropSupported() {
            return this.binarizer.getLuminanceSource().isCropSupported();
        }
        /**
         * Returns a new object with cropped image data. Implementations may keep a reference to the
         * original data rather than a copy. Only callable if isCropSupported() is true.
         *
         * @param left The left coordinate, which must be in [0,getWidth())
         * @param top The top coordinate, which must be in [0,getHeight())
         * @param width The width of the rectangle to crop.
         * @param height The height of the rectangle to crop.
         * @return A cropped version of this object.
         */
        crop(left /*int*/, top /*int*/, width /*int*/, height /*int*/) {
            const newSource = this.binarizer
                .getLuminanceSource()
                .crop(left, top, width, height);
            return new BinaryBitmap(this.binarizer.createBinarizer(newSource));
        }
        /**
         * @return Whether this bitmap supports counter-clockwise rotation.
         */
        isRotateSupported() {
            return this.binarizer.getLuminanceSource().isRotateSupported();
        }
        /**
         * Returns a new object with rotated image data by 90 degrees counterclockwise.
         * Only callable if {@link #isRotateSupported()} is true.
         *
         * @return A rotated version of this object.
         */
        rotateCounterClockwise() {
            const newSource = this.binarizer.getLuminanceSource().rotateCounterClockwise();
            return new BinaryBitmap(this.binarizer.createBinarizer(newSource));
        }
        /**
         * Returns a new object with rotated image data by 45 degrees counterclockwise.
         * Only callable if {@link #isRotateSupported()} is true.
         *
         * @return A rotated version of this object.
         */
        rotateCounterClockwise45() {
            const newSource = this.binarizer
                .getLuminanceSource()
                .rotateCounterClockwise45();
            return new BinaryBitmap(this.binarizer.createBinarizer(newSource));
        }
        /*@Override*/
        toString() {
            try {
                return this.getBlackMatrix().toString();
            }
            catch (e /*: NotFoundException*/) {
                return "";
            }
        }
    }

    class System {
        // public static void arraycopy(Object src, int srcPos, Object dest, int destPos, int length)
        /**
         * Makes a copy of a array.
         */
        static arraycopy(src, srcPos, dest, destPos, length) {
            // TODO: better use split or set?
            while (length--) {
                dest[destPos++] = src[srcPos++];
            }
        }
        /**
         * Returns the current time in milliseconds.
         */
        static currentTimeMillis() {
            return Date.now();
        }
    }

    class Integer {
        static numberOfTrailingZeros(i) {
            let y;
            if (i === 0)
                return 32;
            let n = 31;
            y = i << 16;
            if (y !== 0) {
                n -= 16;
                i = y;
            }
            y = i << 8;
            if (y !== 0) {
                n -= 8;
                i = y;
            }
            y = i << 4;
            if (y !== 0) {
                n -= 4;
                i = y;
            }
            y = i << 2;
            if (y !== 0) {
                n -= 2;
                i = y;
            }
            return n - ((i << 1) >>> 31);
        }
        static numberOfLeadingZeros(i) {
            // HD, Figure 5-6
            if (i === 0) {
                return 32;
            }
            let n = 1;
            if (i >>> 16 === 0) {
                n += 16;
                i <<= 16;
            }
            if (i >>> 24 === 0) {
                n += 8;
                i <<= 8;
            }
            if (i >>> 28 === 0) {
                n += 4;
                i <<= 4;
            }
            if (i >>> 30 === 0) {
                n += 2;
                i <<= 2;
            }
            n -= i >>> 31;
            return n;
        }
        static toHexString(i) {
            return i.toString(16);
        }
        // Returns the number of one-bits in the two's complement binary representation of the specified int value. This function is sometimes referred to as the population count.
        // Returns:
        // the number of one-bits in the two's complement binary representation of the specified int value.
        static bitCount(i) {
            // HD, Figure 5-2
            i = i - ((i >>> 1) & 0x55555555);
            i = (i & 0x33333333) + ((i >>> 2) & 0x33333333);
            i = (i + (i >>> 4)) & 0x0f0f0f0f;
            i = i + (i >>> 8);
            i = i + (i >>> 16);
            return i & 0x3f;
        }
    }
    Integer.MIN_VALUE_32_BITS = -2147483648;

    class Arrays {
        static equals(first, second) {
            if (!first) {
                return false;
            }
            if (!second) {
                return false;
            }
            if (!first.length) {
                return false;
            }
            if (!second.length) {
                return false;
            }
            if (first.length !== second.length) {
                return false;
            }
            for (let i = 0, length = first.length; i < length; i++) {
                if (first[i] !== second[i]) {
                    return false;
                }
            }
            return true;
        }
        static hashCode(a) {
            if (a === null) {
                return 0;
            }
            let result = 1;
            for (const element of a) {
                result = 31 * result + element;
            }
            return result;
        }
        static fillUint8Array(a, value) {
            for (let i = 0; i !== a.length; i++) {
                a[i] = value;
            }
        }
        static copyOf(original, newLength) {
            const copy = new Int32Array(newLength);
            System.arraycopy(original, 0, copy, 0, Math.min(original.length, newLength));
            return copy;
        }
        /*
         * Returns the index of of the element in a sorted array or (-n-1) where n is the insertion point
         * for the new element.
         * Parameters:
         *     ar - A sorted array
         *     el - An element to search for
         *     comparator - A comparator function. The function takes two arguments: (a, b) and returns:
         *        a negative number  if a is less than b;
         *        0 if a is equal to b;
         *        a positive number of a is greater than b.
         * The array may contain duplicate elements. If there are more than one equal elements in the array,
         * the returned value can be the index of any one of the equal elements.
         *
         * http://jsfiddle.net/aryzhov/pkfst550/
         */
        static binarySearch(ar, el, comparator) {
            if (undefined === comparator) {
                comparator = Arrays.numberComparator;
            }
            let m = 0;
            let n = ar.length - 1;
            while (m <= n) {
                const k = (n + m) >> 1;
                const cmp = comparator(el, ar[k]);
                if (cmp > 0) {
                    m = k + 1;
                }
                else if (cmp < 0) {
                    n = k - 1;
                }
                else {
                    return k;
                }
            }
            return -m - 1;
        }
        static numberComparator(a, b) {
            return a - b;
        }
    }

    /*
     * Copyright 2007 ZXing authors
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *      http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */
    /**
     * <p>A simple, fast array of bits, represented compactly by an array of ints internally.</p>
     *
     * @author Sean Owen
     */
    class BitArray /*implements Cloneable*/ {
        // public constructor() {
        //   this.size = 0
        //   this.bits = new Int32Array(1)
        // }
        // public constructor(size?: number /*int*/) {
        //   if (undefined === size) {
        //     this.size = 0
        //   } else {
        //     this.size = size
        //   }
        //   this.bits = this.makeArray(size)
        // }
        // For testing only
        constructor(size /*int*/, bits) {
            if (undefined === size) {
                this.size = 0;
                this.bits = new Int32Array(1);
            }
            else {
                this.size = size;
                if (undefined === bits || null === bits) {
                    this.bits = BitArray.makeArray(size);
                }
                else {
                    this.bits = bits;
                }
            }
        }
        getSize() {
            return this.size;
        }
        getSizeInBytes() {
            return Math.floor((this.size + 7) / 8);
        }
        ensureCapacity(size /*int*/) {
            if (size > this.bits.length * 32) {
                const newBits = BitArray.makeArray(size);
                System.arraycopy(this.bits, 0, newBits, 0, this.bits.length);
                this.bits = newBits;
            }
        }
        /**
         * @param i bit to get
         * @return true iff bit i is set
         */
        get(i /*int*/) {
            return (this.bits[Math.floor(i / 32)] & (1 << (i & 0x1f))) !== 0;
        }
        /**
         * Sets bit i.
         *
         * @param i bit to set
         */
        set(i /*int*/) {
            this.bits[Math.floor(i / 32)] |= 1 << (i & 0x1f);
        }
        /**
         * Flips bit i.
         *
         * @param i bit to set
         */
        flip(i /*int*/) {
            this.bits[Math.floor(i / 32)] ^= 1 << (i & 0x1f);
        }
        /**
         * @param from first bit to check
         * @return index of first bit that is set, starting from the given index, or size if none are set
         *  at or beyond this given index
         * @see #getNextUnset(int)
         */
        getNextSet(from /*int*/) {
            const size = this.size;
            if (from >= size) {
                return size;
            }
            const bits = this.bits;
            let bitsOffset = Math.floor(from / 32);
            let currentBits = bits[bitsOffset];
            // mask off lesser bits first
            currentBits &= ~((1 << (from & 0x1f)) - 1);
            const length = bits.length;
            while (currentBits === 0) {
                if (++bitsOffset === length) {
                    return size;
                }
                currentBits = bits[bitsOffset];
            }
            const result = bitsOffset * 32 + Integer.numberOfTrailingZeros(currentBits);
            return result > size ? size : result;
        }
        /**
         * @param from index to start looking for unset bit
         * @return index of next unset bit, or {@code size} if none are unset until the end
         * @see #getNextSet(int)
         */
        getNextUnset(from /*int*/) {
            const size = this.size;
            if (from >= size) {
                return size;
            }
            const bits = this.bits;
            let bitsOffset = Math.floor(from / 32);
            let currentBits = ~bits[bitsOffset];
            // mask off lesser bits first
            currentBits &= ~((1 << (from & 0x1f)) - 1);
            const length = bits.length;
            while (currentBits === 0) {
                if (++bitsOffset === length) {
                    return size;
                }
                currentBits = ~bits[bitsOffset];
            }
            const result = bitsOffset * 32 + Integer.numberOfTrailingZeros(currentBits);
            return result > size ? size : result;
        }
        /**
         * Sets a block of 32 bits, starting at bit i.
         *
         * @param i first bit to set
         * @param newBits the new value of the next 32 bits. Note again that the least-significant bit
         * corresponds to bit i, the next-least-significant to i+1, and so on.
         */
        setBulk(i /*int*/, newBits /*int*/) {
            this.bits[Math.floor(i / 32)] = newBits;
        }
        /**
         * Sets a range of bits.
         *
         * @param start start of range, inclusive.
         * @param end end of range, exclusive
         */
        setRange(start /*int*/, end /*int*/) {
            if (end < start || start < 0 || end > this.size) {
                throw new IllegalArgumentException();
            }
            if (end === start) {
                return;
            }
            end--; // will be easier to treat this as the last actually set bit -- inclusive
            const firstInt = Math.floor(start / 32);
            const lastInt = Math.floor(end / 32);
            const bits = this.bits;
            for (let i = firstInt; i <= lastInt; i++) {
                const firstBit = i > firstInt ? 0 : start & 0x1f;
                const lastBit = i < lastInt ? 31 : end & 0x1f;
                // Ones from firstBit to lastBit, inclusive
                const mask = (2 << lastBit) - (1 << firstBit);
                bits[i] |= mask;
            }
        }
        /**
         * Clears all bits (sets to false).
         */
        clear() {
            const max = this.bits.length;
            const bits = this.bits;
            for (let i = 0; i < max; i++) {
                bits[i] = 0;
            }
        }
        /**
         * Efficient method to check if a range of bits is set, or not set.
         *
         * @param start start of range, inclusive.
         * @param end end of range, exclusive
         * @param value if true, checks that bits in range are set, otherwise checks that they are not set
         * @return true iff all bits are set or not set in range, according to value argument
         * @throws IllegalArgumentException if end is less than start or the range is not contained in the array
         */
        isRange(start /*int*/, end /*int*/, value) {
            if (end < start || start < 0 || end > this.size) {
                throw new IllegalArgumentException();
            }
            if (end === start) {
                return true; // empty range matches
            }
            end--; // will be easier to treat this as the last actually set bit -- inclusive
            const firstInt = Math.floor(start / 32);
            const lastInt = Math.floor(end / 32);
            const bits = this.bits;
            for (let i = firstInt; i <= lastInt; i++) {
                const firstBit = i > firstInt ? 0 : start & 0x1f;
                const lastBit = i < lastInt ? 31 : end & 0x1f;
                // Ones from firstBit to lastBit, inclusive
                const mask = ((2 << lastBit) - (1 << firstBit)) & 0xffffffff;
                // TYPESCRIPTPORT: & 0xFFFFFFFF added to discard anything after 32 bits, as ES has 53 bits
                // Return false if we're looking for 1s and the masked bits[i] isn't all 1s (is: that,
                // equals the mask, or we're looking for 0s and the masked portion is not all 0s
                if ((bits[i] & mask) !== (value ? mask : 0)) {
                    return false;
                }
            }
            return true;
        }
        appendBit(bit) {
            this.ensureCapacity(this.size + 1);
            if (bit) {
                this.bits[Math.floor(this.size / 32)] |= 1 << (this.size & 0x1f);
            }
            this.size++;
        }
        /**
         * Appends the least-significant bits, from value, in order from most-significant to
         * least-significant. For example, appending 6 bits from 0x000001E will append the bits
         * 0, 1, 1, 1, 1, 0 in that order.
         *
         * @param value {@code int} containing bits to append
         * @param numBits bits from value to append
         */
        appendBits(value /*int*/, numBits /*int*/) {
            if (numBits < 0 || numBits > 32) {
                throw new IllegalArgumentException("Num bits must be between 0 and 32");
            }
            this.ensureCapacity(this.size + numBits);
            this.appendBit;
            for (let numBitsLeft = numBits; numBitsLeft > 0; numBitsLeft--) {
                this.appendBit(((value >> (numBitsLeft - 1)) & 0x01) === 1);
            }
        }
        appendBitArray(other) {
            const otherSize = other.size;
            this.ensureCapacity(this.size + otherSize);
            this.appendBit;
            for (let i = 0; i < otherSize; i++) {
                this.appendBit(other.get(i));
            }
        }
        xor(other) {
            if (this.size !== other.size) {
                throw new IllegalArgumentException("Sizes don't match");
            }
            const bits = this.bits;
            for (let i = 0, length = bits.length; i < length; i++) {
                // The last int could be incomplete (i.e. not have 32 bits in
                // it) but there is no problem since 0 XOR 0 == 0.
                bits[i] ^= other.bits[i];
            }
        }
        /**
         *
         * @param bitOffset first bit to start writing
         * @param array array to write into. Bytes are written most-significant byte first. This is the opposite
         *  of the internal representation, which is exposed by {@link #getBitArray()}
         * @param offset position in array to start writing
         * @param numBytes how many bytes to write
         */
        toBytes(bitOffset /*int*/, array, offset /*int*/, numBytes /*int*/) {
            for (let i = 0; i < numBytes; i++) {
                let theByte = 0;
                for (let j = 0; j < 8; j++) {
                    if (this.get(bitOffset)) {
                        theByte |= 1 << (7 - j);
                    }
                    bitOffset++;
                }
                array[offset + i] = /*(byte)*/ theByte;
            }
        }
        /**
         * @return underlying array of ints. The first element holds the first 32 bits, and the least
         *         significant bit is bit 0.
         */
        getBitArray() {
            return this.bits;
        }
        /**
         * Reverses all bits in the array.
         */
        reverse() {
            const newBits = new Int32Array(this.bits.length);
            // reverse all int's first
            const len = Math.floor((this.size - 1) / 32);
            const oldBitsLen = len + 1;
            const bits = this.bits;
            for (let i = 0; i < oldBitsLen; i++) {
                let x = bits[i];
                x = ((x >> 1) & 0x55555555) | ((x & 0x55555555) << 1);
                x = ((x >> 2) & 0x33333333) | ((x & 0x33333333) << 2);
                x = ((x >> 4) & 0x0f0f0f0f) | ((x & 0x0f0f0f0f) << 4);
                x = ((x >> 8) & 0x00ff00ff) | ((x & 0x00ff00ff) << 8);
                x = ((x >> 16) & 0x0000ffff) | ((x & 0x0000ffff) << 16);
                newBits[len - i] = /*(int)*/ x;
            }
            // now correct the int's if the bit size isn't a multiple of 32
            if (this.size !== oldBitsLen * 32) {
                const leftOffset = oldBitsLen * 32 - this.size;
                let currentInt = newBits[0] >>> leftOffset;
                for (let i = 1; i < oldBitsLen; i++) {
                    const nextInt = newBits[i];
                    currentInt |= nextInt << (32 - leftOffset);
                    newBits[i - 1] = currentInt;
                    currentInt = nextInt >>> leftOffset;
                }
                newBits[oldBitsLen - 1] = currentInt;
            }
            this.bits = newBits;
        }
        static makeArray(size /*int*/) {
            return new Int32Array(Math.floor((size + 31) / 32));
        }
        /*@Override*/
        equals(o) {
            if (!(o instanceof BitArray)) {
                return false;
            }
            const other = o;
            return this.size === other.size && Arrays.equals(this.bits, other.bits);
        }
        /*@Override*/
        hashCode() {
            return 31 * this.size + Arrays.hashCode(this.bits);
        }
        /*@Override*/
        toString() {
            let result = "";
            for (let i = 0, size = this.size; i < size; i++) {
                if ((i & 0x07) === 0) {
                    result += " ";
                }
                result += this.get(i) ? "X" : ".";
            }
            return result;
        }
        /*@Override*/
        clone() {
            return new BitArray(this.size, this.bits.slice());
        }
    }

    class StringBuilder {
        constructor(value = "") {
            this.value = value;
        }
        append(s) {
            if (typeof s === "string") {
                this.value += s.toString();
            }
            else {
                this.value += String.fromCharCode(s);
            }
            return this;
        }
        length() {
            return this.value.length;
        }
        charAt(n) {
            return this.value.charAt(n);
        }
        deleteCharAt(n) {
            this.value = this.value.substr(0, n) + this.value.substring(n + 1);
        }
        setCharAt(n, c) {
            this.value = this.value.substr(0, n) + c + this.value.substr(n + 1);
        }
        toString() {
            return this.value;
        }
        insert(n, c) {
            this.value = this.value.substr(0, n) + c + this.value.substr(n + c.length);
        }
    }

    /*
     * Copyright 2007 ZXing authors
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *      http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */
    /**
     * <p>Represents a 2D matrix of bits. In function arguments below, and throughout the common
     * module, x is the column position, and y is the row position. The ordering is always x, y.
     * The origin is at the top-left.</p>
     *
     * <p>Internally the bits are represented in a 1-D array of 32-bit ints. However, each row begins
     * with a new int. This is done intentionally so that we can copy out a row into a BitArray very
     * efficiently.</p>
     *
     * <p>The ordering of bits is row-major. Within each int, the least significant bits are used first,
     * meaning they represent lower x values. This is compatible with BitArray's implementation.</p>
     *
     * @author Sean Owen
     * @author dswitkin@google.com (Daniel Switkin)
     */
    class BitMatrix /*implements Cloneable*/ {
        constructor(width /*int*/, height /*int*/, rowSize /*int*/, bits) {
            this.width = width;
            if (undefined === height || null === height) {
                height = width;
            }
            this.height = height;
            if (width < 1 || height < 1) {
                throw new IllegalArgumentException("Both dimensions must be greater than 0");
            }
            if (undefined === rowSize || null === rowSize) {
                rowSize = Math.floor((width + 31) / 32);
            }
            this.rowSize = rowSize;
            if (undefined === bits || null === bits) {
                this.bits = new Int32Array(this.rowSize * this.height);
            }
            else {
                this.bits = bits;
            }
        }
        /**
         * Interprets a 2D array of booleans as a {@link BitMatrix}, where "true" means an "on" bit.
         *
         * @param image bits of the image, as a row-major 2D array. Elements are arrays representing rows
         * @return {@link BitMatrix} representation of image
         */
        static parseFromBooleanArray(image) {
            const height = image.length;
            const width = image[0].length;
            const bits = new BitMatrix(width, height);
            for (let i = 0; i < height; i++) {
                const imageI = image[i];
                for (let j = 0; j < width; j++) {
                    if (imageI[j]) {
                        bits.set(j, i);
                    }
                }
            }
            return bits;
        }
        static parseFromString(stringRepresentation, setString, unsetString) {
            if (stringRepresentation === null) {
                throw new IllegalArgumentException("stringRepresentation cannot be null");
            }
            const bits = new Array(stringRepresentation.length);
            let bitsPos = 0;
            let rowStartPos = 0;
            let rowLength = -1;
            let nRows = 0;
            let pos = 0;
            while (pos < stringRepresentation.length) {
                if (stringRepresentation.charAt(pos) === "\n" || stringRepresentation.charAt(pos) === "\r") {
                    if (bitsPos > rowStartPos) {
                        if (rowLength === -1) {
                            rowLength = bitsPos - rowStartPos;
                        }
                        else if (bitsPos - rowStartPos !== rowLength) {
                            throw new IllegalArgumentException("row lengths do not match");
                        }
                        rowStartPos = bitsPos;
                        nRows++;
                    }
                    pos++;
                }
                else if (stringRepresentation.substring(pos, pos + setString.length) === setString) {
                    pos += setString.length;
                    bits[bitsPos] = true;
                    bitsPos++;
                }
                else if (stringRepresentation.substring(pos, pos + unsetString.length) === unsetString) {
                    pos += unsetString.length;
                    bits[bitsPos] = false;
                    bitsPos++;
                }
                else {
                    throw new IllegalArgumentException("illegal character encountered: " + stringRepresentation.substring(pos));
                }
            }
            // no EOL at end?
            if (bitsPos > rowStartPos) {
                if (rowLength === -1) {
                    rowLength = bitsPos - rowStartPos;
                }
                else if (bitsPos - rowStartPos !== rowLength) {
                    throw new IllegalArgumentException("row lengths do not match");
                }
                nRows++;
            }
            const matrix = new BitMatrix(rowLength, nRows);
            for (let i = 0; i < bitsPos; i++) {
                if (bits[i]) {
                    matrix.set(Math.floor(i % rowLength), Math.floor(i / rowLength));
                }
            }
            return matrix;
        }
        /**
         * <p>Gets the requested bit, where true means black.</p>
         *
         * @param x The horizontal component (i.e. which column)
         * @param y The vertical component (i.e. which row)
         * @return value of given bit in matrix
         */
        get(x /*int*/, y /*int*/) {
            const offset = y * this.rowSize + Math.floor(x / 32);
            return ((this.bits[offset] >>> (x & 0x1f)) & 1) !== 0;
        }
        /**
         * <p>Sets the given bit to true.</p>
         *
         * @param x The horizontal component (i.e. which column)
         * @param y The vertical component (i.e. which row)
         */
        set(x /*int*/, y /*int*/) {
            const offset = y * this.rowSize + Math.floor(x / 32);
            this.bits[offset] |= (1 << (x & 0x1f)) & 0xffffffff;
        }
        unset(x /*int*/, y /*int*/) {
            const offset = y * this.rowSize + Math.floor(x / 32);
            this.bits[offset] &= ~((1 << (x & 0x1f)) & 0xffffffff);
        }
        /**
         * <p>Flips the given bit.</p>
         *
         * @param x The horizontal component (i.e. which column)
         * @param y The vertical component (i.e. which row)
         */
        flip(x /*int*/, y /*int*/) {
            const offset = y * this.rowSize + Math.floor(x / 32);
            this.bits[offset] ^= (1 << (x & 0x1f)) & 0xffffffff;
        }
        /**
         * Exclusive-or (XOR): Flip the bit in this {@code BitMatrix} if the corresponding
         * mask bit is set.
         *
         * @param mask XOR mask
         */
        xor(mask) {
            if (this.width !== mask.getWidth() ||
                this.height !== mask.getHeight() ||
                this.rowSize !== mask.getRowSize()) {
                throw new IllegalArgumentException("input matrix dimensions do not match");
            }
            const rowArray = new BitArray(Math.floor(this.width / 32) + 1);
            const rowSize = this.rowSize;
            const bits = this.bits;
            for (let y = 0, height = this.height; y < height; y++) {
                const offset = y * rowSize;
                const row = mask.getRow(y, rowArray).getBitArray();
                for (let x = 0; x < rowSize; x++) {
                    bits[offset + x] ^= row[x];
                }
            }
        }
        /**
         * Clears all bits (sets to false).
         */
        clear() {
            const bits = this.bits;
            const max = bits.length;
            for (let i = 0; i < max; i++) {
                bits[i] = 0;
            }
        }
        /**
         * <p>Sets a square region of the bit matrix to true.</p>
         *
         * @param left The horizontal position to begin at (inclusive)
         * @param top The vertical position to begin at (inclusive)
         * @param width The width of the region
         * @param height The height of the region
         */
        setRegion(left /*int*/, top /*int*/, width /*int*/, height /*int*/) {
            if (top < 0 || left < 0) {
                throw new IllegalArgumentException("Left and top must be nonnegative");
            }
            if (height < 1 || width < 1) {
                throw new IllegalArgumentException("Height and width must be at least 1");
            }
            const right = left + width;
            const bottom = top + height;
            if (bottom > this.height || right > this.width) {
                throw new IllegalArgumentException("The region must fit inside the matrix");
            }
            const rowSize = this.rowSize;
            const bits = this.bits;
            for (let y = top; y < bottom; y++) {
                const offset = y * rowSize;
                for (let x = left; x < right; x++) {
                    bits[offset + Math.floor(x / 32)] |= (1 << (x & 0x1f)) & 0xffffffff;
                }
            }
        }
        /**
         * A fast method to retrieve one row of data from the matrix as a BitArray.
         *
         * @param y The row to retrieve
         * @param row An optional caller-allocated BitArray, will be allocated if null or too small
         * @return The resulting BitArray - this reference should always be used even when passing
         *         your own row
         */
        getRow(y /*int*/, row) {
            if (row === null || row === undefined || row.getSize() < this.width) {
                row = new BitArray(this.width);
            }
            else {
                row.clear();
            }
            const rowSize = this.rowSize;
            const bits = this.bits;
            const offset = y * rowSize;
            for (let x = 0; x < rowSize; x++) {
                row.setBulk(x * 32, bits[offset + x]);
            }
            return row;
        }
        /**
         * @param y row to set
         * @param row {@link BitArray} to copy from
         */
        setRow(y /*int*/, row) {
            System.arraycopy(row.getBitArray(), 0, this.bits, y * this.rowSize, this.rowSize);
        }
        /**
         * Modifies this {@code BitMatrix} to represent the same but rotated 180 degrees
         */
        rotate180() {
            const width = this.getWidth();
            const height = this.getHeight();
            let topRow = new BitArray(width);
            let bottomRow = new BitArray(width);
            for (let i = 0, length = Math.floor((height + 1) / 2); i < length; i++) {
                topRow = this.getRow(i, topRow);
                bottomRow = this.getRow(height - 1 - i, bottomRow);
                topRow.reverse();
                bottomRow.reverse();
                this.setRow(i, bottomRow);
                this.setRow(height - 1 - i, topRow);
            }
        }
        /**
         * This is useful in detecting the enclosing rectangle of a 'pure' barcode.
         *
         * @return {@code left,top,width,height} enclosing rectangle of all 1 bits, or null if it is all white
         */
        getEnclosingRectangle() {
            const width = this.width;
            const height = this.height;
            const rowSize = this.rowSize;
            const bits = this.bits;
            let left = width;
            let top = height;
            let right = -1;
            let bottom = -1;
            for (let y = 0; y < height; y++) {
                for (let x32 = 0; x32 < rowSize; x32++) {
                    const theBits = bits[y * rowSize + x32];
                    if (theBits !== 0) {
                        if (y < top) {
                            top = y;
                        }
                        if (y > bottom) {
                            bottom = y;
                        }
                        if (x32 * 32 < left) {
                            let bit = 0;
                            while (((theBits << (31 - bit)) & 0xffffffff) === 0) {
                                bit++;
                            }
                            if (x32 * 32 + bit < left) {
                                left = x32 * 32 + bit;
                            }
                        }
                        if (x32 * 32 + 31 > right) {
                            let bit = 31;
                            while (theBits >>> bit === 0) {
                                bit--;
                            }
                            if (x32 * 32 + bit > right) {
                                right = x32 * 32 + bit;
                            }
                        }
                    }
                }
            }
            if (right < left || bottom < top) {
                return null;
            }
            return Int32Array.from([left, top, right - left + 1, bottom - top + 1]);
        }
        /**
         * This is useful in detecting a corner of a 'pure' barcode.
         *
         * @return {@code x,y} coordinate of top-left-most 1 bit, or null if it is all white
         */
        getTopLeftOnBit() {
            const rowSize = this.rowSize;
            const bits = this.bits;
            let bitsOffset = 0;
            while (bitsOffset < bits.length && bits[bitsOffset] === 0) {
                bitsOffset++;
            }
            if (bitsOffset === bits.length) {
                return null;
            }
            const y = bitsOffset / rowSize;
            let x = (bitsOffset % rowSize) * 32;
            const theBits = bits[bitsOffset];
            let bit = 0;
            while (((theBits << (31 - bit)) & 0xffffffff) === 0) {
                bit++;
            }
            x += bit;
            return Int32Array.from([x, y]);
        }
        getBottomRightOnBit() {
            const rowSize = this.rowSize;
            const bits = this.bits;
            let bitsOffset = bits.length - 1;
            while (bitsOffset >= 0 && bits[bitsOffset] === 0) {
                bitsOffset--;
            }
            if (bitsOffset < 0) {
                return null;
            }
            const y = Math.floor(bitsOffset / rowSize);
            let x = Math.floor(bitsOffset % rowSize) * 32;
            const theBits = bits[bitsOffset];
            let bit = 31;
            while (theBits >>> bit === 0) {
                bit--;
            }
            x += bit;
            return Int32Array.from([x, y]);
        }
        /**
         * @return The width of the matrix
         */
        getWidth() {
            return this.width;
        }
        /**
         * @return The height of the matrix
         */
        getHeight() {
            return this.height;
        }
        /**
         * @return The row size of the matrix
         */
        getRowSize() {
            return this.rowSize;
        }
        /*@Override*/
        equals(o) {
            if (!(o instanceof BitMatrix)) {
                return false;
            }
            const other = o;
            return (this.width === other.width &&
                this.height === other.height &&
                this.rowSize === other.rowSize &&
                Arrays.equals(this.bits, other.bits));
        }
        /*@Override*/
        hashCode() {
            let hash = this.width;
            hash = 31 * hash + this.width;
            hash = 31 * hash + this.height;
            hash = 31 * hash + this.rowSize;
            hash = 31 * hash + Arrays.hashCode(this.bits);
            return hash;
        }
        /**
         * @return string representation using "X" for set and " " for unset bits
         */
        /*@Override*/
        // public toString(): string {
        //   return toString(": "X, "  ")
        // }
        /**
         * @param setString representation of a set bit
         * @param unsetString representation of an unset bit
         * @return string representation of entire matrix utilizing given strings
         */
        // public toString(setString: string = "X ", unsetString: string = "  "): string {
        //   return this.buildToString(setString, unsetString, "\n")
        // }
        /**
         * @param setString representation of a set bit
         * @param unsetString representation of an unset bit
         * @param lineSeparator newline character in string representation
         * @return string representation of entire matrix utilizing given strings and line separator
         * @deprecated call {@link #toString(String,String)} only, which uses \n line separator always
         */
        // @Deprecated
        toString(setString = "x", unsetString = " ", lineSeparator = "\n") {
            return this.buildToString(setString, unsetString, lineSeparator);
        }
        buildToString(setString, unsetString, lineSeparator) {
            let result = new StringBuilder();
            result.append(lineSeparator);
            for (let y = 0, height = this.height; y < height; y++) {
                for (let x = 0, width = this.width; x < width; x++) {
                    result.append(this.get(x, y) ? setString : unsetString);
                }
                result.append(lineSeparator);
            }
            return result.toString();
        }
        /*@Override*/
        clone() {
            return new BitMatrix(this.width, this.height, this.rowSize, this.bits.slice());
        }
    }

    /*
     * Copyright 2007 ZXing authors
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *      http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */
    /**
     * <p>This provides an easy abstraction to read bits at a time from a sequence of bytes, where the
     * number of bits read is not often a multiple of 8.</p>
     *
     * <p>This class is thread-safe but not reentrant -- unless the caller modifies the bytes array
     * it passed in, in which case all bets are off.</p>
     *
     * @author Sean Owen
     */
    class BitSource {
        /**
         * @param bytes bytes from which this will read bits. Bits will be read from the first byte first.
         * Bits are read within a byte from most-significant to least-significant bit.
         */
        constructor(bytes) {
            this.bytes = bytes;
            this.byteOffset = 0;
            this.bitOffset = 0;
        }
        /**
         * @return index of next bit in current byte which would be read by the next call to {@link #readBits(int)}.
         */
        getBitOffset() {
            return this.bitOffset;
        }
        /**
         * @return index of next byte in input byte array which would be read by the next call to {@link #readBits(int)}.
         */
        getByteOffset() {
            return this.byteOffset;
        }
        /**
         * @param numBits number of bits to read
         * @return int representing the bits read. The bits will appear as the least-significant
         *         bits of the int
         * @throws IllegalArgumentException if numBits isn't in [1,32] or more than is available
         */
        readBits(numBits /*int*/) {
            if (numBits < 1 || numBits > 32 || numBits > this.available()) {
                throw new IllegalArgumentException("" + numBits);
            }
            let result = 0;
            let bitOffset = this.bitOffset;
            let byteOffset = this.byteOffset;
            const bytes = this.bytes;
            // First, read remainder from current byte
            if (bitOffset > 0) {
                const bitsLeft = 8 - bitOffset;
                const toRead = numBits < bitsLeft ? numBits : bitsLeft;
                const bitsToNotRead = bitsLeft - toRead;
                const mask = (0xff >> (8 - toRead)) << bitsToNotRead;
                result = (bytes[byteOffset] & mask) >> bitsToNotRead;
                numBits -= toRead;
                bitOffset += toRead;
                if (bitOffset === 8) {
                    bitOffset = 0;
                    byteOffset++;
                }
            }
            // Next read whole bytes
            if (numBits > 0) {
                while (numBits >= 8) {
                    result = (result << 8) | (bytes[byteOffset] & 0xff);
                    byteOffset++;
                    numBits -= 8;
                }
                // Finally read a partial byte
                if (numBits > 0) {
                    const bitsToNotRead = 8 - numBits;
                    const mask = (0xff >> bitsToNotRead) << bitsToNotRead;
                    result = (result << numBits) | ((bytes[byteOffset] & mask) >> bitsToNotRead);
                    bitOffset += numBits;
                }
            }
            this.bitOffset = bitOffset;
            this.byteOffset = byteOffset;
            return result;
        }
        /**
         * @return number of bits that can be read successfully
         */
        available() {
            return 8 * (this.bytes.length - this.byteOffset) - this.bitOffset;
        }
    }

    /*
     * Direct port to TypeScript of ZXing by Adrian Toșcă
     */
    /*
     * Copyright 2009 ZXing authors
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *      http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */
    /*namespace com.google.zxing {*/
    /**
     * Enumerates barcode formats known to this package. Please keep alphabetized.
     *
     * @author Sean Owen
     */
    var BarcodeFormat;
    (function (BarcodeFormat) {
        /** Aztec 2D barcode format. */
        BarcodeFormat[BarcodeFormat["AZTEC"] = 0] = "AZTEC";
        /** CODABAR 1D format. */
        BarcodeFormat[BarcodeFormat["CODABAR"] = 1] = "CODABAR";
        /** Code 39 1D format. */
        BarcodeFormat[BarcodeFormat["CODE_39"] = 2] = "CODE_39";
        /** Code 93 1D format. */
        BarcodeFormat[BarcodeFormat["CODE_93"] = 3] = "CODE_93";
        /** Code 128 1D format. */
        BarcodeFormat[BarcodeFormat["CODE_128"] = 4] = "CODE_128";
        /** Data Matrix 2D barcode format. */
        BarcodeFormat[BarcodeFormat["DATA_MATRIX"] = 5] = "DATA_MATRIX";
        /** EAN-8 1D format. */
        BarcodeFormat[BarcodeFormat["EAN_8"] = 6] = "EAN_8";
        /** EAN-13 1D format. */
        BarcodeFormat[BarcodeFormat["EAN_13"] = 7] = "EAN_13";
        /** ITF (Interleaved Two of Five) 1D format. */
        BarcodeFormat[BarcodeFormat["ITF"] = 8] = "ITF";
        /** MaxiCode 2D barcode format. */
        BarcodeFormat[BarcodeFormat["MAXICODE"] = 9] = "MAXICODE";
        /** PDF417 format. */
        BarcodeFormat[BarcodeFormat["PDF_417"] = 10] = "PDF_417";
        /** QR Code 2D barcode format. */
        BarcodeFormat[BarcodeFormat["QR_CODE"] = 11] = "QR_CODE";
        /** RSS 14 */
        BarcodeFormat[BarcodeFormat["RSS_14"] = 12] = "RSS_14";
        /** RSS EXPANDED */
        BarcodeFormat[BarcodeFormat["RSS_EXPANDED"] = 13] = "RSS_EXPANDED";
        /** UPC-A 1D format. */
        BarcodeFormat[BarcodeFormat["UPC_A"] = 14] = "UPC_A";
        /** UPC-E 1D format. */
        BarcodeFormat[BarcodeFormat["UPC_E"] = 15] = "UPC_E";
        /** UPC/EAN extension format. Not a stand-alone format. */
        BarcodeFormat[BarcodeFormat["UPC_EAN_EXTENSION"] = 16] = "UPC_EAN_EXTENSION";
    })(BarcodeFormat || (BarcodeFormat = {}));

    var CharacterSetValueIdentifiers;
    (function (CharacterSetValueIdentifiers) {
        CharacterSetValueIdentifiers[CharacterSetValueIdentifiers["Cp437"] = 0] = "Cp437";
        CharacterSetValueIdentifiers[CharacterSetValueIdentifiers["ISO8859_1"] = 1] = "ISO8859_1";
        CharacterSetValueIdentifiers[CharacterSetValueIdentifiers["ISO8859_2"] = 2] = "ISO8859_2";
        CharacterSetValueIdentifiers[CharacterSetValueIdentifiers["ISO8859_3"] = 3] = "ISO8859_3";
        CharacterSetValueIdentifiers[CharacterSetValueIdentifiers["ISO8859_4"] = 4] = "ISO8859_4";
        CharacterSetValueIdentifiers[CharacterSetValueIdentifiers["ISO8859_5"] = 5] = "ISO8859_5";
        CharacterSetValueIdentifiers[CharacterSetValueIdentifiers["ISO8859_6"] = 6] = "ISO8859_6";
        CharacterSetValueIdentifiers[CharacterSetValueIdentifiers["ISO8859_7"] = 7] = "ISO8859_7";
        CharacterSetValueIdentifiers[CharacterSetValueIdentifiers["ISO8859_8"] = 8] = "ISO8859_8";
        CharacterSetValueIdentifiers[CharacterSetValueIdentifiers["ISO8859_9"] = 9] = "ISO8859_9";
        CharacterSetValueIdentifiers[CharacterSetValueIdentifiers["ISO8859_10"] = 10] = "ISO8859_10";
        CharacterSetValueIdentifiers[CharacterSetValueIdentifiers["ISO8859_11"] = 11] = "ISO8859_11";
        CharacterSetValueIdentifiers[CharacterSetValueIdentifiers["ISO8859_13"] = 12] = "ISO8859_13";
        CharacterSetValueIdentifiers[CharacterSetValueIdentifiers["ISO8859_14"] = 13] = "ISO8859_14";
        CharacterSetValueIdentifiers[CharacterSetValueIdentifiers["ISO8859_15"] = 14] = "ISO8859_15";
        CharacterSetValueIdentifiers[CharacterSetValueIdentifiers["ISO8859_16"] = 15] = "ISO8859_16";
        CharacterSetValueIdentifiers[CharacterSetValueIdentifiers["SJIS"] = 16] = "SJIS";
        CharacterSetValueIdentifiers[CharacterSetValueIdentifiers["Cp1250"] = 17] = "Cp1250";
        CharacterSetValueIdentifiers[CharacterSetValueIdentifiers["Cp1251"] = 18] = "Cp1251";
        CharacterSetValueIdentifiers[CharacterSetValueIdentifiers["Cp1252"] = 19] = "Cp1252";
        CharacterSetValueIdentifiers[CharacterSetValueIdentifiers["Cp1256"] = 20] = "Cp1256";
        CharacterSetValueIdentifiers[CharacterSetValueIdentifiers["UnicodeBigUnmarked"] = 21] = "UnicodeBigUnmarked";
        CharacterSetValueIdentifiers[CharacterSetValueIdentifiers["UTF8"] = 22] = "UTF8";
        CharacterSetValueIdentifiers[CharacterSetValueIdentifiers["ASCII"] = 23] = "ASCII";
        CharacterSetValueIdentifiers[CharacterSetValueIdentifiers["Big5"] = 24] = "Big5";
        CharacterSetValueIdentifiers[CharacterSetValueIdentifiers["GB18030"] = 25] = "GB18030";
        CharacterSetValueIdentifiers[CharacterSetValueIdentifiers["EUC_KR"] = 26] = "EUC_KR";
    })(CharacterSetValueIdentifiers || (CharacterSetValueIdentifiers = {}));

    var DataMaskValues;
    (function (DataMaskValues) {
        DataMaskValues[DataMaskValues["DATA_MASK_000"] = 0] = "DATA_MASK_000";
        DataMaskValues[DataMaskValues["DATA_MASK_001"] = 1] = "DATA_MASK_001";
        DataMaskValues[DataMaskValues["DATA_MASK_010"] = 2] = "DATA_MASK_010";
        DataMaskValues[DataMaskValues["DATA_MASK_011"] = 3] = "DATA_MASK_011";
        DataMaskValues[DataMaskValues["DATA_MASK_100"] = 4] = "DATA_MASK_100";
        DataMaskValues[DataMaskValues["DATA_MASK_101"] = 5] = "DATA_MASK_101";
        DataMaskValues[DataMaskValues["DATA_MASK_110"] = 6] = "DATA_MASK_110";
        DataMaskValues[DataMaskValues["DATA_MASK_111"] = 7] = "DATA_MASK_111";
    })(DataMaskValues || (DataMaskValues = {}));

    /*
     * Copyright 2009 ZXing authors
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *      http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */
    /*namespace com.google.zxing {*/
    /**
     * Encapsulates a type of hint that a caller may pass to a barcode reader to help it
     * more quickly or accurately decode it. It is up to implementations to decide what,
     * if anything, to do with the information that is supplied.
     *
     * @author Sean Owen
     * @author dswitkin@google.com (Daniel Switkin)
     * @see Reader#decode(BinaryBitmap,java.util.Map)
     */
    var DecodeHintType;
    (function (DecodeHintType) {
        /**
         * Unspecified, application-specific hint. Maps to an unspecified {@link Object}.
         */
        DecodeHintType[DecodeHintType["OTHER"] = 0] = "OTHER"; /*(Object.class)*/
        /**
         * Image is a pure monochrome image of a barcode. Doesn't matter what it maps to;
         * use {@link Boolean#TRUE}.
         */
        DecodeHintType[DecodeHintType["PURE_BARCODE"] = 1] = "PURE_BARCODE"; /*(Void.class)*/
        /**
         * Image is known to be of one of a few possible formats.
         * Maps to a {@link List} of {@link BarcodeFormat}s.
         */
        DecodeHintType[DecodeHintType["POSSIBLE_FORMATS"] = 2] = "POSSIBLE_FORMATS"; /*(List.class)*/
        /**
         * Spend more time to try to find a barcode; optimize for accuracy, not speed.
         * Doesn't matter what it maps to; use {@link Boolean#TRUE}.
         */
        DecodeHintType[DecodeHintType["TRY_HARDER"] = 3] = "TRY_HARDER"; /*(Void.class)*/
        /**
         * Specifies what character encoding to use when decoding, where applicable (type String)
         */
        DecodeHintType[DecodeHintType["CHARACTER_SET"] = 4] = "CHARACTER_SET"; /*(String.class)*/
        /**
         * Allowed lengths of encoded data -- reject anything else. Maps to an {@code Int32Array}.
         */
        DecodeHintType[DecodeHintType["ALLOWED_LENGTHS"] = 5] = "ALLOWED_LENGTHS"; /*(Int32Array.class)*/
        /**
         * Assume Code 39 codes employ a check digit. Doesn't matter what it maps to;
         * use {@link Boolean#TRUE}.
         */
        DecodeHintType[DecodeHintType["ASSUME_CODE_39_CHECK_DIGIT"] = 6] = "ASSUME_CODE_39_CHECK_DIGIT"; /*(Void.class)*/
        /**
         * Assume the barcode is being processed as a GS1 barcode, and modify behavior as needed.
         * For example this affects FNC1 handling for Code 128 (aka GS1-128). Doesn't matter what it maps to;
         * use {@link Boolean#TRUE}.
         */
        DecodeHintType[DecodeHintType["ASSUME_GS1"] = 7] = "ASSUME_GS1"; /*(Void.class)*/
        /**
         * If true, return the start and end digits in a Codabar barcode instead of stripping them. They
         * are alpha, whereas the rest are numeric. By default, they are stripped, but this causes them
         * to not be. Doesn't matter what it maps to; use {@link Boolean#TRUE}.
         */
        DecodeHintType[DecodeHintType["RETURN_CODABAR_START_END"] = 8] = "RETURN_CODABAR_START_END"; /*(Void.class)*/
        /**
         * The caller needs to be notified via callback when a possible {@link ResultPoint}
         * is found. Maps to a {@link ResultPointCallback}.
         */
        DecodeHintType[DecodeHintType["NEED_RESULT_POINT_CALLBACK"] = 9] = "NEED_RESULT_POINT_CALLBACK"; /*(ResultPointCallback.class)*/
        /**
         * Allowed extension lengths for EAN or UPC barcodes. Other formats will ignore this.
         * Maps to an {@code Int32Array} of the allowed extension lengths, for example [2], [5], or [2, 5].
         * If it is optional to have an extension, do not set this hint. If this is set,
         * and a UPC or EAN barcode is found but an extension is not, then no result will be returned
         * at all.
         */
        DecodeHintType[DecodeHintType["ALLOWED_EAN_EXTENSIONS"] = 10] = "ALLOWED_EAN_EXTENSIONS"; /*(Int32Array.class)*/
        // End of enumeration values.
        /**
         * Data type the hint is expecting.
         * Among the possible values the {@link Void} stands out as being used for
         * hints that do not expect a value to be supplied (flag hints). Such hints
         * will possibly have their value ignored, or replaced by a
         * {@link Boolean#TRUE}. Hint suppliers should probably use
         * {@link Boolean#TRUE} as directed by the actual hint documentation.
         */
        // private valueType: Class<?>
        // DecodeHintType(valueType: Class<?>) {
        //   this.valueType = valueType
        // }
        // public getValueType(): Class<?> {
        //   return valueType
        // }
    })(DecodeHintType || (DecodeHintType = {}));

    /*
     * Copyright 2009 ZXing authors
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *      http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */
    /*namespace com.google.zxing {*/
    /**
     * These are a set of hints that you may pass to Writers to specify their behavior.
     *
     * @author dswitkin@google.com (Daniel Switkin)
     */
    var EncodeHintType;
    (function (EncodeHintType) {
        /**
         * Specifies what degree of error correction to use, for example in QR Codes.
         * Type depends on the encoder. For example for QR codes it's type
         * {@link com.google.zxing.qrcode.decoder.ErrorCorrectionLevel ErrorCorrectionLevel}.
         * For Aztec it is of type {@link Integer}, representing the minimal percentage of error correction words.
         * For PDF417 it is of type {@link Integer}, valid values being 0 to 8.
         * In all cases, it can also be a {@link String} representation of the desired value as well.
         * Note: an Aztec symbol should have a minimum of 25% EC words.
         */
        EncodeHintType[EncodeHintType["ERROR_CORRECTION"] = 0] = "ERROR_CORRECTION";
        /**
         * Specifies what character encoding to use where applicable (type {@link String})
         */
        EncodeHintType[EncodeHintType["CHARACTER_SET"] = 1] = "CHARACTER_SET";
        /**
         * Specifies the matrix shape for Data Matrix (type {@link com.google.zxing.datamatrix.encoder.SymbolShapeHint})
         */
        EncodeHintType[EncodeHintType["DATA_MATRIX_SHAPE"] = 2] = "DATA_MATRIX_SHAPE";
        /**
         * Specifies a minimum barcode size (type {@link Dimension}). Only applicable to Data Matrix now.
         *
         * @deprecated use width/height params in
         * {@link com.google.zxing.datamatrix.DataMatrixWriter#encode(String, BarcodeFormat, int, int)}
         */
        /*@Deprecated*/
        EncodeHintType[EncodeHintType["MIN_SIZE"] = 3] = "MIN_SIZE";
        /**
         * Specifies a maximum barcode size (type {@link Dimension}). Only applicable to Data Matrix now.
         *
         * @deprecated without replacement
         */
        /*@Deprecated*/
        EncodeHintType[EncodeHintType["MAX_SIZE"] = 4] = "MAX_SIZE";
        /**
         * Specifies margin, in pixels, to use when generating the barcode. The meaning can vary
         * by format; for example it controls margin before and after the barcode horizontally for
         * most 1D formats. (Type {@link Integer}, or {@link String} representation of the integer value).
         */
        EncodeHintType[EncodeHintType["MARGIN"] = 5] = "MARGIN";
        /**
         * Specifies whether to use compact mode for PDF417 (type {@link Boolean}, or "true" or "false"
         * {@link String} value).
         */
        EncodeHintType[EncodeHintType["PDF417_COMPACT"] = 6] = "PDF417_COMPACT";
        /**
         * Specifies what compaction mode to use for PDF417 (type
         * {@link com.google.zxing.pdf417.encoder.Compaction Compaction} or {@link String} value of one of its
         * enum values).
         */
        EncodeHintType[EncodeHintType["PDF417_COMPACTION"] = 7] = "PDF417_COMPACTION";
        /**
         * Specifies the minimum and maximum number of rows and columns for PDF417 (type
         * {@link com.google.zxing.pdf417.encoder.Dimensions Dimensions}).
         */
        EncodeHintType[EncodeHintType["PDF417_DIMENSIONS"] = 8] = "PDF417_DIMENSIONS";
        /**
         * Specifies the required number of layers for an Aztec code.
         * A negative number (-1, -2, -3, -4) specifies a compact Aztec code.
         * 0 indicates to use the minimum number of layers (the default).
         * A positive number (1, 2, .. 32) specifies a normal (non-compact) Aztec code.
         * (Type {@link Integer}, or {@link String} representation of the integer value).
         */
        EncodeHintType[EncodeHintType["AZTEC_LAYERS"] = 9] = "AZTEC_LAYERS";
        /**
         * Specifies the exact version of QR code to be encoded.
         * (Type {@link Integer}, or {@link String} representation of the integer value).
         */
        EncodeHintType[EncodeHintType["QR_VERSION"] = 10] = "QR_VERSION";
    })(EncodeHintType || (EncodeHintType = {}));

    var ErrorCorrectionLevelValues;
    (function (ErrorCorrectionLevelValues) {
        ErrorCorrectionLevelValues[ErrorCorrectionLevelValues["L"] = 0] = "L";
        ErrorCorrectionLevelValues[ErrorCorrectionLevelValues["M"] = 1] = "M";
        ErrorCorrectionLevelValues[ErrorCorrectionLevelValues["Q"] = 2] = "Q";
        ErrorCorrectionLevelValues[ErrorCorrectionLevelValues["H"] = 3] = "H";
    })(ErrorCorrectionLevelValues || (ErrorCorrectionLevelValues = {}));

    var ModeValues;
    (function (ModeValues) {
        ModeValues[ModeValues["TERMINATOR"] = 0] = "TERMINATOR";
        ModeValues[ModeValues["NUMERIC"] = 1] = "NUMERIC";
        ModeValues[ModeValues["ALPHANUMERIC"] = 2] = "ALPHANUMERIC";
        ModeValues[ModeValues["STRUCTURED_APPEND"] = 3] = "STRUCTURED_APPEND";
        ModeValues[ModeValues["BYTE"] = 4] = "BYTE";
        ModeValues[ModeValues["ECI"] = 5] = "ECI";
        ModeValues[ModeValues["KANJI"] = 6] = "KANJI";
        ModeValues[ModeValues["FNC1_FIRST_POSITION"] = 7] = "FNC1_FIRST_POSITION";
        ModeValues[ModeValues["FNC1_SECOND_POSITION"] = 8] = "FNC1_SECOND_POSITION";
        /** See GBT 18284-2000; "Hanzi" is a transliteration of this mode name. */
        ModeValues[ModeValues["HANZI"] = 9] = "HANZI";
    })(ModeValues || (ModeValues = {}));

    /*
     * Copyright 2008 ZXing authors
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *      http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */
    /*namespace com.google.zxing {*/
    /**
     * Represents some type of metadata about the result of the decoding that the decoder
     * wishes to communicate back to the caller.
     *
     * @author Sean Owen
     */
    var ResultMetadataType;
    (function (ResultMetadataType) {
        /**
         * Unspecified, application-specific metadata. Maps to an unspecified {@link Object}.
         */
        ResultMetadataType[ResultMetadataType["OTHER"] = 0] = "OTHER";
        /**
         * Denotes the likely approximate orientation of the barcode in the image. This value
         * is given as degrees rotated clockwise from the normal, upright orientation.
         * For example a 1D barcode which was found by reading top-to-bottom would be
         * said to have orientation "90". This key maps to an {@link Integer} whose
         * value is in the range [0,360).
         */
        ResultMetadataType[ResultMetadataType["ORIENTATION"] = 1] = "ORIENTATION";
        /**
         * <p>2D barcode formats typically encode text, but allow for a sort of 'byte mode'
         * which is sometimes used to encode binary data. While {@link Result} makes available
         * the complete raw bytes in the barcode for these formats, it does not offer the bytes
         * from the byte segments alone.</p>
         *
         * <p>This maps to a {@link java.util.List} of byte arrays corresponding to the
         * raw bytes in the byte segments in the barcode, in order.</p>
         */
        ResultMetadataType[ResultMetadataType["BYTE_SEGMENTS"] = 2] = "BYTE_SEGMENTS";
        /**
         * Error correction level used, if applicable. The value type depends on the
         * format, but is typically a String.
         */
        ResultMetadataType[ResultMetadataType["ERROR_CORRECTION_LEVEL"] = 3] = "ERROR_CORRECTION_LEVEL";
        /**
         * For some periodicals, indicates the issue number as an {@link Integer}.
         */
        ResultMetadataType[ResultMetadataType["ISSUE_NUMBER"] = 4] = "ISSUE_NUMBER";
        /**
         * For some products, indicates the suggested retail price in the barcode as a
         * formatted {@link String}.
         */
        ResultMetadataType[ResultMetadataType["SUGGESTED_PRICE"] = 5] = "SUGGESTED_PRICE";
        /**
         * For some products, the possible country of manufacture as a {@link String} denoting the
         * ISO country code. Some map to multiple possible countries, like "US/CA".
         */
        ResultMetadataType[ResultMetadataType["POSSIBLE_COUNTRY"] = 6] = "POSSIBLE_COUNTRY";
        /**
         * For some products, the extension text
         */
        ResultMetadataType[ResultMetadataType["UPC_EAN_EXTENSION"] = 7] = "UPC_EAN_EXTENSION";
        /**
         * PDF417-specific metadata
         */
        ResultMetadataType[ResultMetadataType["PDF417_EXTRA_METADATA"] = 8] = "PDF417_EXTRA_METADATA";
        /**
         * If the code format supports structured append and the current scanned code is part of one then the
         * sequence number is given with it.
         */
        ResultMetadataType[ResultMetadataType["STRUCTURED_APPEND_SEQUENCE"] = 9] = "STRUCTURED_APPEND_SEQUENCE";
        /**
         * If the code format supports structured append and the current scanned code is part of one then the
         * parity is given with it.
         */
        ResultMetadataType[ResultMetadataType["STRUCTURED_APPEND_PARITY"] = 10] = "STRUCTURED_APPEND_PARITY";
    })(ResultMetadataType || (ResultMetadataType = {}));

    /*
     * Copyright 2008 ZXing authors
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *      http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */
    /*import java.util.HashMap;*/
    /*import java.util.Map;*/
    /**
     * Encapsulates a Character Set ECI, according to "Extended Channel Interpretations" 5.3.1.1
     * of ISO 18004.
     *
     * @author Sean Owen
     */
    class CharacterSetECI {
        constructor(valueIdentifier, valuesParam, name, ...otherEncodingNames) {
            this.valueIdentifier = valueIdentifier;
            this.name = name;
            if (typeof valuesParam === "number") {
                this.values = Int32Array.from([valuesParam]);
            }
            else {
                this.values = valuesParam;
            }
            this.otherEncodingNames = otherEncodingNames;
            CharacterSetECI.VALUE_IDENTIFIER_TO_ECI.set(valueIdentifier, this);
            CharacterSetECI.NAME_TO_ECI.set(name, this);
            const values = this.values;
            for (let i = 0, length = values.length; i !== length; i++) {
                const v = values[i];
                CharacterSetECI.VALUES_TO_ECI.set(v, this);
            }
            for (const otherName of otherEncodingNames) {
                CharacterSetECI.NAME_TO_ECI.set(otherName, this);
            }
        }
        // CharacterSetECI(value: number /*int*/) {
        //   this(new Int32Array {value})
        // }
        // CharacterSetECI(value: number /*int*/, String... otherEncodingNames) {
        //   this.values = new Int32Array {value}
        //   this.otherEncodingNames = otherEncodingNames
        // }
        // CharacterSetECI(values: Int32Array, String... otherEncodingNames) {
        //   this.values = values
        //   this.otherEncodingNames = otherEncodingNames
        // }
        getValueIdentifier() {
            return this.valueIdentifier;
        }
        getName() {
            return this.name;
        }
        getValue() {
            return this.values[0];
        }
        /**
         * @param value character set ECI value
         * @return {@code CharacterSetECI} representing ECI of given value, or null if it is legal but
         *   unsupported
         * @throws FormatException if ECI value is invalid
         */
        static getCharacterSetECIByValue(value /*int*/) {
            if (value < 0 || value >= 900) {
                throw new FormatException("incorect value");
            }
            const characterSet = CharacterSetECI.VALUES_TO_ECI.get(value);
            if (undefined === characterSet) {
                throw new FormatException("incorect value");
            }
            return characterSet;
        }
        /**
         * @param name character set ECI encoding name
         * @return CharacterSetECI representing ECI for character encoding, or null if it is legal
         *   but unsupported
         */
        static getCharacterSetECIByName(name) {
            const characterSet = CharacterSetECI.NAME_TO_ECI.get(name);
            if (undefined === characterSet) {
                throw new FormatException("incorect value");
            }
            return characterSet;
        }
        equals(o) {
            if (!(o instanceof CharacterSetECI)) {
                return false;
            }
            const other = o;
            return this.getName() === other.getName();
        }
    }
    CharacterSetECI.VALUE_IDENTIFIER_TO_ECI = new Map();
    CharacterSetECI.VALUES_TO_ECI = new Map();
    CharacterSetECI.NAME_TO_ECI = new Map();
    // Enum name is a Java encoding valid for java.lang and java.io
    // TYPESCRIPTPORT: changed the main label for ISO as the TextEncoder did not recognized them in the form from java
    // (eg ISO8859_1 must be ISO88591 or ISO8859-1 or ISO-8859-1)
    // later on: well, except 16 wich does not work with ISO885916 so used ISO-8859-1 form for default
    CharacterSetECI.Cp437 = new CharacterSetECI(CharacterSetValueIdentifiers.Cp437, Int32Array.from([0, 2]), "Cp437");
    CharacterSetECI.ISO8859_1 = new CharacterSetECI(CharacterSetValueIdentifiers.ISO8859_1, Int32Array.from([1, 3]), "ISO-8859-1", "ISO88591", "ISO8859_1");
    CharacterSetECI.ISO8859_2 = new CharacterSetECI(CharacterSetValueIdentifiers.ISO8859_2, 4, "ISO-8859-2", "ISO88592", "ISO8859_2");
    CharacterSetECI.ISO8859_3 = new CharacterSetECI(CharacterSetValueIdentifiers.ISO8859_3, 5, "ISO-8859-3", "ISO88593", "ISO8859_3");
    CharacterSetECI.ISO8859_4 = new CharacterSetECI(CharacterSetValueIdentifiers.ISO8859_4, 6, "ISO-8859-4", "ISO88594", "ISO8859_4");
    CharacterSetECI.ISO8859_5 = new CharacterSetECI(CharacterSetValueIdentifiers.ISO8859_5, 7, "ISO-8859-5", "ISO88595", "ISO8859_5");
    CharacterSetECI.ISO8859_6 = new CharacterSetECI(CharacterSetValueIdentifiers.ISO8859_6, 8, "ISO-8859-6", "ISO88596", "ISO8859_6");
    CharacterSetECI.ISO8859_7 = new CharacterSetECI(CharacterSetValueIdentifiers.ISO8859_7, 9, "ISO-8859-7", "ISO88597", "ISO8859_7");
    CharacterSetECI.ISO8859_8 = new CharacterSetECI(CharacterSetValueIdentifiers.ISO8859_8, 10, "ISO-8859-8", "ISO88598", "ISO8859_8");
    CharacterSetECI.ISO8859_9 = new CharacterSetECI(CharacterSetValueIdentifiers.ISO8859_9, 11, "ISO-8859-9", "ISO88599", "ISO8859_9");
    CharacterSetECI.ISO8859_10 = new CharacterSetECI(CharacterSetValueIdentifiers.ISO8859_10, 12, "ISO-8859-10", "ISO885910", "ISO8859_10");
    CharacterSetECI.ISO8859_11 = new CharacterSetECI(CharacterSetValueIdentifiers.ISO8859_11, 13, "ISO-8859-11", "ISO885911", "ISO8859_11");
    CharacterSetECI.ISO8859_13 = new CharacterSetECI(CharacterSetValueIdentifiers.ISO8859_13, 15, "ISO-8859-13", "ISO885913", "ISO8859_13");
    CharacterSetECI.ISO8859_14 = new CharacterSetECI(CharacterSetValueIdentifiers.ISO8859_14, 16, "ISO-8859-14", "ISO885914", "ISO8859_14");
    CharacterSetECI.ISO8859_15 = new CharacterSetECI(CharacterSetValueIdentifiers.ISO8859_15, 17, "ISO-8859-15", "ISO885915", "ISO8859_15");
    CharacterSetECI.ISO8859_16 = new CharacterSetECI(CharacterSetValueIdentifiers.ISO8859_16, 18, "ISO-8859-16", "ISO885916", "ISO8859_16");
    CharacterSetECI.SJIS = new CharacterSetECI(CharacterSetValueIdentifiers.SJIS, 20, "SJIS", "Shift_JIS");
    CharacterSetECI.Cp1250 = new CharacterSetECI(CharacterSetValueIdentifiers.Cp1250, 21, "Cp1250", "windows-1250");
    CharacterSetECI.Cp1251 = new CharacterSetECI(CharacterSetValueIdentifiers.Cp1251, 22, "Cp1251", "windows-1251");
    CharacterSetECI.Cp1252 = new CharacterSetECI(CharacterSetValueIdentifiers.Cp1252, 23, "Cp1252", "windows-1252");
    CharacterSetECI.Cp1256 = new CharacterSetECI(CharacterSetValueIdentifiers.Cp1256, 24, "Cp1256", "windows-1256");
    CharacterSetECI.UnicodeBigUnmarked = new CharacterSetECI(CharacterSetValueIdentifiers.UnicodeBigUnmarked, 25, "UnicodeBigUnmarked", "UTF-16BE", "UnicodeBig");
    CharacterSetECI.UTF8 = new CharacterSetECI(CharacterSetValueIdentifiers.UTF8, 26, "UTF8", "UTF-8");
    CharacterSetECI.ASCII = new CharacterSetECI(CharacterSetValueIdentifiers.ASCII, Int32Array.from([27, 170]), "ASCII", "US-ASCII");
    CharacterSetECI.Big5 = new CharacterSetECI(CharacterSetValueIdentifiers.Big5, 28, "Big5");
    CharacterSetECI.GB18030 = new CharacterSetECI(CharacterSetValueIdentifiers.GB18030, 29, "GB18030", "GB2312", "EUC_CN", "GBK");
    CharacterSetECI.EUC_KR = new CharacterSetECI(CharacterSetValueIdentifiers.EUC_KR, 30, "EUC_KR", "EUC-KR");

    /*
     * Copyright 2007 ZXing authors
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *      http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */
    /*namespace com.google.zxing.common {*/
    /*import java.util.List;*/
    /**
     * <p>Encapsulates the result of decoding a matrix of bits. This typically
     * applies to 2D barcode formats. For now it contains the raw bytes obtained,
     * as well as a String interpretation of those bytes, if applicable.</p>
     *
     * @author Sean Owen
     */
    class DecoderResult {
        // public constructor(rawBytes: Uint8Array,
        //                      text: string,
        //                      List<Uint8Array> byteSegments,
        //                      String ecLevel) {
        //   this(rawBytes, text, byteSegments, ecLevel, -1, -1)
        // }
        constructor(rawBytes, text, byteSegments, ecLevel, structuredAppendSequenceNumber = -1, structuredAppendParity = -1) {
            this.rawBytes = rawBytes;
            this.text = text;
            this.byteSegments = byteSegments;
            this.ecLevel = ecLevel;
            this.structuredAppendSequenceNumber = structuredAppendSequenceNumber;
            this.structuredAppendParity = structuredAppendParity;
            this.errorsCorrected = 0; /*Integer*/
            this.erasures = 0; /*Integer*/
            // this.byteSegments = byteSegments || [];
            this.numBits = rawBytes === undefined || rawBytes === null ? 0 : 8 * rawBytes.length;
        }
        /**
         * @return raw bytes representing the result, or {@code null} if not applicable
         */
        getRawBytes() {
            return this.rawBytes;
        }
        /**
         * @return how many bits of {@link #getRawBytes()} are valid; typically 8 times its length
         * @since 3.3.0
         */
        getNumBits() {
            return this.numBits;
        }
        /**
         * @param numBits overrides the number of bits that are valid in {@link #getRawBytes()}
         * @since 3.3.0
         */
        setNumBits(numBits /*int*/) {
            this.numBits = numBits;
        }
        /**
         * @return text representation of the result
         */
        getText() {
            return this.text;
        }
        /**
         * @return list of byte segments in the result, or {@code null} if not applicable
         */
        getByteSegments() {
            return this.byteSegments;
        }
        /**
         * @return name of error correction level used, or {@code null} if not applicable
         */
        getECLevel() {
            return this.ecLevel;
        }
        /**
         * @return number of errors corrected, or {@code null} if not applicable
         */
        getErrorsCorrected() {
            return this.errorsCorrected;
        }
        setErrorsCorrected(errorsCorrected /*Integer*/) {
            this.errorsCorrected = errorsCorrected;
        }
        /**
         * @return number of erasures corrected, or {@code null} if not applicable
         */
        getErasures() {
            return this.erasures;
        }
        setErasures(erasures /*Integer*/) {
            this.erasures = erasures;
        }
        /**
         * @return arbitrary additional metadata
         */
        getOther() {
            return this.other;
        }
        setOther(other) {
            this.other = other;
        }
        hasStructuredAppend() {
            return this.structuredAppendParity >= 0 && this.structuredAppendSequenceNumber >= 0;
        }
        getStructuredAppendParity() {
            return this.structuredAppendParity;
        }
        getStructuredAppendSequenceNumber() {
            return this.structuredAppendSequenceNumber;
        }
    }

    /*
     * Copyright 2007 ZXing authors
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *      http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */
    /**
     * Implementations of this class can, given locations of finder patterns for a QR code in an
     * image, sample the right points in the image to reconstruct the QR code, accounting for
     * perspective distortion. It is abstracted since it is relatively expensive and should be allowed
     * to take advantage of platform-specific optimized implementations, like Sun's Java Advanced
     * Imaging library, but which may not be available in other environments such as J2ME, and vice
     * versa.
     *
     * The implementation used can be controlled by calling {@link #setGridSampler(GridSampler)}
     * with an instance of a class which implements this interface.
     *
     * @author Sean Owen
     */
    class GridSampler {
        /**
         * <p>Checks a set of points that have been transformed to sample points on an image against
         * the image's dimensions to see if the point are even within the image.</p>
         *
         * <p>This method will actually "nudge" the endpoints back onto the image if they are found to be
         * barely (less than 1 pixel) off the image. This accounts for imperfect detection of finder
         * patterns in an image where the QR Code runs all the way to the image border.</p>
         *
         * <p>For efficiency, the method will check points from either end of the line until one is found
         * to be within the image. Because the set of points are assumed to be linear, this is valid.</p>
         *
         * @param image image into which the points should map
         * @param points actual points in x1,y1,...,xn,yn form
         * @throws NotFoundException if an endpoint is lies outside the image boundaries
         */
        static checkAndNudgePoints(image, points) {
            const width = image.getWidth();
            const height = image.getHeight();
            // Check and nudge points from start until we see some that are OK:
            let nudged = true;
            for (let offset = 0; offset < points.length && nudged; offset += 2) {
                const x = Math.floor(points[offset]);
                const y = Math.floor(points[offset + 1]);
                if (x < -1 || x > width || y < -1 || y > height) {
                    throw new NotFoundException();
                }
                nudged = false;
                if (x === -1) {
                    points[offset] = 0.0;
                    nudged = true;
                }
                else if (x === width) {
                    points[offset] = width - 1;
                    nudged = true;
                }
                if (y === -1) {
                    points[offset + 1] = 0.0;
                    nudged = true;
                }
                else if (y === height) {
                    points[offset + 1] = height - 1;
                    nudged = true;
                }
            }
            // Check and nudge points from end:
            nudged = true;
            for (let offset = points.length - 2; offset >= 0 && nudged; offset -= 2) {
                const x = Math.floor(points[offset]);
                const y = Math.floor(points[offset + 1]);
                if (x < -1 || x > width || y < -1 || y > height) {
                    throw new NotFoundException();
                }
                nudged = false;
                if (x === -1) {
                    points[offset] = 0.0;
                    nudged = true;
                }
                else if (x === width) {
                    points[offset] = width - 1;
                    nudged = true;
                }
                if (y === -1) {
                    points[offset + 1] = 0.0;
                    nudged = true;
                }
                else if (y === height) {
                    points[offset + 1] = height - 1;
                    nudged = true;
                }
            }
        }
    }

    /*
     * Copyright 2007 ZXing authors
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *      http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */
    /*namespace com.google.zxing.common {*/
    /**
     * <p>This class implements a perspective transform in two dimensions. Given four source and four
     * destination points, it will compute the transformation implied between them. The code is based
     * directly upon section 3.4.2 of George Wolberg's "Digital Image Warping"; see pages 54-56.</p>
     *
     * @author Sean Owen
     */
    class PerspectiveTransform {
        constructor(a11 /*float*/, a21 /*float*/, a31 /*float*/, a12 /*float*/, a22 /*float*/, a32 /*float*/, a13 /*float*/, a23 /*float*/, a33 /*float*/) {
            this.a11 = a11;
            this.a21 = a21;
            this.a31 = a31;
            this.a12 = a12;
            this.a22 = a22;
            this.a32 = a32;
            this.a13 = a13;
            this.a23 = a23;
            this.a33 = a33;
        }
        static quadrilateralToQuadrilateral(x0 /*float*/, y0 /*float*/, x1 /*float*/, y1 /*float*/, x2 /*float*/, y2 /*float*/, x3 /*float*/, y3 /*float*/, x0p /*float*/, y0p /*float*/, x1p /*float*/, y1p /*float*/, x2p /*float*/, y2p /*float*/, x3p /*float*/, y3p /*float*/) {
            const qToS = PerspectiveTransform.quadrilateralToSquare(x0, y0, x1, y1, x2, y2, x3, y3);
            const sToQ = PerspectiveTransform.squareToQuadrilateral(x0p, y0p, x1p, y1p, x2p, y2p, x3p, y3p);
            return sToQ.times(qToS);
        }
        transformPoints(points) {
            const max = points.length;
            const a11 = this.a11;
            const a12 = this.a12;
            const a13 = this.a13;
            const a21 = this.a21;
            const a22 = this.a22;
            const a23 = this.a23;
            const a31 = this.a31;
            const a32 = this.a32;
            const a33 = this.a33;
            for (let i = 0; i < max; i += 2) {
                const x = points[i];
                const y = points[i + 1];
                const denominator = a13 * x + a23 * y + a33;
                points[i] = (a11 * x + a21 * y + a31) / denominator;
                points[i + 1] = (a12 * x + a22 * y + a32) / denominator;
            }
        }
        transformPointsWithValues(xValues, yValues) {
            const a11 = this.a11;
            const a12 = this.a12;
            const a13 = this.a13;
            const a21 = this.a21;
            const a22 = this.a22;
            const a23 = this.a23;
            const a31 = this.a31;
            const a32 = this.a32;
            const a33 = this.a33;
            const n = xValues.length;
            for (let i = 0; i < n; i++) {
                const x = xValues[i];
                const y = yValues[i];
                const denominator = a13 * x + a23 * y + a33;
                xValues[i] = (a11 * x + a21 * y + a31) / denominator;
                yValues[i] = (a12 * x + a22 * y + a32) / denominator;
            }
        }
        static squareToQuadrilateral(x0 /*float*/, y0 /*float*/, x1 /*float*/, y1 /*float*/, x2 /*float*/, y2 /*float*/, x3 /*float*/, y3 /*float*/) {
            const dx3 = x0 - x1 + x2 - x3;
            const dy3 = y0 - y1 + y2 - y3;
            if (dx3 === 0.0 && dy3 === 0.0) {
                // Affine
                return new PerspectiveTransform(x1 - x0, x2 - x1, x0, y1 - y0, y2 - y1, y0, 0.0, 0.0, 1.0);
            }
            else {
                const dx1 = x1 - x2;
                const dx2 = x3 - x2;
                const dy1 = y1 - y2;
                const dy2 = y3 - y2;
                const denominator = dx1 * dy2 - dx2 * dy1;
                const a13 = (dx3 * dy2 - dx2 * dy3) / denominator;
                const a23 = (dx1 * dy3 - dx3 * dy1) / denominator;
                return new PerspectiveTransform(x1 - x0 + a13 * x1, x3 - x0 + a23 * x3, x0, y1 - y0 + a13 * y1, y3 - y0 + a23 * y3, y0, a13, a23, 1.0);
            }
        }
        static quadrilateralToSquare(x0 /*float*/, y0 /*float*/, x1 /*float*/, y1 /*float*/, x2 /*float*/, y2 /*float*/, x3 /*float*/, y3 /*float*/) {
            // Here, the adjoint serves as the inverse:
            return PerspectiveTransform.squareToQuadrilateral(x0, y0, x1, y1, x2, y2, x3, y3).buildAdjoint();
        }
        buildAdjoint() {
            // Adjoint is the transpose of the cofactor matrix:
            return new PerspectiveTransform(this.a22 * this.a33 - this.a23 * this.a32, this.a23 * this.a31 - this.a21 * this.a33, this.a21 * this.a32 - this.a22 * this.a31, this.a13 * this.a32 - this.a12 * this.a33, this.a11 * this.a33 - this.a13 * this.a31, this.a12 * this.a31 - this.a11 * this.a32, this.a12 * this.a23 - this.a13 * this.a22, this.a13 * this.a21 - this.a11 * this.a23, this.a11 * this.a22 - this.a12 * this.a21);
        }
        times(other) {
            return new PerspectiveTransform(this.a11 * other.a11 + this.a21 * other.a12 + this.a31 * other.a13, this.a11 * other.a21 + this.a21 * other.a22 + this.a31 * other.a23, this.a11 * other.a31 + this.a21 * other.a32 + this.a31 * other.a33, this.a12 * other.a11 + this.a22 * other.a12 + this.a32 * other.a13, this.a12 * other.a21 + this.a22 * other.a22 + this.a32 * other.a23, this.a12 * other.a31 + this.a22 * other.a32 + this.a32 * other.a33, this.a13 * other.a11 + this.a23 * other.a12 + this.a33 * other.a13, this.a13 * other.a21 + this.a23 * other.a22 + this.a33 * other.a23, this.a13 * other.a31 + this.a23 * other.a32 + this.a33 * other.a33);
        }
    }

    /*
     * Copyright 2007 ZXing authors
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *      http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */
    /**
     * @author Sean Owen
     */
    class DefaultGridSampler extends GridSampler {
        /*@Override*/
        sampleGrid(image, dimensionX /*int*/, dimensionY /*int*/, p1ToX /*float*/, p1ToY /*float*/, p2ToX /*float*/, p2ToY /*float*/, p3ToX /*float*/, p3ToY /*float*/, p4ToX /*float*/, p4ToY /*float*/, p1FromX /*float*/, p1FromY /*float*/, p2FromX /*float*/, p2FromY /*float*/, p3FromX /*float*/, p3FromY /*float*/, p4FromX /*float*/, p4FromY /*float*/) {
            const transform = PerspectiveTransform.quadrilateralToQuadrilateral(p1ToX, p1ToY, p2ToX, p2ToY, p3ToX, p3ToY, p4ToX, p4ToY, p1FromX, p1FromY, p2FromX, p2FromY, p3FromX, p3FromY, p4FromX, p4FromY);
            return this.sampleGridWithTransform(image, dimensionX, dimensionY, transform);
        }
        /*@Override*/
        sampleGridWithTransform(image, dimensionX /*int*/, dimensionY /*int*/, transform) {
            if (dimensionX <= 0 || dimensionY <= 0) {
                throw new NotFoundException();
            }
            const bits = new BitMatrix(dimensionX, dimensionY);
            const points = new Float32Array(2 * dimensionX);
            for (let y = 0; y < dimensionY; y++) {
                const max = points.length;
                const iValue = y + 0.5;
                for (let x = 0; x < max; x += 2) {
                    points[x] = /*(float)*/ x / 2 + 0.5;
                    points[x + 1] = iValue;
                }
                transform.transformPoints(points);
                // Quick check to see if points transformed to something inside the image
                // sufficient to check the endpoints
                GridSampler.checkAndNudgePoints(image, points);
                try {
                    for (let x = 0; x < max; x += 2) {
                        if (image.get(Math.floor(points[x]), Math.floor(points[x + 1]))) {
                            // Black(-ish) pixel
                            bits.set(x / 2, y);
                        }
                    }
                }
                catch (aioobe /*: ArrayIndexOutOfBoundsException*/) {
                    // This feels wrong, but, sometimes if the finder patterns are misidentified, the resulting
                    // transform gets "twisted" such that it maps a straight line of points to a set of points
                    // whose endpoints are in bounds, but others are not. There is probably some mathematical
                    // way to detect this about the transformation that I don't know yet.
                    // This results in an ugly runtime exception despite our clever checks above -- can't have
                    // that. We could check each point's coordinates but that feels duplicative. We settle for
                    // catching and wrapping ArrayIndexOutOfBoundsException.
                    throw new NotFoundException();
                }
            }
            return bits;
        }
    }

    /*
     * Copyright 2012 ZXing authors
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *      http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */
    /*namespace com.google.zxing.common.detector {*/
    /**
     * General math-related and numeric utility functions.
     */
    class MathUtils {
        MathUtils() { }
        /**
         * Ends up being a bit faster than {@link Math#round(float)}. This merely rounds its
         * argument to the nearest int, where x.5 rounds up to x+1. Semantics of this shortcut
         * differ slightly from {@link Math#round(float)} in that half rounds down for negative
         * values. -2.5 rounds to -3, not -2. For purposes here it makes no difference.
         *
         * @param d real value to round
         * @return nearest {@code int}
         */
        static round(d /*float*/) {
            if (NaN === d)
                return 0;
            if (d <= Number.MIN_SAFE_INTEGER)
                return Number.MIN_SAFE_INTEGER;
            if (d >= Number.MAX_SAFE_INTEGER)
                return Number.MAX_SAFE_INTEGER;
            return /*(int) */ (d + (d < 0.0 ? -0.5 : 0.5)) | 0;
        }
        // TYPESCRIPTPORT: maybe remove round method and call directly Math.round, it looks like it doesn't make sense for js
        /**
         * @param aX point A x coordinate
         * @param aY point A y coordinate
         * @param bX point B x coordinate
         * @param bY point B y coordinate
         * @return Euclidean distance between points A and B
         */
        static distance(aX /*float|int*/, aY /*float|int*/, bX /*float|int*/, bY /*float|int*/) {
            const xDiff = aX - bX;
            const yDiff = aY - bY;
            return /*(float) */ Math.sqrt(xDiff * xDiff + yDiff * yDiff);
        }
        /**
         * @param aX point A x coordinate
         * @param aY point A y coordinate
         * @param bX point B x coordinate
         * @param bY point B y coordinate
         * @return Euclidean distance between points A and B
         */
        // public static distance(aX: number /*int*/, aY: number /*int*/, bX: number /*int*/, bY: number /*int*/): float {
        //   const xDiff = aX - bX
        //   const yDiff = aY - bY
        //   return (float) Math.sqrt(xDiff * xDiff + yDiff * yDiff);
        // }
        /**
         * @param array values to sum
         * @return sum of values in array
         */
        static sum(array) {
            let count = 0;
            for (let i = 0, length = array.length; i !== length; i++) {
                const a = array[i];
                count += a;
            }
            return count;
        }
    }

    class Float {
        static floatToIntBits(f) {
            return f;
        }
    }

    /*
     * Copyright 2007 ZXing authors
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *      http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */
    /**
     * <p>Encapsulates a point of interest in an image containing a barcode. Typically, this
     * would be the location of a finder pattern or the corner of the barcode, for example.</p>
     *
     * @author Sean Owen
     */
    class ResultPoint {
        constructor(x /*float*/, y /*float*/) {
            this.x = x;
            this.y = y;
        }
        getX() {
            return this.x;
        }
        getY() {
            return this.y;
        }
        /*@Override*/
        equals(other) {
            if (other instanceof ResultPoint) {
                const otherPoint = other;
                return this.x === otherPoint.x && this.y === otherPoint.y;
            }
            return false;
        }
        /*@Override*/
        hashCode() {
            return 31 * Float.floatToIntBits(this.x) + Float.floatToIntBits(this.y);
        }
        /*@Override*/
        toString() {
            return "(" + this.x + "," + this.y + ")";
        }
        /**
         * Orders an array of three ResultPoints in an order [A,B,C] such that AB is less than AC
         * and BC is less than AC, and the angle between BC and BA is less than 180 degrees.
         *
         * @param patterns array of three {@code ResultPoint} to order
         */
        static orderBestPatterns(patterns) {
            // Find distances between pattern centers
            const zeroOneDistance = this.distance(patterns[0], patterns[1]);
            const oneTwoDistance = this.distance(patterns[1], patterns[2]);
            const zeroTwoDistance = this.distance(patterns[0], patterns[2]);
            let pointA;
            let pointB;
            let pointC;
            // Assume one closest to other two is B; A and C will just be guesses at first
            if (oneTwoDistance >= zeroOneDistance && oneTwoDistance >= zeroTwoDistance) {
                pointB = patterns[0];
                pointA = patterns[1];
                pointC = patterns[2];
            }
            else if (zeroTwoDistance >= oneTwoDistance && zeroTwoDistance >= zeroOneDistance) {
                pointB = patterns[1];
                pointA = patterns[0];
                pointC = patterns[2];
            }
            else {
                pointB = patterns[2];
                pointA = patterns[0];
                pointC = patterns[1];
            }
            // Use cross product to figure out whether A and C are correct or flipped.
            // This asks whether BC x BA has a positive z component, which is the arrangement
            // we want for A, B, C. If it's negative, then we've got it flipped around and
            // should swap A and C.
            if (this.crossProductZ(pointA, pointB, pointC) < 0.0) {
                const temp = pointA;
                pointA = pointC;
                pointC = temp;
            }
            patterns[0] = pointA;
            patterns[1] = pointB;
            patterns[2] = pointC;
        }
        /**
         * @param pattern1 first pattern
         * @param pattern2 second pattern
         * @return distance between two points
         */
        static distance(pattern1, pattern2) {
            return MathUtils.distance(pattern1.x, pattern1.y, pattern2.x, pattern2.y);
        }
        /**
         * Returns the z component of the cross product between vectors BC and BA.
         */
        static crossProductZ(pointA, pointB, pointC) {
            const bX = pointB.x;
            const bY = pointB.y;
            return (pointC.x - bX) * (pointA.y - bY) - (pointC.y - bY) * (pointA.x - bX);
        }
    }

    /*
     * Copyright 2007 ZXing authors
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *      http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */
    /**
     * <p>Encapsulates the result of detecting a barcode in an image. This includes the raw
     * matrix of black/white pixels corresponding to the barcode, and possibly points of interest
     * in the image, like the location of finder patterns or corners of the barcode in the image.</p>
     *
     * @author Sean Owen
     */
    class DetectorResult {
        constructor(bits, points) {
            this.bits = bits;
            this.points = points;
        }
        getBits() {
            return this.bits;
        }
        getPoints() {
            return this.points;
        }
    }

    /*
     * Copyright 2009 ZXing authors
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *      http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */
    /**
     * This Binarizer implementation uses the old ZXing global histogram approach. It is suitable
     * for low-end mobile devices which don't have enough CPU or memory to use a local thresholding
     * algorithm. However, because it picks a global black point, it cannot handle difficult shadows
     * and gradients.
     *
     * Faster mobile devices and all desktop applications should probably use HybridBinarizer instead.
     *
     * @author dswitkin@google.com (Daniel Switkin)
     * @author Sean Owen
     */
    class GlobalHistogramBinarizer extends Binarizer {
        constructor(source) {
            super(source);
            this.luminances = GlobalHistogramBinarizer.EMPTY;
            this.buckets = new Int32Array(GlobalHistogramBinarizer.LUMINANCE_BUCKETS);
        }
        // Applies simple sharpening to the row data to improve performance of the 1D Readers.
        /*@Override*/
        getBlackRow(y /*int*/, row) {
            const source = this.getLuminanceSource();
            const width = source.getWidth();
            if (row === undefined || row === null || row.getSize() < width) {
                row = new BitArray(width);
            }
            else {
                row.clear();
            }
            this.initArrays(width);
            const localLuminances = source.getRow(y, this.luminances);
            const localBuckets = this.buckets;
            for (let x = 0; x < width; x++) {
                localBuckets[(localLuminances[x] & 0xff) >> GlobalHistogramBinarizer.LUMINANCE_SHIFT]++;
            }
            const blackPoint = GlobalHistogramBinarizer.estimateBlackPoint(localBuckets);
            if (width < 3) {
                // Special case for very small images
                for (let x = 0; x < width; x++) {
                    if ((localLuminances[x] & 0xff) < blackPoint) {
                        row.set(x);
                    }
                }
            }
            else {
                let left = localLuminances[0] & 0xff;
                let center = localLuminances[1] & 0xff;
                for (let x = 1; x < width - 1; x++) {
                    const right = localLuminances[x + 1] & 0xff;
                    // A simple -1 4 -1 box filter with a weight of 2.
                    if ((center * 4 - left - right) / 2 < blackPoint) {
                        row.set(x);
                    }
                    left = center;
                    center = right;
                }
            }
            return row;
        }
        // Does not sharpen the data, as this call is intended to only be used by 2D Readers.
        /*@Override*/
        getBlackMatrix() {
            const source = this.getLuminanceSource();
            const width = source.getWidth();
            const height = source.getHeight();
            const matrix = new BitMatrix(width, height);
            // Quickly calculates the histogram by sampling four rows from the image. This proved to be
            // more robust on the blackbox tests than sampling a diagonal as we used to do.
            this.initArrays(width);
            const localBuckets = this.buckets;
            for (let y = 1; y < 5; y++) {
                const row = (height * y) / 5;
                const localLuminances = source.getRow(row, this.luminances);
                const right = Math.floor((width * 4) / 5);
                for (let x = Math.floor(width / 5); x < right; x++) {
                    const pixel = localLuminances[x] & 0xff;
                    localBuckets[pixel >> GlobalHistogramBinarizer.LUMINANCE_SHIFT]++;
                }
            }
            const blackPoint = GlobalHistogramBinarizer.estimateBlackPoint(localBuckets);
            // We delay reading the entire image luminance until the black point estimation succeeds.
            // Although we end up reading four rows twice, it is consistent with our motto of
            // "fail quickly" which is necessary for continuous scanning.
            const localLuminances = source.getMatrix();
            for (let y = 0; y < height; y++) {
                const offset = y * width;
                for (let x = 0; x < width; x++) {
                    const pixel = localLuminances[offset + x] & 0xff;
                    if (pixel < blackPoint) {
                        matrix.set(x, y);
                    }
                }
            }
            return matrix;
        }
        /*@Override*/
        createBinarizer(source) {
            return new GlobalHistogramBinarizer(source);
        }
        initArrays(luminanceSize /*int*/) {
            if (this.luminances.length < luminanceSize) {
                this.luminances = new Uint8ClampedArray(luminanceSize);
            }
            const buckets = this.buckets;
            for (let x = 0; x < GlobalHistogramBinarizer.LUMINANCE_BUCKETS; x++) {
                buckets[x] = 0;
            }
        }
        static estimateBlackPoint(buckets) {
            // Find the tallest peak in the histogram.
            const numBuckets = buckets.length;
            let maxBucketCount = 0;
            let firstPeak = 0;
            let firstPeakSize = 0;
            for (let x = 0; x < numBuckets; x++) {
                if (buckets[x] > firstPeakSize) {
                    firstPeak = x;
                    firstPeakSize = buckets[x];
                }
                if (buckets[x] > maxBucketCount) {
                    maxBucketCount = buckets[x];
                }
            }
            // Find the second-tallest peak which is somewhat far from the tallest peak.
            let secondPeak = 0;
            let secondPeakScore = 0;
            for (let x = 0; x < numBuckets; x++) {
                const distanceToBiggest = x - firstPeak;
                // Encourage more distant second peaks by multiplying by square of distance.
                const score = buckets[x] * distanceToBiggest * distanceToBiggest;
                if (score > secondPeakScore) {
                    secondPeak = x;
                    secondPeakScore = score;
                }
            }
            // Make sure firstPeak corresponds to the black peak.
            if (firstPeak > secondPeak) {
                const temp = firstPeak;
                firstPeak = secondPeak;
                secondPeak = temp;
            }
            // If there is too little contrast in the image to pick a meaningful black point, throw rather
            // than waste time trying to decode the image, and risk false positives.
            if (secondPeak - firstPeak <= numBuckets / 16) {
                throw new NotFoundException();
            }
            // Find a valley between them that is low and closer to the white peak.
            let bestValley = secondPeak - 1;
            let bestValleyScore = -1;
            for (let x = secondPeak - 1; x > firstPeak; x--) {
                const fromFirst = x - firstPeak;
                const score = fromFirst * fromFirst * (secondPeak - x) * (maxBucketCount - buckets[x]);
                if (score > bestValleyScore) {
                    bestValley = x;
                    bestValleyScore = score;
                }
            }
            return bestValley << GlobalHistogramBinarizer.LUMINANCE_SHIFT;
        }
    }
    GlobalHistogramBinarizer.LUMINANCE_BITS = 5;
    GlobalHistogramBinarizer.LUMINANCE_SHIFT = 8 - GlobalHistogramBinarizer.LUMINANCE_BITS;
    GlobalHistogramBinarizer.LUMINANCE_BUCKETS = 1 << GlobalHistogramBinarizer.LUMINANCE_BITS;
    GlobalHistogramBinarizer.EMPTY = Uint8ClampedArray.from([0]);

    class GridSamplerInstance {
        /**
         * Sets the implementation of GridSampler used by the library. One global
         * instance is stored, which may sound problematic. But, the implementation provided
         * ought to be appropriate for the entire platform, and all uses of this library
         * in the whole lifetime of the JVM. For instance, an Android activity can swap in
         * an implementation that takes advantage of native platform libraries.
         *
         * @param newGridSampler The platform-specific object to install.
         */
        static setGridSampler(newGridSampler) {
            GridSamplerInstance.gridSampler = newGridSampler;
        }
        /**
         * @return the current implementation of GridSampler
         */
        static getInstance() {
            return GridSamplerInstance.gridSampler;
        }
    }
    GridSamplerInstance.gridSampler = new DefaultGridSampler();

    /*
     * Copyright 2009 ZXing authors
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *      http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */
    /**
     * This class implements a local thresholding algorithm, which while slower than the
     * GlobalHistogramBinarizer, is fairly efficient for what it does. It is designed for
     * high frequency images of barcodes with black data on white backgrounds. For this application,
     * it does a much better job than a global blackpoint with severe shadows and gradients.
     * However it tends to produce artifacts on lower frequency images and is therefore not
     * a good general purpose binarizer for uses outside ZXing.
     *
     * This class extends GlobalHistogramBinarizer, using the older histogram approach for 1D readers,
     * and the newer local approach for 2D readers. 1D decoding using a per-row histogram is already
     * inherently local, and only fails for horizontal gradients. We can revisit that problem later,
     * but for now it was not a win to use local blocks for 1D.
     *
     * This Binarizer is the default for the unit tests and the recommended class for library users.
     *
     * @author dswitkin@google.com (Daniel Switkin)
     */
    class HybridBinarizer extends GlobalHistogramBinarizer {
        constructor(source) {
            super(source);
            this.matrix = null;
        }
        /**
         * Calculates the final BitMatrix once for all requests. This could be called once from the
         * constructor instead, but there are some advantages to doing it lazily, such as making
         * profiling easier, and not doing heavy lifting when callers don't expect it.
         */
        /*@Override*/
        getBlackMatrix() {
            if (this.matrix !== null) {
                return this.matrix;
            }
            const source = this.getLuminanceSource();
            const width = source.getWidth();
            const height = source.getHeight();
            if (width >= HybridBinarizer.MINIMUM_DIMENSION && height >= HybridBinarizer.MINIMUM_DIMENSION) {
                const luminances = source.getMatrix();
                let subWidth = width >> HybridBinarizer.BLOCK_SIZE_POWER;
                if ((width & HybridBinarizer.BLOCK_SIZE_MASK) !== 0) {
                    subWidth++;
                }
                let subHeight = height >> HybridBinarizer.BLOCK_SIZE_POWER;
                if ((height & HybridBinarizer.BLOCK_SIZE_MASK) !== 0) {
                    subHeight++;
                }
                const blackPoints = HybridBinarizer.calculateBlackPoints(luminances, subWidth, subHeight, width, height);
                const newMatrix = new BitMatrix(width, height);
                HybridBinarizer.calculateThresholdForBlock(luminances, subWidth, subHeight, width, height, blackPoints, newMatrix);
                this.matrix = newMatrix;
            }
            else {
                // If the image is too small, fall back to the global histogram approach.
                this.matrix = super.getBlackMatrix();
            }
            return this.matrix;
        }
        /*@Override*/
        createBinarizer(source) {
            return new HybridBinarizer(source);
        }
        /**
         * For each block in the image, calculate the average black point using a 5x5 grid
         * of the blocks around it. Also handles the corner cases (fractional blocks are computed based
         * on the last pixels in the row/column which are also used in the previous block).
         */
        static calculateThresholdForBlock(luminances, subWidth /*int*/, subHeight /*int*/, width /*int*/, height /*int*/, blackPoints, matrix) {
            const maxYOffset = height - HybridBinarizer.BLOCK_SIZE;
            const maxXOffset = width - HybridBinarizer.BLOCK_SIZE;
            const averageSize = 3;
            const averageBase = (averageSize + averageSize + 1) ** 2;
            for (let y = 0; y < subHeight; y++) {
                let yoffset = y << HybridBinarizer.BLOCK_SIZE_POWER;
                if (yoffset > maxYOffset) {
                    yoffset = maxYOffset;
                }
                const top = HybridBinarizer.cap(y, averageSize, subHeight - averageSize - 1);
                for (let x = 0; x < subWidth; x++) {
                    let xoffset = x << HybridBinarizer.BLOCK_SIZE_POWER;
                    if (xoffset > maxXOffset) {
                        xoffset = maxXOffset;
                    }
                    const left = HybridBinarizer.cap(x, averageSize, subWidth - averageSize - 1);
                    let sum = 0;
                    for (let z = -averageSize; z <= averageSize; z++) {
                        const blackRow = blackPoints[top + z];
                        for (let j = -averageSize; j <= averageSize; j++) {
                            sum += blackRow[left - j];
                        }
                    }
                    const average = sum / averageBase;
                    HybridBinarizer.thresholdBlock(luminances, xoffset, yoffset, average, width, matrix);
                }
            }
        }
        static cap(value /*int*/, min /*int*/, max /*int*/) {
            return value < min ? min : value > max ? max : value;
        }
        /**
         * Applies a single threshold to a block of pixels.
         */
        static thresholdBlock(luminances, xoffset /*int*/, yoffset /*int*/, threshold /*int*/, stride /*int*/, matrix) {
            for (let y = 0, offset = yoffset * stride + xoffset; y < HybridBinarizer.BLOCK_SIZE; y++, offset += stride) {
                for (let x = 0; x < HybridBinarizer.BLOCK_SIZE; x++) {
                    // Comparison needs to be <= so that black == 0 pixels are black even if the threshold is 0.
                    if ((luminances[offset + x] & 0xff) <= threshold) {
                        matrix.set(xoffset + x, yoffset + y);
                    }
                }
            }
        }
        /**
         * Calculates a single black point for each block of pixels and saves it away.
         * See the following thread for a discussion of this algorithm:
         *  http://groups.google.com/group/zxing/browse_thread/thread/d06efa2c35a7ddc0
         */
        static calculateBlackPoints(luminances, subWidth /*int*/, subHeight /*int*/, width /*int*/, height /*int*/) {
            const maxYOffset = height - HybridBinarizer.BLOCK_SIZE;
            const maxXOffset = width - HybridBinarizer.BLOCK_SIZE;
            // tslint:disable-next-line:whitespace
            const blackPoints = new Array(subHeight); // subWidth
            for (let y = 0; y < subHeight; y++) {
                blackPoints[y] = new Int32Array(subWidth);
                let yoffset = y << HybridBinarizer.BLOCK_SIZE_POWER;
                if (yoffset > maxYOffset) {
                    yoffset = maxYOffset;
                }
                for (let x = 0; x < subWidth; x++) {
                    let xoffset = x << HybridBinarizer.BLOCK_SIZE_POWER;
                    if (xoffset > maxXOffset) {
                        xoffset = maxXOffset;
                    }
                    let sum = 0;
                    let min = 0xff;
                    let max = 0;
                    for (let yy = 0, offset = yoffset * width + xoffset; yy < HybridBinarizer.BLOCK_SIZE; yy++, offset += width) {
                        for (let xx = 0; xx < HybridBinarizer.BLOCK_SIZE; xx++) {
                            const pixel = luminances[offset + xx] & 0xff;
                            sum += pixel;
                            // still looking for good contrast
                            if (pixel < min) {
                                min = pixel;
                            }
                            if (pixel > max) {
                                max = pixel;
                            }
                        }
                        // short-circuit min/max tests once dynamic range is met
                        if (max - min > HybridBinarizer.MIN_DYNAMIC_RANGE) {
                            // finish the rest of the rows quickly
                            for (yy++, offset += width; yy < HybridBinarizer.BLOCK_SIZE; yy++, offset += width) {
                                for (let xx = 0; xx < HybridBinarizer.BLOCK_SIZE; xx++) {
                                    sum += luminances[offset + xx] & 0xff;
                                }
                            }
                        }
                    }
                    // The default estimate is the average of the values in the block.
                    let average = sum >> (HybridBinarizer.BLOCK_SIZE_POWER * 2);
                    if (max - min <= HybridBinarizer.MIN_DYNAMIC_RANGE) {
                        // If variation within the block is low, assume this is a block with only light or only
                        // dark pixels. In that case we do not want to use the average, as it would divide this
                        // low contrast area into black and white pixels, essentially creating data out of noise.
                        //
                        // The default assumption is that the block is light/background. Since no estimate for
                        // the level of dark pixels exists locally, use half the min for the block.
                        average = min / 2;
                        if (y > 0 && x > 0) {
                            // Correct the "white background" assumption for blocks that have neighbors by comparing
                            // the pixels in this block to the previously calculated black points. This is based on
                            // the fact that dark barcode symbology is always surrounded by some amount of light
                            // background for which reasonable black point estimates were made. The bp estimated at
                            // the boundaries is used for the interior.
                            // The (min < bp) is arbitrary but works better than other heuristics that were tried.
                            const averageNeighborBlackPoint = (blackPoints[y - 1][x] + 2 * blackPoints[y][x - 1] + blackPoints[y - 1][x - 1]) / 4;
                            if (min < averageNeighborBlackPoint) {
                                average = averageNeighborBlackPoint;
                            }
                        }
                    }
                    blackPoints[y][x] = average;
                }
            }
            return blackPoints;
        }
    }
    // This class uses 5x5 blocks to compute local luminance, where each block is 8x8 pixels.
    // So this is the smallest dimension in each axis we can accept.
    HybridBinarizer.BLOCK_SIZE_POWER = 3;
    HybridBinarizer.BLOCK_SIZE = 1 << HybridBinarizer.BLOCK_SIZE_POWER; // ...0100...00
    HybridBinarizer.BLOCK_SIZE_MASK = HybridBinarizer.BLOCK_SIZE - 1; // ...0011...11
    HybridBinarizer.MINIMUM_DIMENSION = HybridBinarizer.BLOCK_SIZE * 5;
    HybridBinarizer.MIN_DYNAMIC_RANGE = 24;

    /*
     * Copyright 2007 ZXing authors
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *      http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */
    /**
     * <p>Represents a polynomial whose coefficients are elements of a GF.
     * Instances of this class are immutable.</p>
     *
     * <p>Much credit is due to William Rucklidge since portions of this code are an indirect
     * port of his C++ Reed-Solomon implementation.</p>
     *
     * @author Sean Owen
     */
    class GenericGFPoly {
        /**
         * @param field the {@link GenericGF} instance representing the field to use
         * to perform computations
         * @param coefficients coefficients as ints representing elements of GF(size), arranged
         * from most significant (highest-power term) coefficient to least significant
         * @throws IllegalArgumentException if argument is null or empty,
         * or if leading coefficient is 0 and this is not a
         * constant polynomial (that is, it is not the monomial "0")
         */
        constructor(field, coefficients) {
            if (coefficients.length === 0) {
                throw new IllegalArgumentException();
            }
            this.field = field;
            const coefficientsLength = coefficients.length;
            if (coefficientsLength > 1 && coefficients[0] === 0) {
                // Leading term must be non-zero for anything except the constant polynomial "0"
                let firstNonZero = 1;
                while (firstNonZero < coefficientsLength && coefficients[firstNonZero] === 0) {
                    firstNonZero++;
                }
                if (firstNonZero === coefficientsLength) {
                    this.coefficients = Int32Array.from([0]);
                }
                else {
                    this.coefficients = new Int32Array(coefficientsLength - firstNonZero);
                    System.arraycopy(coefficients, firstNonZero, this.coefficients, 0, this.coefficients.length);
                }
            }
            else {
                this.coefficients = coefficients;
            }
        }
        getCoefficients() {
            return this.coefficients;
        }
        /**
         * @return degree of this polynomial
         */
        getDegree() {
            return this.coefficients.length - 1;
        }
        /**
         * @return true iff this polynomial is the monomial "0"
         */
        isZero() {
            return this.coefficients[0] === 0;
        }
        /**
         * @return coefficient of x^degree term in this polynomial
         */
        getCoefficient(degree /*int*/) {
            return this.coefficients[this.coefficients.length - 1 - degree];
        }
        /**
         * @return evaluation of this polynomial at a given point
         */
        evaluateAt(a /*int*/) {
            if (a === 0) {
                // Just return the x^0 coefficient
                return this.getCoefficient(0);
            }
            const coefficients = this.coefficients;
            let result;
            if (a === 1) {
                // Just the sum of the coefficients
                result = 0;
                for (let i = 0, length = coefficients.length; i !== length; i++) {
                    const coefficient = coefficients[i];
                    result = GenericGF.addOrSubtract(result, coefficient);
                }
                return result;
            }
            result = coefficients[0];
            const size = coefficients.length;
            const field = this.field;
            for (let i = 1; i < size; i++) {
                result = GenericGF.addOrSubtract(field.multiply(a, result), coefficients[i]);
            }
            return result;
        }
        addOrSubtract(other) {
            if (!this.field.equals(other.field)) {
                throw new IllegalArgumentException("GenericGFPolys do not have same GenericGF field");
            }
            if (this.isZero()) {
                return other;
            }
            if (other.isZero()) {
                return this;
            }
            let smallerCoefficients = this.coefficients;
            let largerCoefficients = other.coefficients;
            if (smallerCoefficients.length > largerCoefficients.length) {
                const temp = smallerCoefficients;
                smallerCoefficients = largerCoefficients;
                largerCoefficients = temp;
            }
            let sumDiff = new Int32Array(largerCoefficients.length);
            const lengthDiff = largerCoefficients.length - smallerCoefficients.length;
            // Copy high-order terms only found in higher-degree polynomial's coefficients
            System.arraycopy(largerCoefficients, 0, sumDiff, 0, lengthDiff);
            for (let i = lengthDiff; i < largerCoefficients.length; i++) {
                sumDiff[i] = GenericGF.addOrSubtract(smallerCoefficients[i - lengthDiff], largerCoefficients[i]);
            }
            return new GenericGFPoly(this.field, sumDiff);
        }
        multiply(other) {
            if (!this.field.equals(other.field)) {
                throw new IllegalArgumentException("GenericGFPolys do not have same GenericGF field");
            }
            if (this.isZero() || other.isZero()) {
                return this.field.getZero();
            }
            const aCoefficients = this.coefficients;
            const aLength = aCoefficients.length;
            const bCoefficients = other.coefficients;
            const bLength = bCoefficients.length;
            const product = new Int32Array(aLength + bLength - 1);
            const field = this.field;
            for (let i = 0; i < aLength; i++) {
                const aCoeff = aCoefficients[i];
                for (let j = 0; j < bLength; j++) {
                    product[i + j] = GenericGF.addOrSubtract(product[i + j], field.multiply(aCoeff, bCoefficients[j]));
                }
            }
            return new GenericGFPoly(field, product);
        }
        multiplyScalar(scalar /*int*/) {
            if (scalar === 0) {
                return this.field.getZero();
            }
            if (scalar === 1) {
                return this;
            }
            const size = this.coefficients.length;
            const field = this.field;
            const product = new Int32Array(size);
            const coefficients = this.coefficients;
            for (let i = 0; i < size; i++) {
                product[i] = field.multiply(coefficients[i], scalar);
            }
            return new GenericGFPoly(field, product);
        }
        multiplyByMonomial(degree /*int*/, coefficient /*int*/) {
            if (degree < 0) {
                throw new IllegalArgumentException();
            }
            if (coefficient === 0) {
                return this.field.getZero();
            }
            const coefficients = this.coefficients;
            const size = coefficients.length;
            const product = new Int32Array(size + degree);
            const field = this.field;
            for (let i = 0; i < size; i++) {
                product[i] = field.multiply(coefficients[i], coefficient);
            }
            return new GenericGFPoly(field, product);
        }
        divide(other) {
            if (!this.field.equals(other.field)) {
                throw new IllegalArgumentException("GenericGFPolys do not have same GenericGF field");
            }
            if (other.isZero()) {
                throw new IllegalArgumentException("Divide by 0");
            }
            const field = this.field;
            let quotient = field.getZero();
            let remainder = this;
            const denominatorLeadingTerm = other.getCoefficient(other.getDegree());
            const inverseDenominatorLeadingTerm = field.inverse(denominatorLeadingTerm);
            while (remainder.getDegree() >= other.getDegree() && !remainder.isZero()) {
                const degreeDifference = remainder.getDegree() - other.getDegree();
                const scale = field.multiply(remainder.getCoefficient(remainder.getDegree()), inverseDenominatorLeadingTerm);
                const term = other.multiplyByMonomial(degreeDifference, scale);
                const iterationQuotient = field.buildMonomial(degreeDifference, scale);
                quotient = quotient.addOrSubtract(iterationQuotient);
                remainder = remainder.addOrSubtract(term);
            }
            return [quotient, remainder];
        }
        /*@Override*/
        toString() {
            let result = "";
            for (let degree = this.getDegree(); degree >= 0; degree--) {
                let coefficient = this.getCoefficient(degree);
                if (coefficient !== 0) {
                    if (coefficient < 0) {
                        result += " - ";
                        coefficient = -coefficient;
                    }
                    else {
                        if (result.length > 0) {
                            result += " + ";
                        }
                    }
                    if (degree === 0 || coefficient !== 1) {
                        const alphaPower = this.field.log(coefficient);
                        if (alphaPower === 0) {
                            result += "1";
                        }
                        else if (alphaPower === 1) {
                            result += "a";
                        }
                        else {
                            result += "a^";
                            result += alphaPower;
                        }
                    }
                    if (degree !== 0) {
                        if (degree === 1) {
                            result += "x";
                        }
                        else {
                            result += "x^";
                            result += degree;
                        }
                    }
                }
            }
            return result;
        }
    }

    /*
     * Copyright 2007 ZXing authors
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *      http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */
    /**
     * <p>This class contains utility methods for performing mathematical operations over
     * the Galois Fields. Operations use a given primitive polynomial in calculations.</p>
     *
     * <p>Throughout this package, elements of the GF are represented as an {@code int}
     * for convenience and speed (but at the cost of memory).
     * </p>
     *
     * @author Sean Owen
     * @author David Olivier
     */
    class GenericGF {
        /**
         * Create a representation of GF(size) using the given primitive polynomial.
         *
         * @param primitive irreducible polynomial whose coefficients are represented by
         *  the bits of an int, where the least-significant bit represents the constant
         *  coefficient
         * @param size the size of the field
         * @param b the factor b in the generator polynomial can be 0- or 1-based
         *  (g(x) = (x+a^b)(x+a^(b+1))...(x+a^(b+2t-1))).
         *  In most cases it should be 1, but for QR code it is 0.
         */
        constructor(primitive /*int*/, size /*int*/, generatorBase /*int*/) {
            this.primitive = primitive;
            this.size = size;
            this.generatorBase = generatorBase;
            const expTable = new Int32Array(size);
            let x = 1;
            for (let i = 0; i < size; i++) {
                expTable[i] = x;
                x *= 2; // we're assuming the generator alpha is 2
                if (x >= size) {
                    x ^= primitive;
                    x &= size - 1;
                }
            }
            this.expTable = expTable;
            const logTable = new Int32Array(size);
            for (let i = 0; i < size - 1; i++) {
                logTable[expTable[i]] = i;
            }
            this.logTable = logTable;
            // logTable[0] == 0 but this should never be used
            this.zero = new GenericGFPoly(this, Int32Array.from([0]));
            this.one = new GenericGFPoly(this, Int32Array.from([1]));
        }
        getZero() {
            return this.zero;
        }
        getOne() {
            return this.one;
        }
        /**
         * @return the monomial representing coefficient * x^degree
         */
        buildMonomial(degree /*int*/, coefficient /*int*/) {
            if (degree < 0) {
                throw new IllegalArgumentException();
            }
            if (coefficient === 0) {
                return this.zero;
            }
            const coefficients = new Int32Array(degree + 1);
            coefficients[0] = coefficient;
            return new GenericGFPoly(this, coefficients);
        }
        /**
         * Implements both addition and subtraction -- they are the same in GF(size).
         *
         * @return sum/difference of a and b
         */
        static addOrSubtract(a /*int*/, b /*int*/) {
            return a ^ b;
        }
        /**
         * @return 2 to the power of a in GF(size)
         */
        exp(a /*int*/) {
            return this.expTable[a];
        }
        /**
         * @return base 2 log of a in GF(size)
         */
        log(a /*int*/) {
            if (a === 0) {
                throw new IllegalArgumentException();
            }
            return this.logTable[a];
        }
        /**
         * @return multiplicative inverse of a
         */
        inverse(a /*int*/) {
            if (a === 0) {
                throw new ArithmeticException();
            }
            return this.expTable[this.size - this.logTable[a] - 1];
        }
        /**
         * @return product of a and b in GF(size)
         */
        multiply(a /*int*/, b /*int*/) {
            if (a === 0 || b === 0) {
                return 0;
            }
            return this.expTable[(this.logTable[a] + this.logTable[b]) % (this.size - 1)];
        }
        getSize() {
            return this.size;
        }
        getGeneratorBase() {
            return this.generatorBase;
        }
        /*@Override*/
        toString() {
            return "GF(0x" + Integer.toHexString(this.primitive) + "," + this.size + ")";
        }
        equals(o) {
            return o === this;
        }
    }
    GenericGF.AZTEC_DATA_12 = new GenericGF(0x1069, 4096, 1); // x^12 + x^6 + x^5 + x^3 + 1
    GenericGF.AZTEC_DATA_10 = new GenericGF(0x409, 1024, 1); // x^10 + x^3 + 1
    GenericGF.AZTEC_DATA_6 = new GenericGF(0x43, 64, 1); // x^6 + x + 1
    GenericGF.AZTEC_PARAM = new GenericGF(0x13, 16, 1); // x^4 + x + 1
    GenericGF.QR_CODE_FIELD_256 = new GenericGF(0x011d, 256, 0); // x^8 + x^4 + x^3 + x^2 + 1
    GenericGF.DATA_MATRIX_FIELD_256 = new GenericGF(0x012d, 256, 1); // x^8 + x^5 + x^3 + x^2 + 1
    GenericGF.AZTEC_DATA_8 = GenericGF.DATA_MATRIX_FIELD_256;
    GenericGF.MAXICODE_FIELD_64 = GenericGF.AZTEC_DATA_6;

    /*
     * Copyright 2007 ZXing authors
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *      http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */
    /**
     * <p>Implements Reed-Solomon decoding, as the name implies.</p>
     *
     * <p>The algorithm will not be explained here, but the following references were helpful
     * in creating this implementation:</p>
     *
     * <ul>
     * <li>Bruce Maggs.
     * <a href="http://www.cs.cmu.edu/afs/cs.cmu.edu/project/pscico-guyb/realworld/www/rs_decode.ps">
     * "Decoding Reed-Solomon Codes"</a> (see discussion of Forney's Formula)</li>
     * <li>J.I. Hall. <a href="www.mth.msu.edu/~jhall/classes/codenotes/GRS.pdf">
     * "Chapter 5. Generalized Reed-Solomon Codes"</a>
     * (see discussion of Euclidean algorithm)</li>
     * </ul>
     *
     * <p>Much credit is due to William Rucklidge since portions of this code are an indirect
     * port of his C++ Reed-Solomon implementation.</p>
     *
     * @author Sean Owen
     * @author William Rucklidge
     * @author sanfordsquires
     */
    class ReedSolomonDecoder {
        constructor(field) {
            this.field = field;
        }
        /**
         * <p>Decodes given set of received codewords, which include both data and error-correction
         * codewords. Really, this means it uses Reed-Solomon to detect and correct errors, in-place,
         * in the input.</p>
         *
         * @param received data and error-correction codewords
         * @param twoS number of error-correction codewords available
         * @throws ReedSolomonException if decoding fails for any reason
         */
        decode(received, twoS /*int*/) {
            const field = this.field;
            const poly = new GenericGFPoly(field, received);
            const syndromeCoefficients = new Int32Array(twoS);
            let noError = true;
            for (let i = 0; i < twoS; i++) {
                const evalResult = poly.evaluateAt(field.exp(i + field.getGeneratorBase()));
                syndromeCoefficients[syndromeCoefficients.length - 1 - i] = evalResult;
                if (evalResult !== 0) {
                    noError = false;
                }
            }
            if (noError) {
                return;
            }
            const syndrome = new GenericGFPoly(field, syndromeCoefficients);
            const sigmaOmega = this.runEuclideanAlgorithm(field.buildMonomial(twoS, 1), syndrome, twoS);
            const sigma = sigmaOmega[0];
            const omega = sigmaOmega[1];
            const errorLocations = this.findErrorLocations(sigma);
            const errorMagnitudes = this.findErrorMagnitudes(omega, errorLocations);
            for (let i = 0; i < errorLocations.length; i++) {
                const position = received.length - 1 - field.log(errorLocations[i]);
                if (position < 0) {
                    throw new ReedSolomonException("Bad error location");
                }
                received[position] = GenericGF.addOrSubtract(received[position], errorMagnitudes[i]);
            }
        }
        runEuclideanAlgorithm(a, b, R /*int*/) {
            // Assume a's degree is >= b's
            if (a.getDegree() < b.getDegree()) {
                const temp = a;
                a = b;
                b = temp;
            }
            const field = this.field;
            let rLast = a;
            let r = b;
            let tLast = field.getZero();
            let t = field.getOne();
            // Run Euclidean algorithm until r's degree is less than R/2
            while (r.getDegree() >= ((R / 2) | 0)) {
                let rLastLast = rLast;
                let tLastLast = tLast;
                rLast = r;
                tLast = t;
                // Divide rLastLast by rLast, with quotient in q and remainder in r
                if (rLast.isZero()) {
                    // Oops, Euclidean algorithm already terminated?
                    throw new ReedSolomonException("r_{i-1} was zero");
                }
                r = rLastLast;
                let q = field.getZero();
                const denominatorLeadingTerm = rLast.getCoefficient(rLast.getDegree());
                const dltInverse = field.inverse(denominatorLeadingTerm);
                while (r.getDegree() >= rLast.getDegree() && !r.isZero()) {
                    const degreeDiff = r.getDegree() - rLast.getDegree();
                    const scale = field.multiply(r.getCoefficient(r.getDegree()), dltInverse);
                    q = q.addOrSubtract(field.buildMonomial(degreeDiff, scale));
                    r = r.addOrSubtract(rLast.multiplyByMonomial(degreeDiff, scale));
                }
                t = q.multiply(tLast).addOrSubtract(tLastLast);
                if (r.getDegree() >= rLast.getDegree()) {
                    throw new IllegalStateException("Division algorithm failed to reduce polynomial?");
                }
            }
            const sigmaTildeAtZero = t.getCoefficient(0);
            if (sigmaTildeAtZero === 0) {
                throw new ReedSolomonException("sigmaTilde(0) was zero");
            }
            const inverse = field.inverse(sigmaTildeAtZero);
            const sigma = t.multiplyScalar(inverse);
            const omega = r.multiplyScalar(inverse);
            return [sigma, omega];
        }
        findErrorLocations(errorLocator) {
            // This is a direct application of Chien's search
            const numErrors = errorLocator.getDegree();
            if (numErrors === 1) {
                // shortcut
                return Int32Array.from([errorLocator.getCoefficient(1)]);
            }
            const result = new Int32Array(numErrors);
            let e = 0;
            const field = this.field;
            for (let i = 1; i < field.getSize() && e < numErrors; i++) {
                if (errorLocator.evaluateAt(i) === 0) {
                    result[e] = field.inverse(i);
                    e++;
                }
            }
            if (e !== numErrors) {
                throw new ReedSolomonException("Error locator degree does not match number of roots");
            }
            return result;
        }
        findErrorMagnitudes(errorEvaluator, errorLocations) {
            // This is directly applying Forney's Formula
            const s = errorLocations.length;
            const result = new Int32Array(s);
            const field = this.field;
            for (let i = 0; i < s; i++) {
                const xiInverse = field.inverse(errorLocations[i]);
                let denominator = 1;
                for (let j = 0; j < s; j++) {
                    if (i !== j) {
                        // denominator = field.multiply(denominator,
                        //    GenericGF.addOrSubtract(1, field.multiply(errorLocations[j], xiInverse)))
                        // Above should work but fails on some Apple and Linux JDKs due to a Hotspot bug.
                        // Below is a funny-looking workaround from Steven Parkes
                        const term = field.multiply(errorLocations[j], xiInverse);
                        const termPlus1 = (term & 0x1) === 0 ? term | 1 : term & ~1;
                        denominator = field.multiply(denominator, termPlus1);
                    }
                }
                result[i] = field.multiply(errorEvaluator.evaluateAt(xiInverse), field.inverse(denominator));
                if (field.getGeneratorBase() !== 0) {
                    result[i] = field.multiply(result[i], xiInverse);
                }
            }
            return result;
        }
    }

    /*
     * Copyright (C) 2010 ZXing authors
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *      http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */
    /**
     * Common string-related functions.
     *
     * @author Sean Owen
     * @author Alex Dupre
     */
    class StringUtils {
        // SHIFT_JIS.equalsIgnoreCase(PLATFORM_DEFAULT_ENCODING) ||
        // EUC_JP.equalsIgnoreCase(PLATFORM_DEFAULT_ENCODING);
        StringUtils() { }
        /**
         * @param bytes bytes encoding a string, whose encoding should be guessed
         * @param hints decode hints if applicable
         * @return name of guessed encoding; at the moment will only guess one of:
         *  {@link #SHIFT_JIS}, {@link #UTF8}, {@link #ISO88591}, or the platform
         *  default encoding if none of these can possibly be correct
         */
        static guessEncoding(bytes, hints) {
            if (hints !== null &&
                hints !== undefined &&
                undefined !== hints.get(DecodeHintType.CHARACTER_SET)) {
                return hints.get(DecodeHintType.CHARACTER_SET).toString();
            }
            // For now, merely tries to distinguish ISO-8859-1, UTF-8 and Shift_JIS,
            // which should be by far the most common encodings.
            const length = bytes.length;
            let canBeISO88591 = true;
            let canBeShiftJIS = true;
            let canBeUTF8 = true;
            let utf8BytesLeft = 0;
            // int utf8LowChars = 0
            let utf2BytesChars = 0;
            let utf3BytesChars = 0;
            let utf4BytesChars = 0;
            let sjisBytesLeft = 0;
            // int sjisLowChars = 0
            let sjisKatakanaChars = 0;
            // int sjisDoubleBytesChars = 0
            let sjisCurKatakanaWordLength = 0;
            let sjisCurDoubleBytesWordLength = 0;
            let sjisMaxKatakanaWordLength = 0;
            let sjisMaxDoubleBytesWordLength = 0;
            // int isoLowChars = 0
            // int isoHighChars = 0
            let isoHighOther = 0;
            const utf8bom = bytes.length > 3 &&
                bytes[0] === /*(byte) */ 0xef &&
                bytes[1] === /*(byte) */ 0xbb &&
                bytes[2] === /*(byte) */ 0xbf;
            for (let i = 0; i < length && (canBeISO88591 || canBeShiftJIS || canBeUTF8); i++) {
                const value = bytes[i] & 0xff;
                // UTF-8 stuff
                if (canBeUTF8) {
                    if (utf8BytesLeft > 0) {
                        if ((value & 0x80) === 0) {
                            canBeUTF8 = false;
                        }
                        else {
                            utf8BytesLeft--;
                        }
                    }
                    else if ((value & 0x80) !== 0) {
                        if ((value & 0x40) === 0) {
                            canBeUTF8 = false;
                        }
                        else {
                            utf8BytesLeft++;
                            if ((value & 0x20) === 0) {
                                utf2BytesChars++;
                            }
                            else {
                                utf8BytesLeft++;
                                if ((value & 0x10) === 0) {
                                    utf3BytesChars++;
                                }
                                else {
                                    utf8BytesLeft++;
                                    if ((value & 0x08) === 0) {
                                        utf4BytesChars++;
                                    }
                                    else {
                                        canBeUTF8 = false;
                                    }
                                }
                            }
                        }
                    } // else {
                    // utf8LowChars++
                    // }
                }
                // ISO-8859-1 stuff
                if (canBeISO88591) {
                    if (value > 0x7f && value < 0xa0) {
                        canBeISO88591 = false;
                    }
                    else if (value > 0x9f) {
                        if (value < 0xc0 || value === 0xd7 || value === 0xf7) {
                            isoHighOther++;
                        } // else {
                        // isoHighChars++
                        // }
                    } // else {
                    // isoLowChars++
                    // }
                }
                // Shift_JIS stuff
                if (canBeShiftJIS) {
                    if (sjisBytesLeft > 0) {
                        if (value < 0x40 || value === 0x7f || value > 0xfc) {
                            canBeShiftJIS = false;
                        }
                        else {
                            sjisBytesLeft--;
                        }
                    }
                    else if (value === 0x80 || value === 0xa0 || value > 0xef) {
                        canBeShiftJIS = false;
                    }
                    else if (value > 0xa0 && value < 0xe0) {
                        sjisKatakanaChars++;
                        sjisCurDoubleBytesWordLength = 0;
                        sjisCurKatakanaWordLength++;
                        if (sjisCurKatakanaWordLength > sjisMaxKatakanaWordLength) {
                            sjisMaxKatakanaWordLength = sjisCurKatakanaWordLength;
                        }
                    }
                    else if (value > 0x7f) {
                        sjisBytesLeft++;
                        // sjisDoubleBytesChars++
                        sjisCurKatakanaWordLength = 0;
                        sjisCurDoubleBytesWordLength++;
                        if (sjisCurDoubleBytesWordLength > sjisMaxDoubleBytesWordLength) {
                            sjisMaxDoubleBytesWordLength = sjisCurDoubleBytesWordLength;
                        }
                    }
                    else {
                        // sjisLowChars++
                        sjisCurKatakanaWordLength = 0;
                        sjisCurDoubleBytesWordLength = 0;
                    }
                }
            }
            if (canBeUTF8 && utf8BytesLeft > 0) {
                canBeUTF8 = false;
            }
            if (canBeShiftJIS && sjisBytesLeft > 0) {
                canBeShiftJIS = false;
            }
            // Easy -- if there is BOM or at least 1 valid not-single byte character (and no evidence it can't be UTF-8), done
            if (canBeUTF8 && (utf8bom || utf2BytesChars + utf3BytesChars + utf4BytesChars > 0)) {
                return StringUtils.UTF8;
            }
            // Easy -- if assuming Shift_JIS or at least 3 valid consecutive not-ascii characters (and no evidence it can't be), done
            if (canBeShiftJIS &&
                (StringUtils.ASSUME_SHIFT_JIS ||
                    sjisMaxKatakanaWordLength >= 3 ||
                    sjisMaxDoubleBytesWordLength >= 3)) {
                return StringUtils.SHIFT_JIS;
            }
            // Distinguishing Shift_JIS and ISO-8859-1 can be a little tough for short words. The crude heuristic is:
            // - If we saw
            //   - only two consecutive katakana chars in the whole text, or
            //   - at least 10% of bytes that could be "upper" not-alphanumeric Latin1,
            // - then we conclude Shift_JIS, else ISO-8859-1
            if (canBeISO88591 && canBeShiftJIS) {
                return (sjisMaxKatakanaWordLength === 2 && sjisKatakanaChars === 2) ||
                    isoHighOther * 10 >= length
                    ? StringUtils.SHIFT_JIS
                    : StringUtils.ISO88591;
            }
            // Otherwise, try in order ISO-8859-1, Shift JIS, UTF-8 and fall back to default platform encoding
            if (canBeISO88591) {
                return StringUtils.ISO88591;
            }
            if (canBeShiftJIS) {
                return StringUtils.SHIFT_JIS;
            }
            if (canBeUTF8) {
                return StringUtils.UTF8;
            }
            // Otherwise, we take a wild guess with platform encoding
            return StringUtils.PLATFORM_DEFAULT_ENCODING;
        }
    }
    StringUtils.SHIFT_JIS = CharacterSetECI.SJIS.getName(); // "SJIS"
    StringUtils.GB2312 = "GB2312";
    StringUtils.ISO88591 = CharacterSetECI.ISO8859_1.getName(); // "ISO8859_1"
    StringUtils.EUC_JP = "EUC_JP";
    StringUtils.UTF8 = CharacterSetECI.UTF8.getName(); // "UTF8"
    StringUtils.PLATFORM_DEFAULT_ENCODING = StringUtils.UTF8; // "UTF8"//Charset.defaultCharset().name()
    StringUtils.ASSUME_SHIFT_JIS = false;

    /*
     * Copyright 2009 ZXing authors
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *      http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */
    /*namespace com.google.zxing {*/
    /**
     * The purpose of this class hierarchy is to abstract different bitmap implementations across
     * platforms into a standard interface for requesting greyscale luminance values. The interface
     * only provides immutable methods; therefore crop and rotation create copies. This is to ensure
     * that one Reader does not modify the original luminance source and leave it in an unknown state
     * for other Readers in the chain.
     *
     * @author dswitkin@google.com (Daniel Switkin)
     */
    class LuminanceSource {
        constructor(width /*int*/, height /*int*/) {
            this.width = width;
            this.height = height;
        }
        /**
         * @return The width of the bitmap.
         */
        getWidth() {
            return this.width;
        }
        /**
         * @return The height of the bitmap.
         */
        getHeight() {
            return this.height;
        }
        /**
         * @return Whether this subclass supports cropping.
         */
        isCropSupported() {
            return false;
        }
        /**
         * Returns a new object with cropped image data. Implementations may keep a reference to the
         * original data rather than a copy. Only callable if isCropSupported() is true.
         *
         * @param left The left coordinate, which must be in [0,getWidth())
         * @param top The top coordinate, which must be in [0,getHeight())
         * @param width The width of the rectangle to crop.
         * @param height The height of the rectangle to crop.
         * @return A cropped version of this object.
         */
        crop(left /*int*/, top /*int*/, width /*int*/, height /*int*/) {
            throw new UnsupportedOperationException("This luminance source does not support cropping.");
        }
        /**
         * @return Whether this subclass supports counter-clockwise rotation.
         */
        isRotateSupported() {
            return false;
        }
        /**
         * Returns a new object with rotated image data by 90 degrees counterclockwise.
         * Only callable if {@link #isRotateSupported()} is true.
         *
         * @return A rotated version of this object.
         */
        rotateCounterClockwise() {
            throw new UnsupportedOperationException("This luminance source does not support rotation by 90 degrees.");
        }
        /**
         * Returns a new object with rotated image data by 45 degrees counterclockwise.
         * Only callable if {@link #isRotateSupported()} is true.
         *
         * @return A rotated version of this object.
         */
        rotateCounterClockwise45() {
            throw new UnsupportedOperationException("This luminance source does not support rotation by 45 degrees.");
        }
        /*@Override*/
        toString() {
            const row = new Uint8ClampedArray(this.width);
            let result = new StringBuilder();
            for (let y = 0; y < this.height; y++) {
                const sourceRow = this.getRow(y, row);
                for (let x = 0; x < this.width; x++) {
                    const luminance = sourceRow[x] & 0xff;
                    let c;
                    if (luminance < 0x40) {
                        c = "#";
                    }
                    else if (luminance < 0x80) {
                        c = "+";
                    }
                    else if (luminance < 0xc0) {
                        c = ".";
                    }
                    else {
                        c = " ";
                    }
                    result.append(c);
                }
                result.append("\n");
            }
            return result.toString();
        }
    }

    /*
     * Copyright 2009 ZXing authors
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *      http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */
    /*namespace com.google.zxing {*/
    /**
     * A wrapper implementation of {@link LuminanceSource} which inverts the luminances it returns -- black becomes
     * white and vice versa, and each value becomes (255-value).
     *
     * @author Sean Owen
     */
    class InvertedLuminanceSource extends LuminanceSource {
        constructor(delegate) {
            super(delegate.getWidth(), delegate.getHeight());
            this.delegate = delegate;
        }
        /*@Override*/
        getRow(y /*int*/, row) {
            const sourceRow = this.delegate.getRow(y, row);
            const width = this.getWidth();
            for (let i = 0; i < width; i++) {
                sourceRow[i] = /*(byte)*/ 255 - (sourceRow[i] & 0xff);
            }
            return sourceRow;
        }
        /*@Override*/
        getMatrix() {
            const matrix = this.delegate.getMatrix();
            const length = this.getWidth() * this.getHeight();
            const invertedMatrix = new Uint8ClampedArray(length);
            for (let i = 0; i < length; i++) {
                invertedMatrix[i] = /*(byte)*/ 255 - (matrix[i] & 0xff);
            }
            return invertedMatrix;
        }
        /*@Override*/
        isCropSupported() {
            return this.delegate.isCropSupported();
        }
        /*@Override*/
        crop(left /*int*/, top /*int*/, width /*int*/, height /*int*/) {
            return new InvertedLuminanceSource(this.delegate.crop(left, top, width, height));
        }
        /*@Override*/
        isRotateSupported() {
            return this.delegate.isRotateSupported();
        }
        /**
         * @return original delegate {@link LuminanceSource} since invert undoes itself
         */
        /*@Override*/
        invert() {
            return this.delegate;
        }
        /*@Override*/
        rotateCounterClockwise() {
            return new InvertedLuminanceSource(this.delegate.rotateCounterClockwise());
        }
        /*@Override*/
        rotateCounterClockwise45() {
            return new InvertedLuminanceSource(this.delegate.rotateCounterClockwise45());
        }
    }

    /*
     * Copyright 2007 ZXing authors
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *      http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */
    const EMPTY_UINT8ARRAY = new Uint8Array();
    /**
     * <p>Encapsulates the result of decoding a barcode within an image.</p>
     *
     * @author Sean Owen
     */
    class Result {
        constructor(text, rawBytes, numBits /*int*/, resultPoints, format, timestamp /*long*/) {
            this.text = text;
            this.resultPoints = resultPoints;
            this.format = format;
            this.text = text;
            this.rawBytes = rawBytes || EMPTY_UINT8ARRAY;
            if (undefined === numBits || null === numBits) {
                this.numBits = rawBytes === null || rawBytes === undefined ? 0 : 8 * rawBytes.length;
            }
            else {
                this.numBits = numBits;
            }
            this.resultPoints = resultPoints;
            this.format = format;
            this.resultMetadata = null;
            if (undefined === timestamp || null === timestamp) {
                this.timestamp = System.currentTimeMillis();
            }
            else {
                this.timestamp = timestamp;
            }
        }
        /**
         * @return raw text encoded by the barcode
         */
        getText() {
            return this.text;
        }
        /**
         * @return raw bytes encoded by the barcode, if applicable, otherwise {@code null}
         */
        getRawBytes() {
            return this.rawBytes;
        }
        /**
         * @return how many bits of {@link #getRawBytes()} are valid; typically 8 times its length
         * @since 3.3.0
         */
        getNumBits() {
            return this.numBits;
        }
        /**
         * @return points related to the barcode in the image. These are typically points
         *         identifying finder patterns or the corners of the barcode. The exact meaning is
         *         specific to the type of barcode that was decoded.
         */
        getResultPoints() {
            return this.resultPoints;
        }
        /**
         * @return {@link BarcodeFormat} representing the format of the barcode that was decoded
         */
        getBarcodeFormat() {
            return this.format;
        }
        /**
         * @return {@link Map} mapping {@link ResultMetadataType} keys to values. May be
         *   {@code null}. This contains optional metadata about what was detected about the barcode,
         *   like orientation.
         */
        getResultMetadata() {
            return this.resultMetadata;
        }
        putMetadata(type, value) {
            if (this.resultMetadata === null) {
                this.resultMetadata = new Map();
            }
            this.resultMetadata.set(type, value);
        }
        putAllMetadata(metadata) {
            if (metadata !== null) {
                if (this.resultMetadata === null) {
                    this.resultMetadata = metadata;
                }
                else {
                    this.resultMetadata = new Map(metadata);
                }
            }
        }
        addResultPoints(newPoints) {
            const oldPoints = this.resultPoints;
            if (oldPoints === null) {
                this.resultPoints = newPoints;
            }
            else if (newPoints !== null && newPoints.length > 0) {
                const allPoints = [];
                System.arraycopy(oldPoints, 0, allPoints, 0, oldPoints.length);
                System.arraycopy(newPoints, 0, allPoints, oldPoints.length, newPoints.length);
                this.resultPoints = allPoints;
            }
        }
        getTimestamp() {
            return this.timestamp;
        }
        /*@Override*/
        toString() {
            return this.text;
        }
    }

    /*
     * Copyright 2007 ZXing authors
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *      http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */
    /**
     * <p>See ISO 18004:2006, 6.5.1. This enum encapsulates the four error correction levels
     * defined by the QR code standard.</p>
     *
     * @author Sean Owen
     */
    class ErrorCorrectionLevel {
        constructor(value, stringValue, bits /*int*/) {
            this.value = value;
            this.stringValue = stringValue;
            this.bits = bits;
            ErrorCorrectionLevel.FOR_BITS.set(bits, this);
            ErrorCorrectionLevel.FOR_VALUE.set(value, this);
        }
        getValue() {
            return this.value;
        }
        getBits() {
            return this.bits;
        }
        static fromString(s) {
            switch (s) {
                case "L":
                    return ErrorCorrectionLevel.L;
                case "M":
                    return ErrorCorrectionLevel.M;
                case "Q":
                    return ErrorCorrectionLevel.Q;
                case "H":
                    return ErrorCorrectionLevel.H;
                default:
                    throw new ArgumentException(s + "not available");
            }
        }
        toString() {
            return this.stringValue;
        }
        equals(o) {
            if (!(o instanceof ErrorCorrectionLevel)) {
                return false;
            }
            const other = o;
            return this.value === other.value;
        }
        /**
         * @param bits int containing the two bits encoding a QR Code's error correction level
         * @return ErrorCorrectionLevel representing the encoded error correction level
         */
        static forBits(bits /*int*/) {
            // if (bits < 0 || bits >= ErrorCorrectionLevel.FOR_BITS.size) {
            //     throw new IllegalArgumentException();
            // }
            const level = ErrorCorrectionLevel.FOR_BITS.get(bits);
            if (level === undefined) {
                throw new IllegalArgumentException();
            }
            return level;
        }
    }
    ErrorCorrectionLevel.FOR_BITS = new Map();
    ErrorCorrectionLevel.FOR_VALUE = new Map();
    /** L = ~7% correction */
    ErrorCorrectionLevel.L = new ErrorCorrectionLevel(ErrorCorrectionLevelValues.L, "L", 0x01);
    /** M = ~15% correction */
    ErrorCorrectionLevel.M = new ErrorCorrectionLevel(ErrorCorrectionLevelValues.M, "M", 0x00);
    /** Q = ~25% correction */
    ErrorCorrectionLevel.Q = new ErrorCorrectionLevel(ErrorCorrectionLevelValues.Q, "Q", 0x03);
    /** H = ~30% correction */
    ErrorCorrectionLevel.H = new ErrorCorrectionLevel(ErrorCorrectionLevelValues.H, "H", 0x02);

    /*
     * Copyright 2007 ZXing authors
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *      http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */
    /**
     * <p>Encapsulates a QR Code's format information, including the data mask used and
     * error correction level.</p>
     *
     * @author Sean Owen
     * @see DataMask
     * @see ErrorCorrectionLevel
     */
    class FormatInformation {
        constructor(formatInfo /*int*/) {
            // Bits 3,4
            this.errorCorrectionLevel = ErrorCorrectionLevel.forBits((formatInfo >> 3) & 0x03);
            // Bottom 3 bits
            this.dataMask = /*(byte) */ formatInfo & 0x07;
        }
        static numBitsDiffering(a /*int*/, b /*int*/) {
            return Integer.bitCount(a ^ b);
        }
        /**
         * @param maskedFormatInfo1 format info indicator, with mask still applied
         * @param maskedFormatInfo2 second copy of same info; both are checked at the same time
         *  to establish best match
         * @return information about the format it specifies, or {@code null}
         *  if doesn't seem to match any known pattern
         */
        static decodeFormatInformation(maskedFormatInfo1 /*int*/, maskedFormatInfo2 /*int*/) {
            const formatInfo = FormatInformation.doDecodeFormatInformation(maskedFormatInfo1, maskedFormatInfo2);
            if (formatInfo !== null) {
                return formatInfo;
            }
            // Should return null, but, some QR codes apparently
            // do not mask this info. Try again by actually masking the pattern
            // first
            return FormatInformation.doDecodeFormatInformation(maskedFormatInfo1 ^ FormatInformation.FORMAT_INFO_MASK_QR, maskedFormatInfo2 ^ FormatInformation.FORMAT_INFO_MASK_QR);
        }
        static doDecodeFormatInformation(maskedFormatInfo1 /*int*/, maskedFormatInfo2 /*int*/) {
            // Find the int in FORMAT_INFO_DECODE_LOOKUP with fewest bits differing
            let bestDifference = Number.MAX_SAFE_INTEGER;
            let bestFormatInfo = 0;
            for (const decodeInfo of FormatInformation.FORMAT_INFO_DECODE_LOOKUP) {
                const targetInfo = decodeInfo[0];
                if (targetInfo === maskedFormatInfo1 || targetInfo === maskedFormatInfo2) {
                    // Found an exact match
                    return new FormatInformation(decodeInfo[1]);
                }
                let bitsDifference = FormatInformation.numBitsDiffering(maskedFormatInfo1, targetInfo);
                if (bitsDifference < bestDifference) {
                    bestFormatInfo = decodeInfo[1];
                    bestDifference = bitsDifference;
                }
                if (maskedFormatInfo1 !== maskedFormatInfo2) {
                    // also try the other option
                    bitsDifference = FormatInformation.numBitsDiffering(maskedFormatInfo2, targetInfo);
                    if (bitsDifference < bestDifference) {
                        bestFormatInfo = decodeInfo[1];
                        bestDifference = bitsDifference;
                    }
                }
            }
            // Hamming distance of the 32 masked codes is 7, by construction, so <= 3 bits
            // differing means we found a match
            if (bestDifference <= 3) {
                return new FormatInformation(bestFormatInfo);
            }
            return null;
        }
        getErrorCorrectionLevel() {
            return this.errorCorrectionLevel;
        }
        getDataMask() {
            return this.dataMask;
        }
        /*@Override*/
        hashCode() {
            return (this.errorCorrectionLevel.getBits() << 3) | this.dataMask;
        }
        /*@Override*/
        equals(o) {
            if (!(o instanceof FormatInformation)) {
                return false;
            }
            const other = o;
            return (this.errorCorrectionLevel === other.errorCorrectionLevel && this.dataMask === other.dataMask);
        }
    }
    FormatInformation.FORMAT_INFO_MASK_QR = 0x5412;
    /**
     * See ISO 18004:2006, Annex C, Table C.1
     */
    FormatInformation.FORMAT_INFO_DECODE_LOOKUP = [
        Int32Array.from([0x5412, 0x00]),
        Int32Array.from([0x5125, 0x01]),
        Int32Array.from([0x5e7c, 0x02]),
        Int32Array.from([0x5b4b, 0x03]),
        Int32Array.from([0x45f9, 0x04]),
        Int32Array.from([0x40ce, 0x05]),
        Int32Array.from([0x4f97, 0x06]),
        Int32Array.from([0x4aa0, 0x07]),
        Int32Array.from([0x77c4, 0x08]),
        Int32Array.from([0x72f3, 0x09]),
        Int32Array.from([0x7daa, 0x0a]),
        Int32Array.from([0x789d, 0x0b]),
        Int32Array.from([0x662f, 0x0c]),
        Int32Array.from([0x6318, 0x0d]),
        Int32Array.from([0x6c41, 0x0e]),
        Int32Array.from([0x6976, 0x0f]),
        Int32Array.from([0x1689, 0x10]),
        Int32Array.from([0x13be, 0x11]),
        Int32Array.from([0x1ce7, 0x12]),
        Int32Array.from([0x19d0, 0x13]),
        Int32Array.from([0x0762, 0x14]),
        Int32Array.from([0x0255, 0x15]),
        Int32Array.from([0x0d0c, 0x16]),
        Int32Array.from([0x083b, 0x17]),
        Int32Array.from([0x355f, 0x18]),
        Int32Array.from([0x3068, 0x19]),
        Int32Array.from([0x3f31, 0x1a]),
        Int32Array.from([0x3a06, 0x1b]),
        Int32Array.from([0x24b4, 0x1c]),
        Int32Array.from([0x2183, 0x1d]),
        Int32Array.from([0x2eda, 0x1e]),
        Int32Array.from([0x2bed, 0x1f]),
    ];

    /**
     * <p>Encapsulates a set of error-correction blocks in one symbol version. Most versions will
     * use blocks of differing sizes within one version, so, this encapsulates the parameters for
     * each set of blocks. It also holds the number of error-correction codewords per block since it
     * will be the same across all blocks within one version.</p>
     */
    class ECBlocks$1 {
        constructor(ecCodewordsPerBlock /*int*/, ...ecBlocks) {
            this.ecCodewordsPerBlock = ecCodewordsPerBlock;
            this.ecBlocks = ecBlocks;
        }
        getECCodewordsPerBlock() {
            return this.ecCodewordsPerBlock;
        }
        getNumBlocks() {
            let total = 0;
            const ecBlocks = this.ecBlocks;
            for (const ecBlock of ecBlocks) {
                total += ecBlock.getCount();
            }
            return total;
        }
        getTotalECCodewords() {
            return this.ecCodewordsPerBlock * this.getNumBlocks();
        }
        getECBlocks() {
            return this.ecBlocks;
        }
    }

    /**
     * <p>Encapsulates the parameters for one error-correction block in one symbol version.
     * This includes the number of data codewords, and the number of times a block with these
     * parameters is used consecutively in the QR code version's format.</p>
     */
    class ECB$1 {
        constructor(count /*int*/, dataCodewords /*int*/) {
            this.count = count;
            this.dataCodewords = dataCodewords;
        }
        getCount() {
            return this.count;
        }
        getDataCodewords() {
            return this.dataCodewords;
        }
    }

    /*
     * Copyright 2007 ZXing authors
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *      http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */
    /**
     * See ISO 18004:2006 Annex D
     *
     * @author Sean Owen
     */
    class Version$1 {
        constructor(versionNumber /*int*/, alignmentPatternCenters, ...ecBlocks) {
            this.versionNumber = versionNumber;
            this.alignmentPatternCenters = alignmentPatternCenters;
            this.ecBlocks = ecBlocks;
            let total = 0;
            const ecCodewords = ecBlocks[0].getECCodewordsPerBlock();
            const ecbArray = ecBlocks[0].getECBlocks();
            for (const ecBlock of ecbArray) {
                total += ecBlock.getCount() * (ecBlock.getDataCodewords() + ecCodewords);
            }
            this.totalCodewords = total;
        }
        getVersionNumber() {
            return this.versionNumber;
        }
        getAlignmentPatternCenters() {
            return this.alignmentPatternCenters;
        }
        getTotalCodewords() {
            return this.totalCodewords;
        }
        getDimensionForVersion() {
            return 17 + 4 * this.versionNumber;
        }
        getECBlocksForLevel(ecLevel) {
            return this.ecBlocks[ecLevel.getValue()];
            // TYPESCRIPTPORT: original was using ordinal, and using the order of levels as defined in ErrorCorrectionLevel enum (LMQH)
            // I will use the direct value from ErrorCorrectionLevelValues enum which in typescript goes to a number
        }
        /**
         * <p>Deduces version information purely from QR Code dimensions.</p>
         *
         * @param dimension dimension in modules
         * @return Version for a QR Code of that dimension
         * @throws FormatException if dimension is not 1 mod 4
         */
        static getProvisionalVersionForDimension(dimension /*int*/) {
            if (dimension % 4 !== 1) {
                throw new FormatException();
            }
            try {
                return this.getVersionForNumber((dimension - 17) / 4);
            }
            catch (ignored /*: IllegalArgumentException*/) {
                throw new FormatException();
            }
        }
        static getVersionForNumber(versionNumber /*int*/) {
            if (versionNumber < 1 || versionNumber > 40) {
                throw new IllegalArgumentException();
            }
            return Version$1.VERSIONS[versionNumber - 1];
        }
        static decodeVersionInformation(versionBits /*int*/) {
            let bestDifference = Number.MAX_SAFE_INTEGER;
            let bestVersion = 0;
            for (let i = 0; i < Version$1.VERSION_DECODE_INFO.length; i++) {
                const targetVersion = Version$1.VERSION_DECODE_INFO[i];
                // Do the version info bits match exactly? done.
                if (targetVersion === versionBits) {
                    return Version$1.getVersionForNumber(i + 7);
                }
                // Otherwise see if this is the closest to a real version info bit string
                // we have seen so far
                const bitsDifference = FormatInformation.numBitsDiffering(versionBits, targetVersion);
                if (bitsDifference < bestDifference) {
                    bestVersion = i + 7;
                    bestDifference = bitsDifference;
                }
            }
            // We can tolerate up to 3 bits of error since no two version info codewords will
            // differ in less than 8 bits.
            if (bestDifference <= 3) {
                return Version$1.getVersionForNumber(bestVersion);
            }
            // If we didn't find a close enough match, fail
            return null;
        }
        /**
         * See ISO 18004:2006 Annex E
         */
        buildFunctionPattern() {
            const dimension = this.getDimensionForVersion();
            const bitMatrix = new BitMatrix(dimension);
            // Top left finder pattern + separator + format
            bitMatrix.setRegion(0, 0, 9, 9);
            // Top right finder pattern + separator + format
            bitMatrix.setRegion(dimension - 8, 0, 8, 9);
            // Bottom left finder pattern + separator + format
            bitMatrix.setRegion(0, dimension - 8, 9, 8);
            // Alignment patterns
            const max = this.alignmentPatternCenters.length;
            for (let x = 0; x < max; x++) {
                const i = this.alignmentPatternCenters[x] - 2;
                for (let y = 0; y < max; y++) {
                    if ((x === 0 && (y === 0 || y === max - 1)) || (x === max - 1 && y === 0)) {
                        // No alignment patterns near the three finder patterns
                        continue;
                    }
                    bitMatrix.setRegion(this.alignmentPatternCenters[y] - 2, i, 5, 5);
                }
            }
            // Vertical timing pattern
            bitMatrix.setRegion(6, 9, 1, dimension - 17);
            // Horizontal timing pattern
            bitMatrix.setRegion(9, 6, dimension - 17, 1);
            if (this.versionNumber > 6) {
                // Version info, top right
                bitMatrix.setRegion(dimension - 11, 0, 3, 6);
                // Version info, bottom left
                bitMatrix.setRegion(0, dimension - 11, 6, 3);
            }
            return bitMatrix;
        }
        /*@Override*/
        toString() {
            return "" + this.versionNumber;
        }
    }
    /**
     * See ISO 18004:2006 Annex D.
     * Element i represents the raw version bits that specify version i + 7
     */
    Version$1.VERSION_DECODE_INFO = Int32Array.from([
        0x07c94,
        0x085bc,
        0x09a99,
        0x0a4d3,
        0x0bbf6,
        0x0c762,
        0x0d847,
        0x0e60d,
        0x0f928,
        0x10b78,
        0x1145d,
        0x12a17,
        0x13532,
        0x149a6,
        0x15683,
        0x168c9,
        0x177ec,
        0x18ec4,
        0x191e1,
        0x1afab,
        0x1b08e,
        0x1cc1a,
        0x1d33f,
        0x1ed75,
        0x1f250,
        0x209d5,
        0x216f0,
        0x228ba,
        0x2379f,
        0x24b0b,
        0x2542e,
        0x26a64,
        0x27541,
        0x28c69,
    ]);
    /**
     * See ISO 18004:2006 6.5.1 Table 9
     */
    Version$1.VERSIONS = [
        new Version$1(1, new Int32Array(0), new ECBlocks$1(7, new ECB$1(1, 19)), new ECBlocks$1(10, new ECB$1(1, 16)), new ECBlocks$1(13, new ECB$1(1, 13)), new ECBlocks$1(17, new ECB$1(1, 9))),
        new Version$1(2, Int32Array.from([6, 18]), new ECBlocks$1(10, new ECB$1(1, 34)), new ECBlocks$1(16, new ECB$1(1, 28)), new ECBlocks$1(22, new ECB$1(1, 22)), new ECBlocks$1(28, new ECB$1(1, 16))),
        new Version$1(3, Int32Array.from([6, 22]), new ECBlocks$1(15, new ECB$1(1, 55)), new ECBlocks$1(26, new ECB$1(1, 44)), new ECBlocks$1(18, new ECB$1(2, 17)), new ECBlocks$1(22, new ECB$1(2, 13))),
        new Version$1(4, Int32Array.from([6, 26]), new ECBlocks$1(20, new ECB$1(1, 80)), new ECBlocks$1(18, new ECB$1(2, 32)), new ECBlocks$1(26, new ECB$1(2, 24)), new ECBlocks$1(16, new ECB$1(4, 9))),
        new Version$1(5, Int32Array.from([6, 30]), new ECBlocks$1(26, new ECB$1(1, 108)), new ECBlocks$1(24, new ECB$1(2, 43)), new ECBlocks$1(18, new ECB$1(2, 15), new ECB$1(2, 16)), new ECBlocks$1(22, new ECB$1(2, 11), new ECB$1(2, 12))),
        new Version$1(6, Int32Array.from([6, 34]), new ECBlocks$1(18, new ECB$1(2, 68)), new ECBlocks$1(16, new ECB$1(4, 27)), new ECBlocks$1(24, new ECB$1(4, 19)), new ECBlocks$1(28, new ECB$1(4, 15))),
        new Version$1(7, Int32Array.from([6, 22, 38]), new ECBlocks$1(20, new ECB$1(2, 78)), new ECBlocks$1(18, new ECB$1(4, 31)), new ECBlocks$1(18, new ECB$1(2, 14), new ECB$1(4, 15)), new ECBlocks$1(26, new ECB$1(4, 13), new ECB$1(1, 14))),
        new Version$1(8, Int32Array.from([6, 24, 42]), new ECBlocks$1(24, new ECB$1(2, 97)), new ECBlocks$1(22, new ECB$1(2, 38), new ECB$1(2, 39)), new ECBlocks$1(22, new ECB$1(4, 18), new ECB$1(2, 19)), new ECBlocks$1(26, new ECB$1(4, 14), new ECB$1(2, 15))),
        new Version$1(9, Int32Array.from([6, 26, 46]), new ECBlocks$1(30, new ECB$1(2, 116)), new ECBlocks$1(22, new ECB$1(3, 36), new ECB$1(2, 37)), new ECBlocks$1(20, new ECB$1(4, 16), new ECB$1(4, 17)), new ECBlocks$1(24, new ECB$1(4, 12), new ECB$1(4, 13))),
        new Version$1(10, Int32Array.from([6, 28, 50]), new ECBlocks$1(18, new ECB$1(2, 68), new ECB$1(2, 69)), new ECBlocks$1(26, new ECB$1(4, 43), new ECB$1(1, 44)), new ECBlocks$1(24, new ECB$1(6, 19), new ECB$1(2, 20)), new ECBlocks$1(28, new ECB$1(6, 15), new ECB$1(2, 16))),
        new Version$1(11, Int32Array.from([6, 30, 54]), new ECBlocks$1(20, new ECB$1(4, 81)), new ECBlocks$1(30, new ECB$1(1, 50), new ECB$1(4, 51)), new ECBlocks$1(28, new ECB$1(4, 22), new ECB$1(4, 23)), new ECBlocks$1(24, new ECB$1(3, 12), new ECB$1(8, 13))),
        new Version$1(12, Int32Array.from([6, 32, 58]), new ECBlocks$1(24, new ECB$1(2, 92), new ECB$1(2, 93)), new ECBlocks$1(22, new ECB$1(6, 36), new ECB$1(2, 37)), new ECBlocks$1(26, new ECB$1(4, 20), new ECB$1(6, 21)), new ECBlocks$1(28, new ECB$1(7, 14), new ECB$1(4, 15))),
        new Version$1(13, Int32Array.from([6, 34, 62]), new ECBlocks$1(26, new ECB$1(4, 107)), new ECBlocks$1(22, new ECB$1(8, 37), new ECB$1(1, 38)), new ECBlocks$1(24, new ECB$1(8, 20), new ECB$1(4, 21)), new ECBlocks$1(22, new ECB$1(12, 11), new ECB$1(4, 12))),
        new Version$1(14, Int32Array.from([6, 26, 46, 66]), new ECBlocks$1(30, new ECB$1(3, 115), new ECB$1(1, 116)), new ECBlocks$1(24, new ECB$1(4, 40), new ECB$1(5, 41)), new ECBlocks$1(20, new ECB$1(11, 16), new ECB$1(5, 17)), new ECBlocks$1(24, new ECB$1(11, 12), new ECB$1(5, 13))),
        new Version$1(15, Int32Array.from([6, 26, 48, 70]), new ECBlocks$1(22, new ECB$1(5, 87), new ECB$1(1, 88)), new ECBlocks$1(24, new ECB$1(5, 41), new ECB$1(5, 42)), new ECBlocks$1(30, new ECB$1(5, 24), new ECB$1(7, 25)), new ECBlocks$1(24, new ECB$1(11, 12), new ECB$1(7, 13))),
        new Version$1(16, Int32Array.from([6, 26, 50, 74]), new ECBlocks$1(24, new ECB$1(5, 98), new ECB$1(1, 99)), new ECBlocks$1(28, new ECB$1(7, 45), new ECB$1(3, 46)), new ECBlocks$1(24, new ECB$1(15, 19), new ECB$1(2, 20)), new ECBlocks$1(30, new ECB$1(3, 15), new ECB$1(13, 16))),
        new Version$1(17, Int32Array.from([6, 30, 54, 78]), new ECBlocks$1(28, new ECB$1(1, 107), new ECB$1(5, 108)), new ECBlocks$1(28, new ECB$1(10, 46), new ECB$1(1, 47)), new ECBlocks$1(28, new ECB$1(1, 22), new ECB$1(15, 23)), new ECBlocks$1(28, new ECB$1(2, 14), new ECB$1(17, 15))),
        new Version$1(18, Int32Array.from([6, 30, 56, 82]), new ECBlocks$1(30, new ECB$1(5, 120), new ECB$1(1, 121)), new ECBlocks$1(26, new ECB$1(9, 43), new ECB$1(4, 44)), new ECBlocks$1(28, new ECB$1(17, 22), new ECB$1(1, 23)), new ECBlocks$1(28, new ECB$1(2, 14), new ECB$1(19, 15))),
        new Version$1(19, Int32Array.from([6, 30, 58, 86]), new ECBlocks$1(28, new ECB$1(3, 113), new ECB$1(4, 114)), new ECBlocks$1(26, new ECB$1(3, 44), new ECB$1(11, 45)), new ECBlocks$1(26, new ECB$1(17, 21), new ECB$1(4, 22)), new ECBlocks$1(26, new ECB$1(9, 13), new ECB$1(16, 14))),
        new Version$1(20, Int32Array.from([6, 34, 62, 90]), new ECBlocks$1(28, new ECB$1(3, 107), new ECB$1(5, 108)), new ECBlocks$1(26, new ECB$1(3, 41), new ECB$1(13, 42)), new ECBlocks$1(30, new ECB$1(15, 24), new ECB$1(5, 25)), new ECBlocks$1(28, new ECB$1(15, 15), new ECB$1(10, 16))),
        new Version$1(21, Int32Array.from([6, 28, 50, 72, 94]), new ECBlocks$1(28, new ECB$1(4, 116), new ECB$1(4, 117)), new ECBlocks$1(26, new ECB$1(17, 42)), new ECBlocks$1(28, new ECB$1(17, 22), new ECB$1(6, 23)), new ECBlocks$1(30, new ECB$1(19, 16), new ECB$1(6, 17))),
        new Version$1(22, Int32Array.from([6, 26, 50, 74, 98]), new ECBlocks$1(28, new ECB$1(2, 111), new ECB$1(7, 112)), new ECBlocks$1(28, new ECB$1(17, 46)), new ECBlocks$1(30, new ECB$1(7, 24), new ECB$1(16, 25)), new ECBlocks$1(24, new ECB$1(34, 13))),
        new Version$1(23, Int32Array.from([6, 30, 54, 78, 102]), new ECBlocks$1(30, new ECB$1(4, 121), new ECB$1(5, 122)), new ECBlocks$1(28, new ECB$1(4, 47), new ECB$1(14, 48)), new ECBlocks$1(30, new ECB$1(11, 24), new ECB$1(14, 25)), new ECBlocks$1(30, new ECB$1(16, 15), new ECB$1(14, 16))),
        new Version$1(24, Int32Array.from([6, 28, 54, 80, 106]), new ECBlocks$1(30, new ECB$1(6, 117), new ECB$1(4, 118)), new ECBlocks$1(28, new ECB$1(6, 45), new ECB$1(14, 46)), new ECBlocks$1(30, new ECB$1(11, 24), new ECB$1(16, 25)), new ECBlocks$1(30, new ECB$1(30, 16), new ECB$1(2, 17))),
        new Version$1(25, Int32Array.from([6, 32, 58, 84, 110]), new ECBlocks$1(26, new ECB$1(8, 106), new ECB$1(4, 107)), new ECBlocks$1(28, new ECB$1(8, 47), new ECB$1(13, 48)), new ECBlocks$1(30, new ECB$1(7, 24), new ECB$1(22, 25)), new ECBlocks$1(30, new ECB$1(22, 15), new ECB$1(13, 16))),
        new Version$1(26, Int32Array.from([6, 30, 58, 86, 114]), new ECBlocks$1(28, new ECB$1(10, 114), new ECB$1(2, 115)), new ECBlocks$1(28, new ECB$1(19, 46), new ECB$1(4, 47)), new ECBlocks$1(28, new ECB$1(28, 22), new ECB$1(6, 23)), new ECBlocks$1(30, new ECB$1(33, 16), new ECB$1(4, 17))),
        new Version$1(27, Int32Array.from([6, 34, 62, 90, 118]), new ECBlocks$1(30, new ECB$1(8, 122), new ECB$1(4, 123)), new ECBlocks$1(28, new ECB$1(22, 45), new ECB$1(3, 46)), new ECBlocks$1(30, new ECB$1(8, 23), new ECB$1(26, 24)), new ECBlocks$1(30, new ECB$1(12, 15), new ECB$1(28, 16))),
        new Version$1(28, Int32Array.from([6, 26, 50, 74, 98, 122]), new ECBlocks$1(30, new ECB$1(3, 117), new ECB$1(10, 118)), new ECBlocks$1(28, new ECB$1(3, 45), new ECB$1(23, 46)), new ECBlocks$1(30, new ECB$1(4, 24), new ECB$1(31, 25)), new ECBlocks$1(30, new ECB$1(11, 15), new ECB$1(31, 16))),
        new Version$1(29, Int32Array.from([6, 30, 54, 78, 102, 126]), new ECBlocks$1(30, new ECB$1(7, 116), new ECB$1(7, 117)), new ECBlocks$1(28, new ECB$1(21, 45), new ECB$1(7, 46)), new ECBlocks$1(30, new ECB$1(1, 23), new ECB$1(37, 24)), new ECBlocks$1(30, new ECB$1(19, 15), new ECB$1(26, 16))),
        new Version$1(30, Int32Array.from([6, 26, 52, 78, 104, 130]), new ECBlocks$1(30, new ECB$1(5, 115), new ECB$1(10, 116)), new ECBlocks$1(28, new ECB$1(19, 47), new ECB$1(10, 48)), new ECBlocks$1(30, new ECB$1(15, 24), new ECB$1(25, 25)), new ECBlocks$1(30, new ECB$1(23, 15), new ECB$1(25, 16))),
        new Version$1(31, Int32Array.from([6, 30, 56, 82, 108, 134]), new ECBlocks$1(30, new ECB$1(13, 115), new ECB$1(3, 116)), new ECBlocks$1(28, new ECB$1(2, 46), new ECB$1(29, 47)), new ECBlocks$1(30, new ECB$1(42, 24), new ECB$1(1, 25)), new ECBlocks$1(30, new ECB$1(23, 15), new ECB$1(28, 16))),
        new Version$1(32, Int32Array.from([6, 34, 60, 86, 112, 138]), new ECBlocks$1(30, new ECB$1(17, 115)), new ECBlocks$1(28, new ECB$1(10, 46), new ECB$1(23, 47)), new ECBlocks$1(30, new ECB$1(10, 24), new ECB$1(35, 25)), new ECBlocks$1(30, new ECB$1(19, 15), new ECB$1(35, 16))),
        new Version$1(33, Int32Array.from([6, 30, 58, 86, 114, 142]), new ECBlocks$1(30, new ECB$1(17, 115), new ECB$1(1, 116)), new ECBlocks$1(28, new ECB$1(14, 46), new ECB$1(21, 47)), new ECBlocks$1(30, new ECB$1(29, 24), new ECB$1(19, 25)), new ECBlocks$1(30, new ECB$1(11, 15), new ECB$1(46, 16))),
        new Version$1(34, Int32Array.from([6, 34, 62, 90, 118, 146]), new ECBlocks$1(30, new ECB$1(13, 115), new ECB$1(6, 116)), new ECBlocks$1(28, new ECB$1(14, 46), new ECB$1(23, 47)), new ECBlocks$1(30, new ECB$1(44, 24), new ECB$1(7, 25)), new ECBlocks$1(30, new ECB$1(59, 16), new ECB$1(1, 17))),
        new Version$1(35, Int32Array.from([6, 30, 54, 78, 102, 126, 150]), new ECBlocks$1(30, new ECB$1(12, 121), new ECB$1(7, 122)), new ECBlocks$1(28, new ECB$1(12, 47), new ECB$1(26, 48)), new ECBlocks$1(30, new ECB$1(39, 24), new ECB$1(14, 25)), new ECBlocks$1(30, new ECB$1(22, 15), new ECB$1(41, 16))),
        new Version$1(36, Int32Array.from([6, 24, 50, 76, 102, 128, 154]), new ECBlocks$1(30, new ECB$1(6, 121), new ECB$1(14, 122)), new ECBlocks$1(28, new ECB$1(6, 47), new ECB$1(34, 48)), new ECBlocks$1(30, new ECB$1(46, 24), new ECB$1(10, 25)), new ECBlocks$1(30, new ECB$1(2, 15), new ECB$1(64, 16))),
        new Version$1(37, Int32Array.from([6, 28, 54, 80, 106, 132, 158]), new ECBlocks$1(30, new ECB$1(17, 122), new ECB$1(4, 123)), new ECBlocks$1(28, new ECB$1(29, 46), new ECB$1(14, 47)), new ECBlocks$1(30, new ECB$1(49, 24), new ECB$1(10, 25)), new ECBlocks$1(30, new ECB$1(24, 15), new ECB$1(46, 16))),
        new Version$1(38, Int32Array.from([6, 32, 58, 84, 110, 136, 162]), new ECBlocks$1(30, new ECB$1(4, 122), new ECB$1(18, 123)), new ECBlocks$1(28, new ECB$1(13, 46), new ECB$1(32, 47)), new ECBlocks$1(30, new ECB$1(48, 24), new ECB$1(14, 25)), new ECBlocks$1(30, new ECB$1(42, 15), new ECB$1(32, 16))),
        new Version$1(39, Int32Array.from([6, 26, 54, 82, 110, 138, 166]), new ECBlocks$1(30, new ECB$1(20, 117), new ECB$1(4, 118)), new ECBlocks$1(28, new ECB$1(40, 47), new ECB$1(7, 48)), new ECBlocks$1(30, new ECB$1(43, 24), new ECB$1(22, 25)), new ECBlocks$1(30, new ECB$1(10, 15), new ECB$1(67, 16))),
        new Version$1(40, Int32Array.from([6, 30, 58, 86, 114, 142, 170]), new ECBlocks$1(30, new ECB$1(19, 118), new ECB$1(6, 119)), new ECBlocks$1(28, new ECB$1(18, 47), new ECB$1(31, 48)), new ECBlocks$1(30, new ECB$1(34, 24), new ECB$1(34, 25)), new ECBlocks$1(30, new ECB$1(20, 15), new ECB$1(61, 16))),
    ];

    /*
     * Copyright 2007 ZXing authors
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *      http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */
    /**
     * <p>Encapsulates data masks for the data bits in a QR code, per ISO 18004:2006 6.8. Implementations
     * of this class can un-mask a raw BitMatrix. For simplicity, they will unmask the entire BitMatrix,
     * including areas used for finder patterns, timing patterns, etc. These areas should be unused
     * after the point they are unmasked anyway.</p>
     *
     * <p>Note that the diagram in section 6.8.1 is misleading since it indicates that i is column position
     * and j is row position. In fact, as the text says, i is row position and j is column position.</p>
     *
     * @author Sean Owen
     */
    class DataMask {
        // See ISO 18004:2006 6.8.1
        constructor(value, isMasked) {
            this.value = value;
            this.isMasked = isMasked;
        }
        // End of enum constants.
        /**
         * <p>Implementations of this method reverse the data masking process applied to a QR Code and
         * make its bits ready to read.</p>
         *
         * @param bits representation of QR Code bits
         * @param dimension dimension of QR Code, represented by bits, being unmasked
         */
        unmaskBitMatrix(bits, dimension /*int*/) {
            for (let i = 0; i < dimension; i++) {
                for (let j = 0; j < dimension; j++) {
                    if (this.isMasked(i, j)) {
                        bits.flip(j, i);
                    }
                }
            }
        }
    }
    DataMask.values = new Map([
        /**
         * 000: mask bits for which (x + y) mod 2 == 0
         */
        [
            DataMaskValues.DATA_MASK_000,
            new DataMask(DataMaskValues.DATA_MASK_000, (i /*int*/, j /*int*/) => {
                return ((i + j) & 0x01) === 0;
            }),
        ],
        /**
         * 001: mask bits for which x mod 2 == 0
         */
        [
            DataMaskValues.DATA_MASK_001,
            new DataMask(DataMaskValues.DATA_MASK_001, (i /*int*/, j /*int*/) => {
                return (i & 0x01) === 0;
            }),
        ],
        /**
         * 010: mask bits for which y mod 3 == 0
         */
        [
            DataMaskValues.DATA_MASK_010,
            new DataMask(DataMaskValues.DATA_MASK_010, (i /*int*/, j /*int*/) => {
                return j % 3 === 0;
            }),
        ],
        /**
         * 011: mask bits for which (x + y) mod 3 == 0
         */
        [
            DataMaskValues.DATA_MASK_011,
            new DataMask(DataMaskValues.DATA_MASK_011, (i /*int*/, j /*int*/) => {
                return (i + j) % 3 === 0;
            }),
        ],
        /**
         * 100: mask bits for which (x/2 + y/3) mod 2 == 0
         */
        [
            DataMaskValues.DATA_MASK_100,
            new DataMask(DataMaskValues.DATA_MASK_100, (i /*int*/, j /*int*/) => {
                return ((Math.floor(i / 2) + Math.floor(j / 3)) & 0x01) === 0;
            }),
        ],
        /**
         * 101: mask bits for which xy mod 2 + xy mod 3 == 0
         * equivalently, such that xy mod 6 == 0
         */
        [
            DataMaskValues.DATA_MASK_101,
            new DataMask(DataMaskValues.DATA_MASK_101, (i /*int*/, j /*int*/) => {
                return (i * j) % 6 === 0;
            }),
        ],
        /**
         * 110: mask bits for which (xy mod 2 + xy mod 3) mod 2 == 0
         * equivalently, such that xy mod 6 < 3
         */
        [
            DataMaskValues.DATA_MASK_110,
            new DataMask(DataMaskValues.DATA_MASK_110, (i /*int*/, j /*int*/) => {
                return (i * j) % 6 < 3;
            }),
        ],
        /**
         * 111: mask bits for which ((x+y)mod 2 + xy mod 3) mod 2 == 0
         * equivalently, such that (x + y + xy mod 3) mod 2 == 0
         */
        [
            DataMaskValues.DATA_MASK_111,
            new DataMask(DataMaskValues.DATA_MASK_111, (i /*int*/, j /*int*/) => {
                return ((i + j + ((i * j) % 3)) & 0x01) === 0;
            }),
        ],
    ]);

    /*
     * Copyright 2007 ZXing authors
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *      http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */
    /**
     * @author Sean Owen
     */
    class BitMatrixParser {
        /**
         * @param bitMatrix {@link BitMatrix} to parse
         * @throws FormatException if dimension is not >= 21 and 1 mod 4
         */
        constructor(bitMatrix) {
            this.isMirror = false;
            const dimension = bitMatrix.getHeight();
            if (dimension < 21 || (dimension & 0x03) !== 1) {
                throw new FormatException();
            }
            this.bitMatrix = bitMatrix;
        }
        /**
         * <p>Reads format information from one of its two locations within the QR Code.</p>
         *
         * @return {@link FormatInformation} encapsulating the QR Code's format info
         * @throws FormatException if both format information locations cannot be parsed as
         * the valid encoding of format information
         */
        readFormatInformation() {
            if (this.parsedFormatInfo !== null && this.parsedFormatInfo !== undefined) {
                return this.parsedFormatInfo;
            }
            // Read top-left format info bits
            let formatInfoBits1 = 0;
            for (let i = 0; i < 6; i++) {
                formatInfoBits1 = this.copyBit(i, 8, formatInfoBits1);
            }
            // .. and skip a bit in the timing pattern ...
            formatInfoBits1 = this.copyBit(7, 8, formatInfoBits1);
            formatInfoBits1 = this.copyBit(8, 8, formatInfoBits1);
            formatInfoBits1 = this.copyBit(8, 7, formatInfoBits1);
            // .. and skip a bit in the timing pattern ...
            for (let j = 5; j >= 0; j--) {
                formatInfoBits1 = this.copyBit(8, j, formatInfoBits1);
            }
            // Read the top-right/bottom-left pattern too
            const dimension = this.bitMatrix.getHeight();
            let formatInfoBits2 = 0;
            const jMin = dimension - 7;
            for (let j = dimension - 1; j >= jMin; j--) {
                formatInfoBits2 = this.copyBit(8, j, formatInfoBits2);
            }
            for (let i = dimension - 8; i < dimension; i++) {
                formatInfoBits2 = this.copyBit(i, 8, formatInfoBits2);
            }
            const parsedFormatInfo = FormatInformation.decodeFormatInformation(formatInfoBits1, formatInfoBits2);
            if (parsedFormatInfo !== null) {
                return (this.parsedFormatInfo = parsedFormatInfo);
            }
            throw new FormatException();
        }
        /**
         * <p>Reads version information from one of its two locations within the QR Code.</p>
         *
         * @return {@link Version} encapsulating the QR Code's version
         * @throws FormatException if both version information locations cannot be parsed as
         * the valid encoding of version information
         */
        readVersion() {
            if (this.parsedVersion !== null && this.parsedVersion !== undefined) {
                return this.parsedVersion;
            }
            const dimension = this.bitMatrix.getHeight();
            const provisionalVersion = Math.floor((dimension - 17) / 4);
            if (provisionalVersion <= 6) {
                return Version$1.getVersionForNumber(provisionalVersion);
            }
            // Read top-right version info: 3 wide by 6 tall
            let versionBits = 0;
            const ijMin = dimension - 11;
            for (let j = 5; j >= 0; j--) {
                for (let i = dimension - 9; i >= ijMin; i--) {
                    versionBits = this.copyBit(i, j, versionBits);
                }
            }
            let theParsedVersion = Version$1.decodeVersionInformation(versionBits);
            if (theParsedVersion !== null && theParsedVersion.getDimensionForVersion() === dimension) {
                this.parsedVersion = theParsedVersion;
                return theParsedVersion;
            }
            // Hmm, failed. Try bottom left: 6 wide by 3 tall
            versionBits = 0;
            for (let i = 5; i >= 0; i--) {
                for (let j = dimension - 9; j >= ijMin; j--) {
                    versionBits = this.copyBit(i, j, versionBits);
                }
            }
            theParsedVersion = Version$1.decodeVersionInformation(versionBits);
            if (theParsedVersion !== null && theParsedVersion.getDimensionForVersion() === dimension) {
                this.parsedVersion = theParsedVersion;
                return theParsedVersion;
            }
            throw new FormatException();
        }
        copyBit(i /*int*/, j /*int*/, versionBits /*int*/) {
            const bit = this.isMirror ? this.bitMatrix.get(j, i) : this.bitMatrix.get(i, j);
            return bit ? (versionBits << 1) | 0x1 : versionBits << 1;
        }
        /**
         * <p>Reads the bits in the {@link BitMatrix} representing the finder pattern in the
         * correct order in order to reconstruct the codewords bytes contained within the
         * QR Code.</p>
         *
         * @return bytes encoded within the QR Code
         * @throws FormatException if the exact number of bytes expected is not read
         */
        readCodewords() {
            const formatInfo = this.readFormatInformation();
            const version = this.readVersion();
            // Get the data mask for the format used in this QR Code. This will exclude
            // some bits from reading as we wind through the bit matrix.
            const dataMask = DataMask.values.get(formatInfo.getDataMask());
            if (dataMask === undefined) {
                throw new FormatException();
            }
            const dimension = this.bitMatrix.getHeight();
            dataMask.unmaskBitMatrix(this.bitMatrix, dimension);
            const functionPattern = version.buildFunctionPattern();
            let readingUp = true;
            const result = new Uint8Array(version.getTotalCodewords());
            let resultOffset = 0;
            let currentByte = 0;
            let bitsRead = 0;
            // Read columns in pairs, from right to left
            for (let j = dimension - 1; j > 0; j -= 2) {
                if (j === 6) {
                    // Skip whole column with vertical alignment pattern
                    // saves time and makes the other code proceed more cleanly
                    j--;
                }
                // Read alternatingly from bottom to top then top to bottom
                for (let count = 0; count < dimension; count++) {
                    const i = readingUp ? dimension - 1 - count : count;
                    for (let col = 0; col < 2; col++) {
                        // Ignore bits covered by the function pattern
                        if (!functionPattern.get(j - col, i)) {
                            // Read a bit
                            bitsRead++;
                            currentByte <<= 1;
                            if (this.bitMatrix.get(j - col, i)) {
                                currentByte |= 1;
                            }
                            // If we've made a whole byte, save it off
                            if (bitsRead === 8) {
                                result[resultOffset++] = /*(byte) */ currentByte;
                                bitsRead = 0;
                                currentByte = 0;
                            }
                        }
                    }
                }
                readingUp = !readingUp; // readingUp ^= true; // readingUp = !readingUp; // switch directions
            }
            if (resultOffset !== version.getTotalCodewords()) {
                throw new FormatException();
            }
            return result;
        }
        /**
         * Revert the mask removal done while reading the code words. The bit matrix should revert to its original state.
         */
        remask() {
            if (this.parsedFormatInfo === null || this.parsedFormatInfo === undefined) {
                return; // We have no format information, and have no data mask
            }
            const dataMask = DataMask.values.get(this.parsedFormatInfo.getDataMask());
            if (!dataMask) {
                throw new FormatException();
            }
            const dimension = this.bitMatrix.getHeight();
            dataMask.unmaskBitMatrix(this.bitMatrix, dimension);
        }
        /**
         * Prepare the parser for a mirrored operation.
         * This flag has effect only on the {@link #readFormatInformation()} and the
         * {@link #readVersion()}. Before proceeding with {@link #readCodewords()} the
         * {@link #mirror()} method should be called.
         *
         * @param mirror Whether to read version and format information mirrored.
         */
        setMirror(isMirror) {
            this.parsedVersion = undefined;
            this.parsedFormatInfo = undefined;
            this.isMirror = isMirror;
        }
        /** Mirror the bit matrix in order to attempt a second reading. */
        mirror() {
            const bitMatrix = this.bitMatrix;
            for (let x = 0, width = bitMatrix.getWidth(); x < width; x++) {
                for (let y = x + 1, height = bitMatrix.getHeight(); y < height; y++) {
                    if (bitMatrix.get(x, y) !== bitMatrix.get(y, x)) {
                        bitMatrix.flip(y, x);
                        bitMatrix.flip(x, y);
                    }
                }
            }
        }
    }

    /*
     * Copyright 2013 ZXing authors
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *      http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */
    /**
     * Meta-data container for QR Code decoding. Instances of this class may be used to convey information back to the
     * decoding caller. Callers are expected to process this.
     *
     * @see com.google.zxing.common.DecoderResult#getOther()
     */
    class QRCodeDecoderMetaData {
        constructor(mirrored) {
            this.mirrored = mirrored;
        }
        /**
         * @return true if the QR Code was mirrored.
         */
        isMirrored() {
            return this.mirrored;
        }
        /**
         * Apply the result points' order correction due to mirroring.
         *
         * @param points Array of points to apply mirror correction to.
         */
        applyMirroredCorrection(points) {
            if (!this.mirrored || points === null || points.length < 3) {
                return;
            }
            const bottomLeft = points[0];
            points[0] = points[2];
            points[2] = bottomLeft;
            // No need to 'fix' top-left and alignment pattern.
        }
    }

    /*
     * Copyright 2007 ZXing authors
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *      http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */
    /**
     * <p>Encapsulates a block of data within a QR Code. QR Codes may split their data into
     * multiple blocks, each of which is a unit of data and error-correction codewords. Each
     * is represented by an instance of this class.</p>
     *
     * @author Sean Owen
     */
    class DataBlock {
        constructor(numDataCodewords /*int*/, codewords) {
            this.numDataCodewords = numDataCodewords;
            this.codewords = codewords;
        }
        /**
         * <p>When QR Codes use multiple data blocks, they are actually interleaved.
         * That is, the first byte of data block 1 to n is written, then the second bytes, and so on. This
         * method will separate the data into original blocks.</p>
         *
         * @param rawCodewords bytes as read directly from the QR Code
         * @param version version of the QR Code
         * @param ecLevel error-correction level of the QR Code
         * @return DataBlocks containing original bytes, "de-interleaved" from representation in the
         *         QR Code
         */
        static getDataBlocks(rawCodewords, version, ecLevel) {
            if (rawCodewords.length !== version.getTotalCodewords()) {
                throw new IllegalArgumentException();
            }
            // Figure out the number and size of data blocks used by this version and
            // error correction level
            const ecBlocks = version.getECBlocksForLevel(ecLevel);
            // First count the total number of data blocks
            let totalBlocks = 0;
            const ecBlockArray = ecBlocks.getECBlocks();
            for (const ecBlock of ecBlockArray) {
                totalBlocks += ecBlock.getCount();
            }
            // Now establish DataBlocks of the appropriate size and number of data codewords
            const result = new Array(totalBlocks);
            let numResultBlocks = 0;
            for (const ecBlock of ecBlockArray) {
                for (let i = 0; i < ecBlock.getCount(); i++) {
                    const numDataCodewords = ecBlock.getDataCodewords();
                    const numBlockCodewords = ecBlocks.getECCodewordsPerBlock() + numDataCodewords;
                    result[numResultBlocks++] = new DataBlock(numDataCodewords, new Uint8Array(numBlockCodewords));
                }
            }
            // All blocks have the same amount of data, except that the last n
            // (where n may be 0) have 1 more byte. Figure out where these start.
            const shorterBlocksTotalCodewords = result[0].codewords.length;
            let longerBlocksStartAt = result.length - 1;
            // TYPESCRIPTPORT: check length is correct here
            while (longerBlocksStartAt >= 0) {
                const numCodewords = result[longerBlocksStartAt].codewords.length;
                if (numCodewords === shorterBlocksTotalCodewords) {
                    break;
                }
                longerBlocksStartAt--;
            }
            longerBlocksStartAt++;
            const shorterBlocksNumDataCodewords = shorterBlocksTotalCodewords - ecBlocks.getECCodewordsPerBlock();
            // The last elements of result may be 1 element longer
            // first fill out as many elements as all of them have
            let rawCodewordsOffset = 0;
            for (let i = 0; i < shorterBlocksNumDataCodewords; i++) {
                for (let j = 0; j < numResultBlocks; j++) {
                    result[j].codewords[i] = rawCodewords[rawCodewordsOffset++];
                }
            }
            // Fill out the last data block in the longer ones
            for (let j = longerBlocksStartAt; j < numResultBlocks; j++) {
                result[j].codewords[shorterBlocksNumDataCodewords] = rawCodewords[rawCodewordsOffset++];
            }
            // Now add in error correction blocks
            const max = result[0].codewords.length;
            for (let i = shorterBlocksNumDataCodewords; i < max; i++) {
                for (let j = 0; j < numResultBlocks; j++) {
                    const iOffset = j < longerBlocksStartAt ? i : i + 1;
                    result[j].codewords[iOffset] = rawCodewords[rawCodewordsOffset++];
                }
            }
            return result;
        }
        getNumDataCodewords() {
            return this.numDataCodewords;
        }
        getCodewords() {
            return this.codewords;
        }
    }

    /*
     * Copyright 2007 ZXing authors
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *      http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */
    /**
     * <p>See ISO 18004:2006, 6.4.1, Tables 2 and 3. This enum encapsulates the various modes in which
     * data can be encoded to bits in the QR code standard.</p>
     *
     * @author Sean Owen
     */
    class Mode$1 {
        constructor(value, stringValue, characterCountBitsForVersions, bits /*int*/) {
            this.value = value;
            this.stringValue = stringValue;
            this.characterCountBitsForVersions = characterCountBitsForVersions;
            this.bits = bits;
            Mode$1.FOR_BITS.set(bits, this);
            Mode$1.FOR_VALUE.set(value, this);
        }
        /**
         * @param bits four bits encoding a QR Code data mode
         * @return Mode encoded by these bits
         * @throws IllegalArgumentException if bits do not correspond to a known mode
         */
        static forBits(bits /*int*/) {
            const mode = Mode$1.FOR_BITS.get(bits);
            if (undefined === mode) {
                throw new IllegalArgumentException();
            }
            return mode;
        }
        /**
         * @param version version in question
         * @return number of bits used, in this QR Code symbol {@link Version}, to encode the
         *         count of characters that will follow encoded in this Mode
         */
        getCharacterCountBits(version) {
            const versionNumber = version.getVersionNumber();
            let offset;
            if (versionNumber <= 9) {
                offset = 0;
            }
            else if (versionNumber <= 26) {
                offset = 1;
            }
            else {
                offset = 2;
            }
            return this.characterCountBitsForVersions[offset];
        }
        getValue() {
            return this.value;
        }
        getBits() {
            return this.bits;
        }
        equals(o) {
            if (!(o instanceof Mode$1)) {
                return false;
            }
            const other = o;
            return this.value === other.value;
        }
        toString() {
            return this.stringValue;
        }
    }
    Mode$1.FOR_BITS = new Map();
    Mode$1.FOR_VALUE = new Map();
    Mode$1.TERMINATOR = new Mode$1(ModeValues.TERMINATOR, "TERMINATOR", Int32Array.from([0, 0, 0]), 0x00); // Not really a mode...
    Mode$1.NUMERIC = new Mode$1(ModeValues.NUMERIC, "NUMERIC", Int32Array.from([10, 12, 14]), 0x01);
    Mode$1.ALPHANUMERIC = new Mode$1(ModeValues.ALPHANUMERIC, "ALPHANUMERIC", Int32Array.from([9, 11, 13]), 0x02);
    Mode$1.STRUCTURED_APPEND = new Mode$1(ModeValues.STRUCTURED_APPEND, "STRUCTURED_APPEND", Int32Array.from([0, 0, 0]), 0x03); // Not supported
    Mode$1.BYTE = new Mode$1(ModeValues.BYTE, "BYTE", Int32Array.from([8, 16, 16]), 0x04);
    Mode$1.ECI = new Mode$1(ModeValues.ECI, "ECI", Int32Array.from([0, 0, 0]), 0x07); // character counts don't apply
    Mode$1.KANJI = new Mode$1(ModeValues.KANJI, "KANJI", Int32Array.from([8, 10, 12]), 0x08);
    Mode$1.FNC1_FIRST_POSITION = new Mode$1(ModeValues.FNC1_FIRST_POSITION, "FNC1_FIRST_POSITION", Int32Array.from([0, 0, 0]), 0x05);
    Mode$1.FNC1_SECOND_POSITION = new Mode$1(ModeValues.FNC1_SECOND_POSITION, "FNC1_SECOND_POSITION", Int32Array.from([0, 0, 0]), 0x09);
    /** See GBT 18284-2000; "Hanzi" is a transliteration of this mode name. */
    Mode$1.HANZI = new Mode$1(ModeValues.HANZI, "HANZI", Int32Array.from([8, 10, 12]), 0x0d);

    /**
     * Responsible for en/decoding strings.
     */
    class StringEncoding {
        /**
         * Decodes some Uint8Array to a string format.
         */
        static decode(bytes, encoding) {
            const encodingName = this.encodingName(encoding);
            // Increases browser support.
            if (typeof TextDecoder === "undefined") {
                return this.decodeFallback(bytes, encodingName);
            }
            return new TextDecoder(encodingName).decode(bytes);
        }
        /**
         * Encodes some string into a Uint8Array.
         *
         * @todo natively support other string formats than UTF-8.
         */
        static encode(s, encoding) {
            // Uses `text-encoding` package.
            if (!StringEncoding.isBrowser()) {
                // SEE: https://nodejs.org/api/buffer.html#buffer_class_buffer
                // SEE: https://github.com/polygonplanet/encoding.js/
                // SEE: https://stackoverflow.com/questions/17191945/conversion-between-utf-8-arraybuffer-and-string
                const EncoderConstructor = TextEncoder;
                return new EncoderConstructor(this.encodingName(encoding), {
                    NONSTANDARD_allowLegacyEncoding: true,
                }).encode(s);
            }
            // Increases browser support.
            if (typeof TextEncoder === "undefined") {
                return this.encodeFallback(s);
            }
            // TextEncoder only encodes to UTF8 by default as specified by encoding.spec.whatwg.org
            return new TextEncoder().encode(s);
        }
        static isBrowser() {
            // self.location : "[object Location]" || "[object WorkerLocation]"
            return (typeof self !== "undefined" &&
                self.location &&
                {}.toString.call(self.location).indexOf("Location]") !== -1);
        }
        /**
         * Returns the string value from some encoding character set.
         */
        static encodingName(encoding) {
            return typeof encoding === "string" ? encoding : encoding.getName();
        }
        /**
         * Returns character set from some encoding character set.
         */
        static encodingCharacterSet(encoding) {
            return CharacterSetECI.getCharacterSetECIByName(this.encodingName(encoding));
        }
        /**
         * Runs a fallback for the native decoding funcion.
         */
        static decodeFallback(bytes, encoding) {
            const characterSet = this.encodingCharacterSet(encoding);
            if (characterSet.equals(CharacterSetECI.UTF8) ||
                characterSet.equals(CharacterSetECI.ISO8859_1) ||
                characterSet.equals(CharacterSetECI.ASCII)) {
                let s = "";
                for (let i = 0, length = bytes.length; i < length; i++) {
                    let h = bytes[i].toString(16);
                    if (h.length < 2) {
                        h = "0" + h;
                    }
                    s += "%" + h;
                }
                return decodeURIComponent(s);
            }
            if (characterSet.equals(CharacterSetECI.UnicodeBigUnmarked)) {
                return String.fromCharCode.apply(null, [].slice.call(new Uint16Array(bytes.buffer)));
            }
            throw new UnsupportedOperationException(`Encoding ${this.encodingName(encoding)} not supported by fallback.`);
        }
        /**
         * Runs a fallback for the native encoding funcion.
         *
         * @see https://stackoverflow.com/a/17192845/4367683
         */
        static encodeFallback(s) {
            const encodedURIstring = btoa(unescape(encodeURIComponent(s)));
            const charList = encodedURIstring.split("");
            const uintArray = [];
            for (let i = 0; i < charList.length; i++) {
                uintArray.push(charList[i].charCodeAt(0));
            }
            return new Uint8Array(uintArray);
        }
    }

    /*
     * Copyright 2007 ZXing authors
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *      http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */
    /*import java.io.UnsupportedEncodingException;*/
    /*import java.util.ArrayList;*/
    /*import java.util.Collection;*/
    /*import java.util.List;*/
    /*import java.util.Map;*/
    /**
     * <p>QR Codes can encode text as bits in one of several modes, and can use multiple modes
     * in one QR Code. This class decodes the bits back into text.</p>
     *
     * <p>See ISO 18004:2006, 6.4.3 - 6.4.7</p>
     *
     * @author Sean Owen
     */
    class DecodedBitStreamParser {
        static decode(bytes, version, ecLevel, hints) {
            const bits = new BitSource(bytes);
            let result = new StringBuilder();
            const byteSegments = new Array(); // 1
            // TYPESCRIPTPORT: I do not use constructor with size 1 as in original Java means capacity and the array length is checked below
            let symbolSequence = -1;
            let parityData = -1;
            try {
                let currentCharacterSetECI = undefined;
                let fc1InEffect = false;
                let mode;
                do {
                    // While still another segment to read...
                    if (bits.available() < 4) {
                        // OK, assume we're done. Really, a TERMINATOR mode should have been recorded here
                        mode = Mode$1.TERMINATOR;
                    }
                    else {
                        const modeBits = bits.readBits(4);
                        mode = Mode$1.forBits(modeBits); // mode is encoded by 4 bits
                    }
                    switch (mode) {
                        case Mode$1.TERMINATOR:
                            break;
                        case Mode$1.FNC1_FIRST_POSITION:
                        case Mode$1.FNC1_SECOND_POSITION:
                            // We do little with FNC1 except alter the parsed result a bit according to the spec
                            fc1InEffect = true;
                            break;
                        case Mode$1.STRUCTURED_APPEND:
                            if (bits.available() < 16) {
                                throw new FormatException();
                            }
                            // sequence number and parity is added later to the result metadata
                            // Read next 8 bits (symbol sequence #) and 8 bits (data: parity), then continue
                            symbolSequence = bits.readBits(8);
                            parityData = bits.readBits(8);
                            break;
                        case Mode$1.ECI:
                            // Count doesn't apply to ECI
                            const value = DecodedBitStreamParser.parseECIValue(bits);
                            currentCharacterSetECI = CharacterSetECI.getCharacterSetECIByValue(value);
                            break;
                        case Mode$1.HANZI:
                            // First handle Hanzi mode which does not start with character count
                            // Chinese mode contains a sub set indicator right after mode indicator
                            const subset = bits.readBits(4);
                            const countHanzi = bits.readBits(mode.getCharacterCountBits(version));
                            if (subset === DecodedBitStreamParser.GB2312_SUBSET) {
                                DecodedBitStreamParser.decodeHanziSegment(bits, result, countHanzi);
                            }
                            break;
                        default:
                            // "Normal" QR code modes:
                            // How many characters will follow, encoded in this mode?
                            const count = bits.readBits(mode.getCharacterCountBits(version));
                            switch (mode) {
                                case Mode$1.NUMERIC:
                                    DecodedBitStreamParser.decodeNumericSegment(bits, result, count);
                                    break;
                                case Mode$1.ALPHANUMERIC:
                                    DecodedBitStreamParser.decodeAlphanumericSegment(bits, result, count, fc1InEffect);
                                    break;
                                case Mode$1.BYTE:
                                    // if (!currentCharacterSetECI) {
                                    //   throw new FormatException();
                                    // }
                                    DecodedBitStreamParser.decodeByteSegment(bits, result, count, currentCharacterSetECI, byteSegments, hints);
                                    break;
                                case Mode$1.KANJI:
                                    DecodedBitStreamParser.decodeKanjiSegment(bits, result, count);
                                    break;
                                default:
                                    throw new FormatException();
                            }
                            break;
                    }
                } while (mode !== Mode$1.TERMINATOR);
            }
            catch (iae /*: IllegalArgumentException*/) {
                // from readBits() calls
                throw new FormatException();
            }
            return new DecoderResult(bytes, result.toString(), byteSegments, ecLevel === null ? "" : ecLevel.toString(), symbolSequence, parityData);
        }
        /**
         * See specification GBT 18284-2000
         */
        static decodeHanziSegment(bits, result, count /*int*/) {
            // Don't crash trying to read more bits than we have available.
            if (count * 13 > bits.available()) {
                throw new FormatException();
            }
            // Each character will require 2 bytes. Read the characters as 2-byte pairs
            // and decode as GB2312 afterwards
            const buffer = new Uint8Array(2 * count);
            let offset = 0;
            while (count > 0) {
                // Each 13 bits encodes a 2-byte character
                const twoBytes = bits.readBits(13);
                let assembledTwoBytes = (((twoBytes / 0x060) << 8) & 0xffffffff) | twoBytes % 0x060;
                if (assembledTwoBytes < 0x003bf) {
                    // In the 0xA1A1 to 0xAAFE range
                    assembledTwoBytes += 0x0a1a1;
                }
                else {
                    // In the 0xB0A1 to 0xFAFE range
                    assembledTwoBytes += 0x0a6a1;
                }
                buffer[offset] = /*(byte) */ (assembledTwoBytes >> 8) & 0xff;
                buffer[offset + 1] = /*(byte) */ assembledTwoBytes & 0xff;
                offset += 2;
                count--;
            }
            try {
                result.append(StringEncoding.decode(buffer, StringUtils.GB2312));
                // TYPESCRIPTPORT: TODO: implement GB2312 decode. StringView from MDN could be a starting point
            }
            catch (ignored /*: UnsupportedEncodingException*/) {
                throw new FormatException(ignored);
            }
        }
        static decodeKanjiSegment(bits, result, count /*int*/) {
            // Don't crash trying to read more bits than we have available.
            if (count * 13 > bits.available()) {
                throw new FormatException();
            }
            // Each character will require 2 bytes. Read the characters as 2-byte pairs
            // and decode as Shift_JIS afterwards
            const buffer = new Uint8Array(2 * count);
            let offset = 0;
            while (count > 0) {
                // Each 13 bits encodes a 2-byte character
                const twoBytes = bits.readBits(13);
                let assembledTwoBytes = (((twoBytes / 0x0c0) << 8) & 0xffffffff) | twoBytes % 0x0c0;
                if (assembledTwoBytes < 0x01f00) {
                    // In the 0x8140 to 0x9FFC range
                    assembledTwoBytes += 0x08140;
                }
                else {
                    // In the 0xE040 to 0xEBBF range
                    assembledTwoBytes += 0x0c140;
                }
                buffer[offset] = /*(byte) */ assembledTwoBytes >> 8;
                buffer[offset + 1] = /*(byte) */ assembledTwoBytes;
                offset += 2;
                count--;
            }
            // Shift_JIS may not be supported in some environments:
            try {
                result.append(StringEncoding.decode(buffer, StringUtils.SHIFT_JIS));
                // TYPESCRIPTPORT: TODO: implement SHIFT_JIS decode. StringView from MDN could be a starting point
            }
            catch (ignored /*: UnsupportedEncodingException*/) {
                throw new FormatException(ignored);
            }
        }
        static decodeByteSegment(bits, result, count /*int*/, currentCharacterSetECI, byteSegments, hints) {
            // Don't crash trying to read more bits than we have available.
            if (8 * count > bits.available()) {
                throw new FormatException();
            }
            const readBytes = new Uint8Array(count);
            for (let i = 0; i < count; i++) {
                readBytes[i] = /*(byte) */ bits.readBits(8);
            }
            let encoding;
            if (currentCharacterSetECI === null || currentCharacterSetECI === undefined) {
                // The spec isn't clear on this mode; see
                // section 6.4.5: t does not say which encoding to assuming
                // upon decoding. I have seen ISO-8859-1 used as well as
                // Shift_JIS -- without anything like an ECI designator to
                // give a hint.
                encoding = StringUtils.guessEncoding(readBytes, hints);
            }
            else {
                encoding = currentCharacterSetECI.getName();
            }
            try {
                result.append(StringEncoding.decode(readBytes, encoding));
            }
            catch (ignored /*: UnsupportedEncodingException*/) {
                throw new FormatException(ignored);
            }
            byteSegments.push(readBytes);
        }
        static toAlphaNumericChar(value /*int*/) {
            if (value >= DecodedBitStreamParser.ALPHANUMERIC_CHARS.length) {
                throw new FormatException();
            }
            return DecodedBitStreamParser.ALPHANUMERIC_CHARS[value];
        }
        static decodeAlphanumericSegment(bits, result, count /*int*/, fc1InEffect) {
            // Read two characters at a time
            const start = result.length();
            while (count > 1) {
                if (bits.available() < 11) {
                    throw new FormatException();
                }
                const nextTwoCharsBits = bits.readBits(11);
                result.append(DecodedBitStreamParser.toAlphaNumericChar(Math.floor(nextTwoCharsBits / 45)));
                result.append(DecodedBitStreamParser.toAlphaNumericChar(nextTwoCharsBits % 45));
                count -= 2;
            }
            if (count === 1) {
                // special case: one character left
                if (bits.available() < 6) {
                    throw new FormatException();
                }
                result.append(DecodedBitStreamParser.toAlphaNumericChar(bits.readBits(6)));
            }
            // See section 6.4.8.1, 6.4.8.2
            if (fc1InEffect) {
                // We need to massage the result a bit if in an FNC1 mode:
                for (let i = start; i < result.length(); i++) {
                    if (result.charAt(i) === "%") {
                        if (i < result.length() - 1 && result.charAt(i + 1) === "%") {
                            // %% is rendered as %
                            result.deleteCharAt(i + 1);
                        }
                        else {
                            // In alpha mode, % should be converted to FNC1 separator 0x1D
                            result.setCharAt(i, String.fromCharCode(0x1d));
                        }
                    }
                }
            }
        }
        static decodeNumericSegment(bits, result, count /*int*/) {
            // Read three digits at a time
            while (count >= 3) {
                // Each 10 bits encodes three digits
                if (bits.available() < 10) {
                    throw new FormatException();
                }
                const threeDigitsBits = bits.readBits(10);
                if (threeDigitsBits >= 1000) {
                    throw new FormatException();
                }
                result.append(DecodedBitStreamParser.toAlphaNumericChar(Math.floor(threeDigitsBits / 100)));
                result.append(DecodedBitStreamParser.toAlphaNumericChar(Math.floor(threeDigitsBits / 10) % 10));
                result.append(DecodedBitStreamParser.toAlphaNumericChar(threeDigitsBits % 10));
                count -= 3;
            }
            if (count === 2) {
                // Two digits left over to read, encoded in 7 bits
                if (bits.available() < 7) {
                    throw new FormatException();
                }
                const twoDigitsBits = bits.readBits(7);
                if (twoDigitsBits >= 100) {
                    throw new FormatException();
                }
                result.append(DecodedBitStreamParser.toAlphaNumericChar(Math.floor(twoDigitsBits / 10)));
                result.append(DecodedBitStreamParser.toAlphaNumericChar(twoDigitsBits % 10));
            }
            else if (count === 1) {
                // One digit left over to read
                if (bits.available() < 4) {
                    throw new FormatException();
                }
                const digitBits = bits.readBits(4);
                if (digitBits >= 10) {
                    throw new FormatException();
                }
                result.append(DecodedBitStreamParser.toAlphaNumericChar(digitBits));
            }
        }
        static parseECIValue(bits) {
            const firstByte = bits.readBits(8);
            if ((firstByte & 0x80) === 0) {
                // just one byte
                return firstByte & 0x7f;
            }
            if ((firstByte & 0xc0) === 0x80) {
                // two bytes
                const secondByte = bits.readBits(8);
                return (((firstByte & 0x3f) << 8) & 0xffffffff) | secondByte;
            }
            if ((firstByte & 0xe0) === 0xc0) {
                // three bytes
                const secondThirdBytes = bits.readBits(16);
                return (((firstByte & 0x1f) << 16) & 0xffffffff) | secondThirdBytes;
            }
            throw new FormatException();
        }
    }
    /**
     * See ISO 18004:2006, 6.4.4 Table 5
     */
    DecodedBitStreamParser.ALPHANUMERIC_CHARS = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ $%*+-./:";
    DecodedBitStreamParser.GB2312_SUBSET = 1;

    /*
     * Copyright 2007 ZXing authors
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *      http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */
    /*import java.util.Map;*/
    /**
     * <p>The main class which implements QR Code decoding -- as opposed to locating and extracting
     * the QR Code from an image.</p>
     *
     * @author Sean Owen
     */
    class Decoder {
        constructor() {
            this.rsDecoder = new ReedSolomonDecoder(GenericGF.QR_CODE_FIELD_256);
        }
        // public decode(image: boolean[][]): DecoderResult /*throws ChecksumException, FormatException*/ {
        //   return decode(image, null)
        // }
        /**
         * <p>Convenience method that can decode a QR Code represented as a 2D array of booleans.
         * "true" is taken to mean a black module.</p>
         *
         * @param image booleans representing white/black QR Code modules
         * @param hints decoding hints that should be used to influence decoding
         * @return text and bytes encoded within the QR Code
         * @throws FormatException if the QR Code cannot be decoded
         * @throws ChecksumException if error correction fails
         */
        decodeBooleanArray(image, hints) {
            return this.decodeBitMatrix(BitMatrix.parseFromBooleanArray(image), hints);
        }
        // public decodeBitMatrix(bits: BitMatrix): DecoderResult /*throws ChecksumException, FormatException*/ {
        //   return decode(bits, null)
        // }
        /**
         * <p>Decodes a QR Code represented as a {@link BitMatrix}. A 1 or "true" is taken to mean a black module.</p>
         *
         * @param bits booleans representing white/black QR Code modules
         * @param hints decoding hints that should be used to influence decoding
         * @return text and bytes encoded within the QR Code
         * @throws FormatException if the QR Code cannot be decoded
         * @throws ChecksumException if error correction fails
         */
        decodeBitMatrix(bits, hints = new Map()) {
            // Construct a parser and read version, error-correction level
            const parser = new BitMatrixParser(bits);
            let ex = null;
            try {
                return this.decodeBitMatrixParser(parser, hints);
            }
            catch (e /*: FormatException, ChecksumException*/) {
                ex = e;
            }
            try {
                // Revert the bit matrix
                parser.remask();
                // Will be attempting a mirrored reading of the version and format info.
                parser.setMirror(true);
                // Preemptively read the version.
                parser.readVersion();
                // Preemptively read the format information.
                parser.readFormatInformation();
                /*
                 * Since we're here, this means we have successfully detected some kind
                 * of version and format information when mirrored. This is a good sign,
                 * that the QR code may be mirrored, and we should try once more with a
                 * mirrored content.
                 */
                // Prepare for a mirrored reading.
                parser.mirror();
                const result = this.decodeBitMatrixParser(parser, hints);
                // Success! Notify the caller that the code was mirrored.
                result.setOther(new QRCodeDecoderMetaData(true));
                return result;
            }
            catch (e /*FormatException | ChecksumException*/) {
                // Throw the exception from the original reading
                if (ex !== null) {
                    throw ex;
                }
                throw e;
            }
        }
        decodeBitMatrixParser(parser, hints) {
            const version = parser.readVersion();
            const ecLevel = parser.readFormatInformation().getErrorCorrectionLevel();
            // Read codewords
            const codewords = parser.readCodewords();
            // Separate into data blocks
            const dataBlocks = DataBlock.getDataBlocks(codewords, version, ecLevel);
            // Count total number of data bytes
            let totalBytes = 0;
            for (const dataBlock of dataBlocks) {
                totalBytes += dataBlock.getNumDataCodewords();
            }
            const resultBytes = new Uint8Array(totalBytes);
            let resultOffset = 0;
            // Error-correct and copy data blocks together into a stream of bytes
            for (const dataBlock of dataBlocks) {
                const codewordBytes = dataBlock.getCodewords();
                const numDataCodewords = dataBlock.getNumDataCodewords();
                this.correctErrors(codewordBytes, numDataCodewords);
                for (let i = 0; i < numDataCodewords; i++) {
                    resultBytes[resultOffset++] = codewordBytes[i];
                }
            }
            // Decode the contents of that stream of bytes
            return DecodedBitStreamParser.decode(resultBytes, version, ecLevel, hints);
        }
        /**
         * <p>Given data and error-correction codewords received, possibly corrupted by errors, attempts to
         * correct the errors in-place using Reed-Solomon error correction.</p>
         *
         * @param codewordBytes data and error correction codewords
         * @param numDataCodewords number of codewords that are data bytes
         * @throws ChecksumException if error correction fails
         */
        correctErrors(codewordBytes, numDataCodewords /*int*/) {
            codewordBytes.length;
            // First read into an array of ints
            const codewordsInts = new Int32Array(codewordBytes);
            // TYPESCRIPTPORT: not realy necessary to transform to ints? could redesign everything to work with unsigned bytes?
            // const codewordsInts = new Int32Array(numCodewords)
            // for (let i = 0; i < numCodewords; i++) {
            //   codewordsInts[i] = codewordBytes[i] & 0xFF
            // }
            try {
                this.rsDecoder.decode(codewordsInts, codewordBytes.length - numDataCodewords);
            }
            catch (ignored /*: ReedSolomonException*/) {
                throw new ChecksumException();
            }
            // Copy back into array of bytes -- only need to worry about the bytes that were data
            // We don't care about errors in the error-correction codewords
            for (let i = 0; i < numDataCodewords; i++) {
                codewordBytes[i] = /*(byte) */ codewordsInts[i];
            }
        }
    }

    /*
     * Copyright 2007 ZXing authors
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *      http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */
    /**
     * <p>Encapsulates a finder pattern, which are the three square patterns found in
     * the corners of QR Codes. It also encapsulates a count of similar finder patterns,
     * as a convenience to the finder's bookkeeping.</p>
     *
     * @author Sean Owen
     */
    class FinderPattern extends ResultPoint {
        // FinderPattern(posX: number/*float*/, posY: number/*float*/, estimatedModuleSize: number/*float*/) {
        //   this(posX, posY, estimatedModuleSize, 1)
        // }
        constructor(posX /*float*/, posY /*float*/, estimatedModuleSize /*float*/, count = 1 /*int*/) {
            super(posX, posY);
            this.estimatedModuleSize = estimatedModuleSize;
            this.count = count;
        }
        getEstimatedModuleSize() {
            return this.estimatedModuleSize;
        }
        getCount() {
            return this.count;
        }
        /*
          void incrementCount() {
            this.count++
          }
           */
        /**
         * <p>Determines if this finder pattern "about equals" a finder pattern at the stated
         * position and size -- meaning, it is at nearly the same center with nearly the same size.</p>
         */
        aboutEquals(moduleSize /*float*/, i /*float*/, j /*float*/) {
            if (Math.abs(i - this.getY()) <= moduleSize && Math.abs(j - this.getX()) <= moduleSize) {
                const moduleSizeDiff = Math.abs(moduleSize - this.estimatedModuleSize);
                return moduleSizeDiff <= 1.0 || moduleSizeDiff <= this.estimatedModuleSize;
            }
            return false;
        }
        /**
         * Combines this object's current estimate of a finder pattern position and module size
         * with a new estimate. It returns a new {@code FinderPattern} containing a weighted average
         * based on count.
         */
        combineEstimate(i /*float*/, j /*float*/, newModuleSize /*float*/) {
            const combinedCount = this.count + 1;
            const combinedX = (this.count * this.getX() + j) / combinedCount;
            const combinedY = (this.count * this.getY() + i) / combinedCount;
            const combinedModuleSize = (this.count * this.estimatedModuleSize + newModuleSize) / combinedCount;
            return new FinderPattern(combinedX, combinedY, combinedModuleSize, combinedCount);
        }
    }

    /*
     * Copyright 2007 ZXing authors
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *      http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */
    /**
     * <p>Encapsulates information about finder patterns in an image, including the location of
     * the three finder patterns, and their estimated module size.</p>
     *
     * @author Sean Owen
     */
    class FinderPatternInfo {
        constructor(patternCenters) {
            this.bottomLeft = patternCenters[0];
            this.topLeft = patternCenters[1];
            this.topRight = patternCenters[2];
        }
        getBottomLeft() {
            return this.bottomLeft;
        }
        getTopLeft() {
            return this.topLeft;
        }
        getTopRight() {
            return this.topRight;
        }
    }

    /*
     * Copyright 2007 ZXing authors
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *      http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */
    /*import java.io.Serializable;*/
    /*import java.util.ArrayList;*/
    /*import java.util.Collections;*/
    /*import java.util.Comparator;*/
    /*import java.util.List;*/
    /*import java.util.Map;*/
    /**
     * <p>This class attempts to find finder patterns in a QR Code. Finder patterns are the square
     * markers at three corners of a QR Code.</p>
     *
     * <p>This class is thread-safe but not reentrant. Each thread must allocate its own object.
     *
     * @author Sean Owen
     */
    class FinderPatternFinder {
        /**
         * <p>Creates a finder that will search the image for three finder patterns.</p>
         *
         * @param image image to search
         */
        // public constructor(image: BitMatrix) {
        //   this(image, null)
        // }
        constructor(image, resultPointCallback) {
            this.image = image;
            this.resultPointCallback = resultPointCallback;
            this.hasSkipped = false;
            this.possibleCenters = [];
            this.crossCheckStateCount = new Int32Array(5);
            this.resultPointCallback = resultPointCallback;
        }
        getImage() {
            return this.image;
        }
        getPossibleCenters() {
            return this.possibleCenters;
        }
        find(hints) {
            const tryHarder = hints !== null && hints !== undefined && undefined !== hints.get(DecodeHintType.TRY_HARDER);
            const pureBarcode = hints !== null && hints !== undefined && undefined !== hints.get(DecodeHintType.PURE_BARCODE);
            const image = this.image;
            const maxI = image.getHeight();
            const maxJ = image.getWidth();
            // We are looking for black/white/black/white/black modules in
            // 1:1:3:1:1 ratio; this tracks the number of such modules seen so far
            // Let's assume that the maximum version QR Code we support takes up 1/4 the height of the
            // image, and then account for the center being 3 modules in size. This gives the smallest
            // number of pixels the center could be, so skip this often. When trying harder, look for all
            // QR versions regardless of how dense they are.
            let iSkip = Math.floor((3 * maxI) / (4 * FinderPatternFinder.MAX_MODULES));
            if (iSkip < FinderPatternFinder.MIN_SKIP || tryHarder) {
                iSkip = FinderPatternFinder.MIN_SKIP;
            }
            let done = false;
            const stateCount = new Int32Array(5);
            for (let i = iSkip - 1; i < maxI && !done; i += iSkip) {
                // Get a row of black/white values
                stateCount[0] = 0;
                stateCount[1] = 0;
                stateCount[2] = 0;
                stateCount[3] = 0;
                stateCount[4] = 0;
                let currentState = 0;
                for (let j = 0; j < maxJ; j++) {
                    if (image.get(j, i)) {
                        // Black pixel
                        if ((currentState & 1) === 1) {
                            // Counting white pixels
                            currentState++;
                        }
                        stateCount[currentState]++;
                    }
                    else {
                        // White pixel
                        if ((currentState & 1) === 0) {
                            // Counting black pixels
                            if (currentState === 4) {
                                // A winner?
                                if (FinderPatternFinder.foundPatternCross(stateCount)) {
                                    // Yes
                                    const confirmed = this.handlePossibleCenter(stateCount, i, j, pureBarcode);
                                    if (confirmed === true) {
                                        // Start examining every other line. Checking each line turned out to be too
                                        // expensive and didn't improve performance.
                                        iSkip = 2;
                                        if (this.hasSkipped === true) {
                                            done = this.haveMultiplyConfirmedCenters();
                                        }
                                        else {
                                            const rowSkip = this.findRowSkip();
                                            if (rowSkip > stateCount[2]) {
                                                // Skip rows between row of lower confirmed center
                                                // and top of presumed third confirmed center
                                                // but back up a bit to get a full chance of detecting
                                                // it, entire width of center of finder pattern
                                                // Skip by rowSkip, but back off by stateCount[2] (size of last center
                                                // of pattern we saw) to be conservative, and also back off by iSkip which
                                                // is about to be re-added
                                                i += rowSkip - stateCount[2] - iSkip;
                                                j = maxJ - 1;
                                            }
                                        }
                                    }
                                    else {
                                        stateCount[0] = stateCount[2];
                                        stateCount[1] = stateCount[3];
                                        stateCount[2] = stateCount[4];
                                        stateCount[3] = 1;
                                        stateCount[4] = 0;
                                        currentState = 3;
                                        continue;
                                    }
                                    // Clear state to start looking again
                                    currentState = 0;
                                    stateCount[0] = 0;
                                    stateCount[1] = 0;
                                    stateCount[2] = 0;
                                    stateCount[3] = 0;
                                    stateCount[4] = 0;
                                }
                                else {
                                    // No, shift counts back by two
                                    stateCount[0] = stateCount[2];
                                    stateCount[1] = stateCount[3];
                                    stateCount[2] = stateCount[4];
                                    stateCount[3] = 1;
                                    stateCount[4] = 0;
                                    currentState = 3;
                                }
                            }
                            else {
                                stateCount[++currentState]++;
                            }
                        }
                        else {
                            // Counting white pixels
                            stateCount[currentState]++;
                        }
                    }
                }
                if (FinderPatternFinder.foundPatternCross(stateCount)) {
                    const confirmed = this.handlePossibleCenter(stateCount, i, maxJ, pureBarcode);
                    if (confirmed === true) {
                        iSkip = stateCount[0];
                        if (this.hasSkipped) {
                            // Found a third one
                            done = this.haveMultiplyConfirmedCenters();
                        }
                    }
                }
            }
            const patternInfo = this.selectBestPatterns();
            ResultPoint.orderBestPatterns(patternInfo);
            return new FinderPatternInfo(patternInfo);
        }
        /**
         * Given a count of black/white/black/white/black pixels just seen and an end position,
         * figures the location of the center of this run.
         */
        static centerFromEnd(stateCount, end /*int*/) {
            return end - stateCount[4] - stateCount[3] - stateCount[2] / 2.0;
        }
        /**
         * @param stateCount count of black/white/black/white/black pixels just read
         * @return true iff the proportions of the counts is close enough to the 1/1/3/1/1 ratios
         *         used by finder patterns to be considered a match
         */
        static foundPatternCross(stateCount) {
            let totalModuleSize = 0;
            for (let i = 0; i < 5; i++) {
                const count = stateCount[i];
                if (count === 0) {
                    return false;
                }
                totalModuleSize += count;
            }
            if (totalModuleSize < 7) {
                return false;
            }
            const moduleSize = totalModuleSize / 7.0;
            const maxVariance = moduleSize / 2.0;
            // Allow less than 50% variance from 1-1-3-1-1 proportions
            return (Math.abs(moduleSize - stateCount[0]) < maxVariance &&
                Math.abs(moduleSize - stateCount[1]) < maxVariance &&
                Math.abs(3.0 * moduleSize - stateCount[2]) < 3 * maxVariance &&
                Math.abs(moduleSize - stateCount[3]) < maxVariance &&
                Math.abs(moduleSize - stateCount[4]) < maxVariance);
        }
        getCrossCheckStateCount() {
            const crossCheckStateCount = this.crossCheckStateCount;
            crossCheckStateCount[0] = 0;
            crossCheckStateCount[1] = 0;
            crossCheckStateCount[2] = 0;
            crossCheckStateCount[3] = 0;
            crossCheckStateCount[4] = 0;
            return crossCheckStateCount;
        }
        /**
         * After a vertical and horizontal scan finds a potential finder pattern, this method
         * "cross-cross-cross-checks" by scanning down diagonally through the center of the possible
         * finder pattern to see if the same proportion is detected.
         *
         * @param startI row where a finder pattern was detected
         * @param centerJ center of the section that appears to cross a finder pattern
         * @param maxCount maximum reasonable number of modules that should be
         *  observed in any reading state, based on the results of the horizontal scan
         * @param originalStateCountTotal The original state count total.
         * @return true if proportions are withing expected limits
         */
        crossCheckDiagonal(startI /*int*/, centerJ /*int*/, maxCount /*int*/, originalStateCountTotal /*int*/) {
            const stateCount = this.getCrossCheckStateCount();
            // Start counting up, left from center finding black center mass
            let i = 0;
            const image = this.image;
            while (startI >= i && centerJ >= i && image.get(centerJ - i, startI - i)) {
                stateCount[2]++;
                i++;
            }
            if (startI < i || centerJ < i) {
                return false;
            }
            // Continue up, left finding white space
            while (startI >= i &&
                centerJ >= i &&
                !image.get(centerJ - i, startI - i) &&
                stateCount[1] <= maxCount) {
                stateCount[1]++;
                i++;
            }
            // If already too many modules in this state or ran off the edge:
            if (startI < i || centerJ < i || stateCount[1] > maxCount) {
                return false;
            }
            // Continue up, left finding black border
            while (startI >= i &&
                centerJ >= i &&
                image.get(centerJ - i, startI - i) &&
                stateCount[0] <= maxCount) {
                stateCount[0]++;
                i++;
            }
            if (stateCount[0] > maxCount) {
                return false;
            }
            const maxI = image.getHeight();
            const maxJ = image.getWidth();
            // Now also count down, right from center
            i = 1;
            while (startI + i < maxI && centerJ + i < maxJ && image.get(centerJ + i, startI + i)) {
                stateCount[2]++;
                i++;
            }
            // Ran off the edge?
            if (startI + i >= maxI || centerJ + i >= maxJ) {
                return false;
            }
            while (startI + i < maxI &&
                centerJ + i < maxJ &&
                !image.get(centerJ + i, startI + i) &&
                stateCount[3] < maxCount) {
                stateCount[3]++;
                i++;
            }
            if (startI + i >= maxI || centerJ + i >= maxJ || stateCount[3] >= maxCount) {
                return false;
            }
            while (startI + i < maxI &&
                centerJ + i < maxJ &&
                image.get(centerJ + i, startI + i) &&
                stateCount[4] < maxCount) {
                stateCount[4]++;
                i++;
            }
            if (stateCount[4] >= maxCount) {
                return false;
            }
            // If we found a finder-pattern-like section, but its size is more than 100% different than
            // the original, assume it's a false positive
            const stateCountTotal = stateCount[0] + stateCount[1] + stateCount[2] + stateCount[3] + stateCount[4];
            return (Math.abs(stateCountTotal - originalStateCountTotal) < 2 * originalStateCountTotal &&
                FinderPatternFinder.foundPatternCross(stateCount));
        }
        /**
         * <p>After a horizontal scan finds a potential finder pattern, this method
         * "cross-checks" by scanning down vertically through the center of the possible
         * finder pattern to see if the same proportion is detected.</p>
         *
         * @param startI row where a finder pattern was detected
         * @param centerJ center of the section that appears to cross a finder pattern
         * @param maxCount maximum reasonable number of modules that should be
         * observed in any reading state, based on the results of the horizontal scan
         * @return vertical center of finder pattern, or {@link Float#NaN} if not found
         */
        crossCheckVertical(startI /*int*/, centerJ /*int*/, maxCount /*int*/, originalStateCountTotal /*int*/) {
            const image = this.image;
            const maxI = image.getHeight();
            const stateCount = this.getCrossCheckStateCount();
            // Start counting up from center
            let i = startI;
            while (i >= 0 && image.get(centerJ, i)) {
                stateCount[2]++;
                i--;
            }
            if (i < 0) {
                return NaN;
            }
            while (i >= 0 && !image.get(centerJ, i) && stateCount[1] <= maxCount) {
                stateCount[1]++;
                i--;
            }
            // If already too many modules in this state or ran off the edge:
            if (i < 0 || stateCount[1] > maxCount) {
                return NaN;
            }
            while (i >= 0 && image.get(centerJ, i) && stateCount[0] <= maxCount) {
                stateCount[0]++;
                i--;
            }
            if (stateCount[0] > maxCount) {
                return NaN;
            }
            // Now also count down from center
            i = startI + 1;
            while (i < maxI && image.get(centerJ, i)) {
                stateCount[2]++;
                i++;
            }
            if (i === maxI) {
                return NaN;
            }
            while (i < maxI && !image.get(centerJ, i) && stateCount[3] < maxCount) {
                stateCount[3]++;
                i++;
            }
            if (i === maxI || stateCount[3] >= maxCount) {
                return NaN;
            }
            while (i < maxI && image.get(centerJ, i) && stateCount[4] < maxCount) {
                stateCount[4]++;
                i++;
            }
            if (stateCount[4] >= maxCount) {
                return NaN;
            }
            // If we found a finder-pattern-like section, but its size is more than 40% different than
            // the original, assume it's a false positive
            const stateCountTotal = stateCount[0] + stateCount[1] + stateCount[2] + stateCount[3] + stateCount[4];
            if (5 * Math.abs(stateCountTotal - originalStateCountTotal) >= 2 * originalStateCountTotal) {
                return NaN;
            }
            return FinderPatternFinder.foundPatternCross(stateCount)
                ? FinderPatternFinder.centerFromEnd(stateCount, i)
                : NaN;
        }
        /**
         * <p>Like {@link #crossCheckVertical(int, int, int, int)}, and in fact is basically identical,
         * except it reads horizontally instead of vertically. This is used to cross-cross
         * check a vertical cross check and locate the real center of the alignment pattern.</p>
         */
        crossCheckHorizontal(startJ /*int*/, centerI /*int*/, maxCount /*int*/, originalStateCountTotal /*int*/) {
            const image = this.image;
            const maxJ = image.getWidth();
            const stateCount = this.getCrossCheckStateCount();
            let j = startJ;
            while (j >= 0 && image.get(j, centerI)) {
                stateCount[2]++;
                j--;
            }
            if (j < 0) {
                return NaN;
            }
            while (j >= 0 && !image.get(j, centerI) && stateCount[1] <= maxCount) {
                stateCount[1]++;
                j--;
            }
            if (j < 0 || stateCount[1] > maxCount) {
                return NaN;
            }
            while (j >= 0 && image.get(j, centerI) && stateCount[0] <= maxCount) {
                stateCount[0]++;
                j--;
            }
            if (stateCount[0] > maxCount) {
                return NaN;
            }
            j = startJ + 1;
            while (j < maxJ && image.get(j, centerI)) {
                stateCount[2]++;
                j++;
            }
            if (j === maxJ) {
                return NaN;
            }
            while (j < maxJ && !image.get(j, centerI) && stateCount[3] < maxCount) {
                stateCount[3]++;
                j++;
            }
            if (j === maxJ || stateCount[3] >= maxCount) {
                return NaN;
            }
            while (j < maxJ && image.get(j, centerI) && stateCount[4] < maxCount) {
                stateCount[4]++;
                j++;
            }
            if (stateCount[4] >= maxCount) {
                return NaN;
            }
            // If we found a finder-pattern-like section, but its size is significantly different than
            // the original, assume it's a false positive
            const stateCountTotal = stateCount[0] + stateCount[1] + stateCount[2] + stateCount[3] + stateCount[4];
            if (5 * Math.abs(stateCountTotal - originalStateCountTotal) >= originalStateCountTotal) {
                return NaN;
            }
            return FinderPatternFinder.foundPatternCross(stateCount)
                ? FinderPatternFinder.centerFromEnd(stateCount, j)
                : NaN;
        }
        /**
         * <p>This is called when a horizontal scan finds a possible alignment pattern. It will
         * cross check with a vertical scan, and if successful, will, ah, cross-cross-check
         * with another horizontal scan. This is needed primarily to locate the real horizontal
         * center of the pattern in cases of extreme skew.
         * And then we cross-cross-cross check with another diagonal scan.</p>
         *
         * <p>If that succeeds the finder pattern location is added to a list that tracks
         * the number of times each location has been nearly-matched as a finder pattern.
         * Each additional find is more evidence that the location is in fact a finder
         * pattern center
         *
         * @param stateCount reading state module counts from horizontal scan
         * @param i row where finder pattern may be found
         * @param j end of possible finder pattern in row
         * @param pureBarcode true if in "pure barcode" mode
         * @return true if a finder pattern candidate was found this time
         */
        handlePossibleCenter(stateCount, i /*int*/, j /*int*/, pureBarcode) {
            const stateCountTotal = stateCount[0] + stateCount[1] + stateCount[2] + stateCount[3] + stateCount[4];
            let centerJ = FinderPatternFinder.centerFromEnd(stateCount, j);
            let centerI = this.crossCheckVertical(i, 
            /*(int) */ Math.floor(centerJ), stateCount[2], stateCountTotal);
            if (!isNaN(centerI)) {
                // Re-cross check
                centerJ = this.crossCheckHorizontal(
                /*(int) */ Math.floor(centerJ), 
                /*(int) */ Math.floor(centerI), stateCount[2], stateCountTotal);
                if (!isNaN(centerJ) &&
                    (!pureBarcode ||
                        this.crossCheckDiagonal(
                        /*(int) */ Math.floor(centerI), 
                        /*(int) */ Math.floor(centerJ), stateCount[2], stateCountTotal))) {
                    const estimatedModuleSize = stateCountTotal / 7.0;
                    let found = false;
                    const possibleCenters = this.possibleCenters;
                    for (let index = 0, length = possibleCenters.length; index < length; index++) {
                        const center = possibleCenters[index];
                        // Look for about the same center and module size:
                        if (center.aboutEquals(estimatedModuleSize, centerI, centerJ)) {
                            possibleCenters[index] = center.combineEstimate(centerI, centerJ, estimatedModuleSize);
                            found = true;
                            break;
                        }
                    }
                    if (!found) {
                        const point = new FinderPattern(centerJ, centerI, estimatedModuleSize);
                        possibleCenters.push(point);
                        if (this.resultPointCallback !== null && this.resultPointCallback !== undefined) {
                            this.resultPointCallback.foundPossibleResultPoint(point);
                        }
                    }
                    return true;
                }
            }
            return false;
        }
        /**
         * @return number of rows we could safely skip during scanning, based on the first
         *         two finder patterns that have been located. In some cases their position will
         *         allow us to infer that the third pattern must lie below a certain point farther
         *         down in the image.
         */
        findRowSkip() {
            const max = this.possibleCenters.length;
            if (max <= 1) {
                return 0;
            }
            let firstConfirmedCenter = null;
            for (const center of this.possibleCenters) {
                if (center.getCount() >= FinderPatternFinder.CENTER_QUORUM) {
                    if (firstConfirmedCenter == null) {
                        firstConfirmedCenter = center;
                    }
                    else {
                        // We have two confirmed centers
                        // How far down can we skip before resuming looking for the next
                        // pattern? In the worst case, only the difference between the
                        // difference in the x / y coordinates of the two centers.
                        // This is the case where you find top left last.
                        this.hasSkipped = true;
                        return /*(int) */ Math.floor((Math.abs(firstConfirmedCenter.getX() - center.getX()) -
                            Math.abs(firstConfirmedCenter.getY() - center.getY())) /
                            2);
                    }
                }
            }
            return 0;
        }
        /**
         * @return true iff we have found at least 3 finder patterns that have been detected
         *         at least {@link #CENTER_QUORUM} times each, and, the estimated module size of the
         *         candidates is "pretty similar"
         */
        haveMultiplyConfirmedCenters() {
            let confirmedCount = 0;
            let totalModuleSize = 0.0;
            const max = this.possibleCenters.length;
            for (const pattern of this.possibleCenters) {
                if (pattern.getCount() >= FinderPatternFinder.CENTER_QUORUM) {
                    confirmedCount++;
                    totalModuleSize += pattern.getEstimatedModuleSize();
                }
            }
            if (confirmedCount < 3) {
                return false;
            }
            // OK, we have at least 3 confirmed centers, but, it's possible that one is a "false positive"
            // and that we need to keep looking. We detect this by asking if the estimated module sizes
            // vary too much. We arbitrarily say that when the total deviation from average exceeds
            // 5% of the total module size estimates, it's too much.
            const average = totalModuleSize / max;
            let totalDeviation = 0.0;
            for (const pattern of this.possibleCenters) {
                totalDeviation += Math.abs(pattern.getEstimatedModuleSize() - average);
            }
            return totalDeviation <= 0.05 * totalModuleSize;
        }
        /**
         * @return the 3 best {@link FinderPattern}s from our list of candidates. The "best" are
         *         those that have been detected at least {@link #CENTER_QUORUM} times, and whose module
         *         size differs from the average among those patterns the least
         * @throws NotFoundException if 3 such finder patterns do not exist
         */
        selectBestPatterns() {
            const startSize = this.possibleCenters.length;
            if (startSize < 3) {
                // Couldn't find enough finder patterns
                throw new NotFoundException();
            }
            const possibleCenters = this.possibleCenters;
            let average; /*float*/
            // Filter outlier possibilities whose module size is too different
            if (startSize > 3) {
                // But we can only afford to do so if we have at least 4 possibilities to choose from
                let totalModuleSize = 0.0;
                let square = 0.0;
                for (const center of this.possibleCenters) {
                    const size = center.getEstimatedModuleSize();
                    totalModuleSize += size;
                    square += size * size;
                }
                average = totalModuleSize / startSize;
                let stdDev = Math.sqrt(square / startSize - average * average);
                possibleCenters.sort(
                /**
                 * <p>Orders by furthest from average</p>
                 */
                // FurthestFromAverageComparator implements Comparator<FinderPattern>
                (center1, center2) => {
                    const dA = Math.abs(center2.getEstimatedModuleSize() - average);
                    const dB = Math.abs(center1.getEstimatedModuleSize() - average);
                    return dA < dB ? -1 : dA > dB ? 1 : 0;
                });
                const limit = Math.max(0.2 * average, stdDev);
                for (let i = 0; i < possibleCenters.length && possibleCenters.length > 3; i++) {
                    const pattern = possibleCenters[i];
                    if (Math.abs(pattern.getEstimatedModuleSize() - average) > limit) {
                        possibleCenters.splice(i, 1);
                        i--;
                    }
                }
            }
            if (possibleCenters.length > 3) {
                // Throw away all but those first size candidate points we found.
                let totalModuleSize = 0.0;
                for (const possibleCenter of possibleCenters) {
                    totalModuleSize += possibleCenter.getEstimatedModuleSize();
                }
                average = totalModuleSize / possibleCenters.length;
                possibleCenters.sort(
                /**
                 * <p>Orders by {@link FinderPattern#getCount()}, descending.</p>
                 */
                // CenterComparator implements Comparator<FinderPattern>
                (center1, center2) => {
                    if (center2.getCount() === center1.getCount()) {
                        const dA = Math.abs(center2.getEstimatedModuleSize() - average);
                        const dB = Math.abs(center1.getEstimatedModuleSize() - average);
                        return dA < dB ? 1 : dA > dB ? -1 : 0;
                    }
                    else {
                        return center2.getCount() - center1.getCount();
                    }
                });
                possibleCenters.splice(3); // this is not realy necessary as we only return first 3 anyway
            }
            return [possibleCenters[0], possibleCenters[1], possibleCenters[2]];
        }
    }
    FinderPatternFinder.CENTER_QUORUM = 2;
    FinderPatternFinder.MIN_SKIP = 3; // 1 pixel/module times 3 modules/center
    FinderPatternFinder.MAX_MODULES = 57; // support up to version 10 for mobile clients

    /*
     * Copyright 2007 ZXing authors
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *      http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */
    /**
     * <p>Encapsulates an alignment pattern, which are the smaller square patterns found in
     * all but the simplest QR Codes.</p>
     *
     * @author Sean Owen
     */
    class AlignmentPattern extends ResultPoint {
        constructor(posX /*float*/, posY /*float*/, estimatedModuleSize /*float*/) {
            super(posX, posY);
            this.estimatedModuleSize = estimatedModuleSize;
        }
        /**
         * <p>Determines if this alignment pattern "about equals" an alignment pattern at the stated
         * position and size -- meaning, it is at nearly the same center with nearly the same size.</p>
         */
        aboutEquals(moduleSize /*float*/, i /*float*/, j /*float*/) {
            if (Math.abs(i - this.getY()) <= moduleSize && Math.abs(j - this.getX()) <= moduleSize) {
                const moduleSizeDiff = Math.abs(moduleSize - this.estimatedModuleSize);
                return moduleSizeDiff <= 1.0 || moduleSizeDiff <= this.estimatedModuleSize;
            }
            return false;
        }
        /**
         * Combines this object's current estimate of a finder pattern position and module size
         * with a new estimate. It returns a new {@code FinderPattern} containing an average of the two.
         */
        combineEstimate(i /*float*/, j /*float*/, newModuleSize /*float*/) {
            const combinedX = (this.getX() + j) / 2.0;
            const combinedY = (this.getY() + i) / 2.0;
            const combinedModuleSize = (this.estimatedModuleSize + newModuleSize) / 2.0;
            return new AlignmentPattern(combinedX, combinedY, combinedModuleSize);
        }
    }

    /*
     * Copyright 2007 ZXing authors
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *      http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */
    /*import java.util.ArrayList;*/
    /*import java.util.List;*/
    /**
     * <p>This class attempts to find alignment patterns in a QR Code. Alignment patterns look like finder
     * patterns but are smaller and appear at regular intervals throughout the image.</p>
     *
     * <p>At the moment this only looks for the bottom-right alignment pattern.</p>
     *
     * <p>This is mostly a simplified copy of {@link FinderPatternFinder}. It is copied,
     * pasted and stripped down here for maximum performance but does unfortunately duplicate
     * some code.</p>
     *
     * <p>This class is thread-safe but not reentrant. Each thread must allocate its own object.</p>
     *
     * @author Sean Owen
     */
    class AlignmentPatternFinder {
        /**
         * <p>Creates a finder that will look in a portion of the whole image.</p>
         *
         * @param image image to search
         * @param startX left column from which to start searching
         * @param startY top row from which to start searching
         * @param width width of region to search
         * @param height height of region to search
         * @param moduleSize estimated module size so far
         */
        constructor(image, startX /*int*/, startY /*int*/, width /*int*/, height /*int*/, moduleSize /*float*/, resultPointCallback) {
            this.image = image;
            this.startX = startX;
            this.startY = startY;
            this.width = width;
            this.height = height;
            this.moduleSize = moduleSize;
            this.resultPointCallback = resultPointCallback;
            this.possibleCenters = []; // new Array<any>(5))
            // TYPESCRIPTPORT: array initialization without size as the length is checked below
            this.crossCheckStateCount = new Int32Array(3);
        }
        /**
         * <p>This method attempts to find the bottom-right alignment pattern in the image. It is a bit messy since
         * it's pretty performance-critical and so is written to be fast foremost.</p>
         *
         * @return {@link AlignmentPattern} if found
         * @throws NotFoundException if not found
         */
        find() {
            const startX = this.startX;
            const height = this.height;
            const width = this.width;
            const maxJ = startX + width;
            const middleI = this.startY + height / 2;
            // We are looking for black/white/black modules in 1:1:1 ratio
            // this tracks the number of black/white/black modules seen so far
            const stateCount = new Int32Array(3);
            const image = this.image;
            for (let iGen = 0; iGen < height; iGen++) {
                // Search from middle outwards
                const i = middleI + ((iGen & 0x01) === 0 ? Math.floor((iGen + 1) / 2) : -Math.floor((iGen + 1) / 2));
                stateCount[0] = 0;
                stateCount[1] = 0;
                stateCount[2] = 0;
                let j = startX;
                // Burn off leading white pixels before anything else; if we start in the middle of
                // a white run, it doesn't make sense to count its length, since we don't know if the
                // white run continued to the left of the start point
                while (j < maxJ && !image.get(j, i)) {
                    j++;
                }
                let currentState = 0;
                while (j < maxJ) {
                    if (image.get(j, i)) {
                        // Black pixel
                        if (currentState === 1) {
                            // Counting black pixels
                            stateCount[1]++;
                        }
                        else {
                            // Counting white pixels
                            if (currentState === 2) {
                                // A winner?
                                if (this.foundPatternCross(stateCount)) {
                                    // Yes
                                    const confirmed = this.handlePossibleCenter(stateCount, i, j);
                                    if (confirmed !== null) {
                                        return confirmed;
                                    }
                                }
                                stateCount[0] = stateCount[2];
                                stateCount[1] = 1;
                                stateCount[2] = 0;
                                currentState = 1;
                            }
                            else {
                                stateCount[++currentState]++;
                            }
                        }
                    }
                    else {
                        // White pixel
                        if (currentState === 1) {
                            // Counting black pixels
                            currentState++;
                        }
                        stateCount[currentState]++;
                    }
                    j++;
                }
                if (this.foundPatternCross(stateCount)) {
                    const confirmed = this.handlePossibleCenter(stateCount, i, maxJ);
                    if (confirmed !== null) {
                        return confirmed;
                    }
                }
            }
            // Hmm, nothing we saw was observed and confirmed twice. If we had
            // any guess at all, return it.
            if (this.possibleCenters.length !== 0) {
                return this.possibleCenters[0];
            }
            throw new NotFoundException();
        }
        /**
         * Given a count of black/white/black pixels just seen and an end position,
         * figures the location of the center of this black/white/black run.
         */
        static centerFromEnd(stateCount, end /*int*/) {
            return end - stateCount[2] - stateCount[1] / 2.0;
        }
        /**
         * @param stateCount count of black/white/black pixels just read
         * @return true iff the proportions of the counts is close enough to the 1/1/1 ratios
         *         used by alignment patterns to be considered a match
         */
        foundPatternCross(stateCount) {
            const moduleSize = this.moduleSize;
            const maxVariance = moduleSize / 2.0;
            for (let i = 0; i < 3; i++) {
                if (Math.abs(moduleSize - stateCount[i]) >= maxVariance) {
                    return false;
                }
            }
            return true;
        }
        /**
         * <p>After a horizontal scan finds a potential alignment pattern, this method
         * "cross-checks" by scanning down vertically through the center of the possible
         * alignment pattern to see if the same proportion is detected.</p>
         *
         * @param startI row where an alignment pattern was detected
         * @param centerJ center of the section that appears to cross an alignment pattern
         * @param maxCount maximum reasonable number of modules that should be
         * observed in any reading state, based on the results of the horizontal scan
         * @return vertical center of alignment pattern, or {@link Float#NaN} if not found
         */
        crossCheckVertical(startI /*int*/, centerJ /*int*/, maxCount /*int*/, originalStateCountTotal /*int*/) {
            const image = this.image;
            const maxI = image.getHeight();
            const stateCount = this.crossCheckStateCount;
            stateCount[0] = 0;
            stateCount[1] = 0;
            stateCount[2] = 0;
            // Start counting up from center
            let i = startI;
            while (i >= 0 && image.get(centerJ, i) && stateCount[1] <= maxCount) {
                stateCount[1]++;
                i--;
            }
            // If already too many modules in this state or ran off the edge:
            if (i < 0 || stateCount[1] > maxCount) {
                return NaN;
            }
            while (i >= 0 && !image.get(centerJ, i) && stateCount[0] <= maxCount) {
                stateCount[0]++;
                i--;
            }
            if (stateCount[0] > maxCount) {
                return NaN;
            }
            // Now also count down from center
            i = startI + 1;
            while (i < maxI && image.get(centerJ, i) && stateCount[1] <= maxCount) {
                stateCount[1]++;
                i++;
            }
            if (i === maxI || stateCount[1] > maxCount) {
                return NaN;
            }
            while (i < maxI && !image.get(centerJ, i) && stateCount[2] <= maxCount) {
                stateCount[2]++;
                i++;
            }
            if (stateCount[2] > maxCount) {
                return NaN;
            }
            const stateCountTotal = stateCount[0] + stateCount[1] + stateCount[2];
            if (5 * Math.abs(stateCountTotal - originalStateCountTotal) >= 2 * originalStateCountTotal) {
                return NaN;
            }
            return this.foundPatternCross(stateCount)
                ? AlignmentPatternFinder.centerFromEnd(stateCount, i)
                : NaN;
        }
        /**
         * <p>This is called when a horizontal scan finds a possible alignment pattern. It will
         * cross check with a vertical scan, and if successful, will see if this pattern had been
         * found on a previous horizontal scan. If so, we consider it confirmed and conclude we have
         * found the alignment pattern.</p>
         *
         * @param stateCount reading state module counts from horizontal scan
         * @param i row where alignment pattern may be found
         * @param j end of possible alignment pattern in row
         * @return {@link AlignmentPattern} if we have found the same pattern twice, or null if not
         */
        handlePossibleCenter(stateCount, i /*int*/, j /*int*/) {
            const stateCountTotal = stateCount[0] + stateCount[1] + stateCount[2];
            const centerJ = AlignmentPatternFinder.centerFromEnd(stateCount, j);
            const centerI = this.crossCheckVertical(i, 
            /*(int) */ centerJ, 2 * stateCount[1], stateCountTotal);
            if (!isNaN(centerI)) {
                const estimatedModuleSize = (stateCount[0] + stateCount[1] + stateCount[2]) / 3.0;
                for (const center of this.possibleCenters) {
                    // Look for about the same center and module size:
                    if (center.aboutEquals(estimatedModuleSize, centerI, centerJ)) {
                        return center.combineEstimate(centerI, centerJ, estimatedModuleSize);
                    }
                }
                // Hadn't found this before; save it
                const point = new AlignmentPattern(centerJ, centerI, estimatedModuleSize);
                this.possibleCenters.push(point);
                if (this.resultPointCallback !== null && this.resultPointCallback !== undefined) {
                    this.resultPointCallback.foundPossibleResultPoint(point);
                }
            }
            return null;
        }
    }

    /*
     * Copyright 2007 ZXing authors
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *      http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */
    /*import java.util.Map;*/
    /**
     * <p>Encapsulates logic that can detect a QR Code in an image, even if the QR Code
     * is rotated or skewed, or partially obscured.</p>
     *
     * @author Sean Owen
     */
    class Detector {
        constructor(image) {
            this.image = image;
        }
        getImage() {
            return this.image;
        }
        getResultPointCallback() {
            return this.resultPointCallback;
        }
        /**
         * <p>Detects a QR Code in an image.</p>
         *
         * @return {@link DetectorResult} encapsulating results of detecting a QR Code
         * @throws NotFoundException if QR Code cannot be found
         * @throws FormatException if a QR Code cannot be decoded
         */
        // public detect(): DetectorResult /*throws NotFoundException, FormatException*/ {
        //   return detect(null)
        // }
        /**
         * <p>Detects a QR Code in an image.</p>
         *
         * @param hints optional hints to detector
         * @return {@link DetectorResult} encapsulating results of detecting a QR Code
         * @throws NotFoundException if QR Code cannot be found
         * @throws FormatException if a QR Code cannot be decoded
         */
        detect(hints) {
            this.resultPointCallback =
                hints === null || hints === undefined
                    ? null
                    : /*(ResultPointCallback) */ hints.get(DecodeHintType.NEED_RESULT_POINT_CALLBACK);
            const finder = new FinderPatternFinder(this.image, this.resultPointCallback);
            const info = finder.find(hints);
            return this.processFinderPatternInfo(info);
        }
        processFinderPatternInfo(info) {
            const topLeft = info.getTopLeft();
            const topRight = info.getTopRight();
            const bottomLeft = info.getBottomLeft();
            const moduleSize = this.calculateModuleSize(topLeft, topRight, bottomLeft);
            if (moduleSize < 1.0) {
                throw new NotFoundException("No pattern found in proccess finder.");
            }
            const dimension = Detector.computeDimension(topLeft, topRight, bottomLeft, moduleSize);
            const provisionalVersion = Version$1.getProvisionalVersionForDimension(dimension);
            const modulesBetweenFPCenters = provisionalVersion.getDimensionForVersion() - 7;
            let alignmentPattern = null;
            // Anything above version 1 has an alignment pattern
            if (provisionalVersion.getAlignmentPatternCenters().length > 0) {
                // Guess where a "bottom right" finder pattern would have been
                const bottomRightX = topRight.getX() - topLeft.getX() + bottomLeft.getX();
                const bottomRightY = topRight.getY() - topLeft.getY() + bottomLeft.getY();
                // Estimate that alignment pattern is closer by 3 modules
                // from "bottom right" to known top left location
                const correctionToTopLeft = 1.0 - 3.0 / modulesBetweenFPCenters;
                const estAlignmentX = /*(int) */ Math.floor(topLeft.getX() + correctionToTopLeft * (bottomRightX - topLeft.getX()));
                const estAlignmentY = /*(int) */ Math.floor(topLeft.getY() + correctionToTopLeft * (bottomRightY - topLeft.getY()));
                // Kind of arbitrary -- expand search radius before giving up
                for (let i = 4; i <= 16; i <<= 1) {
                    try {
                        alignmentPattern = this.findAlignmentInRegion(moduleSize, estAlignmentX, estAlignmentY, i);
                        break;
                    }
                    catch (re /*NotFoundException*/) {
                        if (!(re instanceof NotFoundException)) {
                            throw re;
                        }
                        // try next round
                    }
                }
                // If we didn't find alignment pattern... well try anyway without it
            }
            const transform = Detector.createTransform(topLeft, topRight, bottomLeft, alignmentPattern, dimension);
            const bits = Detector.sampleGrid(this.image, transform, dimension);
            let points;
            if (alignmentPattern === null) {
                points = [bottomLeft, topLeft, topRight];
            }
            else {
                points = [bottomLeft, topLeft, topRight, alignmentPattern];
            }
            return new DetectorResult(bits, points);
        }
        static createTransform(topLeft, topRight, bottomLeft, alignmentPattern, dimension /*int*/) {
            const dimMinusThree = dimension - 3.5;
            let bottomRightX; /*float*/
            let bottomRightY; /*float*/
            let sourceBottomRightX; /*float*/
            let sourceBottomRightY; /*float*/
            if (alignmentPattern !== null) {
                bottomRightX = alignmentPattern.getX();
                bottomRightY = alignmentPattern.getY();
                sourceBottomRightX = dimMinusThree - 3.0;
                sourceBottomRightY = sourceBottomRightX;
            }
            else {
                // Don't have an alignment pattern, just make up the bottom-right point
                bottomRightX = topRight.getX() - topLeft.getX() + bottomLeft.getX();
                bottomRightY = topRight.getY() - topLeft.getY() + bottomLeft.getY();
                sourceBottomRightX = dimMinusThree;
                sourceBottomRightY = dimMinusThree;
            }
            return PerspectiveTransform.quadrilateralToQuadrilateral(3.5, 3.5, dimMinusThree, 3.5, sourceBottomRightX, sourceBottomRightY, 3.5, dimMinusThree, topLeft.getX(), topLeft.getY(), topRight.getX(), topRight.getY(), bottomRightX, bottomRightY, bottomLeft.getX(), bottomLeft.getY());
        }
        static sampleGrid(image, transform, dimension /*int*/) {
            const sampler = GridSamplerInstance.getInstance();
            return sampler.sampleGridWithTransform(image, dimension, dimension, transform);
        }
        /**
         * <p>Computes the dimension (number of modules on a size) of the QR Code based on the position
         * of the finder patterns and estimated module size.</p>
         */
        static computeDimension(topLeft, topRight, bottomLeft, moduleSize /*float*/) {
            const tltrCentersDimension = MathUtils.round(ResultPoint.distance(topLeft, topRight) / moduleSize);
            const tlblCentersDimension = MathUtils.round(ResultPoint.distance(topLeft, bottomLeft) / moduleSize);
            let dimension = Math.floor((tltrCentersDimension + tlblCentersDimension) / 2) + 7;
            switch (dimension & 0x03 // mod 4
            ) {
                case 0:
                    dimension++;
                    break;
                // 1? do nothing
                case 2:
                    dimension--;
                    break;
                case 3:
                    throw new NotFoundException("Dimensions could be not found.");
            }
            return dimension;
        }
        /**
         * <p>Computes an average estimated module size based on estimated derived from the positions
         * of the three finder patterns.</p>
         *
         * @param topLeft detected top-left finder pattern center
         * @param topRight detected top-right finder pattern center
         * @param bottomLeft detected bottom-left finder pattern center
         * @return estimated module size
         */
        calculateModuleSize(topLeft, topRight, bottomLeft) {
            // Take the average
            return ((this.calculateModuleSizeOneWay(topLeft, topRight) +
                this.calculateModuleSizeOneWay(topLeft, bottomLeft)) /
                2.0);
        }
        /**
         * <p>Estimates module size based on two finder patterns -- it uses
         * {@link #sizeOfBlackWhiteBlackRunBothWays(int, int, int, int)} to figure the
         * width of each, measuring along the axis between their centers.</p>
         */
        calculateModuleSizeOneWay(pattern, otherPattern) {
            const moduleSizeEst1 = this.sizeOfBlackWhiteBlackRunBothWays(
            /*(int) */ Math.floor(pattern.getX()), 
            /*(int) */ Math.floor(pattern.getY()), 
            /*(int) */ Math.floor(otherPattern.getX()), 
            /*(int) */ Math.floor(otherPattern.getY()));
            const moduleSizeEst2 = this.sizeOfBlackWhiteBlackRunBothWays(
            /*(int) */ Math.floor(otherPattern.getX()), 
            /*(int) */ Math.floor(otherPattern.getY()), 
            /*(int) */ Math.floor(pattern.getX()), 
            /*(int) */ Math.floor(pattern.getY()));
            if (isNaN(moduleSizeEst1)) {
                return moduleSizeEst2 / 7.0;
            }
            if (isNaN(moduleSizeEst2)) {
                return moduleSizeEst1 / 7.0;
            }
            // Average them, and divide by 7 since we've counted the width of 3 black modules,
            // and 1 white and 1 black module on either side. Ergo, divide sum by 14.
            return (moduleSizeEst1 + moduleSizeEst2) / 14.0;
        }
        /**
         * See {@link #sizeOfBlackWhiteBlackRun(int, int, int, int)}; computes the total width of
         * a finder pattern by looking for a black-white-black run from the center in the direction
         * of another point (another finder pattern center), and in the opposite direction too.
         */
        sizeOfBlackWhiteBlackRunBothWays(fromX /*int*/, fromY /*int*/, toX /*int*/, toY /*int*/) {
            let result = this.sizeOfBlackWhiteBlackRun(fromX, fromY, toX, toY);
            // Now count other way -- don't run off image though of course
            let scale = 1.0;
            let otherToX = fromX - (toX - fromX);
            if (otherToX < 0) {
                scale = fromX / /*(float) */ (fromX - otherToX);
                otherToX = 0;
            }
            else if (otherToX >= this.image.getWidth()) {
                scale = (this.image.getWidth() - 1 - fromX) / /*(float) */ (otherToX - fromX);
                otherToX = this.image.getWidth() - 1;
            }
            let otherToY = /*(int) */ Math.floor(fromY - (toY - fromY) * scale);
            scale = 1.0;
            if (otherToY < 0) {
                scale = fromY / /*(float) */ (fromY - otherToY);
                otherToY = 0;
            }
            else if (otherToY >= this.image.getHeight()) {
                scale = (this.image.getHeight() - 1 - fromY) / /*(float) */ (otherToY - fromY);
                otherToY = this.image.getHeight() - 1;
            }
            otherToX = /*(int) */ Math.floor(fromX + (otherToX - fromX) * scale);
            result += this.sizeOfBlackWhiteBlackRun(fromX, fromY, otherToX, otherToY);
            // Middle pixel is double-counted this way; subtract 1
            return result - 1.0;
        }
        /**
         * <p>This method traces a line from a point in the image, in the direction towards another point.
         * It begins in a black region, and keeps going until it finds white, then black, then white again.
         * It reports the distance from the start to this point.</p>
         *
         * <p>This is used when figuring out how wide a finder pattern is, when the finder pattern
         * may be skewed or rotated.</p>
         */
        sizeOfBlackWhiteBlackRun(fromX /*int*/, fromY /*int*/, toX /*int*/, toY /*int*/) {
            // Mild variant of Bresenham's algorithm
            // see http://en.wikipedia.org/wiki/Bresenham's_line_algorithm
            const steep = Math.abs(toY - fromY) > Math.abs(toX - fromX);
            if (steep) {
                let temp = fromX;
                fromX = fromY;
                fromY = temp;
                temp = toX;
                toX = toY;
                toY = temp;
            }
            const dx = Math.abs(toX - fromX);
            const dy = Math.abs(toY - fromY);
            let error = -dx / 2;
            const xstep = fromX < toX ? 1 : -1;
            const ystep = fromY < toY ? 1 : -1;
            // In black pixels, looking for white, first or second time.
            let state = 0;
            // Loop up until x == toX, but not beyond
            const xLimit = toX + xstep;
            for (let x = fromX, y = fromY; x !== xLimit; x += xstep) {
                const realX = steep ? y : x;
                const realY = steep ? x : y;
                // Does current pixel mean we have moved white to black or vice versa?
                // Scanning black in state 0,2 and white in state 1, so if we find the wrong
                // color, advance to next state or end if we are in state 2 already
                if ((state === 1) === this.image.get(realX, realY)) {
                    if (state === 2) {
                        return MathUtils.distance(x, y, fromX, fromY);
                    }
                    state++;
                }
                error += dy;
                if (error > 0) {
                    if (y === toY) {
                        break;
                    }
                    y += ystep;
                    error -= dx;
                }
            }
            // Found black-white-black; give the benefit of the doubt that the next pixel outside the image
            // is "white" so this last point at (toX+xStep,toY) is the right ending. This is really a
            // small approximation; (toX+xStep,toY+yStep) might be really correct. Ignore this.
            if (state === 2) {
                return MathUtils.distance(toX + xstep, toY, fromX, fromY);
            }
            // else we didn't find even black-white-black; no estimate is really possible
            return NaN;
        }
        /**
         * <p>Attempts to locate an alignment pattern in a limited region of the image, which is
         * guessed to contain it. This method uses {@link AlignmentPattern}.</p>
         *
         * @param overallEstModuleSize estimated module size so far
         * @param estAlignmentX x coordinate of center of area probably containing alignment pattern
         * @param estAlignmentY y coordinate of above
         * @param allowanceFactor number of pixels in all directions to search from the center
         * @return {@link AlignmentPattern} if found, or null otherwise
         * @throws NotFoundException if an unexpected error occurs during detection
         */
        findAlignmentInRegion(overallEstModuleSize /*float*/, estAlignmentX /*int*/, estAlignmentY /*int*/, allowanceFactor /*float*/) {
            // Look for an alignment pattern (3 modules in size) around where it
            // should be
            const allowance = /*(int) */ Math.floor(allowanceFactor * overallEstModuleSize);
            const alignmentAreaLeftX = Math.max(0, estAlignmentX - allowance);
            const alignmentAreaRightX = Math.min(this.image.getWidth() - 1, estAlignmentX + allowance);
            if (alignmentAreaRightX - alignmentAreaLeftX < overallEstModuleSize * 3) {
                throw new NotFoundException("Alignment top exceeds estimated module size.");
            }
            const alignmentAreaTopY = Math.max(0, estAlignmentY - allowance);
            const alignmentAreaBottomY = Math.min(this.image.getHeight() - 1, estAlignmentY + allowance);
            if (alignmentAreaBottomY - alignmentAreaTopY < overallEstModuleSize * 3) {
                throw new NotFoundException("Alignment bottom exceeds estimated module size.");
            }
            const alignmentFinder = new AlignmentPatternFinder(this.image, alignmentAreaLeftX, alignmentAreaTopY, alignmentAreaRightX - alignmentAreaLeftX, alignmentAreaBottomY - alignmentAreaTopY, overallEstModuleSize, this.resultPointCallback);
            return alignmentFinder.find();
        }
    }

    /*
     * Copyright 2007 ZXing authors
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *      http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */
    /*import java.util.List;*/
    /*import java.util.Map;*/
    /**
     * This implementation can detect and decode QR Codes in an image.
     *
     * @author Sean Owen
     */
    class QRCodeReader {
        constructor() {
            this.decoder = new Decoder();
        }
        getDecoder() {
            return this.decoder;
        }
        /**
         * Locates and decodes a QR code in an image.
         *
         * @return a representing: string the content encoded by the QR code
         * @throws NotFoundException if a QR code cannot be found
         * @throws FormatException if a QR code cannot be decoded
         * @throws ChecksumException if error correction fails
         */
        /*@Override*/
        // public decode(image: BinaryBitmap): Result /*throws NotFoundException, ChecksumException, FormatException */ {
        //   return this.decode(image, null)
        // }
        /*@Override*/
        decode(image, hints = new Map()) {
            let decoderResult;
            let points;
            if (hints !== undefined &&
                hints !== null &&
                undefined !== hints.get(DecodeHintType.PURE_BARCODE)) {
                const bits = QRCodeReader.extractPureBits(image.getBlackMatrix());
                decoderResult = this.decoder.decodeBitMatrix(bits, hints);
                points = QRCodeReader.NO_POINTS;
            }
            else {
                const detectorResult = new Detector(image.getBlackMatrix()).detect(hints);
                decoderResult = this.decoder.decodeBitMatrix(detectorResult.getBits(), hints);
                points = detectorResult.getPoints();
            }
            // If the code was mirrored: swap the bottom-left and the top-right points.
            if (decoderResult.getOther() instanceof QRCodeDecoderMetaData) {
                decoderResult.getOther().applyMirroredCorrection(points);
            }
            const result = new Result(decoderResult.getText(), decoderResult.getRawBytes(), undefined, points, BarcodeFormat.QR_CODE, undefined);
            const byteSegments = decoderResult.getByteSegments();
            if (byteSegments !== null) {
                result.putMetadata(ResultMetadataType.BYTE_SEGMENTS, byteSegments);
            }
            const ecLevel = decoderResult.getECLevel();
            if (ecLevel !== null) {
                result.putMetadata(ResultMetadataType.ERROR_CORRECTION_LEVEL, ecLevel);
            }
            if (decoderResult.hasStructuredAppend()) {
                result.putMetadata(ResultMetadataType.STRUCTURED_APPEND_SEQUENCE, decoderResult.getStructuredAppendSequenceNumber());
                result.putMetadata(ResultMetadataType.STRUCTURED_APPEND_PARITY, decoderResult.getStructuredAppendParity());
            }
            return result;
        }
        /*@Override*/
        reset() {
            // do nothing
        }
        /**
         * This method detects a code in a "pure" image -- that is, pure monochrome image
         * which contains only an unrotated, unskewed, image of a code, with some white border
         * around it. This is a specialized method that works exceptionally fast in this special
         * case.
         *
         * @see com.google.zxing.datamatrix.DataMatrixReader#extractPureBits(BitMatrix)
         */
        static extractPureBits(image) {
            const leftTopBlack = image.getTopLeftOnBit();
            const rightBottomBlack = image.getBottomRightOnBit();
            if (leftTopBlack === null || rightBottomBlack === null) {
                throw new NotFoundException();
            }
            const moduleSize = this.moduleSize(leftTopBlack, image);
            let top = leftTopBlack[1];
            let bottom = rightBottomBlack[1];
            let left = leftTopBlack[0];
            let right = rightBottomBlack[0];
            // Sanity check!
            if (left >= right || top >= bottom) {
                throw new NotFoundException();
            }
            if (bottom - top !== right - left) {
                // Special case, where bottom-right module wasn't black so we found something else in the last row
                // Assume it's a square, so use height as the width
                right = left + (bottom - top);
                if (right >= image.getWidth()) {
                    // Abort if that would not make sense -- off image
                    throw new NotFoundException();
                }
            }
            const matrixWidth = Math.round((right - left + 1) / moduleSize);
            const matrixHeight = Math.round((bottom - top + 1) / moduleSize);
            if (matrixWidth <= 0 || matrixHeight <= 0) {
                throw new NotFoundException();
            }
            if (matrixHeight !== matrixWidth) {
                // Only possibly decode square regions
                throw new NotFoundException();
            }
            // Push in the "border" by half the module width so that we start
            // sampling in the middle of the module. Just in case the image is a
            // little off, this will help recover.
            const nudge = /*(int) */ Math.floor(moduleSize / 2.0);
            top += nudge;
            left += nudge;
            // But careful that this does not sample off the edge
            // "right" is the farthest-right valid pixel location -- right+1 is not necessarily
            // This is positive by how much the inner x loop below would be too large
            const nudgedTooFarRight = left + /*(int) */ Math.floor((matrixWidth - 1) * moduleSize) - right;
            if (nudgedTooFarRight > 0) {
                if (nudgedTooFarRight > nudge) {
                    // Neither way fits; abort
                    throw new NotFoundException();
                }
                left -= nudgedTooFarRight;
            }
            // See logic above
            const nudgedTooFarDown = top + /*(int) */ Math.floor((matrixHeight - 1) * moduleSize) - bottom;
            if (nudgedTooFarDown > 0) {
                if (nudgedTooFarDown > nudge) {
                    // Neither way fits; abort
                    throw new NotFoundException();
                }
                top -= nudgedTooFarDown;
            }
            // Now just read off the bits
            const bits = new BitMatrix(matrixWidth, matrixHeight);
            for (let y = 0; y < matrixHeight; y++) {
                const iOffset = top + /*(int) */ Math.floor(y * moduleSize);
                for (let x = 0; x < matrixWidth; x++) {
                    if (image.get(left + /*(int) */ Math.floor(x * moduleSize), iOffset)) {
                        bits.set(x, y);
                    }
                }
            }
            return bits;
        }
        static moduleSize(leftTopBlack, image) {
            const height = image.getHeight();
            const width = image.getWidth();
            let x = leftTopBlack[0];
            let y = leftTopBlack[1];
            let inBlack = true;
            let transitions = 0;
            while (x < width && y < height) {
                if (inBlack !== image.get(x, y)) {
                    if (++transitions === 5) {
                        break;
                    }
                    inBlack = !inBlack;
                }
                x++;
                y++;
            }
            if (x === width || y === height) {
                throw new NotFoundException();
            }
            return (x - leftTopBlack[0]) / 7.0;
        }
    }
    QRCodeReader.NO_POINTS = new Array();

    /*
     * Copyright 2007 ZXing authors
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *      http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */
    /**
     * <p>Encapsulates a set of error-correction blocks in one symbol version. Most versions will
     * use blocks of differing sizes within one version, so, this encapsulates the parameters for
     * each set of blocks. It also holds the number of error-correction codewords per block since it
     * will be the same across all blocks within one version.</p>
     */
    class ECBlocks {
        constructor(ecCodewords, ecBlocks1, ecBlocks2) {
            this.ecCodewords = ecCodewords;
            this.ecBlocks = [ecBlocks1];
            ecBlocks2 && this.ecBlocks.push(ecBlocks2);
        }
        getECCodewords() {
            return this.ecCodewords;
        }
        getECBlocks() {
            return this.ecBlocks;
        }
    }
    /**
     * <p>Encapsulates the parameters for one error-correction block in one symbol version.
     * This includes the number of data codewords, and the number of times a block with these
     * parameters is used consecutively in the Data Matrix code version's format.</p>
     */
    class ECB {
        constructor(count, dataCodewords) {
            this.count = count;
            this.dataCodewords = dataCodewords;
        }
        getCount() {
            return this.count;
        }
        getDataCodewords() {
            return this.dataCodewords;
        }
    }
    /**
     * The Version object encapsulates attributes about a particular
     * size Data Matrix Code.
     *
     * @author bbrown@google.com (Brian Brown)
     */
    class Version {
        constructor(versionNumber, symbolSizeRows, symbolSizeColumns, dataRegionSizeRows, dataRegionSizeColumns, ecBlocks) {
            this.versionNumber = versionNumber;
            this.symbolSizeRows = symbolSizeRows;
            this.symbolSizeColumns = symbolSizeColumns;
            this.dataRegionSizeRows = dataRegionSizeRows;
            this.dataRegionSizeColumns = dataRegionSizeColumns;
            this.ecBlocks = ecBlocks;
            // Calculate the total number of codewords
            let total = 0;
            const ecCodewords = ecBlocks.getECCodewords();
            const ecbArray = ecBlocks.getECBlocks();
            for (let ecBlock of ecbArray) {
                total += ecBlock.getCount() * (ecBlock.getDataCodewords() + ecCodewords);
            }
            this.totalCodewords = total;
        }
        getVersionNumber() {
            return this.versionNumber;
        }
        getSymbolSizeRows() {
            return this.symbolSizeRows;
        }
        getSymbolSizeColumns() {
            return this.symbolSizeColumns;
        }
        getDataRegionSizeRows() {
            return this.dataRegionSizeRows;
        }
        getDataRegionSizeColumns() {
            return this.dataRegionSizeColumns;
        }
        getTotalCodewords() {
            return this.totalCodewords;
        }
        getECBlocks() {
            return this.ecBlocks;
        }
        /**
         * <p>Deduces version information from Data Matrix dimensions.</p>
         *
         * @param numRows Number of rows in modules
         * @param numColumns Number of columns in modules
         * @return Version for a Data Matrix Code of those dimensions
         * @throws FormatException if dimensions do correspond to a valid Data Matrix size
         */
        static getVersionForDimensions(numRows, numColumns) {
            if ((numRows & 0x01) !== 0 || (numColumns & 0x01) !== 0) {
                throw new FormatException();
            }
            for (let version of Version.VERSIONS) {
                if (version.symbolSizeRows === numRows && version.symbolSizeColumns === numColumns) {
                    return version;
                }
            }
            throw new FormatException();
        }
        //  @Override
        toString() {
            return "" + this.versionNumber;
        }
        /**
         * See ISO 16022:2006 5.5.1 Table 7
         */
        static buildVersions() {
            return [
                new Version(1, 10, 10, 8, 8, new ECBlocks(5, new ECB(1, 3))),
                new Version(2, 12, 12, 10, 10, new ECBlocks(7, new ECB(1, 5))),
                new Version(3, 14, 14, 12, 12, new ECBlocks(10, new ECB(1, 8))),
                new Version(4, 16, 16, 14, 14, new ECBlocks(12, new ECB(1, 12))),
                new Version(5, 18, 18, 16, 16, new ECBlocks(14, new ECB(1, 18))),
                new Version(6, 20, 20, 18, 18, new ECBlocks(18, new ECB(1, 22))),
                new Version(7, 22, 22, 20, 20, new ECBlocks(20, new ECB(1, 30))),
                new Version(8, 24, 24, 22, 22, new ECBlocks(24, new ECB(1, 36))),
                new Version(9, 26, 26, 24, 24, new ECBlocks(28, new ECB(1, 44))),
                new Version(10, 32, 32, 14, 14, new ECBlocks(36, new ECB(1, 62))),
                new Version(11, 36, 36, 16, 16, new ECBlocks(42, new ECB(1, 86))),
                new Version(12, 40, 40, 18, 18, new ECBlocks(48, new ECB(1, 114))),
                new Version(13, 44, 44, 20, 20, new ECBlocks(56, new ECB(1, 144))),
                new Version(14, 48, 48, 22, 22, new ECBlocks(68, new ECB(1, 174))),
                new Version(15, 52, 52, 24, 24, new ECBlocks(42, new ECB(2, 102))),
                new Version(16, 64, 64, 14, 14, new ECBlocks(56, new ECB(2, 140))),
                new Version(17, 72, 72, 16, 16, new ECBlocks(36, new ECB(4, 92))),
                new Version(18, 80, 80, 18, 18, new ECBlocks(48, new ECB(4, 114))),
                new Version(19, 88, 88, 20, 20, new ECBlocks(56, new ECB(4, 144))),
                new Version(20, 96, 96, 22, 22, new ECBlocks(68, new ECB(4, 174))),
                new Version(21, 104, 104, 24, 24, new ECBlocks(56, new ECB(6, 136))),
                new Version(22, 120, 120, 18, 18, new ECBlocks(68, new ECB(6, 175))),
                new Version(23, 132, 132, 20, 20, new ECBlocks(62, new ECB(8, 163))),
                new Version(24, 144, 144, 22, 22, new ECBlocks(62, new ECB(8, 156), new ECB(2, 155))),
                new Version(25, 8, 18, 6, 16, new ECBlocks(7, new ECB(1, 5))),
                new Version(26, 8, 32, 6, 14, new ECBlocks(11, new ECB(1, 10))),
                new Version(27, 12, 26, 10, 24, new ECBlocks(14, new ECB(1, 16))),
                new Version(28, 12, 36, 10, 16, new ECBlocks(18, new ECB(1, 22))),
                new Version(29, 16, 36, 14, 16, new ECBlocks(24, new ECB(1, 32))),
                new Version(30, 16, 48, 14, 22, new ECBlocks(28, new ECB(1, 49))),
            ];
        }
    }
    Version.VERSIONS = Version.buildVersions();

    /*
     * Copyright 2008 ZXing authors
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *      http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */
    var Mode;
    (function (Mode) {
        Mode[Mode["PAD_ENCODE"] = 0] = "PAD_ENCODE";
        Mode[Mode["ASCII_ENCODE"] = 1] = "ASCII_ENCODE";
        Mode[Mode["C40_ENCODE"] = 2] = "C40_ENCODE";
        Mode[Mode["TEXT_ENCODE"] = 3] = "TEXT_ENCODE";
        Mode[Mode["ANSIX12_ENCODE"] = 4] = "ANSIX12_ENCODE";
        Mode[Mode["EDIFACT_ENCODE"] = 5] = "EDIFACT_ENCODE";
        Mode[Mode["BASE256_ENCODE"] = 6] = "BASE256_ENCODE";
    })(Mode || (Mode = {}));

    /*
     * Copyright 2008 ZXing authors
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *      http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */
    Array.from([
        Int32Array.from([1, 1, 1, 1, 1, 1, 1]),
        Int32Array.from([1, 0, 0, 0, 0, 0, 1]),
        Int32Array.from([1, 0, 1, 1, 1, 0, 1]),
        Int32Array.from([1, 0, 1, 1, 1, 0, 1]),
        Int32Array.from([1, 0, 1, 1, 1, 0, 1]),
        Int32Array.from([1, 0, 0, 0, 0, 0, 1]),
        Int32Array.from([1, 1, 1, 1, 1, 1, 1]),
    ]);
    Array.from([
        Int32Array.from([1, 1, 1, 1, 1]),
        Int32Array.from([1, 0, 0, 0, 1]),
        Int32Array.from([1, 0, 1, 0, 1]),
        Int32Array.from([1, 0, 0, 0, 1]),
        Int32Array.from([1, 1, 1, 1, 1]),
    ]);
    // From Appendix E. Table 1, JIS0510X:2004 (71: p). The table was double-checked by komatsu.
    Array.from([
        Int32Array.from([-1, -1, -1, -1, -1, -1, -1]),
        Int32Array.from([6, 18, -1, -1, -1, -1, -1]),
        Int32Array.from([6, 22, -1, -1, -1, -1, -1]),
        Int32Array.from([6, 26, -1, -1, -1, -1, -1]),
        Int32Array.from([6, 30, -1, -1, -1, -1, -1]),
        Int32Array.from([6, 34, -1, -1, -1, -1, -1]),
        Int32Array.from([6, 22, 38, -1, -1, -1, -1]),
        Int32Array.from([6, 24, 42, -1, -1, -1, -1]),
        Int32Array.from([6, 26, 46, -1, -1, -1, -1]),
        Int32Array.from([6, 28, 50, -1, -1, -1, -1]),
        Int32Array.from([6, 30, 54, -1, -1, -1, -1]),
        Int32Array.from([6, 32, 58, -1, -1, -1, -1]),
        Int32Array.from([6, 34, 62, -1, -1, -1, -1]),
        Int32Array.from([6, 26, 46, 66, -1, -1, -1]),
        Int32Array.from([6, 26, 48, 70, -1, -1, -1]),
        Int32Array.from([6, 26, 50, 74, -1, -1, -1]),
        Int32Array.from([6, 30, 54, 78, -1, -1, -1]),
        Int32Array.from([6, 30, 56, 82, -1, -1, -1]),
        Int32Array.from([6, 30, 58, 86, -1, -1, -1]),
        Int32Array.from([6, 34, 62, 90, -1, -1, -1]),
        Int32Array.from([6, 28, 50, 72, 94, -1, -1]),
        Int32Array.from([6, 26, 50, 74, 98, -1, -1]),
        Int32Array.from([6, 30, 54, 78, 102, -1, -1]),
        Int32Array.from([6, 28, 54, 80, 106, -1, -1]),
        Int32Array.from([6, 32, 58, 84, 110, -1, -1]),
        Int32Array.from([6, 30, 58, 86, 114, -1, -1]),
        Int32Array.from([6, 34, 62, 90, 118, -1, -1]),
        Int32Array.from([6, 26, 50, 74, 98, 122, -1]),
        Int32Array.from([6, 30, 54, 78, 102, 126, -1]),
        Int32Array.from([6, 26, 52, 78, 104, 130, -1]),
        Int32Array.from([6, 30, 56, 82, 108, 134, -1]),
        Int32Array.from([6, 34, 60, 86, 112, 138, -1]),
        Int32Array.from([6, 30, 58, 86, 114, 142, -1]),
        Int32Array.from([6, 34, 62, 90, 118, 146, -1]),
        Int32Array.from([6, 30, 54, 78, 102, 126, 150]),
        Int32Array.from([6, 24, 50, 76, 102, 128, 154]),
        Int32Array.from([6, 28, 54, 80, 106, 132, 158]),
        Int32Array.from([6, 32, 58, 84, 110, 136, 162]),
        Int32Array.from([6, 26, 54, 82, 110, 138, 166]),
        Int32Array.from([6, 30, 58, 86, 114, 142, 170]),
    ]);
    // Type info cells at the left top corner.
    Array.from([
        Int32Array.from([8, 0]),
        Int32Array.from([8, 1]),
        Int32Array.from([8, 2]),
        Int32Array.from([8, 3]),
        Int32Array.from([8, 4]),
        Int32Array.from([8, 5]),
        Int32Array.from([8, 7]),
        Int32Array.from([8, 8]),
        Int32Array.from([7, 8]),
        Int32Array.from([5, 8]),
        Int32Array.from([4, 8]),
        Int32Array.from([3, 8]),
        Int32Array.from([2, 8]),
        Int32Array.from([1, 8]),
        Int32Array.from([0, 8]),
    ]);

    /*
     * Copyright 2008 ZXing authors
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *      http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */
    CharacterSetECI.UTF8.getName(); // "ISO-8859-1"

    /*
     * Copyright 2009 ZXing authors
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *      http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */
    /**
     * This object extends LuminanceSource around an array of YUV data returned from the camera driver,
     * with the option to crop to a rectangle within the full data. This can be used to exclude
     * superfluous pixels around the perimeter and speed up decoding.
     *
     * It works for any pixel format where the Y channel is planar and appears first, including
     * YCbCr_420_SP and YCbCr_422_SP.
     *
     * @author dswitkin@google.com (Daniel Switkin)
     */
    class PlanarYUVLuminanceSource extends LuminanceSource {
        constructor(yuvData, dataWidth /*int*/, dataHeight /*int*/, left /*int*/, top /*int*/, width /*int*/, height /*int*/, reverseHorizontal) {
            super(width, height);
            this.yuvData = yuvData;
            this.dataWidth = dataWidth;
            this.dataHeight = dataHeight;
            this.left = left;
            this.top = top;
            if (left + width > dataWidth || top + height > dataHeight) {
                throw new IllegalArgumentException("Crop rectangle does not fit within image data.");
            }
            if (reverseHorizontal) {
                this.reverseHorizontal(width, height);
            }
        }
        /*@Override*/
        getRow(y /*int*/, row) {
            if (y < 0 || y >= this.getHeight()) {
                throw new IllegalArgumentException("Requested row is outside the image: " + y);
            }
            const width = this.getWidth();
            if (row === null || row === undefined || row.length < width) {
                row = new Uint8ClampedArray(width);
            }
            const offset = (y + this.top) * this.dataWidth + this.left;
            System.arraycopy(this.yuvData, offset, row, 0, width);
            return row;
        }
        /*@Override*/
        getMatrix() {
            const width = this.getWidth();
            const height = this.getHeight();
            // If the caller asks for the entire underlying image, save the copy and give them the
            // original data. The docs specifically warn that result.length must be ignored.
            if (width === this.dataWidth && height === this.dataHeight) {
                return this.yuvData;
            }
            const area = width * height;
            const matrix = new Uint8ClampedArray(area);
            let inputOffset = this.top * this.dataWidth + this.left;
            // If the width matches the full width of the underlying data, perform a single copy.
            if (width === this.dataWidth) {
                System.arraycopy(this.yuvData, inputOffset, matrix, 0, area);
                return matrix;
            }
            // Otherwise copy one cropped row at a time.
            for (let y = 0; y < height; y++) {
                const outputOffset = y * width;
                System.arraycopy(this.yuvData, inputOffset, matrix, outputOffset, width);
                inputOffset += this.dataWidth;
            }
            return matrix;
        }
        /*@Override*/
        isCropSupported() {
            return true;
        }
        /*@Override*/
        crop(left /*int*/, top /*int*/, width /*int*/, height /*int*/) {
            return new PlanarYUVLuminanceSource(this.yuvData, this.dataWidth, this.dataHeight, this.left + left, this.top + top, width, height, false);
        }
        renderThumbnail() {
            const width = this.getWidth() / PlanarYUVLuminanceSource.THUMBNAIL_SCALE_FACTOR;
            const height = this.getHeight() / PlanarYUVLuminanceSource.THUMBNAIL_SCALE_FACTOR;
            const pixels = new Int32Array(width * height);
            const yuv = this.yuvData;
            let inputOffset = this.top * this.dataWidth + this.left;
            for (let y = 0; y < height; y++) {
                const outputOffset = y * width;
                for (let x = 0; x < width; x++) {
                    const grey = yuv[inputOffset + x * PlanarYUVLuminanceSource.THUMBNAIL_SCALE_FACTOR] & 0xff;
                    pixels[outputOffset + x] = 0xff000000 | (grey * 0x00010101);
                }
                inputOffset += this.dataWidth * PlanarYUVLuminanceSource.THUMBNAIL_SCALE_FACTOR;
            }
            return pixels;
        }
        /**
         * @return width of image from {@link #renderThumbnail()}
         */
        getThumbnailWidth() {
            return this.getWidth() / PlanarYUVLuminanceSource.THUMBNAIL_SCALE_FACTOR;
        }
        /**
         * @return height of image from {@link #renderThumbnail()}
         */
        getThumbnailHeight() {
            return this.getHeight() / PlanarYUVLuminanceSource.THUMBNAIL_SCALE_FACTOR;
        }
        reverseHorizontal(width /*int*/, height /*int*/) {
            const yuvData = this.yuvData;
            for (let y = 0, rowStart = this.top * this.dataWidth + this.left; y < height; y++, rowStart += this.dataWidth) {
                const middle = rowStart + width / 2;
                for (let x1 = rowStart, x2 = rowStart + width - 1; x1 < middle; x1++, x2--) {
                    const temp = yuvData[x1];
                    yuvData[x1] = yuvData[x2];
                    yuvData[x2] = temp;
                }
            }
        }
        invert() {
            return new InvertedLuminanceSource(this);
        }
    }
    PlanarYUVLuminanceSource.THUMBNAIL_SCALE_FACTOR = 2;

    /// <reference lib="dom"/>
    // import { Canvas, Image } from "canvas-webworker";
    class ImageDataLuminanceSource extends LuminanceSource {
        // private tempCanvasElement?: Canvas;
        constructor(imageData) {
            super(imageData.width, imageData.height);
            this.imageData = imageData;
            this.buffer = ImageDataLuminanceSource.makeBufferFromImageData(imageData);
        }
        static makeBufferFromImageData(imageData) {
            return ImageDataLuminanceSource.toGrayscaleBuffer(imageData.data, imageData.width, imageData.height);
        }
        static toGrayscaleBuffer(imageBuffer, width, height) {
            const grayscaleBuffer = new Uint8ClampedArray(width * height);
            for (let i = 0, j = 0, length = imageBuffer.length; i < length; i += 4, j++) {
                let gray;
                const alpha = imageBuffer[i + 3];
                // The color of fully-transparent pixels is irrelevant. They are often, technically, fully-transparent
                // black (0 alpha, and then 0 RGB). They are often used, of course as the "white" area in a
                // barcode image. Force any such pixel to be white:
                if (alpha === 0) {
                    gray = 0xff;
                }
                else {
                    const pixelR = imageBuffer[i];
                    const pixelG = imageBuffer[i + 1];
                    const pixelB = imageBuffer[i + 2];
                    // .299R + 0.587G + 0.114B (YUV/YIQ for PAL and NTSC),
                    // (306*R) >> 10 is approximately equal to R*0.299, and so on.
                    // 0x200 >> 10 is 0.5, it implements rounding.
                    gray = (306 * pixelR + 601 * pixelG + 117 * pixelB + 0x200) >> 10;
                }
                grayscaleBuffer[j] = gray;
            }
            return grayscaleBuffer;
        }
        getMatrix() {
            return this.buffer;
        }
        getRow(y /*int*/, row) {
            if (y < 0 || y >= this.getHeight()) {
                throw new IllegalArgumentException("Requested row is outside the image: " + y);
            }
            const width = this.getWidth();
            const start = y * width;
            if (row === null) {
                row = this.buffer.slice(start, start + width);
            }
            else {
                if (row.length < width) {
                    row = new Uint8ClampedArray(width);
                }
                // The underlying raster of image consists of bytes with the luminance values
                // TODO: can avoid set/slice?
                row.set(this.buffer.slice(start, start + width));
            }
            return row;
        }
        invert() {
            return new InvertedLuminanceSource(this);
        }
    }
    ImageDataLuminanceSource.DEGREE_TO_RADIANS = Math.PI / 180;

    /**
     * @deprecated Moving to @zxing/browser
     *
     * Base class for browser code reader.
     */
    class QRCodeDecoder {
        constructor(hints) {
            this.hints = hints;
            this.reader = new QRCodeReader();
        }
        decode(imageData) {
            const luminanceSource = new ImageDataLuminanceSource(imageData);
            const binaryBitmap = new BinaryBitmap(new HybridBinarizer(luminanceSource));
            return this.readerDecode(binaryBitmap);
        }
        readerDecode(binaryBitmap) {
            return this.reader.decode(binaryBitmap, this.hints);
        }
    }

    transferHandlers.set("ImageData", {
        deserialize: (data) => data,
    });
    class QRCodeDecoderWorker {
        constructor() {
            this.qrcodedecoder = new QRCodeDecoder();
        }
        decode(imageData) {
            const formatedResult = {
                text: "",
                resultPoints: [],
            };
            try {
                const result = this.qrcodedecoder.decode(imageData);
                formatedResult.text = result.getText();
                formatedResult.format = result.getBarcodeFormat();
                formatedResult.resultPoints = result.getResultPoints().map((point) => {
                    return {
                        x: point.getX(),
                        y: point.getY(),
                        size: point.estimatedModuleSize,
                    };
                });
            }
            catch (err) {
                console.warn("QRCodeDecoderWorker decode fail:", err);
            }
            return formatedResult;
        }
    }
    const qrcodeDecoderWorker = new QRCodeDecoderWorker();
    expose(qrcodeDecoderWorker);

    exports.QRCodeDecoderWorker = QRCodeDecoderWorker;

    Object.defineProperty(exports, '__esModule', { value: true });

    return exports;

})({});
