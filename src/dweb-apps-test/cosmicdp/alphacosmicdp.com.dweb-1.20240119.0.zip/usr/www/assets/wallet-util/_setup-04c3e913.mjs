import{p as a}from"./sha256-3121f6d0.mjs";const p=async()=>{await a.prepare()};export{p};
