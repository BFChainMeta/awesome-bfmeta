import * as dntShim from "../../../../../_dnt.shims.js";
import { X_PLAOC_QUERY } from "../../common/const.js";
import { createSignal } from "../../helper/createSignal.js";
import { buildRequest } from "../../helper/request.js";
class BasePlugin {
    constructor(mmid) {
        Object.defineProperty(this, "mmid", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: mmid
        });
        Object.defineProperty(this, "createSignal", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: createSignal
        });
    }
    fetchApi(url, init) {
        return this.buildApiRequest(url, init).fetch();
    }
    buildApiRequest(pathname, init) {
        const url = new URL(init?.base ?? BasePlugin.api_url);
        url.pathname = `${init?.pathPrefix ?? this.mmid}${pathname}`;
        return buildRequest(url, init);
    }
    /**
     * 获取指定的url
     * @param urlType
     * @returns
     */
    static getUrl(urlType) {
        const url = this.urlData.get(urlType) || localStorage.getItem("url:" + urlType);
        if (url === null) {
            console.error(`unconfig url: ${urlType}`);
            return "";
        }
        localStorage.setItem("url:" + urlType, url);
        return url;
    }
}
Object.defineProperty(BasePlugin, "urlData", {
    enumerable: true,
    configurable: true,
    writable: true,
    value: new URLSearchParams(location.search)
});
Object.defineProperty(BasePlugin, "api_url", {
    enumerable: true,
    configurable: true,
    writable: true,
    value: location.origin.replace("//www", "//api")
});
Object.defineProperty(BasePlugin, "external_url", {
    enumerable: true,
    configurable: true,
    writable: true,
    value: BasePlugin.getUrl(X_PLAOC_QUERY.EXTERNAL_URL)
});
export { BasePlugin };
if (typeof HTMLElement !== "function") {
    Object.assign(dntShim.dntGlobalThis, { HTMLElement: class HTMLElement {
        }, customElements: { define: () => { } } });
}
