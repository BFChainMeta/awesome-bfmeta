/**
 * 在调用.then或者.catch的时候才会执行启动函数
 */
const THEN_SYMBOL = Symbol("then");
const CATCH_SYMBOL = Symbol("catch");
export class DelayPromise {
    constructor(executor) {
        Object.defineProperty(this, "promise", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        let _resolve;
        let _reject;
        const promise = new Promise((resolve, reject) => {
            _resolve = resolve;
            _reject = reject;
        });
        this.promise = Object.assign(promise, {
            [THEN_SYMBOL]: promise.then,
            [CATCH_SYMBOL]: promise.catch,
        });
        let is_runed = false;
        const run_executor = () => {
            if (!is_runed) {
                executor(_resolve, _reject);
                is_runed = true;
            }
        };
        promise.then = (onfulfilled, onrejected) => {
            run_executor();
            return this.delayThen(onfulfilled, onrejected);
        };
        promise.catch = (onrejected) => {
            run_executor();
            return this.delayCatch(onrejected);
        };
    }
    delayThen(onfulfilled, onrejected) {
        return this.promise[THEN_SYMBOL](onfulfilled, onrejected);
    }
    delayCatch(onrejected) {
        return this.promise[CATCH_SYMBOL](onrejected);
    }
    /// 直接暴露出then、与catch，可以直接await
    get then() {
        return this.promise.then;
    }
    get catch() {
        return this.promise.catch;
    }
}
Object.defineProperty(DelayPromise, "THEN_SYMBOL", {
    enumerable: true,
    configurable: true,
    writable: true,
    value: THEN_SYMBOL
});
Object.defineProperty(DelayPromise, "CATCH_SYMBOL", {
    enumerable: true,
    configurable: true,
    writable: true,
    value: CATCH_SYMBOL
});
