import {
  d as b,
  v as k,
  y as g,
  a0 as v,
  j as I,
  r as B,
  B as D,
  D as w,
  f as s,
  F as c,
  J as y,
  E as S,
  I as d,
  V as m,
} from "./index-367d22e2.js";
import { S as x } from "./index-ee9d7309.js";
import { _ as N } from "./index.vue_vue_type_script_setup_true_lang-d7754eca.js";
import { _ as i } from "./index.vue_vue_type_script_setup_true_lang-32f2ca7b.js";
import { C as U } from "./data-7f4000cb.js";
import { s as $ } from "./function-call-e762d9f1.js";
import { B as F } from "./index-0f5c28c4.js";
import "./index-e4ec3b15.js";
import "./arrows_left-58dc349e.js";
const T = { class: "page_container" },
  V = { class: "my-2 mx-2 rounded-md overflow-hidden" },
  E = { class: "mx-2 mb-2 rounded-md overflow-hidden" },
  J = { class: "mx-2 rounded-md" },
  G = b({
    __name: "index",
    setup(O) {
      const { t: u } = k(),
        n = g(),
        o = v(),
        f = I(
          () =>
            o.storeBlackList.findIndex((e) => {
              var a;
              return (
                e.userID ===
                ((a = o.storeUserCardData.baseInfo) == null ? void 0 : a.userID)
              );
            }) > -1
        ),
        l = B(!1),
        p = (e) => {
          var t;
          (l.value = !0),
            d[e ? "addBlack" : "removeBlack"](
              (t = o.storeUserCardData.baseInfo) == null ? void 0 : t.userID
            )
              .catch((r) => m({ error: r }))
              .finally(() => (l.value = !1));
        },
        h = () => {
          n.push({
            path: "changeNameOrRemark",
            query: { friendInfo: JSON.stringify(o.storeUserCardData.baseInfo) },
          });
        },
        _ = () => {
          n.push({
            path: "chooseUser",
            state: {
              chooseType: U.ShareCard,
              extraData: JSON.stringify(o.storeUserCardData.baseInfo),
            },
          });
        },
        C = () => {
          $({
            message: u("messageTip.unfriend"),
            beforeClose: (e) =>
              new Promise((a) => {
                var t;
                e === "confirm"
                  ? d
                      .deleteFriend(
                        (t = o.storeUserCardData.baseInfo) == null
                          ? void 0
                          : t.userID
                      )
                      .then(() => n.back())
                      .catch((r) => m({ error: r }))
                      .finally(() => a(!0))
                  : a(!0);
              }),
          });
        };
      return (e, a) => {
        const t = x,
          r = F;
        return (
          D(),
          w("div", T, [
            s(N, { title: e.$t("friendSettings") }, null, 8, ["title"]),
            c("div", V, [
              s(
                i,
                { lable: e.$t("setNickname"), arrow: "", onClick: h },
                null,
                8,
                ["lable"]
              ),
              s(
                i,
                { lable: e.$t("shareFriend"), arrow: "", onClick: _ },
                null,
                8,
                ["lable"]
              ),
            ]),
            c("div", E, [
              s(
                i,
                { lable: e.$t("checks.addToBlack"), arrow: "" },
                {
                  default: y(() => [
                    s(
                      t,
                      {
                        size: "20",
                        loading: l.value,
                        "model-value": S(f),
                        "onUpdate:modelValue": p,
                      },
                      null,
                      8,
                      ["loading", "model-value"]
                    ),
                  ]),
                  _: 1,
                },
                8,
                ["lable"]
              ),
            ]),
            c("div", J, [
              s(
                r,
                {
                  class: "w-full !text-error-text !border-0 !text-base",
                  plain: "",
                  type: "default",
                  text: e.$t("unfriend"),
                  onClick: C,
                },
                null,
                8,
                ["text"]
              ),
            ]),
          ])
        );
      };
    },
  });
export { G as default };
