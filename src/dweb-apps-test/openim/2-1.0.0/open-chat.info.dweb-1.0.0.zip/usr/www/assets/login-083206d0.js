import { d_ as t, d$ as n } from "./index-367d22e2.js";
let o = 5;
const r = (s) => t.post("/account/code/send", JSON.stringify({ ...s })),
  a = (s) =>
    t.post(
      "/account/code/verify",
      JSON.stringify({ ...s, operationID: Date.now() + "" })
    ),
  c = (s) => t.post("/account/register", JSON.stringify({ ...s, platform: o })),
  i = (s) =>
    t.post("/account/password/reset", JSON.stringify({ ...s, platform: o })),
  d = (s) =>
    t.post(
      "/account/login",
      JSON.stringify({ ...s, deviceID: "", platform: 5, account: "" })
    ),
  f = (s) =>
    t.post("/account/password/change", JSON.stringify({ ...s, platform: o }), {
      headers: { token: n() },
    }),
  q = (s) => t.post("/account/challenge", JSON.stringify({ ...s })),
  p = (s) => t.post("account/auth", JSON.stringify({ ...s }));
export { f as b, d as l, i as m, c as r, r as s, a as v, q as w, p as x };
