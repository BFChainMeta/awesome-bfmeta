import {
  d as W,
  N as X,
  a0 as Z,
  x as H,
  y as q,
  v as $,
  j as m,
  r as L,
  aQ as ee,
  B as o,
  D as c,
  f as u,
  J as D,
  E as t,
  H as a,
  F as n,
  _ as se,
  G as A,
  bn as te,
  Q as d,
  ba as b,
  aI as re,
  I as oe,
  V as ae,
  S as j,
  aR as ne,
  bm as w,
  bo as le,
  aO as ie,
} from "./index-367d22e2.js";
import { S as ue } from "./index-ee9d7309.js";
import { m as me } from "./more-f2b22f25.js";
import { _ as ce } from "./index.vue_vue_type_script_setup_true_lang-d7754eca.js";
import { _ as i } from "./index.vue_vue_type_script_setup_true_lang-32f2ca7b.js";
import { u as de } from "./useCurrentMemberRole-15583a5d.js";
import { u as fe } from "./useConversationToggle-d470852f.js";
import { s as pe } from "./function-call-315194bf.js";
import { B as Ae } from "./index-0f5c28c4.js";
import "./index-e4ec3b15.js";
import "./arrows_left-58dc349e.js";
const be =
    "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACgAAAAoCAYAAACM/rhtAAAAAXNSR0IArs4c6QAAAdlJREFUWEftmL8rhVEYxz/fMhiMBoOBUjIoq1D+AINFEYrZoiyUxSAGA4OZgShGg82AMhqUlGLwJxgUdXT0Xr1e98f58XbvpfeMt+c838/5vuc89zlHNPlQk/PxNwGNMS3AENBVJ4efgWtJH1m9Xw4aY3qBM6CnTnAlmUdgTNJDWvcHYOLcfQPg0pB9aSezgKPARZ2dy8qNSLoq/ZgFnAP2Ggw4L2m/AIz4CkEO2uN/C7xGCKentgEDgC1n2REEOCvpICe4rzTGmEr7PQhwUNJNzoDDwGVeDtpKfwy85QTZCswAnXkB5sTllCboEztlzinofwJuAWuSnMuMMaYDOAHsYfAZQQ72S7rzUUlKyRJgF+czggDPgW3PU9yewPn2lEGAPg7ExhaAhYNFw1pjD1Q9JJPAUewmipw/Iem0lCN7J7HdxVOFRjJS12m6bYy7Jb2UBUyq/waw7JQu/6BNSSvptGWfPpJudzpzP671j2BX/etlwHEN9tJ+mL7NVXSwUkJjjKkitipp3RHGK8z58agK4KKkHS9Vj+AYQPs5Ldyuh553aCighZtKlwNvZccJPoDvSfmpG5xdgw/gAjCedNbfjzuORgSHOQMGK0ROLAAjDXTfg7FCofM/ASTAzSmrojnjAAAAAElFTkSuQmCC",
  ge =
    "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACsAAAArCAYAAADhXXHAAAAAAXNSR0IArs4c6QAAA3lJREFUWEftmEuoVWUUx39/jUwMlewGSg1EIyF6gIMgimZh4aUGQUKgw6KMGjiRnPVAcOSkwIE0irIgKSPMkYMoFEwjCCUkIsFIeg7SW/mXJd+Wr805Z3/fPudIF+4ancd6/Pba31p7rS3mkWgesbIAO627tZDZ/3Vmbd8N3AXcm0BPAick/TBJ8LGOge2HgU+BZUOgjgPbJH07CejesLZfAV4rhJiVdKhQd6haL1jbO4A9La/fAF8CtwN3AHE0ctko6cQ4wNWwttcCZ7OgZyWta0PYjt+OAbdk/y2RNNcXuA/sqayQLkiaGRXc9j/A4qSzW9LO6wJrewXwWwpmYJWkXztgZ4GPMp1FksK2Wqoym27tdynK75JWlkS0/TdwQ9JdIemPEru2Ti3s/cBXycmPkqKQOsX2X8BNSXFG0oVOowEKtbAbgKZn/izptpKgti8BNybd5ZL+LLEbN7NrgHPJyZykJSVBbedndKmkiyV2Y8GGcSvwIUlRQEPFdtzyVUnhmKQH+oCGTdUxSLBPAAezgAOfTrbD917gxUw3uscv1w02AefZip+iQzwGNIPLI8BnLagDkp7uC9o3s5Gx6Lcj+2sL6ryk1eOAVsPa3gW8Whl0n6RnGxvbtwJfAIclba/xVXRmbd8DfF3jGHgTeElSPG6vie3oJtFVQtZJyueMkSE6YW1vA94e4OUA8Ebqu5ez/y9Lyr//x9T2T0DTnycHa/s+IKb+RiJLDwHHRwGNSs80YfNmfk5SzKpjyVRgbT8IfJ7ILklqnu3FsLZjNMyLKC7+deDm5CQ2jXxOiIR8MCzA0DNr+33gqWT4jqRniimTYmuWLTXfLOmTQcqjYKNKYysI2SDpdGm0Rs92FFpnEbf8bpH0Xi3stfMqqTbg1Vi2Y0p7OQMOn1uBpQnmXaCZbRelNWi/pH9rYfMWs1rS+drMDtJvFdhaSd+X+h11DA4DjyZHRyQ1n0t9D9SbVjfYDHycRYxN9TlJzabQC3oqsOnMnQHWDyiSWFNi1MvvTOxYTUtqLuSopMfzq2rB3imp2ek6L76zcGzH66FNnZ6GKyzOn3a2433Yh0C8FHmyZtPthE0Zjuy+AMT01FRyCf9bkp4vUSzRKYJtO7IdtztWlWa9DpV409K8U7j6XVIsihOTXrATi17paAG2MmHF6guZLU5VpeK8yuwVWiUpO1GfcKwAAAAASUVORK5CYII=",
  Ce = { class: "page_container !overflow-y-auto" },
  Ie = ["src"],
  De = { class: "flex-1" },
  we = { class: "px-[22px] py-6 mb-2 flex items-center bg-white" },
  Ue = { class: "ml-3 flex flex-row justify-between items-center flex-1" },
  ye = { class: "flex items-start flex-col justify-between" },
  Se = { class: "max-w-[160px] truncate mr-2 font-medium" },
  Me = ["src"],
  ve = { class: "text-white text-sm" },
  ke = { key: 0, class: "mb-2" },
  he = { key: 1, class: "mb-2" },
  Ne = { class: "flex justify-between w-full px-[22px] mb-6 mt-8" },
  Pe = W({
    __name: "index",
    setup(Ge) {
      var v;
      const { toSpecifiedConversation: x } = fe(),
        J = X(),
        e = Z(),
        U = H(),
        y = q(),
        { t: g } = $(),
        f =
          ((v = e.storeUserCardData.baseInfo) == null ? void 0 : v.userID) ===
          U.selfInfo.userID,
        p = m(() =>
          e.storeFriendList.find((s) => {
            var r;
            return (
              s.userID ===
              ((r = e.storeUserCardData.baseInfo) == null ? void 0 : r.userID)
            );
          })
        ),
        { isAdmin: R, isOwner: S } = de(),
        M = L(!1),
        C = L(!1),
        O = m(() =>
          e.storeUserCardData.groupMemberInfo
            ? ne(e.storeUserCardData.groupMemberInfo.joinTime).format(
                "YYYY-MM-DD"
              )
            : ""
        ),
        K = m(() => {
          if (!e.storeUserCardData.groupMemberInfo) return "";
          switch (e.storeUserCardData.groupMemberInfo.joinSource) {
            case w.Invitation:
              return g("inviteToGroup");
            case w.QrCode:
              return g("qrToGroup");
            case w.Search:
              return g("searchToGroup");
            default:
              return "-";
          }
        }),
        E = m(() =>
          Number(U.storeAppConfig && U.storeAppConfig.allowSendMsgNotFriend) === le.Allow
            ? !0
            : !!p.value
        ),
        V = m(() =>
          p.value
            ? !1
            : e.storeUserCardData.groupMemberInfo
            ? J.storeCurrentGroupInfo.applyMemberFriend === ie.Allowed
            : !0
        ),
        F = async () => {
          e.storeUserCardData.groupMemberInfo &&
            (M.value =
              S.value ||
              (R.value &&
                e.storeUserCardData.groupMemberInfo.roleLevel === b.Nomal));
        },
        P = (s) => {
          (C.value = !0),
            oe
              .setGroupMemberRoleLevel({
                groupID: e.storeUserCardData.groupMemberInfo.groupID,
                userID: e.storeUserCardData.groupMemberInfo.userID,
                roleLevel: s ? b.Admin : b.Nomal,
              })
              .catch((r) => ae({ error: r }))
              .finally(() => (C.value = !1));
        },
        z = () => {
          var s;
          x({
            sourceID:
              (s = e.storeUserCardData.baseInfo) == null ? void 0 : s.userID,
            sessionType: j.Single,
          });
        },
        Q = () => {
          var s;
          y.push({
            path: "sendApplication",
            query: {
              sourceID:
                (s = e.storeUserCardData.baseInfo) == null ? void 0 : s.userID,
              sessionType: j.Single,
            },
          });
        },
        Y = () => {
          var s, r, l;
          if (
            (r =
              (s = e.storeUserCardData.baseInfo) == null
                ? void 0
                : s.faceURL) != null &&
            r.includes("http")
          )
            return pe({
              images: [
                (l = e.storeUserCardData.baseInfo) == null ? void 0 : l.faceURL,
              ],
              loop: !1,
            });
        },
        B = () => {
          var s, r, l;
          y.push({
            path: "/designatedMoments",
            state: {
              userID:
                (s = e.storeUserCardData.baseInfo) == null ? void 0 : s.userID,
              nickname:
                (r = e.storeUserCardData.baseInfo) == null
                  ? void 0
                  : r.nickname,
              faceURL:
                (l = e.storeUserCardData.baseInfo) == null ? void 0 : l.faceURL,
            },
          });
        };
      return (
        ee(() => {
          F();
        }),
        (s, r) => {
          var k, h, N, G;
          const l = ue,
            _ = Ae;
          return (
            o(),
            c("div", Ce, [
              u(ce, null, {
                default: D(() => [
                  f
                    ? a("", !0)
                    : (o(),
                      c(
                        "img",
                        {
                          key: 0,
                          class: "h-[23px] min-w-[23px]",
                          src: t(me),
                          alt: "more",
                          onClick:
                            r[0] ||
                            (r[0] = (I) => s.$router.push("userCardSetting")),
                        },
                        null,
                        8,
                        Ie
                      )),
                ]),
                _: 1,
              }),
              n("div", De, [
                n("div", we, [
                  u(
                    se,
                    {
                      size: 48,
                      src:
                        (k = t(e).storeUserCardData.baseInfo) == null
                          ? void 0
                          : k.faceURL,
                      desc:
                        (h = t(e).storeUserCardData.baseInfo) == null
                          ? void 0
                          : h.nickname,
                      onClick: Y,
                    },
                    null,
                    8,
                    ["src", "desc"]
                  ),
                  n("div", Ue, [
                    n("div", ye, [
                      n(
                        "span",
                        Se,
                        A(
                          (N = t(e).storeUserCardData.baseInfo) == null
                            ? void 0
                            : N.nickname
                        ),
                        1
                      ),
                      n(
                        "span",
                        {
                          class:
                            "max-w-[160px] truncate mr-2 font-medium text-sm text-sub-text",
                          onClick:
                            r[1] ||
                            (r[1] = (I) => {
                              var T;
                              return t(te)(
                                ((T = t(e).storeUserCardData.baseInfo) == null
                                  ? void 0
                                  : ((T.address && T.address.slice(0, 5) + "..." + T.address.slice(-5)) || T.userID)) || ""
                              );
                            }),
                        },
                        A(
                          (G = t(e).storeUserCardData.baseInfo) == null
                            ? void 0
                            : ( (G.address && G.address.slice(0, 5) + "..." + G.address.slice(-5)) || G.userID)
                        ),
                        1
                      ),
                    ]),
                    t(V) && !f
                      ? (o(),
                        c(
                          "div",
                          {
                            key: 0,
                            class:
                              "flex flex-row justify-center items-center bg-primary rounded-md px-2 py-1 h-[30px] ml-auto",
                            onClick: Q,
                          },
                          [
                            n(
                              "img",
                              { width: "20", src: t(ge), alt: "" },
                              null,
                              8,
                              Me
                            ),
                            n("span", ve, A(s.$t("add")), 1),
                          ]
                        ))
                      : a("", !0),
                  ]),
                ]),
                t(e).storeUserCardData.groupMemberInfo
                  ? (o(),
                    c("div", ke, [
                      u(
                        i,
                        {
                          lable: s.$t("groupNickDesc"),
                          content:
                            t(e).storeUserCardData.groupMemberInfo.nickname,
                        },
                        null,
                        8,
                        ["lable", "content"]
                      ),
                      u(
                        i,
                        { lable: s.$t("joinGroupTime"), content: t(O) },
                        null,
                        8,
                        ["lable", "content"]
                      ),
                      u(
                        i,
                        { lable: s.$t("joinGroupMethod"), content: t(K) },
                        null,
                        8,
                        ["lable", "content"]
                      ),
                    ]))
                  : a("", !0),
                t(e).storeUserCardData.groupMemberInfo && !f
                  ? (o(),
                    c("div", he, [
                      t(S)
                        ? (o(),
                          d(
                            i,
                            { key: 0, lable: s.$t("setAdmin"), arrow: "" },
                            {
                              default: D(() => [
                                u(
                                  l,
                                  {
                                    size: "20",
                                    loading: C.value,
                                    "model-value":
                                      t(e).storeUserCardData.groupMemberInfo
                                        .roleLevel === t(b).Admin,
                                    "onUpdate:modelValue": P,
                                  },
                                  null,
                                  8,
                                  ["loading", "model-value"]
                                ),
                              ]),
                              _: 1,
                            },
                            8,
                            ["lable"]
                          ))
                        : a("", !0),
                      M.value
                        ? (o(),
                          d(
                            i,
                            {
                              key: 1,
                              lable: s.$t("setMute"),
                              onClick:
                                r[2] ||
                                (r[2] = (I) => s.$router.push("setMemberMute")),
                              arrow: "",
                            },
                            null,
                            8,
                            ["lable"]
                          ))
                        : a("", !0),
                    ]))
                  : a("", !0),
                t(p)
                  ? (o(),
                    d(
                      i,
                      {
                        key: 2,
                        lable: s.$t("userInfo"),
                        arrow: "",
                        onClick:
                          r[3] ||
                          (r[3] = (I) => s.$router.push("userCardDetails")),
                      },
                      null,
                      8,
                      ["lable"]
                    ))
                  : a("", !0),
                t(p)
                  ? (o(),
                    d(
                      i,
                      {
                        key: 3,
                        lable: s.$t("toMoments"),
                        arrow: "",
                        onClick: B,
                      },
                      null,
                      8,
                      ["lable"]
                    ))
                  : a("", !0),
              ]),
              n("div", Ne, [
                t(E) && !f
                  ? (o(),
                    d(
                      _,
                      {
                        key: 0,
                        icon: t(be),
                        type: "primary",
                        class: "w-full !ml-1 text-base",
                        onClick: z,
                      },
                      {
                        default: D(() => [re(A(s.$t("sendMessage")), 1)]),
                        _: 1,
                      },
                      8,
                      ["icon"]
                    ))
                  : a("", !0),
              ]),
            ])
          );
        }
      );
    },
  });
export { Pe as default };
