import {
  d as w,
  a5 as C,
  v as h,
  w as F,
  y as I,
  x as S,
  B as g,
  D as u,
  F as A,
  E as s,
  f as U,
  _ as x,
  G as l,
  a1 as v,
  a2 as K,
  a6 as Y,
} from "./index-367d22e2.js";
import { b as d } from "./back-099fa84a.js";
import { s as D } from "./function-call-e762d9f1.js";
import "./index-0f5c28c4.js";
const R =
    "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACQAAAAkCAYAAADhAJiYAAAAAXNSR0IArs4c6QAAAolJREFUWEftmE9o03AUx78v7aCg4A6DCQpu4MGbHndwOG+CqK3CYKdt4AJlXtI6hyfjSWQ28VaWCZsnL0JTRfDmPAiCJ28eBCt00MOEHSp0NsmT1CbbatP2FxrodLmF3++93ycv7883IQzYRQPGAx9IM8wXYEyEAaxL9uTywq2ytmp+C2PPxOWsnJp0bfcDvQMwFcYh2TyupFMlzTA5jD2AUkZOjh8eIGZYRCgHPi3zCIiOe+ttI8RcBdF2kA9mnCZCvLneNUL+hnYOdcNcZ2CuExABG4qcnA8C0oxGvo0JAel6YZiPxc57Th0pVrp7++p3EaAnz96ckRzbOxj00/6sKKmdUEAr+cJULEZusjcuIlKVhRsPRYD0teIDZlY9H7bNl5fSqc0jIC+H+hqhR/nCWCIuzXrhZqbNjHz9vcgr04xXl4jY7281y3l+/0/PEk/qoAoRAepLlTFQI+Bjhx5yjggnO5U9MypE+BLoA5ggINFr2QtNgP9vdAiFx+1PUQxXUYio9vvy4+lacdSiuJdkQudVy5+2VFW13DHhGSaGdqt3Zm/+CKyy/OtTzpDUGK5S3bEy6WtbkcqPfg9XoQi1y6F/HIi5SkQvOzS1iwDOtjZGt4P7Y4ZQgUN7jdHa/ZBZnP7qreuGuQJgpHm/rcjJpU45FEqg7X+AnFGYI9AeIHg+K6c2uuVCkMhvAIkO18iBRAXaoQbKteRQtpccijJCofSQqq4nTowO+zIDNey4Aj1ID4m8slBAogItSqBu1XlgvZdO3RrVlgO6figeAf31s0FfLepMfEEoNM3NVv3XzL3F6YpmmP5HJQNvs3LysecvZ5jLBFwJ8F/JyMmZA6MjDEgUNgP3B+03Yq/XQxgsydYAAAAASUVORK5CYII=",
  J =
    "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAYAAABXAvmHAAAAAXNSR0IArs4c6QAAA09JREFUaEPtmT9oU1EUxn8nCZLYCBUpFOKg4FDEYmsHFRHtUFBcXcRF9w662ECXLtVWB3EQHAQdBBFXhw6VFlR0sG0URQfFDkZbUOiQ2kCTd+S+9E8Skpf38uc9CrnrPe/c7zvnu/eec5+ww4fscPy0CQSdwXYG2hloMALuJJTo2Re1YvFG1pKwlVv7+SFd0ccdPY7FQ+AIyixwjaR8cLOeI4Fod/+ZSFgeINLjxllNG0uHM7/m75fY3dZTWEwhbAdIyRDiHDfkTS2fVQl0JPqPQui9CJFaTtzOq+rj1fT81S37YvDKV/JcIsIocBFDAk6QlM9O/qsSiCcGniNctD9WzSj8cQu0kp3AUj7H9bXl+Xf2fGnkF1njJGOyxJhGiPF0g8QsSRmsl8AXhIJ01td7M8sfPzVCwFE25ZIZ1z4iLNjfjIijzB0kdOyHiBwwPnK5/MHsUmqxKQTKZWOcmkBtkvjHd6LMbATvEyPSW1cGOhItIFAOPktBHpuAC7pfQjhkExKGGJGC5KoM/zJQCbzRvBk3tYcwM0B3Yc/ZRM6TlNe1su4PASfwBuGYdpdlwRX4gvqqjKZJqIXgW0+gxeBbS6BO8LsTfRdEQsMgU6s/5+4FswfqBG/AxhMDW/dPJpPfy0pqxd9TqAHwBqjXvdfcTdwg+GAJNAF8cATG9Qhh3tolsfKNLKftwmxzeDjng5HQhN5CSG7dosW1vAfwwWVgUk3l2AeYitV0VYWGpLgwc1ke+J+B29qN8hslS5YuYjwqaki2CzOXtY3/BCb1MvAEZZqkDDGmncR4ZWfCY2EWjIQm9BHCFeCdnQXTBgrResAHQ2BSf2+VwdtXZgplijzPGJVUrXKgeN5/CU1ooXsygOElIaa5UXSEekEf+E3sEWwlc/8z0ATQwUqoTaA0Am0JbcbDaySapSSv6zr0AwMLInZ9g2XpsKX6olkgq/pRDoTDoWnzHqtKbjX9dw8smsux6nBqaO6KyLWWg662gPI6k547XWv96u+OnX2d8Y6wqfGb87ReC0nJvK6oWoOr6VTNW9z5B0fX4Xh8V2wEOKvofk8Y6jKWFVHe56z8uNu3WHd/aOoC489HbQL+xLmOUyhoYG7Xb0vIbaRaZbfjM/AfrUHST4a/EmkAAAAASUVORK5CYII=",
  Z =
    "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAYAAABXAvmHAAAAAXNSR0IArs4c6QAAB1BJREFUaEPtWXGIHGcV/71vdi97be92ZjbX21kjpNhixAQqFKpoaKURL6BYMMEGFFNUvKLBFFsupZWsUGhDLUYukIj5o8VKIj1RsNCTtiRipJEUGjDiSSOmVHYvud7M7O21d9zufE++2Z29ud3Z7MzeFa1k/tuZ73vv/d77fe+97y3hQ/7Qh9x+3ADw347guiMwOjx8t0hruyC9K2Vn4dcA6j1ApQpm9ptMIu/J+tlrTvXP63FC3wDyun4PaSgS6N6WAcwXa7a7cw5YjDJqBLglZeqvE9H24DuDz7KH4qzr/rEfIIkB+Ebkss8QxHiUQmY+Wbbd70R9s3LZ49fbV7fdh7uB7wYuEYDC0NDHOa1NE9HWlgeZ60SYBuhLwTvp8f5Z130+rHTUzH5NgF4golTjPb/EjLHV3wAzX6GaN1aqVv8RNxqJAFim8XcibAsZP1Wvy8fmFhYuF3L678MgFDUg+bRaS0KBWwXIzFNl2907Mjx8eyolniKiPas0xPmS7XxmwwEoZem09pbvO2CRWT44a1emAkUjN9+cT2UGzhBWAUZTDOeWJH/ZdV03+J43s3sEiV8CyKh3teUVa+6992bjgIgdAXNwcEvmpsw7TaHLteWV29qVFIaGNst0alIQHmhXzsx1EJ+sz1cebef5iK7fmdboTd85zPXFmmdVq9V3NxSAEmbl9DNB1mHmo2XbfTgy26hoafRVEPl0Y+DiSs37w3y1OhO1vmAapxCAZn6uZLsPxjHep2fchWrdaC67S4N4pXkIL5fm3TuS7O+2tmDqDoh0//tK/ROlLkCj9icCACBVyBm1QND7HhthLvcDJkxNZn63bLsjSeSsC0Bp3km6v8O2vK5vFRr9q8n/DxaAyuUaCT81MvOlsu3uSOKtOBSqefypOde9GFdubA+qNJneNHABhC2+cCkPlZzKkUhFRdaxCfdBoNEySFwC4VUcokrvQ4zzNdv5QtyKfF0AucHBj2ibNm0mwXcJ0BNBBVZcXZK4o4P/RU5hEBNgPAFq5PTWw1gGoYglPIsirWn4VBpNCVwIqrKqyBL8JEt6A8yL1yqVt7s1iZEAbjWGPpsS2nMA3R7lsRp7u+fshek13xrGnwKwWlWjeTCFJexrBzFqZr+lkTgZvYUv16W3P6pz7QDQaNaMtwjItwtTFVhK7LvqOC91KDrChwEUQx6fgd8j+YVgDKEWBMAhTFAH/SzD+DoRT7ZS6poIsluz3Y+2U6sDQEHX74dGv23oxSJUg0W4IhlnRc17vhRVIYu8GRm8E6LNCSzhQMvLjehMAmh0sIpOy7BQpFY7EdiqqjkPpL4LxucA3gKirQTc4h8llnvD7Yt61wHAMvUfENHRxjnlY7OOe6BnRjjCijYvNo2bwTJ2tFMECkQGfw1FYi8mqNVLddORN/RJIej7Pm7mg2Xb/Vl4bWcETP0wiBpUYC6WbPfHMQCE6XMUExTZYuAI/xTAwaa8Iiaop+xCD3v+/wD8r1HIyhnHqXl2YlGo2Zv7fGZglpgvScYMQZ7vemnfwENsmcNfBMQeEJopnLYFGTHWIW6m0XJw8tdmMr4oSY5fnV/4S0QanQDwdL9p1M8+Ke1FEqEhQUiJyoj1ecfqmUbVnryu30sanepWCzxZH+soKusrZJmCqb8OojsjEwazW4Pc11E8e9wHMlY2u10CukiJu4n5kVaBYfz7fck7urQSPwSjmKSVKJjGMyA8EhivJhuA/A1Lsazeea77RrfeKH4zp25ZKe1M0MxFHaiW91QzN4hdAD7ZfPc3LOHVboULAyl1VfV7J5byobJTOdEzdTcXxAag1ltGdpyEON4oEZgu287uuIq6Fqqc8T0BHGsWwUQTichKfD2D1kwmmK+Ubfe29QKwTP0XRPTtRuXHgVnHaYCJ+SSKQNv1b0MAhC/0LOV42an8PKbt/rJEAFSOJtL8DpOZz5Vtd2cSZVFrrZzxOAFP+jLBL5Tn3W8kkZkQgP4KEanDqbT9pGQ7j0Yp82uJMfwVCG07mDcTq34eU9cqlX+2r7ey2bsoJS4E7z/YK2VmoNxUFDnYUpnEMvXHQXQwqhBKlqdFTR5ob8nzpnGqNQxjnC7Zzr64UYgdgTX8V/cE6Y2XnYVfBYp0XddvEvQyCJ++nnIGZurLK58PT/XC/VdSasYG4KdRU3+TQtVSDWk9jw8palhm9mUiMRYYr6YWDEwR81UQ3Rce4DLL6bJd2X1rNvsxTaOn137rPvGLckwiAIWhoW0Y0NQUunVXVrPM9vF6c2LxbPgi7l8XBdQAt/lEjNeBGVqp74y89XUJayIASoY6oGlDfwrNW1K7XIY8UZ6vPBSlr2Dok932QfKxmuM+FnecEshPDCDY6I9CCIdJ0P2rTu39F1Pa1P8UbtrU/wh16f1ozqmei3tww+v6BhAIUWmQNboH4Ldn7crv4vzJZ5nZ/SAxKmvea1cXFs73Y/i6I7AepRu5d90R2Ehj+pF1A0A/XtvIPTcisJHe7EfWfwBFd49eldf+MwAAAABJRU5ErkJggg==",
  j =
    "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAYAAABXAvmHAAAAAXNSR0IArs4c6QAABZFJREFUaEPtWV+IVGUU/517x92ZnRusuZbrHWF9CEqlZmfrIShQSFwhyGiFpCJFA8MiDWNcFJwgc6c/ZKQYVGgYJGjomysJCgo95M6uIRH04EJz1y01Frx3967O3BPfzL27s//m3m9m0jb2e9rZOf9+55zvnPOdIczyQ7PcfswBuN8RnIvA/yYCkQVP6FSvtCsKPQ9GEwMxEC0i5hwDN4moH4ybDjvdPOp0j9y6YtQCfNUpFNXjrwPqdiLEZQxi8GWwc9Ay+r6V4ZtMWzGAaHNiDRTqkjV8sgHM6IPDu6zrmbOVAKkEQEjT274AYWupQgZsMF8ixukc8lfgUNYeHBrEwoZQWK1rCoXQAkdZzoR1IHqGgPAEgxlfmkbP2wByMkDkADTGG6NR5QQRPTeuhIcAHDBN53MM9Ym//U9jvFHTlHfA2AkizWNg5nOW5awPLAeQaGRCaVT9CYRHSxQexx17h3Xj10F/q6dSRBcuW4S68GdE9PLYt4zfTCv/dFAQQSMQiuqJM6Wed5j3DBuZfZUYPpmnQU/sVog+mBAJI7M2SDoFAqDpbYe9nGdGzoGzYcToPRnY+BQ3IUU3y9FH9NYOlZQTJZEQd+JNPx2+AES1IZW6PUFSnk9zDMBFsOgJ2IMkpcsZNCUSeW73q07+APS2Xq9UMvNxy8hs8PPK2Pdp/grAlsJnhg0b85Eiuxx/VE98790JUWIto6e1HH1ZAKJJEalHiwJ4iEftx6Qu7Ed8HoyVLoAcbESQorJlUlxsqgv/7lUn5vzGcs3OB8C49wFOmdnM+4G9LwjTvBtA8XIyjmIXbQrCr8USewFKFdn4spXNPDUT34wAIg8+HlMb5v1RFALbMvPNQUvbmLIUhxDBK2DkYeO4n/fH+ES/0dTrXrPLD99dMvL3L9npQMwIoGFx62ZFUb4uABANxsisDuK9KTQf8gKEEca7JDW8RfXEj17Zdhxny/BA7zdSADS97QQIHQUmh98yBzKHpACICsT4GEAHCINI0hIZfm1xYhsUOuim30nT6FkvCSBxUcwsginn5J61B65cCmxAF78Agrj8jWM8SfKteKXytVh8JaCed/93wcz2rJICENUT14iopQAgl19qD/b1BwKQ5s0AROr1uQAKMiAJILwo3hIKqdfcFO63jMxSOQCxthHvEpnZWxGgv2z9HhO+j+NQ0IhOuoA09wKFd8IQkjQ/kAM8ooXLNK0+cruYQmyaRuaBewOgVEsX3wZBTJt9SFLZhjTFuKoBVJpCniVi/onghvvxNJL0okwEqk4hTa/iEgtL0/wkgJ9dow8gSTtkAFR9ibVY4hRA66ooo4L3lGv0TiTpUykA1ZbRhua2LYoKMYxV1sj281YoOOzW8dewi76TATChkeXxxvD1nkJTnXz+vVEizXsBFOYZOFhVqEpBTy1GCaErWjJKSw9zXXwEhI0ugEcwiizqsRyd1OOHoybDXBFAYiMRHSkqlBynu/gYCK+6ANZCwX446ETn+ONoOiBTx2neZBkZd6SXSCGPtDQKUg+aNIvnYXGWKp5AlaimD5pCFJoT7aTSGc+KwE/KLhabhmMQ+yJCKkgVmvKkdJzV1kDvuXIpF2jAKn3UC2F5OB0j2d4f/HIZKRbDnBnkHRCJtb6kQhlfFBQXXdU/6l0jZ/dapQBipsXW3Tvbrb+u/ukbjWkIog+teBjz6g7ci8VWUf10q0VmE4RP/vurxXEP+i53ofDVXB79dm70lmALh+oXhFSx3KUV93e5W5IGojpBof01Wa+z855ftZkpRQNVoXL5LZodCNsIJKbPwKf4AwcOlWtSQYRVDcBTItYwVD+vXVGwBoQmZm4hoEl8P+EnJgdnefRu90xrkiBGl9LUDICs4lrRzwGolScrlTMXgUo9Vyu+WR+BfwAuuK9PtgVbcgAAAABJRU5ErkJggg==",
  X =
    "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAYAAABXAvmHAAAAAXNSR0IArs4c6QAAAwlJREFUaEPtWT9oE1EY/313Z7023SzYJh0cHCpUTKII0gopLh0U7FhQdHBQxE1IOggdWpo6FxQq6KDYzYoBBQcVF6F//QeCDg690qHVJW06NPfJSy4xtr16l3vX9uAyXt77vd/v+33ve+++IwT8RwHnj1DAXjsYOhA64DEC9aSQprcmujSFOqGgxeP6/0w3GRtM/A0F80Nh5aPhBNuVgMZovEsl5QGIOpyA1zuGGRsEZPPGyjDwc30nHMcCIrHEOUB5RQStXmJu5zHzxKox2y9FQHN78jtAR0tgjGWTeEIBlt2S2nE8kwZCN4BUZZxpFi+uLc4/t5vnyIFILB4nUufK5DlfxMaxgvFpQSr5GrCm2Ml7CuG6Faz7eWPmhicBze3xFKC+sUDe5hdmevwiL3AjbcleUumlk/UcObDbAtysFwrwI5WkO9AQPd5xgBo+ixJqmjy2tjh7yxXxQW6BjqcAdBD6kaYdC4B0AYJsU1viFCs4UjB+5/53uGwRN8ppAFnr+RcUcAaDlLcLgi8CXEV88+Bh7oSKKRB0668c0nQhOAIE0xG+CgUPq6QZQ8jQne1E7D8HKizv8ggYmRrSl5CmJ5tF7F8Bg6yhEc8AnLdO2TwYKQzQTK0IbwLKi1wB0O4p7+3P/maYuF16G+fSoCUwzmKAflSmeBOQ5ZsgjPlCvgJaJo5qS4ExhQydDgWUIiBS6CCuQcFhX1wg/E2h8gJLMGWmkC+sLdDy/noBoLe6iQk9SNO0vE3sp4DNZZRxGRl6HIwyOsqisj0K5kG29SoxiTT12ZntrYxuj6pFYslxcTYUizy0vjT3zlWm7fVlTo+e6NYU7b0gzcy5VWPW9iK2rbDKdbp8mdv967QbS105YzPYzXrhK6WMiPteRt1YKkOQ9LZK4BtbIqp72FrsW1ucn7Rz1tEmFpP11nhKVdXXgW3ulkSI84C0cRCC116vsVDTW+PdmqKIDxyHZGzaCob4wAE2v/K6OV345ax57DiFZBKViRUKkBnNerBCB+qJmsw5oQMyo1kP1h/YtJVA1GA98AAAAABJRU5ErkJggg==",
  k =
    "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAAAXNSR0IArs4c6QAAALZJREFUWEftlkEOwjAMBMc/4ABv5MqJfIAD5Rf8D6n8wIioJ0qKHVkqqtyzvR2tdpMIK3+y8v9JgHSg7cBVjwgXYG8M6hM4UeRunK9jbYBBR2DnEQMeFDl4dpYA9C2kZ5uc3Ka5Iq5cJcAGHZhHZrEd8Q58z2yzHfEAny0YtLaJRjsS4K8diDmKuzMQdRl1A7SugB+Cs7UE2KIDMe2YwuJ6PNSdqHZ0A9geSOYpvwNmadtgAqQDLzSpeiGGIMvrAAAAAElFTkSuQmCC",
  N = "/assets/bg-7346ef41.png",
  V = { class: "page_container" },
  b = ["src"],
  G = {
    class:
      "w-[90%] h-[98px] rounded-md bg-white flex items-center pl-4 pr-2 mx-auto mt-[-60px]",
  },
  P = {
    class:
      "id_row flex justify-between items-start h-[46px] flex-col flex-1 ml-2",
  },
  T = { class: "nickname" },
  O = { class: "text-sub-text text-sm" },
  y = ["src"],
  H = ["src"],
  M = ["src"],
  z = { class: "w-[90%] mx-auto mt-[10px] bg-white rounded-md" },
  W = ["onClick"],
  q = { class: "flex" },
  L = ["src"],
  _ = { class: "ml-3" },
  $ = ["src"],
  AA = w({ name: "profile" }),
  iA = w({
    ...AA,
    setup(eA) {
      const { copy: m, isSupported: a } = C(),
        { t: e, locale: p } = h(),
        n = [
          {
            icon: J,
            title: e("profileMenu.personalInformation"),
            route: "selfInfoDetails",
          },
          {
            icon: Z,
            title: e("profileMenu.accountSetting"),
            route: "accountSettings",
          },
          { icon: j, title: e("profileMenu.aboutUs"), route: "about" },
          { icon: X, title: e("profileMenu.logOut") },
        ];
      F(p, () => {
        (n[0].title = e("profileMenu.personalInformation")),
          (n[1].title = e("profileMenu.accountSetting")),
          (n[2].title = e("profileMenu.aboutUs")),
          (n[3].title = e("profileMenu.logOut"));
      });
      const r = I(),
        t = S(),
        f = (o) => {
          o ? r.push(o) : Q();
        },
        E = () => {
          // a && m(t.storeSelfInfo.userID),
          a && m(self.loginerAddress || ''),
            Y(
              e(
                a
                  ? "messageTip.copySuccess"
                  : "messageTip.environmentNotSupported"
              )
            );
        },
        Q = () => {
          D({
            message: e("messageTip.tryLogout"),
            beforeClose: (o) =>
              new Promise((c) => {
                if (o !== "confirm") {
                  c(!0);
                  return;
                }
                t.userLogout().finally(() => {
                  // c(!0), r.push("/login");
                  c(!0), window.location.replace("./index.html"), document.getElementById('login-page').style.display='block', document.getElementById('app').style.display='none';
                });
              }),
          }).catch(() => {});
        };
      return (o, c) => (
        g(),
        u("div", V, [
          A("img", { src: s(N), mode: "" }, null, 8, b),
          A("view", G, [
            U(
              x,
              {
                size: 46,
                src: s(t).storeSelfInfo.faceURL,
                desc: s(t).storeSelfInfo.nickname,
              },
              null,
              8,
              ["src", "desc"]
            ),
            A("view", P, [
              A("text", T, l(s(t).storeSelfInfo.nickname), 1),
              A("view", { class: "flex items-center", onClick: E }, [
                // A("text", O, l(s(t).storeSelfInfo.userID), 1),
                A("text", O, l(self.displayLoginerAddress), 1),
                A(
                  "img",
                  {
                    style: { width: "16px", height: "16px" },
                    src: s(k),
                    mode: "",
                  },
                  null,
                  8,
                  y
                ),
              ]),
            ]),
            A(
              "view",
              {
                class: "flex flex-row items-center",
                onClick:
                  c[0] || (c[0] = (i) => o.$router.push("selfOrGroupQr")),
              },
              [
                A(
                  "img",
                  { class: "w-[18px] h-[18px]", src: s(R), alt: "" },
                  null,
                  8,
                  H
                ),
                A(
                  "img",
                  { class: "w-[24px] h-[24px]", src: s(d), alt: "" },
                  null,
                  8,
                  M
                ),
              ]
            ),
          ]),
          A("div", z, [
            (g(),
            u(
              v,
              null,
              K(n, (i, B) =>
                A(
                  "div",
                  {
                    key: B,
                    class: "flex items-center justify-between p-4",
                    onClick: (sA) => f(i.route),
                  },
                  [
                    A("div", q, [
                      A(
                        "img",
                        { width: "24", src: i.icon, alt: "" },
                        null,
                        8,
                        L
                      ),
                      A("span", _, l(i.title), 1),
                    ]),
                    A(
                      "img",
                      { src: s(d), width: "24", alt: "back" },
                      null,
                      8,
                      $
                    ),
                  ],
                  8,
                  W
                )
              ),
              64
            )),
          ]),
        ])
      );
    },
  });
export { iA as default };
