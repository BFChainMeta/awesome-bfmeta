var x=(i=>(i[i.TextWithImage=0]="TextWithImage",i[i.TextWithVideo=1]="TextWithVideo",i))(x||{});export{x as M};
