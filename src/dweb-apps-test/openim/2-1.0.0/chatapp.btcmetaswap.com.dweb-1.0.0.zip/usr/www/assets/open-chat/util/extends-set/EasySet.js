var _a;
import { __decorate, __metadata } from "../../tslib/modules/index.js";
import { cacheGetter } from "../decorator/index.js";
export class EasySet {
    constructor(entries, transformKey = (v) => v, _afterDelete) {
        Object.defineProperty(this, "transformKey", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: transformKey
        });
        Object.defineProperty(this, "_afterDelete", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: _afterDelete
        });
        Object.defineProperty(this, "_set", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        this._set = new Set(entries);
    }
    static from(args) {
        return new EasySet(args.entries, args.transformKey, args.afterDelete);
    }
    tryAdd(key) {
        return this.add(this.transformKey(key));
    }
    tryDelete(key) {
        return this.delete(this.transformKey(key));
    }
    tryHas(key) {
        return this.has(this.transformKey(key));
    }
    get clear() {
        return this._set.clear.bind(this._set);
    }
    get delete() {
        const deleteHanlder = this._set.delete.bind(this._set);
        const { _afterDelete } = this;
        if (_afterDelete) {
            return (key) => {
                if (deleteHanlder(key)) {
                    _afterDelete(key);
                    return true;
                }
                return false;
            };
        }
        return deleteHanlder;
    }
    get forEach() {
        return this._set.forEach.bind(this._set);
    }
    get has() {
        return this._set.has.bind(this._set);
    }
    get add() {
        return this._set.add.bind(this._set);
    }
    get size() {
        return this._set.size;
    }
    /** Returns an iterable of entries in the set. */
    get [_a = Symbol.iterator]() {
        return this._set[Symbol.iterator].bind(this._set);
    }
    /**
     * Returns an iterable of key, value pairs for every entry in the set.
     */
    get entries() {
        return this._set.entries.bind(this._set);
    }
    /**
     * Returns an iterable of keys in the set
     */
    get keys() {
        return this._set.keys.bind(this._set);
    }
    /**
     * Returns an iterable of values in the set
     */
    get values() {
        return this._set.values.bind(this._set);
    }
    get [Symbol.toStringTag]() {
        return "EasySet";
    }
}
__decorate([
    cacheGetter,
    __metadata("design:type", Object),
    __metadata("design:paramtypes", [])
], EasySet.prototype, "clear", null);
__decorate([
    cacheGetter,
    __metadata("design:type", Object),
    __metadata("design:paramtypes", [])
], EasySet.prototype, "delete", null);
__decorate([
    cacheGetter,
    __metadata("design:type", Object),
    __metadata("design:paramtypes", [])
], EasySet.prototype, "forEach", null);
__decorate([
    cacheGetter,
    __metadata("design:type", Object),
    __metadata("design:paramtypes", [])
], EasySet.prototype, "has", null);
__decorate([
    cacheGetter,
    __metadata("design:type", Object),
    __metadata("design:paramtypes", [])
], EasySet.prototype, "add", null);
__decorate([
    cacheGetter,
    __metadata("design:type", Object),
    __metadata("design:paramtypes", [])
], EasySet.prototype, _a, null);
__decorate([
    cacheGetter,
    __metadata("design:type", Object),
    __metadata("design:paramtypes", [])
], EasySet.prototype, "entries", null);
__decorate([
    cacheGetter,
    __metadata("design:type", Object),
    __metadata("design:paramtypes", [])
], EasySet.prototype, "keys", null);
__decorate([
    cacheGetter,
    __metadata("design:type", Object),
    __metadata("design:paramtypes", [])
], EasySet.prototype, "values", null);
