import { __decorate, __metadata } from "../../../../../../tslib/modules/index.js";
import { cacheGetter } from "../../helper/cacheGetter.js";
import { safeAreaPlugin } from "./safe-area.plugin.js";
class HTMLDwebSafeAreaElement extends HTMLElement {
    constructor() {
        super(...arguments);
        Object.defineProperty(this, "plugin", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: safeAreaPlugin
        });
    }
    get setState() {
        return safeAreaPlugin.setStateByKey;
    }
    get setOverlay() {
        return safeAreaPlugin.setOverlay;
    }
    get getOverlay() {
        return safeAreaPlugin.getOverlay;
    }
}
Object.defineProperty(HTMLDwebSafeAreaElement, "tagName", {
    enumerable: true,
    configurable: true,
    writable: true,
    value: "dweb-safe-area"
});
__decorate([
    cacheGetter(),
    __metadata("design:type", Object),
    __metadata("design:paramtypes", [])
], HTMLDwebSafeAreaElement.prototype, "setState", null);
__decorate([
    cacheGetter(),
    __metadata("design:type", Object),
    __metadata("design:paramtypes", [])
], HTMLDwebSafeAreaElement.prototype, "setOverlay", null);
__decorate([
    cacheGetter(),
    __metadata("design:type", Object),
    __metadata("design:paramtypes", [])
], HTMLDwebSafeAreaElement.prototype, "getOverlay", null);
export { HTMLDwebSafeAreaElement };
if (!customElements.get(HTMLDwebSafeAreaElement.tagName)) {
    customElements.define(HTMLDwebSafeAreaElement.tagName, HTMLDwebSafeAreaElement);
}
