import {
  d as Y,
  v as x,
  y,
  a0 as J,
  N as H,
  r as v,
  B as R,
  D as b,
  f,
  E as h,
  R as p,
  T as l,
  F as t,
  G as g,
  I as E,
  cg as Q,
  L as V,
} from "./index-367d22e2.js";
import "./index-9e32bade.js";
import { S as F } from "./index-f45378d2.js";
import { _ as N } from "./index.vue_vue_type_script_setup_true_lang-d7754eca.js";
import "./use-id-ce6fd248.js";
import "./index-e4ec3b15.js";
import "./arrows_left-58dc349e.js";
const L =
    "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAYAAABXAvmHAAAAAXNSR0IArs4c6QAAA09JREFUaEPtmn1ozVEYxz9nedmM8rJma5SXppGy1cJstfhDErqMSNG8Zf6YNnlJ3T+UtCs1ihIRovgDI2uWRsrLppa3eQ0ZG42wMTK2dnS2Zrq7u85xz8/90c5ft3uf85zv9/k+5zznuR1Bx9gne1NPNrAUwQRgwM/f3PBB8gnBHSRHGcRhVotmBUu0YSuQIxCcRpDiBqwaGG7TjAeveCHYIgcSyTUE4zQmusdE8hBJuqBA5hNBoXuQGSBpZZ1gu7wBTDSY5ibTCoFPfkPQx02otLFIvisFpPYEFxr2EAi3KD0K+CswKR4ie7V/2/ANahvh/VfndLKuQGMe9Pc706o/Qlk1nHgEF1/YJWOVQNYYOOkJDrCyDrJL4P47O0SsEcgcDmULoVfE74GptBp7AD63XcdCG9YIXFkMGcP0wawshYN39e27s7RGoH4tDIzUB7TnJuSW6ds7TkBuNANz+B4sKzGbE8jamgL/PIFAx2ew+B64C6tKXaRAzRoYZtCE7qqE/EsuIeBJhKK5ZmCaWiDKQhtlZQ9MjofyJWYEVHUeuc9sjqObuGo5jI/RB+S9AtvK9e0dP0aTY0EVM/97UKCFr9bC1OPQYqGVspJCHSBnjYZzWcGjqlIn7RjUfQk9+sqDVQLK4d7pkJPcPTgFvuK1HfCOEIiLhuerO3uCX6EWP4PZp+yBd4SAcnp+PswY1RWoKlyqgNkc1lNIgds5DfJSu8K0nT6OKbA1A7xTuhJQPcCjDzbj78AmTk+AE3MCXyvOPIGcC/DG0glkRYEJse0FLDUOZoyEpCHBI9zSCpdfwuUauP0WVIsZCqE/2gNDo8GbBouSIKZf6CmhiKgG50iVeXEzJqBSpDjLrPvSpaiUUcesSa9sRECd8Q9XOAO+g+TJx7DgrC5lw028aRL4MvWd/6ll4n542qA320iBQzMhe7ye41Cs1EVPbXKdYUQgaTCoNHJ6qE2t/pbUGUYEdBz+bZseAn874v7r/QcK+OQXBBbqaRi0kHxSCqjWenIYlrex5HVFYBPgs+EtDD7WCwplFN+p/AefGjygiZTOxx4RFAFB2vEwxLe7JSW3kMxjs6huJ6BGruxLAhsAD4IxrntuA43AEyRFvGIHu0Vbrf4B+MEr3kXYKrkAAAAASUVORK5CYII=",
  T =
    "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAYAAABXAvmHAAAAAXNSR0IArs4c6QAABD1JREFUaEPtmltsVEUYx39TqK2CUo0RoxYbHhAvUdCqJDWCsQ+QACFoFKMI8cYLBPGGJCaQaGwbDRKJMSY8EErCg8UCIqQpCSEGWpJqvdAS2oKtChEKtGyhtLvbjvk4ru3unt0zs6fbXU3nqd35Lv//fJfznclRRNZXOpculgMvo3gIuPHfvWz4QxNA8TOaSm5mKytUSGCpa9jKdBGKb1DMzAasBhh+IsQiPlAdig26gHwOo7jPQDF7RDTH0ZQoyvQactiYPcgskAzylqJCHwUes1DLJtF6RbnuR3FdNqEyxqIJSgS0sUIWCo4RyHRQxiIgEZg8AabfMhSL9kvQERid2IxIBN5+FD59Khrw5SA0/AW7WmF7M1y4mh5CvglMzIXa52HWHYkB9oXhozqoqIfwCPc83wRqn4PSIrPTXVkLXzSayZpK+SJQerdz+qbrzx4o/NJU2kzOF4HVj8Cmp80cRaTu2QItF+10kkn7IrC+BDaU2IFpOg+9IWi+AHWnoarFX4FnhEBwYIh0/wBUHHW6VSrLF4G1j0P5bDu3xzohNBitEx6E+TvhXK+dLZH2ReDVB2HLXDunv5yDAZdWuu4Q1LTb2fJNoHE5zLjNzumZHjjrctKfNUBlk50t3wT2Pwtzp9o5lTGjqy9e5/MfYOsxO1upEZDwO1cBLJkOOxaaO5Vcly406JJC6w/Dt23mtiKSvmpAjOxYAEvu9XYsr02nuiEQdJetboUPj3jbiZXwTSB/HHz/IhTfntz5mctw9kpimaoT8HF9BgiIy6Kb4PhrkD/eHUCgH052JwYnqfXSXmjpSgeBYTmfzPzmUlj5sLvEnjYoTHLPl2oHMivi2IKTAnb5bU4hHHwhnoB0neJt8PVCKMiP3z/QDu8dsj/5ESviiKGCPOhaHQ9k70lYsBOW3g9riqP3JXXmVWVwFhoOZ7yC0LvxBLY3wdLvnBTavTh6/9dOWLYv9dM3S6FY+y41IW9lZbPda0BeLaVAd7fBj8uijUnfl/7vZ6XURiflOa+QD9wKkvtzpsBEj7u9jkswIRd6w844fTUMEoHXa2D4dGpLxorAM9PgzWJ44i5bN/HyMtDJSNF8Hvadci4ApNVK0dssIwKS35XzzZ64Ns5FVsYKiU53v6MpDzxJrW1NTpS8lhGBsifh/VleplLflzHjxMVowPL/K/u9SXgSkFGhc5V3jqcO39GUe6PfYy7DJAqbGpJb9iRQNAl+W+EXnre+dKvWmFFC6uKNGp8EJALJLq0i5sflwOQbvIEmkpDu9EdP9G5P0PsGwzMCqUMaHc0xAqNzzom9/A8iUK6voPBRfhmMgSYgEagD0viYSivBI0JgLVCeVjfpM/6OYqO+niAN/8FPDZrpY+bQxx45VAMz0ndYI2hZ04hmMetU+z9XVMAqncedyDvVIhTTsu5zG5DndCuaak7zCZvVtfn1b7TXmt6MoNi8AAAAAElFTkSuQmCC",
  j = { class: "page_container" },
  k = ["src"],
  q = { class: "text-primary" },
  O = { class: "flex justify-center px-[22px] py-3 bg-white text-[#999]" },
  M = { class: "flex justify-center px-[22px] py-3 bg-white text-[#999]" },
  te = Y({
    __name: "index",
    props: { isGroup: { type: Boolean } },
    setup(S) {
      const n = S,
        { t: r } = x(),
        B = y(),
        m = J(),
        D = H(),
        a = v(""),
        i = v(!1),
        o = v(!1),
        I = n.isGroup ? r("addGroup") : r("addFriend"),
        G = n.isGroup ? r("addGroupDesc") : r("addFriendDesc"),
        w = n.isGroup ? T : L,
        C = async () => {
          a.value &&
            ((i.value = !0), n.isGroup ? await U() : await z(), (i.value = !1));
        },
        U = async () => {
          try {
            let e = m.storeGroupList.find((s) => s.groupID === a.value);
            if (!e) {
              const { data: s } = await E.getSpecifiedGroupsInfo([a.value]);
              e = s[0];
            }
            e
              ? (D.updateCurrentGroupInfo(e), B.push({ path: "groupCard" }))
              : (o.value = !0);
          } catch {}
        },
        z = async () => {
          var e, s;
          try {
            const {
              data: { users: c, total: d },
            } = await Q(a.value);
            if (d > 0) {
              const u = c[0],
                { data: A } = await E.getUsersInfo([u.userID]),
                P = {
                  ...(((e = A[0]) == null ? void 0 : e.friendInfo) ??
                    ((s = A[0]) == null ? void 0 : s.publicInfo) ??
                    {}),
                  ...u,
                };
              m.setUserCardData({ baseInfo: P });
            } else o.value = !0;
          } catch {}
        },
        K = () => {
          B.back();
        };
      return (e, s) => {
        const c = N,
          d = F,
          u = V;
        return (
          R(),
          b("div", j, [
            f(c, { title: h(I) }, null, 8, ["title"]),
            f(
              d,
              {
                modelValue: a.value,
                "onUpdate:modelValue": s[0] || (s[0] = (A) => (a.value = A)),
                placeholder: h(G),
                onSearch: C,
                onCancel: K,
              },
              null,
              8,
              ["modelValue", "placeholder"]
            ),
            p(
              t(
                "div",
                {
                  class: "flex items-center px-[22px] py-3 bg-white border-y",
                  onClick: C,
                },
                [
                  t(
                    "img",
                    { class: "w-6 h-6 mr-2", src: h(w), alt: "" },
                    null,
                    8,
                    k
                  ),
                  t("div", q, g(`${e.$t("find")}：${a.value}`), 1),
                ],
                512
              ),
              [[l, !o.value && !i.value]]
            ),
            p(t("div", O, [f(u, { size: "24", type: "spinner" })], 512), [
              [l, i.value],
            ]),
            p(
              t(
                "div",
                M,
                [
                  p(t("span", null, g(e.$t("messageTip.searchEmpty")), 513), [
                    [l, o.value],
                  ]),
                ],
                512
              ),
              [[l, o.value]]
            ),
          ])
        );
      };
    },
  });
export { te as default };
