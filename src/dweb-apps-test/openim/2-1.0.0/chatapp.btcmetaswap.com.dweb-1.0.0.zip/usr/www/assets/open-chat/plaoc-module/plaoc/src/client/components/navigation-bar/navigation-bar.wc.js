import { __decorate, __metadata } from "../../../../../../tslib/modules/index.js";
import { cacheGetter } from "../../helper/cacheGetter.js";
import { navigationBarPlugin } from "./navigation-bar.plugin.js";
class HTMLDwebNavigationBarElement extends HTMLElement {
    constructor() {
        super(...arguments);
        Object.defineProperty(this, "plugin", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: navigationBarPlugin
        });
    }
    get setColor() {
        return navigationBarPlugin.setColor;
    }
    get getColor() {
        return navigationBarPlugin.getColor;
    }
    get setStyle() {
        return navigationBarPlugin.setStyle;
    }
    get getStyle() {
        return navigationBarPlugin.getStyle;
    }
    get show() {
        return navigationBarPlugin.show;
    }
    get hide() {
        return navigationBarPlugin.hide;
    }
    get setVisible() {
        return navigationBarPlugin.setVisible;
    }
    get getVisible() {
        return navigationBarPlugin.getVisible;
    }
    get getState() {
        return navigationBarPlugin.getState;
    }
    get setOverlay() {
        return navigationBarPlugin.setOverlay;
    }
    get getOverlay() {
        return navigationBarPlugin.getOverlay;
    }
}
Object.defineProperty(HTMLDwebNavigationBarElement, "tagName", {
    enumerable: true,
    configurable: true,
    writable: true,
    value: "dweb-navigation-bar"
});
__decorate([
    cacheGetter(),
    __metadata("design:type", Object),
    __metadata("design:paramtypes", [])
], HTMLDwebNavigationBarElement.prototype, "setColor", null);
__decorate([
    cacheGetter(),
    __metadata("design:type", Object),
    __metadata("design:paramtypes", [])
], HTMLDwebNavigationBarElement.prototype, "getColor", null);
__decorate([
    cacheGetter(),
    __metadata("design:type", Object),
    __metadata("design:paramtypes", [])
], HTMLDwebNavigationBarElement.prototype, "setStyle", null);
__decorate([
    cacheGetter(),
    __metadata("design:type", Object),
    __metadata("design:paramtypes", [])
], HTMLDwebNavigationBarElement.prototype, "getStyle", null);
__decorate([
    cacheGetter(),
    __metadata("design:type", Object),
    __metadata("design:paramtypes", [])
], HTMLDwebNavigationBarElement.prototype, "show", null);
__decorate([
    cacheGetter(),
    __metadata("design:type", Object),
    __metadata("design:paramtypes", [])
], HTMLDwebNavigationBarElement.prototype, "hide", null);
__decorate([
    cacheGetter(),
    __metadata("design:type", Object),
    __metadata("design:paramtypes", [])
], HTMLDwebNavigationBarElement.prototype, "setVisible", null);
__decorate([
    cacheGetter(),
    __metadata("design:type", Object),
    __metadata("design:paramtypes", [])
], HTMLDwebNavigationBarElement.prototype, "getVisible", null);
__decorate([
    cacheGetter(),
    __metadata("design:type", Object),
    __metadata("design:paramtypes", [])
], HTMLDwebNavigationBarElement.prototype, "getState", null);
__decorate([
    cacheGetter(),
    __metadata("design:type", Object),
    __metadata("design:paramtypes", [])
], HTMLDwebNavigationBarElement.prototype, "setOverlay", null);
__decorate([
    cacheGetter(),
    __metadata("design:type", Object),
    __metadata("design:paramtypes", [])
], HTMLDwebNavigationBarElement.prototype, "getOverlay", null);
export { HTMLDwebNavigationBarElement };
if (!customElements.get(HTMLDwebNavigationBarElement.tagName)) {
    customElements.define(HTMLDwebNavigationBarElement.tagName, HTMLDwebNavigationBarElement);
}
