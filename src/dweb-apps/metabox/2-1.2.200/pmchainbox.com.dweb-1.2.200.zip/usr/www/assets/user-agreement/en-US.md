# Meta Box Terms of Service
> Last Updated: May 25, 2023.

Dear User,<br>
Thank you for choosing Meta Box. This Meta Box Terms of Service (“Agreement”) is made between you (“you” or “User”) and Meta Box(“Meta Box” or “we”)， and is legally binding between you and Meta Box.

Meta Box hereby reminds you that you must carefully read the full content of this Agreement and other documents mentioned in this Agreement before using Meta Box (“Meta Box” or “App”). Particularly, you must carefully read the section of “Disclaimer and Limitation of Liability” and other sections which are displayed in bold. You must make sure that you fully understand the whole Agreement and evaluate the risks of using Meta Box on your own. In addition, Meta Box can be downloaded on mobile application platforms.

## I. **Confirmation and Acceptance of this Agreement**
1. You understand that this Agreement and other relevant documents apply to Meta Box and the Decentralized Applications (“DApps”) which are developed and owned independently by Meta Box on Meta Box (and excluding DApps developed by third parties).
2. After you download Meta Box and start to create or import wallet, you are deemed as having read and accepted this Agreement, which shall cause this Agreement to become effective and legally binding on both you and Meta Box immediately.
3. Meta Box may, at its sole discretion, modify or replace this Agreement at any time. The modified Agreement will automatically take effect once it is posted on Meta Box and you will not be notified separately. If you do not agree with the modifications, you shall cease to use Meta Box immediately. Use of Meta Box by you after any modification to this Agreement constitutes your acceptance of this Agreement as modified.
4. If you are under 18 years old or you are a person of no capacity for civil acts or a person of limited capacity for civil acts, please use Meta Box under the guidance of your parents or guardians.
## **II. Definition**
1. Meta Box: The blockchain wallet developed by Meta Box based on BTC/ETH/BSC/HECO/TRON/Polkadot/Kusama/EOS/COSMOS/BOS/ENU/MOAC/IOST and other blockchain systems which Meta Box may support in the future, and other supporting tools which are developed for the convenience of the Users when using blockchain systems.
2. User: a) a User must be a natural person who possesses full capacity for civil acts; b) if you are under 18 years old, please use Meta Box under the guidance of your parents or guardians. If any person of no capacity for civil acts conducts any transactions on Meta Box or any person of limited capacity for civil acts conducts any transaction which does not commensurate his/her civil rights or act capacity, the parents or guardians of the User shall be liable for the consequences of such transactions.
3. Excluded Person: a) except for natural persons, persons who have the legal and consciousness ability to conclude this Agreement; or b) users who are prohibited, restricted, unauthorized or unqualified to use the service (as defined in this Agreement) ) in any form or method (in whole or in part) due to this Agreement, laws, regulatory requirements, or the provisions of the jurisdiction applicable to the user. For the avoidance of doubt, Chinese Users are also regarded as "Excluded Person". 2.4 Terms:
    - Create or import wallet: Using Meta Box to create or import wallet after you accept this Agreement.
    - Wallet Password: The password you set when you create the wallet. The Wallet Password will be used to encrypt and protect your Private Key. Meta Box, as a decentralized application, will not store your Wallet Password on our servers, nor will your Wallet Password be stored in your own mobile devices. If you lose or forget your Wallet Password, you will have to reset the Wallet Password with your Private Key or Mnemonic Words.
Reminder: It is recommended that Users follow the relevant steps for the information prompts involved in the Meta Box operating interface.
    - Specific Users: Users who should cooperate with Meta Box and disclose Personal Information in order to comply with the laws, regulations and policies of Local country.
    - Private Key: Consists of 256 random bits. Private Key is the core for the User to hold and use the Tokens.
    - Public Key: Public key is derived from the Private Key based on cryptography and is used to generate wallet addresses. A wallet address is a public address for reception of Tokens.
    - Mnemonic Words: Consists of 12 (or 15/18/21/24) words which are randomly generated, and it is based on BIP39, the industry standard of blockchain. It is a human readable format of words to back up your Private Key for recovery.
    - Tokens: The tokens which are supported by Meta Box currently, including but not limited to ETH, EOS and so on.
    - Materials: Contents in the columns of “News”, etc. on Meta Box. The Materials are Meta Box’ proprietary properties. User shall not reproduce or distribute the materials without Meta Box’ permission and authorization.
    - Personal Information: Means information recorded in electronic or any other form which may identify a natural person when used alone or in combination with other information, including but not limited to name, date of birth, identification card number, personal biological identification information, address, telephone number, bank card number, email address, wallet address, mobile device information, operation record, transaction record, but excluding Wallet Password, Private Key, Mnemonic Words .
    - PRC: The People’s Republic of China, including Hong Kong, Macau and Taiwan.
    - Third-party services: Products and services provided by third parties such as third-party DApps, third-party DeFi, third-party smart contracts, third-party open source agreements, third-party web pages, third-party hardware wallets, third-party online web wallets, third-party exchanges, etc.
## **III. Services**
1. Create or import wallet. You may use Meta Box to create a new wallet or import wallets generated by other wallet application. You may only import wallets with Tokens which are supported by Meta Box.
2. Transfer and receive Tokens. You may manage your digital Tokens by using the transfer and reception functions of Meta Box, i.e., you may revise the blockchain ledger by signing with your Private Key. Tokens Transfer means the payer transfer the Token to the blockchain address of the payee. The actual transfer and reception of Tokens happen on the blockchain system (instead of on Meta Box).
3. Manage Tokens. You may use Meta Box to add, manage or delete the Tokens supported by Meta Box.
Browse DApps. Users may use Meta Box to visit and use the services provided by DApps (including DApps developed by Meta Box and DApps developed by third parties).
4. Transaction records. We will copy all or part of your transaction records from the blockchain system. However, Users shall refer to the blockchain system for the latest transaction records.
5. Suspension of service. You understand that we are not able to reverse or cancel the transaction because transactions based on blockchain technologies are irrevocable. However, under certain circumstances, we may suspend or limit the function of Meta Box used by a particular User.
6. Token exchange. Users can exchange tokens with third-party smart contracts or third-party DEXs. As an interface tool, Meta Box is used to help users interact with third parties and display the corresponding results of the token exchange.
7. Other services that Meta Box would like to provide.
## **IV. Users who use Meta Box must understand that:**
1. In order to keep the decentralization feature of blockchain and to protect the security of your digital Tokens, Meta Box offers decentralized service which is largely different from the banking and financial institutions. Users shall understand that Meta Box (the decentralized solution) DOES NOT provide the following services:
    - store Users’ Wallet Password (the password Users set when creating or importing wallets), Private Key, Mnemonic Words ;
    - restore Users’ Wallet Password, Private Key, Mnemonic Words ;
    - freeze the wallet;
    - report the loss of wallet;
    - restore the wallet;
    - rollback transactions.
2. Users shall take care of their mobile devices, back up the Meta Box App, and back up the Wallet Password, Mnemonic Words, Private Key  by themselves. If your mobile device is lost, your Meta Box App or your wallet is deleted and not backed up, your wallet is stolen or you forget your Wallet Password, Private Key, Mnemonic Words , Meta Box is not able to recover the wallet or restore Wallet Password, Private Key, Mnemonic Words . Nor can Meta Box cancel transactions for the mishandling of Users (such as typing in wrong addresses for transactions).
3. Meta Box does not support all existing Tokens. Do not use Meta Box to handle any non-supported Tokens.
4. Meta Box is only a tool for Users to manage their Tokens and is not an exchange or a trading platform. For the purpose of this Agreement, the word “transactions” only means transferring and receiving Tokens, which is substantially different from transactions on the exchanges and trading platforms.
5. The DApps integrated into Meta Box include those developed independently by Meta Box and those developed by third parties. Meta Box only acts as a blockchain browser for those third-party-developed DApps. Users shall, at their sole discretion, decide whether there would be any risks to accept the services provided by or to conduct transactions on the third-party-developed DApps.
## **V. Your Rights and Obligations**
1. Create or Import Wallet
    - Create or import wallet: you are entitled to use Meta Box on your mobile device to create and/or import wallet, set Wallet Password and use your wallet on Meta Box to transfer and receive Tokens on blockchain.
    - Identification verification: Specific Users will be asked to complete identification verification before using Meta Box to comply with related laws and regulations, according to the notification of Meta Box. Specific Users may be asked to provide Personal Information including but not limited to name, identification card number, cell phone number, bank card information, etc., without which the Specific Users will not be able to use certain services and the Specific Users alone shall be responsible for the loss caused by their delay in completing the verification.
    - Meta Box may develop different versions of Meta Box for different terminal devices. You shall download and install applicable version. If you download and install Meta Box or other application with the same name as “Meta Box” from any unauthorized third party, Meta Box cannot guarantee the normal operation or security of such application. Any loss caused by using such application shall be borne by you.
    - A previous version of Meta Box may stop to operate after a new version is released. Meta Box cannot guarantee the security, continuous operation or customer services for the previous version. Users shall download and use the latest version.
2. Use of Meta Box
    - Users shall take care of their mobile devices, Wallet Password, Private Key, Mnemonic Words by themselves. Meta Box does not store or hold the above information for Users. You shall be responsible for any risks, liabilities, losses and expenses which result from frauds, you losing your mobile device, disclosing (whether actively or passively) or forgetting Wallet Password, Private Key, Mnemonic Words , or your wallet being attacked.
    - Follow the Alert. You understand and agree to follow the Alert pushed by Meta Box. You shall be responsible for any risks, liabilities, losses and expenses which result from your failure to comply with the Alert.
    - You understand that Meta Box undertakes no responsibility to conduct due diligence on the services or transactions provided by third-party-developed DApps. You shall make investment decisions rationally and assume the risks by yourself.
    - Complete the identification verification. If Meta Box reasonably deems your operation or transactions to be abnormal, or considers your identification to be doubtful, or Meta Box considers it necessary to verify your identification documents or other necessary documents, you shall cooperate with Meta Box and provide your valid identification documents or other necessary documents and complete the identification verification in time.
    - With the registration method using Meta Box mobile phone number and email address (the effective decentralized solution under the EOS system), you can choose to export the private key functions to better manage your account. You are also informed that you can delete the multiple-signature Owner authority added by default and that Meta Box can no longer help you recover the private key if the authority aforementioned is deleted.
3. Transfer of Tokens
    - You understand that you may be subject to daily limits on the amount and times of transfers according to your location, regulatory requirements, transferring purposes, risk control by Meta Box, or identification verification.
    - You understand that blockchain operations are “irrevocable”. When you use Meta Box to transfer Tokens, you shall be responsible for the consequences of your mishandling of the transfer (including but not limited to wrong address, problems of the node servers selected by you).
    - You understand that the following reasons may result in “transfer failed” or “mining overtime”
        1. insufficient balance in wallet;
        2. insufficient gas for transaction;
        3. blockchain’s failure to execute the code of smart contracts;
        4. the transfer amount exceeds the transfer limits imposed by authorities, Meta Box or laws or regulations;
        5. technical failure of the network or equipment;
        6. abandoned transactions result from blockchain network congestion or failure;
        7. the wallet address of yours or your counterparty’s is identified as special addresses, such as high-risk address, exchange address, ICO address, Token address, etc.
    - You understand that Meta Box is only a tool for transfer of Tokens. Meta Box shall be deemed to have fulfilled its obligations once you have finished the transfer and shall not be held liable for any other disputes.
    -  Compliance. You understand that you shall abide by relevant laws, regulations and policies when you use Meta Box or the DApps on Meta Box.
    - Notifications. Meta Box may send notifications to you by web announcements, e-mails, text messages, phone calls, Notification Centre information, popup tips or client-end notices (e.g., information about your transfer or suggestions on certain operations) which you shall be aware of timely.
4. Service fees and taxes.
    - Meta Box does not charge you any service fees or handling fees for the time being. Meta Box may reach an agreement with you or announce rules regarding service fees in the future;
    - You need to pay gas when you transfer Tokens, the amount of which would be on your sole discretion and would be collected by certain blockchain system;
    - You understand that under some specific circumstances, your transfer of Tokens may fail due to instable network, but you may still be charged gas by certain blockchain system;
    - You shall bear all the applicable taxes and other expenses occurred due to your transactions on Meta Box.
## **VI. Risks**
1. You understand and acknowledge that the blockchain technology is a field of innovation where the laws and regulations are not fully established. You may be faced with material risks including instability of technology or failure of Tokens redemption. You also understand that Tokens have much higher volatility comparing to other financial assets. You shall make investment decisions and hold or dispose of the Tokens in a reasonable way and corresponding to your financial status and risk preferences. You also acknowledge that the market information is captured from exchanges by Meta Box and may not represent the latest or the best quotation of each Token.
2. If you or your counterparty fails to comply with this Agreement or fails to follow the instructions, tips or rules on the website or on the page of the transaction or payment, Meta Box does not guarantee successful transfer of the Tokens and Meta Box shall not be held liable for any of the consequences of such failure. If you or your counterparty has already received the payment in Meta Box wallet or third-party wallet, you understand that transactions on blockchain are irreversible and irrevocable. You and your counterparty shall assume the liabilities and consequences of your transactions.
3. You understand that blockchain operations and related transactions are irreversible. Meta Box shall not be held liable for the corresponding risks and consequences.
4. When you use third-party-developed DApps integrated in Meta Box, Meta Box strongly suggest you read this Agreement and Meta Box’s Alert carefully, get familiar with the counterparty and the product information and evaluate the risks before you make transactions on such DApps.
5. You understand that such transactions and corresponding contractual relationship are between you and your counterparty. Meta Box shall not be held liable for any risks, responsibilities, losses or expenses occurred due to such transactions.
6. It is your sole responsibility to make sure that your counterparty is a person with full capacity for civil acts and decide whether you shall transact with him/her and you assume all risks associated therewith. 
7. You shall check the official blockchain system or other blockchain tools when you receive Alert such as “transaction failed” or “mining overtime” in order to avoid repetitive transfer. If you fail to follow this instruction, you shall bear the losses and expenses occurred due to such repetitive transfer.
8. You understand that after you create or import wallet on Meta Box, your Private Key and Mnemonic Words are only stored on your mobile device and will not be stored in Meta Box or on the servers of Meta Box. You may change another mobile device to use Meta Box after you follow the instructions on Meta Box to backup your wallet. If you lose your mobile device before you could write down or backup your Wallet Password, Private Key, Mnemonic Words, you may lose your Tokens and Meta Box is unable to restore them. If your Wallet Password, Private Key, Mnemonic Words are disclosed or the device which stores or holds your Wallet Password, Private Key, Mnemonic Words  is hacked or attacked, you may lose your Tokens and Meta Box is unable to restore them. You shall bear the foregoing losses on your own.
9. We suggest you backup your Wallet Password, Private Key, Mnemonic Words when you create or import wallet by writing them down on papers or backup them in password management apps. Please do not use electronic methods such as screenshots, e-mails, note-taking apps in cell phones, text messages, WeChat or QQ to backup any of the above information.
10. In order to avoid potential security risks, we suggest you use Meta Box in a secured network environment. Please do not use a jailbreak or Rooted mobile device.
11. Please be alert to frauds when you use Meta Box. If you find any suspicious conducts, we encourage you to inform us immediately.
## **VIl. Change, Suspension, Termination of Meta Box Service**
1. You acknowledge and accept that Meta Box may, at its sole discretion, provide only a part of services for the time being, suspend certain services or provide new services in the future. When we change our services, your continuous use of Meta Box is deemed as your acceptance of this Agreement and revisions of this Agreement.
2. You understand that Meta Box may suspend services under the following circumstances:
    - due to the maintenance, upgrading, failure of equipment and blockchain system and the interruption of communications etc., which lead to the suspension of the operation of Meta Box;
    - due to force majeure events including but not limited to typhoon, earthquake, tsunami, flood, power outage, war, or terrorist attacks, or computer viruses, Trojan Horse, hacker attacks, system instability or government behaviors and other reasons, Meta Box is unable to provide services or in Meta Box’ reasonable opinion, continuous provision of services would result in significant risks;
    - due to other events which Meta Box cannot control or reasonably predicate.
    - Meta Box reserves the right to unilaterally suspend or terminate all or part of the function of Meta Box under the following circumstances:
        1. death of Users;
        2. if you steal others’ wallets information or mobile devices;
        3. if you provide false Personal Information on Meta Box or cheat on Questionnaire;
        4. if you refuse to allow mandatory update of Meta Box;
        5. if you use Meta Box to commit illegal or criminal activities;
        6. if you hinder the normal use of Meta Box by other Users;
        7. if you pretend to be staff or management personnel of Meta Box;
        8. if you threaten the normal operation of Meta Box computer system by attack, invasion, alternation or any other means;
        9. if you use Meta Box to send spams;
        10. if you spread rumors which endanger the goodwill of Meta Box and Meta Box;
        11. if you conduct any illegal activities, breach this Agreement etc. or other circumstances under which Meta Box reasonably considers necessary to suspend services.
3. You are entitled to export your wallets within a reasonable amount of time if Meta Box changes, suspends or terminates its services.
## **VIIl. Your Representations and Warranties**
1. You shall comply with all applicable laws and regulations of the country or area you reside in. You shall not use Meta Box for any unlawful purposes or by any unlawful means.
2. You shall not use Meta Box to commit any illegal or unlawful activities, including but not limited to:
    - activities opposing the basic principles set forth in the constitution, endangering national security, disclosing state secrets, overturning the government or undermining national unity;
    - any illegal conducts, such as money laundering, illegal fund raising etc.;
    - accessing Meta Box services, collecting or processing the content provided by Meta Box, intervening or attempting to intervene any Users, by the employment of any automated programs, software, network engines, web crawlers, web analytics tools, data mining tools or similar tools etc.;
    - providing gambling information or inducing others to engage in gambling;
    - invading into others’ Meta Box wallets to steal Tokens;
    - engaging in any inaccurate or false transactions with the counterparty;
    - committing any activities which harms or attempts to harm Meta Box service system and data;
    - other activities which Meta Box has reason to believe are inappropriate.
3. You understand and accept that you shall be responsible for any violation of law (including but not limited to the regulations of the Customs and Tax) or for breach of this Agreement by you and shall indemnify Meta Box against the losses, the third-party claims or administrative penalties against Meta Box incurred by such violation or breach, including reasonable attorney’s fees.
4. You are not an Excluded Person who is eligible to use the Meta Box service.
5. You confirm that you will pay the service fees charged by Meta Box in time (if applicable). Meta Box reserves the right to suspend the services when the User fails to pay service fees (if applicable).
## **IX. Privacy Policy**
Your privacy is of utmost importance for Meta Box. Please refer to Meta Box Privacy Policy as updated by us from time to time for relevant privacy protection policies.
## **X. Disclaimer and Limitation of Liability**
1. Meta Box only undertakes obligations expressly set forth in this Agreement.
2. YOU ACKNOWLEDGE AND ACCEPT THAT, TO THE MAXIMUM EXTENT PERMITTED BY APPLICABLE LAW, Meta Box IS PROVIDED ON AN “AS IS”, “AS AVAILABLE” AND “WITH ALL FAULTS” BASIS. Meta Box shall not be held liable for malfunction of Meta Box which results from the following reasons:
    - system maintenance or upgrading of Meta Box;
    - force majeure, such as typhoon, earthquake, flood, lightning or terrorist attack etc.;
    - malfunction of your mobile device hardware and software, and failure of telecommunication lines and power supply lines;
    - your improper, unauthorized or unrecognized use of Meta Box services;
    - computer viruses, Trojan Horse, malicious program attacks, network congestion, system instability, system or equipment failure, telecommunication failure, power failure, banking issues, government acts etc.;
    - any other reasons not imputed to Meta Box.
3. Meta Box shall not be held liable under the following circumstances:
    - Users lose their mobile devices, delete Meta Box applications and wallets without back-up, forget Wallet Passwords, Private Keys, Mnemonic Words without back-up, which result in the loss of their Tokens;
    - Users disclose their Wallet Passwords, Private Keys, Mnemonic Words, or lend or transfer their Meta Box wallets to others, or authorize others to use their mobile devices or Meta Box wallets, or download Meta Box applications through unofficial channels, or use Meta Box applications by other insecure means, which result in the loss of their Tokens;
    - Users mishandle Meta Box (including but not limited to wrong address, failure of the node servers selected by you), which result in the loss of Tokens;
    - Users are unfamiliar with the knowledge of blockchain and their mishandling of Meta Box results in loss of their Tokens;
    - Meta Box is unable to copy accurate transaction records due to system delay or blockchain instability etc.;
4. Under the registration method using Meta Box mobile phone number and email address (the effective decentralized solution under the EOS system), users can choose to export the private key. The property damage arising from loss or stolen private key after the user changes the authority of Owner and Active shall not be borne by Meta Box in any way.
5. Under the default mode of the registration method using Meta Box mobile phone number and email address (the effective decentralized solution under the EOS system), if the private key cannot be retrieved through mobile phone number due to the user’s causes (such as the user cannot gain a new SIM card), Meta Box will not provide the service to retrieve the private key.
6. Property loss caused by users themselves (including but not limited to loss of mobile phone number, email address, the disclosure of the verification code, publication of the private key by the user, and the user’s personal information being hacked) shall not be borne by Meta Box in any way.
7. Users shall undertake the risks and consequences of their transactions on the third-party-developed DApps. You understand that Meta Box is only a management tool for Tokens and Meta Box is incapable to control the quality, security and legitimacy of products and services provided by the third-party-developed DApps, or the authenticity and accuracy of their information and their capabilities to fulfill the obligations under the agreements with you. You, at your sole discretion, decide whether to transact on the third-party-developed DApps. It is the third-party-developed DApps, instead of Meta Box, that transact with you. We kindly remind you to carefully review the authenticity, legitimacy, and effectiveness of related information provided by the third-party-developed DApps before you decide to use the DApps. In addition, you shall also assume all the risks arising from the transactions between you and any third party exchanges.
<br>
You acknowledge that Meta Box may provide services to you and your counterparties simultaneously and you agree to waive any actual or potential conflicts of interests and will not claim against Meta Box on such base or burden Meta Box with more responsibilities or duty of care.

## **XI. Meta Box does not warrant that:**
- services provided by Meta Box would satisfy all your needs;
- all techniques, products, services, information or other materials from Meta Box would meet your expectations;
- all the transaction information in digital tokens markets captured from the third party exchanges are prompt, accurate, complete, and reliable;
- your counterparties on Meta Box will perform their obligations in the transaction agreements with you timely.
- in any case, the total liability for Meta Box under this Agreement shall not exceed the greater of:
    - 100 USDT; or
    - 100 USD, higher value shall prevail.
1. You are aware that Meta Box is only a tool for Users to manage their Tokens and to display transaction information. Meta Box does not provide legal, tax or investment advice. You shall seek advice from professional legal, tax, and investment advisors. In addition, Meta Box shall not be liable for any investment loss, data loss etc. during your use of our service.
2. You understand that we may change our entry standards, limit the range and ways to provide services for specific Users etc. at any time in accordance with relevant laws and regulations.
## **XII. Entire Agreement**
1. This Agreement incorporates Meta Box Terms of Service, Meta Box Privacy Policy, and other rules (including contents in the “Support” column) posted by Meta Box from time to time.
2. If any provision of this Agreement is found by a court with competent jurisdiction to be invalid, the other provisions of this Agreement remain in full force and effect.
3. This English version and other translated version of this Agreement (if any) are provided for the convenience of Users, and are not intended to revise the Chinese version of this Agreement. If there is any discrepancy between the Chinese version and non-Chinese version of this Agreement, the Chinese version shall prevail.
## **XIll. Intellectual Property Rights Protection**
Meta Box is an application developed and owned by Meta Box. The intellectual property rights of any contents displayed in Meta Box (including this Agreement, announcements, articles, videos, audios, images, archives, information, materials, trademarks or logos) are owned by Meta Box or the third party licensors. Users can only use the Meta Box applications and its contents for the purpose of holding and managing their Tokens. In particular, without prior written consent from Meta Box or the third party licensors, no one shall use, modify, decompile, reproduce, publicly disseminate, alter, distribute, issue or publicly publish the abovementioned applications and contents.
## **XIV. Governing Law and Dispute Resolution**
1. The validity, interpretation, alternation, enforcement, dispute resolution of this Agreement and its revised versions shall be governed and construed in accordance with the Meta Box's national laws. Where there is no applicable law, this Agreement shall be interpreted by applicable commercial and/or industrial practices.
2. If any dispute or claim in connection with this Agreement arises between you and Meta Box, the parties shall first attempt to resolve the dispute or claim through amicable negotiations in good faith. If the parties cannot reach an agreement, either party may sue the other party at the competent court where Meta Box is located.
## **XV. Miscellaneous**
1. You shall fully understand and conform to the laws, regulations and rules in your jurisdictions which are relevant to use of Meta Box services.
2. During your use of Meta Box services, if you come across any problems, you can contact us through the submission of your feedbacks on Meta Box.
3. This Agreement is accessible for all Users on Meta Box. We encourage you to read this Agreement each time you log onto Meta Box.
<br><br>
>This Agreement shall become effective on May 25th, 2023.

>As for any issues not covered in this Agreement, you shall comply with the announcements and relevant rules as updated by Meta Box from time to time.

<br>

<br><br><br>

# 《Meta Box Privacy Policy》
>Last Updated: May 25, 2023.

Dear Users,<br>
Future Development Metaverse (Meta Box)Foundation. (“Meta Box” or “we”) respects and protects the privacy of Users (“you” or “Users”). Meta Box will collect and use your Personal Information generated from your use of Meta Box in accordance with this Privacy Policy (“Policy”).

Meta Box recommends that you shall carefully read and understand the whole contents of this Policy before your use of the product (“Meta Box”). Additionally, significant information including the Disclaimer is in bold form in this Policy. Definitions of key words in this Policy are consistent with those in the Meta Box Terms of Service of Meta Box.

Meta Box reserves the right to update this Policy online from time to time, and the new policy will immediately replace the older one once posted. In particular, if you do not accept the revised policies, please immediately stop your use of Meta Box. Your continuous use of Meta Box will be regarded as your acceptance of the revised policy. Furthermore, the revised policies will take into effect immediately upon being posted on Meta Box.

You acknowledge and accept that this Policy and other relevant rules apply to Meta Box and the DApps owned by Meta Box on Meta Box.

## **Ⅰ.Information We Collect**

We collect your information in order to provide the services you requested on Meta Box, and we highly value the protection for your privacy. We strictly abide by the principle of “lawful, justifiable and necessary” during our collection of your information. You acknowledge that, if you do not provide us with necessary information, your user experiences on Meta Box may be influenced.

We may collect your Personal Information, including but not limited to your mobile device information, operation records, transaction records and wallet addresses.
1. In order to satisfy your needs for specific services, we may collect your name, bank card number, telephone number (Mobile phone number registration method), email address (Email registration method), etc.
2. You confirm that your Wallet Password, Private Key, Mnemonic Words on Meta Box (the decentralized solution) are not stored or synchronized on Meta Box’ servers. Meta Box does not offer the service to restore your Wallet Password, Private Key, Mnemonic Words .
3. Apart from the foregoing provisions, when you are using specific function of Meta Box, we may give you special notification to ask for more Personal Information.
4. After you link to the third-party-developed DApps from Meta Box, your Personal Information will be collected and held by the third-party-developed DApps instead of being collected or held by Meta Box. When you fill in your Personal Information on a third-party-developed DApp, you should pay attention to the Terms of Use and Privacy Policy of the third-party-developed DApp. We are not accountable for any losses caused by your operation on the third-party-developed DApp.
5. To the extent permitted by laws and regulations, Meta Box may collect and use following Personal Information without your prior consent or authorization:
    - information related to national security and national defense;
    - information related to public security, public health, significant public interests;
    - information related to criminal investigation, prosecution, trial and enforcement;
    - the Personal Information collected is publicized by yourself;
    - the Personal Information is collected from legally publicly disclosed information, such as legal news reports, government information disclosure and other channels;
    - the Personal Information is necessary to maintain the security and compliance of services, such as to detect or to solve the malfunction of products and services;
    - other circumstances prescribed by laws and regulations. We collect information in the following ways:
        1. Information you give us. For example, you fill in your name, telephone number, or bank card number in “My Account” column or you provide your email address when submitting feedbacks, or you give extra information to us when you use our specific services.
        2. we collect information during your use of Meta Box, including your mobile devices information and your operation records on Meta Box, etc.
## **Ⅱ.How We Use Your Information**
1. We may associate you with your wallet by the unique serial number of your mobile device.
2. We may promptly push important notifications to you, such as software update, update of Terms of Service and this Policy.
3. We offer you the “Touch ID” option in the “Settings” column of Meta Box to provide you with a convenient and safe way to manage your digital Tokens.
4. We deal with your feedbacks by using the Wallet Address and the mobile device information provided by you.
5. We may collect your Personal Information to conduct our internal audit, data analysis and research etc. to enhance our services.
6. According to Meta Box Terms of Service and other rules of Meta Box, Meta Box will manage and handle the use behaviors of Users through Users’ information.
7. We may use your information in accordance with laws, regulations and to cooperate with regulatory authorities.
## **Ⅲ.How You Control Your Own Information**
You are entitled to control your Personal Information provided to Meta Box:
1. You may import your other wallets into Meta Box through synchronization of wallets and you may export your wallets from Meta Box to other Tokens management wallets.
2. Meta Box will display the information of imported wallets to you. You may add or delete Tokens, transfer and collect Tokens using the “Assets” column.
3. You understand that you may handle the following operations in the “Me” column on Meta Box:
    - in the “Address Book” column, you may view and edit your “Contacts”;
    - in the “Settings” column, you may choose not to open “Unlock Setting”, which means you may refuse to use the verification service to enter Meta Box;
    - in the “Profile” column, you do not have to provide your name, telephone number, bank card number information. But if you wish to use specific services, you may need to provide the foregoing information;
    - in the “Help” column, you may submit any questions or suggestions for Meta Box at any time. We are glad to communicate with you to improve our services.
4. When we collect information from you for a specific purpose, we will ask for your consent in advance to which you are entitled to refuse. However, you understand that when you refuse to give such consent, you also give up the choice to use specific services provided by Meta Box.
5. You acknowledge that since blockchain is an open source system, your transaction records are automatically public and transparent in the whole blockchain.
6. You understand that after you link to the third-party-developed DApps from Meta Box, the Meta Box Terms of Service and Meta Box Privacy Policy will no longer apply. You are encouraged to carefully review its privacy policies and related terms of service before you start to use the third-party-developed DApps.
7. You are entitled to ask us to update, revise, and delete your relevant information.
8. We reserve the right to collect your information without your prior authorization or consent according to the Article 7 of Section 1 of this Policy.
## **Ⅳ.Information We may Share or Transfer**
1. The Personal Information collected by Meta Box for business and legal purposes
2. The Personal Information will not be sold, traded or transferred to the third parties without your consent.
3. The Personal Information may be disclosed to these entities if you agree to our disclosure of the personal information to strategic partners or related parties. These entities will only use your personal information for the purposes you have agreed to.
4. You agree that we may disclose or share your personal information to the following third parties:       a. service providers and data processors who represent us and provide services to us, such as KYC inspections, accounting, data processing or management services, website hosting, maintenance and operation services, mail information services, analysis services, and payment transaction processing, marketing, etc.;       b. Meta Box consultants and professional consultants (such as accountants, lawyers, auditors).
5. The Personal Information may be transferred to any other country for the above-mentioned purposes. Meta Box will obtain your consent and ensure that the recipient of personal information has the same level of personal information protection measures as Meta Box. If there is no personal information protection law applicable to the relationship between Meta Box and you in these countries or regions, we will sign a legally enforceable agreement with the receivers of personal information.
6. Meta Box will not share with or transfer your Personal Information to any third party without your prior consent, except for the following circumstances:
    - the collected Personal Information is publicized by yourself;
    - the Personal Information is collected from public information which was legally disclosed, such as news (lawfully reported), government information disclosure and other channels;
    - we may share your Personal Information with our affiliates only when necessary and to the extent permitted by this Policy;
    - in order to abide by applicable laws, regulations, legal procedures, and administrative or judiciary authorities, Meta Box will provide or implement this Policy to protect our or other parties' rights, assets or security;
    - in the case of mergers and acquisitions, if transfer of Personal Information is involved, Meta Box may require the receivers of Personal Information to be continuously bound by this Policy.
## **Ⅴ.How We Collect Data Automatically**
1. We use automatic data collection technology in the application. E.g:
   - cookies (or browser cookies). Cookies are small text files set by the operator of a website or application to identify your browser or device. We may use cookies on our apps to store and track information, such as the number and frequency of use of users, user distribution, and users' online preferences. Cookies do not capture information that can identify you, but the information they collect can help us analyze the usage of the application to improve your experience. You can turn off cookies in your browser settings. However, this may affect the functionality of the application.
   - network analysis. Web analytics is a method of collecting and evaluating the operation of visitors to web pages and mobile applications. This includes analyzing traffic patterns, such as determining the frequency of visits to certain functions of a website or mobile application, or to understand the information or services that visitors are most interested in. We use network analysis services provided by third-party tools.
## **Ⅵ.How We Protect Your Information**
1. If Meta Box terminates operation, Meta Box will stop the collection of your Personal Information in time, post the announcement on Meta Box and delete or anonymize your Personal Information held by us within a reasonable period.
2. To protect your Personal Information, Meta Box may adopt data security techniques, improve internal compliance levels, provide security training for our staff, and set security authority for access to relevant data to protect your Personal Information.
3. We will send you messages about information security in the “Wallet Guide” column and update articles concerning the use of wallets and information protection in the “Wallet Guide” column on Meta Box for your reference.
## **Ⅶ.Protection for the Minors**
The following special provisions apply to minors who are under the age of 18 years old:
1. The minors shall not use Meta Box without the guidance from their parents or guardians.
2. The parents and guardians of the minors shall provide guidance to the minors on using Meta Box after they read this Policy, Meta Box Terms of Service and other relevant rules.
3. Meta Box will ensure the confidentiality and security of the minors’ Personal Information in accordance with national laws and regulations.
## **Ⅷ.Disclaimer**
1. After you link to the third-party-developed DApps from Meta Box, the privacy policies of the third-party-developed DApps will apply. The collection and use of your Personal Information by the third-party-developed DApps will be controlled neither by Meta Box, nor by this Policy.
2. You shall carefully select and use the third-party-developed DApps and protect your Personal Information. Meta Box shall not be held liable for the privacy protection obligation of any third-party-developed DApps.
3. You acknowledge and accept that, to the maximum extent permitted by applicable law, Meta Box will adopt measures as reasonable as possible to protect your Personal Information under current techniques on an “as is”, “as available” and “with all faults” basis, to avoid the disclosure, tampering or damage of information. since Meta Box transfers data wirelessly, Meta Box makes no guarantee on the privacy and security of wireless internet data transferring.
## **Ⅸ.Miscellaneous**
1. As a company that provides services to you, we will not actively provide your Personal Information to third parties other than the agreement, unless we obtain your consent and inform the other party's identity, contact information, processing purpose, processing method, etc. If there is service demand of processing your personal sensitive information in the future, we will ask your opinions once again, and use it after obtaining your consent.
2. You shall fully understand and conform to the laws, regulations and rules in your jurisdictions which are relevant to use of Meta Box.
3. During your use of Meta Box services, if you come across any problems related to your Personal Information use, you may contact us through the submission of your feedbacks on Meta Box.
4. You may access this Policy and other service rules of Meta Box on Meta Box. We encourage you to check the Terms of Service and Privacy Policy of Meta Box each time you log into Meta Box.
5. This English version and other translated versions of this Policy are provided for the convenience of Users, and are not intended to revise the original Chinese version of this Policy. If there is any discrepancy between the Chinese version and non-Chinese version of this Policy, the Chinese version shall prevail.
<br><br>

>This Policy shall become effective on October 29, 2022.
>As for any issues not covered in this Policy, you shall comply with the announcements and relevant rules as updated by Meta Box from time to time.

<br>

