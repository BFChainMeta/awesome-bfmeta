import{r as s}from"./index-C42ND1zV.js";const o=()=>{const[,e]=s.useReducer(r=>r+1,0);return e};export{o as u};
