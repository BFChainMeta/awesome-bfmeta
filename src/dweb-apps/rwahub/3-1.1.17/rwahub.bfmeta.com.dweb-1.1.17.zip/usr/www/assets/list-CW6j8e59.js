import{a as s}from"./list-Bwnv5ptc.js";const o=s;export{o as L};
