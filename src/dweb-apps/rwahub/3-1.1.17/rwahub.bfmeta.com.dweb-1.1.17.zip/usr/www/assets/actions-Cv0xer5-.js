import{f as o,A as a}from"./index-C42ND1zV.js";await o.loadModule(a);
