import{i}from"./core-DcRBow3U.js";import"./page-MzH5tNa6.js";const a=async t=>{await i.write({string:t})},o=async t=>{await a(t)};export{o as w};
