import{f as o,A as a}from"./index-q-w6H-Hb.js";await o.loadModule(a);
