import{U as r}from"./page-DYIukvy6.js";import{R as o}from"./index-q-w6H-Hb.js";const m=e=>o.createElement(r,{size:24,...e});export{m as P};
