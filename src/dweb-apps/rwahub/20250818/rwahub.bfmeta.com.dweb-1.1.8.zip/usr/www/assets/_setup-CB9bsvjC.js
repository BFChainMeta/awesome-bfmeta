import{p}from"./sha256-Cd0hi-1H.js";const a=async()=>{await p.prepare()};export{a as p};
