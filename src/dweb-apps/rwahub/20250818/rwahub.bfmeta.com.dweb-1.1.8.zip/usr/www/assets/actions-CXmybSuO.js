import{f as o,A as a}from"./index-CzLCOEc-.js";await o.loadModule(a);
