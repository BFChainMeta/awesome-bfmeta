import{w as r}from"./page-xjPDDURg.js";import{R as o}from"./index-CzLCOEc-.js";const m=e=>o.createElement(r,{size:24,...e});export{m as P};
