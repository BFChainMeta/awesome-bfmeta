import{i}from"./core-C9peAr6i.js";import"./page-xjPDDURg.js";const a=async t=>{await i.write({string:t})},o=async t=>{await a(t)};export{o as w};
