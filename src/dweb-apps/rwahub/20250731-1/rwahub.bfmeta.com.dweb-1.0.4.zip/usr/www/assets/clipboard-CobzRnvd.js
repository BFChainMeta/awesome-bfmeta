import{i}from"./core-BPSTTWcB.js";import"./page-Bl-tRae3.js";const a=async t=>{await i.write({string:t})},o=async t=>{await a(t)};export{o as w};
