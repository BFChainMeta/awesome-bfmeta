import{Q as r}from"./page-Bl-tRae3.js";import{R as o}from"./index-Cy6ZAnWN.js";const m=e=>o.createElement(r,{size:24,...e});export{m as P};
