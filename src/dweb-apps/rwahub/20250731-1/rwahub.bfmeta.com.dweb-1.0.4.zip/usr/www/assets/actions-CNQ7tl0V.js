import{f as o,A as a}from"./index-Cy6ZAnWN.js";await o.loadModule(a);
