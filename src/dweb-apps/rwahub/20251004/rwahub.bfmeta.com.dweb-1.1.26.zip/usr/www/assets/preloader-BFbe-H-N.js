import{K as r}from"./page-DVomCvlZ.js";import{R as o}from"./index-DZ6a9ydY.js";const m=e=>o.createElement(r,{size:24,...e});export{m as P};
