import{f as o,A as a}from"./index-DZ6a9ydY.js";await o.loadModule(a);
