import{i}from"./core-BfU6YOts.js";import"./page-DVomCvlZ.js";const a=async t=>{await i.write({string:t})},o=async t=>{await a(t)};export{o as w};
