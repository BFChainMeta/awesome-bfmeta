import{L as s}from"./list-BUCgTFAc.js";const o=s;export{o as L};
