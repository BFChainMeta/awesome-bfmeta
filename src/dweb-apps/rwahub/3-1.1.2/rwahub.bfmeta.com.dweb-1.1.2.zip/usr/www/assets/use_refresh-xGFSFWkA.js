import{r as s}from"./index-B2YFRYm6.js";const o=()=>{const[,e]=s.useReducer(r=>r+1,0);return e};export{o as u};
