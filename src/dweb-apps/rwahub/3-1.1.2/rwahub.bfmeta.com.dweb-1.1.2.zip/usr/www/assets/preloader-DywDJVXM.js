import{U as r}from"./page-ztMcKQiB.js";import{R as o}from"./index-B2YFRYm6.js";const m=e=>o.createElement(r,{size:24,...e});export{m as P};
