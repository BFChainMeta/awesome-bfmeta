import{f as o,A as a}from"./index-B2YFRYm6.js";await o.loadModule(a);
