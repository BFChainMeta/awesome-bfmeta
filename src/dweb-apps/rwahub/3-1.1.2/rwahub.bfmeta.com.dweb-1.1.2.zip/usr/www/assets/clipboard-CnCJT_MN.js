import{i}from"./core-C3e8D2V9.js";import"./page-ztMcKQiB.js";const a=async t=>{await i.write({string:t})},o=async t=>{await a(t)};export{o as w};
