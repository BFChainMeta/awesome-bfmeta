import{p}from"./sha256-DOV6WrQa.js";const a=async()=>{await p.prepare()};export{a as p};
