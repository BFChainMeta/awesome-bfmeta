import{w as r}from"./page-Dg7R8KhB.js";import{R as o}from"./index-DwO_GzE9.js";const m=e=>o.createElement(r,{size:24,...e});export{m as P};
