import{i}from"./core-DNQFS_G_.js";import"./page-Dg7R8KhB.js";const a=async t=>{await i.write({string:t})},o=async t=>{await a(t)};export{o as w};
