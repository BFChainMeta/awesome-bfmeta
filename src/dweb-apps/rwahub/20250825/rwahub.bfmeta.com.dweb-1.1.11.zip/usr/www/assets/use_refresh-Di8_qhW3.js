import{r as s}from"./index-DwO_GzE9.js";const o=()=>{const[,e]=s.useReducer(r=>r+1,0);return e};export{o as u};
