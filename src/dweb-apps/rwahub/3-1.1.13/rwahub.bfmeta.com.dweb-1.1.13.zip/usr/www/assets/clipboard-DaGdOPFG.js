import{i}from"./core-D_qJQYWT.js";import"./page-CeNEZumH.js";const a=async t=>{await i.write({string:t})},o=async t=>{await a(t)};export{o as w};
