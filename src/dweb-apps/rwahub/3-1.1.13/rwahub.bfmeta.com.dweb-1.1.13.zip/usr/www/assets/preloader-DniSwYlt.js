import{w as r}from"./page-CeNEZumH.js";import{R as o}from"./index-Dr7HfBQ_.js";const m=e=>o.createElement(r,{size:24,...e});export{m as P};
