import{f as o,A as a}from"./index-Dr7HfBQ_.js";await o.loadModule(a);
