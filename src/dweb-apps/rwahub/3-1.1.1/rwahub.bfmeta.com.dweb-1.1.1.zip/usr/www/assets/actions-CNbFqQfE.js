import{f as o,A as a}from"./index-D8mKQx5l.js";await o.loadModule(a);
