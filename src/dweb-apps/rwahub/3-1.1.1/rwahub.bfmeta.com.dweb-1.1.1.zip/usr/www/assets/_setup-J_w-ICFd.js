import{p}from"./sha256-ExQy6aei.js";const a=async()=>{await p.prepare()};export{a as p};
