import{i}from"./core-DhZ2GLi8.js";import"./page-EYqFyeXj.js";const a=async t=>{await i.write({string:t})},o=async t=>{await a(t)};export{o as w};
