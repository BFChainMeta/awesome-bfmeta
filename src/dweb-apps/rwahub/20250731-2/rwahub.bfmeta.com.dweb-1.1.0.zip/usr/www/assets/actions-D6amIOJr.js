import{f as o,A as a}from"./index-CA9686xj.js";await o.loadModule(a);
