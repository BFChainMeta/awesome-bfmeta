import{p}from"./sha256-DxPZT4yL.js";const a=async()=>{await p.prepare()};export{a as p};
