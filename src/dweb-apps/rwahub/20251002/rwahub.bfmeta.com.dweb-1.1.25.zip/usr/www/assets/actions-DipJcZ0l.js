import{f as o,A as a}from"./index-BwRZnk8c.js";await o.loadModule(a);
