import{i}from"./core-Bh7bNFcn.js";import"./page-CgLREsSv.js";const a=async t=>{await i.write({string:t})},o=async t=>{await a(t)};export{o as w};
