import{K as r}from"./page-CgLREsSv.js";import{R as o}from"./index-BwRZnk8c.js";const m=e=>o.createElement(r,{size:24,...e});export{m as P};
