import{L as s}from"./list-D3ZcRnCi.js";const o=s;export{o as L};
