import{C as o,w as g}from"./page-yEMZEOwg.js";import{R as a}from"./index-D52eEuMs.js";let i={};const w=t=>{i=t},h=(t,r)=>{const e={ETH:o.Ethereum,BSC:o.Binance,TRON:o.Tron,BFCHAINV2:o.BFChainV2,BFMCHAIN:o.BFMeta,CCCHAIN:o.CCChain,PMCHAIN:o.PMChain,ETHMETA:o.ETHMeta,BTGMETA:o.BTGMeta,BIWMETA:o.BIWMeta,MALIBU:o.Malibu};r in e&&(r=e[r]);const n=i[r];if(n)return n[t]},B=(t,r)=>{const e=h(t,r);return e||d(t)},A=t=>`./images/icon_${t}.webp`,d=t=>{const r=t.charAt(0);let e=0;for(let s=0;s<t.length;s++)e=t.charCodeAt(s)+((e<<5)-e);const n=`hsl(${Math.abs(e)%360}, 70%, 45%)`,l=`hsl(${(Math.abs(e)+120)%360}, 70%, 30%)`,c=`
                <svg xmlns="http://www.w3.org/2000/svg" width="200" height="200" viewBox="0 0 200 200">
                    <defs>
                        <linearGradient id="gradient" x1="0%" y1="0%" x2="100%" y2="100%">
                            <stop offset="0%" stop-color="${n}" />
                            <stop offset="100%" stop-color="${l}" />
                        </linearGradient>
                    </defs>
                    <rect width="200" height="200" fill="url(#gradient)" rx="15" />
                    <text 
                        x="100" 
                        y="115" 
                        font-family="Arial, sans-serif" 
                        font-size="80" 
                        font-weight="bold" 
                        fill="white" 
                        text-anchor="middle"
                        dominant-baseline="middle"
                        stroke="rgba(0,0,0,0.2)"
                        stroke-width="2"
                    >
                        ${r}
                    </text>
                </svg>
            `,f=new Blob([c],{type:"image/svg+xml;charset=utf-8"});return URL.createObjectURL(f)},C=t=>a.createElement(g,{size:24,...t}),I=t=>a.createElement("div",{className:"flex h-32 w-full items-center justify-center"},a.createElement(C,{size:32,...t}));export{I as L,C as P,A as a,B as g,w as s};
