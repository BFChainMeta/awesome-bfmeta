import{f as o,D as a}from"./index-D52eEuMs.js";const l=o.dialog;await o.loadModule(a);export{l as d};
