import{p}from"./sha256-C85DvC6X.js";const a=async()=>{await p.prepare()};export{a as p};
