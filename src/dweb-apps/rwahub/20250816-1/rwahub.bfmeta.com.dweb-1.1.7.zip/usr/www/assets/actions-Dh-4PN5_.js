import{f as o,A as a}from"./index-Cyh-Mz5A.js";await o.loadModule(a);
