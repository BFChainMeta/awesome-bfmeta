import{w as r}from"./page-CtUwm1MR.js";import{R as o}from"./index-Cyh-Mz5A.js";const m=e=>o.createElement(r,{size:24,...e});export{m as P};
