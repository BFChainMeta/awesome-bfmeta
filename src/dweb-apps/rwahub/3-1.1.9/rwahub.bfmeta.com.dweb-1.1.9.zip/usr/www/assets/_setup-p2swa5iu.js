import{p}from"./sha256-C_vW9y1h.js";const a=async()=>{await p.prepare()};export{a as p};
