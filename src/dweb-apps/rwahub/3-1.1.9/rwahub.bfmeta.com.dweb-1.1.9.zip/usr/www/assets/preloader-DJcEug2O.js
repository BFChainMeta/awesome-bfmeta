import{w as r}from"./page-CCNmD7aV.js";import{R as o}from"./index-DPfF-MVl.js";const m=e=>o.createElement(r,{size:24,...e});export{m as P};
