import{f as o,A as a}from"./index-DPfF-MVl.js";await o.loadModule(a);
