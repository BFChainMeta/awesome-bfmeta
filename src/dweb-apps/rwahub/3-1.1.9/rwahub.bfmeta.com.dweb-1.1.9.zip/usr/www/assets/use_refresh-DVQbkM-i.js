import{r as s}from"./index-DPfF-MVl.js";const o=()=>{const[,e]=s.useReducer(r=>r+1,0);return e};export{o as u};
