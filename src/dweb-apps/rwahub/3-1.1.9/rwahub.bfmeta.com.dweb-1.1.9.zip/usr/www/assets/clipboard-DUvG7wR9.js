import{i}from"./core-pYb5rltD.js";import"./page-CCNmD7aV.js";const a=async t=>{await i.write({string:t})},o=async t=>{await a(t)};export{o as w};
