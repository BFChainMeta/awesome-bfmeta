import{p}from"./sha256-TncPWb1l.js";const a=async()=>{await p.prepare()};export{a as p};
