import{f as o,D as a}from"./index-DBos7hTi.js";const l=o.dialog;await o.loadModule(a);export{l as d};
