import{f as o,A as a}from"./index-oCczNEE0.js";await o.loadModule(a);
