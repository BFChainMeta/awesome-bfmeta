import{L as s}from"./list-D6fJ9hrP.js";const o=s;export{o as L};
