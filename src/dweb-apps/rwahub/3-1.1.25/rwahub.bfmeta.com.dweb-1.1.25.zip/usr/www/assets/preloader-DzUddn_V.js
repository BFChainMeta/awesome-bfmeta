import{K as r}from"./page-cl5BucRv.js";import{R as o}from"./index-oCczNEE0.js";const m=e=>o.createElement(r,{size:24,...e});export{m as P};
