import{i}from"./core-DpSbX-sz.js";import"./page-cl5BucRv.js";const a=async t=>{await i.write({string:t})},o=async t=>{await a(t)};export{o as w};
