import{C as e,p as C}from"./page-yn4gz3mK.js";import{R as s}from"./index-DFih5xAl.js";let l={};const w=t=>{l=t},h=(t,o)=>{const n={ETH:e.Ethereum,BSC:e.Binance,TRON:e.Tron,BFCHAINV2:e.BFChainV2,BFMCHAIN:e.BFMeta,CCCHAIN:e.CCChain,PMCHAIN:e.PMChain,ETHMETA:e.ETHMeta,BTGMETA:e.BTGMeta,BIWMETA:e.BIWMeta,MALIBU:e.Malibu};o in n&&(o=n[o]);const r=l[o];if(r)return r[t]},i={"BFMeta-BFM":"./images/token/BFMeta-BFM.png","BFMeta-DEXT":"./images/token/BFMeta-DEXT.png","BFMeta-CPCC":"./images/token/BFMeta-CPCC.png"},A=(t,o,n)=>{if(i[`${o}-${t}`])return i[`${o}-${t}`];const r=h(t,o);return r||n||M(t)},E=t=>`./images/icon_${t}.webp`,M=t=>{const o=t.charAt(0);let n=0;for(let a=0;a<t.length;a++)n=t.charCodeAt(a)+((n<<5)-n);const r=`hsl(${Math.abs(n)%360}, 70%, 45%)`,c=`hsl(${(Math.abs(n)+120)%360}, 70%, 30%)`,g=`
                <svg xmlns="http://www.w3.org/2000/svg" width="200" height="200" viewBox="0 0 200 200">
                    <defs>
                        <linearGradient id="gradient" x1="0%" y1="0%" x2="100%" y2="100%">
                            <stop offset="0%" stop-color="${r}" />
                            <stop offset="100%" stop-color="${c}" />
                        </linearGradient>
                    </defs>
                    <rect width="200" height="200" fill="url(#gradient)" rx="15" />
                    <text 
                        x="100" 
                        y="115" 
                        font-family="Arial, sans-serif" 
                        font-size="80" 
                        font-weight="bold" 
                        fill="white" 
                        text-anchor="middle"
                        dominant-baseline="middle"
                        stroke="rgba(0,0,0,0.2)"
                        stroke-width="2"
                    >
                        ${o}
                    </text>
                </svg>
            `,f=new Blob([g],{type:"image/svg+xml;charset=utf-8"});return URL.createObjectURL(f)},d=t=>s.createElement(C,{size:24,...t}),F=t=>s.createElement("div",{className:"flex h-32 w-full items-center justify-center"},s.createElement(d,{size:32,...t}));export{F as L,d as P,E as a,A as g,w as s};
