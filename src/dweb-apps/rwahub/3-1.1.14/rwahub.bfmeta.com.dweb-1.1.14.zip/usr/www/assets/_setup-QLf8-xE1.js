import{p}from"./sha256-Bx5uJdNy.js";const a=async()=>{await p.prepare()};export{a as p};
