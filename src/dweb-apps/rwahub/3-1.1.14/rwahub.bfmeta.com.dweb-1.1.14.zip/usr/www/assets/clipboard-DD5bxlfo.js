import{i}from"./core-BGdpX8Vi.js";import"./page-U5sdITlH.js";const a=async t=>{await i.write({string:t})},o=async t=>{await a(t)};export{o as w};
