import{j as o}from"./index-CzR53FE8.js";import{K as e}from"./page-Cie65gcI.js";const a=r=>o.jsx(e,{size:24,...r});export{a as P};
