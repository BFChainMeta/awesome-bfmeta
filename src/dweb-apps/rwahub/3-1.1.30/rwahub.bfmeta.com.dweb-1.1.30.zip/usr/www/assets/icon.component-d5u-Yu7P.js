import{r as h,j as i}from"./index-CzR53FE8.js";import{C as r}from"./page-Cie65gcI.js";const b=`{
  "common-add": [
    {
      "char": "",
      "style": {
        "zIndex": 0,
        "color": "var(--color-1, rgb(255, 255, 255))"
      }
    }
  ],
  "common-next": [
    {
      "char": "",
      "style": {
        "zIndex": 0,
        "color": "var(--color-1, rgb(255, 255, 255))"
      }
    }
  ],
  "common-camera": [
    {
      "char": "",
      "style": {
        "zIndex": 0,
        "color": "var(--color-1, rgb(255, 255, 255))"
      }
    }
  ],
  "common-certification": [
    {
      "char": "",
      "style": {
        "zIndex": 0,
        "color": "var(--color-1, rgb(255, 255, 255))"
      }
    }
  ],
  "common-back": [
    {
      "char": "",
      "style": {
        "zIndex": 0,
        "color": "var(--color-1, rgb(255, 255, 255))"
      }
    }
  ],
  "common-enter": [
    {
      "char": "",
      "style": {
        "zIndex": 0,
        "color": "var(--color-1, rgb(255, 255, 255))"
      }
    }
  ],
  "common-close-fill": [
    {
      "char": "",
      "style": {
        "zIndex": 0,
        "color": "var(--color-1, rgb(248, 50, 74))"
      }
    },
    {
      "char": "",
      "style": {
        "zIndex": 1,
        "color": "var(--color-2, rgb(255, 255, 255))"
      }
    },
    {
      "char": "",
      "style": {
        "zIndex": 2,
        "color": "var(--color-3, rgb(255, 255, 255))"
      }
    }
  ],
  "common-close": [
    {
      "char": "",
      "style": {
        "zIndex": 0,
        "color": "var(--color-1, rgb(255, 255, 255))"
      }
    }
  ],
  "common-help": [
    {
      "char": "",
      "style": {
        "zIndex": 0,
        "color": "var(--color-1, rgb(255, 255, 255))"
      }
    }
  ],
  "common-like": [
    {
      "char": "",
      "style": {
        "zIndex": 0,
        "color": "var(--color-1, rgb(255, 255, 255))"
      }
    }
  ],
  "common-hidden": [
    {
      "char": "",
      "style": {
        "zIndex": 0,
        "color": "var(--color-1, rgb(255, 255, 255))"
      }
    }
  ],
  "common-visible": [
    {
      "char": "",
      "style": {
        "zIndex": 0,
        "color": "var(--color-1, rgb(255, 255, 255))"
      }
    }
  ],
  "common-delete": [
    {
      "char": "",
      "style": {
        "zIndex": 0,
        "color": "var(--color-1, rgb(255, 255, 255))"
      }
    }
  ],
  "common-copy": [
    {
      "char": "",
      "style": {
        "zIndex": 0,
        "color": "var(--color-1, rgb(255, 255, 255))"
      }
    }
  ],
  "common-invitation": [
    {
      "char": "",
      "style": {
        "zIndex": 0,
        "color": "var(--color-1, rgb(255, 255, 255))"
      }
    }
  ],
  "common-language": [
    {
      "char": "",
      "style": {
        "zIndex": 0,
        "color": "var(--color-1, rgb(255, 255, 255))"
      }
    }
  ],
  "common-location": [
    {
      "char": "",
      "style": {
        "zIndex": 0,
        "color": "var(--color-1, rgb(255, 255, 255))"
      }
    }
  ],
  "common-replay": [
    {
      "char": "",
      "style": {
        "zIndex": 0,
        "color": "var(--color-1, rgb(255, 255, 255))"
      }
    }
  ],
  "common-order": [
    {
      "char": "",
      "style": {
        "zIndex": 0,
        "color": "var(--color-1, rgb(255, 255, 255))"
      }
    }
  ],
  "common-passcode": [
    {
      "char": "",
      "style": {
        "zIndex": 0,
        "color": "var(--color-1, rgb(255, 255, 255))"
      }
    }
  ],
  "common-upgrade": [
    {
      "char": "",
      "style": {
        "zIndex": 0,
        "color": "var(--color-1, rgb(255, 255, 255))"
      }
    }
  ],
  "common-website": [
    {
      "char": "",
      "style": {
        "zIndex": 0,
        "color": "var(--color-1, rgb(255, 255, 255))"
      }
    }
  ],
  "common-authenticate": [
    {
      "char": "",
      "style": {
        "zIndex": 0,
        "color": "var(--color-1, rgb(5, 213, 247))"
      }
    }
  ],
  "common-identity": [
    {
      "char": "",
      "style": {
        "zIndex": 0,
        "color": "var(--color-1, rgb(255, 255, 255))"
      }
    }
  ],
  "common-join": [
    {
      "char": "",
      "style": {
        "zIndex": 0,
        "color": "var(--color-1, rgb(255, 255, 255))"
      }
    }
  ],
  "common-messages": [
    {
      "char": "",
      "style": {
        "zIndex": 0,
        "color": "var(--color-1, rgb(255, 255, 255))"
      }
    }
  ],
  "common-unselected": [
    {
      "char": "",
      "style": {
        "zIndex": 0,
        "color": "var(--color-1, rgb(255, 255, 255))"
      }
    }
  ],
  "common-pic-failed": [
    {
      "char": "",
      "style": {
        "zIndex": 0,
        "color": "var(--color-1, rgb(168, 180, 191))"
      }
    }
  ],
  "common-register": [
    {
      "char": "",
      "style": {
        "zIndex": 0,
        "color": "var(--color-1, rgb(255, 255, 255))"
      }
    }
  ],
  "common-filter": [
    {
      "char": "",
      "style": {
        "zIndex": 0,
        "color": "var(--color-1, rgb(255, 255, 255))"
      }
    }
  ],
  "common-select-fill": [
    {
      "char": "",
      "style": {
        "zIndex": 0,
        "color": "var(--color-1, rgb(0, 205, 151))"
      }
    },
    {
      "char": "",
      "style": {
        "zIndex": 1,
        "color": "var(--color-2, rgb(255, 255, 255))"
      }
    }
  ],
  "common-selected": [
    {
      "char": "",
      "style": {
        "zIndex": 0,
        "color": "var(--color-1, rgb(255, 255, 255))"
      }
    }
  ],
  "common-setting": [
    {
      "char": "",
      "style": {
        "zIndex": 0,
        "color": "var(--color-1, rgb(255, 255, 255))"
      }
    }
  ],
  "common-retreat": [
    {
      "char": "",
      "style": {
        "zIndex": 0,
        "color": "var(--color-1, rgb(255, 255, 255))"
      }
    }
  ],
  "abchina-pay": [
    {
      "char": "",
      "style": {
        "zIndex": 0,
        "color": "var(--color-1, rgb(0, 146, 115))"
      }
    }
  ],
  "wechat-pay": [
    {
      "char": "",
      "style": {
        "zIndex": 0,
        "color": "var(--color-1, rgb(255, 255, 255))"
      }
    },
    {
      "char": "",
      "style": {
        "zIndex": 1,
        "color": "var(--color-2, rgb(70, 175, 57))"
      }
    }
  ],
  "china-union-pay": [
    {
      "char": "",
      "style": {
        "zIndex": 0,
        "color": "var(--color-1, rgb(0, 144, 140))"
      }
    },
    {
      "char": "",
      "style": {
        "zIndex": 1,
        "color": "var(--color-2, rgb(230, 0, 18))"
      }
    },
    {
      "char": "",
      "style": {
        "zIndex": 2,
        "color": "var(--color-3, rgb(0, 80, 142))"
      }
    },
    {
      "char": "",
      "style": {
        "zIndex": 3,
        "color": "var(--color-4, rgb(255, 255, 255))"
      }
    },
    {
      "char": "",
      "style": {
        "zIndex": 4,
        "color": "var(--color-5, rgb(255, 255, 255))"
      }
    },
    {
      "char": "",
      "style": {
        "zIndex": 5,
        "color": "var(--color-6, rgb(255, 255, 255))"
      }
    }
  ],
  "ali-pay": [
    {
      "char": "",
      "style": {
        "zIndex": 0,
        "color": "var(--color-1, rgb(255, 255, 255))"
      }
    },
    {
      "char": "",
      "style": {
        "zIndex": 1,
        "color": "var(--color-2, rgb(6, 180, 253))"
      }
    }
  ],
  "common-payment": [
    {
      "char": "",
      "style": {
        "zIndex": 0,
        "color": "var(--color-1, rgb(81, 92, 233))"
      }
    },
    {
      "char": "",
      "style": {
        "zIndex": 1,
        "color": "var(--color-2, rgb(255, 255, 255))"
      }
    }
  ],
  "common-pay-quick": [
    {
      "char": "",
      "style": {
        "zIndex": 0,
        "color": "var(--color-1, rgb(255, 255, 255))"
      }
    },
    {
      "char": "",
      "style": {
        "zIndex": 1,
        "color": "var(--color-2, rgb(55, 211, 202))"
      }
    }
  ],
  "common-order-successful": [
    {
      "char": "",
      "style": {
        "opacity": "var(--opacity-1, 0.15)",
        "zIndex": 0,
        "color": "var(--color-1, rgb(0, 205, 151))"
      }
    },
    {
      "char": "",
      "style": {
        "opacity": "var(--opacity-2, 0.15)",
        "zIndex": 1,
        "color": "var(--color-2, rgb(0, 205, 151))"
      }
    },
    {
      "char": "",
      "style": {
        "opacity": "var(--opacity-3, 0.15)",
        "zIndex": 2,
        "color": "var(--color-3, rgb(0, 205, 151))"
      }
    },
    {
      "char": "",
      "style": {
        "zIndex": 3,
        "color": "var(--color-4, rgb(0, 205, 151))"
      }
    },
    {
      "char": "",
      "style": {
        "zIndex": 4,
        "color": "var(--color-5, rgb(0, 205, 151))"
      }
    },
    {
      "char": "",
      "style": {
        "opacity": "var(--opacity-6, 0.6)",
        "zIndex": 5,
        "color": "var(--color-6, rgb(0, 205, 151))"
      }
    },
    {
      "char": "",
      "style": {
        "zIndex": 6,
        "color": "var(--color-7, rgb(0, 205, 151))"
      }
    },
    {
      "char": "",
      "style": {
        "opacity": "var(--opacity-8, 0.5)",
        "zIndex": 7,
        "color": "var(--color-8, rgb(0, 205, 151))"
      }
    },
    {
      "char": "",
      "style": {
        "zIndex": 8,
        "color": "var(--color-9, rgb(0, 205, 151))"
      }
    },
    {
      "char": "",
      "style": {
        "opacity": "var(--opacity-10, 0.33)",
        "zIndex": 9,
        "color": "var(--color-10, rgb(0, 205, 151))"
      }
    },
    {
      "char": "",
      "style": {
        "opacity": "var(--opacity-11, 0.5)",
        "zIndex": 10,
        "color": "var(--color-11, rgb(0, 205, 151))"
      }
    },
    {
      "char": "",
      "style": {
        "opacity": "var(--opacity-12, 0.4)",
        "zIndex": 11,
        "color": "var(--color-12, rgb(0, 205, 151))"
      }
    },
    {
      "char": "",
      "style": {
        "zIndex": 12,
        "color": "var(--color-13, rgb(0, 205, 151))"
      }
    },
    {
      "char": "",
      "style": {
        "zIndex": 13,
        "color": "var(--color-14, rgb(255, 255, 255))"
      }
    }
  ],
  "asset-credits": [
    {
      "char": " ",
      "style": {
        "zIndex": 0,
        "backgroundImage": "url(./icons/asset-credits.svg)",
        "backgroundRepeat": "no-repeat",
        "backgroundPosition": "center",
        "backgroundSize": "100%",
        "width": "1em",
        "height": "1em"
      }
    }
  ],
  "asset-crystal": [
    {
      "char": " ",
      "style": {
        "zIndex": 0,
        "backgroundImage": "url(./icons/asset-crystal.svg)",
        "backgroundRepeat": "no-repeat",
        "backgroundPosition": "center",
        "backgroundSize": "100%",
        "width": "1em",
        "height": "1em"
      }
    }
  ],
  "authenticate": [
    {
      "char": " ",
      "style": {
        "zIndex": 0,
        "backgroundImage": "url(./icons/authenticate.svg)",
        "backgroundRepeat": "no-repeat",
        "backgroundPosition": "center",
        "backgroundSize": "100%",
        "width": "1em",
        "height": "1em"
      }
    }
  ],
  "blind-box": [
    {
      "char": " ",
      "style": {
        "zIndex": 0,
        "backgroundImage": "url(./icons/blind-box.svg)",
        "backgroundRepeat": "no-repeat",
        "backgroundPosition": "center",
        "backgroundSize": "100%",
        "width": "1em",
        "height": "1em"
      }
    }
  ],
  "brand-f": [
    {
      "char": " ",
      "style": {
        "zIndex": 0,
        "backgroundImage": "url(./icons/brand-f.png)",
        "backgroundRepeat": "no-repeat",
        "backgroundPosition": "center",
        "backgroundSize": "100%",
        "width": "1em",
        "height": "1em"
      }
    }
  ],
  "brand": [
    {
      "char": " ",
      "style": {
        "zIndex": 0,
        "backgroundImage": "url(./icons/brand.svg)",
        "backgroundRepeat": "no-repeat",
        "backgroundPosition": "center",
        "backgroundSize": "100%",
        "width": "1em",
        "height": "1em"
      }
    }
  ],
  "cooperate-f": [
    {
      "char": " ",
      "style": {
        "zIndex": 0,
        "backgroundImage": "url(./icons/cooperate-f.png)",
        "backgroundRepeat": "no-repeat",
        "backgroundPosition": "center",
        "backgroundSize": "100%",
        "width": "1em",
        "height": "1em"
      }
    }
  ],
  "cooperate": [
    {
      "char": " ",
      "style": {
        "zIndex": 0,
        "backgroundImage": "url(./icons/cooperate.svg)",
        "backgroundRepeat": "no-repeat",
        "backgroundPosition": "center",
        "backgroundSize": "100%",
        "width": "1em",
        "height": "1em"
      }
    }
  ],
  "empty-list": [
    {
      "char": " ",
      "style": {
        "zIndex": 0,
        "backgroundImage": "url(./icons/image_general_blank.webp)",
        "backgroundRepeat": "no-repeat",
        "backgroundPosition": "center",
        "backgroundSize": "100%",
        "width": "1em",
        "height": "1em"
      }
    }
  ],
  "home-f": [
    {
      "char": " ",
      "style": {
        "zIndex": 0,
        "backgroundImage": "url(./icons/home-f.png)",
        "backgroundRepeat": "no-repeat",
        "backgroundPosition": "center",
        "backgroundSize": "100%",
        "width": "1em",
        "height": "1em"
      }
    }
  ],
  "home": [
    {
      "char": " ",
      "style": {
        "zIndex": 0,
        "backgroundImage": "url(./icons/home.svg)",
        "backgroundRepeat": "no-repeat",
        "backgroundPosition": "center",
        "backgroundSize": "100%",
        "width": "1em",
        "height": "1em"
      }
    }
  ],
  "invite": [
    {
      "char": " ",
      "style": {
        "zIndex": 0,
        "backgroundImage": "url(./icons/invite.svg)",
        "backgroundRepeat": "no-repeat",
        "backgroundPosition": "center",
        "backgroundSize": "100%",
        "width": "1em",
        "height": "1em"
      }
    }
  ],
  "metaverse": [
    {
      "char": " ",
      "style": {
        "zIndex": 0,
        "backgroundImage": "url(./icons/metaverse.svg)",
        "backgroundRepeat": "no-repeat",
        "backgroundPosition": "center",
        "backgroundSize": "100%",
        "width": "1em",
        "height": "1em"
      }
    }
  ],
  "mine-f": [
    {
      "char": " ",
      "style": {
        "zIndex": 0,
        "backgroundImage": "url(./icons/mine-f.png)",
        "backgroundRepeat": "no-repeat",
        "backgroundPosition": "center",
        "backgroundSize": "100%",
        "width": "1em",
        "height": "1em"
      }
    }
  ],
  "mine": [
    {
      "char": " ",
      "style": {
        "zIndex": 0,
        "backgroundImage": "url(./icons/mine.svg)",
        "backgroundRepeat": "no-repeat",
        "backgroundPosition": "center",
        "backgroundSize": "100%",
        "width": "1em",
        "height": "1em"
      }
    }
  ],
  "notice": [
    {
      "char": " ",
      "style": {
        "zIndex": 0,
        "backgroundImage": "url(./icons/notice.svg)",
        "backgroundRepeat": "no-repeat",
        "backgroundPosition": "center",
        "backgroundSize": "100%",
        "width": "1em",
        "height": "1em"
      }
    }
  ],
  "red-envelope": [
    {
      "char": " ",
      "style": {
        "zIndex": 0,
        "backgroundImage": "url(./icons/red-envelope.svg)",
        "backgroundRepeat": "no-repeat",
        "backgroundPosition": "center",
        "backgroundSize": "100%",
        "width": "1em",
        "height": "1em"
      }
    }
  ],
  "socialize-f": [
    {
      "char": " ",
      "style": {
        "zIndex": 0,
        "backgroundImage": "url(./icons/socialize-f.png)",
        "backgroundRepeat": "no-repeat",
        "backgroundPosition": "center",
        "backgroundSize": "100%",
        "width": "1em",
        "height": "1em"
      }
    }
  ],
  "socialize": [
    {
      "char": " ",
      "style": {
        "zIndex": 0,
        "backgroundImage": "url(./icons/socialize.svg)",
        "backgroundRepeat": "no-repeat",
        "backgroundPosition": "center",
        "backgroundSize": "100%",
        "width": "1em",
        "height": "1em"
      }
    }
  ],
  "task": [
    {
      "char": " ",
      "style": {
        "zIndex": 0,
        "backgroundImage": "url(./icons/task.svg)",
        "backgroundRepeat": "no-repeat",
        "backgroundPosition": "center",
        "backgroundSize": "100%",
        "width": "1em",
        "height": "1em"
      }
    }
  ],
  "asset-star": [
    {
      "char": " ",
      "style": {
        "zIndex": 0,
        "backgroundImage": "url(./icons/asset-star.svg)",
        "backgroundRepeat": "no-repeat",
        "backgroundPosition": "center",
        "backgroundSize": "100%",
        "width": "1em",
        "height": "1em"
      }
    }
  ],
  "fans": [
    {
      "char": " ",
      "style": {
        "zIndex": 0,
        "backgroundImage": "url(./icons/fans.svg)",
        "backgroundRepeat": "no-repeat",
        "backgroundPosition": "center",
        "backgroundSize": "100%",
        "width": "1em",
        "height": "1em"
      }
    }
  ],
  "identity-ID-blue": [
    {
      "char": " ",
      "style": {
        "zIndex": 0,
        "backgroundImage": "url(./icons/identity-ID-blue.svg)",
        "backgroundRepeat": "no-repeat",
        "backgroundPosition": "center",
        "backgroundSize": "100%",
        "width": "1em",
        "height": "1em"
      }
    }
  ],
  "identity-realname-blue": [
    {
      "char": " ",
      "style": {
        "zIndex": 0,
        "backgroundImage": "url(./icons/identity-realname-blue.svg)",
        "backgroundRepeat": "no-repeat",
        "backgroundPosition": "center",
        "backgroundSize": "100%",
        "width": "1em",
        "height": "1em"
      }
    }
  ],
  "identity-register-blue": [
    {
      "char": " ",
      "style": {
        "zIndex": 0,
        "backgroundImage": "url(./icons/identity-register-blue.svg)",
        "backgroundRepeat": "no-repeat",
        "backgroundPosition": "center",
        "backgroundSize": "100%",
        "width": "1em",
        "height": "1em"
      }
    }
  ],
  "image_checked_successful": [
    {
      "char": " ",
      "style": {
        "zIndex": 0,
        "backgroundImage": "url(./icons/image_checked_successful.svg)",
        "backgroundRepeat": "no-repeat",
        "backgroundPosition": "center",
        "backgroundSize": "100%",
        "width": "1em",
        "height": "1em"
      }
    }
  ],
  "like": [
    {
      "char": " ",
      "style": {
        "zIndex": 0,
        "backgroundImage": "url(./icons/like.svg)",
        "backgroundRepeat": "no-repeat",
        "backgroundPosition": "center",
        "backgroundSize": "100%",
        "width": "1em",
        "height": "1em"
      }
    }
  ],
  "login-arrow-blue": [
    {
      "char": " ",
      "style": {
        "zIndex": 0,
        "backgroundImage": "url(./icons/login-arrow-blue.svg)",
        "backgroundRepeat": "no-repeat",
        "backgroundPosition": "center",
        "backgroundSize": "100%",
        "width": "1em",
        "height": "1em"
      }
    }
  ],
  "plus-company": [
    {
      "char": " ",
      "style": {
        "zIndex": 0,
        "backgroundImage": "url(./icons/plus-company.svg)",
        "backgroundRepeat": "no-repeat",
        "backgroundPosition": "center",
        "backgroundSize": "100%",
        "width": "1em",
        "height": "1em"
      }
    }
  ],
  "tag-authenticate": [
    {
      "char": " ",
      "style": {
        "zIndex": 0,
        "backgroundImage": "url(./icons/tag-authenticate.svg)",
        "backgroundRepeat": "no-repeat",
        "backgroundPosition": "center",
        "backgroundSize": "100%",
        "width": "1em",
        "height": "1em"
      }
    }
  ],
  "thumb": [
    {
      "char": " ",
      "style": {
        "zIndex": 0,
        "backgroundImage": "url(./icons/thumb.svg)",
        "backgroundRepeat": "no-repeat",
        "backgroundPosition": "center",
        "backgroundSize": "100%",
        "width": "1em",
        "height": "1em"
      }
    }
  ],
  "modify": [
    {
      "char": " ",
      "style": {
        "zIndex": 0,
        "backgroundImage": "url(./icons/ico_modify.svg)",
        "backgroundRepeat": "no-repeat",
        "backgroundPosition": "center",
        "backgroundSize": "100%",
        "width": "1em",
        "height": "1em"
      }
    }
  ],
  "avatar": [
    {
      "char": " ",
      "style": {
        "zIndex": 0,
        "backgroundImage": "url(./icons/ico_avatar_default.svg)",
        "backgroundRepeat": "no-repeat",
        "backgroundPosition": "center",
        "backgroundSize": "100%",
        "width": "1em",
        "height": "1em"
      }
    }
  ]
}
`,m=JSON.parse(b),z=({name:n,className:e,style:o})=>{const a=h.useMemo(()=>m[n],[n]);return i.jsx("span",{className:`nl-icon ${n} ${e??""}`,style:o??{},children:a?.map((c,t)=>i.jsx("span",{style:c.style,className:"inline-block",children:c.char},t))})};let s={};const v=n=>{s=n},u=(n,e)=>{const o={ETH:r.Ethereum,BSC:r.Binance,TRON:r.Tron,BFCHAINV2:r.BFChainV2,BFMCHAIN:r.BFMeta,CCCHAIN:r.CCChain,PMCHAIN:r.PMChain,ETHMETA:r.ETHMeta,BTGMETA:r.BTGMeta,BIWMETA:r.BIWMeta,MALIBU:r.Malibu};e in o&&(e=o[e]);const a=s[e];if(a)return a[n]},g={"BFMeta-BFM":"./images/token/BFMeta-BFM.png","BFMeta-DEXT":"./images/token/BFMeta-DEXT.png","BFMeta-DEX":"./images/token/BFMeta-DEX.png","BFMeta-DXD":"./images/token/BFMeta-DXD.png","BFMeta-CPCC":"./images/token/BFMeta-CPCC.png","BFMeta-MOC":"./images/token/BFMeta-MOC.png","BFMeta-MOT":"./images/token/BFMeta-MOT.png","BFMeta-MOW":"./images/token/BFMeta-MOW.png","BFMeta-CPCT":"./images/token/BFMeta-CPCT.png","BFMeta-USDT":"./images/token/BFMeta-USDT.webp","Binance-USDT":"./images/token/Binance-USDT.webp","Ethereum-USDT":"./images/token/Ethereum-USDT.webp","Tron-USDT":"./images/token/Tron-USDT.webp"},x=(n,e,o)=>{if(g[`${e}-${n}`])return g[`${e}-${n}`];const a=u(n,e);return a||o||k(n)},w=n=>`./images/icon_${n}.webp`,k=n=>{const e=n.charAt(0);let o=0;for(let l=0;l<n.length;l++)o=n.charCodeAt(l)+((o<<5)-o);const a=`hsl(${Math.abs(o)%360}, 70%, 45%)`,c=`hsl(${(Math.abs(o)+120)%360}, 70%, 30%)`,t=`
                <svg xmlns="http://www.w3.org/2000/svg" width="200" height="200" viewBox="0 0 200 200">
                    <defs>
                        <linearGradient id="gradient" x1="0%" y1="0%" x2="100%" y2="100%">
                            <stop offset="0%" stop-color="${a}" />
                            <stop offset="100%" stop-color="${c}" />
                        </linearGradient>
                    </defs>
                    <rect width="200" height="200" fill="url(#gradient)" rx="15" />
                    <text 
                        x="100" 
                        y="115" 
                        font-family="Arial, sans-serif" 
                        font-size="80" 
                        font-weight="bold" 
                        fill="white" 
                        text-anchor="middle"
                        dominant-baseline="middle"
                        stroke="rgba(0,0,0,0.2)"
                        stroke-width="2"
                    >
                        ${e}
                    </text>
                </svg>
            `,d=new Blob([t],{type:"image/svg+xml;charset=utf-8"});return URL.createObjectURL(d)};export{z as N,w as a,x as g,v as s};
