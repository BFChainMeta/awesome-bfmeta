import{f as o,A as a}from"./index-CzR53FE8.js";await o.loadModule(a);
