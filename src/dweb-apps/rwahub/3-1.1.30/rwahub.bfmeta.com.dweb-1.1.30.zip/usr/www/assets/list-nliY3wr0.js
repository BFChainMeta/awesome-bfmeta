import{L as s}from"./list-CD1gnk6-.js";const o=s;export{o as L};
