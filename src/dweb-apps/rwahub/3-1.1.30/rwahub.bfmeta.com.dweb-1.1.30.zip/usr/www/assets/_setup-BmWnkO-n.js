import{p}from"./sha256-ZuWg9t1b.js";const a=async()=>{await p.prepare()};export{a as p};
