import{i}from"./core-rNBzN21f.js";import"./page-Cie65gcI.js";const a=async t=>{await i.write({string:t})},o=async t=>{await a(t)};export{o as w};
