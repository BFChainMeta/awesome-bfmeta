import{i}from"./core-CgEc07US.js";import"./page-WnEcL0l3.js";const a=async t=>{await i.write({string:t})},o=async t=>{await a(t)};export{o as w};
