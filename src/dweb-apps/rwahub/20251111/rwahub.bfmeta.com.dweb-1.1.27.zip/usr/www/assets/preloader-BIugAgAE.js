import{j as o}from"./index-D4DRyH-c.js";import{K as e}from"./page-WnEcL0l3.js";const a=r=>o.jsx(e,{size:24,...r});export{a as P};
