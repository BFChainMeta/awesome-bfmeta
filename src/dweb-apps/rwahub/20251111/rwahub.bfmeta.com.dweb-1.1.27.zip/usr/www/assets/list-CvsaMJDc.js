import{L as s}from"./list-BMIrD1AU.js";const o=s;export{o as L};
