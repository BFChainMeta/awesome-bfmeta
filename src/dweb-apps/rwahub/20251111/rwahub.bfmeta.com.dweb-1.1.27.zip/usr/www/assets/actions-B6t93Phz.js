import{f as o,A as a}from"./index-D4DRyH-c.js";await o.loadModule(a);
