import{U as r}from"./page-EYqFyeXj.js";import{R as o}from"./index-D8mKQx5l.js";const m=e=>o.createElement(r,{size:24,...e});export{m as P};
