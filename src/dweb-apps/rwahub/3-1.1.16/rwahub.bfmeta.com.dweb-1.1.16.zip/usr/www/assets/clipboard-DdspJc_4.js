import{i}from"./core-D3yvsF9z.js";import"./page-BVUhpBl5.js";const a=async t=>{await i.write({string:t})},o=async t=>{await a(t)};export{o as w};
