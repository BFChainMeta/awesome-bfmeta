import{f as o,A as a}from"./index-Dpm6zZQh.js";await o.loadModule(a);
