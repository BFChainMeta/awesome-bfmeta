import{w as r}from"./page-BVUhpBl5.js";import{R as o}from"./index-Dpm6zZQh.js";const m=e=>o.createElement(r,{size:24,...e});export{m as P};
