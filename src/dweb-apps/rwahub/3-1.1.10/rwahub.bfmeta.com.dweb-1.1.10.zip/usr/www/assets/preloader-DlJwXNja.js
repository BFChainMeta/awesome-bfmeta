import{w as r}from"./page-BsGu_AYy.js";import{R as o}from"./index-CdRCITl4.js";const m=e=>o.createElement(r,{size:24,...e});export{m as P};
