import{f as o,A as a}from"./index-CdRCITl4.js";await o.loadModule(a);
