import{i}from"./core-DD0xQ_U6.js";import"./page-BsGu_AYy.js";const a=async t=>{await i.write({string:t})},o=async t=>{await a(t)};export{o as w};
