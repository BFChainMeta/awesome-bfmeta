import{p}from"./sha256-BHrg3lHV.js";const a=async()=>{await p.prepare()};export{a as p};
