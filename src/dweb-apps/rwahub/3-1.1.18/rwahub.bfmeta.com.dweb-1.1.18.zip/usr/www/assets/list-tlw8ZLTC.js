import{a as s}from"./list-BKkrmTD6.js";const o=s;export{o as L};
