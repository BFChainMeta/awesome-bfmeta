import{i}from"./core-C3vFLeaH.js";import"./page-Cs_fbGhf.js";const a=async t=>{await i.write({string:t})},o=async t=>{await a(t)};export{o as w};
