import{w as r}from"./page-Cs_fbGhf.js";import{R as o}from"./index-DzIQxbL5.js";const m=e=>o.createElement(r,{size:24,...e});export{m as P};
