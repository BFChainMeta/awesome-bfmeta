import{f as o,A as a}from"./index-DzIQxbL5.js";await o.loadModule(a);
