import{T as r}from"./page-BPK9NGta.js";import{R as o}from"./index-DiGXOI55.js";const m=e=>o.createElement(r,{size:24,...e});export{m as P};
