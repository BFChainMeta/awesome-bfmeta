import{i}from"./core-CITZLWzA.js";import"./page-BPK9NGta.js";const a=async t=>{await i.write({string:t})},o=async t=>{await a(t)};export{o as w};
