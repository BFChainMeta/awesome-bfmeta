import{f as o,A as a}from"./index-DiGXOI55.js";await o.loadModule(a);
