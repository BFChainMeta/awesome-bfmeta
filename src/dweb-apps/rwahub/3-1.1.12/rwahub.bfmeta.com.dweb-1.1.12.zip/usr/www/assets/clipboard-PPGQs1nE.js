import{i}from"./core-u2YftUzD.js";import"./page-C34M7YEQ.js";const a=async t=>{await i.write({string:t})},o=async t=>{await a(t)};export{o as w};
