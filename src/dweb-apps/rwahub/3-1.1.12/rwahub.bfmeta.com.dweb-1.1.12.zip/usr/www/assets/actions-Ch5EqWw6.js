import{f as o,A as a}from"./index-BWfLGvnQ.js";await o.loadModule(a);
