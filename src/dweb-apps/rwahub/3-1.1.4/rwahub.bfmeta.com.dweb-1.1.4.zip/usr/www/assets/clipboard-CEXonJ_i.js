import{i}from"./core-3m9pXhlb.js";import"./page-B1224Qmr.js";const a=async t=>{await i.write({string:t})},o=async t=>{await a(t)};export{o as w};
