import{U as r}from"./page-B1224Qmr.js";import{R as o}from"./index-CNpRU8sP.js";const m=e=>o.createElement(r,{size:24,...e});export{m as P};
