import{p}from"./sha256-BnyrTP72.js";const a=async()=>{await p.prepare()};export{a as p};
