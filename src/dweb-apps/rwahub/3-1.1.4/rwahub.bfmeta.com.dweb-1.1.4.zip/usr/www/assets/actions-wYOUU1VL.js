import{f as o,A as a}from"./index-CNpRU8sP.js";await o.loadModule(a);
