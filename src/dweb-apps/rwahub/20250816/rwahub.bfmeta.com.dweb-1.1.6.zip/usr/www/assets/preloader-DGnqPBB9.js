import{w as r}from"./page-BmQTqLF-.js";import{R as o}from"./index-DiA9CTFN.js";const m=e=>o.createElement(r,{size:24,...e});export{m as P};
