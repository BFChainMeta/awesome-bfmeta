import{f as o,A as a}from"./index-DiA9CTFN.js";await o.loadModule(a);
