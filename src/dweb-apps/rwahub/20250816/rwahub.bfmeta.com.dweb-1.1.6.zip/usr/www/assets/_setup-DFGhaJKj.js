import{p}from"./sha256-D14KVYXw.js";const a=async()=>{await p.prepare()};export{a as p};
