import{i}from"./core-DkvapcoQ.js";import"./page-DSjs-Vru.js";const a=async t=>{await i.write({string:t})},o=async t=>{await a(t)};export{o as w};
