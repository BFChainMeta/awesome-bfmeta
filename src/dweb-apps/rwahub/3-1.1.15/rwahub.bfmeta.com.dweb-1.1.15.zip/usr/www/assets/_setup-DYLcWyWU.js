import{p}from"./sha256-i-MrZ9xI.js";const a=async()=>{await p.prepare()};export{a as p};
