import{f as o,A as a}from"./index-xrBaRjF9.js";await o.loadModule(a);
