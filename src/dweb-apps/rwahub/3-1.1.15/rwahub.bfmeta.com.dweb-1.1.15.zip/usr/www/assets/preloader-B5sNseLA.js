import{w as r}from"./page-DSjs-Vru.js";import{R as o}from"./index-xrBaRjF9.js";const m=e=>o.createElement(r,{size:24,...e});export{m as P};
