import{j as o}from"./index-DN8vxF6s.js";import{K as e}from"./page-3F_QkLmH.js";const a=r=>o.jsx(e,{size:24,...r});export{a as P};
