import{f as o,A as a}from"./index-DN8vxF6s.js";await o.loadModule(a);
