import{L as s}from"./list-DuxF0RhH.js";const o=s;export{o as L};
