import{i}from"./core-O1DS7Z9S.js";import"./page-3F_QkLmH.js";const a=async t=>{await i.write({string:t})},o=async t=>{await a(t)};export{o as w};
