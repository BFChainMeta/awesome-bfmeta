import{C as e,p as h}from"./page-oQE8R5D_.js";import{R as a}from"./index-DQaR_LC-.js";let l={};const w=t=>{l=t},d=(t,o)=>{const n={ETH:e.Ethereum,BSC:e.Binance,TRON:e.Tron,BFCHAINV2:e.BFChainV2,BFMCHAIN:e.BFMeta,CCCHAIN:e.CCChain,PMCHAIN:e.PMChain,ETHMETA:e.ETHMeta,BTGMETA:e.BTGMeta,BIWMETA:e.BIWMeta,MALIBU:e.Malibu};o in n&&(o=n[o]);const r=l[o];if(r)return r[t]},i={"BFMeta-BFM":"./images/token/BFMeta-BFM.png","BFMeta-DEXT":"./images/token/BFMeta-DEXT.png"},A=(t,o,n)=>{if(i[`${o}-${t}`])return i[`${o}-${t}`];const r=d(t,o);return r||n||M(t)},E=t=>`./images/icon_${t}.webp`,M=t=>{const o=t.charAt(0);let n=0;for(let s=0;s<t.length;s++)n=t.charCodeAt(s)+((n<<5)-n);const r=`hsl(${Math.abs(n)%360}, 70%, 45%)`,c=`hsl(${(Math.abs(n)+120)%360}, 70%, 30%)`,g=`
                <svg xmlns="http://www.w3.org/2000/svg" width="200" height="200" viewBox="0 0 200 200">
                    <defs>
                        <linearGradient id="gradient" x1="0%" y1="0%" x2="100%" y2="100%">
                            <stop offset="0%" stop-color="${r}" />
                            <stop offset="100%" stop-color="${c}" />
                        </linearGradient>
                    </defs>
                    <rect width="200" height="200" fill="url(#gradient)" rx="15" />
                    <text 
                        x="100" 
                        y="115" 
                        font-family="Arial, sans-serif" 
                        font-size="80" 
                        font-weight="bold" 
                        fill="white" 
                        text-anchor="middle"
                        dominant-baseline="middle"
                        stroke="rgba(0,0,0,0.2)"
                        stroke-width="2"
                    >
                        ${o}
                    </text>
                </svg>
            `,f=new Blob([g],{type:"image/svg+xml;charset=utf-8"});return URL.createObjectURL(f)},m=t=>a.createElement(h,{size:24,...t}),I=t=>a.createElement("div",{className:"flex h-32 w-full items-center justify-center"},a.createElement(m,{size:32,...t}));export{I as L,m as P,E as a,A as g,w as s};
