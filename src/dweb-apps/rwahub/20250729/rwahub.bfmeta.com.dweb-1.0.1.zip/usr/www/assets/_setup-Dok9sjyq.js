import{p}from"./sha256-VUHbS-Nb.js";const a=async()=>{await p.prepare()};export{a as p};
