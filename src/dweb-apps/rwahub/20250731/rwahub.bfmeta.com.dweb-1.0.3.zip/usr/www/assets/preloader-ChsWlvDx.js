import{Q as r}from"./page-d7DyzzQh.js";import{R as o}from"./index-DDRjAzlo.js";const m=e=>o.createElement(r,{size:24,...e});export{m as P};
