import{f as o,I as a}from"./index-DDRjAzlo.js";const l=o.dialog;await o.loadModule(a);export{l as d};
