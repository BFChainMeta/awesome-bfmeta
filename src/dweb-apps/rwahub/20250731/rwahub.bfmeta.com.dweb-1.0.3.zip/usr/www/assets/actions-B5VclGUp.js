import{f as o,A as a}from"./index-DDRjAzlo.js";await o.loadModule(a);
