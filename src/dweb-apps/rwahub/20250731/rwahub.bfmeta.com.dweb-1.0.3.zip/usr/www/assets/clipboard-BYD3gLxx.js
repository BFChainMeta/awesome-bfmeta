import{i}from"./core-B83JNwOx.js";import"./page-d7DyzzQh.js";const a=async t=>{await i.write({string:t})},o=async t=>{await a(t)};export{o as w};
