import{y as r}from"./page-B46o5oWH.js";import{R as o}from"./index-DGHTCzJ4.js";const m=e=>o.createElement(r,{size:24,...e});export{m as P};
