import{p}from"./sha256-C58AGuRA.js";const a=async()=>{await p.prepare()};export{a as p};
