import{i}from"./core-BOxJZ2gs.js";import"./page-B46o5oWH.js";const a=async t=>{await i.write({string:t})},o=async t=>{await a(t)};export{o as w};
