import{f as o,A as a}from"./index-C4XizSoF.js";await o.loadModule(a);
