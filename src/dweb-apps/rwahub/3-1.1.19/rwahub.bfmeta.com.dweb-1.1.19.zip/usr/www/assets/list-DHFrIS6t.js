import{a as s}from"./list-DGOQDndh.js";const o=s;export{o as L};
