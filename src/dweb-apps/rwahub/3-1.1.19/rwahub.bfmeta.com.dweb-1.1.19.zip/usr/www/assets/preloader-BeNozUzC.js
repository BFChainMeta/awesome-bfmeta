import{w as r}from"./page-ZBWevTJD.js";import{R as o}from"./index-C4XizSoF.js";const m=e=>o.createElement(r,{size:24,...e});export{m as P};
