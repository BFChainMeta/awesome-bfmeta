import{p}from"./sha256-Drl8GAf6.js";const a=async()=>{await p.prepare()};export{a as p};
