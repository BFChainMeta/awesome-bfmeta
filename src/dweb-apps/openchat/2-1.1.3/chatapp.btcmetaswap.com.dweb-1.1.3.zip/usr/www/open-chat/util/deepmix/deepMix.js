import { mergeAble } from "./helper.js";
// type Z<L> = L extends (a:infer A, ...args:infer RS)=>unknown?A:L
function _safeDeepMix(objList) {
    if (objList.length === 1) {
        return objList[0];
    }
    return new Proxy(objList[0], {
        get(t, prop, r) {
            const matchedObjList = objList.filter((obj) => Reflect.has(obj, prop));
            if (matchedObjList.length === 0) {
                return undefined;
            }
            if (matchedObjList.length === 1) {
                return Reflect.get(matchedObjList[0], prop);
            }
            /// 如果有object，那么优先object
            const matchedValueList = matchedObjList.map((obj) => Reflect.get(obj, prop));
            const mergeableMatchedValueList = matchedValueList.filter((value) => mergeAble(value));
            /// 如果都是无法合并的值，那么直接返回最后一个就行了
            if (mergeableMatchedValueList.length === 0) {
                return matchedValueList[matchedValueList.length - 1];
            }
            /// 如果能够合并，那么进入合并模式
            return _safeDeepMix(mergeableMatchedValueList);
        },
        getOwnPropertyDescriptor(t, prop) {
            const matchedObjList = objList.filter((obj) => Reflect.has(obj, prop));
            if (matchedObjList.length === 0) {
                return undefined;
            }
            if (matchedObjList.length === 1) {
                return Object.getOwnPropertyDescriptor(matchedObjList[0], prop);
            }
            /// 如果有object，那么优先object
            const matchedObjValueList = matchedObjList.map((obj) => ({
                obj,
                value: Reflect.get(obj, prop),
            }));
            const mergeableMatchedObjValueList = matchedObjValueList.filter((ov) => mergeAble(ov.value));
            const latestPd = Object.getOwnPropertyDescriptor(matchedObjValueList[matchedObjValueList.length - 1].obj, prop);
            /// 如果都是无法合并的值，那么直接返回最后一个就行了
            if (mergeableMatchedObjValueList.length === 0) {
                return latestPd;
            }
            /// 如果能够合并，那么进入合并模式
            return { ...latestPd, value: _safeDeepMix(matchedObjValueList.map((ov) => ov.value)) };
        },
        ownKeys() {
            const keys = new Set();
            for (const obj of objList) {
                for (const key of Reflect.ownKeys(obj)) {
                    keys.add(key);
                }
            }
            return [...keys];
        },
    });
}
export function deepMix(...unsafeObjList) {
    const objList = unsafeObjList.filter(mergeAble);
    if (objList.length === 0) {
        return {};
    }
    return _safeDeepMix(objList);
}
// const a2 = deepMix(
//   { a: 1, c: { a: 1, b: 2, arr: [1, 2, 3] } },
//   { b: 2, c: { b: 3, c: 4, arr: [4, 5] } },
// );
// console.log(Object.keys(a2));
// for (const k in a2) {
//   console.log("kv:", k, (a2 as never)[k]);
// }
// console.log(a2.b, a2.c.b);
// console.log(JSON.stringify(a2, null, 2));
