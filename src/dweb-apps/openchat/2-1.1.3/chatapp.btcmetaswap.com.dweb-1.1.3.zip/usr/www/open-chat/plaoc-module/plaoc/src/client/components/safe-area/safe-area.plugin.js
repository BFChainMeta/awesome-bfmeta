var _a;
import { __decorate, __metadata } from "../../../../../../tslib/modules/index.js";
import { bindThis } from "../../helper/bindThis.js";
import { BasePlugin } from "../base/BasePlugin.js";
export class SafeAreaPlugin extends BasePlugin {
    constructor() {
        super("window.sys.dweb");
    }
    async setState(state) {
    }
    setStateByKey(key, value) {
        return this.setState({ [key]: value });
    }
    setOverlay(overlay) {
    }
    async getOverlay() {
        return false;
    }
}
__decorate([
    bindThis,
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], SafeAreaPlugin.prototype, "setState", null);
__decorate([
    bindThis,
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [typeof (_a = typeof K !== "undefined" && K) === "function" ? _a : Object, Object]),
    __metadata("design:returntype", void 0)
], SafeAreaPlugin.prototype, "setStateByKey", null);
__decorate([
    bindThis,
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Boolean]),
    __metadata("design:returntype", void 0)
], SafeAreaPlugin.prototype, "setOverlay", null);
__decorate([
    bindThis,
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], SafeAreaPlugin.prototype, "getOverlay", null);
export const safeAreaPlugin = new SafeAreaPlugin();
