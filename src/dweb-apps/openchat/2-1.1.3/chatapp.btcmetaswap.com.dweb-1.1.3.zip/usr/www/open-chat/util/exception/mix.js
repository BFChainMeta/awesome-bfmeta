import { __decorate, __metadata } from "../../tslib/modules/index.js";
import { ExceptionGenerator, CustomErrorCodeMap, } from "../exception-generator/index.js";
import { LogGenerator } from "../exception-logger/index.js";
import { platformInfo } from "../platform/index.js";
import { Inject, ModuleStroge, Injectable, Resolve, } from "../dep_inject/index.js";
function MixExceptionGenerator(PLATFORM, CHANNEL, BUSINESS, MODULE, FILE, ERROR_CODE_MAP) {
    let loggerNsp = `${CHANNEL.toLowerCase()}-${BUSINESS.toLowerCase()}`;
    if (MODULE) {
        loggerNsp += `:${MODULE}`;
    }
    if (FILE) {
        loggerNsp += `/${FILE}`;
    }
    const logs = LogGenerator(loggerNsp);
    const exps = ExceptionGenerator(PLATFORM, CHANNEL, BUSINESS, MODULE, FILE, ERROR_CODE_MAP);
    return new Proxy({}, {
        get(t, p) {
            return t[p] || logs[p] || exps[p];
        },
    });
}
export var EXCEPTION_INJECT_SYMBOL;
(function (EXCEPTION_INJECT_SYMBOL) {
    EXCEPTION_INJECT_SYMBOL["PLATFORM"] = "exception.platform";
    EXCEPTION_INJECT_SYMBOL["CHANNEL"] = "exception.channel";
    EXCEPTION_INJECT_SYMBOL["BUSINESS"] = "exception.business";
})(EXCEPTION_INJECT_SYMBOL || (EXCEPTION_INJECT_SYMBOL = {}));
export function RegisterExceptionGeneratorDefiner(opts) {
    const defaultPlatformName = typeof opts.platform === "string"
        ? opts.platform
        : platformInfo.getGlobalFlag("PLATFORM") || platformInfo.platformName();
    const defaultChannelName = typeof opts.platform === "string"
        ? opts.platform
        : platformInfo.getGlobalFlag("CHANNEL") || platformInfo.getChannel();
    const defaultBusinessName = typeof opts.platform === "string"
        ? opts.platform
        : platformInfo.getGlobalFlag("BUSINESS") || platformInfo.getBusiness();
    return function define(moduleName, fileName, opts) {
        return MixExceptionGenerator(opts.platformName || defaultPlatformName, opts.channelName || defaultChannelName, opts.businessName || defaultBusinessName, moduleName, fileName, opts.errorCodeMap);
    };
}
let SingleCustomException = class SingleCustomException {
    constructor(moduleMap) {
        Object.defineProperty(this, "moduleMap", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: moduleMap
        });
        Object.defineProperty(this, "platformName", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: undefined
        });
        Object.defineProperty(this, "channelName", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: undefined
        });
        Object.defineProperty(this, "businessName", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: undefined
        });
        Object.defineProperty(this, "exceptionGeneratorDefiner", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: RegisterExceptionGeneratorDefiner({
                platform: this.platformName,
                channel: this.channelName,
                business: this.businessName,
            })
        });
    }
};
__decorate([
    Inject(EXCEPTION_INJECT_SYMBOL.PLATFORM, { dynamics: true, optional: true }),
    __metadata("design:type", String)
], SingleCustomException.prototype, "platformName", void 0);
__decorate([
    Inject(EXCEPTION_INJECT_SYMBOL.CHANNEL, { dynamics: true, optional: true }),
    __metadata("design:type", String)
], SingleCustomException.prototype, "channelName", void 0);
__decorate([
    Inject(EXCEPTION_INJECT_SYMBOL.BUSINESS, { dynamics: true, optional: true }),
    __metadata("design:type", String)
], SingleCustomException.prototype, "businessName", void 0);
SingleCustomException = __decorate([
    Injectable("#single-custom-exception", { singleton: true }),
    __metadata("design:paramtypes", [ModuleStroge])
], SingleCustomException);
export { SingleCustomException };
const myException = Resolve(SingleCustomException);
export function UtilExceptionGenerator(moduleName, fileName, opts) {
    return myException.exceptionGeneratorDefiner(moduleName, fileName, Object.assign({ errorCodeMap: CustomErrorCodeMap, businessName: "util" }, opts));
}
//#endregion
