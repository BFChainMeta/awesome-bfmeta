import http from "node:http";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { Buffer } from "node:buffer";
const mime = {
  "": "text/html",
  ".html": "text/html",
  ".js": "application/javascript",
  ".css": "text/css",
  ".wasm": "application/wasm",
  ".svg": "image/svg+xml",
  ".png": "image/png",
};
const server = http.createServer(async (req, res) => {
  console.log("req", req.url);
  let pathname = req.url;
  if (!pathname.includes(".")) {
    pathname += ".html";
  }
  pathname = pathname;
  const ext = path.parse(pathname).ext;
  const contentType = mime[ext];
  if (contentType) {
    res.setHeader("Content-Type", contentType);
  }

  const filepath = fileURLToPath(import.meta.resolve("." + pathname));
  try {
    res.end(fs.readFileSync(filepath));
  } catch (err) {
    console.error(err.message);
    const proxy_res = await fetch(
      `https://h5-enterprise.rentsoft.cn/${req.url}`
    );
    res.statusCode = proxy_res.status;
    const proxy_body = Buffer.from(await proxy_res.arrayBuffer());
    if (proxy_res.ok) {
      fs.mkdirSync(path.dirname(filepath), { recursive: true });
      fs.writeFileSync(filepath, proxy_body);
    }
    res.end(proxy_body);
  }
});
server.listen(8800, () => {
  console.log("server start in http://localhost:8800");
});
