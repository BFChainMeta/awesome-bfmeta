export { cacheGetter } from "../decorator/index.js";
export { GetCallerInfo } from "../extends-error/index.js";
export { renameFunction } from "../extends-function/index.js";
export * from "./$types.js";
export * from "./constants.js";
import { isFlagInDev } from "../env/index.js";
export const isDev = isFlagInDev("eventemitter") && isFlagInDev("browser");
