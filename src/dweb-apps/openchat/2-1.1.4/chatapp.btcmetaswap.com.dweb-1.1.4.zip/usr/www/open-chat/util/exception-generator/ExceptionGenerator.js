import { CustomError } from "../extends-error/index.js";
import { ErrorCode } from "../exception-error-code/index.js";
import { cacheObjectGetter } from "../extends-object/index.js";
//#region 定义异常
/**错误码集合 */
export const CustomErrorCodeMap = new Map();
export class Exception extends CustomError {
    constructor(sourceMessage = "", detail, CODE, SEVERIFY) {
        // super(
        //   detail
        //     ? sourceMessage.replace(/\{([^\\]+?)\}/g, (match, key) => {
        //         return detail[key] ?? match;
        //       })
        //     : sourceMessage,
        // );
        super(detail
            ? sourceMessage instanceof ErrorCode
                ? sourceMessage.build(detail)
                : sourceMessage.replace(/\{([^\\]+?)\}/g, (match, key) => {
                    return detail[key] ?? match;
                })
            : sourceMessage instanceof ErrorCode
                ? sourceMessage.message
                : sourceMessage);
        Object.defineProperty(this, "detail", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: detail
        });
        Object.defineProperty(this, "sourceMessage", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "type", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "PLATFORM", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "CHANNEL", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "BUSINESS", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "MODULE", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "FILE", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "CODE", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "SEVERIFY", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        if (ABS_EXCPTION_CTORS.has(this.constructor)) {
            throw new Error("please use ExceptionGenerator to get Exception Constructor");
        }
        const ExceptionCtor = this.constructor;
        const { ERROR_CODE_MAP } = ExceptionCtor;
        Object.defineProperties(this, {
            detail: { value: detail, enumerable: false, writable: false },
            sourceMessage: {
                value: sourceMessage,
                enumerable: false,
                writable: false,
            },
            type: { value: ExceptionCtor.TYPE, enumerable: false, writable: false },
            PLATFORM: {
                value: ExceptionCtor.PLATFORM,
                enumerable: false,
                writable: false,
            },
            CHANNEL: {
                value: ExceptionCtor.CHANNEL,
                enumerable: false,
                writable: false,
            },
            BUSINESS: {
                value: ExceptionCtor.BUSINESS,
                enumerable: false,
                writable: false,
            },
            MODULE: {
                value: ExceptionCtor.MODULE,
                enumerable: false,
                writable: false,
            },
            FILE: { value: ExceptionCtor.FILE, enumerable: false, writable: false },
            // CODE: {
            //   value:
            //     CODE ?? (ERROR_CODE_MAP.get(sourceMessage) || ERROR_CODE_MAP.get("unknown error") || ""),
            //   enumerable: false,
            //   writable: false,
            // },
            CODE: {
                value: CODE ??
                    (sourceMessage instanceof ErrorCode
                        ? sourceMessage.code
                        : ERROR_CODE_MAP.get(sourceMessage) ||
                            ERROR_CODE_MAP.get("unknown error") ||
                            ""),
                enumerable: false,
                writable: false,
            },
            SEVERIFY: {
                value: SEVERIFY || "major" /* EXCEPTION_SEVERIFY.MAJOR */,
                enumerable: false,
                writable: false,
            },
        });
    }
    get name() {
        const ctor = this.constructor;
        return ctor.TYPE;
    }
    static is(err) {
        return !!(err && err.type === this.TYPE);
    }
}
Object.defineProperty(Exception, "TYPE", {
    enumerable: true,
    configurable: true,
    writable: true,
    value: "Exception"
});
Object.defineProperty(Exception, "PLATFORM", {
    enumerable: true,
    configurable: true,
    writable: true,
    value: ""
});
Object.defineProperty(Exception, "CHANNEL", {
    enumerable: true,
    configurable: true,
    writable: true,
    value: ""
});
Object.defineProperty(Exception, "BUSINESS", {
    enumerable: true,
    configurable: true,
    writable: true,
    value: ""
});
Object.defineProperty(Exception, "MODULE", {
    enumerable: true,
    configurable: true,
    writable: true,
    value: ""
});
Object.defineProperty(Exception, "FILE", {
    enumerable: true,
    configurable: true,
    writable: true,
    value: ""
});
Object.defineProperty(Exception, "CODE", {
    enumerable: true,
    configurable: true,
    writable: true,
    value: ""
});
Object.defineProperty(Exception, "SEVERIFY", {
    enumerable: true,
    configurable: true,
    writable: true,
    value: "major" /* EXCEPTION_SEVERIFY.MAJOR */
});
Object.defineProperty(Exception, "ERROR_CODE_MAP", {
    enumerable: true,
    configurable: true,
    writable: true,
    value: CustomErrorCodeMap
});
export class OutOfRangeException extends Exception {
}
Object.defineProperty(OutOfRangeException, "TYPE", {
    enumerable: true,
    configurable: true,
    writable: true,
    value: "OutOfRangeException"
});
export class ArgumentException extends Exception {
}
Object.defineProperty(ArgumentException, "TYPE", {
    enumerable: true,
    configurable: true,
    writable: true,
    value: "ArgumentException"
});
export class ArgumentIllegalException extends Exception {
}
Object.defineProperty(ArgumentIllegalException, "TYPE", {
    enumerable: true,
    configurable: true,
    writable: true,
    value: "ArgumentIllegalException"
});
export class ArgumentFormatException extends Exception {
}
Object.defineProperty(ArgumentFormatException, "TYPE", {
    enumerable: true,
    configurable: true,
    writable: true,
    value: "ArgumentFormatException"
});
export class NoFoundException extends Exception {
}
Object.defineProperty(NoFoundException, "TYPE", {
    enumerable: true,
    configurable: true,
    writable: true,
    value: "NoFoundException"
});
export class ResponseException extends Exception {
}
Object.defineProperty(ResponseException, "TYPE", {
    enumerable: true,
    configurable: true,
    writable: true,
    value: "ResponseException"
});
export class IOException extends Exception {
}
Object.defineProperty(IOException, "TYPE", {
    enumerable: true,
    configurable: true,
    writable: true,
    value: "IOException"
});
export class NetworkIOException extends Exception {
}
Object.defineProperty(NetworkIOException, "TYPE", {
    enumerable: true,
    configurable: true,
    writable: true,
    value: "NetworkIOException"
});
export class BusyIOException extends Exception {
}
Object.defineProperty(BusyIOException, "TYPE", {
    enumerable: true,
    configurable: true,
    writable: true,
    value: "BusyIOException"
});
export class DatebaseIOException extends Exception {
}
Object.defineProperty(DatebaseIOException, "TYPE", {
    enumerable: true,
    configurable: true,
    writable: true,
    value: "DatebaseIOException"
});
export class InterruptedException extends Exception {
}
Object.defineProperty(InterruptedException, "TYPE", {
    enumerable: true,
    configurable: true,
    writable: true,
    value: "InterruptedException"
});
export class IllegalStateException extends Exception {
}
Object.defineProperty(IllegalStateException, "TYPE", {
    enumerable: true,
    configurable: true,
    writable: true,
    value: "IllegalStateException"
});
export class TimeOutException extends Exception {
}
Object.defineProperty(TimeOutException, "TYPE", {
    enumerable: true,
    configurable: true,
    writable: true,
    value: "TimeOutException"
});
export class BusyException extends Exception {
}
Object.defineProperty(BusyException, "TYPE", {
    enumerable: true,
    configurable: true,
    writable: true,
    value: "BusyException"
});
export class ConsensusException extends Exception {
}
Object.defineProperty(ConsensusException, "TYPE", {
    enumerable: true,
    configurable: true,
    writable: true,
    value: "ConsensusException"
});
export class AbortException extends Exception {
}
Object.defineProperty(AbortException, "TYPE", {
    enumerable: true,
    configurable: true,
    writable: true,
    value: "AbortException"
});
export class RefuseException extends Exception {
}
Object.defineProperty(RefuseException, "TYPE", {
    enumerable: true,
    configurable: true,
    writable: true,
    value: "RefuseException"
});
const ABS_EXCPTION_CTORS = new Set([
    Exception,
    OutOfRangeException,
    ArgumentException,
    ArgumentIllegalException,
    ArgumentFormatException,
    NoFoundException,
    ResponseException,
    IOException,
    NetworkIOException,
    BusyIOException,
    DatebaseIOException,
    InterruptedException,
    IllegalStateException,
    TimeOutException,
    BusyException,
    ConsensusException,
    AbortException,
    RefuseException,
]);
//#endregion
if (typeof Error.stackTraceLimit === "number") {
    Error.stackTraceLimit += 3;
}
//#region 异常打包
/**
 *
 * @param PLATFORM 平台
 * @param CHANNEL 渠道
 * @param BUSINESS 业务
 * @param MODULE 模块
 * @param FILE 文件
 */
export function ExceptionGenerator(PLATFORM, CHANNEL, BUSINESS, MODULE, FILE, ERROR_CODE_MAP) {
    const getException = (Con) => {
        const ExtCon = Con;
        ExtCon.PLATFORM = PLATFORM;
        ExtCon.CHANNEL = CHANNEL;
        ExtCon.BUSINESS = BUSINESS;
        ExtCon.MODULE = MODULE;
        ExtCon.FILE = FILE;
        ExtCon.ERROR_CODE_MAP = ERROR_CODE_MAP;
        Object.freeze(ExtCon);
        return ExtCon;
    };
    // const genException = <E extends $ExceptionConstructor>(AbsCtor: E) => {
    //   return class Exc extends AbsCtor {
    //     constructor(...args: any[]) {
    //       super(...args);
    //     }
    //     static #is_base_class = false;
    //   };
    // };
    const exceptionHashMap = {
        getException,
        get Exception() {
            const EC = Exception;
            return getException(class Exception extends EC {
            });
        },
        /**范围溢出错误 */
        get OutOfRangeException() {
            const EC = OutOfRangeException;
            return getException(class OutOfRangeException extends EC {
            });
        },
        /**非法参数 */
        get ArgumentException() {
            const EC = ArgumentException;
            return getException(class ArgumentException extends EC {
            });
        },
        /**非法参数：参数类型、结构错误 */
        get ArgumentIllegalException() {
            const EC = ArgumentIllegalException;
            return getException(class ArgumentIllegalException extends EC {
            });
        },
        /**非法参数：不符合预期的定义，比如要>0，比如只能是"A"与"B" */
        get ArgumentFormatException() {
            const EC = ArgumentFormatException;
            return getException(class ArgumentFormatException extends EC {
            });
        },
        /**找不到该有的 */
        get NoFoundException() {
            const EC = NoFoundException;
            return getException(class NoFoundException extends EC {
            });
        },
        /**没有可用响应的异常 */
        get ResponseException() {
            const EC = ResponseException;
            return getException(class ResponseException extends EC {
            });
        },
        /**IO错误 */
        get IOException() {
            const EC = IOException;
            return getException(class IOException extends EC {
            });
        },
        /**网络IO错误 */
        get NetworkIOException() {
            const EC = NetworkIOException;
            return getException(class NetworkIOException extends EC {
            });
        },
        /**繁忙IO错误 */
        get BusyIOException() {
            const EC = BusyIOException;
            return getException(class BusyIOException extends EC {
            });
        },
        /**数据库IO错误 */
        get DatebaseIOException() {
            const EC = DatebaseIOException;
            return getException(class DatebaseIOException extends EC {
            });
        },
        /**中断异常
         * 流程异常中断时应该打印或者抛出这个错误，而后执行接下来的处理逻辑
         */
        get InterruptedException() {
            const EC = InterruptedException;
            return getException(class InterruptedException extends EC {
            });
        },
        /**
         * 非法状态、流程错误
         * 再执行某些任务时有一些前置工作还没准备好时提供这个错误
         */
        get IllegalStateException() {
            const EC = IllegalStateException;
            return getException(class IllegalStateException extends EC {
            });
        },
        /**响应超时的异常 */
        get TimeOutException() {
            const EC = TimeOutException;
            return getException(class TimeOutException extends EC {
            });
        } /**繁忙的异常 */,
        get BusyException() {
            const EC = BusyException;
            return getException(class BusyException extends EC {
            });
        },
        /**共识异常 */
        get ConsensusException() {
            const EC = ConsensusException;
            return getException(class ConsensusException extends EC {
            });
        },
        /**中断 */
        get AbortException() {
            const EC = AbortException;
            return getException(class AbortException extends EC {
            });
        },
        /**响应拒绝异常 */
        get RefuseException() {
            const EC = RefuseException;
            return getException(class RefuseException extends EC {
            });
        },
    };
    return cacheObjectGetter(exceptionHashMap);
}
