import{p}from"./sha256-BzX3ib4e.js";const a=async()=>{await p.prepare()};export{a as p};
