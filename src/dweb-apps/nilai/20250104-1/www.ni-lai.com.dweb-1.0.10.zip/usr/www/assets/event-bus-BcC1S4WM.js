import{cr as o}from"./index-CYXe6mwj.js";const s=o(),t=o();export{s as a,t as o};
