import{p}from"./sha256-CrUNO9YF.js";const a=async()=>{await p.prepare()};export{a as p};
