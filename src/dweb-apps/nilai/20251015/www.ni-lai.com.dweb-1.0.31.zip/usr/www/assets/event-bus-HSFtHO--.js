import{cq as o}from"./index-BGZ72irz.js";const s=o(),t=o();export{s as a,t as o};
