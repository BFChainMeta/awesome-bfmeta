import{p}from"./sha256-Cq7yKpk_.js";const a=async()=>{await p.prepare()};export{a as p};
