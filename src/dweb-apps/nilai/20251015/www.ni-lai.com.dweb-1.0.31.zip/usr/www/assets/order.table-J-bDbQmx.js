var l=(f=>(f[f.init=0]="init",f[f.wait=1]="wait",f[f.fail=2]="fail",f[f.success=3]="success",f[f.refunding=4]="refunding",f[f.refundSuccessful=5]="refundSuccessful",f))(l||{});export{l as G};
