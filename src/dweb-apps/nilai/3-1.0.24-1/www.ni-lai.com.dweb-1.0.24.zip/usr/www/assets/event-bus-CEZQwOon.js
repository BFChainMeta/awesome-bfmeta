import{co as o}from"./index-OuOf5uwz.js";const s=o(),t=o();export{s as a,t as o};
