import{p}from"./sha256-BUnDL285.js";const a=async()=>{await p.prepare()};export{a as p};
