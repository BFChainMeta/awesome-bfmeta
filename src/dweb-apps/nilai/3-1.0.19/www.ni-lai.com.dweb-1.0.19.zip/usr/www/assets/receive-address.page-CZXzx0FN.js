import { d as definePage, R as React, P as Page, O as Navbar, B as Block } from "./index-DCNl9Xz5.js";
const receiveAddress_page = definePage((args) => /* @__PURE__ */ React.createElement(Page, { name: "receiveAddress" }, /* @__PURE__ */ React.createElement(Navbar, { title: "Receive Address", backLink: true }), /* @__PURE__ */ React.createElement(Block, { strongIos: true, outlineIos: true }, "收货地址")));
export {
  receiveAddress_page as default
};
