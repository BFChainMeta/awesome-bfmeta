import { d as definePage, aB as zBrandDetailsParams, aC as useTrpcQueryState, am as adminApi, r as reactExports, U as GoodsSortType, aD as StateFlow, V as useFlow, R as React, P as Page, O as Navbar, _ as NavRight, a2 as Icon, aE as Views, aF as Toolbar, aG as clsx, aH as introduce, aI as goods, aJ as View, Q as PageContent, ad as LoadingPageData, a3 as BlockTitle, a as Button, ac as sales, a4 as Popover, a5 as useCustomMutableRef, $ as colors, a6 as List, a7 as ListItem, a8 as Link, a9 as overall, aa as price_low_to_high, ab as price_high_to_low, ag as GoodsItem, ae as NoData, B as Block, aK as SuperellipseBox, ax as BlobImage, al as usePageQueryState, at as userApi } from "./index-DCNl9Xz5.js";
const brandDetails_page = definePage((args) => {
  const { brand: brand_cache } = args;
  const { brandId } = zBrandDetailsParams.parse(args.f7route.params);
  if (!brandId) {
    return;
  }
  const [brand = brand_cache] = useTrpcQueryState(adminApi.brand.getBrandDetails).useQuery({
    brandId
  });
  const [sortType, setSortType] = reactExports.useState(GoodsSortType.overall);
  const goodsListFactory = (sortType2) => usePageQueryState([], 1, async (preContent, page) => {
    const result = await userApi.getGoodsList.query({
      page,
      pageSize: 20,
      brandId,
      status: 1,
      goodsSort: sortType2
    });
    const content = [...preContent, ...result.data];
    return {
      content,
      nextPage: page + 1,
      end: content.length >= result.total
    };
  });
  const goodsListHub = {
    [GoodsSortType.overall]: goodsListFactory(GoodsSortType.overall),
    [GoodsSortType.sales]: goodsListFactory(GoodsSortType.sales),
    [GoodsSortType.toHigh]: goodsListFactory(GoodsSortType.toHigh),
    [GoodsSortType.toLow]: goodsListFactory(GoodsSortType.toLow)
  };
  const goodsList = goodsListHub[sortType];
  const getOverallI18n = () => {
    const sortTypeI18n = {
      [GoodsSortType.overall]: overall(),
      [GoodsSortType.sales]: sales(),
      [GoodsSortType.toHigh]: price_low_to_high(),
      [GoodsSortType.toLow]: price_high_to_low()
    };
    if (sortType === GoodsSortType.sales) {
      return overall();
    }
    return sortTypeI18n[sortType];
  };
  reactExports.useEffect(() => {
    goodsList.loadFirst();
  }, [sortType]);
  const activeTabFlow = reactExports.useMemo(() => {
    const flow = new StateFlow(args.routeState.activeTab ??= "introduce");
    flow.on((activeTab2) => {
      args.routeState.activeTab = activeTab2;
    });
    return flow;
  }, []);
  const [activeTab, setActiveTab] = useFlow(activeTabFlow);
  const isActiveGoods = activeTab === "goods";
  const isActiveIntroduce = activeTab === "introduce";
  return /* @__PURE__ */ React.createElement(Page, { name: "brand-detail", className: "bg-background", ...args.pageProps, pageContent: false }, /* @__PURE__ */ React.createElement(Navbar, { title: brand?.brandName, backLink: true, color: "white" }, /* @__PURE__ */ React.createElement(NavRight, null, /* @__PURE__ */ React.createElement(
    "button",
    {
      onClick: () => {
        args.safeF7Navigater.homeSearch({
          props: { brandId }
        });
        args.safeF7Navigater.goods;
      },
      className: "px-2"
    },
    /* @__PURE__ */ React.createElement(Icon, { f7: "search", size: 20 })
  ))), /* @__PURE__ */ React.createElement(Views, { tabs: true, className: "fixPageAni" }, /* @__PURE__ */ React.createElement(Toolbar, { bottom: true, tabbar: true, icons: true }, /* @__PURE__ */ React.createElement(
    "button",
    {
      onClick: () => setActiveTab("introduce"),
      className: clsx(
        "flex flex-col items-center justify-center text-xs",
        isActiveIntroduce ? "text-primary" : "text-subtext"
      )
    },
    /* @__PURE__ */ React.createElement(Icon, { f7: "info_circle_fill", size: 24 }),
    /* @__PURE__ */ React.createElement("span", { className: "text-xss pt-1" }, " ", introduce())
  ), /* @__PURE__ */ React.createElement(
    "button",
    {
      onClick: () => setActiveTab("goods"),
      className: clsx(
        "flex flex-col items-center justify-center text-xs",
        isActiveGoods ? "text-primary" : "text-subtext"
      )
    },
    /* @__PURE__ */ React.createElement(Icon, { f7: "cart_fill", size: 24 }),
    /* @__PURE__ */ React.createElement("span", { className: "text-xss pt-1" }, " ", goods())
  )), /* @__PURE__ */ React.createElement(View, { id: "introduce", tab: true, tabActive: isActiveIntroduce }, /* @__PURE__ */ React.createElement(Page, { pageContent: false }, /* @__PURE__ */ React.createElement(Navbar, { hidden: true }), /* @__PURE__ */ React.createElement(PageContent, { className: "px-4" }, brand != null ? /* @__PURE__ */ React.createElement(BrandDetails, { brand }) : /* @__PURE__ */ React.createElement(LoadingPageData, null)))), /* @__PURE__ */ React.createElement(View, { id: "goods", tab: true, tabActive: isActiveGoods }, /* @__PURE__ */ React.createElement(Page, { onPageInit: goodsList.f7OnPageInit, pageContent: false }, /* @__PURE__ */ React.createElement(Navbar, { hidden: true }), /* @__PURE__ */ React.createElement(PageContent, { ...goodsList.f7PageProps, className: "px-4" }, /* @__PURE__ */ React.createElement(BlockTitle, { className: "mb-4 mt-4 text-white" }, /* @__PURE__ */ React.createElement("div", { className: "grid grid-cols-2" }, /* @__PURE__ */ React.createElement(
    Button,
    {
      popoverOpen: ".brand-goods-sotr-popover-menu",
      className: `text-sm ${sortType !== GoodsSortType.sales ? "text-primary" : "text-subtext"}`
    },
    getOverallI18n()
  ), /* @__PURE__ */ React.createElement(
    Button,
    {
      className: `text-sm ${sortType === GoodsSortType.sales ? "text-primary" : "text-subtext"}`,
      onClick: () => setSortType(GoodsSortType.sales)
    },
    sales()
  ))), /* @__PURE__ */ React.createElement(
    Popover,
    {
      verticalPosition: "bottom",
      ref: useCustomMutableRef((it) => {
        it.f7Popover().backdropEl.classList.add(
          "bg-pop-background/10",
          "backdrop-contrast-75"
          // 降低背景对比度
        );
      }),
      arrow: true,
      style: {
        "--f7-popover-bg-color": colors["pop-background"] + "ee"
      },
      className: "brand-goods-sotr-popover-menu drop-shadow-spread-primary backdrop-blur-sm"
    },
    /* @__PURE__ */ React.createElement(List, null, /* @__PURE__ */ React.createElement(ListItem, null, /* @__PURE__ */ React.createElement(
      Link,
      {
        popoverClose: true,
        className: `w-full justify-start text-xs ${sortType === GoodsSortType.overall && "text-primary"}`,
        onClick: () => setSortType(GoodsSortType.overall)
      },
      overall()
    )), /* @__PURE__ */ React.createElement(ListItem, null, /* @__PURE__ */ React.createElement(
      Link,
      {
        popoverClose: true,
        className: `w-full justify-start text-xs ${sortType === GoodsSortType.toHigh && "text-primary"}`,
        onClick: () => setSortType(GoodsSortType.toHigh)
      },
      price_low_to_high()
    )), /* @__PURE__ */ React.createElement(ListItem, null, /* @__PURE__ */ React.createElement(
      Link,
      {
        popoverClose: true,
        className: `w-full justify-start text-xs ${sortType === GoodsSortType.toLow && "text-primary"}`,
        onClick: () => setSortType(GoodsSortType.toLow)
      },
      price_high_to_low()
    )))
  ), goodsList.render({
    content(data) {
      return /* @__PURE__ */ React.createElement("div", { className: `${data.length ? "medium-grid-cols-4 grid-gap grid grid-cols-2" : ""} pb-4` }, data.length ? data.map((item) => /* @__PURE__ */ React.createElement(GoodsItem, { key: item.goodsId, goods: item, ...args })) : /* @__PURE__ */ React.createElement(NoData, null));
    }
  }))))));
});
const BrandDetails = ({ brand }) => {
  return /* @__PURE__ */ React.createElement(React.Fragment, null, /* @__PURE__ */ React.createElement(Block, { className: "flex items-center justify-center py-4" }, /* @__PURE__ */ React.createElement(SuperellipseBox, { className: "rounded-4 bg-white/10", borderWidth: 1, borderColor: colors.primary, borderInsets: true }, /* @__PURE__ */ React.createElement(BlobImage, { bloburi: brand.logo, className: "rounded-2 h-24 w-24", alt: "" }))), /* @__PURE__ */ React.createElement(SuperellipseBox, { className: "bg-pop-background rounded-3 mb-3 w-full p-4 text-justify" }, brand?.description), brand.brandImages.length ? brand.brandImages.map((bloburi) => /* @__PURE__ */ React.createElement(SuperellipseBox, { key: bloburi, className: "rounded-3 mb-3" }, /* @__PURE__ */ React.createElement(BlobImage, { className: "h-auto w-full object-cover", bloburi, fill: true, alt: "" }))) : (
    // 品牌没有介绍图就不用了
    /* @__PURE__ */ React.createElement(React.Fragment, null)
  ));
};
export {
  brandDetails_page as default
};
