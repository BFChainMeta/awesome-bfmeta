import { d as definePage, R as React, P as Page, O as Navbar } from "./index-DCNl9Xz5.js";
const about_page = definePage((args) => {
  return /* @__PURE__ */ React.createElement(Page, { name: "about" }, /* @__PURE__ */ React.createElement(Navbar, { title: "About", backLink: args.backLink }), "About Page...");
});
export {
  about_page as default
};
