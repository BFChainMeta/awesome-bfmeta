import { b as bitcoin } from "./networks-C0ceHyyb.js";
import { d as decompile, c as compile } from "./script-CvjgZ_M0.js";
import { p as prop } from "./address-dOezXghs.js";
import { a, b, c, f, d, e } from "./address-dOezXghs.js";
import { t as typeforce } from "./typeforce-B8ObC9mU.js";
import { OPS as OPS$1 } from "./ops-DRP2Obq2.js";
import { p } from "./p2pk-Mpbu9okv.js";
import "./index-CQT1PcgH.js";
import "./index-DCNl9Xz5.js";
import "./index-Dbv_Z1yj.js";
import "./sha256-VpXgtVg8.js";
import "./WASMInterface-Ufpqlv9U.js";
import "./index-DzX_QLg7.js";
import "./crypto-BhU_zp8e.js";
import "./ripemd160-CxWbMWzE.js";
import "./sha1-CZKCE3aV.js";
const OPS = OPS$1;
function stacksEqual(a2, b2) {
  if (a2.length !== b2.length)
    return false;
  return a2.every((x, i) => {
    return x.equals(b2[i]);
  });
}
function p2data(a2, opts) {
  if (!a2.data && !a2.output)
    throw new TypeError("Not enough data");
  opts = Object.assign({ validate: true }, opts || {});
  typeforce({
    network: typeforce.maybe(typeforce.Object),
    output: typeforce.maybe(typeforce.Buffer),
    data: typeforce.maybe(typeforce.arrayOf(typeforce.Buffer))
  }, a2);
  const network = a2.network || bitcoin;
  const o = { name: "embed", network };
  prop(o, "output", () => {
    if (!a2.data)
      return;
    return compile([OPS.OP_RETURN].concat(a2.data));
  });
  prop(o, "data", () => {
    if (!a2.output)
      return;
    return decompile(a2.output).slice(1);
  });
  if (opts.validate) {
    if (a2.output) {
      const chunks = decompile(a2.output);
      if (chunks[0] !== OPS.OP_RETURN)
        throw new TypeError("Output is invalid");
      if (!chunks.slice(1).every(typeforce.Buffer))
        throw new TypeError("Output is invalid");
      if (a2.data && !stacksEqual(a2.data, o.data))
        throw new TypeError("Data mismatch");
    }
  }
  return Object.assign(o, a2);
}
export {
  p2data as embed,
  a as p2ms,
  p as p2pk,
  b as p2pkh,
  c as p2sh,
  f as p2tr,
  d as p2wpkh,
  e as p2wsh
};
