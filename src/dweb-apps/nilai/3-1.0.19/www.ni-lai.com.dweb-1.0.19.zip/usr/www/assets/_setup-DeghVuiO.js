import { prepareTinySecp256k1 } from "./_setup-biAMZfUo.js";
import { g as getSha3Preparer } from "./sha3-Br3za9hk.js";
import "./index-CQT1PcgH.js";
import "./index-DCNl9Xz5.js";
import "./index-D4lo3-lM.js";
import "./WASMInterface-Ufpqlv9U.js";
import "./index-DzX_QLg7.js";
const prepareEthereumUtil = async () => {
  await prepareTinySecp256k1();
  await getSha3Preparer(224).prepare();
  await getSha3Preparer(256).prepare();
  await getSha3Preparer(384).prepare();
  await getSha3Preparer(512).prepare();
};
export {
  prepareEthereumUtil
};
