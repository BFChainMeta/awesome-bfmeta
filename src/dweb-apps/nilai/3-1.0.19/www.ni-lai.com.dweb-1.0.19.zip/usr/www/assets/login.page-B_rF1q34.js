import { d as definePage, R as React, P as Page, O as Navbar } from "./index-DCNl9Xz5.js";
const login_page = definePage((args) => {
  return /* @__PURE__ */ React.createElement(Page, { name: "login" }, /* @__PURE__ */ React.createElement(Navbar, { title: "Login", backLink: args.backLink }), "Login Page");
});
export {
  login_page as default
};
