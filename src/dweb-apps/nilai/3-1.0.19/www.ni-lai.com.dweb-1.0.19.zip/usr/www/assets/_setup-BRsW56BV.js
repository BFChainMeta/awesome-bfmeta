import { p as prepareSHA256 } from "./sha256-VpXgtVg8.js";
import { p as prepareSHA512 } from "./sha512-vGL6715g.js";
import "./WASMInterface-Ufpqlv9U.js";
import "./index-DzX_QLg7.js";
import "./index-CQT1PcgH.js";
import "./index-DCNl9Xz5.js";
const prepareBip39 = async () => {
  await prepareSHA256.prepare();
  await prepareSHA512.prepare();
};
export {
  prepareBip39
};
