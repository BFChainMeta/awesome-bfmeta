import { d as definePage, r as reactExports, V as useFlow, cE as chinese_id_card, bh as f7, at as userApi, ah as confirm, cF as hk_macao_taiwan_permit, cG as foreign_id_passport, R as React, P as Page, O as Navbar, cB as withdrawal, _ as NavRight, u as useSuperellipseDomRef, cH as record, cI as withdrawal_time_reminder, a6 as List, az as ListInput, cw as cardholder_name, cJ as please_enter_the_cardholders_name, a2 as Icon, cx as bank_card_number, cK as please_enter_your_bank_card_number, cL as registered_mobile_number_with_bank, cM as please_enter_your_bank_registered_phone_number, cN as document_type, cO as please_select_document_type, cy as document_number, cP as please_enter_document_number, cz as opening_bank, cQ as please_enter_the_name_of_the_bank_where_the_account_is_opened, cR as please_enter_the_amount, cA as withdrawal_quantity, cS as minimum_quantity_of_$amount$, cT as maximum_amount_$amount$, cU as all, a as Button, cV as submit, be as AlertDialog, cW as withdrawal_notice, aj as appUserInfoFlow, F as userController, x as toast, cC as fail, ak as updateLoginerUserInfo, co as successfully, bq as delay, cX as the_bank_card_number_must_be_13_to_19_digits, cY as please_enter_a_valid_mobile_phone_number, cZ as please_enter_a_valid_document_number, c_ as please_enter_a_valid_quantity, c$ as the_quantity_cannot_exceed_$amount$, d0 as the_bank_card_number_is_invalid_please_check } from "./index-DCNl9Xz5.js";
const html = String.raw;
const rewardWithdrawal_page = definePage((args) => {
  const [openTipsDialog, setOpenTipsDialog] = reactExports.useState(false);
  const [isLoading, setIsLoading] = reactExports.useState(false);
  const [appUserInfo] = useFlow(appUserInfoFlow);
  const [MAX_AMOUNT, setMAX_AMOUNT] = reactExports.useState((+(appUserInfo.cashbackAmount || 0) * 0.01).toFixed(2));
  const [cardHolder, setCardHolder] = reactExports.useState("");
  const [cardNumber, setCardNumber] = reactExports.useState("");
  const [phoneNumber, setPhoneNumber] = reactExports.useState("");
  const [idNumber, setIdNumber] = reactExports.useState("");
  const [bankName, setBankName] = reactExports.useState("");
  const [withdrawAmount, setWithdrawAmount] = reactExports.useState("");
  const [documentType, setDocumentType] = reactExports.useState(chinese_id_card());
  const formatCardNumber = (value) => {
    return value.replace(/\D/g, "").replace(/(\d{4})(?=\d)/g, "$1 ");
  };
  const luhnCheck = (number) => {
    let sum = 0;
    let shouldDouble = false;
    for (let i = number.length - 1; i >= 0; i--) {
      let digit = parseInt(number[i], 10);
      if (shouldDouble) {
        digit *= 2;
        if (digit > 9) digit -= 9;
      }
      sum += digit;
      shouldDouble = !shouldDouble;
    }
    return sum % 10 === 0;
  };
  reactExports.useEffect(() => {
    const aborter = new AbortController();
    const debounce = (ms) => {
      let delayer;
      return async () => {
        delayer?.cancel("abort");
        const d = delay(ms);
        delayer = d;
        await d;
        if (delayer === d) {
          delayer = void 0;
        }
      };
    };
    const query_debounce = debounce(300);
    (async () => {
      const autocomplete = f7.autocomplete.create({
        inputEl: "#input-bankname",
        openIn: "dropdown",
        preloader: true,
        source: async (query, render) => {
          if (!query) {
            return;
          }
          try {
            await query_debounce();
            console.log("do query", query);
          } catch {
          }
          const list = await userApi.bank.findSubBranch.query({
            searchName: query
          });
          render(list.map((item) => item.fullName));
        },
        renderItem(item, index) {
          return html` <li>
            <label class="item-radio item-content" data-value="${item.value}">
              <div class="item-inner">
                <div style="font-size: 14px;">${item.text}</div>
              </div>
            </label>
          </li>`;
        }
      });
      aborter.signal.addEventListener("abort", () => {
        autocomplete.destroy();
      });
    })();
    return () => aborter.abort("cancel");
  }, []);
  const validateForm = () => {
    const sanitizedCardNumber = cardNumber.replace(/\s/g, "");
    if (!cardHolder.trim()) {
      toast(please_enter_the_cardholders_name());
      return;
    }
    if (!sanitizedCardNumber.match(/^\d{13,19}$/)) {
      toast(the_bank_card_number_must_be_13_to_19_digits());
      return;
    } else if (!luhnCheck(sanitizedCardNumber)) {
      toast(the_bank_card_number_is_invalid_please_check());
      return;
    }
    if (!phoneNumber.match(/^1[3-9]\d{9}$/)) {
      toast(please_enter_a_valid_mobile_phone_number());
      return;
    }
    {
      const checkDocumentNumber = {
        [chinese_id_card()]: () => !idNumber.match(/^\d{15}$|^\d{17}(\d|X|x)$/),
        [hk_macao_taiwan_permit()]: () => !idNumber.match(/^([HhMm]\d{8}|\d{8})$/),
        [foreign_id_passport()]: () => !idNumber.match(/^[A-Za-z0-9]{5,20}$/)
      };
      if (checkDocumentNumber[documentType]()) {
        toast(please_enter_a_valid_document_number());
        return;
      }
    }
    if (!bankName.trim()) {
      toast(please_enter_the_name_of_the_bank_where_the_account_is_opened());
      return;
    }
    if (!withdrawAmount || parseFloat(withdrawAmount) <= 0) {
      toast(please_enter_a_valid_quantity());
      return;
    } else if (parseFloat(withdrawAmount) < 100) {
      toast(
        minimum_quantity_of_$amount$({
          amount: 100
        })
      );
      return;
    } else if (parseFloat(withdrawAmount) > parseFloat(MAX_AMOUNT)) {
      toast(
        the_quantity_cannot_exceed_$amount$({
          amount: MAX_AMOUNT
        })
      );
      return;
    }
    return true;
  };
  const handleSubmit = async () => {
    try {
      setIsLoading(true);
      if (!validateForm()) return;
      const { success } = await userController.submitWithdrawal({
        /** 持卡名 */
        cardHolder,
        /** 卡号 */
        cardNumber,
        /** 电话 */
        phoneNumber,
        /** 身份证 */
        idNumber: `${documentType} ${idNumber}`,
        /** 银行卡号 */
        bankName,
        /** 提取额度 */
        withdrawAmount: (+withdrawAmount * 100).toFixed(0)
      });
      if (success === false) {
        toast(fail());
        return;
      }
      const address = appUserInfo.address;
      await updateLoginerUserInfo(address);
      setMAX_AMOUNT((+(appUserInfo.cashbackAmount || 0) * 0.01).toFixed(2));
      setCardHolder("");
      setCardNumber("");
      setPhoneNumber("");
      setIdNumber("");
      setBankName("");
      setWithdrawAmount("");
      toast(successfully());
    } finally {
      setIsLoading(false);
    }
  };
  const setMaxAmount = () => {
    setWithdrawAmount(MAX_AMOUNT.toString());
  };
  const pickerRef = reactExports.useRef(null);
  reactExports.useEffect(() => {
    pickerRef.current = f7.picker.create({
      inputEl: "#document-type-picker-input",
      rotateEffect: true,
      renderToolbar() {
        return `<div class="toolbar text-primary"><div class="toolbar-inner"><div class="left"></div><div class="right"><a  class="link sheet-close popover-close !text-primary">${confirm()}</a></div></div></div>`;
      },
      cols: [
        {
          textAlign: "center",
          values: [chinese_id_card(), hk_macao_taiwan_permit(), foreign_id_passport()],
          onChange(picker, value) {
            setDocumentType(value);
          }
        }
      ]
    });
    return () => {
      pickerRef.current?.destroy();
    };
  }, []);
  return /* @__PURE__ */ React.createElement(Page, { name: "reward-withdrawal", className: "bg-background" }, /* @__PURE__ */ React.createElement(Navbar, { title: withdrawal(), backLink: true, color: "white", className: "text-white" }, " ", /* @__PURE__ */ React.createElement(NavRight, null, /* @__PURE__ */ React.createElement(
    "button",
    {
      ref: useSuperellipseDomRef(),
      className: "rounded-2 bg-primary w-auto px-2 py-1 text-sm text-black",
      onClick: () => {
        args.safeF7Navigater.mine.rewardWithdrawalList();
      }
    },
    record()
  ))), /* @__PURE__ */ React.createElement("p", { className: "text-xss text-secondary-red px-5 pt-4" }, "*", withdrawal_time_reminder()), /* @__PURE__ */ React.createElement(List, { dividersIos: true, inset: true, className: "bg-pop-background rounded-3 mx-4 mt-4 py-2" }, /* @__PURE__ */ React.createElement(
    ListInput,
    {
      label: cardholder_name(),
      type: "text",
      placeholder: please_enter_the_cardholders_name(),
      value: cardHolder,
      onInput: (e) => setCardHolder(e.target.value),
      clearButton: true
    },
    /* @__PURE__ */ React.createElement(Icon, { slot: "media", f7: "person_circle" })
  ), /* @__PURE__ */ React.createElement(
    ListInput,
    {
      label: bank_card_number(),
      type: "tel",
      placeholder: please_enter_your_bank_card_number(),
      value: cardNumber,
      onInput: (e) => setCardNumber(formatCardNumber(e.target.value)),
      clearButton: true
    },
    /* @__PURE__ */ React.createElement(Icon, { slot: "media", f7: "creditcard" })
  ), /* @__PURE__ */ React.createElement(
    ListInput,
    {
      label: registered_mobile_number_with_bank(),
      type: "tel",
      placeholder: please_enter_your_bank_registered_phone_number(),
      value: phoneNumber,
      onInput: (e) => setPhoneNumber(e.target.value.replace(/\D/g, "")),
      clearButton: true
    },
    /* @__PURE__ */ React.createElement(Icon, { slot: "media", f7: "phone_circle" })
  ), /* @__PURE__ */ React.createElement(
    ListInput,
    {
      id: "document-type-picker-input",
      name: "area",
      label: document_type(),
      placeholder: please_select_document_type(),
      readonly: true,
      value: documentType
    },
    /* @__PURE__ */ React.createElement(Icon, { f7: "house", slot: "media" })
  ), /* @__PURE__ */ React.createElement(
    ListInput,
    {
      label: document_number(),
      type: "text",
      placeholder: please_enter_document_number(),
      value: idNumber,
      onInput: (e) => setIdNumber(e.target.value),
      clearButton: true
    },
    /* @__PURE__ */ React.createElement(Icon, { slot: "media", f7: "person_crop_rectangle" })
  ), /* @__PURE__ */ React.createElement(
    ListInput,
    {
      label: opening_bank(),
      type: "text",
      inputId: "input-bankname",
      placeholder: please_enter_the_name_of_the_bank_where_the_account_is_opened(),
      value: bankName,
      onInput: (e) => setBankName(e.target.value),
      clearButton: true
    },
    /* @__PURE__ */ React.createElement(Icon, { slot: "media", f7: "building_columns" })
  ), /* @__PURE__ */ React.createElement(
    ListInput,
    {
      type: "number",
      value: withdrawAmount,
      placeholder: please_enter_the_amount(),
      onInput: (e) => {
        let value = e.target.value.replace(/[^0-9.]/g, "");
        const parts = value.split(".");
        if (parts.length > 2) {
          value = parts[0] + "." + parts[1];
        }
        if (parts[1] && parts[1].length > 2) {
          value = parts[0] + "." + parts[1].substring(0, 2);
        }
        setWithdrawAmount(value);
      },
      clearButton: true
    },
    /* @__PURE__ */ React.createElement(Icon, { slot: "media", f7: "cloud_download" }),
    /* @__PURE__ */ React.createElement("div", { slot: "label" }, withdrawal_quantity(), /* @__PURE__ */ React.createElement("span", { onClick: () => setOpenTipsDialog(true) }, /* @__PURE__ */ React.createElement(Icon, { f7: "question_circle_fill", className: "text-secondary-red mb-0.5 ml-1", size: 14 })))
  ), withdrawAmount && +withdrawAmount < 100 && /* @__PURE__ */ React.createElement("p", { className: "text-secondary-red px-4 py-1 text-right text-xs" }, minimum_quantity_of_$amount$({ amount: 100 })), /* @__PURE__ */ React.createElement("div", { className: "flex flex-row items-center justify-end pr-2 pt-2" }, /* @__PURE__ */ React.createElement("span", { className: "pr-2 text-sm" }, maximum_amount_$amount$({
    amount: MAX_AMOUNT
  })), /* @__PURE__ */ React.createElement(
    "button",
    {
      ref: useSuperellipseDomRef(),
      className: "rounded-2 bg-primary w-auto px-2 py-1 text-sm text-black",
      onClick: setMaxAmount
    },
    all()
  ))), /* @__PURE__ */ React.createElement(
    Button,
    {
      className: "bg-primary m-auto mb-4 w-full max-w-80 rounded-full text-base font-bold text-black",
      large: true,
      raised: true,
      fill: true,
      preloader: true,
      preloaderColor: "black",
      loading: isLoading,
      onClick: handleSubmit
    },
    submit()
  ), /* @__PURE__ */ React.createElement(AlertDialog, { open: openTipsDialog, onRequireClose: setOpenTipsDialog }, withdrawal_notice()));
});
export {
  rewardWithdrawal_page as default
};
