import { r as reactExports, c1 as obj_assign_props, c2 as renderBuilder, c3 as f7PtrFactory, d as definePage, c4 as z, V as useFlow, R as React, P as Page, O as Navbar, c5 as shipping_address, _ as NavRight, a8 as Link, Q as PageContent, ad as LoadingPageData, ae as NoData, af as SlideInDownListItem, ao as Card, aq as CardContent, as as CardFooter, N as NiLaiIcon, c6 as default_address, a as Button, c7 as delete_this_address, c8 as edit_this_address, c9 as use_this_address, n as ConfirmDialog, ah as confirm, ca as are_you_sure_to_delete_this_address, aj as appUserInfoFlow, F as userController, ak as updateLoginerUserInfo, x as toast, cb as successfully_deleted_address, cc as failed_to_delete_address } from "./index-DCNl9Xz5.js";
import { a as onSelectMineAddress } from "./event-bus-CjvwdHdC.js";
const useFunQueryState = (initValue, api, exec = (api2, input) => api2(...input)) => {
  const [isLoading, setIsLoading] = reactExports.useState(false);
  const [value, setValue] = reactExports.useState(initValue);
  const [error, setError] = reactExports.useState(null);
  const doQuery = async (input, opts) => {
    setIsLoading(true);
    try {
      const output = await exec(api, input, opts);
      setValue(output);
      setError(null);
      return output;
    } catch (err) {
      setError(err);
    } finally {
      setIsLoading(false);
    }
  };
  const queryWithDestructor = (input) => {
    const aborter = new AbortController();
    doQuery(input, {
      signal: aborter.signal
    });
    return () => aborter.abort("cancel");
  };
  const useQuery = (input, deps) => {
    reactExports.useEffect(() => queryWithDestructor(input), deps ?? input);
    return result;
  };
  const f7OnPageInit = (input) => f7PtrFactory(() => doQuery(input));
  const f7OnPtrRefresh = (input) => {
    return (done) => {
      doQuery(input).finally(done);
    };
  };
  const result = obj_assign_props(
    {
      get value() {
        return value;
      },
      set value(value2) {
        setValue(value2);
      }
    },
    Object.freeze({
      isLoading,
      doQuery,
      queryWithDestructor,
      useQuery,
      f7OnPtrRefresh,
      f7OnPageInit,
      get render() {
        return renderBuilder(!isLoading, value, error);
      }
    })
  );
  return result;
};
const z_MimeAddressPageType = z.enum(["pick", "manage"]);
const mineAddress_page = definePage((args) => {
  const type = z_MimeAddressPageType.parse(args.f7route.params.type);
  const [canEdit, setCanEdit] = reactExports.useState(type === "manage");
  const [canPick, setCanPick] = reactExports.useState(type === "pick");
  const [appUserInfo] = useFlow(appUserInfoFlow);
  const addressList = useFunQueryState(appUserInfo.shippingAddressList ?? [], async (address) => {
    const userInfo = await userController.getUserServiceUser(address);
    return userInfo?.shippingAddressList ?? [];
  }).useQuery([appUserInfo.address]);
  const [openConfirmDialog, setOpenConfirmDialog] = reactExports.useState(false);
  const confirmCallBack = reactExports.useRef(() => {
  });
  const select = (item) => {
    if (canPick) {
      onSelectMineAddress.emit({ ...item });
      args.f7router.back();
    }
  };
  const defaultAddress = async (id) => {
    const res = await userController.setDefaultShippingAddress(id);
    if (res) {
      addressList.value = res;
      await updateLoginerUserInfo(appUserInfo.address);
    }
  };
  const deleteAddress = async (id) => {
    confirmCallBack.current = async () => {
      try {
        await userController.deleteShippingAddress(id);
        await updateLoginerUserInfo(appUserInfo.address);
        toast(successfully_deleted_address());
        addressList.doQuery([appUserInfo.address]);
      } catch (err) {
        console.error(err);
        toast(failed_to_delete_address());
      }
    };
    setOpenConfirmDialog(true);
  };
  const gotoEditAddress = (item) => {
    args.safeF7Navigater.mine.editAddress({ props: item });
  };
  return /* @__PURE__ */ React.createElement(Page, { name: "mine-address", className: "bg-background", pageContent: false }, /* @__PURE__ */ React.createElement(Navbar, { title: shipping_address(), backLink: true, color: "white" }, /* @__PURE__ */ React.createElement(NavRight, null, type === "pick" && addressList.value.length > 0 && /* @__PURE__ */ React.createElement(
    Link,
    {
      iconF7: canEdit ? "checkmark_square" : "square_pencil",
      color: "white",
      onClick: () => {
        setCanEdit(!canEdit);
        setCanPick(!canPick);
      }
    }
  ), /* @__PURE__ */ React.createElement(Link, { iconF7: "plus", color: "white", onClick: () => gotoEditAddress() }))), /* @__PURE__ */ React.createElement(PageContent, { ptr: true, ptrPreloader: false, onPtrRefresh: addressList.f7OnPtrRefresh([appUserInfo.address]) }, addressList.render({
    loading: () => /* @__PURE__ */ React.createElement(LoadingPageData, null),
    listEmpty: () => /* @__PURE__ */ React.createElement(NoData, null),
    listItem: (item, index, list) => /* @__PURE__ */ React.createElement(SlideInDownListItem, { group: list, key: item.id, index }, /* @__PURE__ */ React.createElement(Card, { outline: true, className: "bg-pop-background text-white" }, /* @__PURE__ */ React.createElement(CardContent, null, /* @__PURE__ */ React.createElement("div", { className: "flex items-center justify-between", onClick: () => select(item) }, /* @__PURE__ */ React.createElement(AddressInfoView, { className: "flex-grow pb-1 pr-1", info: item }))), /* @__PURE__ */ React.createElement(CardFooter, { className: "border-t-tiny text-xss flex items-center justify-between border-solid border-white/20" }, canEdit ? /* @__PURE__ */ React.createElement(React.Fragment, null, /* @__PURE__ */ React.createElement("button", { className: "flex h-7 items-center", onClick: () => defaultAddress(item.id) }, /* @__PURE__ */ React.createElement(
      "div",
      {
        className: `border-tiny mr-1 flex h-3.5 w-3.5 items-center justify-center ${item.default ? "bg-primary" : "border-white"}`
      },
      item.default && /* @__PURE__ */ React.createElement(
        NiLaiIcon,
        {
          name: "common-selected",
          className: "text-primary icon-2.5",
          style: { "--color-1": "#000000" }
        }
      )
    ), /* @__PURE__ */ React.createElement("span", { className: "ml-1" }, default_address())), /* @__PURE__ */ React.createElement("div", { className: "flex items-center" }, /* @__PURE__ */ React.createElement(
      Button,
      {
        className: "text-secondary-red",
        iconSize: "1.25rem",
        onClick: () => deleteAddress(item.id)
      },
      delete_this_address()
    ), /* @__PURE__ */ React.createElement(Button, { className: "text-primary", iconSize: "1.25rem", onClick: () => gotoEditAddress(item) }, edit_this_address()))) : /* @__PURE__ */ React.createElement(React.Fragment, null, /* @__PURE__ */ React.createElement("div", { className: "flex h-7 items-center" }, item.default && default_address()), /* @__PURE__ */ React.createElement("div", { className: "flex items-center" }, /* @__PURE__ */ React.createElement(Button, { className: "text-primary", iconSize: "1.25rem", onClick: () => select(item) }, use_this_address()))))))
  })), /* @__PURE__ */ React.createElement(
    ConfirmDialog,
    {
      open: openConfirmDialog,
      onRequireClose: setOpenConfirmDialog,
      onConfirmCallback: confirmCallBack.current,
      confirmText: confirm()
    },
    are_you_sure_to_delete_this_address()
  ));
});
const AddressInfoView = ({
  info,
  ...props
}) => {
  return /* @__PURE__ */ React.createElement("div", { ...props }, /* @__PURE__ */ React.createElement("div", { className: "flex items-center justify-start py-1 font-bold" }, /* @__PURE__ */ React.createElement("span", { className: "mr-2" }, info.name), /* @__PURE__ */ React.createElement("span", null, info.phone)), /* @__PURE__ */ React.createElement("div", { className: "overflow-hidden break-all pb-1 text-xs text-white/80" }, `${info.area || ""} ${info.address}`));
};
export {
  AddressInfoView,
  mineAddress_page as default,
  z_MimeAddressPageType
};
