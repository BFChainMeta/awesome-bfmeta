import { d as definePage, V as useFlow, c1 as obj_assign_props, ba as get_showAsset_balance, R as React, P as Page, O as Navbar, cq as my_points, _ as NavRight, u as useSuperellipseDomRef, cr as history, af as SlideInDownListItem, ae as NoData, ao as Card, aO as useSuperellipseCustomMutableRef, aq as CardContent, cs as appUserAssetsFlow } from "./index-DCNl9Xz5.js";
import { a as AssetTypeIcon, A as AssetTypeName } from "./asset-type-Ct4QfOzQ.js";
const minePoints_page = definePage((args) => {
  const [assetInfo] = useFlow(appUserAssetsFlow);
  const addressAssetTypeList = (() => {
    const values = Object.values(assetInfo).filter((item) => !!item);
    values.sort((a, b) => {
      if (a.assetType === "CCC") {
        return -1;
      }
      if (a.assetType === "NLT") return -1;
      return 0;
    });
    return values.map((item) => {
      return obj_assign_props(item, {
        assetBalance: get_showAsset_balance(item.assetNumber)
      });
    });
  })();
  return /* @__PURE__ */ React.createElement(Page, { name: "mine-points", className: "bg-background p-4" }, /* @__PURE__ */ React.createElement(Navbar, { title: my_points(), backLink: true, color: "white", className: "text-white" }, /* @__PURE__ */ React.createElement(NavRight, null, /* @__PURE__ */ React.createElement(
    "button",
    {
      ref: useSuperellipseDomRef(),
      onClick: () => args.safeF7Navigater.mine.minePointsRecord(),
      className: "rounded-1 bg-primary w-auto px-2 py-1 text-sm text-black"
    },
    history()
  ))), addressAssetTypeList.length ? addressAssetTypeList.map((item, index) => {
    return /* @__PURE__ */ React.createElement(SlideInDownListItem, { group: addressAssetTypeList, key: item.assetType + item.sourceChainName, index }, /* @__PURE__ */ React.createElement(MimePoint, { info: item }));
  }) : /* @__PURE__ */ React.createElement(NoData, { cssClass: "text-subtext mt-[20vh]" }));
});
const MimePoint = ({ info }) => {
  return /* @__PURE__ */ React.createElement(Card, { ref: useSuperellipseCustomMutableRef((it) => it.el), className: "bg-pop-background rounded-2 m-0 mb-3" }, /* @__PURE__ */ React.createElement(CardContent, null, /* @__PURE__ */ React.createElement("div", { className: "flex items-center" }, /* @__PURE__ */ React.createElement(
    AssetTypeIcon,
    {
      assetType: info.assetType,
      chainName: info.sourceChainName,
      cssClass: "w-8 h-8 rounded-full"
    }
  ), /* @__PURE__ */ React.createElement("div", { className: "ml-2" }, /* @__PURE__ */ React.createElement(AssetTypeName, { assetType: info.assetType, chainName: info.sourceChainName })), /* @__PURE__ */ React.createElement("div", { className: "ml-auto overflow-hidden text-ellipsis text-right font-bold" }, info.assetBalance))));
};
export {
  minePoints_page as default
};
