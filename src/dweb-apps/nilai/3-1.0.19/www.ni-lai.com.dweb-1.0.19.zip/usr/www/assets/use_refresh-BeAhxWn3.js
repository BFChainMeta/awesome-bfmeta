import { r as reactExports } from "./index-DCNl9Xz5.js";
const useRefresh = () => {
  const [, contentRefresh] = reactExports.useReducer((x) => x + 1, 0);
  return contentRefresh;
};
export {
  useRefresh as u
};
