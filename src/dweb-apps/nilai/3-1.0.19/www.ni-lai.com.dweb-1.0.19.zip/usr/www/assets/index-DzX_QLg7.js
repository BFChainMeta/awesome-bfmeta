const global = globalThis || void 0 || self;
export {
  global as g
};
