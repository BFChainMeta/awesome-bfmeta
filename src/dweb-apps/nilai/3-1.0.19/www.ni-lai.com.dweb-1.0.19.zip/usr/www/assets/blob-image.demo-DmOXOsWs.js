import { d as definePage, R as React, P as Page, ax as BlobImage } from "./index-DCNl9Xz5.js";
const blobImage_demo = definePage((args) => {
  return /* @__PURE__ */ React.createElement(Page, { name: "blob-image" }, /* @__PURE__ */ React.createElement(BlobImage, { bloburi: "s2VZM6cx/768x768/UZRC_HRj~W%LxuofaeWB~pt79GR*jZWBa}t7/4x4" }), /* @__PURE__ */ React.createElement(BlobImage, { bloburi: "WlfJQ3Rk/1024x1024/U8Hx~fog00t7~qj[IUju00WBtmWBMxf6X9fR/4x4" }), /* @__PURE__ */ React.createElement(BlobImage, { bloburi: "rK5t7-IK/1024x1024/UVLyNRIP01x+_*xTO=R;00tI%gV[L0NgWBsR/4x4" }));
});
export {
  blobImage_demo as default
};
