import { B as Buffer } from "./index-CQT1PcgH.js";
import { b as bs58check } from "./index-Dbv_Z1yj.js";
function decodeRaw(buffer, version) {
  if (buffer.length === 33) {
    return {
      version: buffer[0],
      privateKey: buffer.slice(1, 33),
      compressed: false
    };
  }
  if (buffer.length !== 34)
    throw new Error("Invalid WIF length");
  if (buffer[33] !== 1)
    throw new Error("Invalid compression flag");
  return {
    version: buffer[0],
    privateKey: buffer.slice(1, 33),
    compressed: true
  };
}
function encodeRaw(version, privateKey, compressed) {
  var result = Buffer.alloc(compressed ? 34 : 33);
  result.writeUInt8(version, 0);
  privateKey.copy(result, 1);
  if (compressed) {
    result[33] = 1;
  }
  return result;
}
function decode(string, version) {
  return decodeRaw(bs58check.decode(string));
}
function encode(version, privateKey, compressed) {
  return bs58check.encode(encodeRaw(version, privateKey, compressed));
}
export {
  decode as d,
  encode as e
};
