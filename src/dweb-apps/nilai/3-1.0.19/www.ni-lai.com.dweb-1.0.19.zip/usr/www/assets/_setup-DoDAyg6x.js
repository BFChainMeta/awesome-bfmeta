import { p as prepareSHA256 } from "./sha256-VpXgtVg8.js";
const prepareBs58check = async () => {
  await prepareSHA256.prepare();
};
export {
  prepareBs58check as p
};
