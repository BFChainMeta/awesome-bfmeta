import { d as definePage, bO as zDiscountPointsParams, V as useFlow, al as usePageQueryState, r as reactExports, R as React, P as Page, O as Navbar, bP as select_discount_points, b9 as need_to_consume_$consume$_to_deduction$deduction$, ba as get_showAsset_balance, a as Button, bQ as purchase_at_original_price, bR as why_are_the_available_points_less_than_the_actual_ones, bS as due_to_the_nature_of_digital_points_in_order_to_maximize_the_normal_deduction_of_points_all_orders_to_be_deducted_will_also_be_calculated_in_advance, ad as LoadingPageData, ae as NoData, af as SlideInDownListItem, aO as useSuperellipseCustomMutableRef, ao as Card, aq as CardContent, bD as insufficient_points_unable_to_deduct, aj as appUserInfoFlow, x as toast, am as adminApi, I as ccchainController, F as userController } from "./index-DCNl9Xz5.js";
import { a as AssetTypeIcon, A as AssetTypeName } from "./asset-type-Ct4QfOzQ.js";
import { o as onSelectDiscountPoints } from "./event-bus-CjvwdHdC.js";
const goodsDiscountPoints_page = definePage((args) => {
  const { needAmount } = zDiscountPointsParams.parse(args.f7route.params);
  const [appUserInfo] = useFlow(appUserInfoFlow);
  const select = (item) => {
    if (item) {
      if (BigInt(item.assetBalance) < BigInt(needAmount)) {
        toast(insufficient_points_unable_to_deduct());
        return;
      }
    }
    onSelectDiscountPoints.emit(item && { ...item });
    args.f7router.back();
  };
  const brandAssetTypeInfoList = usePageQueryState([], 1, async (preContent, page) => {
    const result = await adminApi.brand.getBrandAssetTypeInfoList.query();
    const assetInfo = await ccchainController.getAddressAsset(appUserInfo.address);
    const { data: allUnDeductionList } = await userController.getDeductionList(1, 20, {
      getAll: true,
      done: false
    });
    allUnDeductionList.forEach((item) => {
      const assetType = item.transactionInfo.trs.asset.transferAsset.assetType;
      const amount = BigInt(item.transactionInfo.trs.asset.transferAsset.amount);
      const asset = assetInfo[assetType];
      if (asset) {
        const balance = BigInt(asset.assetNumber || "0");
        const diffBalance = balance - amount;
        asset.assetNumber = diffBalance >= 0 ? String(diffBalance) : "0";
      }
    });
    const content = [
      ...preContent,
      ...result.map((item) => {
        return {
          ...item.brandAssetTypeInfo.stablecoin,
          assetBalance: assetInfo[item.brandAssetTypeInfo.stablecoin.assetType]?.assetNumber || "0"
        };
      })
    ].filter((item) => item.assetBalance && BigInt(item.assetBalance) > 0n);
    content.sort((a, b) => {
      if (BigInt(a.assetBalance) > BigInt(b.assetBalance)) {
        return -1;
      }
      return 0;
    });
    return {
      content,
      nextPage: page + 1,
      end: true
    };
  });
  reactExports.useEffect(() => {
    brandAssetTypeInfoList.loadFirst();
  }, []);
  return /* @__PURE__ */ React.createElement(Page, { name: "goods-discount-points", className: "bg-background p-4", ...brandAssetTypeInfoList.f7PageInfiniteProps }, /* @__PURE__ */ React.createElement(Navbar, { title: select_discount_points(), backLink: true, color: "white", className: "text-white" }), /* @__PURE__ */ React.createElement("div", { className: "mb-4 flex items-center justify-between" }, /* @__PURE__ */ React.createElement(
    "div",
    {
      className: "mb-1 mr-1 text-sm",
      dangerouslySetInnerHTML: {
        __html: need_to_consume_$consume$_to_deduction$deduction$({
          consumeCss: "text-secondary-green",
          consume: get_showAsset_balance(needAmount),
          deductionCss: "text-primary",
          deduction: get_showAsset_balance(needAmount)
        })
      }
    }
  ), /* @__PURE__ */ React.createElement(Button, { onClick: () => select(), className: "bg-primary text-black" }, purchase_at_original_price())), /* @__PURE__ */ React.createElement("div", { className: "text-secondary-red text-xs" }, "*", why_are_the_available_points_less_than_the_actual_ones()), /* @__PURE__ */ React.createElement("div", { className: "text-subtext mb-2 text-xs" }, due_to_the_nature_of_digital_points_in_order_to_maximize_the_normal_deduction_of_points_all_orders_to_be_deducted_will_also_be_calculated_in_advance()), brandAssetTypeInfoList.render({
    loading() {
      return /* @__PURE__ */ React.createElement(LoadingPageData, null);
    },
    listEmpty() {
      return /* @__PURE__ */ React.createElement(NoData, null);
    },
    listItem(item, index) {
      return /* @__PURE__ */ React.createElement(SlideInDownListItem, { group: brandAssetTypeInfoList, key: item.assetType + item.chainMagic, index }, /* @__PURE__ */ React.createElement(MimePoint, { info: item, select, targetBalance: needAmount }));
    }
  }));
});
const MimePoint = ({ info, select, targetBalance }) => {
  const canSelect = BigInt(info.assetBalance) >= BigInt(targetBalance);
  return /* @__PURE__ */ React.createElement(
    "button",
    {
      ref: useSuperellipseCustomMutableRef((it) => it),
      className: `mb-3 ${!canSelect && "text-subtext/30"}`,
      onClick: () => select(info)
    },
    /* @__PURE__ */ React.createElement(Card, { className: `${canSelect ? "bg-pop-background" : "bg-pop-background/30"} m-0` }, /* @__PURE__ */ React.createElement(CardContent, null, /* @__PURE__ */ React.createElement("div", { className: "flex items-center" }, /* @__PURE__ */ React.createElement(
      AssetTypeIcon,
      {
        assetType: info.assetType,
        chainName: info.chainName,
        cssClass: "w-8 h-8 rounded-full"
      }
    ), /* @__PURE__ */ React.createElement("div", { className: "ml-2" }, /* @__PURE__ */ React.createElement(AssetTypeName, { assetType: info.assetType, chainName: info.chainName })), /* @__PURE__ */ React.createElement("div", { className: "ml-auto overflow-hidden text-ellipsis text-right font-bold" }, canSelect ? /* @__PURE__ */ React.createElement("div", { className: "text-secondary-green text-right" }, get_showAsset_balance(info.assetBalance)) : /* @__PURE__ */ React.createElement("div", { className: "text-secondary-red text-right" }, insufficient_points_unable_to_deduct())))))
  );
};
export {
  goodsDiscountPoints_page as default
};
