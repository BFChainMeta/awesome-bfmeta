import { cd as pureEvent } from "./index-DCNl9Xz5.js";
const onSelectMineAddress = pureEvent();
const onSelectDiscountPoints = pureEvent();
export {
  onSelectMineAddress as a,
  onSelectDiscountPoints as o
};
