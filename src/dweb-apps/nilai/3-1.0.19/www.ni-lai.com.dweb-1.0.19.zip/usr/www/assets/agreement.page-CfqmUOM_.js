import { d as definePage, M as zAgreement, r as reactExports, R as React, P as Page, O as Navbar, Q as PageContent, S as personal_information_protection_policy, T as user_service_agreement } from "./index-DCNl9Xz5.js";
function _getDefaults() {
  return {
    async: false,
    breaks: false,
    extensions: null,
    gfm: true,
    hooks: null,
    pedantic: false,
    renderer: null,
    silent: false,
    tokenizer: null,
    walkTokens: null
  };
}
let _defaults = _getDefaults();
function changeDefaults(newDefaults) {
  _defaults = newDefaults;
}
const noopTest = { exec: () => null };
function edit(regex, opt = "") {
  let source = typeof regex === "string" ? regex : regex.source;
  const obj = {
    replace: (name, val) => {
      let valSource = typeof val === "string" ? val : val.source;
      valSource = valSource.replace(other.caret, "$1");
      source = source.replace(name, valSource);
      return obj;
    },
    getRegex: () => {
      return new RegExp(source, opt);
    }
  };
  return obj;
}
const other = {
  codeRemoveIndent: /^(?: {1,4}| {0,3}\t)/gm,
  outputLinkReplace: /\\([\[\]])/g,
  indentCodeCompensation: /^(\s+)(?:```)/,
  beginningSpace: /^\s+/,
  endingHash: /#$/,
  startingSpaceChar: /^ /,
  endingSpaceChar: / $/,
  nonSpaceChar: /[^ ]/,
  newLineCharGlobal: /\n/g,
  tabCharGlobal: /\t/g,
  multipleSpaceGlobal: /\s+/g,
  blankLine: /^[ \t]*$/,
  doubleBlankLine: /\n[ \t]*\n[ \t]*$/,
  blockquoteStart: /^ {0,3}>/,
  blockquoteSetextReplace: /\n {0,3}((?:=+|-+) *)(?=\n|$)/g,
  blockquoteSetextReplace2: /^ {0,3}>[ \t]?/gm,
  listReplaceTabs: /^\t+/,
  listReplaceNesting: /^ {1,4}(?=( {4})*[^ ])/g,
  listIsTask: /^\[[ xX]\] /,
  listReplaceTask: /^\[[ xX]\] +/,
  anyLine: /\n.*\n/,
  hrefBrackets: /^<(.*)>$/,
  tableDelimiter: /[:|]/,
  tableAlignChars: /^\||\| *$/g,
  tableRowBlankLine: /\n[ \t]*$/,
  tableAlignRight: /^ *-+: *$/,
  tableAlignCenter: /^ *:-+: *$/,
  tableAlignLeft: /^ *:-+ *$/,
  startATag: /^<a /i,
  endATag: /^<\/a>/i,
  startPreScriptTag: /^<(pre|code|kbd|script)(\s|>)/i,
  endPreScriptTag: /^<\/(pre|code|kbd|script)(\s|>)/i,
  startAngleBracket: /^</,
  endAngleBracket: />$/,
  pedanticHrefTitle: /^([^'"]*[^\s])\s+(['"])(.*)\2/,
  unicodeAlphaNumeric: /[\p{L}\p{N}]/u,
  escapeTest: /[&<>"']/,
  escapeReplace: /[&<>"']/g,
  escapeTestNoEncode: /[<>"']|&(?!(#\d{1,7}|#[Xx][a-fA-F0-9]{1,6}|\w+);)/,
  escapeReplaceNoEncode: /[<>"']|&(?!(#\d{1,7}|#[Xx][a-fA-F0-9]{1,6}|\w+);)/g,
  unescapeTest: /&(#(?:\d+)|(?:#x[0-9A-Fa-f]+)|(?:\w+));?/ig,
  caret: /(^|[^\[])\^/g,
  percentDecode: /%25/g,
  findPipe: /\|/g,
  splitPipe: / \|/,
  slashPipe: /\\\|/g,
  carriageReturn: /\r\n|\r/g,
  spaceLine: /^ +$/gm,
  notSpaceStart: /^\S*/,
  endingNewline: /\n$/,
  listItemRegex: (bull) => new RegExp(`^( {0,3}${bull})((?:[	 ][^\\n]*)?(?:\\n|$))`),
  nextBulletRegex: (indent) => new RegExp(`^ {0,${Math.min(3, indent - 1)}}(?:[*+-]|\\d{1,9}[.)])((?:[ 	][^\\n]*)?(?:\\n|$))`),
  hrRegex: (indent) => new RegExp(`^ {0,${Math.min(3, indent - 1)}}((?:- *){3,}|(?:_ *){3,}|(?:\\* *){3,})(?:\\n+|$)`),
  fencesBeginRegex: (indent) => new RegExp(`^ {0,${Math.min(3, indent - 1)}}(?:\`\`\`|~~~)`),
  headingBeginRegex: (indent) => new RegExp(`^ {0,${Math.min(3, indent - 1)}}#`),
  htmlBeginRegex: (indent) => new RegExp(`^ {0,${Math.min(3, indent - 1)}}<(?:[a-z].*>|!--)`, "i")
};
const newline = /^(?:[ \t]*(?:\n|$))+/;
const blockCode = /^((?: {4}| {0,3}\t)[^\n]+(?:\n(?:[ \t]*(?:\n|$))*)?)+/;
const fences = /^ {0,3}(`{3,}(?=[^`\n]*(?:\n|$))|~{3,})([^\n]*)(?:\n|$)(?:|([\s\S]*?)(?:\n|$))(?: {0,3}\1[~`]* *(?=\n|$)|$)/;
const hr = /^ {0,3}((?:-[\t ]*){3,}|(?:_[ \t]*){3,}|(?:\*[ \t]*){3,})(?:\n+|$)/;
const heading = /^ {0,3}(#{1,6})(?=\s|$)(.*)(?:\n+|$)/;
const bullet = /(?:[*+-]|\d{1,9}[.)])/;
const lheading = edit(/^(?!bull |blockCode|fences|blockquote|heading|html)((?:.|\n(?!\s*?\n|bull |blockCode|fences|blockquote|heading|html))+?)\n {0,3}(=+|-+) *(?:\n+|$)/).replace(/bull/g, bullet).replace(/blockCode/g, /(?: {4}| {0,3}\t)/).replace(/fences/g, / {0,3}(?:`{3,}|~{3,})/).replace(/blockquote/g, / {0,3}>/).replace(/heading/g, / {0,3}#{1,6}/).replace(/html/g, / {0,3}<[^\n>]+>\n/).getRegex();
const _paragraph = /^([^\n]+(?:\n(?!hr|heading|lheading|blockquote|fences|list|html|table| +\n)[^\n]+)*)/;
const blockText = /^[^\n]+/;
const _blockLabel = /(?!\s*\])(?:\\.|[^\[\]\\])+/;
const def = edit(/^ {0,3}\[(label)\]: *(?:\n[ \t]*)?([^<\s][^\s]*|<.*?>)(?:(?: +(?:\n[ \t]*)?| *\n[ \t]*)(title))? *(?:\n+|$)/).replace("label", _blockLabel).replace("title", /(?:"(?:\\"?|[^"\\])*"|'[^'\n]*(?:\n[^'\n]+)*\n?'|\([^()]*\))/).getRegex();
const list = edit(/^( {0,3}bull)([ \t][^\n]+?)?(?:\n|$)/).replace(/bull/g, bullet).getRegex();
const _tag = "address|article|aside|base|basefont|blockquote|body|caption|center|col|colgroup|dd|details|dialog|dir|div|dl|dt|fieldset|figcaption|figure|footer|form|frame|frameset|h[1-6]|head|header|hr|html|iframe|legend|li|link|main|menu|menuitem|meta|nav|noframes|ol|optgroup|option|p|param|search|section|summary|table|tbody|td|tfoot|th|thead|title|tr|track|ul";
const _comment = /<!--(?:-?>|[\s\S]*?(?:-->|$))/;
const html = edit("^ {0,3}(?:<(script|pre|style|textarea)[\\s>][\\s\\S]*?(?:</\\1>[^\\n]*\\n+|$)|comment[^\\n]*(\\n+|$)|<\\?[\\s\\S]*?(?:\\?>\\n*|$)|<![A-Z][\\s\\S]*?(?:>\\n*|$)|<!\\[CDATA\\[[\\s\\S]*?(?:\\]\\]>\\n*|$)|</?(tag)(?: +|\\n|/?>)[\\s\\S]*?(?:(?:\\n[ 	]*)+\\n|$)|<(?!script|pre|style|textarea)([a-z][\\w-]*)(?:attribute)*? */?>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n[ 	]*)+\\n|$)|</(?!script|pre|style|textarea)[a-z][\\w-]*\\s*>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n[ 	]*)+\\n|$))", "i").replace("comment", _comment).replace("tag", _tag).replace("attribute", / +[a-zA-Z:_][\w.:-]*(?: *= *"[^"\n]*"| *= *'[^'\n]*'| *= *[^\s"'=<>`]+)?/).getRegex();
const paragraph = edit(_paragraph).replace("hr", hr).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("|lheading", "").replace("|table", "").replace("blockquote", " {0,3}>").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", _tag).getRegex();
const blockquote = edit(/^( {0,3}> ?(paragraph|[^\n]*)(?:\n|$))+/).replace("paragraph", paragraph).getRegex();
const blockNormal = {
  blockquote,
  code: blockCode,
  def,
  fences,
  heading,
  hr,
  html,
  lheading,
  list,
  newline,
  paragraph,
  table: noopTest,
  text: blockText
};
const gfmTable = edit("^ *([^\\n ].*)\\n {0,3}((?:\\| *)?:?-+:? *(?:\\| *:?-+:? *)*(?:\\| *)?)(?:\\n((?:(?! *\\n|hr|heading|blockquote|code|fences|list|html).*(?:\\n|$))*)\\n*|$)").replace("hr", hr).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("blockquote", " {0,3}>").replace("code", "(?: {4}| {0,3}	)[^\\n]").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", _tag).getRegex();
const blockGfm = {
  ...blockNormal,
  table: gfmTable,
  paragraph: edit(_paragraph).replace("hr", hr).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("|lheading", "").replace("table", gfmTable).replace("blockquote", " {0,3}>").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", _tag).getRegex()
};
const blockPedantic = {
  ...blockNormal,
  html: edit(`^ *(?:comment *(?:\\n|\\s*$)|<(tag)[\\s\\S]+?</\\1> *(?:\\n{2,}|\\s*$)|<tag(?:"[^"]*"|'[^']*'|\\s[^'"/>\\s]*)*?/?> *(?:\\n{2,}|\\s*$))`).replace("comment", _comment).replace(/tag/g, "(?!(?:a|em|strong|small|s|cite|q|dfn|abbr|data|time|code|var|samp|kbd|sub|sup|i|b|u|mark|ruby|rt|rp|bdi|bdo|span|br|wbr|ins|del|img)\\b)\\w+(?!:|[^\\w\\s@]*@)\\b").getRegex(),
  def: /^ *\[([^\]]+)\]: *<?([^\s>]+)>?(?: +(["(][^\n]+[")]))? *(?:\n+|$)/,
  heading: /^(#{1,6})(.*)(?:\n+|$)/,
  fences: noopTest,
  // fences not supported
  lheading: /^(.+?)\n {0,3}(=+|-+) *(?:\n+|$)/,
  paragraph: edit(_paragraph).replace("hr", hr).replace("heading", " *#{1,6} *[^\n]").replace("lheading", lheading).replace("|table", "").replace("blockquote", " {0,3}>").replace("|fences", "").replace("|list", "").replace("|html", "").replace("|tag", "").getRegex()
};
const escape$1 = /^\\([!"#$%&'()*+,\-./:;<=>?@\[\]\\^_`{|}~])/;
const inlineCode = /^(`+)([^`]|[^`][\s\S]*?[^`])\1(?!`)/;
const br = /^( {2,}|\\)\n(?!\s*$)/;
const inlineText = /^(`+|[^`])(?:(?= {2,}\n)|[\s\S]*?(?:(?=[\\<!\[`*_]|\b_|$)|[^ ](?= {2,}\n)))/;
const _punctuation = /[\p{P}\p{S}]/u;
const _punctuationOrSpace = /[\s\p{P}\p{S}]/u;
const _notPunctuationOrSpace = /[^\s\p{P}\p{S}]/u;
const punctuation = edit(/^((?![*_])punctSpace)/, "u").replace(/punctSpace/g, _punctuationOrSpace).getRegex();
const blockSkip = /\[[^[\]]*?\]\((?:\\.|[^\\\(\)]|\((?:\\.|[^\\\(\)])*\))*\)|`[^`]*?`|<[^<>]*?>/g;
const emStrongLDelim = edit(/^(?:\*+(?:((?!\*)punct)|[^\s*]))|^_+(?:((?!_)punct)|([^\s_]))/, "u").replace(/punct/g, _punctuation).getRegex();
const emStrongRDelimAst = edit("^[^_*]*?__[^_*]*?\\*[^_*]*?(?=__)|[^*]+(?=[^*])|(?!\\*)punct(\\*+)(?=[\\s]|$)|notPunctSpace(\\*+)(?!\\*)(?=punctSpace|$)|(?!\\*)punctSpace(\\*+)(?=notPunctSpace)|[\\s](\\*+)(?!\\*)(?=punct)|(?!\\*)punct(\\*+)(?!\\*)(?=punct)|notPunctSpace(\\*+)(?=notPunctSpace)", "gu").replace(/notPunctSpace/g, _notPunctuationOrSpace).replace(/punctSpace/g, _punctuationOrSpace).replace(/punct/g, _punctuation).getRegex();
const emStrongRDelimUnd = edit("^[^_*]*?\\*\\*[^_*]*?_[^_*]*?(?=\\*\\*)|[^_]+(?=[^_])|(?!_)punct(_+)(?=[\\s]|$)|notPunctSpace(_+)(?!_)(?=punctSpace|$)|(?!_)punctSpace(_+)(?=notPunctSpace)|[\\s](_+)(?!_)(?=punct)|(?!_)punct(_+)(?!_)(?=punct)", "gu").replace(/notPunctSpace/g, _notPunctuationOrSpace).replace(/punctSpace/g, _punctuationOrSpace).replace(/punct/g, _punctuation).getRegex();
const anyPunctuation = edit(/\\(punct)/, "gu").replace(/punct/g, _punctuation).getRegex();
const autolink = edit(/^<(scheme:[^\s\x00-\x1f<>]*|email)>/).replace("scheme", /[a-zA-Z][a-zA-Z0-9+.-]{1,31}/).replace("email", /[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+(@)[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)+(?![-_])/).getRegex();
const _inlineComment = edit(_comment).replace("(?:-->|$)", "-->").getRegex();
const tag = edit("^comment|^</[a-zA-Z][\\w:-]*\\s*>|^<[a-zA-Z][\\w-]*(?:attribute)*?\\s*/?>|^<\\?[\\s\\S]*?\\?>|^<![a-zA-Z]+\\s[\\s\\S]*?>|^<!\\[CDATA\\[[\\s\\S]*?\\]\\]>").replace("comment", _inlineComment).replace("attribute", /\s+[a-zA-Z:_][\w.:-]*(?:\s*=\s*"[^"]*"|\s*=\s*'[^']*'|\s*=\s*[^\s"'=<>`]+)?/).getRegex();
const _inlineLabel = /(?:\[(?:\\.|[^\[\]\\])*\]|\\.|`[^`]*`|[^\[\]\\`])*?/;
const link = edit(/^!?\[(label)\]\(\s*(href)(?:\s+(title))?\s*\)/).replace("label", _inlineLabel).replace("href", /<(?:\\.|[^\n<>\\])+>|[^\s\x00-\x1f]*/).replace("title", /"(?:\\"?|[^"\\])*"|'(?:\\'?|[^'\\])*'|\((?:\\\)?|[^)\\])*\)/).getRegex();
const reflink = edit(/^!?\[(label)\]\[(ref)\]/).replace("label", _inlineLabel).replace("ref", _blockLabel).getRegex();
const nolink = edit(/^!?\[(ref)\](?:\[\])?/).replace("ref", _blockLabel).getRegex();
const reflinkSearch = edit("reflink|nolink(?!\\()", "g").replace("reflink", reflink).replace("nolink", nolink).getRegex();
const inlineNormal = {
  _backpedal: noopTest,
  // only used for GFM url
  anyPunctuation,
  autolink,
  blockSkip,
  br,
  code: inlineCode,
  del: noopTest,
  emStrongLDelim,
  emStrongRDelimAst,
  emStrongRDelimUnd,
  escape: escape$1,
  link,
  nolink,
  punctuation,
  reflink,
  reflinkSearch,
  tag,
  text: inlineText,
  url: noopTest
};
const inlinePedantic = {
  ...inlineNormal,
  link: edit(/^!?\[(label)\]\((.*?)\)/).replace("label", _inlineLabel).getRegex(),
  reflink: edit(/^!?\[(label)\]\s*\[([^\]]*)\]/).replace("label", _inlineLabel).getRegex()
};
const inlineGfm = {
  ...inlineNormal,
  escape: edit(escape$1).replace("])", "~|])").getRegex(),
  url: edit(/^((?:ftp|https?):\/\/|www\.)(?:[a-zA-Z0-9\-]+\.?)+[^\s<]*|^email/, "i").replace("email", /[A-Za-z0-9._+-]+(@)[a-zA-Z0-9-_]+(?:\.[a-zA-Z0-9-_]*[a-zA-Z0-9])+(?![-_])/).getRegex(),
  _backpedal: /(?:[^?!.,:;*_'"~()&]+|\([^)]*\)|&(?![a-zA-Z0-9]+;$)|[?!.,:;*_'"~)]+(?!$))+/,
  del: /^(~~?)(?=[^\s~])((?:\\.|[^\\])*?(?:\\.|[^\s~\\]))\1(?=[^~]|$)/,
  text: /^([`~]+|[^`~])(?:(?= {2,}\n)|(?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)|[\s\S]*?(?:(?=[\\<!\[`*~_]|\b_|https?:\/\/|ftp:\/\/|www\.|$)|[^ ](?= {2,}\n)|[^a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-](?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)))/
};
const inlineBreaks = {
  ...inlineGfm,
  br: edit(br).replace("{2,}", "*").getRegex(),
  text: edit(inlineGfm.text).replace("\\b_", "\\b_| {2,}\\n").replace(/\{2,\}/g, "*").getRegex()
};
const block = {
  normal: blockNormal,
  gfm: blockGfm,
  pedantic: blockPedantic
};
const inline = {
  normal: inlineNormal,
  gfm: inlineGfm,
  breaks: inlineBreaks,
  pedantic: inlinePedantic
};
const escapeReplacements = {
  "&": "&amp;",
  "<": "&lt;",
  ">": "&gt;",
  '"': "&quot;",
  "'": "&#39;"
};
const getEscapeReplacement = (ch) => escapeReplacements[ch];
function escape(html2, encode) {
  if (encode) {
    if (other.escapeTest.test(html2)) {
      return html2.replace(other.escapeReplace, getEscapeReplacement);
    }
  } else {
    if (other.escapeTestNoEncode.test(html2)) {
      return html2.replace(other.escapeReplaceNoEncode, getEscapeReplacement);
    }
  }
  return html2;
}
function cleanUrl(href) {
  try {
    href = encodeURI(href).replace(other.percentDecode, "%");
  } catch {
    return null;
  }
  return href;
}
function splitCells(tableRow, count) {
  const row = tableRow.replace(other.findPipe, (match, offset, str) => {
    let escaped = false;
    let curr = offset;
    while (--curr >= 0 && str[curr] === "\\")
      escaped = !escaped;
    if (escaped) {
      return "|";
    } else {
      return " |";
    }
  }), cells = row.split(other.splitPipe);
  let i = 0;
  if (!cells[0].trim()) {
    cells.shift();
  }
  if (cells.length > 0 && !cells.at(-1)?.trim()) {
    cells.pop();
  }
  if (count) {
    if (cells.length > count) {
      cells.splice(count);
    } else {
      while (cells.length < count)
        cells.push("");
    }
  }
  for (; i < cells.length; i++) {
    cells[i] = cells[i].trim().replace(other.slashPipe, "|");
  }
  return cells;
}
function rtrim(str, c, invert) {
  const l = str.length;
  if (l === 0) {
    return "";
  }
  let suffLen = 0;
  while (suffLen < l) {
    const currChar = str.charAt(l - suffLen - 1);
    if (currChar === c && !invert) {
      suffLen++;
    } else if (currChar !== c && invert) {
      suffLen++;
    } else {
      break;
    }
  }
  return str.slice(0, l - suffLen);
}
function findClosingBracket(str, b) {
  if (str.indexOf(b[1]) === -1) {
    return -1;
  }
  let level = 0;
  for (let i = 0; i < str.length; i++) {
    if (str[i] === "\\") {
      i++;
    } else if (str[i] === b[0]) {
      level++;
    } else if (str[i] === b[1]) {
      level--;
      if (level < 0) {
        return i;
      }
    }
  }
  return -1;
}
function outputLink(cap, link2, raw, lexer, rules) {
  const href = link2.href;
  const title = link2.title || null;
  const text = cap[1].replace(rules.other.outputLinkReplace, "$1");
  if (cap[0].charAt(0) !== "!") {
    lexer.state.inLink = true;
    const token = {
      type: "link",
      raw,
      href,
      title,
      text,
      tokens: lexer.inlineTokens(text)
    };
    lexer.state.inLink = false;
    return token;
  }
  return {
    type: "image",
    raw,
    href,
    title,
    text
  };
}
function indentCodeCompensation(raw, text, rules) {
  const matchIndentToCode = raw.match(rules.other.indentCodeCompensation);
  if (matchIndentToCode === null) {
    return text;
  }
  const indentToCode = matchIndentToCode[1];
  return text.split("\n").map((node) => {
    const matchIndentInNode = node.match(rules.other.beginningSpace);
    if (matchIndentInNode === null) {
      return node;
    }
    const [indentInNode] = matchIndentInNode;
    if (indentInNode.length >= indentToCode.length) {
      return node.slice(indentToCode.length);
    }
    return node;
  }).join("\n");
}
class _Tokenizer {
  options;
  rules;
  // set by the lexer
  lexer;
  // set by the lexer
  constructor(options) {
    this.options = options || _defaults;
  }
  space(src) {
    const cap = this.rules.block.newline.exec(src);
    if (cap && cap[0].length > 0) {
      return {
        type: "space",
        raw: cap[0]
      };
    }
  }
  code(src) {
    const cap = this.rules.block.code.exec(src);
    if (cap) {
      const text = cap[0].replace(this.rules.other.codeRemoveIndent, "");
      return {
        type: "code",
        raw: cap[0],
        codeBlockStyle: "indented",
        text: !this.options.pedantic ? rtrim(text, "\n") : text
      };
    }
  }
  fences(src) {
    const cap = this.rules.block.fences.exec(src);
    if (cap) {
      const raw = cap[0];
      const text = indentCodeCompensation(raw, cap[3] || "", this.rules);
      return {
        type: "code",
        raw,
        lang: cap[2] ? cap[2].trim().replace(this.rules.inline.anyPunctuation, "$1") : cap[2],
        text
      };
    }
  }
  heading(src) {
    const cap = this.rules.block.heading.exec(src);
    if (cap) {
      let text = cap[2].trim();
      if (this.rules.other.endingHash.test(text)) {
        const trimmed = rtrim(text, "#");
        if (this.options.pedantic) {
          text = trimmed.trim();
        } else if (!trimmed || this.rules.other.endingSpaceChar.test(trimmed)) {
          text = trimmed.trim();
        }
      }
      return {
        type: "heading",
        raw: cap[0],
        depth: cap[1].length,
        text,
        tokens: this.lexer.inline(text)
      };
    }
  }
  hr(src) {
    const cap = this.rules.block.hr.exec(src);
    if (cap) {
      return {
        type: "hr",
        raw: rtrim(cap[0], "\n")
      };
    }
  }
  blockquote(src) {
    const cap = this.rules.block.blockquote.exec(src);
    if (cap) {
      let lines = rtrim(cap[0], "\n").split("\n");
      let raw = "";
      let text = "";
      const tokens = [];
      while (lines.length > 0) {
        let inBlockquote = false;
        const currentLines = [];
        let i;
        for (i = 0; i < lines.length; i++) {
          if (this.rules.other.blockquoteStart.test(lines[i])) {
            currentLines.push(lines[i]);
            inBlockquote = true;
          } else if (!inBlockquote) {
            currentLines.push(lines[i]);
          } else {
            break;
          }
        }
        lines = lines.slice(i);
        const currentRaw = currentLines.join("\n");
        const currentText = currentRaw.replace(this.rules.other.blockquoteSetextReplace, "\n    $1").replace(this.rules.other.blockquoteSetextReplace2, "");
        raw = raw ? `${raw}
${currentRaw}` : currentRaw;
        text = text ? `${text}
${currentText}` : currentText;
        const top = this.lexer.state.top;
        this.lexer.state.top = true;
        this.lexer.blockTokens(currentText, tokens, true);
        this.lexer.state.top = top;
        if (lines.length === 0) {
          break;
        }
        const lastToken = tokens.at(-1);
        if (lastToken?.type === "code") {
          break;
        } else if (lastToken?.type === "blockquote") {
          const oldToken = lastToken;
          const newText = oldToken.raw + "\n" + lines.join("\n");
          const newToken = this.blockquote(newText);
          tokens[tokens.length - 1] = newToken;
          raw = raw.substring(0, raw.length - oldToken.raw.length) + newToken.raw;
          text = text.substring(0, text.length - oldToken.text.length) + newToken.text;
          break;
        } else if (lastToken?.type === "list") {
          const oldToken = lastToken;
          const newText = oldToken.raw + "\n" + lines.join("\n");
          const newToken = this.list(newText);
          tokens[tokens.length - 1] = newToken;
          raw = raw.substring(0, raw.length - lastToken.raw.length) + newToken.raw;
          text = text.substring(0, text.length - oldToken.raw.length) + newToken.raw;
          lines = newText.substring(tokens.at(-1).raw.length).split("\n");
          continue;
        }
      }
      return {
        type: "blockquote",
        raw,
        tokens,
        text
      };
    }
  }
  list(src) {
    let cap = this.rules.block.list.exec(src);
    if (cap) {
      let bull = cap[1].trim();
      const isordered = bull.length > 1;
      const list2 = {
        type: "list",
        raw: "",
        ordered: isordered,
        start: isordered ? +bull.slice(0, -1) : "",
        loose: false,
        items: []
      };
      bull = isordered ? `\\d{1,9}\\${bull.slice(-1)}` : `\\${bull}`;
      if (this.options.pedantic) {
        bull = isordered ? bull : "[*+-]";
      }
      const itemRegex = this.rules.other.listItemRegex(bull);
      let endsWithBlankLine = false;
      while (src) {
        let endEarly = false;
        let raw = "";
        let itemContents = "";
        if (!(cap = itemRegex.exec(src))) {
          break;
        }
        if (this.rules.block.hr.test(src)) {
          break;
        }
        raw = cap[0];
        src = src.substring(raw.length);
        let line = cap[2].split("\n", 1)[0].replace(this.rules.other.listReplaceTabs, (t) => " ".repeat(3 * t.length));
        let nextLine = src.split("\n", 1)[0];
        let blankLine = !line.trim();
        let indent = 0;
        if (this.options.pedantic) {
          indent = 2;
          itemContents = line.trimStart();
        } else if (blankLine) {
          indent = cap[1].length + 1;
        } else {
          indent = cap[2].search(this.rules.other.nonSpaceChar);
          indent = indent > 4 ? 1 : indent;
          itemContents = line.slice(indent);
          indent += cap[1].length;
        }
        if (blankLine && this.rules.other.blankLine.test(nextLine)) {
          raw += nextLine + "\n";
          src = src.substring(nextLine.length + 1);
          endEarly = true;
        }
        if (!endEarly) {
          const nextBulletRegex = this.rules.other.nextBulletRegex(indent);
          const hrRegex = this.rules.other.hrRegex(indent);
          const fencesBeginRegex = this.rules.other.fencesBeginRegex(indent);
          const headingBeginRegex = this.rules.other.headingBeginRegex(indent);
          const htmlBeginRegex = this.rules.other.htmlBeginRegex(indent);
          while (src) {
            const rawLine = src.split("\n", 1)[0];
            let nextLineWithoutTabs;
            nextLine = rawLine;
            if (this.options.pedantic) {
              nextLine = nextLine.replace(this.rules.other.listReplaceNesting, "  ");
              nextLineWithoutTabs = nextLine;
            } else {
              nextLineWithoutTabs = nextLine.replace(this.rules.other.tabCharGlobal, "    ");
            }
            if (fencesBeginRegex.test(nextLine)) {
              break;
            }
            if (headingBeginRegex.test(nextLine)) {
              break;
            }
            if (htmlBeginRegex.test(nextLine)) {
              break;
            }
            if (nextBulletRegex.test(nextLine)) {
              break;
            }
            if (hrRegex.test(nextLine)) {
              break;
            }
            if (nextLineWithoutTabs.search(this.rules.other.nonSpaceChar) >= indent || !nextLine.trim()) {
              itemContents += "\n" + nextLineWithoutTabs.slice(indent);
            } else {
              if (blankLine) {
                break;
              }
              if (line.replace(this.rules.other.tabCharGlobal, "    ").search(this.rules.other.nonSpaceChar) >= 4) {
                break;
              }
              if (fencesBeginRegex.test(line)) {
                break;
              }
              if (headingBeginRegex.test(line)) {
                break;
              }
              if (hrRegex.test(line)) {
                break;
              }
              itemContents += "\n" + nextLine;
            }
            if (!blankLine && !nextLine.trim()) {
              blankLine = true;
            }
            raw += rawLine + "\n";
            src = src.substring(rawLine.length + 1);
            line = nextLineWithoutTabs.slice(indent);
          }
        }
        if (!list2.loose) {
          if (endsWithBlankLine) {
            list2.loose = true;
          } else if (this.rules.other.doubleBlankLine.test(raw)) {
            endsWithBlankLine = true;
          }
        }
        let istask = null;
        let ischecked;
        if (this.options.gfm) {
          istask = this.rules.other.listIsTask.exec(itemContents);
          if (istask) {
            ischecked = istask[0] !== "[ ] ";
            itemContents = itemContents.replace(this.rules.other.listReplaceTask, "");
          }
        }
        list2.items.push({
          type: "list_item",
          raw,
          task: !!istask,
          checked: ischecked,
          loose: false,
          text: itemContents,
          tokens: []
        });
        list2.raw += raw;
      }
      const lastItem = list2.items.at(-1);
      if (lastItem) {
        lastItem.raw = lastItem.raw.trimEnd();
        lastItem.text = lastItem.text.trimEnd();
      } else {
        return;
      }
      list2.raw = list2.raw.trimEnd();
      for (let i = 0; i < list2.items.length; i++) {
        this.lexer.state.top = false;
        list2.items[i].tokens = this.lexer.blockTokens(list2.items[i].text, []);
        if (!list2.loose) {
          const spacers = list2.items[i].tokens.filter((t) => t.type === "space");
          const hasMultipleLineBreaks = spacers.length > 0 && spacers.some((t) => this.rules.other.anyLine.test(t.raw));
          list2.loose = hasMultipleLineBreaks;
        }
      }
      if (list2.loose) {
        for (let i = 0; i < list2.items.length; i++) {
          list2.items[i].loose = true;
        }
      }
      return list2;
    }
  }
  html(src) {
    const cap = this.rules.block.html.exec(src);
    if (cap) {
      const token = {
        type: "html",
        block: true,
        raw: cap[0],
        pre: cap[1] === "pre" || cap[1] === "script" || cap[1] === "style",
        text: cap[0]
      };
      return token;
    }
  }
  def(src) {
    const cap = this.rules.block.def.exec(src);
    if (cap) {
      const tag2 = cap[1].toLowerCase().replace(this.rules.other.multipleSpaceGlobal, " ");
      const href = cap[2] ? cap[2].replace(this.rules.other.hrefBrackets, "$1").replace(this.rules.inline.anyPunctuation, "$1") : "";
      const title = cap[3] ? cap[3].substring(1, cap[3].length - 1).replace(this.rules.inline.anyPunctuation, "$1") : cap[3];
      return {
        type: "def",
        tag: tag2,
        raw: cap[0],
        href,
        title
      };
    }
  }
  table(src) {
    const cap = this.rules.block.table.exec(src);
    if (!cap) {
      return;
    }
    if (!this.rules.other.tableDelimiter.test(cap[2])) {
      return;
    }
    const headers = splitCells(cap[1]);
    const aligns = cap[2].replace(this.rules.other.tableAlignChars, "").split("|");
    const rows = cap[3]?.trim() ? cap[3].replace(this.rules.other.tableRowBlankLine, "").split("\n") : [];
    const item = {
      type: "table",
      raw: cap[0],
      header: [],
      align: [],
      rows: []
    };
    if (headers.length !== aligns.length) {
      return;
    }
    for (const align of aligns) {
      if (this.rules.other.tableAlignRight.test(align)) {
        item.align.push("right");
      } else if (this.rules.other.tableAlignCenter.test(align)) {
        item.align.push("center");
      } else if (this.rules.other.tableAlignLeft.test(align)) {
        item.align.push("left");
      } else {
        item.align.push(null);
      }
    }
    for (let i = 0; i < headers.length; i++) {
      item.header.push({
        text: headers[i],
        tokens: this.lexer.inline(headers[i]),
        header: true,
        align: item.align[i]
      });
    }
    for (const row of rows) {
      item.rows.push(splitCells(row, item.header.length).map((cell, i) => {
        return {
          text: cell,
          tokens: this.lexer.inline(cell),
          header: false,
          align: item.align[i]
        };
      }));
    }
    return item;
  }
  lheading(src) {
    const cap = this.rules.block.lheading.exec(src);
    if (cap) {
      return {
        type: "heading",
        raw: cap[0],
        depth: cap[2].charAt(0) === "=" ? 1 : 2,
        text: cap[1],
        tokens: this.lexer.inline(cap[1])
      };
    }
  }
  paragraph(src) {
    const cap = this.rules.block.paragraph.exec(src);
    if (cap) {
      const text = cap[1].charAt(cap[1].length - 1) === "\n" ? cap[1].slice(0, -1) : cap[1];
      return {
        type: "paragraph",
        raw: cap[0],
        text,
        tokens: this.lexer.inline(text)
      };
    }
  }
  text(src) {
    const cap = this.rules.block.text.exec(src);
    if (cap) {
      return {
        type: "text",
        raw: cap[0],
        text: cap[0],
        tokens: this.lexer.inline(cap[0])
      };
    }
  }
  escape(src) {
    const cap = this.rules.inline.escape.exec(src);
    if (cap) {
      return {
        type: "escape",
        raw: cap[0],
        text: cap[1]
      };
    }
  }
  tag(src) {
    const cap = this.rules.inline.tag.exec(src);
    if (cap) {
      if (!this.lexer.state.inLink && this.rules.other.startATag.test(cap[0])) {
        this.lexer.state.inLink = true;
      } else if (this.lexer.state.inLink && this.rules.other.endATag.test(cap[0])) {
        this.lexer.state.inLink = false;
      }
      if (!this.lexer.state.inRawBlock && this.rules.other.startPreScriptTag.test(cap[0])) {
        this.lexer.state.inRawBlock = true;
      } else if (this.lexer.state.inRawBlock && this.rules.other.endPreScriptTag.test(cap[0])) {
        this.lexer.state.inRawBlock = false;
      }
      return {
        type: "html",
        raw: cap[0],
        inLink: this.lexer.state.inLink,
        inRawBlock: this.lexer.state.inRawBlock,
        block: false,
        text: cap[0]
      };
    }
  }
  link(src) {
    const cap = this.rules.inline.link.exec(src);
    if (cap) {
      const trimmedUrl = cap[2].trim();
      if (!this.options.pedantic && this.rules.other.startAngleBracket.test(trimmedUrl)) {
        if (!this.rules.other.endAngleBracket.test(trimmedUrl)) {
          return;
        }
        const rtrimSlash = rtrim(trimmedUrl.slice(0, -1), "\\");
        if ((trimmedUrl.length - rtrimSlash.length) % 2 === 0) {
          return;
        }
      } else {
        const lastParenIndex = findClosingBracket(cap[2], "()");
        if (lastParenIndex > -1) {
          const start = cap[0].indexOf("!") === 0 ? 5 : 4;
          const linkLen = start + cap[1].length + lastParenIndex;
          cap[2] = cap[2].substring(0, lastParenIndex);
          cap[0] = cap[0].substring(0, linkLen).trim();
          cap[3] = "";
        }
      }
      let href = cap[2];
      let title = "";
      if (this.options.pedantic) {
        const link2 = this.rules.other.pedanticHrefTitle.exec(href);
        if (link2) {
          href = link2[1];
          title = link2[3];
        }
      } else {
        title = cap[3] ? cap[3].slice(1, -1) : "";
      }
      href = href.trim();
      if (this.rules.other.startAngleBracket.test(href)) {
        if (this.options.pedantic && !this.rules.other.endAngleBracket.test(trimmedUrl)) {
          href = href.slice(1);
        } else {
          href = href.slice(1, -1);
        }
      }
      return outputLink(cap, {
        href: href ? href.replace(this.rules.inline.anyPunctuation, "$1") : href,
        title: title ? title.replace(this.rules.inline.anyPunctuation, "$1") : title
      }, cap[0], this.lexer, this.rules);
    }
  }
  reflink(src, links) {
    let cap;
    if ((cap = this.rules.inline.reflink.exec(src)) || (cap = this.rules.inline.nolink.exec(src))) {
      const linkString = (cap[2] || cap[1]).replace(this.rules.other.multipleSpaceGlobal, " ");
      const link2 = links[linkString.toLowerCase()];
      if (!link2) {
        const text = cap[0].charAt(0);
        return {
          type: "text",
          raw: text,
          text
        };
      }
      return outputLink(cap, link2, cap[0], this.lexer, this.rules);
    }
  }
  emStrong(src, maskedSrc, prevChar = "") {
    let match = this.rules.inline.emStrongLDelim.exec(src);
    if (!match)
      return;
    if (match[3] && prevChar.match(this.rules.other.unicodeAlphaNumeric))
      return;
    const nextChar = match[1] || match[2] || "";
    if (!nextChar || !prevChar || this.rules.inline.punctuation.exec(prevChar)) {
      const lLength = [...match[0]].length - 1;
      let rDelim, rLength, delimTotal = lLength, midDelimTotal = 0;
      const endReg = match[0][0] === "*" ? this.rules.inline.emStrongRDelimAst : this.rules.inline.emStrongRDelimUnd;
      endReg.lastIndex = 0;
      maskedSrc = maskedSrc.slice(-1 * src.length + lLength);
      while ((match = endReg.exec(maskedSrc)) != null) {
        rDelim = match[1] || match[2] || match[3] || match[4] || match[5] || match[6];
        if (!rDelim)
          continue;
        rLength = [...rDelim].length;
        if (match[3] || match[4]) {
          delimTotal += rLength;
          continue;
        } else if (match[5] || match[6]) {
          if (lLength % 3 && !((lLength + rLength) % 3)) {
            midDelimTotal += rLength;
            continue;
          }
        }
        delimTotal -= rLength;
        if (delimTotal > 0)
          continue;
        rLength = Math.min(rLength, rLength + delimTotal + midDelimTotal);
        const lastCharLength = [...match[0]][0].length;
        const raw = src.slice(0, lLength + match.index + lastCharLength + rLength);
        if (Math.min(lLength, rLength) % 2) {
          const text2 = raw.slice(1, -1);
          return {
            type: "em",
            raw,
            text: text2,
            tokens: this.lexer.inlineTokens(text2)
          };
        }
        const text = raw.slice(2, -2);
        return {
          type: "strong",
          raw,
          text,
          tokens: this.lexer.inlineTokens(text)
        };
      }
    }
  }
  codespan(src) {
    const cap = this.rules.inline.code.exec(src);
    if (cap) {
      let text = cap[2].replace(this.rules.other.newLineCharGlobal, " ");
      const hasNonSpaceChars = this.rules.other.nonSpaceChar.test(text);
      const hasSpaceCharsOnBothEnds = this.rules.other.startingSpaceChar.test(text) && this.rules.other.endingSpaceChar.test(text);
      if (hasNonSpaceChars && hasSpaceCharsOnBothEnds) {
        text = text.substring(1, text.length - 1);
      }
      return {
        type: "codespan",
        raw: cap[0],
        text
      };
    }
  }
  br(src) {
    const cap = this.rules.inline.br.exec(src);
    if (cap) {
      return {
        type: "br",
        raw: cap[0]
      };
    }
  }
  del(src) {
    const cap = this.rules.inline.del.exec(src);
    if (cap) {
      return {
        type: "del",
        raw: cap[0],
        text: cap[2],
        tokens: this.lexer.inlineTokens(cap[2])
      };
    }
  }
  autolink(src) {
    const cap = this.rules.inline.autolink.exec(src);
    if (cap) {
      let text, href;
      if (cap[2] === "@") {
        text = cap[1];
        href = "mailto:" + text;
      } else {
        text = cap[1];
        href = text;
      }
      return {
        type: "link",
        raw: cap[0],
        text,
        href,
        tokens: [
          {
            type: "text",
            raw: text,
            text
          }
        ]
      };
    }
  }
  url(src) {
    let cap;
    if (cap = this.rules.inline.url.exec(src)) {
      let text, href;
      if (cap[2] === "@") {
        text = cap[0];
        href = "mailto:" + text;
      } else {
        let prevCapZero;
        do {
          prevCapZero = cap[0];
          cap[0] = this.rules.inline._backpedal.exec(cap[0])?.[0] ?? "";
        } while (prevCapZero !== cap[0]);
        text = cap[0];
        if (cap[1] === "www.") {
          href = "http://" + cap[0];
        } else {
          href = cap[0];
        }
      }
      return {
        type: "link",
        raw: cap[0],
        text,
        href,
        tokens: [
          {
            type: "text",
            raw: text,
            text
          }
        ]
      };
    }
  }
  inlineText(src) {
    const cap = this.rules.inline.text.exec(src);
    if (cap) {
      const escaped = this.lexer.state.inRawBlock;
      return {
        type: "text",
        raw: cap[0],
        text: cap[0],
        escaped
      };
    }
  }
}
class _Lexer {
  tokens;
  options;
  state;
  tokenizer;
  inlineQueue;
  constructor(options) {
    this.tokens = [];
    this.tokens.links = /* @__PURE__ */ Object.create(null);
    this.options = options || _defaults;
    this.options.tokenizer = this.options.tokenizer || new _Tokenizer();
    this.tokenizer = this.options.tokenizer;
    this.tokenizer.options = this.options;
    this.tokenizer.lexer = this;
    this.inlineQueue = [];
    this.state = {
      inLink: false,
      inRawBlock: false,
      top: true
    };
    const rules = {
      other,
      block: block.normal,
      inline: inline.normal
    };
    if (this.options.pedantic) {
      rules.block = block.pedantic;
      rules.inline = inline.pedantic;
    } else if (this.options.gfm) {
      rules.block = block.gfm;
      if (this.options.breaks) {
        rules.inline = inline.breaks;
      } else {
        rules.inline = inline.gfm;
      }
    }
    this.tokenizer.rules = rules;
  }
  /**
   * Expose Rules
   */
  static get rules() {
    return {
      block,
      inline
    };
  }
  /**
   * Static Lex Method
   */
  static lex(src, options) {
    const lexer = new _Lexer(options);
    return lexer.lex(src);
  }
  /**
   * Static Lex Inline Method
   */
  static lexInline(src, options) {
    const lexer = new _Lexer(options);
    return lexer.inlineTokens(src);
  }
  /**
   * Preprocessing
   */
  lex(src) {
    src = src.replace(other.carriageReturn, "\n");
    this.blockTokens(src, this.tokens);
    for (let i = 0; i < this.inlineQueue.length; i++) {
      const next = this.inlineQueue[i];
      this.inlineTokens(next.src, next.tokens);
    }
    this.inlineQueue = [];
    return this.tokens;
  }
  blockTokens(src, tokens = [], lastParagraphClipped = false) {
    if (this.options.pedantic) {
      src = src.replace(other.tabCharGlobal, "    ").replace(other.spaceLine, "");
    }
    while (src) {
      let token;
      if (this.options.extensions?.block?.some((extTokenizer) => {
        if (token = extTokenizer.call({ lexer: this }, src, tokens)) {
          src = src.substring(token.raw.length);
          tokens.push(token);
          return true;
        }
        return false;
      })) {
        continue;
      }
      if (token = this.tokenizer.space(src)) {
        src = src.substring(token.raw.length);
        const lastToken = tokens.at(-1);
        if (token.raw.length === 1 && lastToken !== void 0) {
          lastToken.raw += "\n";
        } else {
          tokens.push(token);
        }
        continue;
      }
      if (token = this.tokenizer.code(src)) {
        src = src.substring(token.raw.length);
        const lastToken = tokens.at(-1);
        if (lastToken?.type === "paragraph" || lastToken?.type === "text") {
          lastToken.raw += "\n" + token.raw;
          lastToken.text += "\n" + token.text;
          this.inlineQueue.at(-1).src = lastToken.text;
        } else {
          tokens.push(token);
        }
        continue;
      }
      if (token = this.tokenizer.fences(src)) {
        src = src.substring(token.raw.length);
        tokens.push(token);
        continue;
      }
      if (token = this.tokenizer.heading(src)) {
        src = src.substring(token.raw.length);
        tokens.push(token);
        continue;
      }
      if (token = this.tokenizer.hr(src)) {
        src = src.substring(token.raw.length);
        tokens.push(token);
        continue;
      }
      if (token = this.tokenizer.blockquote(src)) {
        src = src.substring(token.raw.length);
        tokens.push(token);
        continue;
      }
      if (token = this.tokenizer.list(src)) {
        src = src.substring(token.raw.length);
        tokens.push(token);
        continue;
      }
      if (token = this.tokenizer.html(src)) {
        src = src.substring(token.raw.length);
        tokens.push(token);
        continue;
      }
      if (token = this.tokenizer.def(src)) {
        src = src.substring(token.raw.length);
        const lastToken = tokens.at(-1);
        if (lastToken?.type === "paragraph" || lastToken?.type === "text") {
          lastToken.raw += "\n" + token.raw;
          lastToken.text += "\n" + token.raw;
          this.inlineQueue.at(-1).src = lastToken.text;
        } else if (!this.tokens.links[token.tag]) {
          this.tokens.links[token.tag] = {
            href: token.href,
            title: token.title
          };
        }
        continue;
      }
      if (token = this.tokenizer.table(src)) {
        src = src.substring(token.raw.length);
        tokens.push(token);
        continue;
      }
      if (token = this.tokenizer.lheading(src)) {
        src = src.substring(token.raw.length);
        tokens.push(token);
        continue;
      }
      let cutSrc = src;
      if (this.options.extensions?.startBlock) {
        let startIndex = Infinity;
        const tempSrc = src.slice(1);
        let tempStart;
        this.options.extensions.startBlock.forEach((getStartIndex) => {
          tempStart = getStartIndex.call({ lexer: this }, tempSrc);
          if (typeof tempStart === "number" && tempStart >= 0) {
            startIndex = Math.min(startIndex, tempStart);
          }
        });
        if (startIndex < Infinity && startIndex >= 0) {
          cutSrc = src.substring(0, startIndex + 1);
        }
      }
      if (this.state.top && (token = this.tokenizer.paragraph(cutSrc))) {
        const lastToken = tokens.at(-1);
        if (lastParagraphClipped && lastToken?.type === "paragraph") {
          lastToken.raw += "\n" + token.raw;
          lastToken.text += "\n" + token.text;
          this.inlineQueue.pop();
          this.inlineQueue.at(-1).src = lastToken.text;
        } else {
          tokens.push(token);
        }
        lastParagraphClipped = cutSrc.length !== src.length;
        src = src.substring(token.raw.length);
        continue;
      }
      if (token = this.tokenizer.text(src)) {
        src = src.substring(token.raw.length);
        const lastToken = tokens.at(-1);
        if (lastToken?.type === "text") {
          lastToken.raw += "\n" + token.raw;
          lastToken.text += "\n" + token.text;
          this.inlineQueue.pop();
          this.inlineQueue.at(-1).src = lastToken.text;
        } else {
          tokens.push(token);
        }
        continue;
      }
      if (src) {
        const errMsg = "Infinite loop on byte: " + src.charCodeAt(0);
        if (this.options.silent) {
          console.error(errMsg);
          break;
        } else {
          throw new Error(errMsg);
        }
      }
    }
    this.state.top = true;
    return tokens;
  }
  inline(src, tokens = []) {
    this.inlineQueue.push({ src, tokens });
    return tokens;
  }
  /**
   * Lexing/Compiling
   */
  inlineTokens(src, tokens = []) {
    let maskedSrc = src;
    let match = null;
    if (this.tokens.links) {
      const links = Object.keys(this.tokens.links);
      if (links.length > 0) {
        while ((match = this.tokenizer.rules.inline.reflinkSearch.exec(maskedSrc)) != null) {
          if (links.includes(match[0].slice(match[0].lastIndexOf("[") + 1, -1))) {
            maskedSrc = maskedSrc.slice(0, match.index) + "[" + "a".repeat(match[0].length - 2) + "]" + maskedSrc.slice(this.tokenizer.rules.inline.reflinkSearch.lastIndex);
          }
        }
      }
    }
    while ((match = this.tokenizer.rules.inline.blockSkip.exec(maskedSrc)) != null) {
      maskedSrc = maskedSrc.slice(0, match.index) + "[" + "a".repeat(match[0].length - 2) + "]" + maskedSrc.slice(this.tokenizer.rules.inline.blockSkip.lastIndex);
    }
    while ((match = this.tokenizer.rules.inline.anyPunctuation.exec(maskedSrc)) != null) {
      maskedSrc = maskedSrc.slice(0, match.index) + "++" + maskedSrc.slice(this.tokenizer.rules.inline.anyPunctuation.lastIndex);
    }
    let keepPrevChar = false;
    let prevChar = "";
    while (src) {
      if (!keepPrevChar) {
        prevChar = "";
      }
      keepPrevChar = false;
      let token;
      if (this.options.extensions?.inline?.some((extTokenizer) => {
        if (token = extTokenizer.call({ lexer: this }, src, tokens)) {
          src = src.substring(token.raw.length);
          tokens.push(token);
          return true;
        }
        return false;
      })) {
        continue;
      }
      if (token = this.tokenizer.escape(src)) {
        src = src.substring(token.raw.length);
        tokens.push(token);
        continue;
      }
      if (token = this.tokenizer.tag(src)) {
        src = src.substring(token.raw.length);
        tokens.push(token);
        continue;
      }
      if (token = this.tokenizer.link(src)) {
        src = src.substring(token.raw.length);
        tokens.push(token);
        continue;
      }
      if (token = this.tokenizer.reflink(src, this.tokens.links)) {
        src = src.substring(token.raw.length);
        const lastToken = tokens.at(-1);
        if (token.type === "text" && lastToken?.type === "text") {
          lastToken.raw += token.raw;
          lastToken.text += token.text;
        } else {
          tokens.push(token);
        }
        continue;
      }
      if (token = this.tokenizer.emStrong(src, maskedSrc, prevChar)) {
        src = src.substring(token.raw.length);
        tokens.push(token);
        continue;
      }
      if (token = this.tokenizer.codespan(src)) {
        src = src.substring(token.raw.length);
        tokens.push(token);
        continue;
      }
      if (token = this.tokenizer.br(src)) {
        src = src.substring(token.raw.length);
        tokens.push(token);
        continue;
      }
      if (token = this.tokenizer.del(src)) {
        src = src.substring(token.raw.length);
        tokens.push(token);
        continue;
      }
      if (token = this.tokenizer.autolink(src)) {
        src = src.substring(token.raw.length);
        tokens.push(token);
        continue;
      }
      if (!this.state.inLink && (token = this.tokenizer.url(src))) {
        src = src.substring(token.raw.length);
        tokens.push(token);
        continue;
      }
      let cutSrc = src;
      if (this.options.extensions?.startInline) {
        let startIndex = Infinity;
        const tempSrc = src.slice(1);
        let tempStart;
        this.options.extensions.startInline.forEach((getStartIndex) => {
          tempStart = getStartIndex.call({ lexer: this }, tempSrc);
          if (typeof tempStart === "number" && tempStart >= 0) {
            startIndex = Math.min(startIndex, tempStart);
          }
        });
        if (startIndex < Infinity && startIndex >= 0) {
          cutSrc = src.substring(0, startIndex + 1);
        }
      }
      if (token = this.tokenizer.inlineText(cutSrc)) {
        src = src.substring(token.raw.length);
        if (token.raw.slice(-1) !== "_") {
          prevChar = token.raw.slice(-1);
        }
        keepPrevChar = true;
        const lastToken = tokens.at(-1);
        if (lastToken?.type === "text") {
          lastToken.raw += token.raw;
          lastToken.text += token.text;
        } else {
          tokens.push(token);
        }
        continue;
      }
      if (src) {
        const errMsg = "Infinite loop on byte: " + src.charCodeAt(0);
        if (this.options.silent) {
          console.error(errMsg);
          break;
        } else {
          throw new Error(errMsg);
        }
      }
    }
    return tokens;
  }
}
class _Renderer {
  options;
  parser;
  // set by the parser
  constructor(options) {
    this.options = options || _defaults;
  }
  space(token) {
    return "";
  }
  code({ text, lang, escaped }) {
    const langString = (lang || "").match(other.notSpaceStart)?.[0];
    const code = text.replace(other.endingNewline, "") + "\n";
    if (!langString) {
      return "<pre><code>" + (escaped ? code : escape(code, true)) + "</code></pre>\n";
    }
    return '<pre><code class="language-' + escape(langString) + '">' + (escaped ? code : escape(code, true)) + "</code></pre>\n";
  }
  blockquote({ tokens }) {
    const body = this.parser.parse(tokens);
    return `<blockquote>
${body}</blockquote>
`;
  }
  html({ text }) {
    return text;
  }
  heading({ tokens, depth }) {
    return `<h${depth}>${this.parser.parseInline(tokens)}</h${depth}>
`;
  }
  hr(token) {
    return "<hr>\n";
  }
  list(token) {
    const ordered = token.ordered;
    const start = token.start;
    let body = "";
    for (let j = 0; j < token.items.length; j++) {
      const item = token.items[j];
      body += this.listitem(item);
    }
    const type = ordered ? "ol" : "ul";
    const startAttr = ordered && start !== 1 ? ' start="' + start + '"' : "";
    return "<" + type + startAttr + ">\n" + body + "</" + type + ">\n";
  }
  listitem(item) {
    let itemBody = "";
    if (item.task) {
      const checkbox = this.checkbox({ checked: !!item.checked });
      if (item.loose) {
        if (item.tokens[0]?.type === "paragraph") {
          item.tokens[0].text = checkbox + " " + item.tokens[0].text;
          if (item.tokens[0].tokens && item.tokens[0].tokens.length > 0 && item.tokens[0].tokens[0].type === "text") {
            item.tokens[0].tokens[0].text = checkbox + " " + escape(item.tokens[0].tokens[0].text);
            item.tokens[0].tokens[0].escaped = true;
          }
        } else {
          item.tokens.unshift({
            type: "text",
            raw: checkbox + " ",
            text: checkbox + " ",
            escaped: true
          });
        }
      } else {
        itemBody += checkbox + " ";
      }
    }
    itemBody += this.parser.parse(item.tokens, !!item.loose);
    return `<li>${itemBody}</li>
`;
  }
  checkbox({ checked }) {
    return "<input " + (checked ? 'checked="" ' : "") + 'disabled="" type="checkbox">';
  }
  paragraph({ tokens }) {
    return `<p>${this.parser.parseInline(tokens)}</p>
`;
  }
  table(token) {
    let header = "";
    let cell = "";
    for (let j = 0; j < token.header.length; j++) {
      cell += this.tablecell(token.header[j]);
    }
    header += this.tablerow({ text: cell });
    let body = "";
    for (let j = 0; j < token.rows.length; j++) {
      const row = token.rows[j];
      cell = "";
      for (let k = 0; k < row.length; k++) {
        cell += this.tablecell(row[k]);
      }
      body += this.tablerow({ text: cell });
    }
    if (body)
      body = `<tbody>${body}</tbody>`;
    return "<table>\n<thead>\n" + header + "</thead>\n" + body + "</table>\n";
  }
  tablerow({ text }) {
    return `<tr>
${text}</tr>
`;
  }
  tablecell(token) {
    const content = this.parser.parseInline(token.tokens);
    const type = token.header ? "th" : "td";
    const tag2 = token.align ? `<${type} align="${token.align}">` : `<${type}>`;
    return tag2 + content + `</${type}>
`;
  }
  /**
   * span level renderer
   */
  strong({ tokens }) {
    return `<strong>${this.parser.parseInline(tokens)}</strong>`;
  }
  em({ tokens }) {
    return `<em>${this.parser.parseInline(tokens)}</em>`;
  }
  codespan({ text }) {
    return `<code>${escape(text, true)}</code>`;
  }
  br(token) {
    return "<br>";
  }
  del({ tokens }) {
    return `<del>${this.parser.parseInline(tokens)}</del>`;
  }
  link({ href, title, tokens }) {
    const text = this.parser.parseInline(tokens);
    const cleanHref = cleanUrl(href);
    if (cleanHref === null) {
      return text;
    }
    href = cleanHref;
    let out = '<a href="' + href + '"';
    if (title) {
      out += ' title="' + escape(title) + '"';
    }
    out += ">" + text + "</a>";
    return out;
  }
  image({ href, title, text }) {
    const cleanHref = cleanUrl(href);
    if (cleanHref === null) {
      return escape(text);
    }
    href = cleanHref;
    let out = `<img src="${href}" alt="${text}"`;
    if (title) {
      out += ` title="${escape(title)}"`;
    }
    out += ">";
    return out;
  }
  text(token) {
    return "tokens" in token && token.tokens ? this.parser.parseInline(token.tokens) : "escaped" in token && token.escaped ? token.text : escape(token.text);
  }
}
class _TextRenderer {
  // no need for block level renderers
  strong({ text }) {
    return text;
  }
  em({ text }) {
    return text;
  }
  codespan({ text }) {
    return text;
  }
  del({ text }) {
    return text;
  }
  html({ text }) {
    return text;
  }
  text({ text }) {
    return text;
  }
  link({ text }) {
    return "" + text;
  }
  image({ text }) {
    return "" + text;
  }
  br() {
    return "";
  }
}
class _Parser {
  options;
  renderer;
  textRenderer;
  constructor(options) {
    this.options = options || _defaults;
    this.options.renderer = this.options.renderer || new _Renderer();
    this.renderer = this.options.renderer;
    this.renderer.options = this.options;
    this.renderer.parser = this;
    this.textRenderer = new _TextRenderer();
  }
  /**
   * Static Parse Method
   */
  static parse(tokens, options) {
    const parser = new _Parser(options);
    return parser.parse(tokens);
  }
  /**
   * Static Parse Inline Method
   */
  static parseInline(tokens, options) {
    const parser = new _Parser(options);
    return parser.parseInline(tokens);
  }
  /**
   * Parse Loop
   */
  parse(tokens, top = true) {
    let out = "";
    for (let i = 0; i < tokens.length; i++) {
      const anyToken = tokens[i];
      if (this.options.extensions?.renderers?.[anyToken.type]) {
        const genericToken = anyToken;
        const ret = this.options.extensions.renderers[genericToken.type].call({ parser: this }, genericToken);
        if (ret !== false || !["space", "hr", "heading", "code", "table", "blockquote", "list", "html", "paragraph", "text"].includes(genericToken.type)) {
          out += ret || "";
          continue;
        }
      }
      const token = anyToken;
      switch (token.type) {
        case "space": {
          out += this.renderer.space(token);
          continue;
        }
        case "hr": {
          out += this.renderer.hr(token);
          continue;
        }
        case "heading": {
          out += this.renderer.heading(token);
          continue;
        }
        case "code": {
          out += this.renderer.code(token);
          continue;
        }
        case "table": {
          out += this.renderer.table(token);
          continue;
        }
        case "blockquote": {
          out += this.renderer.blockquote(token);
          continue;
        }
        case "list": {
          out += this.renderer.list(token);
          continue;
        }
        case "html": {
          out += this.renderer.html(token);
          continue;
        }
        case "paragraph": {
          out += this.renderer.paragraph(token);
          continue;
        }
        case "text": {
          let textToken = token;
          let body = this.renderer.text(textToken);
          while (i + 1 < tokens.length && tokens[i + 1].type === "text") {
            textToken = tokens[++i];
            body += "\n" + this.renderer.text(textToken);
          }
          if (top) {
            out += this.renderer.paragraph({
              type: "paragraph",
              raw: body,
              text: body,
              tokens: [{ type: "text", raw: body, text: body, escaped: true }]
            });
          } else {
            out += body;
          }
          continue;
        }
        default: {
          const errMsg = 'Token with "' + token.type + '" type was not found.';
          if (this.options.silent) {
            console.error(errMsg);
            return "";
          } else {
            throw new Error(errMsg);
          }
        }
      }
    }
    return out;
  }
  /**
   * Parse Inline Tokens
   */
  parseInline(tokens, renderer = this.renderer) {
    let out = "";
    for (let i = 0; i < tokens.length; i++) {
      const anyToken = tokens[i];
      if (this.options.extensions?.renderers?.[anyToken.type]) {
        const ret = this.options.extensions.renderers[anyToken.type].call({ parser: this }, anyToken);
        if (ret !== false || !["escape", "html", "link", "image", "strong", "em", "codespan", "br", "del", "text"].includes(anyToken.type)) {
          out += ret || "";
          continue;
        }
      }
      const token = anyToken;
      switch (token.type) {
        case "escape": {
          out += renderer.text(token);
          break;
        }
        case "html": {
          out += renderer.html(token);
          break;
        }
        case "link": {
          out += renderer.link(token);
          break;
        }
        case "image": {
          out += renderer.image(token);
          break;
        }
        case "strong": {
          out += renderer.strong(token);
          break;
        }
        case "em": {
          out += renderer.em(token);
          break;
        }
        case "codespan": {
          out += renderer.codespan(token);
          break;
        }
        case "br": {
          out += renderer.br(token);
          break;
        }
        case "del": {
          out += renderer.del(token);
          break;
        }
        case "text": {
          out += renderer.text(token);
          break;
        }
        default: {
          const errMsg = 'Token with "' + token.type + '" type was not found.';
          if (this.options.silent) {
            console.error(errMsg);
            return "";
          } else {
            throw new Error(errMsg);
          }
        }
      }
    }
    return out;
  }
}
class _Hooks {
  options;
  block;
  constructor(options) {
    this.options = options || _defaults;
  }
  static passThroughHooks = /* @__PURE__ */ new Set([
    "preprocess",
    "postprocess",
    "processAllTokens"
  ]);
  /**
   * Process markdown before marked
   */
  preprocess(markdown) {
    return markdown;
  }
  /**
   * Process HTML after marked is finished
   */
  postprocess(html2) {
    return html2;
  }
  /**
   * Process all tokens before walk tokens
   */
  processAllTokens(tokens) {
    return tokens;
  }
  /**
   * Provide function to tokenize markdown
   */
  provideLexer() {
    return this.block ? _Lexer.lex : _Lexer.lexInline;
  }
  /**
   * Provide function to parse tokens
   */
  provideParser() {
    return this.block ? _Parser.parse : _Parser.parseInline;
  }
}
class Marked {
  defaults = _getDefaults();
  options = this.setOptions;
  parse = this.parseMarkdown(true);
  parseInline = this.parseMarkdown(false);
  Parser = _Parser;
  Renderer = _Renderer;
  TextRenderer = _TextRenderer;
  Lexer = _Lexer;
  Tokenizer = _Tokenizer;
  Hooks = _Hooks;
  constructor(...args) {
    this.use(...args);
  }
  /**
   * Run callback for every token
   */
  walkTokens(tokens, callback) {
    let values = [];
    for (const token of tokens) {
      values = values.concat(callback.call(this, token));
      switch (token.type) {
        case "table": {
          const tableToken = token;
          for (const cell of tableToken.header) {
            values = values.concat(this.walkTokens(cell.tokens, callback));
          }
          for (const row of tableToken.rows) {
            for (const cell of row) {
              values = values.concat(this.walkTokens(cell.tokens, callback));
            }
          }
          break;
        }
        case "list": {
          const listToken = token;
          values = values.concat(this.walkTokens(listToken.items, callback));
          break;
        }
        default: {
          const genericToken = token;
          if (this.defaults.extensions?.childTokens?.[genericToken.type]) {
            this.defaults.extensions.childTokens[genericToken.type].forEach((childTokens) => {
              const tokens2 = genericToken[childTokens].flat(Infinity);
              values = values.concat(this.walkTokens(tokens2, callback));
            });
          } else if (genericToken.tokens) {
            values = values.concat(this.walkTokens(genericToken.tokens, callback));
          }
        }
      }
    }
    return values;
  }
  use(...args) {
    const extensions = this.defaults.extensions || { renderers: {}, childTokens: {} };
    args.forEach((pack) => {
      const opts = { ...pack };
      opts.async = this.defaults.async || opts.async || false;
      if (pack.extensions) {
        pack.extensions.forEach((ext) => {
          if (!ext.name) {
            throw new Error("extension name required");
          }
          if ("renderer" in ext) {
            const prevRenderer = extensions.renderers[ext.name];
            if (prevRenderer) {
              extensions.renderers[ext.name] = function(...args2) {
                let ret = ext.renderer.apply(this, args2);
                if (ret === false) {
                  ret = prevRenderer.apply(this, args2);
                }
                return ret;
              };
            } else {
              extensions.renderers[ext.name] = ext.renderer;
            }
          }
          if ("tokenizer" in ext) {
            if (!ext.level || ext.level !== "block" && ext.level !== "inline") {
              throw new Error("extension level must be 'block' or 'inline'");
            }
            const extLevel = extensions[ext.level];
            if (extLevel) {
              extLevel.unshift(ext.tokenizer);
            } else {
              extensions[ext.level] = [ext.tokenizer];
            }
            if (ext.start) {
              if (ext.level === "block") {
                if (extensions.startBlock) {
                  extensions.startBlock.push(ext.start);
                } else {
                  extensions.startBlock = [ext.start];
                }
              } else if (ext.level === "inline") {
                if (extensions.startInline) {
                  extensions.startInline.push(ext.start);
                } else {
                  extensions.startInline = [ext.start];
                }
              }
            }
          }
          if ("childTokens" in ext && ext.childTokens) {
            extensions.childTokens[ext.name] = ext.childTokens;
          }
        });
        opts.extensions = extensions;
      }
      if (pack.renderer) {
        const renderer = this.defaults.renderer || new _Renderer(this.defaults);
        for (const prop in pack.renderer) {
          if (!(prop in renderer)) {
            throw new Error(`renderer '${prop}' does not exist`);
          }
          if (["options", "parser"].includes(prop)) {
            continue;
          }
          const rendererProp = prop;
          const rendererFunc = pack.renderer[rendererProp];
          const prevRenderer = renderer[rendererProp];
          renderer[rendererProp] = (...args2) => {
            let ret = rendererFunc.apply(renderer, args2);
            if (ret === false) {
              ret = prevRenderer.apply(renderer, args2);
            }
            return ret || "";
          };
        }
        opts.renderer = renderer;
      }
      if (pack.tokenizer) {
        const tokenizer = this.defaults.tokenizer || new _Tokenizer(this.defaults);
        for (const prop in pack.tokenizer) {
          if (!(prop in tokenizer)) {
            throw new Error(`tokenizer '${prop}' does not exist`);
          }
          if (["options", "rules", "lexer"].includes(prop)) {
            continue;
          }
          const tokenizerProp = prop;
          const tokenizerFunc = pack.tokenizer[tokenizerProp];
          const prevTokenizer = tokenizer[tokenizerProp];
          tokenizer[tokenizerProp] = (...args2) => {
            let ret = tokenizerFunc.apply(tokenizer, args2);
            if (ret === false) {
              ret = prevTokenizer.apply(tokenizer, args2);
            }
            return ret;
          };
        }
        opts.tokenizer = tokenizer;
      }
      if (pack.hooks) {
        const hooks = this.defaults.hooks || new _Hooks();
        for (const prop in pack.hooks) {
          if (!(prop in hooks)) {
            throw new Error(`hook '${prop}' does not exist`);
          }
          if (["options", "block"].includes(prop)) {
            continue;
          }
          const hooksProp = prop;
          const hooksFunc = pack.hooks[hooksProp];
          const prevHook = hooks[hooksProp];
          if (_Hooks.passThroughHooks.has(prop)) {
            hooks[hooksProp] = (arg) => {
              if (this.defaults.async) {
                return Promise.resolve(hooksFunc.call(hooks, arg)).then((ret2) => {
                  return prevHook.call(hooks, ret2);
                });
              }
              const ret = hooksFunc.call(hooks, arg);
              return prevHook.call(hooks, ret);
            };
          } else {
            hooks[hooksProp] = (...args2) => {
              let ret = hooksFunc.apply(hooks, args2);
              if (ret === false) {
                ret = prevHook.apply(hooks, args2);
              }
              return ret;
            };
          }
        }
        opts.hooks = hooks;
      }
      if (pack.walkTokens) {
        const walkTokens = this.defaults.walkTokens;
        const packWalktokens = pack.walkTokens;
        opts.walkTokens = function(token) {
          let values = [];
          values.push(packWalktokens.call(this, token));
          if (walkTokens) {
            values = values.concat(walkTokens.call(this, token));
          }
          return values;
        };
      }
      this.defaults = { ...this.defaults, ...opts };
    });
    return this;
  }
  setOptions(opt) {
    this.defaults = { ...this.defaults, ...opt };
    return this;
  }
  lexer(src, options) {
    return _Lexer.lex(src, options ?? this.defaults);
  }
  parser(tokens, options) {
    return _Parser.parse(tokens, options ?? this.defaults);
  }
  parseMarkdown(blockType) {
    const parse = (src, options) => {
      const origOpt = { ...options };
      const opt = { ...this.defaults, ...origOpt };
      const throwError = this.onError(!!opt.silent, !!opt.async);
      if (this.defaults.async === true && origOpt.async === false) {
        return throwError(new Error("marked(): The async option was set to true by an extension. Remove async: false from the parse options object to return a Promise."));
      }
      if (typeof src === "undefined" || src === null) {
        return throwError(new Error("marked(): input parameter is undefined or null"));
      }
      if (typeof src !== "string") {
        return throwError(new Error("marked(): input parameter is of type " + Object.prototype.toString.call(src) + ", string expected"));
      }
      if (opt.hooks) {
        opt.hooks.options = opt;
        opt.hooks.block = blockType;
      }
      const lexer = opt.hooks ? opt.hooks.provideLexer() : blockType ? _Lexer.lex : _Lexer.lexInline;
      const parser = opt.hooks ? opt.hooks.provideParser() : blockType ? _Parser.parse : _Parser.parseInline;
      if (opt.async) {
        return Promise.resolve(opt.hooks ? opt.hooks.preprocess(src) : src).then((src2) => lexer(src2, opt)).then((tokens) => opt.hooks ? opt.hooks.processAllTokens(tokens) : tokens).then((tokens) => opt.walkTokens ? Promise.all(this.walkTokens(tokens, opt.walkTokens)).then(() => tokens) : tokens).then((tokens) => parser(tokens, opt)).then((html2) => opt.hooks ? opt.hooks.postprocess(html2) : html2).catch(throwError);
      }
      try {
        if (opt.hooks) {
          src = opt.hooks.preprocess(src);
        }
        let tokens = lexer(src, opt);
        if (opt.hooks) {
          tokens = opt.hooks.processAllTokens(tokens);
        }
        if (opt.walkTokens) {
          this.walkTokens(tokens, opt.walkTokens);
        }
        let html2 = parser(tokens, opt);
        if (opt.hooks) {
          html2 = opt.hooks.postprocess(html2);
        }
        return html2;
      } catch (e) {
        return throwError(e);
      }
    };
    return parse;
  }
  onError(silent, async) {
    return (e) => {
      e.message += "\nPlease report this to https://github.com/markedjs/marked.";
      if (silent) {
        const msg = "<p>An error occurred:</p><pre>" + escape(e.message + "", true) + "</pre>";
        if (async) {
          return Promise.resolve(msg);
        }
        return msg;
      }
      if (async) {
        return Promise.reject(e);
      }
      throw e;
    };
  }
}
const markedInstance = new Marked();
function marked(src, opt) {
  return markedInstance.parse(src, opt);
}
marked.options = marked.setOptions = function(options) {
  markedInstance.setOptions(options);
  marked.defaults = markedInstance.defaults;
  changeDefaults(marked.defaults);
  return marked;
};
marked.getDefaults = _getDefaults;
marked.defaults = _defaults;
marked.use = function(...args) {
  markedInstance.use(...args);
  marked.defaults = markedInstance.defaults;
  changeDefaults(marked.defaults);
  return marked;
};
marked.walkTokens = function(tokens, callback) {
  return markedInstance.walkTokens(tokens, callback);
};
marked.parseInline = markedInstance.parseInline;
marked.Parser = _Parser;
marked.parser = _Parser.parse;
marked.Renderer = _Renderer;
marked.TextRenderer = _TextRenderer;
marked.Lexer = _Lexer;
marked.lexer = _Lexer.lex;
marked.Tokenizer = _Tokenizer;
marked.Hooks = _Hooks;
marked.parse = marked;
marked.options;
marked.setOptions;
marked.use;
marked.walkTokens;
marked.parseInline;
_Parser.parse;
_Lexer.lex;
const serviceAgreement = '# 尼来用户服务协议\n\n> 更新时间：2024 年 12 月 20 日\n\n> 生效时间：2024 年 12 月 20 日\n\n\n\n**欢迎您使用“尼来”软件与/或相关服务!**\n\n\n“尼来”软件与/或相关服务，包括但不限于公司以不同版本和客户端的尼来应用程序向用户（又称“您”）提供的产品与服务。\n\n《尼来用户服务协议》（以下简称“本协议”）是您与公司之间就您下载、安装、注册、登录、使用（以下统称“使用”）“尼来”软件与/或相关服务所订立的协议。\n\n为了更好地为您提供服务，请您在开始使用“尼来”软件与/或相关服务之前，详细阅读、充分理解并遵守本协议，特别是涉及免除或者限制责任的条款、权利许可和信息使用的条款、法律适用和争议解决条款等。其中，<u>**免除或者限制责任条款等重要内容将以加粗形式提示您注意，请您留意并重点查阅。**</u> \n\n## **_【特别提示】_**\n\n1. 本协议条款构成您使用尼来软件与/或相关服务之先决条件。您使用尼来软件与/或相关服务的行为（包括但不限于下载、安装、启动、浏览、注册、登录、发布、评论、使用），都表示您同意并接受本协议。\n2. 如您不同意本协议，这将导致我们无法为您提供完整的产品和服务，您也可以选择停止使用。如您自主选择同意或使用“尼来”软件与/或相关服务，则视为您已充分理解本协议，并同意作为本协议的一方当事人接受本协议以及其他与“尼来”软件与/或相关服务相关的协议和规则（包括但不限于《尼来个人信息保护政策》）的约束。\n3. 本协议所称“用户”，包括注册用户及未注册用户。凡未注册“尼来”软件与/或相关服务的用户，自下载安装“尼来”软件与/或相关服务时，即自动成为“尼来”软件与/或相关服务的“非注册用户”，须遵循除本协议用户注册规定以外的其他所有条款。\n4. 若您是未满18周岁的未成年人，请确保在征得您的监护人同意后使用“尼来”软件与/或相关服务，并特别注意**未成年人使用条款**，否则请您不要使用“尼来”软件与/或相关服务。未成年人行使和履行本协议项下的权利和义务视为已获得了法定监护人的同意。\n\n如您在阅读本协议过程中有任何疑惑或其他相关事宜的，您可以发送邮件至 service@tansocc.com 进行询问，我们会尽快为您做出解答。\n\n## **本用户服务协议包含以下内容：**\n1. <u>“尼来”软件与/或相关服务\n\n2. 账户使用规则\n\n3. 用户个人信息保护\n\n4. 用户行为规范\n\n5. 服务的变更、中断和终止\n\n6. 违约处理\n\n7. 免责声明\n\n8. 未成年人保护\n\n9. 通知\n\n10. 管辖\n\n11. 更新\n\n12. 其他</u>\n\n\n## “尼来”软件与/或相关服务\n\n1. 您使用“尼来”软件与/或相关服务，可以通过预装、公司已授权的第三方下载等方式获取“尼来”客户端应用程序。<u>**若您并非从公司或经公司授权的第三方获取本软件的，公司无法保证非官方版本的“尼来”软件能够正常使用，您因此遭受的损失与公司无关。**</u> \n2. 公司可能为不同的终端设备开发不同的应用程序软件版本，您应当根据实际设备状况获取、下载、安装合适的版本。如您不再使用“尼来”软件与/或相关服务，您也可自行卸载相应的应用程序软件。\n3. 为更好的提升用户体验及服务，公司将不定期提供“尼来”软件与/或相关服务的更新或改变（包括但不限于软件修改、升级、功能强化、开发新服务、软件替换等），您可根据需要自行选择是否更新相应的版本。\n为保证“尼来”软件与/或相关服务安全、提升用户服务，在“尼来”软件与/或相关服务的部分或全部更新后，公司将在可行的情况下以适当的方式（包括但不限于系统提示、公告、站内信等）提示您，您有权选择接受更新后的版本；如您选择不作更新，“尼来”软件与/或相关服务的部分功能将受到限制或不能正常使用。\n4. 除非得到公司事先明示书面授权，您不得以任何形式对“尼来”软件与/或相关服务进行包括但不限于改编、复制、传播、垂直搜索、镜像或交易等未经授权的访问或使用。\n5. 您理解并同意，使用“尼来”软件与/或相关服务需自行准备与软件及相关服务有关的终端设备（如电脑、手机等），一旦您在终端设备中打开“尼来”软件或访问“尼来”的官方网站，即视为您同意使用“尼来”软件与/或相关服务。为充分实现“尼来”的全部功能，您可能需要将终端设备联网，您理解并同意由您承担所需要的费用（如流量费、上网费等）。\n6. 您无需注册也可开始使用“尼来”软件与/或相关服务，但部分功能或服务可能会受到影响。同时，您也理解并同意，为使您更好地使用“尼来”软件与/或相关服务，保障您的账户安全，某些功能和/或某些单项服务项目（如发布服务、评论服务等）将要求您按照国家相关法律法规的规定，提供真实的身份信息注册并登录后方可使用。\n7. 尼来向您提供包括但不限于如下内容：发布和分享文章、话题和视频等，在尼来可以实现发布文章、信息、视频、话题探讨、原创文章、DP等功能。除非本协议另有其他明示规定，尼来增加或强化目前本产品的任何新功能，包括推出的新产品，均受本协议的规范。\n\n## 账户使用规则\n\n1. “尼来”软件与/或相关服务为您提供了注册通道。账户密码是您使用尼来链上功能的唯一入口。尼来将根据您导入的地址密码为您分配一个唯一的地址账户。<u>**您理解并同意，您设置的账户密码是您用以登录并以注册用户身份使用“尼来”链上功能与/或相关服务的唯一入口。**</u> \n2. <u>**您理解并同意，尼来无法注销您已注册的地址。**</u> \n3. <u>**您理解并同意，无论您因何种原因导致的账户账户密码丢失或遗忘，“尼来”均无法找回或重置您丢失的账户密码。您需要自行承担账户密码丢失或遗忘的相应责任、风险和损失。请妥善保管好您的账户密码。**</u> \n4. <u>**您理解并同意，您所设置的账户不得违反国家法律法规及公司的相关规则，您的账户昵称、头像和签名等注册信息及其他个人信息中不得出现违法和不良信息，未经他人许可不得用他人名义（包括但不限于冒用他人姓名、昵称、头像或其他足以让人引起混淆的方式）开设账户，不得恶意注册“尼来”账户（包括但不限于频繁注册、批量注册账户等行为）。您在账户注册及使用过程中需遵守相关法律法规，不得实施任何侵害国家利益、损害其他公民合法权益，有害社会道德风尚的行为。**</u> \n5. 您有责任维护个人账户、登录密码、账户密码的安全性与保密性，并对您以注册账户名义所从事的活动承担全部法律责任，包括但不限于您在“尼来”软件与/或相关服务上进行的任何数据修改、言论发表、款项支付等操作行为可能引起的一切法律责任。您应高度重视对账户与密码的保密，在任何情况下不向他人透露账户及密码。\n6. 在注册、使用和管理账户时，您应保证注册账户时填写的身份信息的真实性，请您在注册、管理账户时使用真实、准确、合法、有效的相关身份证明材料（包括但不限于您的联系电话等）。依照国家相关法律法规的规定，为使用“尼来”软件与/或相关服务的部分功能，您需要填写真实的身份信息，请您按照相关法律规定完成实名认证，并注意及时更新上述相关信息。若您提交的材料或提供的信息不准确、不真实、不规范，您可能无法使用“尼来”软件与/或相关服务或在使用过程中部分功能受到限制。\n\n## 用户个人信息保护\n\n1. 公司与您一同致力于您个人信息（即能够独立或与其他信息结合后识别您身份的信息）的保护，保护用户个人信息是公司的基本原则之一。在使用“尼来”软件与/或相关服务的过程中，您可能需要提供您的个人信息（包括但不限于电话号码等），以便公司向您提供更好的服务和相应的技术支持。我们将按照本协议及《尼来个人信息保护政策》的规定收集、使用、储存和分享您的个人信息。具体要求，请您参照《尼来个人信息保护政策》。\n\n## 用户行为规范\n\n### 用户行为要求\n\n您应当对您使用“尼来”软件与/或相关服务的行为负责，除非法律允许或者经公司事先书面许可，您使用“尼来”软件与/或相关服务不得具有下列行为：\n1. <u>**使用未经公司授权或许可的任何插件、外挂、系统或第三方工具对“尼来”软件与/或相关服务的正常运行进行干扰、破坏、修改或施加其他影响。**</u>\n2. <u>**利用或针对“尼来”软件与/或相关服务进行任何危害计算机网络安全的行为，包括但不限于：**</u>\n   - 非法侵入网络、干扰网络正常功能、窃取网络数据等危害网络安全的活动；\n   - 提供专门用于从事侵入网络、干扰网络正常功能及防护措施、窃取网络数据等危害网络安全活动的程序、工具；\n   - 明知他人从事危害网络安全的活动的，为其提供技术支持、广告推广等帮助；\n   - 使用未经许可的数据或进入未经许可的服务器/账户；\n   - 未经允许进入公众计算机网络或者他人计算机系统并删除、修改、增加存储信息；\n   - 未经许可，企图探查、扫描、测试“尼来”系统或网络的弱点或其它实施破坏网络安全的行为；\n   - 企图干涉、破坏“尼来”系统或网站的正常运行，故意传播恶意程序或病毒以及其他破坏干扰正常网络信息服务的行为；\n   - 伪造TCP/IP数据包名称或部分名称；\n   - 对“尼来”软件与/或相关服务进行反向工程、反向汇编、编译或者以其他方式尝试发现本软件的源代码；\n   - 恶意注册“尼来”软件与/或相关服务的账户，包括但不限于频繁、批量注册账户；\n   - 违反法律法规、本协议、公司的相关规则及侵犯他人合法权益的其他行为。\n3. 如果公司有理由认为您的行为违反或可能违反上述约定的，公司可独立进行判断并处理，且有权在不事先通知的情况下终止向您提供服务，并追究相关法律责任。\n\n### 内容规范\n\n1. 您按规定完成实名认证后，可以享有尼来的更多服务。您和其他用户在“尼来”中因相关操作所形成的信息将会向其他用户展示。\n\n2. <u>**您传播的内容信息应自觉遵守法律法规，遵守公共秩序，尊重社会公德、国家利益、公民合法权益、道德风尚和信息真实性等要求，否则公司有权立即采取相应处理措施。您同意并承诺不制作、复制、发布、传播下列信息：**</u> \n   - 反对中华人民共和国宪法确定的基本原则的；\n   - 危害国家安全，泄露国家秘密的；\n   - 颠覆国家政权，推翻社会主义制度、煽动分裂国家、破坏国家统一的；\n   - 损害国家荣誉和利益的；\n   - 宣扬恐怖主义、极端主义的；\n   - 宣扬民族仇恨、民族歧视，破坏民族团结的；\n   - 煽动地域歧视、地域仇恨的；\n   - 破坏国家宗教政策，宣扬邪教和封建迷信的；\n   - 编造、散布谣言、虚假信息，扰乱经济秩序和社会秩序、破坏社会稳定的；\n   - 散布、传播淫秽、色情、赌博、暴力、凶杀、恐怖或者教唆犯罪的；\n   - 侵害未成年人合法权益或者损害未成年人身心健康的；\n   - 侮辱或者诽谤他人，侵害他人合法权益的；\n   - 对他人进行暴力恐吓、威胁，实施人肉搜索的；\n   - 涉及他人隐私、个人信息或资料的；\n   - 散布污言秽语，损害社会公序良俗的；\n   - 侵犯他人隐私权、名誉权、肖像权、知识产权等合法权益内容的；\n   - 散布垃圾内容；\n   - 使用本网站常用语言文字以外的其他语言文字评论的；\n   - 与所评论的内容毫无关系的；\n   - 所发表的内容毫无意义的，或刻意使用字符组合以逃避技术审核的；\n   - 侵害未成年人合法权益或者损害未成年人身心健康的；\n   - 未获他人允许，偷拍、偷录他人，侵害他人合法权利的；\n   - 包含恐怖、暴力血腥、高危险性、危害表演者自身或他人身心健康内容的，包括但不限于以下情形：\n      - 任何暴力和/或自残行为内容；\n      - 任何威胁生命健康、利用刀具等危险器械表演的危及自身或他人人身及/或财产权利的内容；\n      - 怂恿、诱导他人参与可能会造成人身伤害或导致死亡的危险或违法活动的内容；\n   - 其他违反法律法规、政策及公序良俗、干扰“尼来”正常运营或侵犯其他用户或第三方合法权益内容的其他信息。\n\n## 服务的变更、中断和终止\n\n1. 您理解并同意，公司提供的“尼来”软件与/或相关服务是按照现有技术和条件所能达到的现状提供的。公司会尽最大努力向您提供服务，确保服务的连贯性和安全性。您理解并同意，公司不能随时预见和防范技术以及其他风险，包括但不限于不可抗力、网络原因、第三方服务瑕疵、第三方网站等原因可能导致的服务中断、不能正常使用“尼来”软件及服务以及其他的损失和风险。\n2. 您理解并同意，公司为了整体服务运营、平台运营安全的需要，有权视具体情况决定服务/功能设置、范围，修改、中断、中止或终止“尼来”软件与/或相关服务。\n3. 我们有权根据公司的业务发展情况，随时变更或终止部分或全部"尼来"产品与/或服务，无论是否通知用户，我们不因"尼来"产品与/或服务的变更或终止而对用户和任何第三人承担违约责任。\n\n## <u>**知识产权** </u>\n\n1. <u>**您理解并保证，您在使用尼来软件及"尼来"产品与/或服务时发布上传的文字、图片等均由您原创或已获得合法授权（含转授权且保证您有权将上述文字及图片等内容以本协议约定的方式授权给我们使用），不会侵犯第三方的合法权利。您通过"尼来"产品与/或服务由您独自上传、发布的任何内容的知识产权归您或原始著作权人所有。如果任何第三方就该等信息或内容提出关于知识产权的异议，我们有权根据实际情况删除相关的信息或内容，并且保留追究您相应法律责任的权利，您应当赔偿由此给我们或者任何第三方造成的一切损失。** </u>\n2. <u>**您理解并同意，您通过"尼来"产品与/或服务上传的内容包括用于共建的内容（包括但不限于符号、文字、图片等），授予我们及我们的关联公司一项全球范围内的、永久性的、免费的、非独家的、不可撤销的、可转授权（通过多层次）的权利（包括除署名权外的所有权利，其中财产性权利包括但不限于复制权、翻译权、汇编权、信息网络传播权、改编权、制作衍生作品等），即我们可以对上述作品行使使用、发布、传播、复制、修改、改编、汇编、出版、翻译、传播、表演和展示等权利，并据以创作衍生作品的权利；将信息的全部或部分编入其他任何形式的作品、媒体、技术中的权利；对用户上传、发布的信息进行商业开发的权利；通过有线或无线网络向用户的计算机终端、移动通讯终端（包括但不限于便携式通讯设备如手机和智能平板电脑等）进行相关宣传和推广等服务。同时，您亦理解并同意，您对通过"尼来"产品与/或服务上传的内容，包括用于共建的内容，均不予行使保护作品完整权及修改权。** </u>\n3. 除本章节1至2条款规定以外部分或"尼来"产品与/或服务中另行说明部分的内容（包括但不限于软件、技术、程序、网页、文字、图片、图像、图标、版面设计、电子文档等）之外，尼来软件及"尼来"产品与/或服务中的的知识产权，完整归属于公司所有；在我们提供"尼来"产品与/或服务过程中所依托的著作权（包括软件著作权）、专利权、商标权、商业秘密及其他知识产权归公司所有，或者由公司已从第三方权利人处获得合法使用的有效授权；以及，经我们创作、整理或以其他方式（如人工智能）生成内容的知识产权或其他相关权利归属于公司所有。未经公司事先书面许可，任何人不得擅自使用、大批量地监视、复制、传播、展示、镜像、上传、下载尼来软件及相关服务中的内容（也包括通过任何机器人、蜘蛛等程序或设备进行操作）。未经公司事先书面许可，除5.6条规定的情况外，您不得以任何营利性或非营利性的目的修改、复制、传播、传送、发行、转移、销售"尼来"产品与/或服务所使用的知识产权或创造、制作与其有关的派生产品或衍生品或者利用"尼来"产品与/或服务之部分或全部向任何第三方提供服务或产品。若您违反上述约定，我们有权追究您的责任，要求您赔偿由此给我们或其他人造成的损失，并有权视情况将上述行为移交相关政府部门处理。\n4. <u>**用户在使用"尼来"产品与/或服务的过程中需要下载尼来软件的，对于该软件，我们仅授予用户可撤销的、有限的、不可转让及非排他性的许可。用户仅可为访问/使用产品、服务的目的而使用该软件。\n您理解并同意，在未获得我们许可的情况下，用户不得修改、改编、翻译"尼来"产品与/或服务所使用的软件、技术、材料等，或者创作与之相关的派生作品或衍生品，不得通过反向工程、反编译、反汇编或其他类似行为获得其源代码，否则由此引起的一切法律后果由用户负责，我们将依法追究侵权方的法律责任。** </u>\n5. 用户只能在本协议以及我们明示授权的范围内容使用"尼来"产品与/或服务。用户有权：\n   - 上传用户原创或取得了合法授权（含转授权）的内容；\n   - 对于"尼来"产品与/或服务中用户共建的内容在尼来平台上进行编辑、修改；\n   - 在我们允许转发的数量范围内，将"尼来"产品与/或服务内容转发至第三方平台。具体内容以我们实际提供的服务为准。\n6. <u>**用户不得擅自使用、删除、掩盖或更改我们的版权标识及声明、商标、专利、域名、网站名称、其他商业标识或其它权利声明。我们在"尼来"产品与/或服务中所呈现的所有设计图样以及其他图样、产品及服务名称、商业标识等，均为我们及/或其关联公司所享有的商标、标识。任何人不得使用、复制或用作其他用途。** </u>\n\n## <u>**违约处理** </u>\n\n1. <u>**针对您违反本协议或其他服务条款的行为，公司有权独立判断并视情况采取预先警示、拒绝发布、删除内容或评论等措施，对于因此而造成的后果，公司不承担任何责任。对涉嫌违反法律法规、涉嫌违法犯罪的行为，公司将保存有关记录，并有权依法向有关主管部门报告、配合有关主管部门调查、向公安机关报案等。对已删除内容公司有权不予恢复。** </u>\n2. <u>**因您违反本协议或其他服务条款规定，引起第三方投诉或诉讼索赔的，您应当自行处理并承担全部可能由此引起的法律责任。因您的违法、侵权或违约等行为导致公司及其关联方、控制公司、继承公司向任何第三方赔偿或遭受国家机关处罚的，您还应足额赔偿公司及其关联方、控制公司、继承公司因此遭受的全部损失。** </u>\n3. <u>**公司尊重并保护用户及他人的知识产权、名誉权、姓名权、隐私权等合法权益。您保证，在使用“尼来”软件与/或相关服务时上传的文字、图片、视频、音频、链接等不侵犯任何第三方的知识产权、名誉权、姓名权、隐私权等权利及合法权益。否则，公司有权在收到权利方或者相关方通知的情况下移除该涉嫌侵权内容。针对第三方提出的全部权利主张，您应自行处理并承担全部可能由此引起的法律责任；如因您的侵权行为导致公司及其关联方、控制公司、继承公司遭受损失的（包括经济、商誉等损失），您还应足额赔偿公司及其关联方、控制公司、继承公司遭受的全部损失。** </u>\n\n## <u>**免责声明** </u>\n\n1. <u>**公司有权利但无义务对用户发表的内容（包括文字、图片等其他形式）进行审查，同时不对用户发表的内容的正确性进行保证。用户在尼来发表的内容仅标明其个人观点及立场，不代表尼来的观点和立场。用户为内容的发表者，需对所发表内容负责。因其发表内容引发的一切纠纷，由该内容的发表者承担全部法律责任，尼来不承担任何法律责任。** </u>\n2. <u>**您理解并同意，"尼来"产品与/或服务是按照现有技术和条件所能达到的现状提供的，我们无法保证所提供的"尼来"产品与/或服务毫无瑕疵。并且，我们不对提供的"尼来"产品与/或服务（含技术和信息）作出任何明示或暗示的承诺或保证，包括但不限于质量、稳定、正确、及时、完整、连贯等，但我们承诺将不断提升服务质量及服务水平，为用户提供更加优质的服务。** </u>\n3. <u>**在所适用的法律允许的最大范围内，我们对如下事项不做担保：** </u>\n   - <u>**由于技术本身的局限性，即便我们已经做出最大努力，我们不能保证我们的网站、移动客户端等软件与其他软硬件、系统完全兼容。如果出现不兼容的情况，用户可以向客服咨询，以获得技术支持。如果无法解决问题，用户可以选择卸载、停止使用"尼来"产品与/或服务；** </u>\n   - <u>**因不可抗力，包括但不限于自然灾害(如洪水、地震、台风等)、黑客攻击、战争、罢工、系统不稳定、网络中断、用户关机、通信线路、第三方服务瑕疵、政府行为、尼来自身产品与/或服务规划/调整/改版等原因，均可能造成"尼来"产品与/或服务中断、数据丢失、账号内数据损毁以及其他的损失或风险。当出现不可抗力情况时，公司将努力在第一时间及时修复，但因不可抗力造成的暂停、中止、终止服务或造成的任何损失，公司在法律法规允许范围内免于承担责任。** </u>\n   - <u>**对于从非公司指定官方途径下载、非公司指定途径获得的尼来软件，我们无法保证"尼来"产品与/或服务的一致性、安全性、稳定性，也不承担用户由此遭受的一切直接或间接损害赔偿等法律责任。** </u>\n4. <u>**基于以下原因而造成的利润、商业信誉、资料损失或其他有形或无形损失，我们不承担任何直接、间接、附带、衍生或惩罚性的赔偿责任：** </u>\n   - <u>**"尼来"产品与/或服务使用或无法使用；** </u>\n   - <u>**经由"尼来"产品与/或服务取得的任何产品、资料或服务；** </u>\n   - <u>**非因我们原因导致的用户资料遭到未授权的使用或修改。** </u>\n5. <u>**您应妥善保管自己的登录密码，加强密码安全性，谨防密码泄露。非因公司的原因造成用户登录密码被泄露或被盗而遭受的任何损失，我们不予承担法律责任。** </u>\n6. <u>**您理解并同意，我们为了整体运营的需要，有权自行决定进行业务与/或技术的变更、调整，有权视情况，随时修改或中断、中止或终止"尼来"产品与/或服务而无需通知用户，也无需向用户或第三方负责或承担任何赔偿责任，除非法律另有规定或双方另有约定。** </u>\n7. <u>**根据法律法规的要求，我们有权依据其自身判断，对于用户任何违反或涉嫌违反中国法律、法规或本协议约定的内容，有权视情节进行删除、屏蔽或断开链接；并有权依据中国法律法规之规定保存有关信息并向相关政府部门进行报告。** </u>\n8. <u>**不论是否可以预见，不论是源于何种形式的行为，我们不对由任何原因造成的特别的、间接的、惩罚性的、突发性的或有因果关系的损害或其他任何损害承担责任** </u>\n9. <u>**公司依据本协议约定获得处理违法违规内容的权利，该权利不构成公司的义务或承诺，公司不能保证及时发现违法行为或进行相应处理。** </u>\n10. <u>**您理解并同意，本协议旨在保障遵守国家法律法规、维护公序良俗，保护用户和他人合法权益，公司在能力范围内尽最大的努力按照相关法律法规进行判断，但并不保证公司判断完全与司法机关、行政机关的判断一致，如因此产生的后果您已经理解并同意自行承担。** </u>\n\n## <u>**未成年人保护** </u>\n1. <u>**若您是未满18周岁的未成年人，您应在监护人监护、指导并获得监护人同意的情况下，认真阅读并同意本协议后，方可使用“尼来”软件与/或相关服务。** </u>\n2. <u>**公司重视对未成年人个人信息的保护，未成年用户在填写个人信息时，请加强个人保护意识并谨慎对待，并应在取得监护人的同意以及在监护人指导下正确使用“尼来”软件与/或相关服务。** </u>\n3. <u>**未成年用户及其监护人理解并确认，如因您违反法律法规、本协议内容，则您及您的监护人应依照法律规定承担因此而可能导致的全部法律责任。** </u>\n4. <u>**未成年人用户特别提示：** </u>\n   - <u>**青少年使用“尼来”软件与/或相关服务应该在其监护人的监督指导下，在合理范围内正确学习使用网络，避免沉迷虚拟的网络空间，养成良好上网习惯。** </u>\n   - <u>**青少年用户必须遵守《全国青少年网络文明公约》：** </u>\n      - <u>**要善于网上学习，不浏览不良信息；** </u>\n      - <u>**要诚实友好交流，不侮辱欺诈他人；** </u>\n      - <u>**要增强自护意识，不随意约会网友；** </u>\n      - <u>**要维护网络安全，不破坏网络秩序；** </u>\n      - <u>**要有益身心健康，不沉溺虚拟时空。** </u>\n\n\n## 通知\n本协议条款和规则项下我们对于您所有的通知均可通过网页公告、站内通知、手机短信传送等方式进行，该等通知于发送之日视为已送达用户。\n\n## 管辖\n本协议条款和规则的签订、效力、履行、终止及其解释均适用中华人民共和国大陆地区法律（为本协议的目的，不包括香港特别行政区、澳门特别行政区及台湾地区的法律）。与本协议和规则相关的任何争议或纠纷，双方应协商友好解决；若不能协商解决，任何一方均有权将争议提交至人民法院诉讼解决。\n\n## 更新\n1. 我们有权根据业务需要，在必要时修改本协议条款和规则。本协议条款和规则更新及修改时，我们将通过第十一条约定的方式通知您，并将更新后的协议和规则在尼来网站和移动客户端上进行展示，供您查询。\n2. 若本协议条款和规则更新后，您继续使用"尼来"产品与/或服务，即视为您已经理解并愿意接受变更后的协议条款和规则的约束。若您不同意任何本协议条款和规则的修改和更新的，请您不要继续使用"尼来"产品与/或服务。\n\n\n## 其他\n\n1. 本协议的成立、生效、履行、解释及争议的解决均应适用中华人民共和国法律。若本协议之任何规定因与中华人民共和国的法律抵触而无效或不可执行，则这些条款应在不违反法律的前提下尽可能按照接近本协议原条文目的之原则进行解释和使用，且本协议其它规定仍应具有完整的效力及效果。\n2. 为给您提供更好的服务或国家法律法规、政策调整、技术条件、产品功能等变化需要，公司会适时对本协议进行修订，修订内容构成本协议的组成部分。本协议更新后，公司会在“尼来”发出更新版本，并在更新后的条款生效前以适当的方式提醒您更新的内容，以便您及时了解本协议的最新版本，您也可以在网站首页或软件设置页面查阅最新版本的协议条款。如您继续使用“尼来”软件与/或相关服务，即表示您已同意接受修订后的本协议内容。\n您对修改后的协议条款存有异议的，请立即停止登录或使用“尼来”软件与/或相关服务。若您继续登录或使用“尼来”软件与/或相关服务，即视为您认可并接受修改后的协议条款。\n3. 公司有权依“尼来”软件与/或相关服务或运营的需要单方决定，安排或指定其关联方、控制公司、继承公司或公司认可的第三方公司继续运营“尼来”软件。并且，就本协议项下涉及的某些服务，可能会由公司的关联方、控制公司、继承公司或公司认可的第三方公司向您提供。您知晓并同意接受相关服务内容，即视为接受相关权利义务关系亦受本协议约束。\n4. 本协议中的标题仅为方便及阅读而设，并不影响本协议中任何规定的含义或解释。\n5. 您和公司均是独立的主体，在任何情况下本协议不构成公司对您的任何形式的明示或暗示担保或条件，双方之间亦不构成代理、合伙、合营或雇佣关系。\n';
const userAgreement = "# 尼来个人信息保护政策\n\n> 更新时间：2024 年 12 月 20 日\n\n> 生效时间：2024 年 12 月 20 日\n\n尼来（简称“我们”）深知个人信息对您的重要性，您的信任对我们非常重要，我们将按照《中华人民共和国网络安全法》和相关法律法规的规定并参照行业最佳实践保护您的个人信息及隐私安全。我们制定“尼来个人信息保护政策”(以下简称“本政策”)并特别提示：希望您在使用“尼来”软件与/或相关服务前仔细阅读并理解本政策，以便做出适当的选择。\n\n## **_【特别提示】_**\n\n1. **在您使用“尼来”产品与/或相关服务前，请仔细阅读并充分了解本政策。重点内容我们已采用粗体特别表示，希望您在阅读时特别关注。**  一旦您使用或继续使用“尼来”产品与/或相关服务，即表示您同意我们按照本政策处理您的相关个人信息。\n\n2. **我们会遵循本政策收集、使用您的信息，但不会仅因您同意本政策而采用强制捆绑的方式一揽子收集个人信息。**\n\n3. **只有在得到您确认同意的情况下，我们才会按照本政策处理您的个人信息；除非再次征得您的同意，我们不会将您的个人信息用于本政策未载明的其他目的。您可以选择不同意，我们将向您提供「仅浏览和搜索」功能，但这可能导致您无法完整使用“尼来”产品与/或相关服务及其功能。**\n4. 当您使用相关功能或使用服务时，为实现功能、服务所必需，我们会收集、使用相关信息。除非是为实现业务功能或根据法律法规要求所必需的必要信息，您均可以拒绝提供且不影响其他功能或服务。\n\n5. 您在向我们提供您的任何个人敏感信息前，请您考虑清楚该等提供是恰当的并且同意您的个人敏感信息可按本政策所述的目的和方式进行处理。\n\n6. **若您是未满18周岁的未成年人，请确保在征得您的监护人同意后使用“尼来”产品与/或相关服务并向我们提供您的个人信息。**\n\n7. 我们会采取互联网行业内标准的技术措施和管理措施来保证您的信息安全。\n\n8. 摄像头（相机）、相册（存储）、活动记录权限，均不会默认开启，只有经过您的明示授权才会在为实现特定功能或服务时使用，您也可以撤回授权。特别需要指出的是，即使经过您的授权，我们获得了这些敏感权限，也不会在相关功能或服务不需要时收集您的信息。\n\n如您在阅读本协议过程中有任何疑惑、意见或建议，您可以发送邮件至\nservice@tansocc.com 与我们联系。\n\n下文将帮您详细了解我们如何收集、使用、存储与保护个人信息本政策与您使用我们的服务关系密切，我们建议您仔细阅读并理解本政策全部内容，作出您认为适当的选择。\n\n## **本个人信息保护政策包含以下内容：**\n\n1. 收集和使用个人信息\n\n2. 数据使用过程中涉及的公开披露您的个人信息\n\n3. 存储个人信息\n\n4. 保护个人信息的安全\n\n5. 管理您的个人信息\n\n6. 未成年人条款\n\n7. 政策的修订和通知\n\n8. 联系我们\n\n## 收集和使用个人信息\n\n我们会秉承合法、正当、必要、公开的原则，出于本政策所述的以下目的，收集和使用您在使用“尼来”产品与/或相关服务过程中主动提供或因使用“尼来”产品与/或相关服务而产生的个人信息。\n\nA. 为实现尼来的基本业务功能，我们需要向您收集和使用您的个人信息。以下将详细列出尼来的基本业务功能及为实现该功能所需收集和使用的个人信息，若您拒绝收集，则无法使用该功能。**提示您注意：如果您提供的是他人的个人信息，请您确保已取得相关主体的授权。**\n\nB. 应用权限申请与使用情况说明\n\n| 权限名称         |              权限功能说明              |                                               使用场景或目的                                                |\n| ---------------- | :------------------------------------: | :---------------------------------------------------------------------------------------------------------: |\n| 拍摄             |      使用拍摄照片、完成扫描二维码      |                                          发布内容、修改头像时使用                                           |\n| 读取外置存储器   |    提供读取手机储存空间内数据的功能    |   允许App读取存储中的图片信息，主要用于帮助您发布信息，在本地记录崩溃日志信息（如有）、清理卸载残留等功能   |\n| 写入外置存储器   |          提供写入外部储存功能          |                     允许App写入/下载/保存/修改/删除图片、文件、崩溃日志、卸载残留等信息                     |\n| 网络             |            提供网络访问支持            |                                             下载应用，同步数据                                              |\n| 读取手机状态     |        提供手机状态和出厂信息等        |           获取手机型号等信息，获取手机当前状态等信息，保障软件与服务的安全运行、运营的质量及效率            |\n| 网络状态         |         读取手机当前的网络状态         |                         允许应用程序查看获取网络信息状态,如当前的网络连接是否有效。                         |\n| 软件安装列表     |           读取已安装应用列表           |                           用于获取APP市场最新的APP应用版本，提示您及时更新本APP。                           |\n| 手机号码         |         获取当前设备的手机号码         | 用于校验用户信息，为账号提供安全保障；作为账户密码自动生成的传入参数之一，在App注册时用于自动生成账户密码。 |\n| 通知             |                系统通知                |                                   用于APP相关消息推送，避免错过重要消息。                                   |\n| 麦克风权限       |         允许使用麦克风进行录音         |                    作为账户密码自动生成的传入参数之一，在App注册时用于自动生成账户密码。                    |\n| 模糊地址位置权限 | 访问大概的位置源，以确定手机的大概位置 |                    作为账户密码自动生成的传入参数之一，在App注册时用于自动生成账户密码。                    |\n| 精准地址位置权限 | 访问精准的位置源，以确定手机的精准位置 |                    作为账户密码自动生成的传入参数之一，在App注册时用于自动生成账户密码。                    |\n| 传感器数据权限   |      访问传感器数据(当手机支持时)      |                    作为账户密码自动生成的传入参数之一，在App注册时用于自动生成账户密码。                    |\n\n### 注册、登录、认证、注销\n\n#### 注册、登录账户\n\n1. 在您访问尼来时，需要注册成为平台用户后才能使用服务。\n\n2. **当您注册尼来账号时，根据我国法律法规及出于安全保障目的，如注册不成功，也无法使用尼来产品与/或相关服务的相关功能。**\n\n</u>\n\n3. <u>**成功登录后，若想要使用“尼来”产品与/或相关服务的全部功能，您还需要先登录或者绑定您的地址。**</u>\n\n4. 为了保障功能或服务的一致性，我们可能会在客户端对授权、登录的帐号与设备重新进行校验。\n\n5. 无论注册还是登录，您都必须提供上述信息并同意用户服务协议和本政策后，您才可以使用除「浏览和搜索」功能外的“尼来”产品与/或相关服务的其他功能。\n\n#### 认证\n\n1. 在你使用身份认证的功能或相关服务所需时，根据相关法律法规，**我们可能收集你的真实身份信息（真实姓名、身份证号码、电话号码等）以完成实名验证**。 部分信息属于个人敏感信息，你可以拒绝提供，如果拒绝提供你将可能无法获得相关服务，但不影响其他功能与服务的正常使用。\n\n### 运营与安全保障\n\n我们致力于为您提供安全、可信的产品与使用环境，提供优质而可靠的服务与信息是我们的核心目标。为了维护我们服务的正常运行并保护您或其他用户或公众的合法利益免受损失，我们会收集用于维护产品或服务安全稳定运行的必要信息。\n\n#### 设备信息\n\n为了保障软件与服务的安全运行、运营的质量及效率，我们会自动收集您的设备信息，如设备型号、操作系统版本号、设备标识符（Android如IMEI、AndroidID、OAID、IMSI、ICCID、MEID；不同的标识符在有效期、是否可由用户重置以及获取方式方面会有所不同）、软件版本号、服务日志。我们可能会将您的设备信息或电话号码与您的尼来帐号相关联，以便我们能在这些设备上为您提供一致的服务。\n\n#### 日志信息\n\n1. 当您使用“尼来”产品与/或相关服务时，我们会自动收集您使用“尼来”产品与/或相关服务的详细情况，并作为网络日志进行保存，包括您对“尼来”产品与/或相关服务的使用情况、IP地址、所访问服务的URL、浏览器类型和使用的语言、下载、安装或使用移动应用和软件的信息以及访问服务的日期、时间、时长等，以便我们统计产品与/或服务的使用情况、分析数据并记录您对相应内容的收藏情况。\n2. 为了预防恶意程序、提升运营质量及效率、保障帐号安全，我们会收集安装的应用信息或正在运行的进程信息、应用程序的总体运行、使用情况与频率、应用崩溃情况、总体安装使用情况、性能数据、应用来源。\n\n### 收集、使用个人信息目的变更\n\n请您了解，随着我们业务的发展，可能会对“尼来”产品与/或相关服务有所调整变化。原则上，当新功能或服务与我们当前提供的功能或服务相关时，收集与使用的个人信息将与原处理目的具有直接或合理关联。在与原处理目的无直接或合理关联的场景下，我们收集、使用您的个人信息，会再次按照法律法规及国家标准的要求以页面提示、交互流程、协议确认方式另行向您进行告知说明，并征得您的同意。\n\n### 征得授权同意的例外\n\n请您理解，在下列情形中，根据法律法规及相关国家标准，我们收集和使用您的个人信息不必事先征得您的授权同意：\n\n- 与我们履行法律法规规定的义务相关的；\n- 与国家安全、国防安全直接相关的；\n- 与公共安全、公共卫生、重大公共利益直接相关的；\n- 与刑事侦查、起诉、审判和判决执行等直接相关的；\n- 出于维护您或他人的生命、财产等重大合法权益但又很难得到本人授权同意的；\n- 您自行向社会公众公开的个人信息；\n- 根据个人信息主体要求签订和履行合同所必需的；\n- 从合法公开披露的信息中收集的您的个人信息的，如合法的新闻报道、政府信息公开等渠道；\n- 用于维护软件及相关服务的安全稳定运行所必需的，例如发现、处置软件及相关服务的故障；\n- 为开展合法的新闻报道所必需的；\n- 为学术研究机构，基于公共利益开展统计或学术研究所必要，且对外提供学术研究或描述的结果时，对结果中所包含的个人信息进行去标识化处理的；\n- 法律法规规定的其他情形。\n\n特别提示您注意，如信息无法单独或结合其他信息识别到您的个人身份，其不属于法律意义上您的个人信息；当您的信息可以单独或结合其他信息识别到您的个人身份时或我们将无法与任何特定个人信息建立联系的数据与其他您的个人信息结合使用时，这些信息在结合使用期间，将作为您的个人信息按照本政策处理与保护。\n\nB.为了给您提供更好的使用体验，我们会为您提供下述扩展业务功能，在您使用此类功能时，我们会基于特定目的收集您的个人信息。如您不提供此类信息，您将无法使用下述扩展业务功能，但不会影响您使用基本业务功能。\n\n1. **基于”相册/存储“的扩展业务功能：**\n   当您使用“尼来”产品与/或相关服务时，您可在开启“读取相册权限/存储权限”后上传照片或图片，用于设置头像及封面图、发布等功能。我们会获取您上传的图片并对其内容的合规性进行审核。\n\n## 数据使用过程中涉及的公开披露您的个人信息\n\n### 公开\n\n1. **我们不会公开您的个人信息，除非遵循国家法律法规规定或者获得您的同意。我们公开您的个人信息会采用符合行业内标准的安全保护措施。**\n2. 依法豁免征得同意可提供、公开的个人信息。请您理解，在下列情形中，根据法律法规及国家标准，我们向合作方提供、公开您的个人信息无需征得您的授权同意：\n   - 为订立、履行您作为一方当事人的合同所必需，或者按照依法制定的劳动规章制度和依法签订的集体合同实施人力资源管理所必需；\n   - 为履行法定职责或者法定义务所必需；\n   - 与国家安全、国防安全直接相关的；\n   - 与刑事侦查、起诉、审判和判决执行等直接相关的；\n   - 为应对突发公共卫生事件，或者紧急情况下为保护自然人的生命、健康和财产安全所必需；\n   - 为公共利益实施新闻报道、舆论监督等行为，在合理的范围内处理个人信息\n   - 您自行向社会公众公开的个人信息；\n   - 从合法公开披露的信息中收集个人信息的，如合法的新闻报道、政府信息公开等渠道；\n   - 法律、行政法规规定的其他情形。\n\n## 存储个人信息\n\n### 存储地点\n\n我们依照法律法规的规定，将在境内运营过程中收集和产生的您的个人信息存储于中华人民共和国境内。目前，我们不会将上述信息传输至境外，如果我们向境外传输，会严格遵守中国的相关法律、监管政策，并会遵循相关国家规定或者征求您的同意。\n\n### 存储期限\n\n我们仅在为提供尼来及服务之目的所必需的期间内保留您的个人信息，例如：\n\n**手机号码：使用手机号码认证时，我们需要持续保留您的手机号码，以便于向您提供正常的服务并保障您的帐号和系统安全。**\n\n如我们因经营不善或其他原因出现停止运营的情况，我们会将此情况通知您，并停止对您个人信息的收集以及删除或匿名化已收集的个人信息，但法律法规另有要求的除外。\n\n如果您主动删除个人信息或超出必要的期限后，我们将对您的个人信息进行删除或匿名化处理。\n\n### 保护个人信息的安全\n\n1. 我们非常重视您个人信息的安全，将努力采取合理的安全措施（包括技术方面和管理方面）来保护您的个人信息，防止您提供的个人信息被不当使用或在未经授权的情况下被访问、公开披露、使用、修改、损坏、丢失或泄漏。\n2. **我们会使用不低于行业同行的加密技术、匿名化处理及相关合理可行的手段保护您的个人信息，并使用安全保护机制防止您的个人信息遭到恶意攻击，包括但不限于：**\n   - **我们会提供 https 安全浏览方式保护数据在其传输过程中的安全，除此以外我们还会使用妥善的保护机制以防止数据遭到恶意攻击；**\n   - **我们会使用加密技术以及去标识化的处理方式并采用分类存储的方式保存您的个人信息；**\n   - **为提升我们整体员工的数据安全保护意识，我们会举办安全和隐私保护培训课程，加强员工对于保护个人信息重要性的认识。**\n3. 请您注意，电子邮件、即时通讯及与其他尼来用户之间的交流并未加密，如非必要，我们强烈建议您不要通过此类方式发送重要的个人信息，并采取积极措施保护个人信息的安全，**包括但不限于使用复杂密码、定期修改密码、不将自己的帐号密码及相关个人信息透露给他人**。\n4. 尽管已经采取了上述合理有效措施，并已经遵守了相关法律规定要求的标准，但请您理解，由于技术的限制以及可能存在的各种恶意手段，在互联网行业，即便竭尽所能加强安全措施，也不可能始终保证信息百分之百的安全，我们将尽力确保您提供给我们的个人信息的安全性。\n5. 我们会制定应急处理预案，并在发生用户信息安全事件时立即启动应急预案，努力阻止这些安全事件的影响和后果扩大。一旦发生用户信息安全事件（泄露、丢失）后，我们将按照法律法规的要求，及时向您告知：安全事件的基本情况和可能的影响、我们已经采取或将要采取的处置措施、您可自主防范和降低风险的建议、对您的补救措施。我们将及时将事件相关情况以推送通知、邮件、信函、短信及相关形式告知您，难以逐一告知时，我们会采取合理、有效的方式发布公告。同时，我们还将按照相关监管部门要求，上报用户信息安全事件的处置情况。\n6. 您一旦离开尼来及相关服务，浏览或使用其他网站、服务及内容资源，我们将没有能力和直接义务保护您在尼来及相关服务之外的软件、网站提交的任何个人信息，无论您登录、浏览或使用上述软件、网站是否基于“尼来”的链接或引导。\n\n## 管理您的个人信息\n\n为了您可以更加便捷地访问、更改或删除您的个人信息，同时保障您撤回处理您个人信息同意的权利，您可以参考下面的指引进行操作：\n\n1. 访问和更正您的个人信息\n   **除法律法规规定外，您有权随时登录您的账户访问或修改您的个人信息**\n\n2. 改变或撤回授权范围我们非常重视您对个人信息的管理，并尽全力保护对您个人信息的查阅、复制、更正、补充、删除、撤回同意授权的相关权利，以使您有能力保障您的隐私和信息安全。为了优化您的使用体验，我们也可能对操作设置进行调整，故如下指引仅供参考。\n\n   - **改变或撤回敏感权限设置**\n\n     - **您可以在设备本身的操作系统中，相册（存储）改变同意范围或撤回您的授权。关闭授权后我们将不再收集与这些权限相关的信息。**\n\n   - **改变或撤回授权的信息处理**\n     - **特定的业务功能和服务将需要您的信息才能得以完成，当您撤回同意或授权后，我们无法继续为您提供撤回同意或授权所对应的功能和服务，也不再处理您相应的个人信息。但您撤回同意或授权的决定，不会影响公司此前基于您的授权而开展的个人信息处理**。\n\n3. 个人信息收集与管理的说明\n\n   - **在以下情形中，您可以向我们提出删除个人信息的请求：**\n\n     - 处理目的已实现、无法实现或者为实现处理目的不再必要；\n     - 我们停止提供产品或者服务，或者保存期限已届满；\n     - 个人撤回同意\n     - 如果我们处理个人信息的行为违反了法律、行政法规或与您的约定；\n     - 法律、行政法规规定的其他情形。\n\n   - **个人信息删除：指在实现日常业务功能所涉及的系统中去除个人信息的行为，使其保持不可被检索、访问的状态。当您或我们协助您删除相关信息后，因为适用的法律和安全技术限制，我们可能无法立即从备份系统中删除相应的信息，我们将安全地存储您的个人信息并限制对其的任何进一步的处理，直到备份可以清除或实现匿名化。**\n\n4. 访问政策\n   - 您可以在登录页面查看本政策全部内容。\n   - 请您了解，本政策中所述的“尼来”与/或相关服务可能会根据您所使用的手机型号、系统版本、软件应用程序版本、移动客户端等因素而有所不同。最终的产品和服务以您所使用的“尼来”软件及相关服务为准。\n\n## 未成年人条款\n\n### 未成年人的个人信息保护原则\n\n我们非常重视对未成年个人信息的保护。尼来主要面向成年人。**若您是未满18周岁的未成年人，在使用本产品前，应在您的父母或其他监护人的监护、指导下共同阅读并同意本政策。若您是未满14周岁的未成年人的监护人，在使用尼来及相关服务前，应为您的被监护人阅读并同意本政策。**\n\n1. 我们根据国家相关法律法规的规定保护未成年人的个人信息，只会在法律允许、父母或其他监护人明确同意或保护未成年人所必要的情况下收集、使用或披露未成年人的个人信息；如果我们发现在未事先获得可证实的监护人同意的情况下收集了未成年人的个人信息，则会设法尽快删除相关信息。\n2. 若您是未成年人的监护人，当您对您所监护的未成年人使用“尼来”产品与/或服务或其向我们提供的的个人信息有其他疑问时，请通过公司本政策公示的联系方式与我们联系。\n\n## 政策的修订和通知\n\n1. 为了给您提供更好的服务，尼来及相关服务将不时更新与变化，我们会适时对本政策进行修订，这些修订构成本政策的一部分并具有等同于本政策的效力，未经您明确同意，我们不会削减您依据当前生效的本政策所应享受的权利。\n2. 请您仔细阅读变更后的本政策内容。如果您不同意本政策，或对本政策修改、更新的内容有异议，您可以选择注销账号并不再使用本服务但请您知悉，您账号注销之前、停止使用本服务之前的行为和活动仍受本政策的约束。\n3. 本政策更新后，我们会在尼来发出更新版本，并在更新后的条款生效前以适当的方式提醒您更新的内容，以便您及时了解本政策的最新版本。\n4. 若涉及重大变更，我们会依据具体情况，以显著的方式通知您。重大变更的情形包括但不限于以下情形：\n   - 我们的服务模式发生重大变化。如处理个人信息的目的、处理的个人信息类型、个人信息的使用方式等；\n   - 您参与个人信息处理方面的权利及其行使方式发生重大变化。\n\n## 联系我们\n\n1. 尼来由中数碳本(厦门)元宇宙科技有限公司提供，如果您对个人信息保护问题有投诉、建议、疑问，您可以将问题发送至：service@tansocc.com，我们核查并验证您的用户身份后会及时反馈您的投诉与举报。\n2. 若您对本政策有任何疑问或为行使您的个人主体权利，您可以通过发送邮件至\n   service@tansocc.com 的方式与我们联系。一般情况下，我们将于14个工作日内响应。\n";
const agreement_page = definePage((args) => {
  const { type } = zAgreement.parse(args.f7route.params);
  const [content, setContent] = reactExports.useState("");
  const [title, setTitle] = reactExports.useState("");
  reactExports.useEffect(() => {
    const converter = new Marked();
    let title2 = "";
    let content2 = "";
    if (type === "protection") {
      title2 = personal_information_protection_policy();
      content2 = userAgreement;
    } else if (type === "user") {
      title2 = user_service_agreement();
      content2 = serviceAgreement;
    }
    setTitle(title2);
    setContent(converter.parse(content2, { async: false }));
  });
  return /* @__PURE__ */ React.createElement(Page, { name: "agreement", pageContent: false }, /* @__PURE__ */ React.createElement(
    Navbar,
    {
      backLink: true,
      title,
      color: "white",
      className: "text-white"
    }
  ), /* @__PURE__ */ React.createElement(PageContent, { className: "px-4" }, /* @__PURE__ */ React.createElement(
    "article",
    {
      className: "prose prose-sm lg:prose-xl prose-invert",
      dangerouslySetInnerHTML: {
        __html: content
      }
    }
  )));
});
export {
  agreement_page as default
};
