import { d as definePage, r as reactExports, g as getDwebAppDownUrl, c as canOpenUrl, R as React, P as Page, B as Block, u as useSuperellipseDomRef, a as Button, s as sign_in, N as NiLaiIcon, b as user_service_agreement_1, e as user_service_agreement_2, f as user_service_agreement_3, h as user_service_agreement_4, i as user_service_agreement_5, A as Actions, j as ActionsGroup, C as ComponentName, k as connect_your_account, l as register_a_new_account, m as reconnect_$wallet$, n as ConfirmDialog, o as agree, p as agree_to_the_platform_agreement, q as dwebAppConfig, t as gotoDwebAppMarketDownLoad, v as getWalleterAddresss, w as focusWindow, x as toast, y as address_registration_failed, z as isBioforestChainName, D as BIOFOREST_CHAIN_NAME, E as iter_map_not_null, F as userController, G as authorization_failed, H as store, I as ccchainController, J as BIOFOREST_CHAIN_NAME_VALUES, K as loginAppUser, L as authorization_successful } from "./index-DCNl9Xz5.js";
import { s as setup, g as generateRandomMnemonic } from "./index-CQT1PcgH.js";
setup({
  wasmBaseUrl: "./wallet-util/assets"
});
const createMnemonic = async (lang) => {
  let language = "english";
  switch (lang) {
    case "zh-hans":
      language = "chinese_simplified";
      break;
    case "zh-hant":
      language = "chinese_traditional";
      break;
  }
  const { mnemonic } = await generateRandomMnemonic(12, language);
  return mnemonic;
};
const linkWallet_page = definePage((args) => {
  const xPayInfo = dwebAppConfig.XPay(false);
  const biwMetaInfo = dwebAppConfig.BIWMeta(false);
  const [openAgreementDialog, setOpenAgreementDialog] = reactExports.useState(false);
  const [isLoading, setIsLoading] = reactExports.useState(false);
  const walletInfo = reactExports.useRef({
    xpay: {
      down: true,
      downloadUrl: "",
      marketUrl: ""
    },
    biw: {
      down: true,
      downloadUrl: "",
      marketUrl: ""
    }
  });
  const [agreementProtocol, setAgreementProtocol] = reactExports.useState(false);
  const logined = async (info) => {
    await loginAppUser(info);
    toast(authorization_successful());
    args.safeF7Navigater.tabs();
  };
  const load = async (walletType) => {
    if (isLoading) return;
    if (!agreementProtocol) {
      setOpenAgreementDialog(true);
      return;
    }
    setIsLoading(true);
    try {
      if (true) {
        const wallet = walletType === "xpay" ? walletInfo.current.xpay : walletInfo.current.biw;
        if (!wallet.down) {
          gotoDwebAppMarketDownLoad(wallet);
          wallet.down = true;
          walletInfo.current = {
            ...walletInfo.current,
            [walletType]: {
              ...wallet
            }
          };
          return;
        }
        setIsLoading(false);
        const res = await getWalleterAddresss(walletType === "xpay" ? xPayInfo.mmid : biwMetaInfo.mmid);
        void focusWindow();
        if (res == null || res.length == 0) {
          toast(address_registration_failed());
          return;
        }
        const addressInfo = res.find((item) => isBioforestChainName(item.chainName, BIOFOREST_CHAIN_NAME.CCChain)) || res[0];
        const info = {
          id: "",
          notBackedUp: false,
          avatarStr: "",
          address: addressInfo.address,
          level: 0,
          chain: addressInfo.chainName,
          privateKey: addressInfo.privateKey,
          publicKey: addressInfo.publicKey,
          main: addressInfo.main,
          score: "0",
          inviteds: [],
          chainList: iter_map_not_null(
            res,
            (item) => isBioforestChainName(item) ? item : null
          )
        };
        setIsLoading(true);
        if (await userController.registry({
          address: info.address,
          main: info.main
        })) {
          await logined(info);
        } else {
          toast(authorization_failed());
        }
      }
    } catch (error) {
      console.error(error);
      toast(authorization_failed() + "\n" + (error instanceof Error ? error.message : String(error)));
      const wallet = walletType === "xpay" ? walletInfo.current.xpay : walletInfo.current.biw;
      wallet.down = false;
      walletInfo.current = {
        ...walletInfo.current,
        [walletType]: {
          ...wallet
        }
      };
    } finally {
      setIsLoading(false);
    }
  };
  reactExports.useEffect(() => {
    {
      Promise.all([
        getDwebAppDownUrl(xPayInfo),
        getDwebAppDownUrl(biwMetaInfo),
        canOpenUrl(xPayInfo.mmid),
        canOpenUrl(biwMetaInfo.mmid)
      ]).then((res) => {
        walletInfo.current = {
          xpay: {
            down: res[2].success,
            ...res[0]
          },
          biw: {
            down: res[3].success,
            ...res[1]
          }
        };
      });
    }
  }, []);
  const [loginUserActionsOpened, setLoginUserActionsOpened] = reactExports.useState(false);
  const actionsClosed = () => {
    setLoginUserActionsOpened(false);
  };
  const [selectWallet, setSelectWallet] = reactExports.useState(false);
  const oneClickLogin = async () => {
    try {
      setIsLoading(true);
      const mnemonic = await createMnemonic(store.state.lang);
      const address = await ccchainController.getAddressByMainSecret(mnemonic);
      const keypair = await ccchainController.createKeypair(mnemonic);
      const userInfo = {
        id: "",
        avatarStr: "",
        address,
        chain: BIOFOREST_CHAIN_NAME.CCChain,
        publicKey: keypair.publicKey.toString("hex"),
        privateKey: keypair.secretKey.toString("hex"),
        main: mnemonic,
        level: 0,
        notBackedUp: true,
        score: "0",
        inviteds: [],
        chainList: BIOFOREST_CHAIN_NAME_VALUES.map((item) => {
          return {
            name: "wallet",
            chainName: item,
            address,
            publicKey: keypair.publicKey.toString("hex")
          };
        })
      };
      if (await userController.registry({
        address: userInfo.address,
        main: userInfo.main
      })) {
        await logined(userInfo);
      } else {
        toast(address_registration_failed());
      }
    } finally {
      setIsLoading(false);
    }
  };
  return /* @__PURE__ */ React.createElement(
    Page,
    {
      noToolbar: true,
      noNavbar: true,
      noSwipeback: true,
      name: "link-wallet",
      className: "bg-black bg-[url('../images/link_wallet_bg.webp')] bg-[length:100%_auto] bg-top bg-no-repeat"
    },
    /* @__PURE__ */ React.createElement("div", { className: "flex h-full w-full flex-col items-center justify-between px-5" }, /* @__PURE__ */ React.createElement("div", { className: "my-auto" }, /* @__PURE__ */ React.createElement(Block, { className: "text-primary mb-20" }, /* @__PURE__ */ React.createElement(
      "img",
      {
        ref: useSuperellipseDomRef(),
        src: "./images/logo.svg",
        alt: "logo",
        className: "rounded-4 m-auto mb-5",
        style: { width: "68px", height: "68px" }
      }
    ))), /* @__PURE__ */ React.createElement("div", { className: "mb-8" }, /* @__PURE__ */ React.createElement(
      Button,
      {
        className: "bg-primary mb-5 w-full rounded-full text-base font-bold text-black",
        large: true,
        raised: true,
        fill: true,
        preloader: true,
        preloaderColor: "black",
        loading: isLoading,
        onClick: () => {
          if (!agreementProtocol) {
            setOpenAgreementDialog(true);
            return;
          }
          setLoginUserActionsOpened(true);
        }
      },
      sign_in()
    ), /* @__PURE__ */ React.createElement("div", { className: "flex items-center py-2" }, /* @__PURE__ */ React.createElement(
      "button",
      {
        className: "inline-block w-auto items-center",
        onClick: () => setAgreementProtocol(!agreementProtocol)
      },
      /* @__PURE__ */ React.createElement(
        "div",
        {
          className: `border-tiny mr-1 flex h-3 w-3 items-center justify-center ${agreementProtocol ? "bg-primary" : "border-white"}`
        },
        agreementProtocol && /* @__PURE__ */ React.createElement(
          NiLaiIcon,
          {
            name: "common-selected",
            className: "text-primary icon-3",
            style: { "--color-1": "#000000" }
          }
        )
      )
    ), /* @__PURE__ */ React.createElement("span", { className: "text-xss break-all" }, user_service_agreement_1(), " ", /* @__PURE__ */ React.createElement(
      "span",
      {
        className: "text-primary",
        onClick: () => {
          args.safeF7Navigater.agreement({
            params: { type: "user" }
          });
        }
      },
      user_service_agreement_2()
    ), " ", user_service_agreement_3(), " ", /* @__PURE__ */ React.createElement(
      "span",
      {
        className: "text-primary",
        onClick: () => {
          args.safeF7Navigater.agreement({
            params: { type: "protection" }
          });
        }
      },
      user_service_agreement_4()
    ), " ", user_service_agreement_5())), /* @__PURE__ */ React.createElement("div", { className: "text-subtext text-xss text-center" }, "ICP备案/许可证号:", /* @__PURE__ */ React.createElement("span", null, "闽ICP备2024073349号-1")))),
    /* @__PURE__ */ React.createElement(Actions, { opened: loginUserActionsOpened, onActionsClosed: actionsClosed }, /* @__PURE__ */ React.createElement(ActionsGroup, null, /* @__PURE__ */ React.createElement(ComponentName, { onClick: () => setSelectWallet(true), className: "!bg-pop-background !text-primary" }, connect_your_account()), /* @__PURE__ */ React.createElement(
      ComponentName,
      {
        className: "!bg-pop-background !text-secondary-red",
        onClick: () => {
          oneClickLogin();
        }
      },
      register_a_new_account()
    ))),
    /* @__PURE__ */ React.createElement(Actions, { opened: selectWallet, onActionsClosed: () => setSelectWallet(false) }, /* @__PURE__ */ React.createElement(ActionsGroup, null, /* @__PURE__ */ React.createElement(ComponentName, { onClick: () => load("xpay"), className: "!bg-pop-background !text-primary" }, reconnect_$wallet$({
      wallet: xPayInfo.name
    })), /* @__PURE__ */ React.createElement(ComponentName, { className: "!bg-pop-background !text-primary", onClick: () => load("biw") }, reconnect_$wallet$({
      wallet: biwMetaInfo.name
    })))),
    /* @__PURE__ */ React.createElement(
      ConfirmDialog,
      {
        open: openAgreementDialog,
        confirmText: agree(),
        onConfirmCallback: () => {
          setAgreementProtocol(true);
        },
        onRequireClose: () => {
          setOpenAgreementDialog(false);
        }
      },
      agree_to_the_platform_agreement()
    )
  );
});
export {
  linkWallet_page as default
};
