import { d as definePage, r as reactExports, V as useFlow, at as userApi, am as adminApi, bt as the_inventory_of_this_product_is_insufficient, x as toast, bu as get_goods_detail_error, R as React, P as Page, O as Navbar, b5 as confirm_payment, aF as Toolbar, bv as total_price, a2 as Icon, aW as price_with_html, a as Button, aG as clsx, bw as sold_out, bx as go_to_checkout, Q as PageContent, ao as Card, aq as CardContent, by as please_fill_in_the_shipping_address, ax as BlobImage, aP as price, B as Block, a6 as List, az as ListInput, bz as order_notes, bA as purchase_limit_per_order_$number$, aT as z, a7 as ListItem, bB as deduction, bC as unused_discount_points, b9 as need_to_consume_$consume$_to_deduction$deduction$, ba as get_showAsset_balance, bb as get_discount_consumption_asset_types_amount_info, bD as insufficient_points_unable_to_deduct, bE as choose_to_give_away_rewards, bF as estimated_quantity_subject_to_actual_distribution, bG as platform_rewards, bH as consumption_rewards, bI as i18nGetAssetTypeText, b7 as Preloader, bJ as brand_rewards, be as AlertDialog, n as ConfirmDialog, bf as address_transaction_password, ah as confirm, bg as please_enter_the_address_transaction_password, bK as quantity_of_inputs, N as NiLaiIcon, aj as appUserInfoFlow, I as ccchainController, br as transaction_password_incorrect, aQ as discounted_price_info, bL as no_bonus_has_been_selected_for_gifting, bM as platform_points_not_selected, bN as brand_points_not_selected, bj as getUserAddressSecondPublicKey, bs as nilaiDialogStyle } from "./index-DCNl9Xz5.js";
import { A as AssetTypeName } from "./asset-type-Ct4QfOzQ.js";
import { o as onSelectDiscountPoints, a as onSelectMineAddress } from "./event-bus-CjvwdHdC.js";
import { AddressInfoView } from "./mine-address.page-Da4XZNT3.js";
const goodsOrderConfirmation_page = definePage((args) => {
  const detailObj = args.f7route.query;
  const [goodTitle, setGoodTitle] = reactExports.useState("");
  const [quantity, setQuantity] = reactExports.useState(1);
  const [maxQuantity, setMaxQuantity] = reactExports.useState(1);
  const orderNotesMaxlength = 50;
  const [orderNotes, setOrderNotes] = reactExports.useState("");
  const [appUserInfo] = useFlow(appUserInfoFlow);
  const handleOrderNotesChange = (event) => {
    const value = (event.target?.value || "").trim();
    setOrderNotes(value);
  };
  const [addressInfo, setAddressInfo] = reactExports.useState(
    (() => {
      if (appUserInfo.shippingAddressList) {
        const item = appUserInfo.shippingAddressList.find((item2) => !!item2.default);
        return item;
      }
      return void 0;
    })()
  );
  const [selectAirdrop, setSelectAirdrop] = reactExports.useState();
  const [selectBrandAirdrop, setBrandSelectAirdrop] = reactExports.useState();
  const [platformAirdropList, setPlatformAirdropList] = reactExports.useState([]);
  const [brandAirdropList, setBrandAirdropList] = reactExports.useState([]);
  const [soldOut, setSoldOut] = reactExports.useState(false);
  const handleSelectAirdrop = (item) => {
    setSelectAirdrop({ ...item });
  };
  const [openUserPayPwdDialog, setOpenUserPayPwdDialog] = reactExports.useState(false);
  const [inputUserPayPwd, setInputUserPayPwd] = reactExports.useState("");
  const secondPublicKey = reactExports.useRef("");
  const checkUserPayPwd = async () => {
    const userPayPwd = inputUserPayPwd;
    setInputUserPayPwd("");
    if (!userPayPwd) {
      return;
    }
    const res = await ccchainController.checkSecondSecret(appUserInfo.main, userPayPwd, secondPublicKey.current);
    if (!res) {
      toast(transaction_password_incorrect());
      return;
    }
    confirmPayment();
  };
  const [openInputQuantityDialog, setOpenInputQuantityDialog] = reactExports.useState(false);
  const [inputQuantity, setInputQuantity] = reactExports.useState(1);
  const getActualPrice = () => {
    if (!!detailObj.goodsDiscountbrandProportion) {
      if (selectDiscountPoints && selectDiscountPoints.select) {
        return discounted_price_info(detailObj.amount || "0", detailObj.goodsDiscountbrandProportion).discountedPrice;
      }
    }
    return detailObj.amount;
  };
  const [errorText, setDialogText] = reactExports.useState("");
  const dialogCallBack = () => {
    args.f7router.back();
  };
  const [openErrorDialog, setOpenErrorDialog] = reactExports.useState(false);
  const [selectDiscountPoints, setSelectDiscountPoints] = reactExports.useState(
    detailObj.goodsDiscountbrandProportion ? {
      select: false
    } : void 0
  );
  const checkSufficientDeduction = () => {
    if (!selectDiscountPoints || selectDiscountPoints.select === false) {
      return false;
    }
    const discountAmount = get_discount_consumption_asset_types_amount_info(detailObj.amount, {
      deductionRatio: detailObj.goodsDiscountbrandProportion,
      numberToPriceRatio: selectDiscountPoints.number,
      goodsQuantity: quantity
    }).discountedAmount;
    return BigInt(selectDiscountPoints.assetBalance) >= BigInt(discountAmount);
  };
  const goToSelectDiscountPoints = () => {
    const needAmount = get_discount_consumption_asset_types_amount_info(detailObj.amount, {
      deductionRatio: detailObj.goodsDiscountbrandProportion,
      numberToPriceRatio: "100000000",
      goodsQuantity: quantity
    }).discountedAmount;
    args.safeF7Navigater.goods.discountPoints({ params: { needAmount } });
  };
  reactExports.useEffect(() => {
    const off = onSelectDiscountPoints((v) => {
      setSelectDiscountPoints(
        v ? {
          ...v,
          select: true
        } : { select: false }
      );
    });
    return () => {
      off();
    };
  }, []);
  reactExports.useEffect(() => {
    let pageDestroy = false;
    (async () => {
      try {
        const details = await userApi.getGoodsDetails.query(detailObj.goodsId);
        setGoodTitle(details.title);
        if (typeof details.type !== "number") {
          throw new Error(`goods type ${details.type}!!!`);
        }
        const brandAirList = details.brandInfo.brandAssetTypeInfo ? [
          // {
          //   ...details.brandInfo.brandAssetTypeInfo.rwa,
          //   stablecoin: false,
          // },
          {
            ...details.brandInfo.brandAssetTypeInfo.stablecoin,
            stablecoin: true
          }
        ] : [];
        setBrandSelectAirdrop(brandAirList[0]);
        setBrandAirdropList(brandAirList);
        const list = await adminApi.airdrop.getAirdropList.query(details.type);
        if (!list.length) {
          throw new Error(`airdrop ist is empty ${details.type}!!!`);
        }
        const NLTItem = list.find(
          (item) => item.airdropType === "assetType" && item.airdropContent.assetType === "NLT"
        );
        NLTItem && setSelectAirdrop(NLTItem);
        setPlatformAirdropList([...list]);
        setMaxQuantity(+(details.singleLimitQuantity || 1));
        if (BigInt(details.stock) <= BigInt(0) && pageDestroy == false) {
          setDialogText(the_inventory_of_this_product_is_insufficient());
          setOpenErrorDialog(true);
          setSoldOut(true);
        }
      } catch (err) {
        console.error(err);
        if (pageDestroy) {
          return;
        }
        toast(String(err));
        setDialogText(get_goods_detail_error());
        setOpenErrorDialog(true);
      }
    })();
    const off = onSelectMineAddress(setSelectAddress);
    return () => {
      pageDestroy = true;
      off();
    };
  }, []);
  const setSelectAddress = (info) => {
    setAddressInfo(info);
  };
  const selectAddress = () => {
    args.safeF7Navigater.mine.mineAddress({ params: { type: "pick" } });
  };
  const getDPImage = (item) => {
    return "";
  };
  const [isLoadingPayment, setIsLoadingPayment] = reactExports.useState(false);
  const confirmPayment = async () => {
    try {
      setIsLoadingPayment(true);
      if (selectDiscountPoints && selectDiscountPoints.select === true) {
        const canPay = checkSufficientDeduction();
        if (canPay == false) {
          return toast(insufficient_points_unable_to_deduct());
        }
      }
      if (!addressInfo) {
        toast(please_fill_in_the_shipping_address());
        return;
      }
      if (!selectAirdrop?.airdropType && !selectBrandAirdrop?.assetType) {
        toast(no_bonus_has_been_selected_for_gifting());
        return;
      }
      if (!selectAirdrop?.airdropType) {
        toast(platform_points_not_selected());
        return;
      }
      if (!selectBrandAirdrop?.assetType) {
        toast(brand_points_not_selected());
        return;
      }
      if (selectDiscountPoints && selectDiscountPoints.select === true) {
        const userSecondPublicKey = await getUserAddressSecondPublicKey(appUserInfo.address);
        if (userSecondPublicKey) {
          secondPublicKey.current = userSecondPublicKey;
        }
        if (secondPublicKey.current && !inputUserPayPwd) {
          setOpenUserPayPwdDialog(true);
          return;
        }
      }
      const discountInfo = selectDiscountPoints && selectDiscountPoints.select ? {
        discountAssetType: selectDiscountPoints.assetType,
        discountChainMagic: selectDiscountPoints.chainMagic
      } : void 0;
      args.safeF7Navigater.goods.payment({
        query: {
          ...detailObj,
          actualPrice: getActualPrice(),
          quantity: String(quantity),
          addressId: addressInfo.id,
          platformAssetType: selectAirdrop.airdropContent.assetType,
          platformChainMagic: selectAirdrop.airdropContent.chainMagic,
          brandAssetType: selectBrandAirdrop.assetType,
          brandChainMagic: selectBrandAirdrop.chainMagic,
          orderNotes,
          // 折扣信息
          ...discountInfo
        },
        props: {
          payPwd: inputUserPayPwd
        },
        reloadCurrent: true
      });
    } finally {
      setIsLoadingPayment(false);
    }
  };
  const getRewardAmount = (airdropContent, key) => {
    const proportion_1000 = (+detailObj[key] * 1e3).toFixed(0);
    const amount = String(
      BigInt(airdropContent.number) * BigInt(proportion_1000) * BigInt(getActualPrice()) / BigInt(100) / BigInt(1e3)
    );
    return get_showAsset_balance(amount);
  };
  return /* @__PURE__ */ React.createElement(Page, { name: "good-detail", pageContent: false }, /* @__PURE__ */ React.createElement(Navbar, { title: confirm_payment(), backLink: true, color: "white" }), /* @__PURE__ */ React.createElement(Toolbar, { bottom: true }, /* @__PURE__ */ React.createElement("div", { className: "flex flex-1 items-end justify-start" }, /* @__PURE__ */ React.createElement("span", { className: "text-xss" }, total_price(), ":"), /* @__PURE__ */ React.createElement("span", { className: "text-secondary-red flex items-end" }, /* @__PURE__ */ React.createElement(Icon, { f7: "money_yen", size: 12 }), /* @__PURE__ */ React.createElement("span", { className: "text-base font-bold leading-4" }, price_with_html(+(getActualPrice() || 0) * quantity, {
    dotClassName: "text-xss",
    floatClassName: "text-xss"
  })))), /* @__PURE__ */ React.createElement(
    Button,
    {
      disabled: soldOut,
      preloader: isLoadingPayment,
      preloaderColor: "white",
      loading: isLoadingPayment,
      fill: true,
      onClick: confirmPayment,
      round: true,
      bgColor: "secondary-red",
      className: clsx("!bg-secondary-red flex-shrink-0 font-bold", {
        grayscale: soldOut
      })
    },
    soldOut ? sold_out() : go_to_checkout()
  )), /* @__PURE__ */ React.createElement(PageContent, null, /* @__PURE__ */ React.createElement("div", { className: "w-full" }, /* @__PURE__ */ React.createElement(Card, { outline: true, footerDivider: true, className: "bg-pop-background text-white" }, addressInfo === void 0 ? /* @__PURE__ */ React.createElement("div", { onClick: selectAddress }, /* @__PURE__ */ React.createElement(CardContent, null, /* @__PURE__ */ React.createElement("div", { className: "flex items-center justify-between" }, please_fill_in_the_shipping_address(), /* @__PURE__ */ React.createElement(Icon, { f7: "chevron_right", size: 16 })))) : /* @__PURE__ */ React.createElement(SelectedAddressCardView, { addressInfo, onClick: selectAddress })), /* @__PURE__ */ React.createElement(Card, { outline: true, footerDivider: true, className: "bg-pop-background relative mb-1 p-4 pb-5 text-white" }, /* @__PURE__ */ React.createElement(CardContent, { padding: false }, /* @__PURE__ */ React.createElement("div", { className: "h-18 mb-2 flex items-start justify-between" }, /* @__PURE__ */ React.createElement(BlobImage, { bloburi: detailObj.imgBloburi, className: "w-18 h-18 mr-2 flex-shrink-0" }), /* @__PURE__ */ React.createElement("div", { className: "flex h-full flex-grow flex-col justify-between overflow-hidden" }, /* @__PURE__ */ React.createElement("div", { className: "mb-2 flex-grow break-words" }, goodTitle), /* @__PURE__ */ React.createElement("div", { className: "text-primary flex flex-shrink-0 items-center justify-between text-base" }, /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("span", { className: "mr-1 text-sm" }, "¥"), price(getActualPrice())), /* @__PURE__ */ React.createElement("div", { className: "flex flex-shrink-0 items-center justify-center" }, /* @__PURE__ */ React.createElement(
    "div",
    {
      className: "flex items-center justify-center",
      onClick: () => {
        if (quantity >= 2) {
          setInputQuantity(quantity - 1);
          setQuantity(quantity - 1);
        }
      }
    },
    /* @__PURE__ */ React.createElement(
      Icon,
      {
        f7: "minus",
        className: `${quantity <= 1 ? "text-white/20" : "text-white"}`,
        size: 16
      }
    )
  ), /* @__PURE__ */ React.createElement(
    "div",
    {
      className: "rounded-1 bg-stepper-bg px-4.5 mx-1 text-white",
      onClick: () => {
        setInputQuantity(quantity);
        setOpenInputQuantityDialog(true);
      }
    },
    quantity
  ), /* @__PURE__ */ React.createElement(
    "div",
    {
      className: "flex items-center justify-center",
      onClick: () => {
        if (quantity < maxQuantity) {
          setInputQuantity(quantity + 1);
          setQuantity(quantity + 1);
        }
      }
    },
    /* @__PURE__ */ React.createElement(
      Icon,
      {
        f7: "plus",
        className: `${quantity >= maxQuantity ? "text-white/20" : "text-white"}`,
        size: 16
      }
    )
  ))))), /* @__PURE__ */ React.createElement(Block, { strong: true, inset: true, className: "p-2" }, /* @__PURE__ */ React.createElement(List, null, /* @__PURE__ */ React.createElement(
    ListInput,
    {
      style: {
        "--f7-input-font-size": "12px",
        "--f7-list-item-padding-horizontal": "0px",
        "--f7-list-item-padding-vertical": "0px"
      },
      className: "break-all text-xs",
      type: "textarea",
      placeholder: order_notes(),
      value: orderNotes,
      onChange: handleOrderNotesChange,
      maxlength: orderNotesMaxlength,
      resizable: true
    }
  )))), /* @__PURE__ */ React.createElement("div", { className: "text-xss absolute bottom-0.5 right-0 z-10 pr-5" }, orderNotes.length, "/", orderNotesMaxlength)), /* @__PURE__ */ React.createElement("div", { className: "text-secondary-red mb-2 mt-1 pr-4 text-right text-[12px]" }, purchase_limit_per_order_$number$({ number: maxQuantity })), z(selectDiscountPoints).with({ select: false }, () => /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement(List, { strongIos: true, dividersIos: true, className: "nilai nilai-background my-0 text-white" }, /* @__PURE__ */ React.createElement(ListItem, { name: "seleted-brand-airdrop-type", onClick: goToSelectDiscountPoints }, /* @__PURE__ */ React.createElement("div", { slot: "before-title", className: "w-full text-sm" }, /* @__PURE__ */ React.createElement("div", { className: "flex items-center justify-between" }, deduction(), /* @__PURE__ */ React.createElement("div", { className: "flex items-center" }, /* @__PURE__ */ React.createElement(Button, { className: "bg-secondary-red mr-1 text-white" }, unused_discount_points()), /* @__PURE__ */ React.createElement(Icon, { f7: "chevron_right", size: 16 })))))))).with({ select: true }, (item) => /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement(List, { strongIos: true, dividersIos: true, className: "nilai nilai-background my-0 text-white" }, /* @__PURE__ */ React.createElement(ListItem, { name: "seleted-brand-airdrop-type", onClick: goToSelectDiscountPoints }, /* @__PURE__ */ React.createElement("div", { slot: "before-title", className: "w-full text-sm" }, /* @__PURE__ */ React.createElement("div", { className: "flex items-center justify-between" }, /* @__PURE__ */ React.createElement("span", { className: "mr-2 flex-shrink-0" }, deduction()), /* @__PURE__ */ React.createElement(BlobImage, { className: "mr-1 h-6 w-6 rounded-full object-cover", bloburi: item.logo, alt: "" }), /* @__PURE__ */ React.createElement("div", { slot: "before-title", className: "w-full text-sm" }, /* @__PURE__ */ React.createElement("div", { className: "flex items-center justify-between" }, /* @__PURE__ */ React.createElement(
    AssetTypeName,
    {
      cssClass: "flex-shrink-0",
      assetType: item.assetType,
      chainName: item.chainName
    }
  ), /* @__PURE__ */ React.createElement("div", { className: "ml-2 flex items-center" }, /* @__PURE__ */ React.createElement("div", { className: "text-xss mr-1 text-right" }, checkSufficientDeduction() ? /* @__PURE__ */ React.createElement(
    "div",
    {
      className: "text-sm",
      dangerouslySetInnerHTML: {
        __html: need_to_consume_$consume$_to_deduction$deduction$({
          consumeCss: "text-secondary-green",
          consume: get_showAsset_balance(
            get_discount_consumption_asset_types_amount_info(detailObj.amount, {
              deductionRatio: detailObj.goodsDiscountbrandProportion,
              numberToPriceRatio: item.number,
              goodsQuantity: quantity
            }).discountedAmount
          ),
          deductionCss: "text-primary",
          deduction: price(
            get_discount_consumption_asset_types_amount_info(detailObj.amount, {
              deductionRatio: detailObj.goodsDiscountbrandProportion,
              numberToPriceRatio: item.number,
              goodsQuantity: quantity
            }).discountedDiff
          )
        })
      }
    }
  ) : /* @__PURE__ */ React.createElement("div", { className: "flex items-center" }, /* @__PURE__ */ React.createElement(Button, { className: "bg-secondary-red mr-1 text-white" }, insufficient_points_unable_to_deduct()))), /* @__PURE__ */ React.createElement(Icon, { f7: "chevron_right", className: "text-white", size: 16 })))))))))).otherwise(() => /* @__PURE__ */ React.createElement(React.Fragment, null)), /* @__PURE__ */ React.createElement("div", { className: "px-4 py-2 text-white" }, choose_to_give_away_rewards(), " :", /* @__PURE__ */ React.createElement("div", { className: "text-xss text-secondary-red" }, "* ", estimated_quantity_subject_to_actual_distribution())), /* @__PURE__ */ React.createElement("p", { className: "text-subtext flex items-center px-4 py-1 text-xs" }, /* @__PURE__ */ React.createElement(Icon, { f7: "arrowtriangle_down_fill", size: "12", className: "mr-1" }), platform_rewards()), platformAirdropList.length ? platformAirdropList.map((item, index) => {
    return /* @__PURE__ */ React.createElement("div", { key: index }, /* @__PURE__ */ React.createElement(List, { strongIos: true, dividersIos: true, className: "nilai nilai-background my-0" }, item.airdropType === "DP" ? /* @__PURE__ */ React.createElement(
      ListItem,
      {
        radio: true,
        name: "seleted-airdrop-type",
        checked: selectAirdrop?.airdropType === "DP",
        onChange: () => handleSelectAirdrop(item)
      },
      /* @__PURE__ */ React.createElement("img", { src: getDPImage(), className: "h-6 w-6", slot: "media" }),
      /* @__PURE__ */ React.createElement("div", { slot: "before-title", className: "text-sm" }, consumption_rewards())
    ) : /* @__PURE__ */ React.createElement(
      ListItem,
      {
        radio: true,
        name: "seleted-airdrop-type",
        checked: selectAirdrop?.airdropType === "assetType" && selectAirdrop.airdropContent.assetType === item.airdropContent.assetType,
        onChange: () => handleSelectAirdrop(item)
      },
      /* @__PURE__ */ React.createElement(
        "img",
        {
          src: item.iconUrl ? item.iconUrl : `./images/asset-logo/ccchain-${item.airdropContent.assetType.toLowerCase()}.webp`,
          className: "h-6 w-6 rounded-full",
          slot: "media"
        }
      ),
      /* @__PURE__ */ React.createElement("div", { slot: "before-title", className: "w-full text-sm" }, /* @__PURE__ */ React.createElement("div", { className: "flex items-center justify-between" }, i18nGetAssetTypeText(item.airdropContent.assetType), /* @__PURE__ */ React.createElement("span", { className: "text-primary mx-4" }, getRewardAmount(item.airdropContent, "nilaiProportion"), /* @__PURE__ */ React.createElement("span", { className: "text-xss ml-1 text-white" }, "x ", quantity))))
    )));
  }) : /* @__PURE__ */ React.createElement("div", { className: "my-2 h-8 text-center" }, /* @__PURE__ */ React.createElement(Preloader, null)), /* @__PURE__ */ React.createElement("p", { className: "text-subtext flex items-center px-4 py-1 text-xs" }, /* @__PURE__ */ React.createElement(Icon, { f7: "arrowtriangle_down_fill", size: "12", className: "mr-1" }), brand_rewards()), brandAirdropList.length ? brandAirdropList.map((item, index) => {
    return /* @__PURE__ */ React.createElement("div", { key: index }, /* @__PURE__ */ React.createElement(List, { strongIos: true, dividersIos: true, className: "nilai nilai-background my-0 text-white" }, /* @__PURE__ */ React.createElement(
      ListItem,
      {
        radio: true,
        name: "seleted-brand-airdrop-type",
        checked: selectBrandAirdrop?.assetType === item.assetType,
        onChange: () => setBrandSelectAirdrop(item)
      },
      /* @__PURE__ */ React.createElement(
        BlobImage,
        {
          className: "h-6 w-6 rounded-full object-cover",
          bloburi: item.logo,
          alt: "",
          slot: "media"
        }
      ),
      /* @__PURE__ */ React.createElement("div", { slot: "before-title", className: "w-full text-sm" }, /* @__PURE__ */ React.createElement("div", { className: "flex items-center justify-between" }, /* @__PURE__ */ React.createElement(AssetTypeName, { assetType: item.assetType, chainName: item.chainName }), /* @__PURE__ */ React.createElement("span", { className: "text-primary mx-4" }, getRewardAmount(item, "brandProportion"), /* @__PURE__ */ React.createElement("span", { className: "text-xss ml-1 text-white" }, "x ", quantity))))
    )));
  }) : /* @__PURE__ */ React.createElement("div", { className: "my-2 h-8 text-center" }, /* @__PURE__ */ React.createElement(Preloader, null)))), /* @__PURE__ */ React.createElement(AlertDialog, { open: openErrorDialog, onRequireClose: setOpenErrorDialog, onConfirmCallback: dialogCallBack }, errorText), /* @__PURE__ */ React.createElement(
    ConfirmDialog,
    {
      open: openUserPayPwdDialog,
      title: address_transaction_password(),
      confirmText: confirm(),
      onRequireClose: () => {
        setOpenUserPayPwdDialog(false);
      },
      className: clsx("dialog", nilaiDialogStyle.nilaiDialog),
      onCancelCallback: () => setInputUserPayPwd(""),
      onConfirmCallback: () => checkUserPayPwd()
    },
    /* @__PURE__ */ React.createElement(
      "input",
      {
        value: inputUserPayPwd,
        onChange: (e) => {
          setInputUserPayPwd(e.target.value);
        },
        placeholder: please_enter_the_address_transaction_password(),
        type: "password",
        className: "!bg-pop-background !rounded-3 !px-2 !py-1 text-center text-white"
      }
    )
  ), /* @__PURE__ */ React.createElement(
    AlertDialog,
    {
      open: openInputQuantityDialog,
      title: quantity_of_inputs(),
      confirmText: confirm(),
      onRequireClose: () => {
        setOpenInputQuantityDialog(false);
      },
      className: clsx("dialog", nilaiDialogStyle.nilaiDialog)
    },
    /* @__PURE__ */ React.createElement(
      "input",
      {
        value: inputQuantity,
        onChange: (e) => {
          const target = e.target;
          let newValue = target.value;
          newValue = newValue.replace(/[^0-9]/g, "");
          if (newValue) {
            let newQuantity = isNaN(+newValue) ? 1 : +newValue;
            if (newQuantity > maxQuantity) {
              newQuantity = maxQuantity;
            }
            if (newQuantity < 1) {
              newQuantity = 1;
            }
            setInputQuantity(newQuantity);
            setQuantity(newQuantity);
            return;
          }
          setInputQuantity(newValue);
        },
        type: "number",
        className: "!bg-pop-background !rounded-3 !mx-auto block !px-2 !py-1 text-center text-white"
      }
    )
  ));
});
const SelectedAddressCardView = ({ addressInfo, onClick }) => {
  return /* @__PURE__ */ React.createElement(CardContent, { className: "py-1" }, /* @__PURE__ */ React.createElement("div", { className: "flex items-center justify-between", onClick }, /* @__PURE__ */ React.createElement(AddressInfoView, { className: "flex-grow", info: addressInfo }), /* @__PURE__ */ React.createElement("div", { className: "ml-4 flex-shrink-0" }, /* @__PURE__ */ React.createElement(NiLaiIcon, { name: "modify", className: "icon-5" }))));
};
export {
  goodsOrderConfirmation_page as default
};
