import { dw as getDefaultExportFromCjs } from "./index-DCNl9Xz5.js";
import { B as Buffer } from "./index-CQT1PcgH.js";
import { c as createSHA256Sync } from "./sha256-VpXgtVg8.js";
var baseX;
var hasRequiredBaseX;
function requireBaseX() {
  if (hasRequiredBaseX) return baseX;
  hasRequiredBaseX = 1;
  function base(ALPHABET) {
    if (ALPHABET.length >= 255) {
      throw new TypeError("Alphabet too long");
    }
    var BASE_MAP = new Uint8Array(256);
    for (var j = 0; j < BASE_MAP.length; j++) {
      BASE_MAP[j] = 255;
    }
    for (var i = 0; i < ALPHABET.length; i++) {
      var x = ALPHABET.charAt(i);
      var xc = x.charCodeAt(0);
      if (BASE_MAP[xc] !== 255) {
        throw new TypeError(x + " is ambiguous");
      }
      BASE_MAP[xc] = i;
    }
    var BASE = ALPHABET.length;
    var LEADER = ALPHABET.charAt(0);
    var FACTOR = Math.log(BASE) / Math.log(256);
    var iFACTOR = Math.log(256) / Math.log(BASE);
    function encode2(source) {
      if (source instanceof Uint8Array) ;
      else if (ArrayBuffer.isView(source)) {
        source = new Uint8Array(
          source.buffer,
          source.byteOffset,
          source.byteLength
        );
      } else if (Array.isArray(source)) {
        source = Uint8Array.from(source);
      }
      if (!(source instanceof Uint8Array)) {
        throw new TypeError("Expected Uint8Array");
      }
      if (source.length === 0) {
        return "";
      }
      var zeroes = 0;
      var length = 0;
      var pbegin = 0;
      var pend = source.length;
      while (pbegin !== pend && source[pbegin] === 0) {
        pbegin++;
        zeroes++;
      }
      var size = (pend - pbegin) * iFACTOR + 1 >>> 0;
      var b58 = new Uint8Array(size);
      while (pbegin !== pend) {
        var carry = source[pbegin];
        var i2 = 0;
        for (var it1 = size - 1; (carry !== 0 || i2 < length) && it1 !== -1; it1--, i2++) {
          carry += 256 * b58[it1] >>> 0;
          b58[it1] = carry % BASE >>> 0;
          carry = carry / BASE >>> 0;
        }
        if (carry !== 0) {
          throw new Error("Non-zero carry");
        }
        length = i2;
        pbegin++;
      }
      var it2 = size - length;
      while (it2 !== size && b58[it2] === 0) {
        it2++;
      }
      var str = LEADER.repeat(zeroes);
      for (; it2 < size; ++it2) {
        str += ALPHABET.charAt(b58[it2]);
      }
      return str;
    }
    function decodeUnsafe2(source) {
      if (typeof source !== "string") {
        throw new TypeError("Expected String");
      }
      if (source.length === 0) {
        return new Uint8Array();
      }
      var psz = 0;
      var zeroes = 0;
      var length = 0;
      while (source[psz] === LEADER) {
        zeroes++;
        psz++;
      }
      var size = (source.length - psz) * FACTOR + 1 >>> 0;
      var b256 = new Uint8Array(size);
      while (source[psz]) {
        var carry = BASE_MAP[source.charCodeAt(psz)];
        if (carry === 255) {
          return;
        }
        var i2 = 0;
        for (var it3 = size - 1; (carry !== 0 || i2 < length) && it3 !== -1; it3--, i2++) {
          carry += BASE * b256[it3] >>> 0;
          b256[it3] = carry % 256 >>> 0;
          carry = carry / 256 >>> 0;
        }
        if (carry !== 0) {
          throw new Error("Non-zero carry");
        }
        length = i2;
        psz++;
      }
      var it4 = size - length;
      while (it4 !== size && b256[it4] === 0) {
        it4++;
      }
      var vch = new Uint8Array(zeroes + (size - it4));
      var j2 = zeroes;
      while (it4 !== size) {
        vch[j2++] = b256[it4++];
      }
      return vch;
    }
    function decode2(string) {
      var buffer = decodeUnsafe2(string);
      if (buffer) {
        return buffer;
      }
      throw new Error("Non-base" + BASE + " character");
    }
    return {
      encode: encode2,
      decodeUnsafe: decodeUnsafe2,
      decode: decode2
    };
  }
  baseX = base;
  return baseX;
}
var bs58;
var hasRequiredBs58;
function requireBs58() {
  if (hasRequiredBs58) return bs58;
  hasRequiredBs58 = 1;
  const basex = requireBaseX();
  const ALPHABET = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz";
  bs58 = basex(ALPHABET);
  return bs58;
}
var bs58Exports = requireBs58();
const bs58_cjs = /* @__PURE__ */ getDefaultExportFromCjs(bs58Exports);
const decode = bs58_cjs.decode;
const decodeUnsafe = bs58_cjs.decodeUnsafe;
const encode = bs58_cjs.encode;
const Bs58CheckFactory = (checksumFn) => {
  function encode$1(payload) {
    var checksum = checksumFn(payload);
    return encode(Buffer.concat([payload, checksum], payload.length + 4));
  }
  function decodeRaw(buffer) {
    var payload = buffer.slice(0, -4);
    var checksum = buffer.slice(-4);
    var newChecksum = checksumFn(payload);
    if (checksum[0] ^ newChecksum[0] | checksum[1] ^ newChecksum[1] | checksum[2] ^ newChecksum[2] | checksum[3] ^ newChecksum[3])
      return;
    return Buffer.from(payload);
  }
  function decodeUnsafe$1(string) {
    var buffer = decodeUnsafe(string);
    if (!buffer)
      return;
    return decodeRaw(buffer);
  }
  function decode$1(string) {
    var buffer = decode(string);
    var payload = decodeRaw(buffer);
    if (!payload)
      throw new Error("Invalid checksum");
    return payload;
  }
  return {
    encode: encode$1,
    decode: decode$1,
    decodeUnsafe: decodeUnsafe$1
  };
};
function sha256(buffer) {
  return Buffer.from(createSHA256Sync().update(buffer).digest());
}
function sha256x2(buffer) {
  return sha256(sha256(buffer));
}
const bs58check = Bs58CheckFactory(sha256x2);
export {
  bs58check as b
};
