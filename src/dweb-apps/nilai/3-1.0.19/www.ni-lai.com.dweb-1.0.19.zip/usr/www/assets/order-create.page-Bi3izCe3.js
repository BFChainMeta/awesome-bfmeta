import { d as definePage, R as React, P as Page, O as Navbar, B as Block } from "./index-DCNl9Xz5.js";
const orderCreate_page = definePage((args) => /* @__PURE__ */ React.createElement(Page, { name: "orderCreate" }, /* @__PURE__ */ React.createElement(Navbar, { title: "Order Create", backLink: true }), /* @__PURE__ */ React.createElement(Block, { strongIos: true, outlineIos: true }, "填写订单")));
export {
  orderCreate_page as default
};
