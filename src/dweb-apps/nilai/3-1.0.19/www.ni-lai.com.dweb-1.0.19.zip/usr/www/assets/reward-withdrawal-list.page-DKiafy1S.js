import { d as definePage, al as usePageQueryState, R as React, P as Page, O as Navbar, ct as withdrawal_list, af as SlideInDownListItem, ae as NoData, cu as withdrawal_number, cv as writeText, x as toast, cw as cardholder_name, cx as bank_card_number, ch as phone_number, cy as document_number, cz as opening_bank, cA as withdrawal_quantity, cB as withdrawal, co as successfully, cC as fail, F as userController, cD as copied_successfully } from "./index-DCNl9Xz5.js";
const rewardWithdrawalList_page = definePage((args) => {
  const dataPage = usePageQueryState([], 1, async (list, page) => {
    const { data, total } = await userController.withdrawalList(page, 20);
    list.push(...data);
    return {
      content: list,
      end: list.length >= total,
      nextPage: page + 1
    };
  });
  return /* @__PURE__ */ React.createElement(Page, { name: "reward-withdrawal-list", className: "bg-background", ...dataPage.f7PageProps }, /* @__PURE__ */ React.createElement(Navbar, { title: withdrawal_list(), color: "white", className: "text-white", backLink: true }), /* @__PURE__ */ React.createElement("div", { className: "pt-2" }, dataPage.render({
    listItem: (item, index) => {
      return /* @__PURE__ */ React.createElement(SlideInDownListItem, { group: dataPage, key: item.id, index }, /* @__PURE__ */ React.createElement(ExtractItem, { withdrawalInfo: item, ...args }));
    },
    listEmpty: () => /* @__PURE__ */ React.createElement(NoData, null)
  })));
});
const ExtractItem = ({ withdrawalInfo, f7router, ...props }) => {
  return /* @__PURE__ */ React.createElement("div", { className: "bg-pop-background rounded-4 mx-4 mb-3 flex items-center justify-between px-4 py-4 text-white" }, /* @__PURE__ */ React.createElement("div", { className: "text-subtext w-full text-center text-[12px]" }, /* @__PURE__ */ React.createElement("div", { className: "mb-1 flex items-center justify-between text-right" }, /* @__PURE__ */ React.createElement("div", { className: "text-primary text-left" }, withdrawal_number()), /* @__PURE__ */ React.createElement(
    "div",
    {
      className: "max-w-[66%] break-all text-white",
      onClick: async ($event) => {
        $event.stopPropagation();
        await writeText(withdrawalInfo.id);
        toast(copied_successfully());
      }
    },
    withdrawalInfo.id
  )), /* @__PURE__ */ React.createElement("div", { className: "mb-1 flex items-center justify-between text-right" }, /* @__PURE__ */ React.createElement("div", { className: "text-primary text-left" }, cardholder_name()), /* @__PURE__ */ React.createElement("div", { className: "max-w-[66%] text-white" }, withdrawalInfo.cardHolder)), /* @__PURE__ */ React.createElement("div", { className: "mb-1 flex items-center justify-between text-right" }, /* @__PURE__ */ React.createElement("div", { className: "text-primary text-left" }, bank_card_number()), /* @__PURE__ */ React.createElement("div", { className: "max-w-[66%] text-white" }, withdrawalInfo.cardNumber)), /* @__PURE__ */ React.createElement("div", { className: "mb-1 flex items-center justify-between text-right" }, /* @__PURE__ */ React.createElement("div", { className: "text-primary text-left" }, phone_number()), /* @__PURE__ */ React.createElement("div", { className: "max-w-[66%] text-white" }, withdrawalInfo.phoneNumber)), /* @__PURE__ */ React.createElement("div", { className: "mb-1 flex items-center justify-between text-right" }, /* @__PURE__ */ React.createElement("div", { className: "text-primary text-left" }, document_number()), /* @__PURE__ */ React.createElement("div", { className: "max-w-[66%] text-white" }, withdrawalInfo.idNumber)), /* @__PURE__ */ React.createElement("div", { className: "mb-1 flex items-center justify-between text-right" }, /* @__PURE__ */ React.createElement("div", { className: "text-primary text-left" }, opening_bank()), /* @__PURE__ */ React.createElement("div", { className: "max-w-[66%] text-white" }, withdrawalInfo.bankName)), /* @__PURE__ */ React.createElement("div", { className: "mb-1 flex items-center justify-between text-right" }, /* @__PURE__ */ React.createElement("div", { className: "text-primary text-left" }, withdrawal_quantity()), /* @__PURE__ */ React.createElement("div", { className: "max-w-[66%] text-white" }, (+withdrawalInfo.withdrawAmount * 0.01).toFixed(2))), /* @__PURE__ */ React.createElement("div", { className: "text-right" }, withdrawalInfo.status === 0 ? /* @__PURE__ */ React.createElement("span", null, withdrawal()) : withdrawalInfo.status === 1 ? /* @__PURE__ */ React.createElement("span", { className: "text-secondary-green" }, successfully()) : /* @__PURE__ */ React.createElement("span", { className: "text-secondary-red" }, fail()))));
};
export {
  rewardWithdrawalList_page as default
};
