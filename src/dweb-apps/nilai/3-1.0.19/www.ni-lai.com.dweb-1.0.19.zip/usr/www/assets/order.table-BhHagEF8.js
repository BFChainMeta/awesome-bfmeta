var GoodsOrderDiscountStatus = /* @__PURE__ */ ((GoodsOrderDiscountStatus2) => {
  GoodsOrderDiscountStatus2[GoodsOrderDiscountStatus2["init"] = 0] = "init";
  GoodsOrderDiscountStatus2[GoodsOrderDiscountStatus2["wait"] = 1] = "wait";
  GoodsOrderDiscountStatus2[GoodsOrderDiscountStatus2["fail"] = 2] = "fail";
  GoodsOrderDiscountStatus2[GoodsOrderDiscountStatus2["success"] = 3] = "success";
  GoodsOrderDiscountStatus2[GoodsOrderDiscountStatus2["refunding"] = 4] = "refunding";
  GoodsOrderDiscountStatus2[GoodsOrderDiscountStatus2["refundSuccessful"] = 5] = "refundSuccessful";
  return GoodsOrderDiscountStatus2;
})(GoodsOrderDiscountStatus || {});
export {
  GoodsOrderDiscountStatus as G
};
