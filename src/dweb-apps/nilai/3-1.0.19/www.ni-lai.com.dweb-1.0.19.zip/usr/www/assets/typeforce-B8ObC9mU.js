import { dw as getDefaultExportFromCjs } from "./index-DCNl9Xz5.js";
import { r as requireBuffer } from "./index-CQT1PcgH.js";
var errors = {};
var native;
var hasRequiredNative;
function requireNative() {
  if (hasRequiredNative) return native;
  hasRequiredNative = 1;
  var types = {
    Array: function(value) {
      return value !== null && value !== void 0 && value.constructor === Array;
    },
    Boolean: function(value) {
      return typeof value === "boolean";
    },
    Function: function(value) {
      return typeof value === "function";
    },
    Nil: function(value) {
      return value === void 0 || value === null;
    },
    Number: function(value) {
      return typeof value === "number";
    },
    Object: function(value) {
      return typeof value === "object";
    },
    String: function(value) {
      return typeof value === "string";
    },
    "": function() {
      return true;
    }
  };
  types.Null = types.Nil;
  for (var typeName in types) {
    types[typeName].toJSON = function(t) {
      return t;
    }.bind(null, typeName);
  }
  native = types;
  return native;
}
var hasRequiredErrors;
function requireErrors() {
  if (hasRequiredErrors) return errors;
  hasRequiredErrors = 1;
  var native2 = requireNative();
  function getTypeName(fn) {
    return fn.name || fn.toString().match(/function (.*?)\s*\(/)[1];
  }
  function getValueTypeName(value) {
    return native2.Nil(value) ? "" : getTypeName(value.constructor);
  }
  function getValue(value) {
    if (native2.Function(value)) return "";
    if (native2.String(value)) return JSON.stringify(value);
    if (value && native2.Object(value)) return "";
    return value;
  }
  function captureStackTrace(e, t) {
    if (Error.captureStackTrace) {
      Error.captureStackTrace(e, t);
    }
  }
  function tfJSON(type) {
    if (native2.Function(type))
      return type.toJSON ? type.toJSON() : getTypeName(type);
    if (native2.Array(type)) return "Array";
    if (type && native2.Object(type)) return "Object";
    return type !== void 0 ? type : "";
  }
  function tfErrorString(type, value, valueTypeName) {
    var valueJson = getValue(value);
    return "Expected " + tfJSON(type) + ", got" + (valueTypeName !== "" ? " " + valueTypeName : "") + (valueJson !== "" ? " " + valueJson : "");
  }
  function TfTypeError(type, value, valueTypeName) {
    valueTypeName = valueTypeName || getValueTypeName(value);
    this.message = tfErrorString(type, value, valueTypeName);
    captureStackTrace(this, TfTypeError);
    this.__type = type;
    this.__value = value;
    this.__valueTypeName = valueTypeName;
  }
  TfTypeError.prototype = Object.create(Error.prototype);
  TfTypeError.prototype.constructor = TfTypeError;
  function tfPropertyErrorString(type, label, name, value, valueTypeName) {
    var description = '" of type ';
    if (label === "key") description = '" with key type ';
    return tfErrorString(
      'property "' + tfJSON(name) + description + tfJSON(type),
      value,
      valueTypeName
    );
  }
  function TfPropertyTypeError(type, property, label, value, valueTypeName) {
    if (type) {
      valueTypeName = valueTypeName || getValueTypeName(value);
      this.message = tfPropertyErrorString(
        type,
        label,
        property,
        value,
        valueTypeName
      );
    } else {
      this.message = 'Unexpected property "' + property + '"';
    }
    captureStackTrace(this, TfTypeError);
    this.__label = label;
    this.__property = property;
    this.__type = type;
    this.__value = value;
    this.__valueTypeName = valueTypeName;
  }
  TfPropertyTypeError.prototype = Object.create(Error.prototype);
  TfPropertyTypeError.prototype.constructor = TfTypeError;
  function tfCustomError(expected, actual) {
    return new TfTypeError(expected, {}, actual);
  }
  function tfSubError(e, property, label) {
    if (e instanceof TfPropertyTypeError) {
      property = property + "." + e.__property;
      e = new TfPropertyTypeError(
        e.__type,
        property,
        e.__label,
        e.__value,
        e.__valueTypeName
      );
    } else if (e instanceof TfTypeError) {
      e = new TfPropertyTypeError(
        e.__type,
        property,
        label,
        e.__value,
        e.__valueTypeName
      );
    }
    captureStackTrace(e);
    return e;
  }
  errors.TfTypeError = TfTypeError;
  errors.TfPropertyTypeError = TfPropertyTypeError;
  errors.tfCustomError = tfCustomError;
  errors.tfSubError = tfSubError;
  errors.tfJSON = tfJSON;
  errors.getValueTypeName = getValueTypeName;
  return errors;
}
var extra;
var hasRequiredExtra;
function requireExtra() {
  if (hasRequiredExtra) return extra;
  hasRequiredExtra = 1;
  var NATIVE = requireNative();
  var ERRORS = requireErrors();
  var { Buffer } = requireBuffer();
  function _Buffer(value) {
    return Buffer.isBuffer(value);
  }
  function Hex(value) {
    return typeof value === "string" && /^([0-9a-f]{2})+$/i.test(value);
  }
  function _LengthN(type, length) {
    var name = type.toJSON();
    function Length(value) {
      if (!type(value)) return false;
      if (value.length === length) return true;
      throw ERRORS.tfCustomError(
        name + "(Length: " + length + ")",
        name + "(Length: " + value.length + ")"
      );
    }
    Length.toJSON = function() {
      return name;
    };
    return Length;
  }
  var _ArrayN = _LengthN.bind(null, NATIVE.Array);
  var _BufferN = _LengthN.bind(null, _Buffer);
  var _HexN = _LengthN.bind(null, Hex);
  var _StringN = _LengthN.bind(null, NATIVE.String);
  function Range(a, b, f) {
    f = f || NATIVE.Number;
    function _range(value, strict) {
      return f(value, strict) && value > a && value < b;
    }
    _range.toJSON = function() {
      return `${f.toJSON()} between [${a}, ${b}]`;
    };
    return _range;
  }
  var INT53_MAX = Math.pow(2, 53) - 1;
  function Finite(value) {
    return typeof value === "number" && isFinite(value);
  }
  function Int8(value) {
    return value << 24 >> 24 === value;
  }
  function Int16(value) {
    return value << 16 >> 16 === value;
  }
  function Int32(value) {
    return (value | 0) === value;
  }
  function Int53(value) {
    return typeof value === "number" && value >= -INT53_MAX && value <= INT53_MAX && Math.floor(value) === value;
  }
  function UInt8(value) {
    return (value & 255) === value;
  }
  function UInt16(value) {
    return (value & 65535) === value;
  }
  function UInt32(value) {
    return value >>> 0 === value;
  }
  function UInt53(value) {
    return typeof value === "number" && value >= 0 && value <= INT53_MAX && Math.floor(value) === value;
  }
  var types = {
    ArrayN: _ArrayN,
    Buffer: _Buffer,
    BufferN: _BufferN,
    Finite,
    Hex,
    HexN: _HexN,
    Int8,
    Int16,
    Int32,
    Int53,
    Range,
    StringN: _StringN,
    UInt8,
    UInt16,
    UInt32,
    UInt53
  };
  for (var typeName in types) {
    types[typeName].toJSON = function(t) {
      return t;
    }.bind(null, typeName);
  }
  extra = types;
  return extra;
}
var typeforce_1;
var hasRequiredTypeforce;
function requireTypeforce() {
  if (hasRequiredTypeforce) return typeforce_1;
  hasRequiredTypeforce = 1;
  var ERRORS = requireErrors();
  var NATIVE = requireNative();
  var tfJSON = ERRORS.tfJSON;
  var TfTypeError = ERRORS.TfTypeError;
  var TfPropertyTypeError = ERRORS.TfPropertyTypeError;
  var tfSubError = ERRORS.tfSubError;
  var getValueTypeName = ERRORS.getValueTypeName;
  var TYPES = {
    arrayOf: function arrayOf(type, options) {
      type = compile(type);
      options = options || {};
      function _arrayOf(array, strict) {
        if (!NATIVE.Array(array)) return false;
        if (NATIVE.Nil(array)) return false;
        if (options.minLength !== void 0 && array.length < options.minLength)
          return false;
        if (options.maxLength !== void 0 && array.length > options.maxLength)
          return false;
        if (options.length !== void 0 && array.length !== options.length)
          return false;
        return array.every(function(value, i) {
          try {
            return typeforce2(type, value, strict);
          } catch (e) {
            throw tfSubError(e, i);
          }
        });
      }
      _arrayOf.toJSON = function() {
        var str = "[" + tfJSON(type) + "]";
        if (options.length !== void 0) {
          str += "{" + options.length + "}";
        } else if (options.minLength !== void 0 || options.maxLength !== void 0) {
          str += "{" + (options.minLength === void 0 ? 0 : options.minLength) + "," + (options.maxLength === void 0 ? Infinity : options.maxLength) + "}";
        }
        return str;
      };
      return _arrayOf;
    },
    maybe: function maybe(type) {
      type = compile(type);
      function _maybe(value, strict) {
        return NATIVE.Nil(value) || type(value, strict, maybe);
      }
      _maybe.toJSON = function() {
        return "?" + tfJSON(type);
      };
      return _maybe;
    },
    map: function map(propertyType, propertyKeyType) {
      propertyType = compile(propertyType);
      if (propertyKeyType) propertyKeyType = compile(propertyKeyType);
      function _map(value, strict) {
        if (!NATIVE.Object(value)) return false;
        if (NATIVE.Nil(value)) return false;
        for (var propertyName in value) {
          try {
            if (propertyKeyType) {
              typeforce2(propertyKeyType, propertyName, strict);
            }
          } catch (e) {
            throw tfSubError(e, propertyName, "key");
          }
          try {
            var propertyValue = value[propertyName];
            typeforce2(propertyType, propertyValue, strict);
          } catch (e) {
            throw tfSubError(e, propertyName);
          }
        }
        return true;
      }
      if (propertyKeyType) {
        _map.toJSON = function() {
          return "{" + tfJSON(propertyKeyType) + ": " + tfJSON(propertyType) + "}";
        };
      } else {
        _map.toJSON = function() {
          return "{" + tfJSON(propertyType) + "}";
        };
      }
      return _map;
    },
    object: function object(uncompiled) {
      var type = {};
      for (var typePropertyName in uncompiled) {
        type[typePropertyName] = compile(uncompiled[typePropertyName]);
      }
      function _object(value, strict) {
        if (!NATIVE.Object(value)) return false;
        if (NATIVE.Nil(value)) return false;
        var propertyName;
        try {
          for (propertyName in type) {
            var propertyType = type[propertyName];
            var propertyValue = value[propertyName];
            typeforce2(propertyType, propertyValue, strict);
          }
        } catch (e) {
          throw tfSubError(e, propertyName);
        }
        if (strict) {
          for (propertyName in value) {
            if (type[propertyName]) continue;
            throw new TfPropertyTypeError(void 0, propertyName);
          }
        }
        return true;
      }
      _object.toJSON = function() {
        return tfJSON(type);
      };
      return _object;
    },
    anyOf: function anyOf() {
      var types = [].slice.call(arguments).map(compile);
      function _anyOf(value, strict) {
        return types.some(function(type) {
          try {
            return typeforce2(type, value, strict);
          } catch (e) {
            return false;
          }
        });
      }
      _anyOf.toJSON = function() {
        return types.map(tfJSON).join("|");
      };
      return _anyOf;
    },
    allOf: function allOf() {
      var types = [].slice.call(arguments).map(compile);
      function _allOf(value, strict) {
        return types.every(function(type) {
          try {
            return typeforce2(type, value, strict);
          } catch (e) {
            return false;
          }
        });
      }
      _allOf.toJSON = function() {
        return types.map(tfJSON).join(" & ");
      };
      return _allOf;
    },
    quacksLike: function quacksLike(type) {
      function _quacksLike(value) {
        return type === getValueTypeName(value);
      }
      _quacksLike.toJSON = function() {
        return type;
      };
      return _quacksLike;
    },
    tuple: function tuple() {
      var types = [].slice.call(arguments).map(compile);
      function _tuple(values, strict) {
        if (NATIVE.Nil(values)) return false;
        if (NATIVE.Nil(values.length)) return false;
        if (strict && values.length !== types.length) return false;
        return types.every(function(type, i) {
          try {
            return typeforce2(type, values[i], strict);
          } catch (e) {
            throw tfSubError(e, i);
          }
        });
      }
      _tuple.toJSON = function() {
        return "(" + types.map(tfJSON).join(", ") + ")";
      };
      return _tuple;
    },
    value: function value(expected) {
      function _value(actual) {
        return actual === expected;
      }
      _value.toJSON = function() {
        return expected;
      };
      return _value;
    }
  };
  TYPES.oneOf = TYPES.anyOf;
  function compile(type) {
    if (NATIVE.String(type)) {
      if (type[0] === "?") return TYPES.maybe(type.slice(1));
      return NATIVE[type] || TYPES.quacksLike(type);
    } else if (type && NATIVE.Object(type)) {
      if (NATIVE.Array(type)) {
        if (type.length !== 1)
          throw new TypeError(
            "Expected compile() parameter of type Array of length 1"
          );
        return TYPES.arrayOf(type[0]);
      }
      return TYPES.object(type);
    } else if (NATIVE.Function(type)) {
      return type;
    }
    return TYPES.value(type);
  }
  function typeforce2(type, value, strict, surrogate) {
    if (NATIVE.Function(type)) {
      if (type(value, strict)) return true;
      throw new TfTypeError(surrogate || type, value);
    }
    return typeforce2(compile(type), value, strict);
  }
  for (var typeName in NATIVE) {
    typeforce2[typeName] = NATIVE[typeName];
  }
  for (typeName in TYPES) {
    typeforce2[typeName] = TYPES[typeName];
  }
  var EXTRA = requireExtra();
  for (typeName in EXTRA) {
    typeforce2[typeName] = EXTRA[typeName];
  }
  typeforce2.compile = compile;
  typeforce2.TfTypeError = TfTypeError;
  typeforce2.TfPropertyTypeError = TfPropertyTypeError;
  typeforce_1 = typeforce2;
  return typeforce_1;
}
var typeforceExports = requireTypeforce();
const typeforce_cjs = /* @__PURE__ */ getDefaultExportFromCjs(typeforceExports);
const typeforce = typeforce_cjs;
export {
  typeforce as t
};
