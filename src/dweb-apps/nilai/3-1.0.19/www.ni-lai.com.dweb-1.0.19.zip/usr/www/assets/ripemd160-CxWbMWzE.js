import { c as createWasmPreparer } from "./WASMInterface-Ufpqlv9U.js";
const prepareRIPEMD160 = createWasmPreparer("ripemd160", 20);
const ripemd160 = async (data) => {
  return (await prepareRIPEMD160()).calculate(data);
};
const createRIPEMD160 = async () => {
  return createRIPEMD160Sync(await prepareRIPEMD160());
};
const createRIPEMD160Sync = (wasm = prepareRIPEMD160.wasm) => {
  wasm.init();
  const obj = {
    init: () => {
      wasm.init();
      return obj;
    },
    update: (data) => {
      wasm.update(data);
      return obj;
    },
    digest: (outputType) => wasm.digest(outputType),
    save: () => wasm.save(),
    load: (data) => {
      wasm.load(data);
      return obj;
    },
    blockSize: 64,
    digestSize: 20
  };
  return obj;
};
export {
  createRIPEMD160 as a,
  createRIPEMD160Sync as c,
  prepareRIPEMD160 as p,
  ripemd160 as r
};
