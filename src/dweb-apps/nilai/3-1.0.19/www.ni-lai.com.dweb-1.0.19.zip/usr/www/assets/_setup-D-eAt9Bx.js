import { p as prepareBs58check } from "./_setup-DoDAyg6x.js";
import "./sha256-VpXgtVg8.js";
import "./WASMInterface-Ufpqlv9U.js";
import "./index-DzX_QLg7.js";
import "./index-CQT1PcgH.js";
import "./index-DCNl9Xz5.js";
const prepareWif = async () => {
  await prepareBs58check();
};
const prepareEcpair = async () => {
  await prepareWif();
};
export {
  prepareEcpair
};
