import { p as prepareBs58check } from "./_setup-DoDAyg6x.js";
import { p as prepareRIPEMD160 } from "./ripemd160-CxWbMWzE.js";
import { p as prepareSHA1 } from "./sha1-CZKCE3aV.js";
import { p as prepareSHA256 } from "./sha256-VpXgtVg8.js";
import "./WASMInterface-Ufpqlv9U.js";
import "./index-DzX_QLg7.js";
import "./index-CQT1PcgH.js";
import "./index-DCNl9Xz5.js";
const prepareBitcoinLib = async () => {
  await prepareBs58check();
  await prepareRIPEMD160.prepare();
  await prepareSHA1.prepare();
  await prepareSHA256.prepare();
};
export {
  prepareBitcoinLib
};
