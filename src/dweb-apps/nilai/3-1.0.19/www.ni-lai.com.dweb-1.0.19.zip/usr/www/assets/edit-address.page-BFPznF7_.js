import { ce as __vitePreload, d as definePage, V as useFlow, r as reactExports, bh as f7, ah as confirm, R as React, P as Page, O as Navbar, c5 as shipping_address, ao as Card, a6 as List, az as ListInput, cf as consignee, cg as please_fill_in_the_recipients_name, a2 as Icon, ch as phone_number, ci as please_provide_the_recipients_mobile_phone_number, cj as select_province_city_district, ck as please_select_your_province_city_district, cl as detailed_address, cm as please_provide_a_detailed_address, cn as please_ensure_that_the_information_provided_is_accurate_to_avoid_being_unable_to_receive_the_goods, a as Button, aj as appUserInfoFlow, x as toast, F as userController, ak as updateLoginerUserInfo, co as successfully, cp as incorrect_phone_number_input } from "./index-DCNl9Xz5.js";
const loadChinaDivision = async () => {
  const chinaDivision2 = await __vitePreload(() => import("./china-division-CnY1vEnR.js"), true ? [] : void 0);
  if (typeof chinaDivision2.default === "string") {
    return JSON.parse(chinaDivision2.default);
  }
  return chinaDivision2.default;
};
const chinaDivision = await loadChinaDivision();
const editAddress_page = definePage((args) => {
  const [appUserInfo] = useFlow(appUserInfoFlow);
  const [isLoading, setIsLoading] = reactExports.useState(false);
  const [formData, setFormData] = reactExports.useState({
    name: args.name || "",
    address: args.address || "",
    phone: args.phone || "",
    area: args.area || ""
  });
  const load = async () => {
    if (isLoading) return;
    if (!formData.name) {
      toast(please_fill_in_the_recipients_name());
      return;
    }
    if (!formData.phone) {
      toast(please_provide_the_recipients_mobile_phone_number());
      return;
    }
    if (!formData.area) {
      toast(please_select_your_province_city_district());
      return;
    }
    if (!formData.address) {
      toast(please_provide_a_detailed_address());
      return;
    }
    try {
      setIsLoading(true);
      if (new RegExp(/^1[3|4|5|6|7|8|9][0-9]\d{8}$/).test(formData.phone)) {
        let force = false;
        if (formData.address !== args.address || formData.name !== args.name || formData.phone !== args.phone || formData.area !== args.area) {
          force = true;
          await userController.upsertShippingAddress({
            id: args.id || "",
            name: formData.name,
            address: formData.address,
            phone: formData.phone,
            area: formData.area
          });
        }
        await updateLoginerUserInfo(appUserInfo.address);
        args.f7router.back(void 0, { force });
        toast(successfully());
      } else {
        toast(incorrect_phone_number_input());
      }
    } catch (error) {
      console.error(error);
      toast(String(error));
    } finally {
      setIsLoading(false);
    }
  };
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };
  const pickerRef = reactExports.useRef(null);
  reactExports.useEffect(() => {
    const aborter = new AbortController();
    (async () => {
      const { provinces, cities, areas } = chinaDivision;
      const getCityData = (str) => cities.filter((city) => city.provinceCode === str || city.name == str).map((c) => ({ value: c.code, text: c.name }));
      const getAreaData = (str) => areas.filter((area) => area.cityCode === str || area.name === str).map((a) => ({ value: a.code, text: a.name }));
      const provinceData = provinces.map((p) => ({
        value: p.code,
        text: p.name
      }));
      const cityData = getCityData(provinceData[0].value);
      const areaData = getAreaData(cityData[0]?.value || "");
      pickerRef.current = f7.picker.create({
        inputEl: "#province-picker-input",
        rotateEffect: true,
        renderToolbar() {
          return `<div class="toolbar text-primary"><div class="toolbar-inner"><div class="left"></div><div class="right"><a  class="link sheet-close popover-close !text-primary">${confirm()}</a></div></div></div>`;
        },
        cols: [
          {
            textAlign: "center",
            cssClass: "w-1/3",
            values: provinceData.map((p) => p.value),
            displayValues: provinceData.map((p) => p.text),
            onChange(picker, value) {
              const cityList = getCityData(value);
              const firstCity = cityList[0]?.value || "";
              picker.cols[1].replaceValues && picker.cols[1].replaceValues(
                cityList.map((c) => c.value),
                cityList.map((c) => c.text)
              );
              const areaList = getAreaData(firstCity);
              picker.cols[2].replaceValues && picker.cols[2].replaceValues(
                areaList.map((a) => a.value),
                areaList.map((a) => a.text)
              );
            }
          },
          {
            textAlign: "center",
            cssClass: "w-1/3",
            values: cityData.map((p) => p.value),
            displayValues: cityData.map((p) => p.text),
            onChange(picker, value) {
              const newAreasList = getAreaData(value);
              picker.cols[2].replaceValues && picker.cols[2].replaceValues(
                newAreasList.map((a) => a.value),
                newAreasList.map((a) => a.text)
              );
            }
          },
          {
            textAlign: "center",
            cssClass: "w-1/3",
            values: areaData.map((p) => p.value),
            displayValues: areaData.map((p) => p.text)
          }
        ],
        on: {
          closed: (picker) => {
            const value = picker.value;
            const selectVale = [
              provinces.find((v) => v.code === value[0]),
              cities.find((v) => v.code === value[1]),
              areas.find((v) => v.code === value[2])
            ].map((item) => item?.name || "").join(" ");
            setFormData({ ...formData, area: selectVale });
          }
        }
      });
    })();
    return () => {
      pickerRef.current?.destroy();
      aborter.abort("cancel");
    };
  }, [formData]);
  return /* @__PURE__ */ React.createElement(Page, { name: "edit-address", className: "bg-background" }, /* @__PURE__ */ React.createElement(Navbar, { title: shipping_address(), backLink: true, color: "white", className: "text-white" }), /* @__PURE__ */ React.createElement(Card, { className: "bg-pop-background rounded-3" }, /* @__PURE__ */ React.createElement(List, { strongIos: true, outlineIos: true, dividersIos: true, form: true, formStoreData: true, id: "address-form " }, /* @__PURE__ */ React.createElement(
    ListInput,
    {
      type: "text",
      label: consignee(),
      placeholder: please_fill_in_the_recipients_name(),
      name: "name",
      value: formData.name,
      onInput: handleInputChange
    },
    /* @__PURE__ */ React.createElement(Icon, { f7: "person_alt_circle", slot: "media" })
  ), /* @__PURE__ */ React.createElement(
    ListInput,
    {
      type: "tel",
      label: phone_number(),
      placeholder: please_provide_the_recipients_mobile_phone_number(),
      name: "phone",
      value: formData.phone,
      onInput: handleInputChange
    },
    /* @__PURE__ */ React.createElement(Icon, { f7: "phone_circle", slot: "media" })
  ), /* @__PURE__ */ React.createElement(
    ListInput,
    {
      id: "province-picker-input",
      name: "area",
      label: select_province_city_district(),
      placeholder: please_select_your_province_city_district(),
      readonly: true,
      value: formData.area,
      onInput: handleInputChange
    },
    /* @__PURE__ */ React.createElement(Icon, { f7: "house", slot: "media" })
  ), /* @__PURE__ */ React.createElement(
    ListInput,
    {
      type: "textarea",
      label: detailed_address(),
      placeholder: please_provide_a_detailed_address(),
      name: "address",
      value: formData.address,
      onInput: handleInputChange,
      multiple: true,
      className: "pb-2"
    },
    /* @__PURE__ */ React.createElement(Icon, { f7: "location_circle", slot: "media" })
  ))), /* @__PURE__ */ React.createElement("div", { className: "text-secondary-red px-4 text-[10px]" }, "*", please_ensure_that_the_information_provided_is_accurate_to_avoid_being_unable_to_receive_the_goods()), /* @__PURE__ */ React.createElement("div", { className: "mt-10 w-full flex-shrink-0 px-5" }, /* @__PURE__ */ React.createElement(
    Button,
    {
      large: true,
      raised: true,
      fill: true,
      preloader: true,
      loading: isLoading,
      onClick: load,
      className: "bg-primary my-4 w-full rounded-full text-base font-bold text-black"
    },
    confirm()
  )));
});
export {
  editAddress_page as default
};
