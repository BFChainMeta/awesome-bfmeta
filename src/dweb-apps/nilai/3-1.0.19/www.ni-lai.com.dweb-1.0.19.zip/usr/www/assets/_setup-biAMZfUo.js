import { b as randomBytes, c as config, d as cacheCall } from "./index-CQT1PcgH.js";
import { t as throwError, i as init } from "./index-D4lo3-lM.js";
import "./index-DCNl9Xz5.js";
function get4RandomBytes() {
  return randomBytes(4);
}
function generateInt32() {
  const array = get4RandomBytes();
  return (array[0] << 3 * 8) + (array[1] << 2 * 8) + (array[2] << 1 * 8) + array[3];
}
async function instantiateWasm() {
  const wasmUrl = `${config.wasmBaseUrl}/tiny-secp256k1/secp256k1.wasm`;
  const data = await config.wasmLoader(wasmUrl);
  const module = await WebAssembly.instantiate(data, {
    "./validate_error.mjs": {
      throwError
    },
    "./rand.mjs": {
      generateInt32
    }
  });
  return module.instance.exports;
}
const prepareTinySecp256k1 = cacheCall(async () => {
  init(await instantiateWasm());
});
export {
  prepareTinySecp256k1
};
