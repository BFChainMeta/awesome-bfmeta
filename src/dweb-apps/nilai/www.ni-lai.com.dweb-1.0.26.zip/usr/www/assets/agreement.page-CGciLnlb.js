import{d as xe,M as be,r as O,R as C,P as me,O as we,Q as ye,S as A,T as Te,U as $e}from"./index-BRI03nc8.js";function H(){return{async:!1,breaks:!1,extensions:null,gfm:!0,hooks:null,pedantic:!1,renderer:null,silent:!1,tokenizer:null,walkTokens:null}}let R=H();function le(c){R=c}const I={exec:()=>null};function f(c,e=""){let t=typeof c=="string"?c:c.source;const n={replace:(s,i)=>{let r=typeof i=="string"?i:i.source;return r=r.replace(b.caret,"$1"),t=t.replace(s,r),n},getRegex:()=>new RegExp(t,e)};return n}const b={codeRemoveIndent:/^(?: {1,4}| {0,3}\t)/gm,outputLinkReplace:/\\([\[\]])/g,indentCodeCompensation:/^(\s+)(?:```)/,beginningSpace:/^\s+/,endingHash:/#$/,startingSpaceChar:/^ /,endingSpaceChar:/ $/,nonSpaceChar:/[^ ]/,newLineCharGlobal:/\n/g,tabCharGlobal:/\t/g,multipleSpaceGlobal:/\s+/g,blankLine:/^[ \t]*$/,doubleBlankLine:/\n[ \t]*\n[ \t]*$/,blockquoteStart:/^ {0,3}>/,blockquoteSetextReplace:/\n {0,3}((?:=+|-+) *)(?=\n|$)/g,blockquoteSetextReplace2:/^ {0,3}>[ \t]?/gm,listReplaceTabs:/^\t+/,listReplaceNesting:/^ {1,4}(?=( {4})*[^ ])/g,listIsTask:/^\[[ xX]\] /,listReplaceTask:/^\[[ xX]\] +/,anyLine:/\n.*\n/,hrefBrackets:/^<(.*)>$/,tableDelimiter:/[:|]/,tableAlignChars:/^\||\| *$/g,tableRowBlankLine:/\n[ \t]*$/,tableAlignRight:/^ *-+: *$/,tableAlignCenter:/^ *:-+: *$/,tableAlignLeft:/^ *:-+ *$/,startATag:/^<a /i,endATag:/^<\/a>/i,startPreScriptTag:/^<(pre|code|kbd|script)(\s|>)/i,endPreScriptTag:/^<\/(pre|code|kbd|script)(\s|>)/i,startAngleBracket:/^</,endAngleBracket:/>$/,pedanticHrefTitle:/^([^'"]*[^\s])\s+(['"])(.*)\2/,unicodeAlphaNumeric:/[\p{L}\p{N}]/u,escapeTest:/[&<>"']/,escapeReplace:/[&<>"']/g,escapeTestNoEncode:/[<>"']|&(?!(#\d{1,7}|#[Xx][a-fA-F0-9]{1,6}|\w+);)/,escapeReplaceNoEncode:/[<>"']|&(?!(#\d{1,7}|#[Xx][a-fA-F0-9]{1,6}|\w+);)/g,unescapeTest:/&(#(?:\d+)|(?:#x[0-9A-Fa-f]+)|(?:\w+));?/ig,caret:/(^|[^\[])\^/g,percentDecode:/%25/g,findPipe:/\|/g,splitPipe:/ \|/,slashPipe:/\\\|/g,carriageReturn:/\r\n|\r/g,spaceLine:/^ +$/gm,notSpaceStart:/^\S*/,endingNewline:/\n$/,listItemRegex:c=>new RegExp(`^( {0,3}${c})((?:[	 ][^\\n]*)?(?:\\n|$))`),nextBulletRegex:c=>new RegExp(`^ {0,${Math.min(3,c-1)}}(?:[*+-]|\\d{1,9}[.)])((?:[ 	][^\\n]*)?(?:\\n|$))`),hrRegex:c=>new RegExp(`^ {0,${Math.min(3,c-1)}}((?:- *){3,}|(?:_ *){3,}|(?:\\* *){3,})(?:\\n+|$)`),fencesBeginRegex:c=>new RegExp(`^ {0,${Math.min(3,c-1)}}(?:\`\`\`|~~~)`),headingBeginRegex:c=>new RegExp(`^ {0,${Math.min(3,c-1)}}#`),htmlBeginRegex:c=>new RegExp(`^ {0,${Math.min(3,c-1)}}<(?:[a-z].*>|!--)`,"i")},Re=/^(?:[ \t]*(?:\n|$))+/,Se=/^((?: {4}| {0,3}\t)[^\n]+(?:\n(?:[ \t]*(?:\n|$))*)?)+/,Ae=/^ {0,3}(`{3,}(?=[^`\n]*(?:\n|$))|~{3,})([^\n]*)(?:\n|$)(?:|([\s\S]*?)(?:\n|$))(?: {0,3}\1[~`]* *(?=\n|$)|$)/,P=/^ {0,3}((?:-[\t ]*){3,}|(?:_[ \t]*){3,}|(?:\*[ \t]*){3,})(?:\n+|$)/,ze=/^ {0,3}(#{1,6})(?=\s|$)(.*)(?:\n+|$)/,oe=/(?:[*+-]|\d{1,9}[.)])/,ae=f(/^(?!bull |blockCode|fences|blockquote|heading|html)((?:.|\n(?!\s*?\n|bull |blockCode|fences|blockquote|heading|html))+?)\n {0,3}(=+|-+) *(?:\n+|$)/).replace(/bull/g,oe).replace(/blockCode/g,/(?: {4}| {0,3}\t)/).replace(/fences/g,/ {0,3}(?:`{3,}|~{3,})/).replace(/blockquote/g,/ {0,3}>/).replace(/heading/g,/ {0,3}#{1,6}/).replace(/html/g,/ {0,3}<[^\n>]+>\n/).getRegex(),Q=/^([^\n]+(?:\n(?!hr|heading|lheading|blockquote|fences|list|html|table| +\n)[^\n]+)*)/,_e=/^[^\n]+/,G=/(?!\s*\])(?:\\.|[^\[\]\\])+/,Ie=f(/^ {0,3}\[(label)\]: *(?:\n[ \t]*)?([^<\s][^\s]*|<.*?>)(?:(?: +(?:\n[ \t]*)?| *\n[ \t]*)(title))? *(?:\n+|$)/).replace("label",G).replace("title",/(?:"(?:\\"?|[^"\\])*"|'[^'\n]*(?:\n[^'\n]+)*\n?'|\([^()]*\))/).getRegex(),Pe=f(/^( {0,3}bull)([ \t][^\n]+?)?(?:\n|$)/).replace(/bull/g,oe).getRegex(),Z="address|article|aside|base|basefont|blockquote|body|caption|center|col|colgroup|dd|details|dialog|dir|div|dl|dt|fieldset|figcaption|figure|footer|form|frame|frameset|h[1-6]|head|header|hr|html|iframe|legend|li|link|main|menu|menuitem|meta|nav|noframes|ol|optgroup|option|p|param|search|section|summary|table|tbody|td|tfoot|th|thead|title|tr|track|ul",U=/<!--(?:-?>|[\s\S]*?(?:-->|$))/,Ce=f("^ {0,3}(?:<(script|pre|style|textarea)[\\s>][\\s\\S]*?(?:</\\1>[^\\n]*\\n+|$)|comment[^\\n]*(\\n+|$)|<\\?[\\s\\S]*?(?:\\?>\\n*|$)|<![A-Z][\\s\\S]*?(?:>\\n*|$)|<!\\[CDATA\\[[\\s\\S]*?(?:\\]\\]>\\n*|$)|</?(tag)(?: +|\\n|/?>)[\\s\\S]*?(?:(?:\\n[ 	]*)+\\n|$)|<(?!script|pre|style|textarea)([a-z][\\w-]*)(?:attribute)*? */?>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n[ 	]*)+\\n|$)|</(?!script|pre|style|textarea)[a-z][\\w-]*\\s*>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n[ 	]*)+\\n|$))","i").replace("comment",U).replace("tag",Z).replace("attribute",/ +[a-zA-Z:_][\w.:-]*(?: *= *"[^"\n]*"| *= *'[^'\n]*'| *= *[^\s"'=<>`]+)?/).getRegex(),ce=f(Q).replace("hr",P).replace("heading"," {0,3}#{1,6}(?:\\s|$)").replace("|lheading","").replace("|table","").replace("blockquote"," {0,3}>").replace("fences"," {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list"," {0,3}(?:[*+-]|1[.)]) ").replace("html","</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag",Z).getRegex(),Le=f(/^( {0,3}> ?(paragraph|[^\n]*)(?:\n|$))+/).replace("paragraph",ce).getRegex(),F={blockquote:Le,code:Se,def:Ie,fences:Ae,heading:ze,hr:P,html:Ce,lheading:ae,list:Pe,newline:Re,paragraph:ce,table:I,text:_e},te=f("^ *([^\\n ].*)\\n {0,3}((?:\\| *)?:?-+:? *(?:\\| *:?-+:? *)*(?:\\| *)?)(?:\\n((?:(?! *\\n|hr|heading|blockquote|code|fences|list|html).*(?:\\n|$))*)\\n*|$)").replace("hr",P).replace("heading"," {0,3}#{1,6}(?:\\s|$)").replace("blockquote"," {0,3}>").replace("code","(?: {4}| {0,3}	)[^\\n]").replace("fences"," {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list"," {0,3}(?:[*+-]|1[.)]) ").replace("html","</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag",Z).getRegex(),Be={...F,table:te,paragraph:f(Q).replace("hr",P).replace("heading"," {0,3}#{1,6}(?:\\s|$)").replace("|lheading","").replace("table",te).replace("blockquote"," {0,3}>").replace("fences"," {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list"," {0,3}(?:[*+-]|1[.)]) ").replace("html","</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag",Z).getRegex()},Ee={...F,html:f(`^ *(?:comment *(?:\\n|\\s*$)|<(tag)[\\s\\S]+?</\\1> *(?:\\n{2,}|\\s*$)|<tag(?:"[^"]*"|'[^']*'|\\s[^'"/>\\s]*)*?/?> *(?:\\n{2,}|\\s*$))`).replace("comment",U).replace(/tag/g,"(?!(?:a|em|strong|small|s|cite|q|dfn|abbr|data|time|code|var|samp|kbd|sub|sup|i|b|u|mark|ruby|rt|rp|bdi|bdo|span|br|wbr|ins|del|img)\\b)\\w+(?!:|[^\\w\\s@]*@)\\b").getRegex(),def:/^ *\[([^\]]+)\]: *<?([^\s>]+)>?(?: +(["(][^\n]+[")]))? *(?:\n+|$)/,heading:/^(#{1,6})(.*)(?:\n+|$)/,fences:I,lheading:/^(.+?)\n {0,3}(=+|-+) *(?:\n+|$)/,paragraph:f(Q).replace("hr",P).replace("heading",` *#{1,6} *[^
]`).replace("lheading",ae).replace("|table","").replace("blockquote"," {0,3}>").replace("|fences","").replace("|list","").replace("|html","").replace("|tag","").getRegex()},ue=/^\\([!"#$%&'()*+,\-./:;<=>?@\[\]\\^_`{|}~])/,ve=/^(`+)([^`]|[^`][\s\S]*?[^`])\1(?!`)/,he=/^( {2,}|\\)\n(?!\s*$)/,qe=/^(`+|[^`])(?:(?= {2,}\n)|[\s\S]*?(?:(?=[\\<!\[`*_]|\b_|$)|[^ ](?= {2,}\n)))/,M=/[\p{P}\p{S}]/u,X=/[\s\p{P}\p{S}]/u,pe=/[^\s\p{P}\p{S}]/u,Ze=f(/^((?![*_])punctSpace)/,"u").replace(/punctSpace/g,X).getRegex(),Me=/\[[^[\]]*?\]\((?:\\.|[^\\\(\)]|\((?:\\.|[^\\\(\)])*\))*\)|`[^`]*?`|<[^<>]*?>/g,De=f(/^(?:\*+(?:((?!\*)punct)|[^\s*]))|^_+(?:((?!_)punct)|([^\s_]))/,"u").replace(/punct/g,M).getRegex(),Ne=f("^[^_*]*?__[^_*]*?\\*[^_*]*?(?=__)|[^*]+(?=[^*])|(?!\\*)punct(\\*+)(?=[\\s]|$)|notPunctSpace(\\*+)(?!\\*)(?=punctSpace|$)|(?!\\*)punctSpace(\\*+)(?=notPunctSpace)|[\\s](\\*+)(?!\\*)(?=punct)|(?!\\*)punct(\\*+)(?!\\*)(?=punct)|notPunctSpace(\\*+)(?=notPunctSpace)","gu").replace(/notPunctSpace/g,pe).replace(/punctSpace/g,X).replace(/punct/g,M).getRegex(),Oe=f("^[^_*]*?\\*\\*[^_*]*?_[^_*]*?(?=\\*\\*)|[^_]+(?=[^_])|(?!_)punct(_+)(?=[\\s]|$)|notPunctSpace(_+)(?!_)(?=punctSpace|$)|(?!_)punctSpace(_+)(?=notPunctSpace)|[\\s](_+)(?!_)(?=punct)|(?!_)punct(_+)(?!_)(?=punct)","gu").replace(/notPunctSpace/g,pe).replace(/punctSpace/g,X).replace(/punct/g,M).getRegex(),je=f(/\\(punct)/,"gu").replace(/punct/g,M).getRegex(),He=f(/^<(scheme:[^\s\x00-\x1f<>]*|email)>/).replace("scheme",/[a-zA-Z][a-zA-Z0-9+.-]{1,31}/).replace("email",/[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+(@)[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)+(?![-_])/).getRegex(),Qe=f(U).replace("(?:-->|$)","-->").getRegex(),Ge=f("^comment|^</[a-zA-Z][\\w:-]*\\s*>|^<[a-zA-Z][\\w-]*(?:attribute)*?\\s*/?>|^<\\?[\\s\\S]*?\\?>|^<![a-zA-Z]+\\s[\\s\\S]*?>|^<!\\[CDATA\\[[\\s\\S]*?\\]\\]>").replace("comment",Qe).replace("attribute",/\s+[a-zA-Z:_][\w.:-]*(?:\s*=\s*"[^"]*"|\s*=\s*'[^']*'|\s*=\s*[^\s"'=<>`]+)?/).getRegex(),E=/(?:\[(?:\\.|[^\[\]\\])*\]|\\.|`[^`]*`|[^\[\]\\`])*?/,Ue=f(/^!?\[(label)\]\(\s*(href)(?:\s+(title))?\s*\)/).replace("label",E).replace("href",/<(?:\\.|[^\n<>\\])+>|[^\s\x00-\x1f]*/).replace("title",/"(?:\\"?|[^"\\])*"|'(?:\\'?|[^'\\])*'|\((?:\\\)?|[^)\\])*\)/).getRegex(),ge=f(/^!?\[(label)\]\[(ref)\]/).replace("label",E).replace("ref",G).getRegex(),fe=f(/^!?\[(ref)\](?:\[\])?/).replace("ref",G).getRegex(),Fe=f("reflink|nolink(?!\\()","g").replace("reflink",ge).replace("nolink",fe).getRegex(),W={_backpedal:I,anyPunctuation:je,autolink:He,blockSkip:Me,br:he,code:ve,del:I,emStrongLDelim:De,emStrongRDelimAst:Ne,emStrongRDelimUnd:Oe,escape:ue,link:Ue,nolink:fe,punctuation:Ze,reflink:ge,reflinkSearch:Fe,tag:Ge,text:qe,url:I},Xe={...W,link:f(/^!?\[(label)\]\((.*?)\)/).replace("label",E).getRegex(),reflink:f(/^!?\[(label)\]\s*\[([^\]]*)\]/).replace("label",E).getRegex()},j={...W,escape:f(ue).replace("])","~|])").getRegex(),url:f(/^((?:ftp|https?):\/\/|www\.)(?:[a-zA-Z0-9\-]+\.?)+[^\s<]*|^email/,"i").replace("email",/[A-Za-z0-9._+-]+(@)[a-zA-Z0-9-_]+(?:\.[a-zA-Z0-9-_]*[a-zA-Z0-9])+(?![-_])/).getRegex(),_backpedal:/(?:[^?!.,:;*_'"~()&]+|\([^)]*\)|&(?![a-zA-Z0-9]+;$)|[?!.,:;*_'"~)]+(?!$))+/,del:/^(~~?)(?=[^\s~])((?:\\.|[^\\])*?(?:\\.|[^\s~\\]))\1(?=[^~]|$)/,text:/^([`~]+|[^`~])(?:(?= {2,}\n)|(?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)|[\s\S]*?(?:(?=[\\<!\[`*~_]|\b_|https?:\/\/|ftp:\/\/|www\.|$)|[^ ](?= {2,}\n)|[^a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-](?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)))/},We={...j,br:f(he).replace("{2,}","*").getRegex(),text:f(j.text).replace("\\b_","\\b_| {2,}\\n").replace(/\{2,\}/g,"*").getRegex()},L={normal:F,gfm:Be,pedantic:Ee},z={normal:W,gfm:j,breaks:We,pedantic:Xe},Je={"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"},ne=c=>Je[c];function T(c,e){if(e){if(b.escapeTest.test(c))return c.replace(b.escapeReplace,ne)}else if(b.escapeTestNoEncode.test(c))return c.replace(b.escapeReplaceNoEncode,ne);return c}function se(c){try{c=encodeURI(c).replace(b.percentDecode,"%")}catch{return null}return c}function re(c,e){const t=c.replace(b.findPipe,(i,r,l)=>{let o=!1,a=r;for(;--a>=0&&l[a]==="\\";)o=!o;return o?"|":" |"}),n=t.split(b.splitPipe);let s=0;if(n[0].trim()||n.shift(),n.length>0&&!n.at(-1)?.trim()&&n.pop(),e)if(n.length>e)n.splice(e);else for(;n.length<e;)n.push("");for(;s<n.length;s++)n[s]=n[s].trim().replace(b.slashPipe,"|");return n}function _(c,e,t){const n=c.length;if(n===0)return"";let s=0;for(;s<n;){const i=c.charAt(n-s-1);if(i===e&&!t)s++;else if(i!==e&&t)s++;else break}return c.slice(0,n-s)}function Ke(c,e){if(c.indexOf(e[1])===-1)return-1;let t=0;for(let n=0;n<c.length;n++)if(c[n]==="\\")n++;else if(c[n]===e[0])t++;else if(c[n]===e[1]&&(t--,t<0))return n;return-1}function ie(c,e,t,n,s){const i=e.href,r=e.title||null,l=c[1].replace(s.other.outputLinkReplace,"$1");if(c[0].charAt(0)!=="!"){n.state.inLink=!0;const o={type:"link",raw:t,href:i,title:r,text:l,tokens:n.inlineTokens(l)};return n.state.inLink=!1,o}return{type:"image",raw:t,href:i,title:r,text:l}}function Ve(c,e,t){const n=c.match(t.other.indentCodeCompensation);if(n===null)return e;const s=n[1];return e.split(`
`).map(i=>{const r=i.match(t.other.beginningSpace);if(r===null)return i;const[l]=r;return l.length>=s.length?i.slice(s.length):i}).join(`
`)}class v{options;rules;lexer;constructor(e){this.options=e||R}space(e){const t=this.rules.block.newline.exec(e);if(t&&t[0].length>0)return{type:"space",raw:t[0]}}code(e){const t=this.rules.block.code.exec(e);if(t){const n=t[0].replace(this.rules.other.codeRemoveIndent,"");return{type:"code",raw:t[0],codeBlockStyle:"indented",text:this.options.pedantic?n:_(n,`
`)}}}fences(e){const t=this.rules.block.fences.exec(e);if(t){const n=t[0],s=Ve(n,t[3]||"",this.rules);return{type:"code",raw:n,lang:t[2]?t[2].trim().replace(this.rules.inline.anyPunctuation,"$1"):t[2],text:s}}}heading(e){const t=this.rules.block.heading.exec(e);if(t){let n=t[2].trim();if(this.rules.other.endingHash.test(n)){const s=_(n,"#");(this.options.pedantic||!s||this.rules.other.endingSpaceChar.test(s))&&(n=s.trim())}return{type:"heading",raw:t[0],depth:t[1].length,text:n,tokens:this.lexer.inline(n)}}}hr(e){const t=this.rules.block.hr.exec(e);if(t)return{type:"hr",raw:_(t[0],`
`)}}blockquote(e){const t=this.rules.block.blockquote.exec(e);if(t){let n=_(t[0],`
`).split(`
`),s="",i="";const r=[];for(;n.length>0;){let l=!1;const o=[];let a;for(a=0;a<n.length;a++)if(this.rules.other.blockquoteStart.test(n[a]))o.push(n[a]),l=!0;else if(!l)o.push(n[a]);else break;n=n.slice(a);const u=o.join(`
`),h=u.replace(this.rules.other.blockquoteSetextReplace,`
    $1`).replace(this.rules.other.blockquoteSetextReplace2,"");s=s?`${s}
${u}`:u,i=i?`${i}
${h}`:h;const d=this.lexer.state.top;if(this.lexer.state.top=!0,this.lexer.blockTokens(h,r,!0),this.lexer.state.top=d,n.length===0)break;const p=r.at(-1);if(p?.type==="code")break;if(p?.type==="blockquote"){const x=p,k=x.raw+`
`+n.join(`
`),m=this.blockquote(k);r[r.length-1]=m,s=s.substring(0,s.length-x.raw.length)+m.raw,i=i.substring(0,i.length-x.text.length)+m.text;break}else if(p?.type==="list"){const x=p,k=x.raw+`
`+n.join(`
`),m=this.list(k);r[r.length-1]=m,s=s.substring(0,s.length-p.raw.length)+m.raw,i=i.substring(0,i.length-x.raw.length)+m.raw,n=k.substring(r.at(-1).raw.length).split(`
`);continue}}return{type:"blockquote",raw:s,tokens:r,text:i}}}list(e){let t=this.rules.block.list.exec(e);if(t){let n=t[1].trim();const s=n.length>1,i={type:"list",raw:"",ordered:s,start:s?+n.slice(0,-1):"",loose:!1,items:[]};n=s?`\\d{1,9}\\${n.slice(-1)}`:`\\${n}`,this.options.pedantic&&(n=s?n:"[*+-]");const r=this.rules.other.listItemRegex(n);let l=!1;for(;e;){let a=!1,u="",h="";if(!(t=r.exec(e))||this.rules.block.hr.test(e))break;u=t[0],e=e.substring(u.length);let d=t[2].split(`
`,1)[0].replace(this.rules.other.listReplaceTabs,D=>" ".repeat(3*D.length)),p=e.split(`
`,1)[0],x=!d.trim(),k=0;if(this.options.pedantic?(k=2,h=d.trimStart()):x?k=t[1].length+1:(k=t[2].search(this.rules.other.nonSpaceChar),k=k>4?1:k,h=d.slice(k),k+=t[1].length),x&&this.rules.other.blankLine.test(p)&&(u+=p+`
`,e=e.substring(p.length+1),a=!0),!a){const D=this.rules.other.nextBulletRegex(k),V=this.rules.other.hrRegex(k),Y=this.rules.other.fencesBeginRegex(k),ee=this.rules.other.headingBeginRegex(k),de=this.rules.other.htmlBeginRegex(k);for(;e;){const N=e.split(`
`,1)[0];let S;if(p=N,this.options.pedantic?(p=p.replace(this.rules.other.listReplaceNesting,"  "),S=p):S=p.replace(this.rules.other.tabCharGlobal,"    "),Y.test(p)||ee.test(p)||de.test(p)||D.test(p)||V.test(p))break;if(S.search(this.rules.other.nonSpaceChar)>=k||!p.trim())h+=`
`+S.slice(k);else{if(x||d.replace(this.rules.other.tabCharGlobal,"    ").search(this.rules.other.nonSpaceChar)>=4||Y.test(d)||ee.test(d)||V.test(d))break;h+=`
`+p}!x&&!p.trim()&&(x=!0),u+=N+`
`,e=e.substring(N.length+1),d=S.slice(k)}}i.loose||(l?i.loose=!0:this.rules.other.doubleBlankLine.test(u)&&(l=!0));let m=null,K;this.options.gfm&&(m=this.rules.other.listIsTask.exec(h),m&&(K=m[0]!=="[ ] ",h=h.replace(this.rules.other.listReplaceTask,""))),i.items.push({type:"list_item",raw:u,task:!!m,checked:K,loose:!1,text:h,tokens:[]}),i.raw+=u}const o=i.items.at(-1);if(o)o.raw=o.raw.trimEnd(),o.text=o.text.trimEnd();else return;i.raw=i.raw.trimEnd();for(let a=0;a<i.items.length;a++)if(this.lexer.state.top=!1,i.items[a].tokens=this.lexer.blockTokens(i.items[a].text,[]),!i.loose){const u=i.items[a].tokens.filter(d=>d.type==="space"),h=u.length>0&&u.some(d=>this.rules.other.anyLine.test(d.raw));i.loose=h}if(i.loose)for(let a=0;a<i.items.length;a++)i.items[a].loose=!0;return i}}html(e){const t=this.rules.block.html.exec(e);if(t)return{type:"html",block:!0,raw:t[0],pre:t[1]==="pre"||t[1]==="script"||t[1]==="style",text:t[0]}}def(e){const t=this.rules.block.def.exec(e);if(t){const n=t[1].toLowerCase().replace(this.rules.other.multipleSpaceGlobal," "),s=t[2]?t[2].replace(this.rules.other.hrefBrackets,"$1").replace(this.rules.inline.anyPunctuation,"$1"):"",i=t[3]?t[3].substring(1,t[3].length-1).replace(this.rules.inline.anyPunctuation,"$1"):t[3];return{type:"def",tag:n,raw:t[0],href:s,title:i}}}table(e){const t=this.rules.block.table.exec(e);if(!t||!this.rules.other.tableDelimiter.test(t[2]))return;const n=re(t[1]),s=t[2].replace(this.rules.other.tableAlignChars,"").split("|"),i=t[3]?.trim()?t[3].replace(this.rules.other.tableRowBlankLine,"").split(`
`):[],r={type:"table",raw:t[0],header:[],align:[],rows:[]};if(n.length===s.length){for(const l of s)this.rules.other.tableAlignRight.test(l)?r.align.push("right"):this.rules.other.tableAlignCenter.test(l)?r.align.push("center"):this.rules.other.tableAlignLeft.test(l)?r.align.push("left"):r.align.push(null);for(let l=0;l<n.length;l++)r.header.push({text:n[l],tokens:this.lexer.inline(n[l]),header:!0,align:r.align[l]});for(const l of i)r.rows.push(re(l,r.header.length).map((o,a)=>({text:o,tokens:this.lexer.inline(o),header:!1,align:r.align[a]})));return r}}lheading(e){const t=this.rules.block.lheading.exec(e);if(t)return{type:"heading",raw:t[0],depth:t[2].charAt(0)==="="?1:2,text:t[1],tokens:this.lexer.inline(t[1])}}paragraph(e){const t=this.rules.block.paragraph.exec(e);if(t){const n=t[1].charAt(t[1].length-1)===`
`?t[1].slice(0,-1):t[1];return{type:"paragraph",raw:t[0],text:n,tokens:this.lexer.inline(n)}}}text(e){const t=this.rules.block.text.exec(e);if(t)return{type:"text",raw:t[0],text:t[0],tokens:this.lexer.inline(t[0])}}escape(e){const t=this.rules.inline.escape.exec(e);if(t)return{type:"escape",raw:t[0],text:t[1]}}tag(e){const t=this.rules.inline.tag.exec(e);if(t)return!this.lexer.state.inLink&&this.rules.other.startATag.test(t[0])?this.lexer.state.inLink=!0:this.lexer.state.inLink&&this.rules.other.endATag.test(t[0])&&(this.lexer.state.inLink=!1),!this.lexer.state.inRawBlock&&this.rules.other.startPreScriptTag.test(t[0])?this.lexer.state.inRawBlock=!0:this.lexer.state.inRawBlock&&this.rules.other.endPreScriptTag.test(t[0])&&(this.lexer.state.inRawBlock=!1),{type:"html",raw:t[0],inLink:this.lexer.state.inLink,inRawBlock:this.lexer.state.inRawBlock,block:!1,text:t[0]}}link(e){const t=this.rules.inline.link.exec(e);if(t){const n=t[2].trim();if(!this.options.pedantic&&this.rules.other.startAngleBracket.test(n)){if(!this.rules.other.endAngleBracket.test(n))return;const r=_(n.slice(0,-1),"\\");if((n.length-r.length)%2===0)return}else{const r=Ke(t[2],"()");if(r>-1){const o=(t[0].indexOf("!")===0?5:4)+t[1].length+r;t[2]=t[2].substring(0,r),t[0]=t[0].substring(0,o).trim(),t[3]=""}}let s=t[2],i="";if(this.options.pedantic){const r=this.rules.other.pedanticHrefTitle.exec(s);r&&(s=r[1],i=r[3])}else i=t[3]?t[3].slice(1,-1):"";return s=s.trim(),this.rules.other.startAngleBracket.test(s)&&(this.options.pedantic&&!this.rules.other.endAngleBracket.test(n)?s=s.slice(1):s=s.slice(1,-1)),ie(t,{href:s&&s.replace(this.rules.inline.anyPunctuation,"$1"),title:i&&i.replace(this.rules.inline.anyPunctuation,"$1")},t[0],this.lexer,this.rules)}}reflink(e,t){let n;if((n=this.rules.inline.reflink.exec(e))||(n=this.rules.inline.nolink.exec(e))){const s=(n[2]||n[1]).replace(this.rules.other.multipleSpaceGlobal," "),i=t[s.toLowerCase()];if(!i){const r=n[0].charAt(0);return{type:"text",raw:r,text:r}}return ie(n,i,n[0],this.lexer,this.rules)}}emStrong(e,t,n=""){let s=this.rules.inline.emStrongLDelim.exec(e);if(!s||s[3]&&n.match(this.rules.other.unicodeAlphaNumeric))return;if(!(s[1]||s[2]||"")||!n||this.rules.inline.punctuation.exec(n)){const r=[...s[0]].length-1;let l,o,a=r,u=0;const h=s[0][0]==="*"?this.rules.inline.emStrongRDelimAst:this.rules.inline.emStrongRDelimUnd;for(h.lastIndex=0,t=t.slice(-1*e.length+r);(s=h.exec(t))!=null;){if(l=s[1]||s[2]||s[3]||s[4]||s[5]||s[6],!l)continue;if(o=[...l].length,s[3]||s[4]){a+=o;continue}else if((s[5]||s[6])&&r%3&&!((r+o)%3)){u+=o;continue}if(a-=o,a>0)continue;o=Math.min(o,o+a+u);const d=[...s[0]][0].length,p=e.slice(0,r+s.index+d+o);if(Math.min(r,o)%2){const k=p.slice(1,-1);return{type:"em",raw:p,text:k,tokens:this.lexer.inlineTokens(k)}}const x=p.slice(2,-2);return{type:"strong",raw:p,text:x,tokens:this.lexer.inlineTokens(x)}}}}codespan(e){const t=this.rules.inline.code.exec(e);if(t){let n=t[2].replace(this.rules.other.newLineCharGlobal," ");const s=this.rules.other.nonSpaceChar.test(n),i=this.rules.other.startingSpaceChar.test(n)&&this.rules.other.endingSpaceChar.test(n);return s&&i&&(n=n.substring(1,n.length-1)),{type:"codespan",raw:t[0],text:n}}}br(e){const t=this.rules.inline.br.exec(e);if(t)return{type:"br",raw:t[0]}}del(e){const t=this.rules.inline.del.exec(e);if(t)return{type:"del",raw:t[0],text:t[2],tokens:this.lexer.inlineTokens(t[2])}}autolink(e){const t=this.rules.inline.autolink.exec(e);if(t){let n,s;return t[2]==="@"?(n=t[1],s="mailto:"+n):(n=t[1],s=n),{type:"link",raw:t[0],text:n,href:s,tokens:[{type:"text",raw:n,text:n}]}}}url(e){let t;if(t=this.rules.inline.url.exec(e)){let n,s;if(t[2]==="@")n=t[0],s="mailto:"+n;else{let i;do i=t[0],t[0]=this.rules.inline._backpedal.exec(t[0])?.[0]??"";while(i!==t[0]);n=t[0],t[1]==="www."?s="http://"+t[0]:s=t[0]}return{type:"link",raw:t[0],text:n,href:s,tokens:[{type:"text",raw:n,text:n}]}}}inlineText(e){const t=this.rules.inline.text.exec(e);if(t){const n=this.lexer.state.inRawBlock;return{type:"text",raw:t[0],text:t[0],escaped:n}}}}class w{tokens;options;state;tokenizer;inlineQueue;constructor(e){this.tokens=[],this.tokens.links=Object.create(null),this.options=e||R,this.options.tokenizer=this.options.tokenizer||new v,this.tokenizer=this.options.tokenizer,this.tokenizer.options=this.options,this.tokenizer.lexer=this,this.inlineQueue=[],this.state={inLink:!1,inRawBlock:!1,top:!0};const t={other:b,block:L.normal,inline:z.normal};this.options.pedantic?(t.block=L.pedantic,t.inline=z.pedantic):this.options.gfm&&(t.block=L.gfm,this.options.breaks?t.inline=z.breaks:t.inline=z.gfm),this.tokenizer.rules=t}static get rules(){return{block:L,inline:z}}static lex(e,t){return new w(t).lex(e)}static lexInline(e,t){return new w(t).inlineTokens(e)}lex(e){e=e.replace(b.carriageReturn,`
`),this.blockTokens(e,this.tokens);for(let t=0;t<this.inlineQueue.length;t++){const n=this.inlineQueue[t];this.inlineTokens(n.src,n.tokens)}return this.inlineQueue=[],this.tokens}blockTokens(e,t=[],n=!1){for(this.options.pedantic&&(e=e.replace(b.tabCharGlobal,"    ").replace(b.spaceLine,""));e;){let s;if(this.options.extensions?.block?.some(r=>(s=r.call({lexer:this},e,t))?(e=e.substring(s.raw.length),t.push(s),!0):!1))continue;if(s=this.tokenizer.space(e)){e=e.substring(s.raw.length);const r=t.at(-1);s.raw.length===1&&r!==void 0?r.raw+=`
`:t.push(s);continue}if(s=this.tokenizer.code(e)){e=e.substring(s.raw.length);const r=t.at(-1);r?.type==="paragraph"||r?.type==="text"?(r.raw+=`
`+s.raw,r.text+=`
`+s.text,this.inlineQueue.at(-1).src=r.text):t.push(s);continue}if(s=this.tokenizer.fences(e)){e=e.substring(s.raw.length),t.push(s);continue}if(s=this.tokenizer.heading(e)){e=e.substring(s.raw.length),t.push(s);continue}if(s=this.tokenizer.hr(e)){e=e.substring(s.raw.length),t.push(s);continue}if(s=this.tokenizer.blockquote(e)){e=e.substring(s.raw.length),t.push(s);continue}if(s=this.tokenizer.list(e)){e=e.substring(s.raw.length),t.push(s);continue}if(s=this.tokenizer.html(e)){e=e.substring(s.raw.length),t.push(s);continue}if(s=this.tokenizer.def(e)){e=e.substring(s.raw.length);const r=t.at(-1);r?.type==="paragraph"||r?.type==="text"?(r.raw+=`
`+s.raw,r.text+=`
`+s.raw,this.inlineQueue.at(-1).src=r.text):this.tokens.links[s.tag]||(this.tokens.links[s.tag]={href:s.href,title:s.title});continue}if(s=this.tokenizer.table(e)){e=e.substring(s.raw.length),t.push(s);continue}if(s=this.tokenizer.lheading(e)){e=e.substring(s.raw.length),t.push(s);continue}let i=e;if(this.options.extensions?.startBlock){let r=1/0;const l=e.slice(1);let o;this.options.extensions.startBlock.forEach(a=>{o=a.call({lexer:this},l),typeof o=="number"&&o>=0&&(r=Math.min(r,o))}),r<1/0&&r>=0&&(i=e.substring(0,r+1))}if(this.state.top&&(s=this.tokenizer.paragraph(i))){const r=t.at(-1);n&&r?.type==="paragraph"?(r.raw+=`
`+s.raw,r.text+=`
`+s.text,this.inlineQueue.pop(),this.inlineQueue.at(-1).src=r.text):t.push(s),n=i.length!==e.length,e=e.substring(s.raw.length);continue}if(s=this.tokenizer.text(e)){e=e.substring(s.raw.length);const r=t.at(-1);r?.type==="text"?(r.raw+=`
`+s.raw,r.text+=`
`+s.text,this.inlineQueue.pop(),this.inlineQueue.at(-1).src=r.text):t.push(s);continue}if(e){const r="Infinite loop on byte: "+e.charCodeAt(0);if(this.options.silent){console.error(r);break}else throw new Error(r)}}return this.state.top=!0,t}inline(e,t=[]){return this.inlineQueue.push({src:e,tokens:t}),t}inlineTokens(e,t=[]){let n=e,s=null;if(this.tokens.links){const l=Object.keys(this.tokens.links);if(l.length>0)for(;(s=this.tokenizer.rules.inline.reflinkSearch.exec(n))!=null;)l.includes(s[0].slice(s[0].lastIndexOf("[")+1,-1))&&(n=n.slice(0,s.index)+"["+"a".repeat(s[0].length-2)+"]"+n.slice(this.tokenizer.rules.inline.reflinkSearch.lastIndex))}for(;(s=this.tokenizer.rules.inline.blockSkip.exec(n))!=null;)n=n.slice(0,s.index)+"["+"a".repeat(s[0].length-2)+"]"+n.slice(this.tokenizer.rules.inline.blockSkip.lastIndex);for(;(s=this.tokenizer.rules.inline.anyPunctuation.exec(n))!=null;)n=n.slice(0,s.index)+"++"+n.slice(this.tokenizer.rules.inline.anyPunctuation.lastIndex);let i=!1,r="";for(;e;){i||(r=""),i=!1;let l;if(this.options.extensions?.inline?.some(a=>(l=a.call({lexer:this},e,t))?(e=e.substring(l.raw.length),t.push(l),!0):!1))continue;if(l=this.tokenizer.escape(e)){e=e.substring(l.raw.length),t.push(l);continue}if(l=this.tokenizer.tag(e)){e=e.substring(l.raw.length),t.push(l);continue}if(l=this.tokenizer.link(e)){e=e.substring(l.raw.length),t.push(l);continue}if(l=this.tokenizer.reflink(e,this.tokens.links)){e=e.substring(l.raw.length);const a=t.at(-1);l.type==="text"&&a?.type==="text"?(a.raw+=l.raw,a.text+=l.text):t.push(l);continue}if(l=this.tokenizer.emStrong(e,n,r)){e=e.substring(l.raw.length),t.push(l);continue}if(l=this.tokenizer.codespan(e)){e=e.substring(l.raw.length),t.push(l);continue}if(l=this.tokenizer.br(e)){e=e.substring(l.raw.length),t.push(l);continue}if(l=this.tokenizer.del(e)){e=e.substring(l.raw.length),t.push(l);continue}if(l=this.tokenizer.autolink(e)){e=e.substring(l.raw.length),t.push(l);continue}if(!this.state.inLink&&(l=this.tokenizer.url(e))){e=e.substring(l.raw.length),t.push(l);continue}let o=e;if(this.options.extensions?.startInline){let a=1/0;const u=e.slice(1);let h;this.options.extensions.startInline.forEach(d=>{h=d.call({lexer:this},u),typeof h=="number"&&h>=0&&(a=Math.min(a,h))}),a<1/0&&a>=0&&(o=e.substring(0,a+1))}if(l=this.tokenizer.inlineText(o)){e=e.substring(l.raw.length),l.raw.slice(-1)!=="_"&&(r=l.raw.slice(-1)),i=!0;const a=t.at(-1);a?.type==="text"?(a.raw+=l.raw,a.text+=l.text):t.push(l);continue}if(e){const a="Infinite loop on byte: "+e.charCodeAt(0);if(this.options.silent){console.error(a);break}else throw new Error(a)}}return t}}class q{options;parser;constructor(e){this.options=e||R}space(e){return""}code({text:e,lang:t,escaped:n}){const s=(t||"").match(b.notSpaceStart)?.[0],i=e.replace(b.endingNewline,"")+`
`;return s?'<pre><code class="language-'+T(s)+'">'+(n?i:T(i,!0))+`</code></pre>
`:"<pre><code>"+(n?i:T(i,!0))+`</code></pre>
`}blockquote({tokens:e}){return`<blockquote>
${this.parser.parse(e)}</blockquote>
`}html({text:e}){return e}heading({tokens:e,depth:t}){return`<h${t}>${this.parser.parseInline(e)}</h${t}>
`}hr(e){return`<hr>
`}list(e){const t=e.ordered,n=e.start;let s="";for(let l=0;l<e.items.length;l++){const o=e.items[l];s+=this.listitem(o)}const i=t?"ol":"ul",r=t&&n!==1?' start="'+n+'"':"";return"<"+i+r+`>
`+s+"</"+i+`>
`}listitem(e){let t="";if(e.task){const n=this.checkbox({checked:!!e.checked});e.loose?e.tokens[0]?.type==="paragraph"?(e.tokens[0].text=n+" "+e.tokens[0].text,e.tokens[0].tokens&&e.tokens[0].tokens.length>0&&e.tokens[0].tokens[0].type==="text"&&(e.tokens[0].tokens[0].text=n+" "+T(e.tokens[0].tokens[0].text),e.tokens[0].tokens[0].escaped=!0)):e.tokens.unshift({type:"text",raw:n+" ",text:n+" ",escaped:!0}):t+=n+" "}return t+=this.parser.parse(e.tokens,!!e.loose),`<li>${t}</li>
`}checkbox({checked:e}){return"<input "+(e?'checked="" ':"")+'disabled="" type="checkbox">'}paragraph({tokens:e}){return`<p>${this.parser.parseInline(e)}</p>
`}table(e){let t="",n="";for(let i=0;i<e.header.length;i++)n+=this.tablecell(e.header[i]);t+=this.tablerow({text:n});let s="";for(let i=0;i<e.rows.length;i++){const r=e.rows[i];n="";for(let l=0;l<r.length;l++)n+=this.tablecell(r[l]);s+=this.tablerow({text:n})}return s&&(s=`<tbody>${s}</tbody>`),`<table>
<thead>
`+t+`</thead>
`+s+`</table>
`}tablerow({text:e}){return`<tr>
${e}</tr>
`}tablecell(e){const t=this.parser.parseInline(e.tokens),n=e.header?"th":"td";return(e.align?`<${n} align="${e.align}">`:`<${n}>`)+t+`</${n}>
`}strong({tokens:e}){return`<strong>${this.parser.parseInline(e)}</strong>`}em({tokens:e}){return`<em>${this.parser.parseInline(e)}</em>`}codespan({text:e}){return`<code>${T(e,!0)}</code>`}br(e){return"<br>"}del({tokens:e}){return`<del>${this.parser.parseInline(e)}</del>`}link({href:e,title:t,tokens:n}){const s=this.parser.parseInline(n),i=se(e);if(i===null)return s;e=i;let r='<a href="'+e+'"';return t&&(r+=' title="'+T(t)+'"'),r+=">"+s+"</a>",r}image({href:e,title:t,text:n}){const s=se(e);if(s===null)return T(n);e=s;let i=`<img src="${e}" alt="${n}"`;return t&&(i+=` title="${T(t)}"`),i+=">",i}text(e){return"tokens"in e&&e.tokens?this.parser.parseInline(e.tokens):"escaped"in e&&e.escaped?e.text:T(e.text)}}class J{strong({text:e}){return e}em({text:e}){return e}codespan({text:e}){return e}del({text:e}){return e}html({text:e}){return e}text({text:e}){return e}link({text:e}){return""+e}image({text:e}){return""+e}br(){return""}}class y{options;renderer;textRenderer;constructor(e){this.options=e||R,this.options.renderer=this.options.renderer||new q,this.renderer=this.options.renderer,this.renderer.options=this.options,this.renderer.parser=this,this.textRenderer=new J}static parse(e,t){return new y(t).parse(e)}static parseInline(e,t){return new y(t).parseInline(e)}parse(e,t=!0){let n="";for(let s=0;s<e.length;s++){const i=e[s];if(this.options.extensions?.renderers?.[i.type]){const l=i,o=this.options.extensions.renderers[l.type].call({parser:this},l);if(o!==!1||!["space","hr","heading","code","table","blockquote","list","html","paragraph","text"].includes(l.type)){n+=o||"";continue}}const r=i;switch(r.type){case"space":{n+=this.renderer.space(r);continue}case"hr":{n+=this.renderer.hr(r);continue}case"heading":{n+=this.renderer.heading(r);continue}case"code":{n+=this.renderer.code(r);continue}case"table":{n+=this.renderer.table(r);continue}case"blockquote":{n+=this.renderer.blockquote(r);continue}case"list":{n+=this.renderer.list(r);continue}case"html":{n+=this.renderer.html(r);continue}case"paragraph":{n+=this.renderer.paragraph(r);continue}case"text":{let l=r,o=this.renderer.text(l);for(;s+1<e.length&&e[s+1].type==="text";)l=e[++s],o+=`
`+this.renderer.text(l);t?n+=this.renderer.paragraph({type:"paragraph",raw:o,text:o,tokens:[{type:"text",raw:o,text:o,escaped:!0}]}):n+=o;continue}default:{const l='Token with "'+r.type+'" type was not found.';if(this.options.silent)return console.error(l),"";throw new Error(l)}}}return n}parseInline(e,t=this.renderer){let n="";for(let s=0;s<e.length;s++){const i=e[s];if(this.options.extensions?.renderers?.[i.type]){const l=this.options.extensions.renderers[i.type].call({parser:this},i);if(l!==!1||!["escape","html","link","image","strong","em","codespan","br","del","text"].includes(i.type)){n+=l||"";continue}}const r=i;switch(r.type){case"escape":{n+=t.text(r);break}case"html":{n+=t.html(r);break}case"link":{n+=t.link(r);break}case"image":{n+=t.image(r);break}case"strong":{n+=t.strong(r);break}case"em":{n+=t.em(r);break}case"codespan":{n+=t.codespan(r);break}case"br":{n+=t.br(r);break}case"del":{n+=t.del(r);break}case"text":{n+=t.text(r);break}default:{const l='Token with "'+r.type+'" type was not found.';if(this.options.silent)return console.error(l),"";throw new Error(l)}}}return n}}class B{options;block;constructor(e){this.options=e||R}static passThroughHooks=new Set(["preprocess","postprocess","processAllTokens"]);preprocess(e){return e}postprocess(e){return e}processAllTokens(e){return e}provideLexer(){return this.block?w.lex:w.lexInline}provideParser(){return this.block?y.parse:y.parseInline}}class ke{defaults=H();options=this.setOptions;parse=this.parseMarkdown(!0);parseInline=this.parseMarkdown(!1);Parser=y;Renderer=q;TextRenderer=J;Lexer=w;Tokenizer=v;Hooks=B;constructor(...e){this.use(...e)}walkTokens(e,t){let n=[];for(const s of e)switch(n=n.concat(t.call(this,s)),s.type){case"table":{const i=s;for(const r of i.header)n=n.concat(this.walkTokens(r.tokens,t));for(const r of i.rows)for(const l of r)n=n.concat(this.walkTokens(l.tokens,t));break}case"list":{const i=s;n=n.concat(this.walkTokens(i.items,t));break}default:{const i=s;this.defaults.extensions?.childTokens?.[i.type]?this.defaults.extensions.childTokens[i.type].forEach(r=>{const l=i[r].flat(1/0);n=n.concat(this.walkTokens(l,t))}):i.tokens&&(n=n.concat(this.walkTokens(i.tokens,t)))}}return n}use(...e){const t=this.defaults.extensions||{renderers:{},childTokens:{}};return e.forEach(n=>{const s={...n};if(s.async=this.defaults.async||s.async||!1,n.extensions&&(n.extensions.forEach(i=>{if(!i.name)throw new Error("extension name required");if("renderer"in i){const r=t.renderers[i.name];r?t.renderers[i.name]=function(...l){let o=i.renderer.apply(this,l);return o===!1&&(o=r.apply(this,l)),o}:t.renderers[i.name]=i.renderer}if("tokenizer"in i){if(!i.level||i.level!=="block"&&i.level!=="inline")throw new Error("extension level must be 'block' or 'inline'");const r=t[i.level];r?r.unshift(i.tokenizer):t[i.level]=[i.tokenizer],i.start&&(i.level==="block"?t.startBlock?t.startBlock.push(i.start):t.startBlock=[i.start]:i.level==="inline"&&(t.startInline?t.startInline.push(i.start):t.startInline=[i.start]))}"childTokens"in i&&i.childTokens&&(t.childTokens[i.name]=i.childTokens)}),s.extensions=t),n.renderer){const i=this.defaults.renderer||new q(this.defaults);for(const r in n.renderer){if(!(r in i))throw new Error(`renderer '${r}' does not exist`);if(["options","parser"].includes(r))continue;const l=r,o=n.renderer[l],a=i[l];i[l]=(...u)=>{let h=o.apply(i,u);return h===!1&&(h=a.apply(i,u)),h||""}}s.renderer=i}if(n.tokenizer){const i=this.defaults.tokenizer||new v(this.defaults);for(const r in n.tokenizer){if(!(r in i))throw new Error(`tokenizer '${r}' does not exist`);if(["options","rules","lexer"].includes(r))continue;const l=r,o=n.tokenizer[l],a=i[l];i[l]=(...u)=>{let h=o.apply(i,u);return h===!1&&(h=a.apply(i,u)),h}}s.tokenizer=i}if(n.hooks){const i=this.defaults.hooks||new B;for(const r in n.hooks){if(!(r in i))throw new Error(`hook '${r}' does not exist`);if(["options","block"].includes(r))continue;const l=r,o=n.hooks[l],a=i[l];B.passThroughHooks.has(r)?i[l]=u=>{if(this.defaults.async)return Promise.resolve(o.call(i,u)).then(d=>a.call(i,d));const h=o.call(i,u);return a.call(i,h)}:i[l]=(...u)=>{let h=o.apply(i,u);return h===!1&&(h=a.apply(i,u)),h}}s.hooks=i}if(n.walkTokens){const i=this.defaults.walkTokens,r=n.walkTokens;s.walkTokens=function(l){let o=[];return o.push(r.call(this,l)),i&&(o=o.concat(i.call(this,l))),o}}this.defaults={...this.defaults,...s}}),this}setOptions(e){return this.defaults={...this.defaults,...e},this}lexer(e,t){return w.lex(e,t??this.defaults)}parser(e,t){return y.parse(e,t??this.defaults)}parseMarkdown(e){return(n,s)=>{const i={...s},r={...this.defaults,...i},l=this.onError(!!r.silent,!!r.async);if(this.defaults.async===!0&&i.async===!1)return l(new Error("marked(): The async option was set to true by an extension. Remove async: false from the parse options object to return a Promise."));if(typeof n>"u"||n===null)return l(new Error("marked(): input parameter is undefined or null"));if(typeof n!="string")return l(new Error("marked(): input parameter is of type "+Object.prototype.toString.call(n)+", string expected"));r.hooks&&(r.hooks.options=r,r.hooks.block=e);const o=r.hooks?r.hooks.provideLexer():e?w.lex:w.lexInline,a=r.hooks?r.hooks.provideParser():e?y.parse:y.parseInline;if(r.async)return Promise.resolve(r.hooks?r.hooks.preprocess(n):n).then(u=>o(u,r)).then(u=>r.hooks?r.hooks.processAllTokens(u):u).then(u=>r.walkTokens?Promise.all(this.walkTokens(u,r.walkTokens)).then(()=>u):u).then(u=>a(u,r)).then(u=>r.hooks?r.hooks.postprocess(u):u).catch(l);try{r.hooks&&(n=r.hooks.preprocess(n));let u=o(n,r);r.hooks&&(u=r.hooks.processAllTokens(u)),r.walkTokens&&this.walkTokens(u,r.walkTokens);let h=a(u,r);return r.hooks&&(h=r.hooks.postprocess(h)),h}catch(u){return l(u)}}}onError(e,t){return n=>{if(n.message+=`
Please report this to https://github.com/markedjs/marked.`,e){const s="<p>An error occurred:</p><pre>"+T(n.message+"",!0)+"</pre>";return t?Promise.resolve(s):s}if(t)return Promise.reject(n);throw n}}}const $=new ke;function g(c,e){return $.parse(c,e)}g.options=g.setOptions=function(c){return $.setOptions(c),g.defaults=$.defaults,le(g.defaults),g};g.getDefaults=H;g.defaults=R;g.use=function(...c){return $.use(...c),g.defaults=$.defaults,le(g.defaults),g};g.walkTokens=function(c,e){return $.walkTokens(c,e)};g.parseInline=$.parseInline;g.Parser=y;g.parser=y.parse;g.Renderer=q;g.TextRenderer=J;g.Lexer=w;g.lexer=w.lex;g.Tokenizer=v;g.Hooks=B;g.parse=g;g.options;g.setOptions;g.use;g.walkTokens;g.parseInline;y.parse;w.lex;const Ye=`# 尼来用户服务协议

> 更新时间：2024 年 12 月 20 日

> 生效时间：2024 年 12 月 20 日



**欢迎您使用“尼来”软件与/或相关服务!**


“尼来”软件与/或相关服务，包括但不限于公司以不同版本和客户端的尼来应用程序向用户（又称“您”）提供的产品与服务。

《尼来用户服务协议》（以下简称“本协议”）是您与公司之间就您下载、安装、注册、登录、使用（以下统称“使用”）“尼来”软件与/或相关服务所订立的协议。

为了更好地为您提供服务，请您在开始使用“尼来”软件与/或相关服务之前，详细阅读、充分理解并遵守本协议，特别是涉及免除或者限制责任的条款、权利许可和信息使用的条款、法律适用和争议解决条款等。其中，<u>**免除或者限制责任条款等重要内容将以加粗形式提示您注意，请您留意并重点查阅。**</u> 

## **_【特别提示】_**

1. 本协议条款构成您使用尼来软件与/或相关服务之先决条件。您使用尼来软件与/或相关服务的行为（包括但不限于下载、安装、启动、浏览、注册、登录、发布、评论、使用），都表示您同意并接受本协议。
2. 如您不同意本协议，这将导致我们无法为您提供完整的产品和服务，您也可以选择停止使用。如您自主选择同意或使用“尼来”软件与/或相关服务，则视为您已充分理解本协议，并同意作为本协议的一方当事人接受本协议以及其他与“尼来”软件与/或相关服务相关的协议和规则（包括但不限于《尼来个人信息保护政策》）的约束。
3. 本协议所称“用户”，包括注册用户及未注册用户。凡未注册“尼来”软件与/或相关服务的用户，自下载安装“尼来”软件与/或相关服务时，即自动成为“尼来”软件与/或相关服务的“非注册用户”，须遵循除本协议用户注册规定以外的其他所有条款。
4. 若您是未满18周岁的未成年人，请确保在征得您的监护人同意后使用“尼来”软件与/或相关服务，并特别注意**未成年人使用条款**，否则请您不要使用“尼来”软件与/或相关服务。未成年人行使和履行本协议项下的权利和义务视为已获得了法定监护人的同意。

如您在阅读本协议过程中有任何疑惑或其他相关事宜的，您可以发送邮件至 service@tansocc.com 进行询问，我们会尽快为您做出解答。

## **本用户服务协议包含以下内容：**
1. <u>“尼来”软件与/或相关服务

2. 账户使用规则

3. 用户个人信息保护

4. 用户行为规范

5. 服务的变更、中断和终止

6. 违约处理

7. 免责声明

8. 未成年人保护

9. 通知

10. 管辖

11. 更新

12. 其他</u>


## “尼来”软件与/或相关服务

1. 您使用“尼来”软件与/或相关服务，可以通过预装、公司已授权的第三方下载等方式获取“尼来”客户端应用程序。<u>**若您并非从公司或经公司授权的第三方获取本软件的，公司无法保证非官方版本的“尼来”软件能够正常使用，您因此遭受的损失与公司无关。**</u> 
2. 公司可能为不同的终端设备开发不同的应用程序软件版本，您应当根据实际设备状况获取、下载、安装合适的版本。如您不再使用“尼来”软件与/或相关服务，您也可自行卸载相应的应用程序软件。
3. 为更好的提升用户体验及服务，公司将不定期提供“尼来”软件与/或相关服务的更新或改变（包括但不限于软件修改、升级、功能强化、开发新服务、软件替换等），您可根据需要自行选择是否更新相应的版本。
为保证“尼来”软件与/或相关服务安全、提升用户服务，在“尼来”软件与/或相关服务的部分或全部更新后，公司将在可行的情况下以适当的方式（包括但不限于系统提示、公告、站内信等）提示您，您有权选择接受更新后的版本；如您选择不作更新，“尼来”软件与/或相关服务的部分功能将受到限制或不能正常使用。
4. 除非得到公司事先明示书面授权，您不得以任何形式对“尼来”软件与/或相关服务进行包括但不限于改编、复制、传播、垂直搜索、镜像或交易等未经授权的访问或使用。
5. 您理解并同意，使用“尼来”软件与/或相关服务需自行准备与软件及相关服务有关的终端设备（如电脑、手机等），一旦您在终端设备中打开“尼来”软件或访问“尼来”的官方网站，即视为您同意使用“尼来”软件与/或相关服务。为充分实现“尼来”的全部功能，您可能需要将终端设备联网，您理解并同意由您承担所需要的费用（如流量费、上网费等）。
6. 您无需注册也可开始使用“尼来”软件与/或相关服务，但部分功能或服务可能会受到影响。同时，您也理解并同意，为使您更好地使用“尼来”软件与/或相关服务，保障您的账户安全，某些功能和/或某些单项服务项目（如发布服务、评论服务等）将要求您按照国家相关法律法规的规定，提供真实的身份信息注册并登录后方可使用。
7. 尼来向您提供包括但不限于如下内容：发布和分享文章、话题和视频等，在尼来可以实现发布文章、信息、视频、话题探讨、原创文章、DP等功能。除非本协议另有其他明示规定，尼来增加或强化目前本产品的任何新功能，包括推出的新产品，均受本协议的规范。

## 账户使用规则

1. “尼来”软件与/或相关服务为您提供了注册通道。账户密码是您使用尼来链上功能的唯一入口。尼来将根据您导入的地址密码为您分配一个唯一的地址账户。<u>**您理解并同意，您设置的账户密码是您用以登录并以注册用户身份使用“尼来”链上功能与/或相关服务的唯一入口。**</u> 
2. <u>**您理解并同意，尼来无法注销您已注册的地址。**</u> 
3. <u>**您理解并同意，无论您因何种原因导致的账户账户密码丢失或遗忘，“尼来”均无法找回或重置您丢失的账户密码。您需要自行承担账户密码丢失或遗忘的相应责任、风险和损失。请妥善保管好您的账户密码。**</u> 
4. <u>**您理解并同意，您所设置的账户不得违反国家法律法规及公司的相关规则，您的账户昵称、头像和签名等注册信息及其他个人信息中不得出现违法和不良信息，未经他人许可不得用他人名义（包括但不限于冒用他人姓名、昵称、头像或其他足以让人引起混淆的方式）开设账户，不得恶意注册“尼来”账户（包括但不限于频繁注册、批量注册账户等行为）。您在账户注册及使用过程中需遵守相关法律法规，不得实施任何侵害国家利益、损害其他公民合法权益，有害社会道德风尚的行为。**</u> 
5. 您有责任维护个人账户、登录密码、账户密码的安全性与保密性，并对您以注册账户名义所从事的活动承担全部法律责任，包括但不限于您在“尼来”软件与/或相关服务上进行的任何数据修改、言论发表、款项支付等操作行为可能引起的一切法律责任。您应高度重视对账户与密码的保密，在任何情况下不向他人透露账户及密码。
6. 在注册、使用和管理账户时，您应保证注册账户时填写的身份信息的真实性，请您在注册、管理账户时使用真实、准确、合法、有效的相关身份证明材料（包括但不限于您的联系电话等）。依照国家相关法律法规的规定，为使用“尼来”软件与/或相关服务的部分功能，您需要填写真实的身份信息，请您按照相关法律规定完成实名认证，并注意及时更新上述相关信息。若您提交的材料或提供的信息不准确、不真实、不规范，您可能无法使用“尼来”软件与/或相关服务或在使用过程中部分功能受到限制。

## 用户个人信息保护

1. 公司与您一同致力于您个人信息（即能够独立或与其他信息结合后识别您身份的信息）的保护，保护用户个人信息是公司的基本原则之一。在使用“尼来”软件与/或相关服务的过程中，您可能需要提供您的个人信息（包括但不限于电话号码等），以便公司向您提供更好的服务和相应的技术支持。我们将按照本协议及《尼来个人信息保护政策》的规定收集、使用、储存和分享您的个人信息。具体要求，请您参照《尼来个人信息保护政策》。

## 用户行为规范

### 用户行为要求

您应当对您使用“尼来”软件与/或相关服务的行为负责，除非法律允许或者经公司事先书面许可，您使用“尼来”软件与/或相关服务不得具有下列行为：
1. <u>**使用未经公司授权或许可的任何插件、外挂、系统或第三方工具对“尼来”软件与/或相关服务的正常运行进行干扰、破坏、修改或施加其他影响。**</u>
2. <u>**利用或针对“尼来”软件与/或相关服务进行任何危害计算机网络安全的行为，包括但不限于：**</u>
   - 非法侵入网络、干扰网络正常功能、窃取网络数据等危害网络安全的活动；
   - 提供专门用于从事侵入网络、干扰网络正常功能及防护措施、窃取网络数据等危害网络安全活动的程序、工具；
   - 明知他人从事危害网络安全的活动的，为其提供技术支持、广告推广等帮助；
   - 使用未经许可的数据或进入未经许可的服务器/账户；
   - 未经允许进入公众计算机网络或者他人计算机系统并删除、修改、增加存储信息；
   - 未经许可，企图探查、扫描、测试“尼来”系统或网络的弱点或其它实施破坏网络安全的行为；
   - 企图干涉、破坏“尼来”系统或网站的正常运行，故意传播恶意程序或病毒以及其他破坏干扰正常网络信息服务的行为；
   - 伪造TCP/IP数据包名称或部分名称；
   - 对“尼来”软件与/或相关服务进行反向工程、反向汇编、编译或者以其他方式尝试发现本软件的源代码；
   - 恶意注册“尼来”软件与/或相关服务的账户，包括但不限于频繁、批量注册账户；
   - 违反法律法规、本协议、公司的相关规则及侵犯他人合法权益的其他行为。
3. 如果公司有理由认为您的行为违反或可能违反上述约定的，公司可独立进行判断并处理，且有权在不事先通知的情况下终止向您提供服务，并追究相关法律责任。

### 内容规范

1. 您按规定完成实名认证后，可以享有尼来的更多服务。您和其他用户在“尼来”中因相关操作所形成的信息将会向其他用户展示。

2. <u>**您传播的内容信息应自觉遵守法律法规，遵守公共秩序，尊重社会公德、国家利益、公民合法权益、道德风尚和信息真实性等要求，否则公司有权立即采取相应处理措施。您同意并承诺不制作、复制、发布、传播下列信息：**</u> 
   - 反对中华人民共和国宪法确定的基本原则的；
   - 危害国家安全，泄露国家秘密的；
   - 颠覆国家政权，推翻社会主义制度、煽动分裂国家、破坏国家统一的；
   - 损害国家荣誉和利益的；
   - 宣扬恐怖主义、极端主义的；
   - 宣扬民族仇恨、民族歧视，破坏民族团结的；
   - 煽动地域歧视、地域仇恨的；
   - 破坏国家宗教政策，宣扬邪教和封建迷信的；
   - 编造、散布谣言、虚假信息，扰乱经济秩序和社会秩序、破坏社会稳定的；
   - 散布、传播淫秽、色情、赌博、暴力、凶杀、恐怖或者教唆犯罪的；
   - 侵害未成年人合法权益或者损害未成年人身心健康的；
   - 侮辱或者诽谤他人，侵害他人合法权益的；
   - 对他人进行暴力恐吓、威胁，实施人肉搜索的；
   - 涉及他人隐私、个人信息或资料的；
   - 散布污言秽语，损害社会公序良俗的；
   - 侵犯他人隐私权、名誉权、肖像权、知识产权等合法权益内容的；
   - 散布垃圾内容；
   - 使用本网站常用语言文字以外的其他语言文字评论的；
   - 与所评论的内容毫无关系的；
   - 所发表的内容毫无意义的，或刻意使用字符组合以逃避技术审核的；
   - 侵害未成年人合法权益或者损害未成年人身心健康的；
   - 未获他人允许，偷拍、偷录他人，侵害他人合法权利的；
   - 包含恐怖、暴力血腥、高危险性、危害表演者自身或他人身心健康内容的，包括但不限于以下情形：
      - 任何暴力和/或自残行为内容；
      - 任何威胁生命健康、利用刀具等危险器械表演的危及自身或他人人身及/或财产权利的内容；
      - 怂恿、诱导他人参与可能会造成人身伤害或导致死亡的危险或违法活动的内容；
   - 其他违反法律法规、政策及公序良俗、干扰“尼来”正常运营或侵犯其他用户或第三方合法权益内容的其他信息。

## 服务的变更、中断和终止

1. 您理解并同意，公司提供的“尼来”软件与/或相关服务是按照现有技术和条件所能达到的现状提供的。公司会尽最大努力向您提供服务，确保服务的连贯性和安全性。您理解并同意，公司不能随时预见和防范技术以及其他风险，包括但不限于不可抗力、网络原因、第三方服务瑕疵、第三方网站等原因可能导致的服务中断、不能正常使用“尼来”软件及服务以及其他的损失和风险。
2. 您理解并同意，公司为了整体服务运营、平台运营安全的需要，有权视具体情况决定服务/功能设置、范围，修改、中断、中止或终止“尼来”软件与/或相关服务。
3. 我们有权根据公司的业务发展情况，随时变更或终止部分或全部"尼来"产品与/或服务，无论是否通知用户，我们不因"尼来"产品与/或服务的变更或终止而对用户和任何第三人承担违约责任。

## <u>**知识产权** </u>

1. <u>**您理解并保证，您在使用尼来软件及"尼来"产品与/或服务时发布上传的文字、图片等均由您原创或已获得合法授权（含转授权且保证您有权将上述文字及图片等内容以本协议约定的方式授权给我们使用），不会侵犯第三方的合法权利。您通过"尼来"产品与/或服务由您独自上传、发布的任何内容的知识产权归您或原始著作权人所有。如果任何第三方就该等信息或内容提出关于知识产权的异议，我们有权根据实际情况删除相关的信息或内容，并且保留追究您相应法律责任的权利，您应当赔偿由此给我们或者任何第三方造成的一切损失。** </u>
2. <u>**您理解并同意，您通过"尼来"产品与/或服务上传的内容包括用于共建的内容（包括但不限于符号、文字、图片等），授予我们及我们的关联公司一项全球范围内的、永久性的、免费的、非独家的、不可撤销的、可转授权（通过多层次）的权利（包括除署名权外的所有权利，其中财产性权利包括但不限于复制权、翻译权、汇编权、信息网络传播权、改编权、制作衍生作品等），即我们可以对上述作品行使使用、发布、传播、复制、修改、改编、汇编、出版、翻译、传播、表演和展示等权利，并据以创作衍生作品的权利；将信息的全部或部分编入其他任何形式的作品、媒体、技术中的权利；对用户上传、发布的信息进行商业开发的权利；通过有线或无线网络向用户的计算机终端、移动通讯终端（包括但不限于便携式通讯设备如手机和智能平板电脑等）进行相关宣传和推广等服务。同时，您亦理解并同意，您对通过"尼来"产品与/或服务上传的内容，包括用于共建的内容，均不予行使保护作品完整权及修改权。** </u>
3. 除本章节1至2条款规定以外部分或"尼来"产品与/或服务中另行说明部分的内容（包括但不限于软件、技术、程序、网页、文字、图片、图像、图标、版面设计、电子文档等）之外，尼来软件及"尼来"产品与/或服务中的的知识产权，完整归属于公司所有；在我们提供"尼来"产品与/或服务过程中所依托的著作权（包括软件著作权）、专利权、商标权、商业秘密及其他知识产权归公司所有，或者由公司已从第三方权利人处获得合法使用的有效授权；以及，经我们创作、整理或以其他方式（如人工智能）生成内容的知识产权或其他相关权利归属于公司所有。未经公司事先书面许可，任何人不得擅自使用、大批量地监视、复制、传播、展示、镜像、上传、下载尼来软件及相关服务中的内容（也包括通过任何机器人、蜘蛛等程序或设备进行操作）。未经公司事先书面许可，除5.6条规定的情况外，您不得以任何营利性或非营利性的目的修改、复制、传播、传送、发行、转移、销售"尼来"产品与/或服务所使用的知识产权或创造、制作与其有关的派生产品或衍生品或者利用"尼来"产品与/或服务之部分或全部向任何第三方提供服务或产品。若您违反上述约定，我们有权追究您的责任，要求您赔偿由此给我们或其他人造成的损失，并有权视情况将上述行为移交相关政府部门处理。
4. <u>**用户在使用"尼来"产品与/或服务的过程中需要下载尼来软件的，对于该软件，我们仅授予用户可撤销的、有限的、不可转让及非排他性的许可。用户仅可为访问/使用产品、服务的目的而使用该软件。
您理解并同意，在未获得我们许可的情况下，用户不得修改、改编、翻译"尼来"产品与/或服务所使用的软件、技术、材料等，或者创作与之相关的派生作品或衍生品，不得通过反向工程、反编译、反汇编或其他类似行为获得其源代码，否则由此引起的一切法律后果由用户负责，我们将依法追究侵权方的法律责任。** </u>
5. 用户只能在本协议以及我们明示授权的范围内容使用"尼来"产品与/或服务。用户有权：
   - 上传用户原创或取得了合法授权（含转授权）的内容；
   - 对于"尼来"产品与/或服务中用户共建的内容在尼来平台上进行编辑、修改；
   - 在我们允许转发的数量范围内，将"尼来"产品与/或服务内容转发至第三方平台。具体内容以我们实际提供的服务为准。
6. <u>**用户不得擅自使用、删除、掩盖或更改我们的版权标识及声明、商标、专利、域名、网站名称、其他商业标识或其它权利声明。我们在"尼来"产品与/或服务中所呈现的所有设计图样以及其他图样、产品及服务名称、商业标识等，均为我们及/或其关联公司所享有的商标、标识。任何人不得使用、复制或用作其他用途。** </u>

## <u>**违约处理** </u>

1. <u>**针对您违反本协议或其他服务条款的行为，公司有权独立判断并视情况采取预先警示、拒绝发布、删除内容或评论等措施，对于因此而造成的后果，公司不承担任何责任。对涉嫌违反法律法规、涉嫌违法犯罪的行为，公司将保存有关记录，并有权依法向有关主管部门报告、配合有关主管部门调查、向公安机关报案等。对已删除内容公司有权不予恢复。** </u>
2. <u>**因您违反本协议或其他服务条款规定，引起第三方投诉或诉讼索赔的，您应当自行处理并承担全部可能由此引起的法律责任。因您的违法、侵权或违约等行为导致公司及其关联方、控制公司、继承公司向任何第三方赔偿或遭受国家机关处罚的，您还应足额赔偿公司及其关联方、控制公司、继承公司因此遭受的全部损失。** </u>
3. <u>**公司尊重并保护用户及他人的知识产权、名誉权、姓名权、隐私权等合法权益。您保证，在使用“尼来”软件与/或相关服务时上传的文字、图片、视频、音频、链接等不侵犯任何第三方的知识产权、名誉权、姓名权、隐私权等权利及合法权益。否则，公司有权在收到权利方或者相关方通知的情况下移除该涉嫌侵权内容。针对第三方提出的全部权利主张，您应自行处理并承担全部可能由此引起的法律责任；如因您的侵权行为导致公司及其关联方、控制公司、继承公司遭受损失的（包括经济、商誉等损失），您还应足额赔偿公司及其关联方、控制公司、继承公司遭受的全部损失。** </u>

## <u>**免责声明** </u>

1. <u>**公司有权利但无义务对用户发表的内容（包括文字、图片等其他形式）进行审查，同时不对用户发表的内容的正确性进行保证。用户在尼来发表的内容仅标明其个人观点及立场，不代表尼来的观点和立场。用户为内容的发表者，需对所发表内容负责。因其发表内容引发的一切纠纷，由该内容的发表者承担全部法律责任，尼来不承担任何法律责任。** </u>
2. <u>**您理解并同意，"尼来"产品与/或服务是按照现有技术和条件所能达到的现状提供的，我们无法保证所提供的"尼来"产品与/或服务毫无瑕疵。并且，我们不对提供的"尼来"产品与/或服务（含技术和信息）作出任何明示或暗示的承诺或保证，包括但不限于质量、稳定、正确、及时、完整、连贯等，但我们承诺将不断提升服务质量及服务水平，为用户提供更加优质的服务。** </u>
3. <u>**在所适用的法律允许的最大范围内，我们对如下事项不做担保：** </u>
   - <u>**由于技术本身的局限性，即便我们已经做出最大努力，我们不能保证我们的网站、移动客户端等软件与其他软硬件、系统完全兼容。如果出现不兼容的情况，用户可以向客服咨询，以获得技术支持。如果无法解决问题，用户可以选择卸载、停止使用"尼来"产品与/或服务；** </u>
   - <u>**因不可抗力，包括但不限于自然灾害(如洪水、地震、台风等)、黑客攻击、战争、罢工、系统不稳定、网络中断、用户关机、通信线路、第三方服务瑕疵、政府行为、尼来自身产品与/或服务规划/调整/改版等原因，均可能造成"尼来"产品与/或服务中断、数据丢失、账号内数据损毁以及其他的损失或风险。当出现不可抗力情况时，公司将努力在第一时间及时修复，但因不可抗力造成的暂停、中止、终止服务或造成的任何损失，公司在法律法规允许范围内免于承担责任。** </u>
   - <u>**对于从非公司指定官方途径下载、非公司指定途径获得的尼来软件，我们无法保证"尼来"产品与/或服务的一致性、安全性、稳定性，也不承担用户由此遭受的一切直接或间接损害赔偿等法律责任。** </u>
4. <u>**基于以下原因而造成的利润、商业信誉、资料损失或其他有形或无形损失，我们不承担任何直接、间接、附带、衍生或惩罚性的赔偿责任：** </u>
   - <u>**"尼来"产品与/或服务使用或无法使用；** </u>
   - <u>**经由"尼来"产品与/或服务取得的任何产品、资料或服务；** </u>
   - <u>**非因我们原因导致的用户资料遭到未授权的使用或修改。** </u>
5. <u>**您应妥善保管自己的登录密码，加强密码安全性，谨防密码泄露。非因公司的原因造成用户登录密码被泄露或被盗而遭受的任何损失，我们不予承担法律责任。** </u>
6. <u>**您理解并同意，我们为了整体运营的需要，有权自行决定进行业务与/或技术的变更、调整，有权视情况，随时修改或中断、中止或终止"尼来"产品与/或服务而无需通知用户，也无需向用户或第三方负责或承担任何赔偿责任，除非法律另有规定或双方另有约定。** </u>
7. <u>**根据法律法规的要求，我们有权依据其自身判断，对于用户任何违反或涉嫌违反中国法律、法规或本协议约定的内容，有权视情节进行删除、屏蔽或断开链接；并有权依据中国法律法规之规定保存有关信息并向相关政府部门进行报告。** </u>
8. <u>**不论是否可以预见，不论是源于何种形式的行为，我们不对由任何原因造成的特别的、间接的、惩罚性的、突发性的或有因果关系的损害或其他任何损害承担责任** </u>
9. <u>**公司依据本协议约定获得处理违法违规内容的权利，该权利不构成公司的义务或承诺，公司不能保证及时发现违法行为或进行相应处理。** </u>
10. <u>**您理解并同意，本协议旨在保障遵守国家法律法规、维护公序良俗，保护用户和他人合法权益，公司在能力范围内尽最大的努力按照相关法律法规进行判断，但并不保证公司判断完全与司法机关、行政机关的判断一致，如因此产生的后果您已经理解并同意自行承担。** </u>

## <u>**未成年人保护** </u>
1. <u>**若您是未满18周岁的未成年人，您应在监护人监护、指导并获得监护人同意的情况下，认真阅读并同意本协议后，方可使用“尼来”软件与/或相关服务。** </u>
2. <u>**公司重视对未成年人个人信息的保护，未成年用户在填写个人信息时，请加强个人保护意识并谨慎对待，并应在取得监护人的同意以及在监护人指导下正确使用“尼来”软件与/或相关服务。** </u>
3. <u>**未成年用户及其监护人理解并确认，如因您违反法律法规、本协议内容，则您及您的监护人应依照法律规定承担因此而可能导致的全部法律责任。** </u>
4. <u>**未成年人用户特别提示：** </u>
   - <u>**青少年使用“尼来”软件与/或相关服务应该在其监护人的监督指导下，在合理范围内正确学习使用网络，避免沉迷虚拟的网络空间，养成良好上网习惯。** </u>
   - <u>**青少年用户必须遵守《全国青少年网络文明公约》：** </u>
      - <u>**要善于网上学习，不浏览不良信息；** </u>
      - <u>**要诚实友好交流，不侮辱欺诈他人；** </u>
      - <u>**要增强自护意识，不随意约会网友；** </u>
      - <u>**要维护网络安全，不破坏网络秩序；** </u>
      - <u>**要有益身心健康，不沉溺虚拟时空。** </u>


## 通知
本协议条款和规则项下我们对于您所有的通知均可通过网页公告、站内通知、手机短信传送等方式进行，该等通知于发送之日视为已送达用户。

## 管辖
本协议条款和规则的签订、效力、履行、终止及其解释均适用中华人民共和国大陆地区法律（为本协议的目的，不包括香港特别行政区、澳门特别行政区及台湾地区的法律）。与本协议和规则相关的任何争议或纠纷，双方应协商友好解决；若不能协商解决，任何一方均有权将争议提交至人民法院诉讼解决。

## 更新
1. 我们有权根据业务需要，在必要时修改本协议条款和规则。本协议条款和规则更新及修改时，我们将通过第十一条约定的方式通知您，并将更新后的协议和规则在尼来网站和移动客户端上进行展示，供您查询。
2. 若本协议条款和规则更新后，您继续使用"尼来"产品与/或服务，即视为您已经理解并愿意接受变更后的协议条款和规则的约束。若您不同意任何本协议条款和规则的修改和更新的，请您不要继续使用"尼来"产品与/或服务。


## 其他

1. 本协议的成立、生效、履行、解释及争议的解决均应适用中华人民共和国法律。若本协议之任何规定因与中华人民共和国的法律抵触而无效或不可执行，则这些条款应在不违反法律的前提下尽可能按照接近本协议原条文目的之原则进行解释和使用，且本协议其它规定仍应具有完整的效力及效果。
2. 为给您提供更好的服务或国家法律法规、政策调整、技术条件、产品功能等变化需要，公司会适时对本协议进行修订，修订内容构成本协议的组成部分。本协议更新后，公司会在“尼来”发出更新版本，并在更新后的条款生效前以适当的方式提醒您更新的内容，以便您及时了解本协议的最新版本，您也可以在网站首页或软件设置页面查阅最新版本的协议条款。如您继续使用“尼来”软件与/或相关服务，即表示您已同意接受修订后的本协议内容。
您对修改后的协议条款存有异议的，请立即停止登录或使用“尼来”软件与/或相关服务。若您继续登录或使用“尼来”软件与/或相关服务，即视为您认可并接受修改后的协议条款。
3. 公司有权依“尼来”软件与/或相关服务或运营的需要单方决定，安排或指定其关联方、控制公司、继承公司或公司认可的第三方公司继续运营“尼来”软件。并且，就本协议项下涉及的某些服务，可能会由公司的关联方、控制公司、继承公司或公司认可的第三方公司向您提供。您知晓并同意接受相关服务内容，即视为接受相关权利义务关系亦受本协议约束。
4. 本协议中的标题仅为方便及阅读而设，并不影响本协议中任何规定的含义或解释。
5. 您和公司均是独立的主体，在任何情况下本协议不构成公司对您的任何形式的明示或暗示担保或条件，双方之间亦不构成代理、合伙、合营或雇佣关系。
`,et=`# 尼来个人信息保护政策

> 更新时间：2024 年 12 月 20 日

> 生效时间：2024 年 12 月 20 日

尼来（简称“我们”）深知个人信息对您的重要性，您的信任对我们非常重要，我们将按照《中华人民共和国网络安全法》和相关法律法规的规定并参照行业最佳实践保护您的个人信息及隐私安全。我们制定“尼来个人信息保护政策”(以下简称“本政策”)并特别提示：希望您在使用“尼来”软件与/或相关服务前仔细阅读并理解本政策，以便做出适当的选择。

## **_【特别提示】_**

1. **在您使用“尼来”产品与/或相关服务前，请仔细阅读并充分了解本政策。重点内容我们已采用粗体特别表示，希望您在阅读时特别关注。**  一旦您使用或继续使用“尼来”产品与/或相关服务，即表示您同意我们按照本政策处理您的相关个人信息。

2. **我们会遵循本政策收集、使用您的信息，但不会仅因您同意本政策而采用强制捆绑的方式一揽子收集个人信息。**

3. **只有在得到您确认同意的情况下，我们才会按照本政策处理您的个人信息；除非再次征得您的同意，我们不会将您的个人信息用于本政策未载明的其他目的。您可以选择不同意，我们将向您提供「仅浏览和搜索」功能，但这可能导致您无法完整使用“尼来”产品与/或相关服务及其功能。**
4. 当您使用相关功能或使用服务时，为实现功能、服务所必需，我们会收集、使用相关信息。除非是为实现业务功能或根据法律法规要求所必需的必要信息，您均可以拒绝提供且不影响其他功能或服务。

5. 您在向我们提供您的任何个人敏感信息前，请您考虑清楚该等提供是恰当的并且同意您的个人敏感信息可按本政策所述的目的和方式进行处理。

6. **若您是未满18周岁的未成年人，请确保在征得您的监护人同意后使用“尼来”产品与/或相关服务并向我们提供您的个人信息。**

7. 我们会采取互联网行业内标准的技术措施和管理措施来保证您的信息安全。

8. 摄像头（相机）、相册（存储）、活动记录权限，均不会默认开启，只有经过您的明示授权才会在为实现特定功能或服务时使用，您也可以撤回授权。特别需要指出的是，即使经过您的授权，我们获得了这些敏感权限，也不会在相关功能或服务不需要时收集您的信息。

如您在阅读本协议过程中有任何疑惑、意见或建议，您可以发送邮件至
service@tansocc.com 与我们联系。

下文将帮您详细了解我们如何收集、使用、存储与保护个人信息本政策与您使用我们的服务关系密切，我们建议您仔细阅读并理解本政策全部内容，作出您认为适当的选择。

## **本个人信息保护政策包含以下内容：**

1. 收集和使用个人信息

2. 数据使用过程中涉及的公开披露您的个人信息

3. 存储个人信息

4. 保护个人信息的安全

5. 管理您的个人信息

6. 未成年人条款

7. 政策的修订和通知

8. 联系我们

## 收集和使用个人信息

我们会秉承合法、正当、必要、公开的原则，出于本政策所述的以下目的，收集和使用您在使用“尼来”产品与/或相关服务过程中主动提供或因使用“尼来”产品与/或相关服务而产生的个人信息。

A. 为实现尼来的基本业务功能，我们需要向您收集和使用您的个人信息。以下将详细列出尼来的基本业务功能及为实现该功能所需收集和使用的个人信息，若您拒绝收集，则无法使用该功能。**提示您注意：如果您提供的是他人的个人信息，请您确保已取得相关主体的授权。**

B. 应用权限申请与使用情况说明

| 权限名称         |              权限功能说明              |                                               使用场景或目的                                                |
| ---------------- | :------------------------------------: | :---------------------------------------------------------------------------------------------------------: |
| 拍摄             |      使用拍摄照片、完成扫描二维码      |                                          发布内容、修改头像时使用                                           |
| 读取外置存储器   |    提供读取手机储存空间内数据的功能    |   允许App读取存储中的图片信息，主要用于帮助您发布信息，在本地记录崩溃日志信息（如有）、清理卸载残留等功能   |
| 写入外置存储器   |          提供写入外部储存功能          |                     允许App写入/下载/保存/修改/删除图片、文件、崩溃日志、卸载残留等信息                     |
| 网络             |            提供网络访问支持            |                                             下载应用，同步数据                                              |
| 读取手机状态     |        提供手机状态和出厂信息等        |           获取手机型号等信息，获取手机当前状态等信息，保障软件与服务的安全运行、运营的质量及效率            |
| 网络状态         |         读取手机当前的网络状态         |                         允许应用程序查看获取网络信息状态,如当前的网络连接是否有效。                         |
| 软件安装列表     |           读取已安装应用列表           |                           用于获取APP市场最新的APP应用版本，提示您及时更新本APP。                           |
| 手机号码         |         获取当前设备的手机号码         | 用于校验用户信息，为账号提供安全保障；作为账户密码自动生成的传入参数之一，在App注册时用于自动生成账户密码。 |
| 通知             |                系统通知                |                                   用于APP相关消息推送，避免错过重要消息。                                   |
| 麦克风权限       |         允许使用麦克风进行录音         |                    作为账户密码自动生成的传入参数之一，在App注册时用于自动生成账户密码。                    |
| 模糊地址位置权限 | 访问大概的位置源，以确定手机的大概位置 |                    作为账户密码自动生成的传入参数之一，在App注册时用于自动生成账户密码。                    |
| 精准地址位置权限 | 访问精准的位置源，以确定手机的精准位置 |                    作为账户密码自动生成的传入参数之一，在App注册时用于自动生成账户密码。                    |
| 传感器数据权限   |      访问传感器数据(当手机支持时)      |                    作为账户密码自动生成的传入参数之一，在App注册时用于自动生成账户密码。                    |

### 注册、登录、认证、注销

#### 注册、登录账户

1. 在您访问尼来时，需要注册成为平台用户后才能使用服务。

2. **当您注册尼来账号时，根据我国法律法规及出于安全保障目的，如注册不成功，也无法使用尼来产品与/或相关服务的相关功能。**

</u>

3. <u>**成功登录后，若想要使用“尼来”产品与/或相关服务的全部功能，您还需要先登录或者绑定您的地址。**</u>

4. 为了保障功能或服务的一致性，我们可能会在客户端对授权、登录的帐号与设备重新进行校验。

5. 无论注册还是登录，您都必须提供上述信息并同意用户服务协议和本政策后，您才可以使用除「浏览和搜索」功能外的“尼来”产品与/或相关服务的其他功能。

#### 认证

1. 在你使用身份认证的功能或相关服务所需时，根据相关法律法规，**我们可能收集你的真实身份信息（真实姓名、身份证号码、电话号码等）以完成实名验证**。 部分信息属于个人敏感信息，你可以拒绝提供，如果拒绝提供你将可能无法获得相关服务，但不影响其他功能与服务的正常使用。

### 运营与安全保障

我们致力于为您提供安全、可信的产品与使用环境，提供优质而可靠的服务与信息是我们的核心目标。为了维护我们服务的正常运行并保护您或其他用户或公众的合法利益免受损失，我们会收集用于维护产品或服务安全稳定运行的必要信息。

#### 设备信息

为了保障软件与服务的安全运行、运营的质量及效率，我们会自动收集您的设备信息，如设备型号、操作系统版本号、设备标识符（Android如IMEI、AndroidID、OAID、IMSI、ICCID、MEID；不同的标识符在有效期、是否可由用户重置以及获取方式方面会有所不同）、软件版本号、服务日志。我们可能会将您的设备信息或电话号码与您的尼来帐号相关联，以便我们能在这些设备上为您提供一致的服务。

#### 日志信息

1. 当您使用“尼来”产品与/或相关服务时，我们会自动收集您使用“尼来”产品与/或相关服务的详细情况，并作为网络日志进行保存，包括您对“尼来”产品与/或相关服务的使用情况、IP地址、所访问服务的URL、浏览器类型和使用的语言、下载、安装或使用移动应用和软件的信息以及访问服务的日期、时间、时长等，以便我们统计产品与/或服务的使用情况、分析数据并记录您对相应内容的收藏情况。
2. 为了预防恶意程序、提升运营质量及效率、保障帐号安全，我们会收集安装的应用信息或正在运行的进程信息、应用程序的总体运行、使用情况与频率、应用崩溃情况、总体安装使用情况、性能数据、应用来源。

### 收集、使用个人信息目的变更

请您了解，随着我们业务的发展，可能会对“尼来”产品与/或相关服务有所调整变化。原则上，当新功能或服务与我们当前提供的功能或服务相关时，收集与使用的个人信息将与原处理目的具有直接或合理关联。在与原处理目的无直接或合理关联的场景下，我们收集、使用您的个人信息，会再次按照法律法规及国家标准的要求以页面提示、交互流程、协议确认方式另行向您进行告知说明，并征得您的同意。

### 征得授权同意的例外

请您理解，在下列情形中，根据法律法规及相关国家标准，我们收集和使用您的个人信息不必事先征得您的授权同意：

- 与我们履行法律法规规定的义务相关的；
- 与国家安全、国防安全直接相关的；
- 与公共安全、公共卫生、重大公共利益直接相关的；
- 与刑事侦查、起诉、审判和判决执行等直接相关的；
- 出于维护您或他人的生命、财产等重大合法权益但又很难得到本人授权同意的；
- 您自行向社会公众公开的个人信息；
- 根据个人信息主体要求签订和履行合同所必需的；
- 从合法公开披露的信息中收集的您的个人信息的，如合法的新闻报道、政府信息公开等渠道；
- 用于维护软件及相关服务的安全稳定运行所必需的，例如发现、处置软件及相关服务的故障；
- 为开展合法的新闻报道所必需的；
- 为学术研究机构，基于公共利益开展统计或学术研究所必要，且对外提供学术研究或描述的结果时，对结果中所包含的个人信息进行去标识化处理的；
- 法律法规规定的其他情形。

特别提示您注意，如信息无法单独或结合其他信息识别到您的个人身份，其不属于法律意义上您的个人信息；当您的信息可以单独或结合其他信息识别到您的个人身份时或我们将无法与任何特定个人信息建立联系的数据与其他您的个人信息结合使用时，这些信息在结合使用期间，将作为您的个人信息按照本政策处理与保护。

B.为了给您提供更好的使用体验，我们会为您提供下述扩展业务功能，在您使用此类功能时，我们会基于特定目的收集您的个人信息。如您不提供此类信息，您将无法使用下述扩展业务功能，但不会影响您使用基本业务功能。

1. **基于”相册/存储“的扩展业务功能：**
   当您使用“尼来”产品与/或相关服务时，您可在开启“读取相册权限/存储权限”后上传照片或图片，用于设置头像及封面图、发布等功能。我们会获取您上传的图片并对其内容的合规性进行审核。

## 数据使用过程中涉及的公开披露您的个人信息

### 公开

1. **我们不会公开您的个人信息，除非遵循国家法律法规规定或者获得您的同意。我们公开您的个人信息会采用符合行业内标准的安全保护措施。**
2. 依法豁免征得同意可提供、公开的个人信息。请您理解，在下列情形中，根据法律法规及国家标准，我们向合作方提供、公开您的个人信息无需征得您的授权同意：
   - 为订立、履行您作为一方当事人的合同所必需，或者按照依法制定的劳动规章制度和依法签订的集体合同实施人力资源管理所必需；
   - 为履行法定职责或者法定义务所必需；
   - 与国家安全、国防安全直接相关的；
   - 与刑事侦查、起诉、审判和判决执行等直接相关的；
   - 为应对突发公共卫生事件，或者紧急情况下为保护自然人的生命、健康和财产安全所必需；
   - 为公共利益实施新闻报道、舆论监督等行为，在合理的范围内处理个人信息
   - 您自行向社会公众公开的个人信息；
   - 从合法公开披露的信息中收集个人信息的，如合法的新闻报道、政府信息公开等渠道；
   - 法律、行政法规规定的其他情形。

## 存储个人信息

### 存储地点

我们依照法律法规的规定，将在境内运营过程中收集和产生的您的个人信息存储于中华人民共和国境内。目前，我们不会将上述信息传输至境外，如果我们向境外传输，会严格遵守中国的相关法律、监管政策，并会遵循相关国家规定或者征求您的同意。

### 存储期限

我们仅在为提供尼来及服务之目的所必需的期间内保留您的个人信息，例如：

**手机号码：使用手机号码认证时，我们需要持续保留您的手机号码，以便于向您提供正常的服务并保障您的帐号和系统安全。**

如我们因经营不善或其他原因出现停止运营的情况，我们会将此情况通知您，并停止对您个人信息的收集以及删除或匿名化已收集的个人信息，但法律法规另有要求的除外。

如果您主动删除个人信息或超出必要的期限后，我们将对您的个人信息进行删除或匿名化处理。

### 保护个人信息的安全

1. 我们非常重视您个人信息的安全，将努力采取合理的安全措施（包括技术方面和管理方面）来保护您的个人信息，防止您提供的个人信息被不当使用或在未经授权的情况下被访问、公开披露、使用、修改、损坏、丢失或泄漏。
2. **我们会使用不低于行业同行的加密技术、匿名化处理及相关合理可行的手段保护您的个人信息，并使用安全保护机制防止您的个人信息遭到恶意攻击，包括但不限于：**
   - **我们会提供 https 安全浏览方式保护数据在其传输过程中的安全，除此以外我们还会使用妥善的保护机制以防止数据遭到恶意攻击；**
   - **我们会使用加密技术以及去标识化的处理方式并采用分类存储的方式保存您的个人信息；**
   - **为提升我们整体员工的数据安全保护意识，我们会举办安全和隐私保护培训课程，加强员工对于保护个人信息重要性的认识。**
3. 请您注意，电子邮件、即时通讯及与其他尼来用户之间的交流并未加密，如非必要，我们强烈建议您不要通过此类方式发送重要的个人信息，并采取积极措施保护个人信息的安全，**包括但不限于使用复杂密码、定期修改密码、不将自己的帐号密码及相关个人信息透露给他人**。
4. 尽管已经采取了上述合理有效措施，并已经遵守了相关法律规定要求的标准，但请您理解，由于技术的限制以及可能存在的各种恶意手段，在互联网行业，即便竭尽所能加强安全措施，也不可能始终保证信息百分之百的安全，我们将尽力确保您提供给我们的个人信息的安全性。
5. 我们会制定应急处理预案，并在发生用户信息安全事件时立即启动应急预案，努力阻止这些安全事件的影响和后果扩大。一旦发生用户信息安全事件（泄露、丢失）后，我们将按照法律法规的要求，及时向您告知：安全事件的基本情况和可能的影响、我们已经采取或将要采取的处置措施、您可自主防范和降低风险的建议、对您的补救措施。我们将及时将事件相关情况以推送通知、邮件、信函、短信及相关形式告知您，难以逐一告知时，我们会采取合理、有效的方式发布公告。同时，我们还将按照相关监管部门要求，上报用户信息安全事件的处置情况。
6. 您一旦离开尼来及相关服务，浏览或使用其他网站、服务及内容资源，我们将没有能力和直接义务保护您在尼来及相关服务之外的软件、网站提交的任何个人信息，无论您登录、浏览或使用上述软件、网站是否基于“尼来”的链接或引导。

## 管理您的个人信息

为了您可以更加便捷地访问、更改或删除您的个人信息，同时保障您撤回处理您个人信息同意的权利，您可以参考下面的指引进行操作：

1. 访问和更正您的个人信息
   **除法律法规规定外，您有权随时登录您的账户访问或修改您的个人信息**

2. 改变或撤回授权范围我们非常重视您对个人信息的管理，并尽全力保护对您个人信息的查阅、复制、更正、补充、删除、撤回同意授权的相关权利，以使您有能力保障您的隐私和信息安全。为了优化您的使用体验，我们也可能对操作设置进行调整，故如下指引仅供参考。

   - **改变或撤回敏感权限设置**

     - **您可以在设备本身的操作系统中，相册（存储）改变同意范围或撤回您的授权。关闭授权后我们将不再收集与这些权限相关的信息。**

   - **改变或撤回授权的信息处理**
     - **特定的业务功能和服务将需要您的信息才能得以完成，当您撤回同意或授权后，我们无法继续为您提供撤回同意或授权所对应的功能和服务，也不再处理您相应的个人信息。但您撤回同意或授权的决定，不会影响公司此前基于您的授权而开展的个人信息处理**。

3. 个人信息收集与管理的说明

   - **在以下情形中，您可以向我们提出删除个人信息的请求：**

     - 处理目的已实现、无法实现或者为实现处理目的不再必要；
     - 我们停止提供产品或者服务，或者保存期限已届满；
     - 个人撤回同意
     - 如果我们处理个人信息的行为违反了法律、行政法规或与您的约定；
     - 法律、行政法规规定的其他情形。

   - **个人信息删除：指在实现日常业务功能所涉及的系统中去除个人信息的行为，使其保持不可被检索、访问的状态。当您或我们协助您删除相关信息后，因为适用的法律和安全技术限制，我们可能无法立即从备份系统中删除相应的信息，我们将安全地存储您的个人信息并限制对其的任何进一步的处理，直到备份可以清除或实现匿名化。**

4. 访问政策
   - 您可以在登录页面查看本政策全部内容。
   - 请您了解，本政策中所述的“尼来”与/或相关服务可能会根据您所使用的手机型号、系统版本、软件应用程序版本、移动客户端等因素而有所不同。最终的产品和服务以您所使用的“尼来”软件及相关服务为准。

## 未成年人条款

### 未成年人的个人信息保护原则

我们非常重视对未成年个人信息的保护。尼来主要面向成年人。**若您是未满18周岁的未成年人，在使用本产品前，应在您的父母或其他监护人的监护、指导下共同阅读并同意本政策。若您是未满14周岁的未成年人的监护人，在使用尼来及相关服务前，应为您的被监护人阅读并同意本政策。**

1. 我们根据国家相关法律法规的规定保护未成年人的个人信息，只会在法律允许、父母或其他监护人明确同意或保护未成年人所必要的情况下收集、使用或披露未成年人的个人信息；如果我们发现在未事先获得可证实的监护人同意的情况下收集了未成年人的个人信息，则会设法尽快删除相关信息。
2. 若您是未成年人的监护人，当您对您所监护的未成年人使用“尼来”产品与/或服务或其向我们提供的的个人信息有其他疑问时，请通过公司本政策公示的联系方式与我们联系。

## 政策的修订和通知

1. 为了给您提供更好的服务，尼来及相关服务将不时更新与变化，我们会适时对本政策进行修订，这些修订构成本政策的一部分并具有等同于本政策的效力，未经您明确同意，我们不会削减您依据当前生效的本政策所应享受的权利。
2. 请您仔细阅读变更后的本政策内容。如果您不同意本政策，或对本政策修改、更新的内容有异议，您可以选择注销账号并不再使用本服务但请您知悉，您账号注销之前、停止使用本服务之前的行为和活动仍受本政策的约束。
3. 本政策更新后，我们会在尼来发出更新版本，并在更新后的条款生效前以适当的方式提醒您更新的内容，以便您及时了解本政策的最新版本。
4. 若涉及重大变更，我们会依据具体情况，以显著的方式通知您。重大变更的情形包括但不限于以下情形：
   - 我们的服务模式发生重大变化。如处理个人信息的目的、处理的个人信息类型、个人信息的使用方式等；
   - 您参与个人信息处理方面的权利及其行使方式发生重大变化。

## 联系我们

1. 尼来由中数碳本(厦门)元宇宙科技有限公司提供，如果您对个人信息保护问题有投诉、建议、疑问，您可以将问题发送至：service@tansocc.com，我们核查并验证您的用户身份后会及时反馈您的投诉与举报。
2. 若您对本政策有任何疑问或为行使您的个人主体权利，您可以通过发送邮件至
   service@tansocc.com 的方式与我们联系。一般情况下，我们将于14个工作日内响应。
`,nt=xe(c=>{const{type:e}=be.parse(c.f7route.params),[t,n]=O.useState(""),[s,i]=O.useState("");return O.useEffect(()=>{const r=new ke;let l="",o="";e==="protection"?(l=Te(),o=et):e==="user"&&(l=$e(),o=Ye),i(l),n(r.parse(o,{async:!1}))}),C.createElement(me,{name:"agreement",pageContent:!1},C.createElement(we,{backLink:!0,title:s,color:"black",className:"text-title"}),C.createElement(ye,{className:"px-4"},C.createElement("article",{className:"prose prose-sm lg:prose-xl prose-invert bg-white p-4 my-4 rounded-3",style:{"--tw-prose-headings":A.title,"--tw-prose-quotes":A.subtext,"--tw-prose-bold":A.title,"--tw-prose-body":A.title,"--tw-prose-counters":A.title},dangerouslySetInnerHTML:{__html:t}})))});export{nt as default};
