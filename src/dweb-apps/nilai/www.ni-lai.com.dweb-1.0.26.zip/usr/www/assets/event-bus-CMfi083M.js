import{co as o}from"./index-BRI03nc8.js";const s=o(),t=o();export{s as a,t as o};
