import{co as o}from"./index-BRmeX5wK.js";const s=o(),t=o();export{s as a,t as o};
