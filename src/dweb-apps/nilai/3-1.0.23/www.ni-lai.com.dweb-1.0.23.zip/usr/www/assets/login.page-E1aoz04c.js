import{d as n,R as e,P as t,O as i}from"./index-CE8D-oDf.js";const o=n(a=>e.createElement(t,{name:"login"},e.createElement(i,{title:"Login",backLink:a.backLink}),"Login Page"));export{o as default};
