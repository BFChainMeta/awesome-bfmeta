import{ck as o}from"./index-CE8D-oDf.js";const s=o(),t=o();export{s as a,t as o};
