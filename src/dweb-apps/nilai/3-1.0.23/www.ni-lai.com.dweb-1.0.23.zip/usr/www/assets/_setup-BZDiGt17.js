import{p}from"./sha256-CTcaH5DM.js";const a=async()=>{await p.prepare()};export{a as p};
