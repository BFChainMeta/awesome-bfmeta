import{d as n,R as e,P as t,E as i}from"./index-BSsW7jDT.js";const o=n(a=>e.createElement(t,{name:"login"},e.createElement(i,{title:"Login",backLink:a.backLink}),"Login Page"));export{o as default};
