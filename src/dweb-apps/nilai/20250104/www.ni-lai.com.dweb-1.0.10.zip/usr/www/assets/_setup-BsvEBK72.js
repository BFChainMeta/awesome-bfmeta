import{p}from"./sha256-Dx0uctB8.js";const a=async()=>{await p.prepare()};export{a as p};
