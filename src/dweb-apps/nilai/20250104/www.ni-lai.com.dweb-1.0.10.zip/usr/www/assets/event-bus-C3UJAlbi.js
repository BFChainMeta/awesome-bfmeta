import{cn as o}from"./index-BSsW7jDT.js";const n=o(),s=o();export{n as a,s as o};
