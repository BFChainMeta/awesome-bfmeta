import{p}from"./sha256-CsJfy6M_.js";const a=async()=>{await p.prepare()};export{a as p};
