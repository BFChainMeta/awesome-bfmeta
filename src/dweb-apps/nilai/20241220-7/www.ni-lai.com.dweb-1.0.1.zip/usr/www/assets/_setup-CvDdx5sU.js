import{p}from"./sha256-7NwOh3Ye.js";const a=async()=>{await p.prepare()};export{a as p};
