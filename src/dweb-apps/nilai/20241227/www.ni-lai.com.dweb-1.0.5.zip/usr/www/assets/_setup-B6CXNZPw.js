import{p}from"./sha256-D8lhxIpz.js";const a=async()=>{await p.prepare()};export{a as p};
