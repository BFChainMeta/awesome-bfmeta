import{p}from"./sha256-CGnrJQGh.js";const a=async()=>{await p.prepare()};export{a as p};
