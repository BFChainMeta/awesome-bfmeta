import{d as n,R as e,P as t,F as i}from"./index-1BJ14Pai.js";const o=n(a=>e.createElement(t,{name:"login"},e.createElement(i,{title:"Login",backLink:a.backLink}),"Login Page"));export{o as default};
