import { d as definePage, r as reactExports, R as React, P as Page } from "./index-DAk_nVWR.js";
const _404 = definePage(
  (args) => {
    reactExports.useEffect(() => {
      const navigate = (targetPath) => {
        let options = { reloadAll: true };
        if (targetPath === "/tabs") {
          options = {};
        }
        args.f7router.navigate(targetPath, options);
      };
      if (location.hash.startsWith("#!")) {
        const targetPath = location.hash.slice(2);
        if (args.f7route.path !== targetPath) {
          navigate(targetPath);
          return;
        }
      }
      navigate("/link-wallet");
    }, []);
    return /* @__PURE__ */ React.createElement(
      Page,
      {
        name: "Loss",
        className: "bg-[url('../images/image_login_cover.webp')] bg-black bg-center bg-no-repeat bg-cover"
      }
    );
  },
  { bindingHistory: false }
);
export {
  _404 as default
};
