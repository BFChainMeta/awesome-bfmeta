import { p as pbkdf2Sync$1, a as pbkdf2$1 } from "./pbkdf2-TR6Dwt-C.js";
import { c as createSHA256Sync } from "./sha256-C2OttJA4.js";
import { c as createSHA512Sync, a as createSHA512 } from "./sha512-D6HcgfaY.js";
import { B as Buffer, b as randomBytes } from "./index-BgMR6XJ4.js";
import { getDefaultWordlist } from "./wordlists-DNtPJMJf.js";
import "./hmac-CYoWib7y.js";
import "./WASMInterface-BIOcGvqx.js";
import "./index-DzX_QLg7.js";
import "./index-DAk_nVWR.js";
const pbkdf2Sync = (password, salt2, iterations, hashLength, _hash) => {
  const buf = pbkdf2Sync$1({
    hashFunction: createSHA512Sync(),
    password,
    salt: salt2,
    iterations,
    hashLength,
    outputType: "binary"
  });
  return Buffer.from(buf);
};
const pbkdf2 = async (password, salt2, iterations, hashLength, _hash) => {
  const buf = await pbkdf2$1({
    hashFunction: createSHA512(),
    password,
    salt: salt2,
    iterations,
    hashLength,
    outputType: "binary"
  });
  return Buffer.from(buf);
};
const sha256 = (data) => {
  return createSHA256Sync().update(data).digest();
};
const INVALID_MNEMONIC = "Invalid mnemonic";
const INVALID_ENTROPY = "Invalid entropy";
const INVALID_CHECKSUM = "Invalid mnemonic checksum";
const WORDLIST_REQUIRED = "A wordlist is required but a default could not be found.\nPlease pass a 2048 word array explicitly.";
function normalize(str) {
  return (str || "").normalize("NFKD");
}
function binaryToByte(bin) {
  return parseInt(bin, 2);
}
function bytesToBinary(bytes) {
  let binary = "";
  for (let i = 0; i < bytes.length; i++) {
    const byte = bytes[i];
    binary += byte.toString(2).padStart(8, "0");
  }
  return binary;
}
function deriveChecksumBits(entropyBuffer) {
  const ENT = entropyBuffer.length * 8;
  const CS = ENT / 32;
  const hash = sha256(entropyBuffer);
  return bytesToBinary(hash).slice(0, CS);
}
function salt(password) {
  return "mnemonic" + (password || "");
}
function mnemonicToSeedSync(mnemonic, password) {
  const mnemonicBuffer = Buffer.from(normalize(mnemonic), "utf8");
  const saltBuffer = Buffer.from(salt(normalize(password)), "utf8");
  return pbkdf2Sync(mnemonicBuffer, saltBuffer, 2048, 64);
}
function mnemonicToSeed(mnemonic, password) {
  const mnemonicBuffer = Buffer.from(normalize(mnemonic), "utf8");
  const saltBuffer = Buffer.from(salt(normalize(password)), "utf8");
  return pbkdf2(mnemonicBuffer, saltBuffer, 2048, 64);
}
function mnemonicToEntropy(mnemonic, wordlist) {
  wordlist = wordlist || getDefaultWordlist()?.wordlist;
  if (!wordlist) {
    throw new Error(WORDLIST_REQUIRED);
  }
  const words = normalize(mnemonic).split(" ");
  if (words.length % 3 !== 0) {
    throw new Error(INVALID_MNEMONIC);
  }
  const bits = words.map((word) => {
    const index = wordlist.indexOf(word);
    if (index === -1) {
      throw new Error(INVALID_MNEMONIC);
    }
    return index.toString(2).padStart(11, "0");
  }).join("");
  const dividerIndex = Math.floor(bits.length / 33) * 32;
  const entropyBits = bits.slice(0, dividerIndex);
  const checksumBits = bits.slice(dividerIndex);
  const entropyBytes = entropyBits.match(/(.{1,8})/g).map(binaryToByte);
  if (entropyBytes.length < 16) {
    throw new Error(INVALID_ENTROPY);
  }
  if (entropyBytes.length % 4 !== 0) {
    throw new Error(INVALID_ENTROPY);
  }
  const entropy = Buffer.from(entropyBytes);
  const newChecksum = deriveChecksumBits(entropy);
  if (newChecksum !== checksumBits) {
    throw new Error(INVALID_CHECKSUM);
  }
  return entropy.toString("hex");
}
function entropyToMnemonic(entropy, wordlist) {
  if (!Buffer.isBuffer(entropy)) {
    entropy = Buffer.from(entropy, "hex");
  }
  wordlist = wordlist || getDefaultWordlist()?.wordlist;
  if (!wordlist) {
    throw new Error(WORDLIST_REQUIRED);
  }
  if (entropy.length < 16) {
    throw new TypeError(INVALID_ENTROPY);
  }
  if (entropy.length % 4 !== 0) {
    throw new TypeError(INVALID_ENTROPY);
  }
  const entropyBits = bytesToBinary(Array.from(entropy));
  const checksumBits = deriveChecksumBits(entropy);
  const bits = entropyBits + checksumBits;
  const chunks = bits.match(/(.{1,11})/g);
  const words = chunks.map((binary) => {
    const index = binaryToByte(binary);
    return wordlist[index];
  });
  return wordlist[0] === "あいこくしん" ? words.join("　") : words.join(" ");
}
function generateMnemonic(strength, rng = randomBytes, wordlist) {
  strength = strength || 128;
  if (strength % 32 !== 0) {
    throw new TypeError(INVALID_ENTROPY);
  }
  return entropyToMnemonic(Buffer.from(rng(strength / 8)), wordlist);
}
function validateMnemonic(mnemonic, wordlist) {
  try {
    mnemonicToEntropy(mnemonic, wordlist);
  } catch (e) {
    return false;
  }
  return true;
}
export {
  entropyToMnemonic,
  generateMnemonic,
  mnemonicToEntropy,
  mnemonicToSeed,
  mnemonicToSeedSync,
  normalize,
  validateMnemonic
};
