import { G as GoodsOrderDiscountStatus } from "./order.table-BhHagEF8.js";
import { d as definePage, r as reactExports, dd as useConfirmDialog, V as useFlow, ak as updateLoginerUserInfo, R as React, P as Page, O as Navbar, de as order_list, bU as Subnavbar, bV as Segmented, $ as colors, a as Button, df as order_all, dg as order_pending, dh as order_paid, di as order_shipped, Q as PageContent, dj as cumulative_platform_spending, aW as price_with_html, ad as LoadingPageData, ae as NoData, af as SlideInDownListItem, ao as Card, cv as writeText, x as toast, bY as order_id, aT as z, aU as N, dk as pending_shipment, aq as CardContent, ax as BlobImage, aP as price, bv as total_price, b9 as need_to_consume_$consume$_to_deduction$deduction$, ba as get_showAsset_balance, bb as get_discount_consumption_asset_types_amount_info, bX as deducted, c0 as returned, dl as not_deducted, bz as order_notes, B as Block, cf as consignee, ch as phone_number, cl as detailed_address, bG as platform_rewards, bJ as brand_rewards, a2 as Icon, as as CardFooter, dm as payment_completed, co as successfully, dn as sending_$asset$_$count$_$total$, dp as pending_payment, b1 as cancel, b2 as payment, bk as payment_error, dq as order_cancellation, b3 as Big, at as userApi, a_ as this_product_has_been_taken_down, bh as f7, F as userController, dr as cancel_failed, aj as appUserInfoFlow, al as usePageQueryState, cD as copied_successfully, n as ConfirmDialog, ds as cancel_the_payment_for_this_order } from "./index-DAk_nVWR.js";
import { A as AssetTypeName, a as AssetTypeIcon } from "./asset-type-Dz_tlnol.js";
import { u as useRefresh } from "./use_refresh-BDtdKSoi.js";
var GoodsOrderStatus = /* @__PURE__ */ ((GoodsOrderStatus2) => {
  GoodsOrderStatus2["ALL"] = "all";
  GoodsOrderStatus2["PAYMENT"] = "payment";
  GoodsOrderStatus2["DELIVERED"] = "delivered";
  GoodsOrderStatus2["PENDING"] = "pending";
  return GoodsOrderStatus2;
})(GoodsOrderStatus || {});
const orderList_page = definePage((args) => {
  const [orderStatus, setOrderStatus] = reactExports.useState(GoodsOrderStatus.ALL);
  const confirmDialog = useConfirmDialog(({ ...props }) => /* @__PURE__ */ React.createElement(ConfirmDialog, { ...props }, cancel_the_payment_for_this_order()));
  const contentRefresh = useRefresh();
  const goPayment = async (item) => {
    if (item.paymentStatus) {
      return;
    }
    const details = await userApi.getGoodsDetails.query(item.goodsDetails.goodsId);
    if (details.status !== 1) {
      toast(this_product_has_been_taken_down());
      return;
    }
    args.safeF7Navigater.goods.payment({
      query: {
        nilaiProportion: "",
        brandProportion: "",
        imgBloburi: "",
        amount: item.goodPrice,
        actualPrice: item.actualPrice,
        goodsName: item.goodsDetails.goodsName,
        goodsId: item.goodsDetails.goodsId,
        quantity: String(item.quantity),
        goodsDiscountbrandProportion: item.goodsDetails.goodsDiscountbrandProportion,
        orderId: item.orderId
      },
      props: {
        payPwd: ""
      }
    });
  };
  const getTotalPrice = (goodPrice, quantity) => {
    const price_BI = new Big(goodPrice);
    const quantity_BI = new Big(quantity);
    return price_BI.mul(quantity_BI).toString();
  };
  const cancelOrder = (item) => {
    confirmDialog.open({
      onConfirmCallback: async () => {
        try {
          f7.preloader.show();
          await userController.cancelOrder(item.orderId);
          item.paymentStatus = 2;
          contentRefresh();
        } catch (err) {
          console.error(err);
          toast(cancel_failed());
        } finally {
          f7.preloader.hide();
        }
      }
    });
  };
  const [appUserInfo] = useFlow(appUserInfoFlow);
  reactExports.useEffect(() => {
    updateLoginerUserInfo(appUserInfo.address);
  }, []);
  const userOrderListFactory = (orderStatus2) => usePageQueryState([], 1, async (preContent, page) => {
    const result = await userController.getOrderList(page, 20, orderStatus2);
    preContent.push(
      ...result.data.map((item) => {
        return {
          ...item,
          showMoreInfo: false
        };
      })
    );
    const content = preContent;
    return {
      content,
      nextPage: page + 1,
      end: content.length >= result.total
    };
  });
  const userOrderListHub = {
    [GoodsOrderStatus.ALL]: userOrderListFactory(GoodsOrderStatus.ALL),
    [GoodsOrderStatus.PAYMENT]: userOrderListFactory(GoodsOrderStatus.PAYMENT),
    [GoodsOrderStatus.DELIVERED]: userOrderListFactory(GoodsOrderStatus.DELIVERED),
    [GoodsOrderStatus.PENDING]: userOrderListFactory(GoodsOrderStatus.PENDING)
  };
  const userOrderList = userOrderListHub[orderStatus];
  reactExports.useEffect(() => {
    if (userOrderList.isLoading === false && userOrderList.isReady === false) {
      userOrderList.loadFirst();
    }
  }, [userOrderList]);
  const switchOrderStatus = (status) => {
    if (orderStatus === status) {
      return;
    }
    pageContentRef.current.el && pageContentRef.current.el.scrollTo({
      left: 0,
      top: 0,
      behavior: "smooth"
    });
    setOrderStatus(status);
  };
  const pageContentRef = reactExports.useRef({ el: null });
  return /* @__PURE__ */ React.createElement(Page, { name: "order-list", pageContent: false }, /* @__PURE__ */ React.createElement(Navbar, { title: order_list(), backLink: true, color: "white", className: "text-white" }, /* @__PURE__ */ React.createElement(Subnavbar, null, /* @__PURE__ */ React.createElement(
    Segmented,
    {
      strong: true,
      style: {
        "--f7-segmented-strong-button-active-bg-color": colors.primary,
        "--f7-segmented-strong-button-text-color": colors.subtext,
        "--f7-segmented-strong-button-active-text-color": colors.black
      }
    },
    /* @__PURE__ */ React.createElement(
      Button,
      {
        active: orderStatus === GoodsOrderStatus.ALL,
        onClick: () => switchOrderStatus(GoodsOrderStatus.ALL)
      },
      order_all()
    ),
    /* @__PURE__ */ React.createElement(
      Button,
      {
        active: orderStatus === GoodsOrderStatus.PENDING,
        onClick: () => switchOrderStatus(GoodsOrderStatus.PENDING)
      },
      order_pending()
    ),
    /* @__PURE__ */ React.createElement(
      Button,
      {
        active: orderStatus === GoodsOrderStatus.PAYMENT,
        onClick: () => switchOrderStatus(GoodsOrderStatus.PAYMENT)
      },
      order_paid()
    ),
    /* @__PURE__ */ React.createElement(
      Button,
      {
        active: orderStatus === GoodsOrderStatus.DELIVERED,
        onClick: () => switchOrderStatus(GoodsOrderStatus.DELIVERED)
      },
      order_shipped()
    )
  ))), /* @__PURE__ */ React.createElement(PageContent, { ref: pageContentRef, ...userOrderList.f7PagePtrProps, ...userOrderList.f7PageInfiniteProps }, /* @__PURE__ */ React.createElement("div", { className: "text-subtext flex items-center justify-end px-4 pt-2 text-right text-xs" }, cumulative_platform_spending(), ":", /* @__PURE__ */ React.createElement("span", { className: "text-primary ml-1" }, " ", price_with_html(appUserInfo.accumulatedAmount || "0"))), userOrderList.render({
    loading: () => /* @__PURE__ */ React.createElement(LoadingPageData, null),
    listEmpty: () => /* @__PURE__ */ React.createElement(NoData, null),
    listItem: (order, index, list) => /* @__PURE__ */ React.createElement(SlideInDownListItem, { group: list, key: order.orderId + orderStatus, index }, /* @__PURE__ */ React.createElement(Card, { outline: true, className: "bg-pop-background" }, /* @__PURE__ */ React.createElement("div", { className: "text-subtext text-xss p-1 px-2 text-right" }, /* @__PURE__ */ React.createElement(
      "span",
      {
        onClick: async ($event) => {
          $event.stopPropagation();
          await writeText(order.orderId);
          toast(copied_successfully());
        }
      },
      order_id(),
      ": ",
      order.orderId
    )), z(order).with({ paymentStatus: 1, courierNumber: N.nonNullable.select() }, (courierNumber) => /* @__PURE__ */ React.createElement("div", { className: "text-subtext px-2 text-right text-xs" }, /* @__PURE__ */ React.createElement(
      "span",
      {
        onClick: async ($event) => {
          $event.stopPropagation();
          await writeText(courierNumber);
          toast(copied_successfully());
        }
      },
      order.courierCompany,
      " : ",
      courierNumber
    ))).with({ paymentStatus: 1 }, () => /* @__PURE__ */ React.createElement("div", { className: "text-subtext px-2 text-right text-xs" }, pending_shipment())).otherwise(() => /* @__PURE__ */ React.createElement(React.Fragment, null)), /* @__PURE__ */ React.createElement(CardContent, { className: "py-1 text-white" }, /* @__PURE__ */ React.createElement("div", { className: "flex items-start justify-between" }, /* @__PURE__ */ React.createElement(
      BlobImage,
      {
        bloburi: order.goodsDetails.thumbnail?.[0]?.bloburi,
        className: "w-18 h-18 mr-2 flex-shrink-0"
      }
    ), /* @__PURE__ */ React.createElement("div", { className: "max-h-18 h-full flex-grow break-words" }, order.goodsDetails.title)), /* @__PURE__ */ React.createElement("div", { className: "text-primary mt-2 flex items-center justify-between text-right" }, /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("span", { className: "text-base" }, /* @__PURE__ */ React.createElement("span", { className: "mr-1 text-xs" }, "¥"), price(order.actualPrice)), /* @__PURE__ */ React.createElement("span", { className: "text-[10px]" }, " x", order.quantity)), /* @__PURE__ */ React.createElement("div", { className: "flex items-center justify-center" }, total_price(), ":", /* @__PURE__ */ React.createElement("span", { className: "ml-1 text-base" }, /* @__PURE__ */ React.createElement("span", { className: "mr-1 text-xs" }, "¥"), price(getTotalPrice(order.actualPrice, order.quantity))))), !!order.discountInfo?.length && /* @__PURE__ */ React.createElement("div", { className: "text-subtext mb-1 py-1 text-xs" }, order.discountInfo.map((item, index2) => /* @__PURE__ */ React.createElement("div", { key: index2 }, /* @__PURE__ */ React.createElement("div", { className: "mt-0.5 flex items-center justify-between" }, /* @__PURE__ */ React.createElement("div", { className: "flex flex-shrink-0 items-center" }, " ", /* @__PURE__ */ React.createElement(
      BlobImage,
      {
        className: "mr-1 inline-block h-4 w-4 rounded-full object-cover",
        bloburi: item.info.brandStablecoin.logo,
        alt: ""
      }
    ), " ", /* @__PURE__ */ React.createElement(
      AssetTypeName,
      {
        assetType: item.info.brandStablecoin.assetType,
        chainName: item.info.brandStablecoin.chainName
      }
    )), /* @__PURE__ */ React.createElement("div", { className: "flex" }, /* @__PURE__ */ React.createElement(
      "div",
      {
        dangerouslySetInnerHTML: {
          __html: need_to_consume_$consume$_to_deduction$deduction$({
            consumeCss: "text-white",
            consume: get_showAsset_balance(
              get_discount_consumption_asset_types_amount_info(order.goodPrice, {
                deductionRatio: order.goodsDetails.goodsDiscountbrandProportion,
                numberToPriceRatio: item.info.brandStablecoin.number,
                goodsQuantity: order.quantity
              }).discountedAmount
            ),
            deductionCss: "text-primary",
            deduction: price(
              get_discount_consumption_asset_types_amount_info(order.goodPrice, {
                deductionRatio: order.goodsDetails.goodsDiscountbrandProportion,
                numberToPriceRatio: item.info.brandStablecoin.number,
                goodsQuantity: order.quantity
              }).discountedDiff
            )
          })
        }
      }
    ), /* @__PURE__ */ React.createElement("div", { className: "text-right" }, z(item.info).with({ status: GoodsOrderDiscountStatus.success }, () => /* @__PURE__ */ React.createElement("span", { className: "text-xss text-secondary-green ml-1" }, "(", deducted(), ")")).with(
      {
        status: GoodsOrderDiscountStatus.refundSuccessful
      },
      () => /* @__PURE__ */ React.createElement("span", { className: "text-xss text-secondary-red ml-1" }, "(", returned(), ")")
    ).otherwise(() => /* @__PURE__ */ React.createElement("span", { className: "text-xss ml-1" }, "(", not_deducted(), ")")))))))), !!order.orderNotes && /* @__PURE__ */ React.createElement("div", { className: "text-subtext py-2" }, /* @__PURE__ */ React.createElement("p", { className: "mb-1 text-xs" }, " ", order_notes()), /* @__PURE__ */ React.createElement(Block, { strong: true, inset: true, className: "flex-grow p-2" }, /* @__PURE__ */ React.createElement("div", { className: "text-xs" }, order.orderNotes))), /* @__PURE__ */ React.createElement(
      "div",
      {
        className: "text-subtext text-center text-[12px]",
        onClick: async ($event) => {
          $event.stopPropagation();
          order.showMoreInfo = !order.showMoreInfo;
          contentRefresh();
        }
      },
      /* @__PURE__ */ React.createElement("div", { className: order.showMoreInfo ? "" : "h-0 overflow-hidden" }, /* @__PURE__ */ React.createElement("div", { className: "flex items-center justify-between text-right" }, /* @__PURE__ */ React.createElement("div", null, consignee()), /* @__PURE__ */ React.createElement("div", { className: "max-w-[66%]" }, order.shippingAddress.name)), /* @__PURE__ */ React.createElement("div", { className: "flex items-center justify-between text-right" }, /* @__PURE__ */ React.createElement("div", null, phone_number()), /* @__PURE__ */ React.createElement("div", { className: "max-w-[66%]" }, order.shippingAddress.phone)), /* @__PURE__ */ React.createElement("div", { className: "flex items-center justify-between text-right" }, /* @__PURE__ */ React.createElement("div", null, detailed_address()), /* @__PURE__ */ React.createElement("div", { className: "max-w-[66%]" }, `${order.shippingAddress.area || ""} ${order.shippingAddress.address}`)), order.airdropInfo && /* @__PURE__ */ React.createElement(React.Fragment, null, /* @__PURE__ */ React.createElement("div", { className: "mb-1 flex items-center justify-between text-right" }, /* @__PURE__ */ React.createElement("div", null, platform_rewards()), /* @__PURE__ */ React.createElement("div", { className: "max-w-[66%]" }, /* @__PURE__ */ React.createElement("div", { className: "flex items-center justify-end" }, /* @__PURE__ */ React.createElement(
        AssetTypeIcon,
        {
          assetType: order.airdropInfo.platform.assetType,
          chainName: order.airdropInfo.platform.chainName,
          cssClass: "mr-1 h-4 w-4 rounded-full"
        }
      ), /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement(
        AssetTypeName,
        {
          assetType: order.airdropInfo.platform.assetType,
          chainName: order.airdropInfo.platform.chainName
        }
      ), /* @__PURE__ */ React.createElement("span", { className: "ml-1" }, getRewardAmount(order.airdropInfo.platform.number), /* @__PURE__ */ React.createElement("span", { className: "text-xss ml-1" }, "x ", order.quantity)))))), /* @__PURE__ */ React.createElement("div", { className: "flex items-center justify-between text-right" }, /* @__PURE__ */ React.createElement("div", null, brand_rewards()), /* @__PURE__ */ React.createElement("div", { className: "max-w-[66%]" }, /* @__PURE__ */ React.createElement("div", { className: "flex items-center justify-end" }, /* @__PURE__ */ React.createElement(
        AssetTypeIcon,
        {
          assetType: order.airdropInfo.brand.assetType,
          chainName: order.airdropInfo.brand.chainName,
          cssClass: "mr-1 h-4 w-4 rounded-full"
        }
      ), /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement(
        AssetTypeName,
        {
          assetType: order.airdropInfo.brand.assetType,
          chainName: order.airdropInfo.brand.chainName
        }
      ), /* @__PURE__ */ React.createElement("span", { className: "ml-1" }, getRewardAmount(order.airdropInfo.brand.number), /* @__PURE__ */ React.createElement("span", { className: "text-xss ml-1" }, "x ", order.quantity)))))))),
      /* @__PURE__ */ React.createElement(
        Icon,
        {
          f7: order.showMoreInfo ? "chevron_up" : "chevron_down",
          className: "text-white",
          size: 16
        }
      )
    )), /* @__PURE__ */ React.createElement("div", { className: "border-t-tiny w-full border-white/40" }), z(order.paymentStatus).with(1, () => /* @__PURE__ */ React.createElement(CardFooter, { className: "flex items-center justify-between text-[12px]" }, /* @__PURE__ */ React.createElement("span", { className: "text-secondary-green" }, order.courierNumber ? order_shipped() : payment_completed()), order.distributionInfo?.every((item) => item.distributionSuccessfully) ? /* @__PURE__ */ React.createElement("span", { className: "text-primary" }, successfully(), ": ", order.distributionInfo?.length || 0, "/", String(BigInt(order.quantity) * BigInt(2))) : /* @__PURE__ */ React.createElement("span", { className: "text-subtext text-xs" }, sending_$asset$_$count$_$total$({
      count: order.distributionInfo?.filter((item) => item.distributionSuccessfully).length || 0,
      total: String(BigInt(order.quantity) * BigInt(2)),
      // assetType: i18nGetAssetTypeText(
      //   item.airdropInfo.platform.assetType,
      // ),
      assetType: ""
    })))).with(0, () => /* @__PURE__ */ React.createElement(CardFooter, { className: "text-[12px] text-red-500" }, pending_payment(), /* @__PURE__ */ React.createElement("div", { className: "flex items-center" }, /* @__PURE__ */ React.createElement(
      Button,
      {
        small: true,
        fill: true,
        className: "bg-secondary-red mr-4 border-none text-white",
        onClick: ($event) => {
          $event.stopPropagation();
          cancelOrder(order);
        }
      },
      cancel()
    ), /* @__PURE__ */ React.createElement(
      Button,
      {
        small: true,
        fill: true,
        className: "bg-primary border-none text-black",
        onClick: () => goPayment(order)
      },
      payment()
    )))).with(-1, () => /* @__PURE__ */ React.createElement(CardFooter, { className: "text-secondary-red text-[12px]" }, payment_error())).with(2, () => /* @__PURE__ */ React.createElement(CardFooter, { className: "text-subtext text-[12px]" }, order_cancellation())).exhaustive()))
  })), confirmDialog.render());
});
const getRewardAmount = (number) => {
  return new Big(number).div(1e8).toString();
};
export {
  orderList_page as default
};
