import { ce as __vitePreload, dy as ChainBrowserApi, D as BIOFOREST_CHAIN_NAME } from "./index-DAk_nVWR.js";
const jsonToGenesisBlockObj = (json) => {
  if (typeof json.default === "object") {
    return json.default;
  }
  return JSON.parse(json.default);
};
const ccchainGenesisBlockProd = async () => {
  const json = await __vitePreload(() => import("./ccchain-genesisBlock.prod-DBTqMUCf.js"), true ? [] : void 0);
  return jsonToGenesisBlockObj(json);
};
const PROD_GENESIS_BLOCK_ASSET = await ccchainGenesisBlockProd();
const EXPIRED_HEIGHT = 58;
const GET_LAST_BLOCK_TIMESTAMP = /* @__PURE__ */ (() => {
  const value = {
    timestamp: 0,
    count: 0
  };
  return (timestamp) => {
    if (timestamp !== value.timestamp) {
      value.timestamp = timestamp;
      value.count = 0;
    } else {
      value.count--;
    }
    return Number(BigInt(value.timestamp) + BigInt(value.count));
  };
})();
class CCChainController extends ChainBrowserApi {
  constructor(_bundleCore, _isProd, _i18n, browserUrl) {
    super();
    this._bundleCore = _bundleCore;
    this._isProd = _isProd;
    this._i18n = _i18n;
    this.browserUrl = browserUrl;
    this.getBlockInfo_task = {
      hasRunning: false,
      task: Promise.withResolvers()
    };
    this.broadcastTransaction = async (transaction) => {
      try {
        const res = await this.SERVER_API.broadcastTransaction(transaction);
        return res;
      } catch (err) {
        if (typeof err === "string") {
          throw err;
        }
        const error = err;
        if (error.message) {
          throw error.message;
        }
        if (error.error) {
          throw error.error.message || error.error;
        }
        throw err;
      }
    };
  }
  get genesitBlockAsset() {
    return PROD_GENESIS_BLOCK_ASSET;
  }
  get genesitBlockConfig() {
    return this.genesitBlockAsset.asset.genesisAsset;
  }
  //#region @TODO 可能多链会用到的公用部分到时候抽出
  /** 是否为地址 */
  isAddress(address) {
    return this._bundleCore.bioforestChainSignUtil.isAddress(address);
  }
  /**
   * 校验二次密码公钥是否正确
   * @param secret 主密码
   * @param secondSecret 二次密码
   * @param secondPublicKey 二次密码公钥
   */
  async checkSecondSecret(secret, secondSecret, secondPublicKey) {
    return await this._bundleCore.bioforestChainSignUtil.checkSecondSecretV2(secret, secondSecret, secondPublicKey) || await this._bundleCore.bioforestChainSignUtil.checkSecondSecret(secret, secondSecret, secondPublicKey);
  }
  /** 根据主密码生成公私钥 */
  createKeypair(secret) {
    return this._bundleCore.bioforestChainSignUtil.createKeypair(secret);
  }
  /** 通过主密码生成地址 */
  async getAddressByMainSecret(mainSecret) {
    const { publicKey } = await this.createKeypair(mainSecret);
    return this.getAddressByPublicKeyString(publicKey.toString("hex"));
  }
  /** 通过公钥生成地址 */
  getAddressByPublicKeyString(publicKey) {
    return this._bundleCore.bioforestChainSignUtil.getAddressFromPublicKeyString(publicKey);
  }
  /** 通过私钥生成地址 */
  getAddressByPrivateKeyString(privateKey) {
    const keypair = this._bundleCore.bioforestChainSignUtil.createKeypairBySecretKeyString(privateKey);
    return this._bundleCore.bioforestChainSignUtil.getAddressFromPublicKey(keypair.publicKey);
  }
  /** 根据id查交易 */
  async getTransactionInBlockById(txId, height) {
    if (!height) {
      const res = await this.getBlockInfo();
      height = res.height;
    }
    const { trs } = await this.SERVER_API.getTransactionInBlockById(txId, height);
    return trs && trs[0];
  }
  /** 获取区块 */
  async getBlockInfo(height) {
    if (height) {
      const { blocks } = await this.SERVER_API.queryBlock(height);
      if (blocks.length === 0) {
        throw new Error(
          this._i18n.$chain$_failed_to_query_block_with_height_of_$height$({
            chain: BIOFOREST_CHAIN_NAME.CCChain,
            height
          })
        );
      }
      return blocks[0];
    }
    try {
      if (this.getBlockInfo_task.hasRunning) {
        return this.getBlockInfo_task.task.promise;
      }
      this.getBlockInfo_task.hasRunning = true;
      this.getBlockInfo_task.task = Promise.withResolvers();
      const lastBlock = await this.SERVER_API.getLastBlock();
      this.getBlockInfo_task.task.resolve(lastBlock);
      return lastBlock;
    } catch (err) {
      this.getBlockInfo_task.task.reject(err);
      throw err;
    } finally {
      this.getBlockInfo_task.hasRunning = false;
    }
  }
  async getAddressAsset(address, opts) {
    const res = await this.SERVER_API.getAddressAsset(address, opts);
    if (res) {
      const assets = res.assets || {};
      const magicAssets = assets[this.genesitBlockConfig.magic] || {};
      return magicAssets;
    }
    return {};
  }
  async getAddressSecondPublicKey(address) {
    const res = await this.SERVER_API.getAddressInfo(address);
    if (res) {
      return res.secondPublicKey || void 0;
    }
    return void 0;
  }
  async getCreateTransactionBlockInfo() {
    const lastBlock = await this.getBlockInfo();
    return {
      applyBlockHeight: lastBlock.height,
      timestamp: GET_LAST_BLOCK_TIMESTAMP(lastBlock.timestamp)
    };
  }
  /** @TODO 交易体 以及 可能用到的共有部分 */
  /** entity转移 */
  async createEntityTransaction(options, blockInfo) {
    const { fee, applyBlockHeight, timestamp } = await this.getCreateEntityTransactionMinFee(options, blockInfo);
    if (!options.fee) {
      options.fee = fee;
    }
    return this._bundleCore.bioforestChain.transactionController.createEntityTransferTransactionJSON({
      secrets: {
        mainSecret: options.mainSecret,
        paySecret: options.paySecret
      },
      transaction: {
        fee: options.fee,
        recipientId: options.receiveAddress,
        applyBlockHeight,
        timestamp,
        remark: options.remark ?? void 0,
        effectiveBlockHeight: applyBlockHeight + EXPIRED_HEIGHT
      },
      assetInfo: {
        assetType: options.entityId,
        amount: "1",
        taxInformation: {
          taxCollector: options.entityFeeReceiveAddress,
          taxAssetPrealnum: options.entityFee
        }
      }
    });
  }
  /** entity转移最小手续费 */
  async getCreateEntityTransactionMinFee(options, blockInfo) {
    const { applyBlockHeight, timestamp } = blockInfo || await this.getCreateTransactionBlockInfo();
    const fee = await this._bundleCore.bioforestChain.transactionController.createEntityTransferTransactionMinFee(
      {
        applyBlockHeight,
        timestamp,
        remark: options.remark,
        effectiveBlockHeight: applyBlockHeight + EXPIRED_HEIGHT
      },
      {
        assetType: options.entityId,
        amount: "1",
        taxInformation: {
          taxCollector: options.entityFeeReceiveAddress,
          taxAssetPrealnum: options.entityFee
        }
      }
    );
    return {
      fee,
      applyBlockHeight,
      timestamp
    };
  }
  /** assetType转移 */
  async getTransferTransaction(options, blockInfo) {
    const { fee, applyBlockHeight, timestamp } = await this.getTransferTransactionMinFee(options, blockInfo);
    if (!options.fee) {
      options.fee = fee;
    }
    return this._bundleCore.bioforestChain.transactionController.createTransferTransactionJSON({
      secrets: {
        mainSecret: options.mainSecret,
        paySecret: options.paySecret
      },
      transaction: {
        fee: options.fee,
        recipientId: options.receiveAddress,
        applyBlockHeight,
        timestamp,
        remark: options.remark ?? void 0,
        effectiveBlockHeight: applyBlockHeight + EXPIRED_HEIGHT
      },
      assetInfo: {
        sourceChainName: this.genesitBlockConfig.chainName,
        sourceChainMagic: this.genesitBlockConfig.magic,
        assetType: options.assetType,
        amount: options.amount
      }
    });
  }
  /** assetType转移最小手续费 */
  async getTransferTransactionMinFee(options, blockInfo) {
    const { applyBlockHeight, timestamp } = blockInfo || await this.getCreateTransactionBlockInfo();
    const fee = await this._bundleCore.bioforestChain.transactionController.getTransferTransactionMinFee({
      transaction: {
        applyBlockHeight,
        timestamp
      },
      assetInfo: {
        sourceChainName: this.genesitBlockConfig.chainName,
        sourceChainMagic: this.genesitBlockConfig.magic,
        assetType: options.assetType,
        amount: options.amount
      }
    });
    return {
      fee,
      applyBlockHeight,
      timestamp
    };
  }
}
export {
  CCChainController,
  PROD_GENESIS_BLOCK_ASSET
};
