import { g as getSha3Preparer } from "./sha3-DcKHfBWh.js";
const keccak = async (data, bits = 512) => {
  return (await getSha3Preparer(bits)()).calculate(data, bits, 1);
};
const createKeccak = async (bits = 512) => {
  return createKeccakSync(bits, await getSha3Preparer(bits)());
};
const createKeccakSync = (bits = 512, wasm = getSha3Preparer(bits).wasm) => {
  const outputSize = bits / 8;
  wasm.init(bits);
  const obj = {
    init: () => {
      wasm.init(bits);
      return obj;
    },
    update: (data) => {
      wasm.update(data);
      return obj;
    },
    digest: (outputType) => wasm.digest(outputType, 1),
    save: () => wasm.save(),
    load: (data) => {
      wasm.load(data);
      return obj;
    },
    blockSize: 200 - 2 * outputSize,
    digestSize: outputSize
  };
  return obj;
};
export {
  createKeccak as a,
  createKeccakSync as c,
  keccak as k
};
