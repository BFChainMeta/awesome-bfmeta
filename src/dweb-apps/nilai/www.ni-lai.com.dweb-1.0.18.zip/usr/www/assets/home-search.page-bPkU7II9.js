import { d as definePage, r as reactExports, U as GoodsSortType, V as useFlow, R as React, P as Page, O as Navbar, W as NavTitle, X as Searchbar, Y as search_for_goods_of_this_brand, Z as please_enter_search_content, _ as NavRight, a as Button, $ as colors, a0 as search, a1 as historical_search, a2 as Icon, a3 as BlockTitle, a4 as Popover, a5 as useCustomMutableRef, a6 as List, a7 as ListItem, a8 as Link, a9 as overall, aa as price_low_to_high, ab as price_high_to_low, ac as sales, B as Block, ad as LoadingPageData, ae as NoData, af as SlideInDownListItem, ag as GoodsItem, n as ConfirmDialog, ah as confirm, ai as are_you_sure_to_delete_all_historical_records, aj as appUserInfoFlow, F as userController, ak as updateLoginerUserInfo, al as usePageQueryState, am as adminApi } from "./index-DAk_nVWR.js";
import { u as useRefresh } from "./use_refresh-BDtdKSoi.js";
const homeSearch_page = definePage(({ brandId, ...args }) => {
  const [sortType, setSortType] = reactExports.useState(GoodsSortType.overall);
  const [appUserInfo] = useFlow(appUserInfoFlow);
  const contentRefresh = useRefresh();
  const [searchContent, setSearchContent] = reactExports.useState("");
  const searchQueryAborted = reactExports.useRef(null);
  const [showRecordOrGoods, setShowRecordOrGoods] = reactExports.useState("record");
  const [openConfirmDialog, setOpenConfirmDialog] = reactExports.useState(false);
  const handleSearch = async (historySearch) => {
    if (showRecordOrGoods === "goods") {
      return;
    }
    setShowRecordOrGoods("goods");
    if (historySearch) {
      setSearchContent(historySearch);
    }
    const currentSearch = (historySearch || searchContent || "").trim();
    if (searchQueryAborted.current) {
      searchQueryAborted.current.abort("cancel");
      searchQueryAborted.current = null;
    }
    const aborter = new AbortController();
    searchQueryAborted.current = aborter;
    userController.recordHistorySearch({
      key: "home",
      value: currentSearch
    }).then((res) => res && updateLoginerUserInfo(appUserInfo.address));
    {
      Object.values(goodsListHub).forEach((v) => v.page = 1);
    }
    await goodsList.loadFirst({ signal: aborter.signal }).finally(() => searchQueryAborted.current = null);
  };
  const searchContentChange = (event) => {
    const query = event.target.value;
    setSearchContent(query);
  };
  const getUserHomeSearchHistory = reactExports.useMemo(() => {
    return (appUserInfo.historicalSearch || {})[brandId || "home"] || [];
  }, [appUserInfo.historicalSearch]);
  const clearSearchHistory = () => {
    userController.recordHistorySearch({
      key: brandId || "home",
      clear: true
    }).then((res) => res && updateLoginerUserInfo(appUserInfo.address)).finally(contentRefresh);
  };
  const getOverallI18n = () => {
    const sortTypeI18n = {
      [GoodsSortType.overall]: () => overall(),
      [GoodsSortType.sales]: () => sales(),
      [GoodsSortType.toHigh]: () => price_low_to_high(),
      [GoodsSortType.toLow]: () => price_high_to_low()
    };
    if (sortType === GoodsSortType.sales) {
      return overall();
    }
    return sortTypeI18n[sortType]();
  };
  const goodsListFactory = (sortType2) => usePageQueryState([], 1, async (content, page) => {
    const result = await adminApi.goods.searchGoodsList.query({
      page,
      pageSize: 20,
      status: 1,
      brandId,
      goodsSort: sortType2,
      query: searchContent
    });
    content.push(...result.data);
    return {
      content,
      nextPage: page + 1,
      end: content.length >= result.total
    };
  });
  const goodsListHub = {
    [GoodsSortType.overall]: goodsListFactory(GoodsSortType.overall),
    [GoodsSortType.sales]: goodsListFactory(GoodsSortType.sales),
    [GoodsSortType.toHigh]: goodsListFactory(GoodsSortType.toHigh),
    [GoodsSortType.toLow]: goodsListFactory(GoodsSortType.toLow)
  };
  const goodsList = goodsListHub[sortType];
  reactExports.useEffect(() => {
    if (showRecordOrGoods === "goods") {
      goodsList.loadFirst();
    }
  }, [sortType]);
  return /* @__PURE__ */ React.createElement(
    Page,
    {
      name: "home-search",
      className: "bg-background",
      ...goodsList.f7PageInfiniteProps
    },
    /* @__PURE__ */ React.createElement(Navbar, { backLink: true, color: "white", className: "text-white" }, /* @__PURE__ */ React.createElement(NavTitle, { className: "w-full" }, /* @__PURE__ */ React.createElement(
      Searchbar,
      {
        disableButton: false,
        disableButtonText: "Cancel",
        placeholder: brandId ? search_for_goods_of_this_brand() : please_enter_search_content(),
        clearButton: false,
        value: searchContent,
        onChange: searchContentChange,
        onSubmit: (event) => {
          event?.target?.querySelector?.("input")?.blur();
          handleSearch();
        },
        onFocus: () => setShowRecordOrGoods("record"),
        className: "m-0",
        style: {
          "--f7-searchbar-input-font-size": "0.875rem",
          backdropFilter: "none",
          "--f7-bars-bg-color-rgb": "transparent"
        }
      }
    )), /* @__PURE__ */ React.createElement(NavRight, null, /* @__PURE__ */ React.createElement(
      Button,
      {
        onClick: () => handleSearch(),
        disabled: showRecordOrGoods === "goods",
        style: { "--f7-button-text-color": colors["black"] },
        className: "bg-primary px-4 text-sm text-black"
      },
      search()
    ))),
    /* @__PURE__ */ React.createElement(
      "div",
      {
        className: `bg-background fixed left-0 top-0 z-10 h-full w-full overflow-scroll pt-[var(--f7-page-navbar-offset)] ${showRecordOrGoods === "goods" && "hidden"}`
      },
      /* @__PURE__ */ React.createElement("div", { className: "mb-2 flex w-full items-center justify-between px-4 pt-2" }, /* @__PURE__ */ React.createElement("span", null, historical_search()), !!getUserHomeSearchHistory.length && /* @__PURE__ */ React.createElement("button", { className: "w-auto px-2", onClick: () => setOpenConfirmDialog(true) }, /* @__PURE__ */ React.createElement(Icon, { f7: "trash", size: 16 }))),
      /* @__PURE__ */ React.createElement("div", { className: "flex w-full flex-wrap px-4 pb-5" }, getUserHomeSearchHistory.map((value, index) => {
        return /* @__PURE__ */ React.createElement(
          "button",
          {
            key: value + index,
            onClick: () => handleSearch(value),
            className: "bg-pop-background mb-2 mr-2 w-auto max-w-full rounded-full py-1 text-sm"
          },
          /* @__PURE__ */ React.createElement("div", { className: "mx-4 max-w-full truncate" }, " ", value)
        );
      }))
    ),
    /* @__PURE__ */ React.createElement(React.Fragment, null, /* @__PURE__ */ React.createElement(BlockTitle, { className: "my-2 text-white" }, /* @__PURE__ */ React.createElement("div", { className: "grid grid-cols-2" }, /* @__PURE__ */ React.createElement(
      Button,
      {
        popoverOpen: ".search-sotr-popover-menu",
        className: `text-sm ${sortType !== GoodsSortType.sales ? "text-primary" : "text-subtext"}`
      },
      getOverallI18n(),
      /* @__PURE__ */ React.createElement(
        Popover,
        {
          ref: useCustomMutableRef((it) => {
            it.f7Popover().backdropEl.classList.add(
              "bg-pop-background/10",
              "backdrop-contrast-75"
              // 降低背景对比度
            );
          }),
          arrow: true,
          style: {
            "--f7-popover-bg-color": colors["pop-background"] + "ee"
          },
          verticalPosition: "bottom",
          className: "search-sotr-popover-menu drop-shadow-spread-primary backdrop-blur-sm"
        },
        /* @__PURE__ */ React.createElement(List, null, /* @__PURE__ */ React.createElement(ListItem, null, /* @__PURE__ */ React.createElement(
          Link,
          {
            popoverClose: true,
            className: `w-full justify-start text-xs ${sortType === GoodsSortType.overall && "text-primary"}`,
            onClick: () => setSortType(GoodsSortType.overall)
          },
          overall()
        )), /* @__PURE__ */ React.createElement(ListItem, null, /* @__PURE__ */ React.createElement(
          Link,
          {
            popoverClose: true,
            className: `w-full justify-start text-xs ${sortType === GoodsSortType.toHigh && "text-primary"}`,
            onClick: () => setSortType(GoodsSortType.toHigh)
          },
          price_low_to_high()
        )), /* @__PURE__ */ React.createElement(ListItem, null, /* @__PURE__ */ React.createElement(
          Link,
          {
            popoverClose: true,
            className: `w-full justify-start text-xs ${sortType === GoodsSortType.toLow && "text-primary"}`,
            onClick: () => setSortType(GoodsSortType.toLow)
          },
          price_high_to_low()
        )))
      )
    ), /* @__PURE__ */ React.createElement(
      Button,
      {
        className: `text-sm ${sortType === GoodsSortType.sales ? "text-primary" : "text-subtext"}`,
        onClick: () => setSortType(GoodsSortType.sales)
      },
      sales()
    ))), /* @__PURE__ */ React.createElement(Block, { className: "mt-4" }, goodsList.render({
      loading() {
        return /* @__PURE__ */ React.createElement(LoadingPageData, null);
      },
      content(data) {
        if (data.length === 0) {
          return /* @__PURE__ */ React.createElement(NoData, null);
        }
        return /* @__PURE__ */ React.createElement("div", { className: "medium-grid-cols-4 grid-gap grid grid-cols-2" }, data.map((item, index, list) => /* @__PURE__ */ React.createElement(SlideInDownListItem, { group: list, key: item.goodsId, index, className: "size-full" }, /* @__PURE__ */ React.createElement(GoodsItem, { goods: item, ...args }))));
      }
    }))),
    /* @__PURE__ */ React.createElement(
      ConfirmDialog,
      {
        open: openConfirmDialog,
        onRequireClose: setOpenConfirmDialog,
        onConfirmCallback: clearSearchHistory,
        confirmText: confirm()
      },
      are_you_sure_to_delete_all_historical_records()
    )
  );
});
export {
  homeSearch_page as default
};
