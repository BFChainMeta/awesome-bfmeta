const bitcoin = {
  messagePrefix: "Bitcoin Signed Message:\n",
  bech32: "bc",
  bip32: {
    public: 76067358,
    private: 76066276
  },
  pubKeyHash: 0,
  scriptHash: 5,
  wif: 128
};
const regtest = {
  messagePrefix: "Bitcoin Signed Message:\n",
  bech32: "bcrt",
  bip32: {
    public: 70617039,
    private: 70615956
  },
  pubKeyHash: 111,
  scriptHash: 196,
  wif: 239
};
const testnet = {
  messagePrefix: "Bitcoin Signed Message:\n",
  bech32: "tb",
  bip32: {
    public: 70617039,
    private: 70615956
  },
  pubKeyHash: 111,
  scriptHash: 196,
  wif: 239
};
export {
  bitcoin as b,
  regtest as r,
  testnet as t
};
