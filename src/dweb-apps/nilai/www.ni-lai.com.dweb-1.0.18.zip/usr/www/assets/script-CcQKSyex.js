import { B as Buffer$1 } from "./index-BgMR6XJ4.js";
import { OPS, REVERSE_OPS } from "./ops-DRP2Obq2.js";
import { dv as Buffer$2 } from "./index-DAk_nVWR.js";
import { t as typeforce$2 } from "./typeforce-BXjzjt-d.js";
function check(buffer) {
  if (buffer.length < 8)
    return false;
  if (buffer.length > 72)
    return false;
  if (buffer[0] !== 48)
    return false;
  if (buffer[1] !== buffer.length - 2)
    return false;
  if (buffer[2] !== 2)
    return false;
  const lenR = buffer[3];
  if (lenR === 0)
    return false;
  if (5 + lenR >= buffer.length)
    return false;
  if (buffer[4 + lenR] !== 2)
    return false;
  const lenS = buffer[5 + lenR];
  if (lenS === 0)
    return false;
  if (6 + lenR + lenS !== buffer.length)
    return false;
  if (buffer[4] & 128)
    return false;
  if (lenR > 1 && buffer[4] === 0 && !(buffer[5] & 128))
    return false;
  if (buffer[lenR + 6] & 128)
    return false;
  if (lenS > 1 && buffer[lenR + 6] === 0 && !(buffer[lenR + 7] & 128))
    return false;
  return true;
}
function decode$3(buffer) {
  if (buffer.length < 8)
    throw new Error("DER sequence length is too short");
  if (buffer.length > 72)
    throw new Error("DER sequence length is too long");
  if (buffer[0] !== 48)
    throw new Error("Expected DER sequence");
  if (buffer[1] !== buffer.length - 2)
    throw new Error("DER sequence length is invalid");
  if (buffer[2] !== 2)
    throw new Error("Expected DER integer");
  const lenR = buffer[3];
  if (lenR === 0)
    throw new Error("R length is zero");
  if (5 + lenR >= buffer.length)
    throw new Error("R length is too long");
  if (buffer[4 + lenR] !== 2)
    throw new Error("Expected DER integer (2)");
  const lenS = buffer[5 + lenR];
  if (lenS === 0)
    throw new Error("S length is zero");
  if (6 + lenR + lenS !== buffer.length)
    throw new Error("S length is invalid");
  if (buffer[4] & 128)
    throw new Error("R value is negative");
  if (lenR > 1 && buffer[4] === 0 && !(buffer[5] & 128))
    throw new Error("R value excessively padded");
  if (buffer[lenR + 6] & 128)
    throw new Error("S value is negative");
  if (lenS > 1 && buffer[lenR + 6] === 0 && !(buffer[lenR + 7] & 128))
    throw new Error("S value excessively padded");
  return {
    r: buffer.slice(4, 4 + lenR),
    s: buffer.slice(6 + lenR)
  };
}
function encode$3(r, s) {
  const lenR = r.length;
  const lenS = s.length;
  if (lenR === 0)
    throw new Error("R length is zero");
  if (lenS === 0)
    throw new Error("S length is zero");
  if (lenR > 33)
    throw new Error("R length is too long");
  if (lenS > 33)
    throw new Error("S length is too long");
  if (r[0] & 128)
    throw new Error("R value is negative");
  if (s[0] & 128)
    throw new Error("S value is negative");
  if (lenR > 1 && r[0] === 0 && !(r[1] & 128))
    throw new Error("R value excessively padded");
  if (lenS > 1 && s[0] === 0 && !(s[1] & 128))
    throw new Error("S value excessively padded");
  const signature2 = Buffer$1.allocUnsafe(6 + lenR + lenS);
  signature2[0] = 48;
  signature2[1] = signature2.length - 2;
  signature2[2] = 2;
  signature2[3] = r.length;
  r.copy(signature2, 4);
  signature2[4 + lenR] = 2;
  signature2[5 + lenR] = s.length;
  s.copy(signature2, 6 + lenR);
  return signature2;
}
function encodingLength(i) {
  return i < OPS.OP_PUSHDATA1 ? 1 : i <= 255 ? 2 : i <= 65535 ? 3 : 5;
}
function encode$2(buffer, num, offset) {
  const size = encodingLength(num);
  if (size === 1) {
    buffer.writeUInt8(num, offset);
  } else if (size === 2) {
    buffer.writeUInt8(OPS.OP_PUSHDATA1, offset);
    buffer.writeUInt8(num, offset + 1);
  } else if (size === 3) {
    buffer.writeUInt8(OPS.OP_PUSHDATA2, offset);
    buffer.writeUInt16LE(num, offset + 1);
  } else {
    buffer.writeUInt8(OPS.OP_PUSHDATA4, offset);
    buffer.writeUInt32LE(num, offset + 1);
  }
  return size;
}
function decode$2(buffer, offset) {
  const opcode = buffer.readUInt8(offset);
  let num;
  let size;
  if (opcode < OPS.OP_PUSHDATA1) {
    num = opcode;
    size = 1;
  } else if (opcode === OPS.OP_PUSHDATA1) {
    if (offset + 2 > buffer.length)
      return null;
    num = buffer.readUInt8(offset + 1);
    size = 2;
  } else if (opcode === OPS.OP_PUSHDATA2) {
    if (offset + 3 > buffer.length)
      return null;
    num = buffer.readUInt16LE(offset + 1);
    size = 3;
  } else {
    if (offset + 5 > buffer.length)
      return null;
    if (opcode !== OPS.OP_PUSHDATA4)
      throw new Error("Unexpected opcode");
    num = buffer.readUInt32LE(offset + 1);
    size = 5;
  }
  return {
    opcode,
    number: num,
    size
  };
}
function decode$1(buffer, maxLength, minimal) {
  maxLength = maxLength || 4;
  minimal = minimal === void 0 ? true : minimal;
  const length = buffer.length;
  if (length === 0)
    return 0;
  if (length > maxLength)
    throw new TypeError("Script number overflow");
  if (minimal) {
    if ((buffer[length - 1] & 127) === 0) {
      if (length <= 1 || (buffer[length - 2] & 128) === 0)
        throw new Error("Non-minimally encoded script number");
    }
  }
  if (length === 5) {
    const a = buffer.readUInt32LE(0);
    const b = buffer.readUInt8(4);
    if (b & 128)
      return -((b & ~128) * 4294967296 + a);
    return b * 4294967296 + a;
  }
  let result = 0;
  for (let i = 0; i < length; ++i) {
    result |= buffer[i] << 8 * i;
  }
  if (buffer[length - 1] & 128)
    return -(result & ~(128 << 8 * (length - 1)));
  return result;
}
function scriptNumSize(i) {
  return i > 2147483647 ? 5 : i > 8388607 ? 4 : i > 32767 ? 3 : i > 127 ? 2 : i > 0 ? 1 : 0;
}
function encode$1(_number) {
  let value = Math.abs(_number);
  const size = scriptNumSize(value);
  const buffer = Buffer$2.allocUnsafe(size);
  const negative = _number < 0;
  for (let i = 0; i < size; ++i) {
    buffer.writeUInt8(value & 255, i);
    value >>= 8;
  }
  if (buffer[size - 1] & 128) {
    buffer.writeUInt8(negative ? 128 : 0, size - 1);
  } else if (negative) {
    buffer[size - 1] |= 128;
  }
  return buffer;
}
const scriptNumber = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  decode: decode$1,
  encode: encode$1
}, Symbol.toStringTag, { value: "Module" }));
const ZERO32 = Buffer$1.alloc(32, 0);
const EC_P = Buffer$1.from("fffffffffffffffffffffffffffffffffffffffffffffffffffffffefffffc2f", "hex");
function stacksEqual(a, b) {
  if (a.length !== b.length)
    return false;
  return a.every((x, i) => {
    return x.equals(b[i]);
  });
}
function isPoint(p) {
  if (!Buffer$1.isBuffer(p))
    return false;
  if (p.length < 33)
    return false;
  const t = p[0];
  const x = p.subarray(1, 33);
  if (x.compare(ZERO32) === 0)
    return false;
  if (x.compare(EC_P) >= 0)
    return false;
  if ((t === 2 || t === 3) && p.length === 33) {
    return true;
  }
  const y = p.subarray(33);
  if (y.compare(ZERO32) === 0)
    return false;
  if (y.compare(EC_P) >= 0)
    return false;
  if (t === 4 && p.length === 65)
    return true;
  return false;
}
const UINT31_MAX = Math.pow(2, 31) - 1;
function UInt31(value) {
  return typeforce$2.UInt32(value) && value <= UINT31_MAX;
}
function BIP32Path(value) {
  return typeforce$2.String(value) && !!value.match(/^(m\/)?(\d+'?\/)*\d+'?$/);
}
BIP32Path.toJSON = () => {
  return "BIP32 derivation path";
};
function Signer(obj) {
  return (typeforce$2.Buffer(obj.publicKey) || typeof obj.getPublicKey === "function") && typeof obj.sign === "function";
}
const SATOSHI_MAX = 21 * 1e14;
function Satoshi(value) {
  return typeforce$2.UInt53(value) && value <= SATOSHI_MAX;
}
const ECPoint = typeforce$2.quacksLike("Point");
const Network = typeforce$2.compile({
  messagePrefix: typeforce$2.anyOf(typeforce$2.Buffer, typeforce$2.String),
  bip32: {
    public: typeforce$2.UInt32,
    private: typeforce$2.UInt32
  },
  pubKeyHash: typeforce$2.UInt8,
  scriptHash: typeforce$2.UInt8,
  wif: typeforce$2.UInt8
});
const TAPLEAF_VERSION_MASK = 254;
function isTapleaf(o) {
  if (!o || !("output" in o))
    return false;
  if (!Buffer$1.isBuffer(o.output))
    return false;
  if (o.version !== void 0)
    return (o.version & TAPLEAF_VERSION_MASK) === o.version;
  return true;
}
function isTaptree(scriptTree) {
  if (!Array(scriptTree))
    return isTapleaf(scriptTree);
  if (scriptTree.length !== 2)
    return false;
  return scriptTree.every((t) => isTaptree(t));
}
const Buffer256bit = typeforce$2.BufferN(32);
const Hash160bit = typeforce$2.BufferN(20);
const Hash256bit = typeforce$2.BufferN(32);
const Number = typeforce$2.Number;
const Array = typeforce$2.Array;
const Boolean = typeforce$2.Boolean;
const String = typeforce$2.String;
const Buffer = typeforce$2.Buffer;
const Hex = typeforce$2.Hex;
const maybe = typeforce$2.maybe;
const tuple = typeforce$2.tuple;
const UInt8 = typeforce$2.UInt8;
const UInt32 = typeforce$2.UInt32;
const Function = typeforce$2.Function;
const BufferN = typeforce$2.BufferN;
const Null = typeforce$2.Null;
const oneOf = typeforce$2.oneOf;
const Nil = typeforce$2.Nil;
const anyOf = typeforce$2.anyOf;
const types = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  Array,
  BIP32Path,
  Boolean,
  Buffer,
  Buffer256bit,
  BufferN,
  ECPoint,
  Function,
  Hash160bit,
  Hash256bit,
  Hex,
  Network,
  Nil,
  Null,
  Number,
  Satoshi,
  Signer,
  String,
  TAPLEAF_VERSION_MASK,
  UInt31,
  UInt32,
  UInt8,
  anyOf,
  isPoint,
  isTapleaf,
  isTaptree,
  maybe,
  oneOf,
  stacksEqual,
  tuple,
  typeforce: typeforce$2
}, Symbol.toStringTag, { value: "Module" }));
const { typeforce: typeforce$1 } = types;
const ZERO = Buffer$1.alloc(1, 0);
function toDER(x) {
  let i = 0;
  while (x[i] === 0)
    ++i;
  if (i === x.length)
    return ZERO;
  x = x.slice(i);
  if (x[0] & 128)
    return Buffer$1.concat([ZERO, x], 1 + x.length);
  return x;
}
function fromDER(x) {
  if (x[0] === 0)
    x = x.slice(1);
  const buffer = Buffer$1.alloc(32, 0);
  const bstart = Math.max(0, 32 - x.length);
  x.copy(buffer, bstart);
  return buffer;
}
function decode(buffer) {
  const hashType = buffer.readUInt8(buffer.length - 1);
  const hashTypeMod = hashType & ~128;
  if (hashTypeMod <= 0 || hashTypeMod >= 4)
    throw new Error("Invalid hashType " + hashType);
  const decoded = decode$3(buffer.slice(0, -1));
  const r = fromDER(decoded.r);
  const s = fromDER(decoded.s);
  const signature2 = Buffer$1.concat([r, s], 64);
  return { signature: signature2, hashType };
}
function encode(signature2, hashType) {
  typeforce$1({
    signature: BufferN(64),
    hashType: UInt8
  }, { signature: signature2, hashType });
  const hashTypeMod = hashType & ~128;
  if (hashTypeMod <= 0 || hashTypeMod >= 4)
    throw new Error("Invalid hashType " + hashType);
  const hashTypeBuffer = Buffer$1.allocUnsafe(1);
  hashTypeBuffer.writeUInt8(hashType, 0);
  const r = toDER(signature2.slice(0, 32));
  const s = toDER(signature2.slice(32, 64));
  return Buffer$1.concat([encode$3(r, s), hashTypeBuffer]);
}
const scriptSignature = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  decode,
  encode
}, Symbol.toStringTag, { value: "Module" }));
const { typeforce } = types;
const OP_INT_BASE = OPS.OP_RESERVED;
function isOPInt(value) {
  return Number(value) && (value === OPS.OP_0 || value >= OPS.OP_1 && value <= OPS.OP_16 || value === OPS.OP_1NEGATE);
}
function isPushOnlyChunk(value) {
  return Buffer(value) || isOPInt(value);
}
function isPushOnly(value) {
  return Array(value) && value.every(isPushOnlyChunk);
}
function asMinimalOP(buffer) {
  if (buffer.length === 0)
    return OPS.OP_0;
  if (buffer.length !== 1)
    return;
  if (buffer[0] >= 1 && buffer[0] <= 16)
    return OP_INT_BASE + buffer[0];
  if (buffer[0] === 129)
    return OPS.OP_1NEGATE;
}
function chunksIsBuffer(buf) {
  return Buffer$1.isBuffer(buf);
}
function chunksIsArray(buf) {
  return Array(buf);
}
function singleChunkIsBuffer(buf) {
  return Buffer$1.isBuffer(buf);
}
function compile(chunks) {
  if (chunksIsBuffer(chunks))
    return chunks;
  typeforce(Array, chunks);
  const bufferSize = chunks.reduce((accum, chunk) => {
    if (singleChunkIsBuffer(chunk)) {
      if (chunk.length === 1 && asMinimalOP(chunk) !== void 0) {
        return accum + 1;
      }
      return accum + encodingLength(chunk.length) + chunk.length;
    }
    return accum + 1;
  }, 0);
  const buffer = Buffer$1.allocUnsafe(bufferSize);
  let offset = 0;
  chunks.forEach((chunk) => {
    if (singleChunkIsBuffer(chunk)) {
      const opcode = asMinimalOP(chunk);
      if (opcode !== void 0) {
        buffer.writeUInt8(opcode, offset);
        offset += 1;
        return;
      }
      offset += encode$2(buffer, chunk.length, offset);
      chunk.copy(buffer, offset);
      offset += chunk.length;
    } else {
      buffer.writeUInt8(chunk, offset);
      offset += 1;
    }
  });
  if (offset !== buffer.length)
    throw new Error("Could not decode chunks");
  return buffer;
}
function decompile(buffer) {
  if (chunksIsArray(buffer))
    return buffer;
  typeforce(Buffer, buffer);
  const chunks = [];
  let i = 0;
  while (i < buffer.length) {
    const opcode = buffer[i];
    if (opcode > OPS.OP_0 && opcode <= OPS.OP_PUSHDATA4) {
      const d = decode$2(buffer, i);
      if (d === null)
        return null;
      i += d.size;
      if (i + d.number > buffer.length)
        return null;
      const data = buffer.slice(i, i + d.number);
      i += d.number;
      const op = asMinimalOP(data);
      if (op !== void 0) {
        chunks.push(op);
      } else {
        chunks.push(data);
      }
    } else {
      chunks.push(opcode);
      i += 1;
    }
  }
  return chunks;
}
function toASM(chunks) {
  if (chunksIsBuffer(chunks)) {
    chunks = decompile(chunks);
  }
  return chunks.map((chunk) => {
    if (singleChunkIsBuffer(chunk)) {
      const op = asMinimalOP(chunk);
      if (op === void 0)
        return chunk.toString("hex");
      chunk = op;
    }
    return REVERSE_OPS[chunk];
  }).join(" ");
}
function fromASM(asm) {
  typeforce(String, asm);
  return compile(asm.split(" ").map((chunkStr) => {
    if (OPS[chunkStr] !== void 0)
      return OPS[chunkStr];
    typeforce(Hex, chunkStr);
    return Buffer$1.from(chunkStr, "hex");
  }));
}
function toStack(chunks) {
  chunks = decompile(chunks);
  typeforce(isPushOnly, chunks);
  return chunks.map((op) => {
    if (singleChunkIsBuffer(op))
      return op;
    if (op === OPS.OP_0)
      return Buffer$1.allocUnsafe(0);
    return encode$1(op - OP_INT_BASE);
  });
}
function isCanonicalPubKey(buffer) {
  return isPoint(buffer);
}
function isDefinedHashType(hashType) {
  const hashTypeMod = hashType & ~128;
  return hashTypeMod > 0 && hashTypeMod < 4;
}
function isCanonicalScriptSignature(buffer) {
  if (!Buffer$1.isBuffer(buffer))
    return false;
  if (!isDefinedHashType(buffer[buffer.length - 1]))
    return false;
  return check(buffer.slice(0, -1));
}
const number = scriptNumber;
const signature = scriptSignature;
const script = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  OPS,
  compile,
  decompile,
  fromASM,
  isCanonicalPubKey,
  isCanonicalScriptSignature,
  isDefinedHashType,
  isPushOnly,
  number,
  signature,
  toASM,
  toStack
}, Symbol.toStringTag, { value: "Module" }));
export {
  Buffer as B,
  Hash160bit as H,
  Null as N,
  Satoshi as S,
  TAPLEAF_VERSION_MASK as T,
  UInt8 as U,
  isCanonicalScriptSignature as a,
  isPushOnly as b,
  compile as c,
  decompile as d,
  isTapleaf as e,
  isTaptree as f,
  tuple as g,
  toASM as h,
  isPoint as i,
  types as j,
  UInt32 as k,
  Hash256bit as l,
  maybe as m,
  Number as n,
  signature as o,
  isCanonicalPubKey as p,
  script as q,
  stacksEqual as s,
  toStack as t
};
