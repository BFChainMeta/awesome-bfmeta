import { B as Buffer, r as requireBuffer } from "./index-BgMR6XJ4.js";
import { dx as getDefaultExportFromCjs } from "./index-DAk_nVWR.js";
import { g as varuintBitcoinExports, h as fromOutputScript, t as toOutputScript, e as p2wsh, c as p2sh, b as p2pkh, d as p2wpkh, a as p2ms } from "./address-myg3N2yt.js";
import { g as tuple, B as Buffer$1, k as UInt32, j as types, l as Hash256bit, m as maybe, N as Null, S as Satoshi, n as Number$1, c as compile, d as decompile, o as signature, a as isCanonicalScriptSignature, p as isCanonicalPubKey } from "./script-CcQKSyex.js";
import { hash256, sha256, taggedHash, hash160 } from "./crypto-CIvSaiGD.js";
import { b as bitcoin } from "./networks-C0ceHyyb.js";
import { p as p2pk } from "./p2pk-X_Z_V9g_.js";
import { OPS } from "./ops-DRP2Obq2.js";
import "./typeforce-BXjzjt-d.js";
import "./index-mSLBfEgs.js";
import "./sha256-C2OttJA4.js";
import "./WASMInterface-BIOcGvqx.js";
import "./index-DzX_QLg7.js";
import "./ripemd160-DVjwZ6Kb.js";
import "./sha1-CAxM_YzN.js";
const { typeforce: typeforce$1 } = types;
function verifuint(value, max) {
  if (typeof value !== "number")
    throw new Error("cannot write a non-number as a number");
  if (value < 0)
    throw new Error("specified a negative value for writing an unsigned value");
  if (value > max)
    throw new Error("RangeError: value out of range");
  if (Math.floor(value) !== value)
    throw new Error("value has a fractional component");
}
function readUInt64LE(buffer, offset) {
  const a = buffer.readUInt32LE(offset);
  let b = buffer.readUInt32LE(offset + 4);
  b *= 4294967296;
  verifuint(b + a, 9007199254740991);
  return b + a;
}
function writeUInt64LE(buffer, value, offset) {
  verifuint(value, 9007199254740991);
  buffer.writeInt32LE(value & -1, offset);
  buffer.writeUInt32LE(Math.floor(value / 4294967296), offset + 4);
  return offset + 8;
}
function reverseBuffer(buffer) {
  if (buffer.length < 1)
    return buffer;
  let j = buffer.length - 1;
  let tmp = 0;
  for (let i = 0; i < buffer.length / 2; i++) {
    tmp = buffer[i];
    buffer[i] = buffer[j];
    buffer[j] = tmp;
    j--;
  }
  return buffer;
}
function cloneBuffer(buffer) {
  const clone = Buffer.allocUnsafe(buffer.length);
  buffer.copy(clone);
  return clone;
}
class BufferWriter {
  static withCapacity(size) {
    return new BufferWriter(Buffer.alloc(size));
  }
  constructor(buffer, offset = 0) {
    this.buffer = buffer;
    this.offset = offset;
    typeforce$1(tuple(Buffer$1, UInt32), [buffer, offset]);
  }
  writeUInt8(i) {
    this.offset = this.buffer.writeUInt8(i, this.offset);
  }
  writeInt32(i) {
    this.offset = this.buffer.writeInt32LE(i, this.offset);
  }
  writeUInt32(i) {
    this.offset = this.buffer.writeUInt32LE(i, this.offset);
  }
  writeUInt64(i) {
    this.offset = writeUInt64LE(this.buffer, i, this.offset);
  }
  writeVarInt(i) {
    varuintBitcoinExports.encode(i, this.buffer, this.offset);
    this.offset += varuintBitcoinExports.encode.bytes;
  }
  writeSlice(slice) {
    if (this.buffer.length < this.offset + slice.length) {
      throw new Error("Cannot write slice out of bounds");
    }
    this.offset += slice.copy(this.buffer, this.offset);
  }
  writeVarSlice(slice) {
    this.writeVarInt(slice.length);
    this.writeSlice(slice);
  }
  writeVector(vector) {
    this.writeVarInt(vector.length);
    vector.forEach((buf) => this.writeVarSlice(buf));
  }
  end() {
    if (this.buffer.length === this.offset) {
      return this.buffer;
    }
    throw new Error(`buffer size ${this.buffer.length}, offset ${this.offset}`);
  }
}
class BufferReader {
  constructor(buffer, offset = 0) {
    this.buffer = buffer;
    this.offset = offset;
    typeforce$1(tuple(Buffer$1, UInt32), [buffer, offset]);
  }
  readUInt8() {
    const result = this.buffer.readUInt8(this.offset);
    this.offset++;
    return result;
  }
  readInt32() {
    const result = this.buffer.readInt32LE(this.offset);
    this.offset += 4;
    return result;
  }
  readUInt32() {
    const result = this.buffer.readUInt32LE(this.offset);
    this.offset += 4;
    return result;
  }
  readUInt64() {
    const result = readUInt64LE(this.buffer, this.offset);
    this.offset += 8;
    return result;
  }
  readVarInt() {
    const vi = varuintBitcoinExports.decode(this.buffer, this.offset);
    this.offset += varuintBitcoinExports.decode.bytes;
    return vi;
  }
  readSlice(n) {
    if (this.buffer.length < this.offset + n) {
      throw new Error("Cannot read slice out of bounds");
    }
    const result = this.buffer.slice(this.offset, this.offset + n);
    this.offset += n;
    return result;
  }
  readVarSlice() {
    return this.readSlice(this.readVarInt());
  }
  readVector() {
    const count = this.readVarInt();
    const vector = [];
    for (let i = 0; i < count; i++)
      vector.push(this.readVarSlice());
    return vector;
  }
}
var psbt = {};
var combiner = {};
var parser = {};
var fromBuffer = {};
var converter = {};
var typeFields = {};
var hasRequiredTypeFields;
function requireTypeFields() {
  if (hasRequiredTypeFields) return typeFields;
  hasRequiredTypeFields = 1;
  (function(exports) {
    Object.defineProperty(exports, "__esModule", { value: true });
    (function(GlobalTypes) {
      GlobalTypes[GlobalTypes["UNSIGNED_TX"] = 0] = "UNSIGNED_TX";
      GlobalTypes[GlobalTypes["GLOBAL_XPUB"] = 1] = "GLOBAL_XPUB";
    })(exports.GlobalTypes || (exports.GlobalTypes = {}));
    exports.GLOBAL_TYPE_NAMES = ["unsignedTx", "globalXpub"];
    (function(InputTypes) {
      InputTypes[InputTypes["NON_WITNESS_UTXO"] = 0] = "NON_WITNESS_UTXO";
      InputTypes[InputTypes["WITNESS_UTXO"] = 1] = "WITNESS_UTXO";
      InputTypes[InputTypes["PARTIAL_SIG"] = 2] = "PARTIAL_SIG";
      InputTypes[InputTypes["SIGHASH_TYPE"] = 3] = "SIGHASH_TYPE";
      InputTypes[InputTypes["REDEEM_SCRIPT"] = 4] = "REDEEM_SCRIPT";
      InputTypes[InputTypes["WITNESS_SCRIPT"] = 5] = "WITNESS_SCRIPT";
      InputTypes[InputTypes["BIP32_DERIVATION"] = 6] = "BIP32_DERIVATION";
      InputTypes[InputTypes["FINAL_SCRIPTSIG"] = 7] = "FINAL_SCRIPTSIG";
      InputTypes[InputTypes["FINAL_SCRIPTWITNESS"] = 8] = "FINAL_SCRIPTWITNESS";
      InputTypes[InputTypes["POR_COMMITMENT"] = 9] = "POR_COMMITMENT";
      InputTypes[InputTypes["TAP_KEY_SIG"] = 19] = "TAP_KEY_SIG";
      InputTypes[InputTypes["TAP_SCRIPT_SIG"] = 20] = "TAP_SCRIPT_SIG";
      InputTypes[InputTypes["TAP_LEAF_SCRIPT"] = 21] = "TAP_LEAF_SCRIPT";
      InputTypes[InputTypes["TAP_BIP32_DERIVATION"] = 22] = "TAP_BIP32_DERIVATION";
      InputTypes[InputTypes["TAP_INTERNAL_KEY"] = 23] = "TAP_INTERNAL_KEY";
      InputTypes[InputTypes["TAP_MERKLE_ROOT"] = 24] = "TAP_MERKLE_ROOT";
    })(exports.InputTypes || (exports.InputTypes = {}));
    exports.INPUT_TYPE_NAMES = [
      "nonWitnessUtxo",
      "witnessUtxo",
      "partialSig",
      "sighashType",
      "redeemScript",
      "witnessScript",
      "bip32Derivation",
      "finalScriptSig",
      "finalScriptWitness",
      "porCommitment",
      "tapKeySig",
      "tapScriptSig",
      "tapLeafScript",
      "tapBip32Derivation",
      "tapInternalKey",
      "tapMerkleRoot"
    ];
    (function(OutputTypes) {
      OutputTypes[OutputTypes["REDEEM_SCRIPT"] = 0] = "REDEEM_SCRIPT";
      OutputTypes[OutputTypes["WITNESS_SCRIPT"] = 1] = "WITNESS_SCRIPT";
      OutputTypes[OutputTypes["BIP32_DERIVATION"] = 2] = "BIP32_DERIVATION";
      OutputTypes[OutputTypes["TAP_INTERNAL_KEY"] = 5] = "TAP_INTERNAL_KEY";
      OutputTypes[OutputTypes["TAP_TREE"] = 6] = "TAP_TREE";
      OutputTypes[OutputTypes["TAP_BIP32_DERIVATION"] = 7] = "TAP_BIP32_DERIVATION";
    })(exports.OutputTypes || (exports.OutputTypes = {}));
    exports.OUTPUT_TYPE_NAMES = [
      "redeemScript",
      "witnessScript",
      "bip32Derivation",
      "tapInternalKey",
      "tapTree",
      "tapBip32Derivation"
    ];
  })(typeFields);
  return typeFields;
}
var globalXpub = {};
var hasRequiredGlobalXpub;
function requireGlobalXpub() {
  if (hasRequiredGlobalXpub) return globalXpub;
  hasRequiredGlobalXpub = 1;
  const { Buffer: Buffer2 } = requireBuffer();
  Object.defineProperty(globalXpub, "__esModule", { value: true });
  const typeFields_1 = requireTypeFields();
  const range2 = (n) => [...Array(n).keys()];
  function decode(keyVal) {
    if (keyVal.key[0] !== typeFields_1.GlobalTypes.GLOBAL_XPUB) {
      throw new Error(
        "Decode Error: could not decode globalXpub with key 0x" + keyVal.key.toString("hex")
      );
    }
    if (keyVal.key.length !== 79 || ![2, 3].includes(keyVal.key[46])) {
      throw new Error(
        "Decode Error: globalXpub has invalid extended pubkey in key 0x" + keyVal.key.toString("hex")
      );
    }
    if (keyVal.value.length / 4 % 1 !== 0) {
      throw new Error(
        "Decode Error: Global GLOBAL_XPUB value length should be multiple of 4"
      );
    }
    const extendedPubkey = keyVal.key.slice(1);
    const data = {
      masterFingerprint: keyVal.value.slice(0, 4),
      extendedPubkey,
      path: "m"
    };
    for (const i of range2(keyVal.value.length / 4 - 1)) {
      const val = keyVal.value.readUInt32LE(i * 4 + 4);
      const isHard = !!(val & 2147483648);
      const idx = val & 2147483647;
      data.path += "/" + idx.toString(10) + (isHard ? "'" : "");
    }
    return data;
  }
  globalXpub.decode = decode;
  function encode(data) {
    const head = Buffer2.from([typeFields_1.GlobalTypes.GLOBAL_XPUB]);
    const key = Buffer2.concat([head, data.extendedPubkey]);
    const splitPath = data.path.split("/");
    const value = Buffer2.allocUnsafe(splitPath.length * 4);
    data.masterFingerprint.copy(value, 0);
    let offset = 4;
    splitPath.slice(1).forEach((level) => {
      const isHard = level.slice(-1) === "'";
      let num = 2147483647 & parseInt(isHard ? level.slice(0, -1) : level, 10);
      if (isHard) num += 2147483648;
      value.writeUInt32LE(num, offset);
      offset += 4;
    });
    return {
      key,
      value
    };
  }
  globalXpub.encode = encode;
  globalXpub.expected = "{ masterFingerprint: Buffer; extendedPubkey: Buffer; path: string; }";
  function check(data) {
    const epk = data.extendedPubkey;
    const mfp = data.masterFingerprint;
    const p = data.path;
    return Buffer2.isBuffer(epk) && epk.length === 78 && [2, 3].indexOf(epk[45]) > -1 && Buffer2.isBuffer(mfp) && mfp.length === 4 && typeof p === "string" && !!p.match(/^m(\/\d+'?)*$/);
  }
  globalXpub.check = check;
  function canAddToArray(array, item, dupeSet) {
    const dupeString = item.extendedPubkey.toString("hex");
    if (dupeSet.has(dupeString)) return false;
    dupeSet.add(dupeString);
    return array.filter((v) => v.extendedPubkey.equals(item.extendedPubkey)).length === 0;
  }
  globalXpub.canAddToArray = canAddToArray;
  return globalXpub;
}
var unsignedTx = {};
var hasRequiredUnsignedTx;
function requireUnsignedTx() {
  if (hasRequiredUnsignedTx) return unsignedTx;
  hasRequiredUnsignedTx = 1;
  const { Buffer: Buffer2 } = requireBuffer();
  Object.defineProperty(unsignedTx, "__esModule", { value: true });
  const typeFields_1 = requireTypeFields();
  function encode(data) {
    return {
      key: Buffer2.from([typeFields_1.GlobalTypes.UNSIGNED_TX]),
      value: data.toBuffer()
    };
  }
  unsignedTx.encode = encode;
  return unsignedTx;
}
var finalScriptSig = {};
var hasRequiredFinalScriptSig;
function requireFinalScriptSig() {
  if (hasRequiredFinalScriptSig) return finalScriptSig;
  hasRequiredFinalScriptSig = 1;
  const { Buffer: Buffer2 } = requireBuffer();
  Object.defineProperty(finalScriptSig, "__esModule", { value: true });
  const typeFields_1 = requireTypeFields();
  function decode(keyVal) {
    if (keyVal.key[0] !== typeFields_1.InputTypes.FINAL_SCRIPTSIG) {
      throw new Error(
        "Decode Error: could not decode finalScriptSig with key 0x" + keyVal.key.toString("hex")
      );
    }
    return keyVal.value;
  }
  finalScriptSig.decode = decode;
  function encode(data) {
    const key = Buffer2.from([typeFields_1.InputTypes.FINAL_SCRIPTSIG]);
    return {
      key,
      value: data
    };
  }
  finalScriptSig.encode = encode;
  finalScriptSig.expected = "Buffer";
  function check(data) {
    return Buffer2.isBuffer(data);
  }
  finalScriptSig.check = check;
  function canAdd(currentData, newData) {
    return !!currentData && !!newData && currentData.finalScriptSig === void 0;
  }
  finalScriptSig.canAdd = canAdd;
  return finalScriptSig;
}
var finalScriptWitness = {};
var hasRequiredFinalScriptWitness;
function requireFinalScriptWitness() {
  if (hasRequiredFinalScriptWitness) return finalScriptWitness;
  hasRequiredFinalScriptWitness = 1;
  const { Buffer: Buffer2 } = requireBuffer();
  Object.defineProperty(finalScriptWitness, "__esModule", { value: true });
  const typeFields_1 = requireTypeFields();
  function decode(keyVal) {
    if (keyVal.key[0] !== typeFields_1.InputTypes.FINAL_SCRIPTWITNESS) {
      throw new Error(
        "Decode Error: could not decode finalScriptWitness with key 0x" + keyVal.key.toString("hex")
      );
    }
    return keyVal.value;
  }
  finalScriptWitness.decode = decode;
  function encode(data) {
    const key = Buffer2.from([typeFields_1.InputTypes.FINAL_SCRIPTWITNESS]);
    return {
      key,
      value: data
    };
  }
  finalScriptWitness.encode = encode;
  finalScriptWitness.expected = "Buffer";
  function check(data) {
    return Buffer2.isBuffer(data);
  }
  finalScriptWitness.check = check;
  function canAdd(currentData, newData) {
    return !!currentData && !!newData && currentData.finalScriptWitness === void 0;
  }
  finalScriptWitness.canAdd = canAdd;
  return finalScriptWitness;
}
var nonWitnessUtxo = {};
var hasRequiredNonWitnessUtxo;
function requireNonWitnessUtxo() {
  if (hasRequiredNonWitnessUtxo) return nonWitnessUtxo;
  hasRequiredNonWitnessUtxo = 1;
  const { Buffer: Buffer2 } = requireBuffer();
  Object.defineProperty(nonWitnessUtxo, "__esModule", { value: true });
  const typeFields_1 = requireTypeFields();
  function decode(keyVal) {
    if (keyVal.key[0] !== typeFields_1.InputTypes.NON_WITNESS_UTXO) {
      throw new Error(
        "Decode Error: could not decode nonWitnessUtxo with key 0x" + keyVal.key.toString("hex")
      );
    }
    return keyVal.value;
  }
  nonWitnessUtxo.decode = decode;
  function encode(data) {
    return {
      key: Buffer2.from([typeFields_1.InputTypes.NON_WITNESS_UTXO]),
      value: data
    };
  }
  nonWitnessUtxo.encode = encode;
  nonWitnessUtxo.expected = "Buffer";
  function check(data) {
    return Buffer2.isBuffer(data);
  }
  nonWitnessUtxo.check = check;
  function canAdd(currentData, newData) {
    return !!currentData && !!newData && currentData.nonWitnessUtxo === void 0;
  }
  nonWitnessUtxo.canAdd = canAdd;
  return nonWitnessUtxo;
}
var partialSig = {};
var hasRequiredPartialSig;
function requirePartialSig() {
  if (hasRequiredPartialSig) return partialSig;
  hasRequiredPartialSig = 1;
  const { Buffer: Buffer2 } = requireBuffer();
  Object.defineProperty(partialSig, "__esModule", { value: true });
  const typeFields_1 = requireTypeFields();
  function decode(keyVal) {
    if (keyVal.key[0] !== typeFields_1.InputTypes.PARTIAL_SIG) {
      throw new Error(
        "Decode Error: could not decode partialSig with key 0x" + keyVal.key.toString("hex")
      );
    }
    if (!(keyVal.key.length === 34 || keyVal.key.length === 66) || ![2, 3, 4].includes(keyVal.key[1])) {
      throw new Error(
        "Decode Error: partialSig has invalid pubkey in key 0x" + keyVal.key.toString("hex")
      );
    }
    const pubkey = keyVal.key.slice(1);
    return {
      pubkey,
      signature: keyVal.value
    };
  }
  partialSig.decode = decode;
  function encode(pSig) {
    const head = Buffer2.from([typeFields_1.InputTypes.PARTIAL_SIG]);
    return {
      key: Buffer2.concat([head, pSig.pubkey]),
      value: pSig.signature
    };
  }
  partialSig.encode = encode;
  partialSig.expected = "{ pubkey: Buffer; signature: Buffer; }";
  function check(data) {
    return Buffer2.isBuffer(data.pubkey) && Buffer2.isBuffer(data.signature) && [33, 65].includes(data.pubkey.length) && [2, 3, 4].includes(data.pubkey[0]) && isDerSigWithSighash(data.signature);
  }
  partialSig.check = check;
  function isDerSigWithSighash(buf) {
    if (!Buffer2.isBuffer(buf) || buf.length < 9) return false;
    if (buf[0] !== 48) return false;
    if (buf.length !== buf[1] + 3) return false;
    if (buf[2] !== 2) return false;
    const rLen = buf[3];
    if (rLen > 33 || rLen < 1) return false;
    if (buf[3 + rLen + 1] !== 2) return false;
    const sLen = buf[3 + rLen + 2];
    if (sLen > 33 || sLen < 1) return false;
    if (buf.length !== 3 + rLen + 2 + sLen + 2) return false;
    return true;
  }
  function canAddToArray(array, item, dupeSet) {
    const dupeString = item.pubkey.toString("hex");
    if (dupeSet.has(dupeString)) return false;
    dupeSet.add(dupeString);
    return array.filter((v) => v.pubkey.equals(item.pubkey)).length === 0;
  }
  partialSig.canAddToArray = canAddToArray;
  return partialSig;
}
var porCommitment = {};
var hasRequiredPorCommitment;
function requirePorCommitment() {
  if (hasRequiredPorCommitment) return porCommitment;
  hasRequiredPorCommitment = 1;
  const { Buffer: Buffer2 } = requireBuffer();
  Object.defineProperty(porCommitment, "__esModule", { value: true });
  const typeFields_1 = requireTypeFields();
  function decode(keyVal) {
    if (keyVal.key[0] !== typeFields_1.InputTypes.POR_COMMITMENT) {
      throw new Error(
        "Decode Error: could not decode porCommitment with key 0x" + keyVal.key.toString("hex")
      );
    }
    return keyVal.value.toString("utf8");
  }
  porCommitment.decode = decode;
  function encode(data) {
    const key = Buffer2.from([typeFields_1.InputTypes.POR_COMMITMENT]);
    return {
      key,
      value: Buffer2.from(data, "utf8")
    };
  }
  porCommitment.encode = encode;
  porCommitment.expected = "string";
  function check(data) {
    return typeof data === "string";
  }
  porCommitment.check = check;
  function canAdd(currentData, newData) {
    return !!currentData && !!newData && currentData.porCommitment === void 0;
  }
  porCommitment.canAdd = canAdd;
  return porCommitment;
}
var sighashType = {};
var hasRequiredSighashType;
function requireSighashType() {
  if (hasRequiredSighashType) return sighashType;
  hasRequiredSighashType = 1;
  const { Buffer: Buffer2 } = requireBuffer();
  Object.defineProperty(sighashType, "__esModule", { value: true });
  const typeFields_1 = requireTypeFields();
  function decode(keyVal) {
    if (keyVal.key[0] !== typeFields_1.InputTypes.SIGHASH_TYPE) {
      throw new Error(
        "Decode Error: could not decode sighashType with key 0x" + keyVal.key.toString("hex")
      );
    }
    return keyVal.value.readUInt32LE(0);
  }
  sighashType.decode = decode;
  function encode(data) {
    const key = Buffer2.from([typeFields_1.InputTypes.SIGHASH_TYPE]);
    const value = Buffer2.allocUnsafe(4);
    value.writeUInt32LE(data, 0);
    return {
      key,
      value
    };
  }
  sighashType.encode = encode;
  sighashType.expected = "number";
  function check(data) {
    return typeof data === "number";
  }
  sighashType.check = check;
  function canAdd(currentData, newData) {
    return !!currentData && !!newData && currentData.sighashType === void 0;
  }
  sighashType.canAdd = canAdd;
  return sighashType;
}
var tapKeySig = {};
var hasRequiredTapKeySig;
function requireTapKeySig() {
  if (hasRequiredTapKeySig) return tapKeySig;
  hasRequiredTapKeySig = 1;
  const { Buffer: Buffer2 } = requireBuffer();
  Object.defineProperty(tapKeySig, "__esModule", { value: true });
  const typeFields_1 = requireTypeFields();
  function decode(keyVal) {
    if (keyVal.key[0] !== typeFields_1.InputTypes.TAP_KEY_SIG || keyVal.key.length !== 1) {
      throw new Error(
        "Decode Error: could not decode tapKeySig with key 0x" + keyVal.key.toString("hex")
      );
    }
    if (!check(keyVal.value)) {
      throw new Error(
        "Decode Error: tapKeySig not a valid 64-65-byte BIP340 signature"
      );
    }
    return keyVal.value;
  }
  tapKeySig.decode = decode;
  function encode(value) {
    const key = Buffer2.from([typeFields_1.InputTypes.TAP_KEY_SIG]);
    return { key, value };
  }
  tapKeySig.encode = encode;
  tapKeySig.expected = "Buffer";
  function check(data) {
    return Buffer2.isBuffer(data) && (data.length === 64 || data.length === 65);
  }
  tapKeySig.check = check;
  function canAdd(currentData, newData) {
    return !!currentData && !!newData && currentData.tapKeySig === void 0;
  }
  tapKeySig.canAdd = canAdd;
  return tapKeySig;
}
var tapLeafScript = {};
var hasRequiredTapLeafScript;
function requireTapLeafScript() {
  if (hasRequiredTapLeafScript) return tapLeafScript;
  hasRequiredTapLeafScript = 1;
  const { Buffer: Buffer2 } = requireBuffer();
  Object.defineProperty(tapLeafScript, "__esModule", { value: true });
  const typeFields_1 = requireTypeFields();
  function decode(keyVal) {
    if (keyVal.key[0] !== typeFields_1.InputTypes.TAP_LEAF_SCRIPT) {
      throw new Error(
        "Decode Error: could not decode tapLeafScript with key 0x" + keyVal.key.toString("hex")
      );
    }
    if ((keyVal.key.length - 2) % 32 !== 0) {
      throw new Error(
        "Decode Error: tapLeafScript has invalid control block in key 0x" + keyVal.key.toString("hex")
      );
    }
    const leafVersion = keyVal.value[keyVal.value.length - 1];
    if ((keyVal.key[1] & 254) !== leafVersion) {
      throw new Error(
        "Decode Error: tapLeafScript bad leaf version in key 0x" + keyVal.key.toString("hex")
      );
    }
    const script = keyVal.value.slice(0, -1);
    const controlBlock = keyVal.key.slice(1);
    return { controlBlock, script, leafVersion };
  }
  tapLeafScript.decode = decode;
  function encode(tScript) {
    const head = Buffer2.from([typeFields_1.InputTypes.TAP_LEAF_SCRIPT]);
    const verBuf = Buffer2.from([tScript.leafVersion]);
    return {
      key: Buffer2.concat([head, tScript.controlBlock]),
      value: Buffer2.concat([tScript.script, verBuf])
    };
  }
  tapLeafScript.encode = encode;
  tapLeafScript.expected = "{ controlBlock: Buffer; leafVersion: number, script: Buffer; }";
  function check(data) {
    return Buffer2.isBuffer(data.controlBlock) && (data.controlBlock.length - 1) % 32 === 0 && (data.controlBlock[0] & 254) === data.leafVersion && Buffer2.isBuffer(data.script);
  }
  tapLeafScript.check = check;
  function canAddToArray(array, item, dupeSet) {
    const dupeString = item.controlBlock.toString("hex");
    if (dupeSet.has(dupeString)) return false;
    dupeSet.add(dupeString);
    return array.filter((v) => v.controlBlock.equals(item.controlBlock)).length === 0;
  }
  tapLeafScript.canAddToArray = canAddToArray;
  return tapLeafScript;
}
var tapMerkleRoot = {};
var hasRequiredTapMerkleRoot;
function requireTapMerkleRoot() {
  if (hasRequiredTapMerkleRoot) return tapMerkleRoot;
  hasRequiredTapMerkleRoot = 1;
  const { Buffer: Buffer2 } = requireBuffer();
  Object.defineProperty(tapMerkleRoot, "__esModule", { value: true });
  const typeFields_1 = requireTypeFields();
  function decode(keyVal) {
    if (keyVal.key[0] !== typeFields_1.InputTypes.TAP_MERKLE_ROOT || keyVal.key.length !== 1) {
      throw new Error(
        "Decode Error: could not decode tapMerkleRoot with key 0x" + keyVal.key.toString("hex")
      );
    }
    if (!check(keyVal.value)) {
      throw new Error("Decode Error: tapMerkleRoot not a 32-byte hash");
    }
    return keyVal.value;
  }
  tapMerkleRoot.decode = decode;
  function encode(value) {
    const key = Buffer2.from([typeFields_1.InputTypes.TAP_MERKLE_ROOT]);
    return { key, value };
  }
  tapMerkleRoot.encode = encode;
  tapMerkleRoot.expected = "Buffer";
  function check(data) {
    return Buffer2.isBuffer(data) && data.length === 32;
  }
  tapMerkleRoot.check = check;
  function canAdd(currentData, newData) {
    return !!currentData && !!newData && currentData.tapMerkleRoot === void 0;
  }
  tapMerkleRoot.canAdd = canAdd;
  return tapMerkleRoot;
}
var tapScriptSig = {};
var hasRequiredTapScriptSig;
function requireTapScriptSig() {
  if (hasRequiredTapScriptSig) return tapScriptSig;
  hasRequiredTapScriptSig = 1;
  const { Buffer: Buffer2 } = requireBuffer();
  Object.defineProperty(tapScriptSig, "__esModule", { value: true });
  const typeFields_1 = requireTypeFields();
  function decode(keyVal) {
    if (keyVal.key[0] !== typeFields_1.InputTypes.TAP_SCRIPT_SIG) {
      throw new Error(
        "Decode Error: could not decode tapScriptSig with key 0x" + keyVal.key.toString("hex")
      );
    }
    if (keyVal.key.length !== 65) {
      throw new Error(
        "Decode Error: tapScriptSig has invalid key 0x" + keyVal.key.toString("hex")
      );
    }
    if (keyVal.value.length !== 64 && keyVal.value.length !== 65) {
      throw new Error(
        "Decode Error: tapScriptSig has invalid signature in key 0x" + keyVal.key.toString("hex")
      );
    }
    const pubkey = keyVal.key.slice(1, 33);
    const leafHash = keyVal.key.slice(33);
    return {
      pubkey,
      leafHash,
      signature: keyVal.value
    };
  }
  tapScriptSig.decode = decode;
  function encode(tSig) {
    const head = Buffer2.from([typeFields_1.InputTypes.TAP_SCRIPT_SIG]);
    return {
      key: Buffer2.concat([head, tSig.pubkey, tSig.leafHash]),
      value: tSig.signature
    };
  }
  tapScriptSig.encode = encode;
  tapScriptSig.expected = "{ pubkey: Buffer; leafHash: Buffer; signature: Buffer; }";
  function check(data) {
    return Buffer2.isBuffer(data.pubkey) && Buffer2.isBuffer(data.leafHash) && Buffer2.isBuffer(data.signature) && data.pubkey.length === 32 && data.leafHash.length === 32 && (data.signature.length === 64 || data.signature.length === 65);
  }
  tapScriptSig.check = check;
  function canAddToArray(array, item, dupeSet) {
    const dupeString = item.pubkey.toString("hex") + item.leafHash.toString("hex");
    if (dupeSet.has(dupeString)) return false;
    dupeSet.add(dupeString);
    return array.filter(
      (v) => v.pubkey.equals(item.pubkey) && v.leafHash.equals(item.leafHash)
    ).length === 0;
  }
  tapScriptSig.canAddToArray = canAddToArray;
  return tapScriptSig;
}
var witnessUtxo = {};
var tools = {};
var varint = {};
var hasRequiredVarint;
function requireVarint() {
  if (hasRequiredVarint) return varint;
  hasRequiredVarint = 1;
  const { Buffer: Buffer2 } = requireBuffer();
  Object.defineProperty(varint, "__esModule", { value: true });
  const MAX_SAFE_INTEGER = 9007199254740991;
  function checkUInt53(n) {
    if (n < 0 || n > MAX_SAFE_INTEGER || n % 1 !== 0)
      throw new RangeError("value out of range");
  }
  function encode(_number, buffer, offset) {
    checkUInt53(_number);
    if (!buffer) buffer = Buffer2.allocUnsafe(encodingLength(_number));
    if (!Buffer2.isBuffer(buffer))
      throw new TypeError("buffer must be a Buffer instance");
    if (!offset) offset = 0;
    if (_number < 253) {
      buffer.writeUInt8(_number, offset);
      Object.assign(encode, { bytes: 1 });
    } else if (_number <= 65535) {
      buffer.writeUInt8(253, offset);
      buffer.writeUInt16LE(_number, offset + 1);
      Object.assign(encode, { bytes: 3 });
    } else if (_number <= 4294967295) {
      buffer.writeUInt8(254, offset);
      buffer.writeUInt32LE(_number, offset + 1);
      Object.assign(encode, { bytes: 5 });
    } else {
      buffer.writeUInt8(255, offset);
      buffer.writeUInt32LE(_number >>> 0, offset + 1);
      buffer.writeUInt32LE(_number / 4294967296 | 0, offset + 5);
      Object.assign(encode, { bytes: 9 });
    }
    return buffer;
  }
  varint.encode = encode;
  function decode(buffer, offset) {
    if (!Buffer2.isBuffer(buffer))
      throw new TypeError("buffer must be a Buffer instance");
    if (!offset) offset = 0;
    const first = buffer.readUInt8(offset);
    if (first < 253) {
      Object.assign(decode, { bytes: 1 });
      return first;
    } else if (first === 253) {
      Object.assign(decode, { bytes: 3 });
      return buffer.readUInt16LE(offset + 1);
    } else if (first === 254) {
      Object.assign(decode, { bytes: 5 });
      return buffer.readUInt32LE(offset + 1);
    } else {
      Object.assign(decode, { bytes: 9 });
      const lo = buffer.readUInt32LE(offset + 1);
      const hi = buffer.readUInt32LE(offset + 5);
      const _number = hi * 4294967296 + lo;
      checkUInt53(_number);
      return _number;
    }
  }
  varint.decode = decode;
  function encodingLength(_number) {
    checkUInt53(_number);
    return _number < 253 ? 1 : _number <= 65535 ? 3 : _number <= 4294967295 ? 5 : 9;
  }
  varint.encodingLength = encodingLength;
  return varint;
}
var hasRequiredTools;
function requireTools() {
  if (hasRequiredTools) return tools;
  hasRequiredTools = 1;
  const { Buffer: Buffer2 } = requireBuffer();
  Object.defineProperty(tools, "__esModule", { value: true });
  const varuint = requireVarint();
  tools.range = (n) => [...Array(n).keys()];
  function reverseBuffer2(buffer) {
    if (buffer.length < 1) return buffer;
    let j = buffer.length - 1;
    let tmp = 0;
    for (let i = 0; i < buffer.length / 2; i++) {
      tmp = buffer[i];
      buffer[i] = buffer[j];
      buffer[j] = tmp;
      j--;
    }
    return buffer;
  }
  tools.reverseBuffer = reverseBuffer2;
  function keyValsToBuffer(keyVals) {
    const buffers = keyVals.map(keyValToBuffer);
    buffers.push(Buffer2.from([0]));
    return Buffer2.concat(buffers);
  }
  tools.keyValsToBuffer = keyValsToBuffer;
  function keyValToBuffer(keyVal) {
    const keyLen = keyVal.key.length;
    const valLen = keyVal.value.length;
    const keyVarIntLen = varuint.encodingLength(keyLen);
    const valVarIntLen = varuint.encodingLength(valLen);
    const buffer = Buffer2.allocUnsafe(
      keyVarIntLen + keyLen + valVarIntLen + valLen
    );
    varuint.encode(keyLen, buffer, 0);
    keyVal.key.copy(buffer, keyVarIntLen);
    varuint.encode(valLen, buffer, keyVarIntLen + keyLen);
    keyVal.value.copy(buffer, keyVarIntLen + keyLen + valVarIntLen);
    return buffer;
  }
  tools.keyValToBuffer = keyValToBuffer;
  function verifuint2(value, max) {
    if (typeof value !== "number")
      throw new Error("cannot write a non-number as a number");
    if (value < 0)
      throw new Error("specified a negative value for writing an unsigned value");
    if (value > max) throw new Error("RangeError: value out of range");
    if (Math.floor(value) !== value)
      throw new Error("value has a fractional component");
  }
  function readUInt64LE2(buffer, offset) {
    const a = buffer.readUInt32LE(offset);
    let b = buffer.readUInt32LE(offset + 4);
    b *= 4294967296;
    verifuint2(b + a, 9007199254740991);
    return b + a;
  }
  tools.readUInt64LE = readUInt64LE2;
  function writeUInt64LE2(buffer, value, offset) {
    verifuint2(value, 9007199254740991);
    buffer.writeInt32LE(value & -1, offset);
    buffer.writeUInt32LE(Math.floor(value / 4294967296), offset + 4);
    return offset + 8;
  }
  tools.writeUInt64LE = writeUInt64LE2;
  return tools;
}
var hasRequiredWitnessUtxo;
function requireWitnessUtxo() {
  if (hasRequiredWitnessUtxo) return witnessUtxo;
  hasRequiredWitnessUtxo = 1;
  const { Buffer: Buffer2 } = requireBuffer();
  Object.defineProperty(witnessUtxo, "__esModule", { value: true });
  const typeFields_1 = requireTypeFields();
  const tools_1 = requireTools();
  const varuint = requireVarint();
  function decode(keyVal) {
    if (keyVal.key[0] !== typeFields_1.InputTypes.WITNESS_UTXO) {
      throw new Error(
        "Decode Error: could not decode witnessUtxo with key 0x" + keyVal.key.toString("hex")
      );
    }
    const value = tools_1.readUInt64LE(keyVal.value, 0);
    let _offset = 8;
    const scriptLen = varuint.decode(keyVal.value, _offset);
    _offset += varuint.encodingLength(scriptLen);
    const script = keyVal.value.slice(_offset);
    if (script.length !== scriptLen) {
      throw new Error("Decode Error: WITNESS_UTXO script is not proper length");
    }
    return {
      script,
      value
    };
  }
  witnessUtxo.decode = decode;
  function encode(data) {
    const { script, value } = data;
    const varintLen = varuint.encodingLength(script.length);
    const result = Buffer2.allocUnsafe(8 + varintLen + script.length);
    tools_1.writeUInt64LE(result, value, 0);
    varuint.encode(script.length, result, 8);
    script.copy(result, 8 + varintLen);
    return {
      key: Buffer2.from([typeFields_1.InputTypes.WITNESS_UTXO]),
      value: result
    };
  }
  witnessUtxo.encode = encode;
  witnessUtxo.expected = "{ script: Buffer; value: number; }";
  function check(data) {
    return Buffer2.isBuffer(data.script) && typeof data.value === "number";
  }
  witnessUtxo.check = check;
  function canAdd(currentData, newData) {
    return !!currentData && !!newData && currentData.witnessUtxo === void 0;
  }
  witnessUtxo.canAdd = canAdd;
  return witnessUtxo;
}
var tapTree = {};
var hasRequiredTapTree;
function requireTapTree() {
  if (hasRequiredTapTree) return tapTree;
  hasRequiredTapTree = 1;
  const { Buffer: Buffer2 } = requireBuffer();
  Object.defineProperty(tapTree, "__esModule", { value: true });
  const typeFields_1 = requireTypeFields();
  const varuint = requireVarint();
  function decode(keyVal) {
    if (keyVal.key[0] !== typeFields_1.OutputTypes.TAP_TREE || keyVal.key.length !== 1) {
      throw new Error(
        "Decode Error: could not decode tapTree with key 0x" + keyVal.key.toString("hex")
      );
    }
    let _offset = 0;
    const data = [];
    while (_offset < keyVal.value.length) {
      const depth = keyVal.value[_offset++];
      const leafVersion = keyVal.value[_offset++];
      const scriptLen = varuint.decode(keyVal.value, _offset);
      _offset += varuint.encodingLength(scriptLen);
      data.push({
        depth,
        leafVersion,
        script: keyVal.value.slice(_offset, _offset + scriptLen)
      });
      _offset += scriptLen;
    }
    return { leaves: data };
  }
  tapTree.decode = decode;
  function encode(tree) {
    const key = Buffer2.from([typeFields_1.OutputTypes.TAP_TREE]);
    const bufs = [].concat(
      ...tree.leaves.map((tapLeaf) => [
        Buffer2.of(tapLeaf.depth, tapLeaf.leafVersion),
        varuint.encode(tapLeaf.script.length),
        tapLeaf.script
      ])
    );
    return {
      key,
      value: Buffer2.concat(bufs)
    };
  }
  tapTree.encode = encode;
  tapTree.expected = "{ leaves: [{ depth: number; leafVersion: number, script: Buffer; }] }";
  function check(data) {
    return Array.isArray(data.leaves) && data.leaves.every(
      (tapLeaf) => tapLeaf.depth >= 0 && tapLeaf.depth <= 128 && (tapLeaf.leafVersion & 254) === tapLeaf.leafVersion && Buffer2.isBuffer(tapLeaf.script)
    );
  }
  tapTree.check = check;
  function canAdd(currentData, newData) {
    return !!currentData && !!newData && currentData.tapTree === void 0;
  }
  tapTree.canAdd = canAdd;
  return tapTree;
}
var bip32Derivation = {};
var hasRequiredBip32Derivation;
function requireBip32Derivation() {
  if (hasRequiredBip32Derivation) return bip32Derivation;
  hasRequiredBip32Derivation = 1;
  const { Buffer: Buffer2 } = requireBuffer();
  Object.defineProperty(bip32Derivation, "__esModule", { value: true });
  const range2 = (n) => [...Array(n).keys()];
  const isValidDERKey = (pubkey) => pubkey.length === 33 && [2, 3].includes(pubkey[0]) || pubkey.length === 65 && 4 === pubkey[0];
  function makeConverter(TYPE_BYTE, isValidPubkey = isValidDERKey) {
    function decode(keyVal) {
      if (keyVal.key[0] !== TYPE_BYTE) {
        throw new Error(
          "Decode Error: could not decode bip32Derivation with key 0x" + keyVal.key.toString("hex")
        );
      }
      const pubkey = keyVal.key.slice(1);
      if (!isValidPubkey(pubkey)) {
        throw new Error(
          "Decode Error: bip32Derivation has invalid pubkey in key 0x" + keyVal.key.toString("hex")
        );
      }
      if (keyVal.value.length / 4 % 1 !== 0) {
        throw new Error(
          "Decode Error: Input BIP32_DERIVATION value length should be multiple of 4"
        );
      }
      const data = {
        masterFingerprint: keyVal.value.slice(0, 4),
        pubkey,
        path: "m"
      };
      for (const i of range2(keyVal.value.length / 4 - 1)) {
        const val = keyVal.value.readUInt32LE(i * 4 + 4);
        const isHard = !!(val & 2147483648);
        const idx = val & 2147483647;
        data.path += "/" + idx.toString(10) + (isHard ? "'" : "");
      }
      return data;
    }
    function encode(data) {
      const head = Buffer2.from([TYPE_BYTE]);
      const key = Buffer2.concat([head, data.pubkey]);
      const splitPath = data.path.split("/");
      const value = Buffer2.allocUnsafe(splitPath.length * 4);
      data.masterFingerprint.copy(value, 0);
      let offset = 4;
      splitPath.slice(1).forEach((level) => {
        const isHard = level.slice(-1) === "'";
        let num = 2147483647 & parseInt(isHard ? level.slice(0, -1) : level, 10);
        if (isHard) num += 2147483648;
        value.writeUInt32LE(num, offset);
        offset += 4;
      });
      return {
        key,
        value
      };
    }
    const expected = "{ masterFingerprint: Buffer; pubkey: Buffer; path: string; }";
    function check(data) {
      return Buffer2.isBuffer(data.pubkey) && Buffer2.isBuffer(data.masterFingerprint) && typeof data.path === "string" && isValidPubkey(data.pubkey) && data.masterFingerprint.length === 4;
    }
    function canAddToArray(array, item, dupeSet) {
      const dupeString = item.pubkey.toString("hex");
      if (dupeSet.has(dupeString)) return false;
      dupeSet.add(dupeString);
      return array.filter((v) => v.pubkey.equals(item.pubkey)).length === 0;
    }
    return {
      decode,
      encode,
      check,
      expected,
      canAddToArray
    };
  }
  bip32Derivation.makeConverter = makeConverter;
  return bip32Derivation;
}
var checkPubkey = {};
var hasRequiredCheckPubkey;
function requireCheckPubkey() {
  if (hasRequiredCheckPubkey) return checkPubkey;
  hasRequiredCheckPubkey = 1;
  Object.defineProperty(checkPubkey, "__esModule", { value: true });
  function makeChecker(pubkeyTypes) {
    return checkPubkey2;
    function checkPubkey2(keyVal) {
      let pubkey;
      if (pubkeyTypes.includes(keyVal.key[0])) {
        pubkey = keyVal.key.slice(1);
        if (!(pubkey.length === 33 || pubkey.length === 65) || ![2, 3, 4].includes(pubkey[0])) {
          throw new Error(
            "Format Error: invalid pubkey in key 0x" + keyVal.key.toString("hex")
          );
        }
      }
      return pubkey;
    }
  }
  checkPubkey.makeChecker = makeChecker;
  return checkPubkey;
}
var redeemScript = {};
var hasRequiredRedeemScript;
function requireRedeemScript() {
  if (hasRequiredRedeemScript) return redeemScript;
  hasRequiredRedeemScript = 1;
  const { Buffer: Buffer2 } = requireBuffer();
  Object.defineProperty(redeemScript, "__esModule", { value: true });
  function makeConverter(TYPE_BYTE) {
    function decode(keyVal) {
      if (keyVal.key[0] !== TYPE_BYTE) {
        throw new Error(
          "Decode Error: could not decode redeemScript with key 0x" + keyVal.key.toString("hex")
        );
      }
      return keyVal.value;
    }
    function encode(data) {
      const key = Buffer2.from([TYPE_BYTE]);
      return {
        key,
        value: data
      };
    }
    const expected = "Buffer";
    function check(data) {
      return Buffer2.isBuffer(data);
    }
    function canAdd(currentData, newData) {
      return !!currentData && !!newData && currentData.redeemScript === void 0;
    }
    return {
      decode,
      encode,
      check,
      expected,
      canAdd
    };
  }
  redeemScript.makeConverter = makeConverter;
  return redeemScript;
}
var tapBip32Derivation = {};
var hasRequiredTapBip32Derivation;
function requireTapBip32Derivation() {
  if (hasRequiredTapBip32Derivation) return tapBip32Derivation;
  hasRequiredTapBip32Derivation = 1;
  const { Buffer: Buffer2 } = requireBuffer();
  Object.defineProperty(tapBip32Derivation, "__esModule", { value: true });
  const varuint = requireVarint();
  const bip32Derivation2 = requireBip32Derivation();
  const isValidBIP340Key = (pubkey) => pubkey.length === 32;
  function makeConverter(TYPE_BYTE) {
    const parent = bip32Derivation2.makeConverter(TYPE_BYTE, isValidBIP340Key);
    function decode(keyVal) {
      const nHashes = varuint.decode(keyVal.value);
      const nHashesLen = varuint.encodingLength(nHashes);
      const base = parent.decode({
        key: keyVal.key,
        value: keyVal.value.slice(nHashesLen + nHashes * 32)
      });
      const leafHashes = new Array(nHashes);
      for (let i = 0, _offset = nHashesLen; i < nHashes; i++, _offset += 32) {
        leafHashes[i] = keyVal.value.slice(_offset, _offset + 32);
      }
      return Object.assign({}, base, { leafHashes });
    }
    function encode(data) {
      const base = parent.encode(data);
      const nHashesLen = varuint.encodingLength(data.leafHashes.length);
      const nHashesBuf = Buffer2.allocUnsafe(nHashesLen);
      varuint.encode(data.leafHashes.length, nHashesBuf);
      const value = Buffer2.concat([nHashesBuf, ...data.leafHashes, base.value]);
      return Object.assign({}, base, { value });
    }
    const expected = "{ masterFingerprint: Buffer; pubkey: Buffer; path: string; leafHashes: Buffer[]; }";
    function check(data) {
      return Array.isArray(data.leafHashes) && data.leafHashes.every(
        (leafHash) => Buffer2.isBuffer(leafHash) && leafHash.length === 32
      ) && parent.check(data);
    }
    return {
      decode,
      encode,
      check,
      expected,
      canAddToArray: parent.canAddToArray
    };
  }
  tapBip32Derivation.makeConverter = makeConverter;
  return tapBip32Derivation;
}
var tapInternalKey = {};
var hasRequiredTapInternalKey;
function requireTapInternalKey() {
  if (hasRequiredTapInternalKey) return tapInternalKey;
  hasRequiredTapInternalKey = 1;
  const { Buffer: Buffer2 } = requireBuffer();
  Object.defineProperty(tapInternalKey, "__esModule", { value: true });
  function makeConverter(TYPE_BYTE) {
    function decode(keyVal) {
      if (keyVal.key[0] !== TYPE_BYTE || keyVal.key.length !== 1) {
        throw new Error(
          "Decode Error: could not decode tapInternalKey with key 0x" + keyVal.key.toString("hex")
        );
      }
      if (keyVal.value.length !== 32) {
        throw new Error(
          "Decode Error: tapInternalKey not a 32-byte x-only pubkey"
        );
      }
      return keyVal.value;
    }
    function encode(value) {
      const key = Buffer2.from([TYPE_BYTE]);
      return { key, value };
    }
    const expected = "Buffer";
    function check(data) {
      return Buffer2.isBuffer(data) && data.length === 32;
    }
    function canAdd(currentData, newData) {
      return !!currentData && !!newData && currentData.tapInternalKey === void 0;
    }
    return {
      decode,
      encode,
      check,
      expected,
      canAdd
    };
  }
  tapInternalKey.makeConverter = makeConverter;
  return tapInternalKey;
}
var witnessScript = {};
var hasRequiredWitnessScript;
function requireWitnessScript() {
  if (hasRequiredWitnessScript) return witnessScript;
  hasRequiredWitnessScript = 1;
  const { Buffer: Buffer2 } = requireBuffer();
  Object.defineProperty(witnessScript, "__esModule", { value: true });
  function makeConverter(TYPE_BYTE) {
    function decode(keyVal) {
      if (keyVal.key[0] !== TYPE_BYTE) {
        throw new Error(
          "Decode Error: could not decode witnessScript with key 0x" + keyVal.key.toString("hex")
        );
      }
      return keyVal.value;
    }
    function encode(data) {
      const key = Buffer2.from([TYPE_BYTE]);
      return {
        key,
        value: data
      };
    }
    const expected = "Buffer";
    function check(data) {
      return Buffer2.isBuffer(data);
    }
    function canAdd(currentData, newData) {
      return !!currentData && !!newData && currentData.witnessScript === void 0;
    }
    return {
      decode,
      encode,
      check,
      expected,
      canAdd
    };
  }
  witnessScript.makeConverter = makeConverter;
  return witnessScript;
}
var hasRequiredConverter;
function requireConverter() {
  if (hasRequiredConverter) return converter;
  hasRequiredConverter = 1;
  Object.defineProperty(converter, "__esModule", { value: true });
  const typeFields_1 = requireTypeFields();
  const globalXpub2 = requireGlobalXpub();
  const unsignedTx2 = requireUnsignedTx();
  const finalScriptSig2 = requireFinalScriptSig();
  const finalScriptWitness2 = requireFinalScriptWitness();
  const nonWitnessUtxo2 = requireNonWitnessUtxo();
  const partialSig2 = requirePartialSig();
  const porCommitment2 = requirePorCommitment();
  const sighashType2 = requireSighashType();
  const tapKeySig2 = requireTapKeySig();
  const tapLeafScript2 = requireTapLeafScript();
  const tapMerkleRoot2 = requireTapMerkleRoot();
  const tapScriptSig2 = requireTapScriptSig();
  const witnessUtxo2 = requireWitnessUtxo();
  const tapTree2 = requireTapTree();
  const bip32Derivation2 = requireBip32Derivation();
  const checkPubkey2 = requireCheckPubkey();
  const redeemScript2 = requireRedeemScript();
  const tapBip32Derivation2 = requireTapBip32Derivation();
  const tapInternalKey2 = requireTapInternalKey();
  const witnessScript2 = requireWitnessScript();
  const globals = {
    unsignedTx: unsignedTx2,
    globalXpub: globalXpub2,
    // pass an Array of key bytes that require pubkey beside the key
    checkPubkey: checkPubkey2.makeChecker([])
  };
  converter.globals = globals;
  const inputs = {
    nonWitnessUtxo: nonWitnessUtxo2,
    partialSig: partialSig2,
    sighashType: sighashType2,
    finalScriptSig: finalScriptSig2,
    finalScriptWitness: finalScriptWitness2,
    porCommitment: porCommitment2,
    witnessUtxo: witnessUtxo2,
    bip32Derivation: bip32Derivation2.makeConverter(
      typeFields_1.InputTypes.BIP32_DERIVATION
    ),
    redeemScript: redeemScript2.makeConverter(
      typeFields_1.InputTypes.REDEEM_SCRIPT
    ),
    witnessScript: witnessScript2.makeConverter(
      typeFields_1.InputTypes.WITNESS_SCRIPT
    ),
    checkPubkey: checkPubkey2.makeChecker([
      typeFields_1.InputTypes.PARTIAL_SIG,
      typeFields_1.InputTypes.BIP32_DERIVATION
    ]),
    tapKeySig: tapKeySig2,
    tapScriptSig: tapScriptSig2,
    tapLeafScript: tapLeafScript2,
    tapBip32Derivation: tapBip32Derivation2.makeConverter(
      typeFields_1.InputTypes.TAP_BIP32_DERIVATION
    ),
    tapInternalKey: tapInternalKey2.makeConverter(
      typeFields_1.InputTypes.TAP_INTERNAL_KEY
    ),
    tapMerkleRoot: tapMerkleRoot2
  };
  converter.inputs = inputs;
  const outputs = {
    bip32Derivation: bip32Derivation2.makeConverter(
      typeFields_1.OutputTypes.BIP32_DERIVATION
    ),
    redeemScript: redeemScript2.makeConverter(
      typeFields_1.OutputTypes.REDEEM_SCRIPT
    ),
    witnessScript: witnessScript2.makeConverter(
      typeFields_1.OutputTypes.WITNESS_SCRIPT
    ),
    checkPubkey: checkPubkey2.makeChecker([
      typeFields_1.OutputTypes.BIP32_DERIVATION
    ]),
    tapBip32Derivation: tapBip32Derivation2.makeConverter(
      typeFields_1.OutputTypes.TAP_BIP32_DERIVATION
    ),
    tapTree: tapTree2,
    tapInternalKey: tapInternalKey2.makeConverter(
      typeFields_1.OutputTypes.TAP_INTERNAL_KEY
    )
  };
  converter.outputs = outputs;
  return converter;
}
var hasRequiredFromBuffer;
function requireFromBuffer() {
  if (hasRequiredFromBuffer) return fromBuffer;
  hasRequiredFromBuffer = 1;
  const { Buffer: Buffer2 } = requireBuffer();
  Object.defineProperty(fromBuffer, "__esModule", { value: true });
  const convert = requireConverter();
  const tools_1 = requireTools();
  const varuint = requireVarint();
  const typeFields_1 = requireTypeFields();
  function psbtFromBuffer(buffer, txGetter) {
    let offset = 0;
    function varSlice() {
      const keyLen = varuint.decode(buffer, offset);
      offset += varuint.encodingLength(keyLen);
      const key = buffer.slice(offset, offset + keyLen);
      offset += keyLen;
      return key;
    }
    function readUInt32BE() {
      const num = buffer.readUInt32BE(offset);
      offset += 4;
      return num;
    }
    function readUInt8() {
      const num = buffer.readUInt8(offset);
      offset += 1;
      return num;
    }
    function getKeyValue() {
      const key = varSlice();
      const value = varSlice();
      return {
        key,
        value
      };
    }
    function checkEndOfKeyValPairs() {
      if (offset >= buffer.length) {
        throw new Error("Format Error: Unexpected End of PSBT");
      }
      const isEnd = buffer.readUInt8(offset) === 0;
      if (isEnd) {
        offset++;
      }
      return isEnd;
    }
    if (readUInt32BE() !== 1886610036) {
      throw new Error("Format Error: Invalid Magic Number");
    }
    if (readUInt8() !== 255) {
      throw new Error(
        "Format Error: Magic Number must be followed by 0xff separator"
      );
    }
    const globalMapKeyVals = [];
    const globalKeyIndex = {};
    while (!checkEndOfKeyValPairs()) {
      const keyVal = getKeyValue();
      const hexKey = keyVal.key.toString("hex");
      if (globalKeyIndex[hexKey]) {
        throw new Error(
          "Format Error: Keys must be unique for global keymap: key " + hexKey
        );
      }
      globalKeyIndex[hexKey] = 1;
      globalMapKeyVals.push(keyVal);
    }
    const unsignedTxMaps = globalMapKeyVals.filter(
      (keyVal) => keyVal.key[0] === typeFields_1.GlobalTypes.UNSIGNED_TX
    );
    if (unsignedTxMaps.length !== 1) {
      throw new Error("Format Error: Only one UNSIGNED_TX allowed");
    }
    const unsignedTx2 = txGetter(unsignedTxMaps[0].value);
    const { inputCount, outputCount } = unsignedTx2.getInputOutputCounts();
    const inputKeyVals = [];
    const outputKeyVals = [];
    for (const index of tools_1.range(inputCount)) {
      const inputKeyIndex = {};
      const input = [];
      while (!checkEndOfKeyValPairs()) {
        const keyVal = getKeyValue();
        const hexKey = keyVal.key.toString("hex");
        if (inputKeyIndex[hexKey]) {
          throw new Error(
            "Format Error: Keys must be unique for each input: input index " + index + " key " + hexKey
          );
        }
        inputKeyIndex[hexKey] = 1;
        input.push(keyVal);
      }
      inputKeyVals.push(input);
    }
    for (const index of tools_1.range(outputCount)) {
      const outputKeyIndex = {};
      const output = [];
      while (!checkEndOfKeyValPairs()) {
        const keyVal = getKeyValue();
        const hexKey = keyVal.key.toString("hex");
        if (outputKeyIndex[hexKey]) {
          throw new Error(
            "Format Error: Keys must be unique for each output: output index " + index + " key " + hexKey
          );
        }
        outputKeyIndex[hexKey] = 1;
        output.push(keyVal);
      }
      outputKeyVals.push(output);
    }
    return psbtFromKeyVals(unsignedTx2, {
      globalMapKeyVals,
      inputKeyVals,
      outputKeyVals
    });
  }
  fromBuffer.psbtFromBuffer = psbtFromBuffer;
  function checkKeyBuffer(type, keyBuf, keyNum) {
    if (!keyBuf.equals(Buffer2.from([keyNum]))) {
      throw new Error(
        `Format Error: Invalid ${type} key: ${keyBuf.toString("hex")}`
      );
    }
  }
  fromBuffer.checkKeyBuffer = checkKeyBuffer;
  function psbtFromKeyVals(unsignedTx2, { globalMapKeyVals, inputKeyVals, outputKeyVals }) {
    const globalMap = {
      unsignedTx: unsignedTx2
    };
    let txCount = 0;
    for (const keyVal of globalMapKeyVals) {
      switch (keyVal.key[0]) {
        case typeFields_1.GlobalTypes.UNSIGNED_TX:
          checkKeyBuffer(
            "global",
            keyVal.key,
            typeFields_1.GlobalTypes.UNSIGNED_TX
          );
          if (txCount > 0) {
            throw new Error("Format Error: GlobalMap has multiple UNSIGNED_TX");
          }
          txCount++;
          break;
        case typeFields_1.GlobalTypes.GLOBAL_XPUB:
          if (globalMap.globalXpub === void 0) {
            globalMap.globalXpub = [];
          }
          globalMap.globalXpub.push(convert.globals.globalXpub.decode(keyVal));
          break;
        default:
          if (!globalMap.unknownKeyVals) globalMap.unknownKeyVals = [];
          globalMap.unknownKeyVals.push(keyVal);
      }
    }
    const inputCount = inputKeyVals.length;
    const outputCount = outputKeyVals.length;
    const inputs = [];
    const outputs = [];
    for (const index of tools_1.range(inputCount)) {
      const input = {};
      for (const keyVal of inputKeyVals[index]) {
        convert.inputs.checkPubkey(keyVal);
        switch (keyVal.key[0]) {
          case typeFields_1.InputTypes.NON_WITNESS_UTXO:
            checkKeyBuffer(
              "input",
              keyVal.key,
              typeFields_1.InputTypes.NON_WITNESS_UTXO
            );
            if (input.nonWitnessUtxo !== void 0) {
              throw new Error(
                "Format Error: Input has multiple NON_WITNESS_UTXO"
              );
            }
            input.nonWitnessUtxo = convert.inputs.nonWitnessUtxo.decode(keyVal);
            break;
          case typeFields_1.InputTypes.WITNESS_UTXO:
            checkKeyBuffer(
              "input",
              keyVal.key,
              typeFields_1.InputTypes.WITNESS_UTXO
            );
            if (input.witnessUtxo !== void 0) {
              throw new Error("Format Error: Input has multiple WITNESS_UTXO");
            }
            input.witnessUtxo = convert.inputs.witnessUtxo.decode(keyVal);
            break;
          case typeFields_1.InputTypes.PARTIAL_SIG:
            if (input.partialSig === void 0) {
              input.partialSig = [];
            }
            input.partialSig.push(convert.inputs.partialSig.decode(keyVal));
            break;
          case typeFields_1.InputTypes.SIGHASH_TYPE:
            checkKeyBuffer(
              "input",
              keyVal.key,
              typeFields_1.InputTypes.SIGHASH_TYPE
            );
            if (input.sighashType !== void 0) {
              throw new Error("Format Error: Input has multiple SIGHASH_TYPE");
            }
            input.sighashType = convert.inputs.sighashType.decode(keyVal);
            break;
          case typeFields_1.InputTypes.REDEEM_SCRIPT:
            checkKeyBuffer(
              "input",
              keyVal.key,
              typeFields_1.InputTypes.REDEEM_SCRIPT
            );
            if (input.redeemScript !== void 0) {
              throw new Error("Format Error: Input has multiple REDEEM_SCRIPT");
            }
            input.redeemScript = convert.inputs.redeemScript.decode(keyVal);
            break;
          case typeFields_1.InputTypes.WITNESS_SCRIPT:
            checkKeyBuffer(
              "input",
              keyVal.key,
              typeFields_1.InputTypes.WITNESS_SCRIPT
            );
            if (input.witnessScript !== void 0) {
              throw new Error("Format Error: Input has multiple WITNESS_SCRIPT");
            }
            input.witnessScript = convert.inputs.witnessScript.decode(keyVal);
            break;
          case typeFields_1.InputTypes.BIP32_DERIVATION:
            if (input.bip32Derivation === void 0) {
              input.bip32Derivation = [];
            }
            input.bip32Derivation.push(
              convert.inputs.bip32Derivation.decode(keyVal)
            );
            break;
          case typeFields_1.InputTypes.FINAL_SCRIPTSIG:
            checkKeyBuffer(
              "input",
              keyVal.key,
              typeFields_1.InputTypes.FINAL_SCRIPTSIG
            );
            input.finalScriptSig = convert.inputs.finalScriptSig.decode(keyVal);
            break;
          case typeFields_1.InputTypes.FINAL_SCRIPTWITNESS:
            checkKeyBuffer(
              "input",
              keyVal.key,
              typeFields_1.InputTypes.FINAL_SCRIPTWITNESS
            );
            input.finalScriptWitness = convert.inputs.finalScriptWitness.decode(keyVal);
            break;
          case typeFields_1.InputTypes.POR_COMMITMENT:
            checkKeyBuffer(
              "input",
              keyVal.key,
              typeFields_1.InputTypes.POR_COMMITMENT
            );
            input.porCommitment = convert.inputs.porCommitment.decode(keyVal);
            break;
          case typeFields_1.InputTypes.TAP_KEY_SIG:
            checkKeyBuffer(
              "input",
              keyVal.key,
              typeFields_1.InputTypes.TAP_KEY_SIG
            );
            input.tapKeySig = convert.inputs.tapKeySig.decode(keyVal);
            break;
          case typeFields_1.InputTypes.TAP_SCRIPT_SIG:
            if (input.tapScriptSig === void 0) {
              input.tapScriptSig = [];
            }
            input.tapScriptSig.push(convert.inputs.tapScriptSig.decode(keyVal));
            break;
          case typeFields_1.InputTypes.TAP_LEAF_SCRIPT:
            if (input.tapLeafScript === void 0) {
              input.tapLeafScript = [];
            }
            input.tapLeafScript.push(convert.inputs.tapLeafScript.decode(keyVal));
            break;
          case typeFields_1.InputTypes.TAP_BIP32_DERIVATION:
            if (input.tapBip32Derivation === void 0) {
              input.tapBip32Derivation = [];
            }
            input.tapBip32Derivation.push(
              convert.inputs.tapBip32Derivation.decode(keyVal)
            );
            break;
          case typeFields_1.InputTypes.TAP_INTERNAL_KEY:
            checkKeyBuffer(
              "input",
              keyVal.key,
              typeFields_1.InputTypes.TAP_INTERNAL_KEY
            );
            input.tapInternalKey = convert.inputs.tapInternalKey.decode(keyVal);
            break;
          case typeFields_1.InputTypes.TAP_MERKLE_ROOT:
            checkKeyBuffer(
              "input",
              keyVal.key,
              typeFields_1.InputTypes.TAP_MERKLE_ROOT
            );
            input.tapMerkleRoot = convert.inputs.tapMerkleRoot.decode(keyVal);
            break;
          default:
            if (!input.unknownKeyVals) input.unknownKeyVals = [];
            input.unknownKeyVals.push(keyVal);
        }
      }
      inputs.push(input);
    }
    for (const index of tools_1.range(outputCount)) {
      const output = {};
      for (const keyVal of outputKeyVals[index]) {
        convert.outputs.checkPubkey(keyVal);
        switch (keyVal.key[0]) {
          case typeFields_1.OutputTypes.REDEEM_SCRIPT:
            checkKeyBuffer(
              "output",
              keyVal.key,
              typeFields_1.OutputTypes.REDEEM_SCRIPT
            );
            if (output.redeemScript !== void 0) {
              throw new Error("Format Error: Output has multiple REDEEM_SCRIPT");
            }
            output.redeemScript = convert.outputs.redeemScript.decode(keyVal);
            break;
          case typeFields_1.OutputTypes.WITNESS_SCRIPT:
            checkKeyBuffer(
              "output",
              keyVal.key,
              typeFields_1.OutputTypes.WITNESS_SCRIPT
            );
            if (output.witnessScript !== void 0) {
              throw new Error("Format Error: Output has multiple WITNESS_SCRIPT");
            }
            output.witnessScript = convert.outputs.witnessScript.decode(keyVal);
            break;
          case typeFields_1.OutputTypes.BIP32_DERIVATION:
            if (output.bip32Derivation === void 0) {
              output.bip32Derivation = [];
            }
            output.bip32Derivation.push(
              convert.outputs.bip32Derivation.decode(keyVal)
            );
            break;
          case typeFields_1.OutputTypes.TAP_INTERNAL_KEY:
            checkKeyBuffer(
              "output",
              keyVal.key,
              typeFields_1.OutputTypes.TAP_INTERNAL_KEY
            );
            output.tapInternalKey = convert.outputs.tapInternalKey.decode(keyVal);
            break;
          case typeFields_1.OutputTypes.TAP_TREE:
            checkKeyBuffer(
              "output",
              keyVal.key,
              typeFields_1.OutputTypes.TAP_TREE
            );
            output.tapTree = convert.outputs.tapTree.decode(keyVal);
            break;
          case typeFields_1.OutputTypes.TAP_BIP32_DERIVATION:
            if (output.tapBip32Derivation === void 0) {
              output.tapBip32Derivation = [];
            }
            output.tapBip32Derivation.push(
              convert.outputs.tapBip32Derivation.decode(keyVal)
            );
            break;
          default:
            if (!output.unknownKeyVals) output.unknownKeyVals = [];
            output.unknownKeyVals.push(keyVal);
        }
      }
      outputs.push(output);
    }
    return { globalMap, inputs, outputs };
  }
  fromBuffer.psbtFromKeyVals = psbtFromKeyVals;
  return fromBuffer;
}
var toBuffer = {};
var hasRequiredToBuffer;
function requireToBuffer() {
  if (hasRequiredToBuffer) return toBuffer;
  hasRequiredToBuffer = 1;
  const { Buffer: Buffer2 } = requireBuffer();
  Object.defineProperty(toBuffer, "__esModule", { value: true });
  const convert = requireConverter();
  const tools_1 = requireTools();
  function psbtToBuffer({ globalMap, inputs, outputs }) {
    const { globalKeyVals, inputKeyVals, outputKeyVals } = psbtToKeyVals({
      globalMap,
      inputs,
      outputs
    });
    const globalBuffer = tools_1.keyValsToBuffer(globalKeyVals);
    const keyValsOrEmptyToBuffer = (keyVals) => keyVals.length === 0 ? (
      //@ts-ignore
      [Buffer2.from([0])]
    ) : keyVals.map(tools_1.keyValsToBuffer);
    const inputBuffers = keyValsOrEmptyToBuffer(inputKeyVals);
    const outputBuffers = keyValsOrEmptyToBuffer(outputKeyVals);
    const header = Buffer2.allocUnsafe(5);
    header.writeUIntBE(482972169471, 0, 5);
    return Buffer2.concat(
      [header, globalBuffer].concat(inputBuffers, outputBuffers)
    );
  }
  toBuffer.psbtToBuffer = psbtToBuffer;
  const sortKeyVals = (a, b) => {
    return a.key.compare(b.key);
  };
  function keyValsFromMap(keyValMap, converterFactory) {
    const keyHexSet = /* @__PURE__ */ new Set();
    const keyVals = Object.entries(keyValMap).reduce((result, [key, value]) => {
      if (key === "unknownKeyVals") return result;
      const converter2 = converterFactory[key];
      if (converter2 === void 0) return result;
      const encodedKeyVals = (Array.isArray(value) ? value : [value]).map(
        converter2.encode
      );
      const keyHexes = encodedKeyVals.map((kv) => kv.key.toString("hex"));
      keyHexes.forEach((hex) => {
        if (keyHexSet.has(hex))
          throw new Error("Serialize Error: Duplicate key: " + hex);
        keyHexSet.add(hex);
      });
      return result.concat(encodedKeyVals);
    }, []);
    const otherKeyVals = keyValMap.unknownKeyVals ? keyValMap.unknownKeyVals.filter((keyVal) => {
      return !keyHexSet.has(keyVal.key.toString("hex"));
    }) : [];
    return keyVals.concat(otherKeyVals).sort(sortKeyVals);
  }
  function psbtToKeyVals({ globalMap, inputs, outputs }) {
    return {
      globalKeyVals: keyValsFromMap(globalMap, convert.globals),
      inputKeyVals: inputs.map((i) => keyValsFromMap(i, convert.inputs)),
      outputKeyVals: outputs.map((o) => keyValsFromMap(o, convert.outputs))
    };
  }
  toBuffer.psbtToKeyVals = psbtToKeyVals;
  return toBuffer;
}
var hasRequiredParser;
function requireParser() {
  if (hasRequiredParser) return parser;
  hasRequiredParser = 1;
  (function(exports) {
    function __export(m) {
      for (var p in m) if (!exports.hasOwnProperty(p)) exports[p] = m[p];
    }
    Object.defineProperty(exports, "__esModule", { value: true });
    __export(requireFromBuffer());
    __export(requireToBuffer());
  })(parser);
  return parser;
}
var hasRequiredCombiner;
function requireCombiner() {
  if (hasRequiredCombiner) return combiner;
  hasRequiredCombiner = 1;
  Object.defineProperty(combiner, "__esModule", { value: true });
  const parser_1 = requireParser();
  function combine(psbts) {
    const self = psbts[0];
    const selfKeyVals = parser_1.psbtToKeyVals(self);
    const others = psbts.slice(1);
    if (others.length === 0) throw new Error("Combine: Nothing to combine");
    const selfTx = getTx(self);
    if (selfTx === void 0) {
      throw new Error("Combine: Self missing transaction");
    }
    const selfGlobalSet = getKeySet(selfKeyVals.globalKeyVals);
    const selfInputSets = selfKeyVals.inputKeyVals.map(getKeySet);
    const selfOutputSets = selfKeyVals.outputKeyVals.map(getKeySet);
    for (const other of others) {
      const otherTx = getTx(other);
      if (otherTx === void 0 || !otherTx.toBuffer().equals(selfTx.toBuffer())) {
        throw new Error(
          "Combine: One of the Psbts does not have the same transaction."
        );
      }
      const otherKeyVals = parser_1.psbtToKeyVals(other);
      const otherGlobalSet = getKeySet(otherKeyVals.globalKeyVals);
      otherGlobalSet.forEach(
        keyPusher(
          selfGlobalSet,
          selfKeyVals.globalKeyVals,
          otherKeyVals.globalKeyVals
        )
      );
      const otherInputSets = otherKeyVals.inputKeyVals.map(getKeySet);
      otherInputSets.forEach(
        (inputSet, idx) => inputSet.forEach(
          keyPusher(
            selfInputSets[idx],
            selfKeyVals.inputKeyVals[idx],
            otherKeyVals.inputKeyVals[idx]
          )
        )
      );
      const otherOutputSets = otherKeyVals.outputKeyVals.map(getKeySet);
      otherOutputSets.forEach(
        (outputSet, idx) => outputSet.forEach(
          keyPusher(
            selfOutputSets[idx],
            selfKeyVals.outputKeyVals[idx],
            otherKeyVals.outputKeyVals[idx]
          )
        )
      );
    }
    return parser_1.psbtFromKeyVals(selfTx, {
      globalMapKeyVals: selfKeyVals.globalKeyVals,
      inputKeyVals: selfKeyVals.inputKeyVals,
      outputKeyVals: selfKeyVals.outputKeyVals
    });
  }
  combiner.combine = combine;
  function keyPusher(selfSet, selfKeyVals, otherKeyVals) {
    return (key) => {
      if (selfSet.has(key)) return;
      const newKv = otherKeyVals.filter(
        (kv) => kv.key.toString("hex") === key
      )[0];
      selfKeyVals.push(newKv);
      selfSet.add(key);
    };
  }
  function getTx(psbt2) {
    return psbt2.globalMap.unsignedTx;
  }
  function getKeySet(keyVals) {
    const set = /* @__PURE__ */ new Set();
    keyVals.forEach((keyVal) => {
      const hex = keyVal.key.toString("hex");
      if (set.has(hex))
        throw new Error("Combine: KeyValue Map keys should be unique");
      set.add(hex);
    });
    return set;
  }
  return combiner;
}
var utils = {};
var hasRequiredUtils;
function requireUtils() {
  if (hasRequiredUtils) return utils;
  hasRequiredUtils = 1;
  (function(exports) {
    const { Buffer: Buffer2 } = requireBuffer();
    Object.defineProperty(exports, "__esModule", { value: true });
    const converter2 = requireConverter();
    function checkForInput(inputs, inputIndex) {
      const input = inputs[inputIndex];
      if (input === void 0) throw new Error(`No input #${inputIndex}`);
      return input;
    }
    exports.checkForInput = checkForInput;
    function checkForOutput(outputs, outputIndex) {
      const output = outputs[outputIndex];
      if (output === void 0) throw new Error(`No output #${outputIndex}`);
      return output;
    }
    exports.checkForOutput = checkForOutput;
    function checkHasKey(checkKeyVal, keyVals, enumLength) {
      if (checkKeyVal.key[0] < enumLength) {
        throw new Error(
          `Use the method for your specific key instead of addUnknownKeyVal*`
        );
      }
      if (keyVals && keyVals.filter((kv) => kv.key.equals(checkKeyVal.key)).length !== 0) {
        throw new Error(`Duplicate Key: ${checkKeyVal.key.toString("hex")}`);
      }
    }
    exports.checkHasKey = checkHasKey;
    function getEnumLength(myenum) {
      let count = 0;
      Object.keys(myenum).forEach((val) => {
        if (Number(isNaN(Number(val)))) {
          count++;
        }
      });
      return count;
    }
    exports.getEnumLength = getEnumLength;
    function inputCheckUncleanFinalized(inputIndex, input) {
      let result = false;
      if (input.nonWitnessUtxo || input.witnessUtxo) {
        const needScriptSig = !!input.redeemScript;
        const needWitnessScript = !!input.witnessScript;
        const scriptSigOK = !needScriptSig || !!input.finalScriptSig;
        const witnessScriptOK = !needWitnessScript || !!input.finalScriptWitness;
        const hasOneFinal = !!input.finalScriptSig || !!input.finalScriptWitness;
        result = scriptSigOK && witnessScriptOK && hasOneFinal;
      }
      if (result === false) {
        throw new Error(
          `Input #${inputIndex} has too much or too little data to clean`
        );
      }
    }
    exports.inputCheckUncleanFinalized = inputCheckUncleanFinalized;
    function throwForUpdateMaker(typeName, name, expected, data) {
      throw new Error(
        `Data for ${typeName} key ${name} is incorrect: Expected ${expected} and got ${JSON.stringify(data)}`
      );
    }
    function updateMaker(typeName) {
      return (updateData, mainData) => {
        for (const name of Object.keys(updateData)) {
          const data = updateData[name];
          const { canAdd, canAddToArray, check, expected } = (
            // @ts-ignore
            converter2[typeName + "s"][name] || {}
          );
          const isArray = !!canAddToArray;
          if (check) {
            if (isArray) {
              if (!Array.isArray(data) || // @ts-ignore
              mainData[name] && !Array.isArray(mainData[name])) {
                throw new Error(`Key type ${name} must be an array`);
              }
              if (!data.every(check)) {
                throwForUpdateMaker(typeName, name, expected, data);
              }
              const arr = mainData[name] || [];
              const dupeCheckSet = /* @__PURE__ */ new Set();
              if (!data.every((v) => canAddToArray(arr, v, dupeCheckSet))) {
                throw new Error("Can not add duplicate data to array");
              }
              mainData[name] = arr.concat(data);
            } else {
              if (!check(data)) {
                throwForUpdateMaker(typeName, name, expected, data);
              }
              if (!canAdd(mainData, data)) {
                throw new Error(`Can not add duplicate data to ${typeName}`);
              }
              mainData[name] = data;
            }
          }
        }
      };
    }
    exports.updateGlobal = updateMaker("global");
    exports.updateInput = updateMaker("input");
    exports.updateOutput = updateMaker("output");
    function addInputAttributes(inputs, data) {
      const index = inputs.length - 1;
      const input = checkForInput(inputs, index);
      exports.updateInput(data, input);
    }
    exports.addInputAttributes = addInputAttributes;
    function addOutputAttributes(outputs, data) {
      const index = outputs.length - 1;
      const output = checkForOutput(outputs, index);
      exports.updateOutput(data, output);
    }
    exports.addOutputAttributes = addOutputAttributes;
    function defaultVersionSetter(version, txBuf) {
      if (!Buffer2.isBuffer(txBuf) || txBuf.length < 4) {
        throw new Error("Set Version: Invalid Transaction");
      }
      txBuf.writeUInt32LE(version, 0);
      return txBuf;
    }
    exports.defaultVersionSetter = defaultVersionSetter;
    function defaultLocktimeSetter(locktime, txBuf) {
      if (!Buffer2.isBuffer(txBuf) || txBuf.length < 4) {
        throw new Error("Set Locktime: Invalid Transaction");
      }
      txBuf.writeUInt32LE(locktime, txBuf.length - 4);
      return txBuf;
    }
    exports.defaultLocktimeSetter = defaultLocktimeSetter;
  })(utils);
  return utils;
}
var hasRequiredPsbt;
function requirePsbt() {
  if (hasRequiredPsbt) return psbt;
  hasRequiredPsbt = 1;
  const { Buffer: Buffer2 } = requireBuffer();
  Object.defineProperty(psbt, "__esModule", { value: true });
  const combiner_1 = requireCombiner();
  const parser_1 = requireParser();
  const typeFields_1 = requireTypeFields();
  const utils_1 = requireUtils();
  class Psbt2 {
    constructor(tx) {
      this.inputs = [];
      this.outputs = [];
      this.globalMap = {
        unsignedTx: tx
      };
    }
    static fromBase64(data, txFromBuffer) {
      const buffer = Buffer2.from(data, "base64");
      return this.fromBuffer(buffer, txFromBuffer);
    }
    static fromHex(data, txFromBuffer) {
      const buffer = Buffer2.from(data, "hex");
      return this.fromBuffer(buffer, txFromBuffer);
    }
    static fromBuffer(buffer, txFromBuffer) {
      const results = parser_1.psbtFromBuffer(buffer, txFromBuffer);
      const psbt2 = new this(results.globalMap.unsignedTx);
      Object.assign(psbt2, results);
      return psbt2;
    }
    toBase64() {
      const buffer = this.toBuffer();
      return buffer.toString("base64");
    }
    toHex() {
      const buffer = this.toBuffer();
      return buffer.toString("hex");
    }
    toBuffer() {
      return parser_1.psbtToBuffer(this);
    }
    updateGlobal(updateData) {
      utils_1.updateGlobal(updateData, this.globalMap);
      return this;
    }
    updateInput(inputIndex, updateData) {
      const input = utils_1.checkForInput(this.inputs, inputIndex);
      utils_1.updateInput(updateData, input);
      return this;
    }
    updateOutput(outputIndex, updateData) {
      const output = utils_1.checkForOutput(this.outputs, outputIndex);
      utils_1.updateOutput(updateData, output);
      return this;
    }
    addUnknownKeyValToGlobal(keyVal) {
      utils_1.checkHasKey(
        keyVal,
        this.globalMap.unknownKeyVals,
        utils_1.getEnumLength(typeFields_1.GlobalTypes)
      );
      if (!this.globalMap.unknownKeyVals) this.globalMap.unknownKeyVals = [];
      this.globalMap.unknownKeyVals.push(keyVal);
      return this;
    }
    addUnknownKeyValToInput(inputIndex, keyVal) {
      const input = utils_1.checkForInput(this.inputs, inputIndex);
      utils_1.checkHasKey(
        keyVal,
        input.unknownKeyVals,
        utils_1.getEnumLength(typeFields_1.InputTypes)
      );
      if (!input.unknownKeyVals) input.unknownKeyVals = [];
      input.unknownKeyVals.push(keyVal);
      return this;
    }
    addUnknownKeyValToOutput(outputIndex, keyVal) {
      const output = utils_1.checkForOutput(this.outputs, outputIndex);
      utils_1.checkHasKey(
        keyVal,
        output.unknownKeyVals,
        utils_1.getEnumLength(typeFields_1.OutputTypes)
      );
      if (!output.unknownKeyVals) output.unknownKeyVals = [];
      output.unknownKeyVals.push(keyVal);
      return this;
    }
    addInput(inputData) {
      this.globalMap.unsignedTx.addInput(inputData);
      this.inputs.push({
        unknownKeyVals: []
      });
      const addKeyVals = inputData.unknownKeyVals || [];
      const inputIndex = this.inputs.length - 1;
      if (!Array.isArray(addKeyVals)) {
        throw new Error("unknownKeyVals must be an Array");
      }
      addKeyVals.forEach(
        (keyVal) => this.addUnknownKeyValToInput(inputIndex, keyVal)
      );
      utils_1.addInputAttributes(this.inputs, inputData);
      return this;
    }
    addOutput(outputData) {
      this.globalMap.unsignedTx.addOutput(outputData);
      this.outputs.push({
        unknownKeyVals: []
      });
      const addKeyVals = outputData.unknownKeyVals || [];
      const outputIndex = this.outputs.length - 1;
      if (!Array.isArray(addKeyVals)) {
        throw new Error("unknownKeyVals must be an Array");
      }
      addKeyVals.forEach(
        (keyVal) => this.addUnknownKeyValToInput(outputIndex, keyVal)
      );
      utils_1.addOutputAttributes(this.outputs, outputData);
      return this;
    }
    clearFinalizedInput(inputIndex) {
      const input = utils_1.checkForInput(this.inputs, inputIndex);
      utils_1.inputCheckUncleanFinalized(inputIndex, input);
      for (const key of Object.keys(input)) {
        if (![
          "witnessUtxo",
          "nonWitnessUtxo",
          "finalScriptSig",
          "finalScriptWitness",
          "unknownKeyVals"
        ].includes(key)) {
          delete input[key];
        }
      }
      return this;
    }
    combine(...those) {
      const result = combiner_1.combine([this].concat(those));
      Object.assign(this, result);
      return this;
    }
    getTransaction() {
      return this.globalMap.unsignedTx.toBuffer();
    }
  }
  psbt.Psbt = Psbt2;
  return psbt;
}
var bip174;
var hasRequiredBip174;
function requireBip174() {
  if (hasRequiredBip174) return bip174;
  hasRequiredBip174 = 1;
  bip174 = requirePsbt();
  return bip174;
}
var bip174Exports = requireBip174();
var varintExports = requireVarint();
const converter_varint_cjs = /* @__PURE__ */ getDefaultExportFromCjs(varintExports);
var utilsExports = requireUtils();
const converter_varint = converter_varint_cjs;
const { typeforce } = types;
function varSliceSize(someScript) {
  const length = someScript.length;
  return varuintBitcoinExports.encodingLength(length) + length;
}
function vectorSize(someVector) {
  const length = someVector.length;
  return varuintBitcoinExports.encodingLength(length) + someVector.reduce((sum, witness) => {
    return sum + varSliceSize(witness);
  }, 0);
}
const EMPTY_BUFFER = Buffer.allocUnsafe(0);
const EMPTY_WITNESS = [];
const ZERO = Buffer.from("0000000000000000000000000000000000000000000000000000000000000000", "hex");
const ONE = Buffer.from("0000000000000000000000000000000000000000000000000000000000000001", "hex");
const VALUE_UINT64_MAX = Buffer.from("ffffffffffffffff", "hex");
const BLANK_OUTPUT = {
  script: EMPTY_BUFFER,
  valueBuffer: VALUE_UINT64_MAX
};
function isOutput(out) {
  return out.value !== void 0;
}
class Transaction {
  constructor() {
    this.version = 1;
    this.locktime = 0;
    this.ins = [];
    this.outs = [];
  }
  static fromBuffer(buffer, _NO_STRICT) {
    const bufferReader = new BufferReader(buffer);
    const tx = new Transaction();
    tx.version = bufferReader.readInt32();
    const marker = bufferReader.readUInt8();
    const flag = bufferReader.readUInt8();
    let hasWitnesses = false;
    if (marker === Transaction.ADVANCED_TRANSACTION_MARKER && flag === Transaction.ADVANCED_TRANSACTION_FLAG) {
      hasWitnesses = true;
    } else {
      bufferReader.offset -= 2;
    }
    const vinLen = bufferReader.readVarInt();
    for (let i = 0; i < vinLen; ++i) {
      tx.ins.push({
        hash: bufferReader.readSlice(32),
        index: bufferReader.readUInt32(),
        script: bufferReader.readVarSlice(),
        sequence: bufferReader.readUInt32(),
        witness: EMPTY_WITNESS
      });
    }
    const voutLen = bufferReader.readVarInt();
    for (let i = 0; i < voutLen; ++i) {
      tx.outs.push({
        value: bufferReader.readUInt64(),
        script: bufferReader.readVarSlice()
      });
    }
    if (hasWitnesses) {
      for (let i = 0; i < vinLen; ++i) {
        tx.ins[i].witness = bufferReader.readVector();
      }
      if (!tx.hasWitnesses())
        throw new Error("Transaction has superfluous witness data");
    }
    tx.locktime = bufferReader.readUInt32();
    if (_NO_STRICT)
      return tx;
    if (bufferReader.offset !== buffer.length)
      throw new Error("Transaction has unexpected data");
    return tx;
  }
  static fromHex(hex) {
    return Transaction.fromBuffer(Buffer.from(hex, "hex"), false);
  }
  static isCoinbaseHash(buffer) {
    typeforce(Hash256bit, buffer);
    for (let i = 0; i < 32; ++i) {
      if (buffer[i] !== 0)
        return false;
    }
    return true;
  }
  isCoinbase() {
    return this.ins.length === 1 && Transaction.isCoinbaseHash(this.ins[0].hash);
  }
  addInput(hash, index, sequence, scriptSig) {
    typeforce(tuple(Hash256bit, UInt32, maybe(UInt32), maybe(Buffer$1)), arguments);
    if (Null(sequence)) {
      sequence = Transaction.DEFAULT_SEQUENCE;
    }
    return this.ins.push({
      hash,
      index,
      script: scriptSig || EMPTY_BUFFER,
      sequence,
      witness: EMPTY_WITNESS
    }) - 1;
  }
  addOutput(scriptPubKey, value) {
    typeforce(tuple(Buffer$1, Satoshi), arguments);
    return this.outs.push({
      script: scriptPubKey,
      value
    }) - 1;
  }
  hasWitnesses() {
    return this.ins.some((x) => {
      return x.witness.length !== 0;
    });
  }
  weight() {
    const base = this.byteLength(false);
    const total = this.byteLength(true);
    return base * 3 + total;
  }
  virtualSize() {
    return Math.ceil(this.weight() / 4);
  }
  byteLength(_ALLOW_WITNESS = true) {
    const hasWitnesses = _ALLOW_WITNESS && this.hasWitnesses();
    return (hasWitnesses ? 10 : 8) + varuintBitcoinExports.encodingLength(this.ins.length) + varuintBitcoinExports.encodingLength(this.outs.length) + this.ins.reduce((sum, input) => {
      return sum + 40 + varSliceSize(input.script);
    }, 0) + this.outs.reduce((sum, output) => {
      return sum + 8 + varSliceSize(output.script);
    }, 0) + (hasWitnesses ? this.ins.reduce((sum, input) => {
      return sum + vectorSize(input.witness);
    }, 0) : 0);
  }
  clone() {
    const newTx = new Transaction();
    newTx.version = this.version;
    newTx.locktime = this.locktime;
    newTx.ins = this.ins.map((txIn) => {
      return {
        hash: txIn.hash,
        index: txIn.index,
        script: txIn.script,
        sequence: txIn.sequence,
        witness: txIn.witness
      };
    });
    newTx.outs = this.outs.map((txOut) => {
      return {
        script: txOut.script,
        value: txOut.value
      };
    });
    return newTx;
  }
  /**
   * Hash transaction for signing a specific input.
   *
   * Bitcoin uses a different hash for each signed transaction input.
   * This method copies the transaction, makes the necessary changes based on the
   * hashType, and then hashes the result.
   * This hash can then be used to sign the provided transaction input.
   */
  hashForSignature(inIndex, prevOutScript, hashType) {
    typeforce(tuple(
      UInt32,
      Buffer$1,
      /* types.UInt8 */
      Number$1
    ), arguments);
    if (inIndex >= this.ins.length)
      return ONE;
    const ourScript = compile(decompile(prevOutScript).filter((x) => {
      return x !== OPS.OP_CODESEPARATOR;
    }));
    const txTmp = this.clone();
    if ((hashType & 31) === Transaction.SIGHASH_NONE) {
      txTmp.outs = [];
      txTmp.ins.forEach((input, i) => {
        if (i === inIndex)
          return;
        input.sequence = 0;
      });
    } else if ((hashType & 31) === Transaction.SIGHASH_SINGLE) {
      if (inIndex >= this.outs.length)
        return ONE;
      txTmp.outs.length = inIndex + 1;
      for (let i = 0; i < inIndex; i++) {
        txTmp.outs[i] = BLANK_OUTPUT;
      }
      txTmp.ins.forEach((input, y) => {
        if (y === inIndex)
          return;
        input.sequence = 0;
      });
    }
    if (hashType & Transaction.SIGHASH_ANYONECANPAY) {
      txTmp.ins = [txTmp.ins[inIndex]];
      txTmp.ins[0].script = ourScript;
    } else {
      txTmp.ins.forEach((input) => {
        input.script = EMPTY_BUFFER;
      });
      txTmp.ins[inIndex].script = ourScript;
    }
    const buffer = Buffer.allocUnsafe(txTmp.byteLength(false) + 4);
    buffer.writeInt32LE(hashType, buffer.length - 4);
    txTmp.__toBuffer(buffer, 0, false);
    return hash256(buffer);
  }
  hashForWitnessV1(inIndex, prevOutScripts, values, hashType, leafHash, annex) {
    typeforce(tuple(UInt32, typeforce.arrayOf(Buffer$1), typeforce.arrayOf(Satoshi), UInt32), arguments);
    if (values.length !== this.ins.length || prevOutScripts.length !== this.ins.length) {
      throw new Error("Must supply prevout script and value for all inputs");
    }
    const outputType = hashType === Transaction.SIGHASH_DEFAULT ? Transaction.SIGHASH_ALL : hashType & Transaction.SIGHASH_OUTPUT_MASK;
    const inputType = hashType & Transaction.SIGHASH_INPUT_MASK;
    const isAnyoneCanPay = inputType === Transaction.SIGHASH_ANYONECANPAY;
    const isNone = outputType === Transaction.SIGHASH_NONE;
    const isSingle = outputType === Transaction.SIGHASH_SINGLE;
    let hashPrevouts = EMPTY_BUFFER;
    let hashAmounts = EMPTY_BUFFER;
    let hashScriptPubKeys = EMPTY_BUFFER;
    let hashSequences = EMPTY_BUFFER;
    let hashOutputs = EMPTY_BUFFER;
    if (!isAnyoneCanPay) {
      let bufferWriter = BufferWriter.withCapacity(36 * this.ins.length);
      this.ins.forEach((txIn) => {
        bufferWriter.writeSlice(txIn.hash);
        bufferWriter.writeUInt32(txIn.index);
      });
      hashPrevouts = sha256(bufferWriter.end());
      bufferWriter = BufferWriter.withCapacity(8 * this.ins.length);
      values.forEach((value) => bufferWriter.writeUInt64(value));
      hashAmounts = sha256(bufferWriter.end());
      bufferWriter = BufferWriter.withCapacity(prevOutScripts.map(varSliceSize).reduce((a, b) => a + b));
      prevOutScripts.forEach((prevOutScript) => bufferWriter.writeVarSlice(prevOutScript));
      hashScriptPubKeys = sha256(bufferWriter.end());
      bufferWriter = BufferWriter.withCapacity(4 * this.ins.length);
      this.ins.forEach((txIn) => bufferWriter.writeUInt32(txIn.sequence));
      hashSequences = sha256(bufferWriter.end());
    }
    if (!(isNone || isSingle)) {
      const txOutsSize = this.outs.map((output) => 8 + varSliceSize(output.script)).reduce((a, b) => a + b);
      const bufferWriter = BufferWriter.withCapacity(txOutsSize);
      this.outs.forEach((out) => {
        bufferWriter.writeUInt64(out.value);
        bufferWriter.writeVarSlice(out.script);
      });
      hashOutputs = sha256(bufferWriter.end());
    } else if (isSingle && inIndex < this.outs.length) {
      const output = this.outs[inIndex];
      const bufferWriter = BufferWriter.withCapacity(8 + varSliceSize(output.script));
      bufferWriter.writeUInt64(output.value);
      bufferWriter.writeVarSlice(output.script);
      hashOutputs = sha256(bufferWriter.end());
    }
    const spendType = (leafHash ? 2 : 0) + (annex ? 1 : 0);
    const sigMsgSize = 174 - (isAnyoneCanPay ? 49 : 0) - (isNone ? 32 : 0) + (annex ? 32 : 0) + (leafHash ? 37 : 0);
    const sigMsgWriter = BufferWriter.withCapacity(sigMsgSize);
    sigMsgWriter.writeUInt8(hashType);
    sigMsgWriter.writeInt32(this.version);
    sigMsgWriter.writeUInt32(this.locktime);
    sigMsgWriter.writeSlice(hashPrevouts);
    sigMsgWriter.writeSlice(hashAmounts);
    sigMsgWriter.writeSlice(hashScriptPubKeys);
    sigMsgWriter.writeSlice(hashSequences);
    if (!(isNone || isSingle)) {
      sigMsgWriter.writeSlice(hashOutputs);
    }
    sigMsgWriter.writeUInt8(spendType);
    if (isAnyoneCanPay) {
      const input = this.ins[inIndex];
      sigMsgWriter.writeSlice(input.hash);
      sigMsgWriter.writeUInt32(input.index);
      sigMsgWriter.writeUInt64(values[inIndex]);
      sigMsgWriter.writeVarSlice(prevOutScripts[inIndex]);
      sigMsgWriter.writeUInt32(input.sequence);
    } else {
      sigMsgWriter.writeUInt32(inIndex);
    }
    if (annex) {
      const bufferWriter = BufferWriter.withCapacity(varSliceSize(annex));
      bufferWriter.writeVarSlice(annex);
      sigMsgWriter.writeSlice(sha256(bufferWriter.end()));
    }
    if (isSingle) {
      sigMsgWriter.writeSlice(hashOutputs);
    }
    if (leafHash) {
      sigMsgWriter.writeSlice(leafHash);
      sigMsgWriter.writeUInt8(0);
      sigMsgWriter.writeUInt32(4294967295);
    }
    return taggedHash("TapSighash", Buffer.concat([Buffer.of(0), sigMsgWriter.end()]));
  }
  hashForWitnessV0(inIndex, prevOutScript, value, hashType) {
    typeforce(tuple(UInt32, Buffer$1, Satoshi, UInt32), arguments);
    let tbuffer = Buffer.from([]);
    let bufferWriter;
    let hashOutputs = ZERO;
    let hashPrevouts = ZERO;
    let hashSequence = ZERO;
    if (!(hashType & Transaction.SIGHASH_ANYONECANPAY)) {
      tbuffer = Buffer.allocUnsafe(36 * this.ins.length);
      bufferWriter = new BufferWriter(tbuffer, 0);
      this.ins.forEach((txIn) => {
        bufferWriter.writeSlice(txIn.hash);
        bufferWriter.writeUInt32(txIn.index);
      });
      hashPrevouts = hash256(tbuffer);
    }
    if (!(hashType & Transaction.SIGHASH_ANYONECANPAY) && (hashType & 31) !== Transaction.SIGHASH_SINGLE && (hashType & 31) !== Transaction.SIGHASH_NONE) {
      tbuffer = Buffer.allocUnsafe(4 * this.ins.length);
      bufferWriter = new BufferWriter(tbuffer, 0);
      this.ins.forEach((txIn) => {
        bufferWriter.writeUInt32(txIn.sequence);
      });
      hashSequence = hash256(tbuffer);
    }
    if ((hashType & 31) !== Transaction.SIGHASH_SINGLE && (hashType & 31) !== Transaction.SIGHASH_NONE) {
      const txOutsSize = this.outs.reduce((sum, output) => {
        return sum + 8 + varSliceSize(output.script);
      }, 0);
      tbuffer = Buffer.allocUnsafe(txOutsSize);
      bufferWriter = new BufferWriter(tbuffer, 0);
      this.outs.forEach((out) => {
        bufferWriter.writeUInt64(out.value);
        bufferWriter.writeVarSlice(out.script);
      });
      hashOutputs = hash256(tbuffer);
    } else if ((hashType & 31) === Transaction.SIGHASH_SINGLE && inIndex < this.outs.length) {
      const output = this.outs[inIndex];
      tbuffer = Buffer.allocUnsafe(8 + varSliceSize(output.script));
      bufferWriter = new BufferWriter(tbuffer, 0);
      bufferWriter.writeUInt64(output.value);
      bufferWriter.writeVarSlice(output.script);
      hashOutputs = hash256(tbuffer);
    }
    tbuffer = Buffer.allocUnsafe(156 + varSliceSize(prevOutScript));
    bufferWriter = new BufferWriter(tbuffer, 0);
    const input = this.ins[inIndex];
    bufferWriter.writeInt32(this.version);
    bufferWriter.writeSlice(hashPrevouts);
    bufferWriter.writeSlice(hashSequence);
    bufferWriter.writeSlice(input.hash);
    bufferWriter.writeUInt32(input.index);
    bufferWriter.writeVarSlice(prevOutScript);
    bufferWriter.writeUInt64(value);
    bufferWriter.writeUInt32(input.sequence);
    bufferWriter.writeSlice(hashOutputs);
    bufferWriter.writeUInt32(this.locktime);
    bufferWriter.writeUInt32(hashType);
    return hash256(tbuffer);
  }
  getHash(forWitness) {
    if (forWitness && this.isCoinbase())
      return Buffer.alloc(32, 0);
    return hash256(this.__toBuffer(void 0, void 0, forWitness));
  }
  getId() {
    return reverseBuffer(this.getHash(false)).toString("hex");
  }
  toBuffer(buffer, initialOffset) {
    return this.__toBuffer(buffer, initialOffset, true);
  }
  toHex() {
    return this.toBuffer(void 0, void 0).toString("hex");
  }
  setInputScript(index, scriptSig) {
    typeforce(tuple(Number$1, Buffer$1), arguments);
    this.ins[index].script = scriptSig;
  }
  setWitness(index, witness) {
    typeforce(tuple(Number$1, [Buffer$1]), arguments);
    this.ins[index].witness = witness;
  }
  __toBuffer(buffer, initialOffset, _ALLOW_WITNESS = false) {
    if (!buffer)
      buffer = Buffer.allocUnsafe(this.byteLength(_ALLOW_WITNESS));
    const bufferWriter = new BufferWriter(buffer, initialOffset || 0);
    bufferWriter.writeInt32(this.version);
    const hasWitnesses = _ALLOW_WITNESS && this.hasWitnesses();
    if (hasWitnesses) {
      bufferWriter.writeUInt8(Transaction.ADVANCED_TRANSACTION_MARKER);
      bufferWriter.writeUInt8(Transaction.ADVANCED_TRANSACTION_FLAG);
    }
    bufferWriter.writeVarInt(this.ins.length);
    this.ins.forEach((txIn) => {
      bufferWriter.writeSlice(txIn.hash);
      bufferWriter.writeUInt32(txIn.index);
      bufferWriter.writeVarSlice(txIn.script);
      bufferWriter.writeUInt32(txIn.sequence);
    });
    bufferWriter.writeVarInt(this.outs.length);
    this.outs.forEach((txOut) => {
      if (isOutput(txOut)) {
        bufferWriter.writeUInt64(txOut.value);
      } else {
        bufferWriter.writeSlice(txOut.valueBuffer);
      }
      bufferWriter.writeVarSlice(txOut.script);
    });
    if (hasWitnesses) {
      this.ins.forEach((input) => {
        bufferWriter.writeVector(input.witness);
      });
    }
    bufferWriter.writeUInt32(this.locktime);
    if (initialOffset !== void 0)
      return buffer.slice(initialOffset, bufferWriter.offset);
    return buffer;
  }
}
Transaction.DEFAULT_SEQUENCE = 4294967295;
Transaction.SIGHASH_DEFAULT = 0;
Transaction.SIGHASH_ALL = 1;
Transaction.SIGHASH_NONE = 2;
Transaction.SIGHASH_SINGLE = 3;
Transaction.SIGHASH_ANYONECANPAY = 128;
Transaction.SIGHASH_OUTPUT_MASK = 3;
Transaction.SIGHASH_INPUT_MASK = 128;
Transaction.ADVANCED_TRANSACTION_MARKER = 0;
Transaction.ADVANCED_TRANSACTION_FLAG = 1;
const DEFAULT_OPTS = {
  /**
   * A bitcoinjs Network object. This is only used if you pass an `address`
   * parameter to addOutput. Otherwise it is not needed and can be left default.
   */
  network: bitcoin,
  /**
   * When extractTransaction is called, the fee rate is checked.
   * THIS IS NOT TO BE RELIED ON.
   * It is only here as a last ditch effort to prevent sending a 500 BTC fee etc.
   */
  maximumFeeRate: 5e3
  // satoshi per byte
};
class Psbt {
  static fromBase64(data, opts = {}) {
    const buffer = Buffer.from(data, "base64");
    return this.fromBuffer(buffer, opts);
  }
  static fromHex(data, opts = {}) {
    const buffer = Buffer.from(data, "hex");
    return this.fromBuffer(buffer, opts);
  }
  static fromBuffer(buffer, opts = {}) {
    const psbtBase = bip174Exports.Psbt.fromBuffer(buffer, transactionFromBuffer);
    const psbt2 = new Psbt(opts, psbtBase);
    checkTxForDupeIns(psbt2.__CACHE.__TX, psbt2.__CACHE);
    return psbt2;
  }
  constructor(opts = {}, data = new bip174Exports.Psbt(new PsbtTransaction())) {
    this.data = data;
    this.opts = Object.assign({}, DEFAULT_OPTS, opts);
    this.__CACHE = {
      __NON_WITNESS_UTXO_TX_CACHE: [],
      __NON_WITNESS_UTXO_BUF_CACHE: [],
      __TX_IN_CACHE: {},
      __TX: this.data.globalMap.unsignedTx.tx,
      // Psbt's predecesor (TransactionBuilder - now removed) behavior
      // was to not confirm input values  before signing.
      // Even though we highly encourage people to get
      // the full parent transaction to verify values, the ability to
      // sign non-segwit inputs without the full transaction was often
      // requested. So the only way to activate is to use @ts-ignore.
      // We will disable exporting the Psbt when unsafe sign is active.
      // because it is not BIP174 compliant.
      __UNSAFE_SIGN_NONSEGWIT: false
    };
    if (this.data.inputs.length === 0)
      this.setVersion(2);
    const dpew = (obj, attr, enumerable, writable) => Object.defineProperty(obj, attr, {
      enumerable,
      writable
    });
    dpew(this, "__CACHE", false, true);
    dpew(this, "opts", false, true);
  }
  get inputCount() {
    return this.data.inputs.length;
  }
  get version() {
    return this.__CACHE.__TX.version;
  }
  set version(version) {
    this.setVersion(version);
  }
  get locktime() {
    return this.__CACHE.__TX.locktime;
  }
  set locktime(locktime) {
    this.setLocktime(locktime);
  }
  get txInputs() {
    return this.__CACHE.__TX.ins.map((input) => ({
      hash: cloneBuffer(input.hash),
      index: input.index,
      sequence: input.sequence
    }));
  }
  get txOutputs() {
    return this.__CACHE.__TX.outs.map((output) => {
      let address;
      try {
        address = fromOutputScript(output.script, this.opts.network);
      } catch (_) {
      }
      return {
        script: cloneBuffer(output.script),
        value: output.value,
        address
      };
    });
  }
  combine(...those) {
    this.data.combine(...those.map((o) => o.data));
    return this;
  }
  clone() {
    const res = Psbt.fromBuffer(this.data.toBuffer());
    res.opts = JSON.parse(JSON.stringify(this.opts));
    return res;
  }
  setMaximumFeeRate(satoshiPerByte) {
    check32Bit(satoshiPerByte);
    this.opts.maximumFeeRate = satoshiPerByte;
  }
  setVersion(version) {
    check32Bit(version);
    checkInputsForPartialSig(this.data.inputs, "setVersion");
    const c = this.__CACHE;
    c.__TX.version = version;
    c.__EXTRACTED_TX = void 0;
    return this;
  }
  setLocktime(locktime) {
    check32Bit(locktime);
    checkInputsForPartialSig(this.data.inputs, "setLocktime");
    const c = this.__CACHE;
    c.__TX.locktime = locktime;
    c.__EXTRACTED_TX = void 0;
    return this;
  }
  setInputSequence(inputIndex, sequence) {
    check32Bit(sequence);
    checkInputsForPartialSig(this.data.inputs, "setInputSequence");
    const c = this.__CACHE;
    if (c.__TX.ins.length <= inputIndex) {
      throw new Error("Input index too high");
    }
    c.__TX.ins[inputIndex].sequence = sequence;
    c.__EXTRACTED_TX = void 0;
    return this;
  }
  addInputs(inputDatas) {
    inputDatas.forEach((inputData) => this.addInput(inputData));
    return this;
  }
  addInput(inputData) {
    if (arguments.length > 1 || !inputData || inputData.hash === void 0 || inputData.index === void 0) {
      throw new Error(`Invalid arguments for Psbt.addInput. Requires single object with at least [hash] and [index]`);
    }
    checkInputsForPartialSig(this.data.inputs, "addInput");
    if (inputData.witnessScript)
      checkInvalidP2WSH(inputData.witnessScript);
    const c = this.__CACHE;
    this.data.addInput(inputData);
    const txIn = c.__TX.ins[c.__TX.ins.length - 1];
    checkTxInputCache(c, txIn);
    const inputIndex = this.data.inputs.length - 1;
    const input = this.data.inputs[inputIndex];
    if (input.nonWitnessUtxo) {
      addNonWitnessTxCache(this.__CACHE, input, inputIndex);
    }
    c.__FEE = void 0;
    c.__FEE_RATE = void 0;
    c.__EXTRACTED_TX = void 0;
    return this;
  }
  addOutputs(outputDatas) {
    outputDatas.forEach((outputData) => this.addOutput(outputData));
    return this;
  }
  addOutput(outputData) {
    if (arguments.length > 1 || !outputData || outputData.value === void 0 || outputData.address === void 0 && outputData.script === void 0) {
      throw new Error(`Invalid arguments for Psbt.addOutput. Requires single object with at least [script or address] and [value]`);
    }
    checkInputsForPartialSig(this.data.inputs, "addOutput");
    const { address } = outputData;
    if (typeof address === "string") {
      const { network } = this.opts;
      const script = toOutputScript(address, network);
      outputData = Object.assign(outputData, { script });
    }
    const c = this.__CACHE;
    this.data.addOutput(outputData);
    c.__FEE = void 0;
    c.__FEE_RATE = void 0;
    c.__EXTRACTED_TX = void 0;
    return this;
  }
  extractTransaction(disableFeeCheck) {
    if (!this.data.inputs.every(isFinalized))
      throw new Error("Not finalized");
    const c = this.__CACHE;
    if (!disableFeeCheck) {
      checkFees(this, c, this.opts);
    }
    if (c.__EXTRACTED_TX)
      return c.__EXTRACTED_TX;
    const tx = c.__TX.clone();
    inputFinalizeGetAmts(this.data.inputs, tx, c, true);
    return tx;
  }
  getFeeRate() {
    return getTxCacheValue("__FEE_RATE", "fee rate", this.data.inputs, this.__CACHE);
  }
  getFee() {
    return getTxCacheValue("__FEE", "fee", this.data.inputs, this.__CACHE);
  }
  finalizeAllInputs() {
    utilsExports.checkForInput(this.data.inputs, 0);
    range(this.data.inputs.length).forEach((idx) => this.finalizeInput(idx));
    return this;
  }
  finalizeInput(inputIndex, finalScriptsFunc = getFinalScripts) {
    const input = utilsExports.checkForInput(this.data.inputs, inputIndex);
    const { script, isP2SH, isP2WSH, isSegwit } = getScriptFromInput(inputIndex, input, this.__CACHE);
    if (!script)
      throw new Error(`No script found for input #${inputIndex}`);
    checkPartialSigSighashes(input);
    const { finalScriptSig: finalScriptSig2, finalScriptWitness: finalScriptWitness2 } = finalScriptsFunc(inputIndex, input, script, isSegwit, isP2SH, isP2WSH);
    if (finalScriptSig2)
      this.data.updateInput(inputIndex, { finalScriptSig: finalScriptSig2 });
    if (finalScriptWitness2)
      this.data.updateInput(inputIndex, { finalScriptWitness: finalScriptWitness2 });
    if (!finalScriptSig2 && !finalScriptWitness2)
      throw new Error(`Unknown error finalizing input #${inputIndex}`);
    this.data.clearFinalizedInput(inputIndex);
    return this;
  }
  getInputType(inputIndex) {
    const input = utilsExports.checkForInput(this.data.inputs, inputIndex);
    const script = getScriptFromUtxo(inputIndex, input, this.__CACHE);
    const result = getMeaningfulScript(script, inputIndex, "input", input.redeemScript || redeemFromFinalScriptSig(input.finalScriptSig), input.witnessScript || redeemFromFinalWitnessScript(input.finalScriptWitness));
    const type = result.type === "raw" ? "" : result.type + "-";
    const mainType = classifyScript(result.meaningfulScript);
    return type + mainType;
  }
  inputHasPubkey(inputIndex, pubkey) {
    const input = utilsExports.checkForInput(this.data.inputs, inputIndex);
    return pubkeyInInput(pubkey, input, inputIndex, this.__CACHE);
  }
  inputHasHDKey(inputIndex, root) {
    const input = utilsExports.checkForInput(this.data.inputs, inputIndex);
    const derivationIsMine = bip32DerivationIsMine(root);
    return !!input.bip32Derivation && input.bip32Derivation.some(derivationIsMine);
  }
  outputHasPubkey(outputIndex, pubkey) {
    const output = utilsExports.checkForOutput(this.data.outputs, outputIndex);
    return pubkeyInOutput(pubkey, output, outputIndex, this.__CACHE);
  }
  outputHasHDKey(outputIndex, root) {
    const output = utilsExports.checkForOutput(this.data.outputs, outputIndex);
    const derivationIsMine = bip32DerivationIsMine(root);
    return !!output.bip32Derivation && output.bip32Derivation.some(derivationIsMine);
  }
  validateSignaturesOfAllInputs(validator) {
    utilsExports.checkForInput(this.data.inputs, 0);
    const results = range(this.data.inputs.length).map((idx) => this.validateSignaturesOfInput(idx, validator));
    return results.reduce((final, res) => res === true && final, true);
  }
  validateSignaturesOfInput(inputIndex, validator, pubkey) {
    const input = this.data.inputs[inputIndex];
    const partialSig2 = (input || {}).partialSig;
    if (!input || !partialSig2 || partialSig2.length < 1)
      throw new Error("No signatures to validate");
    if (typeof validator !== "function")
      throw new Error("Need validator function to validate signatures");
    const mySigs = pubkey ? partialSig2.filter((sig) => sig.pubkey.equals(pubkey)) : partialSig2;
    if (mySigs.length < 1)
      throw new Error("No signatures for this pubkey");
    const results = [];
    let hashCache;
    let scriptCache;
    let sighashCache;
    for (const pSig of mySigs) {
      const sig = signature.decode(pSig.signature);
      const { hash, script } = sighashCache !== sig.hashType ? getHashForSig(inputIndex, Object.assign({}, input, { sighashType: sig.hashType }), this.__CACHE, true) : { hash: hashCache, script: scriptCache };
      sighashCache = sig.hashType;
      hashCache = hash;
      scriptCache = script;
      checkScriptForPubkey(pSig.pubkey, script, "verify");
      results.push(validator(pSig.pubkey, hash, sig.signature));
    }
    return results.every((res) => res === true);
  }
  signAllInputsHD(hdKeyPair, sighashTypes = [Transaction.SIGHASH_ALL]) {
    if (!hdKeyPair || !hdKeyPair.publicKey || !hdKeyPair.fingerprint) {
      throw new Error("Need HDSigner to sign input");
    }
    const results = [];
    for (const i of range(this.data.inputs.length)) {
      try {
        this.signInputHD(i, hdKeyPair, sighashTypes);
        results.push(true);
      } catch (err) {
        results.push(false);
      }
    }
    if (results.every((v) => v === false)) {
      throw new Error("No inputs were signed");
    }
    return this;
  }
  signAllInputsHDAsync(hdKeyPair, sighashTypes = [Transaction.SIGHASH_ALL]) {
    return new Promise((resolve, reject) => {
      if (!hdKeyPair || !hdKeyPair.publicKey || !hdKeyPair.fingerprint) {
        return reject(new Error("Need HDSigner to sign input"));
      }
      const results = [];
      const promises = [];
      for (const i of range(this.data.inputs.length)) {
        promises.push(this.signInputHDAsync(i, hdKeyPair, sighashTypes).then(() => {
          results.push(true);
        }, () => {
          results.push(false);
        }));
      }
      return Promise.all(promises).then(() => {
        if (results.every((v) => v === false)) {
          return reject(new Error("No inputs were signed"));
        }
        resolve();
      });
    });
  }
  signInputHD(inputIndex, hdKeyPair, sighashTypes = [Transaction.SIGHASH_ALL]) {
    if (!hdKeyPair || !hdKeyPair.publicKey || !hdKeyPair.fingerprint) {
      throw new Error("Need HDSigner to sign input");
    }
    const signers = getSignersFromHD(inputIndex, this.data.inputs, hdKeyPair);
    signers.forEach((signer) => this.signInput(inputIndex, signer, sighashTypes));
    return this;
  }
  signInputHDAsync(inputIndex, hdKeyPair, sighashTypes = [Transaction.SIGHASH_ALL]) {
    return new Promise((resolve, reject) => {
      if (!hdKeyPair || !hdKeyPair.publicKey || !hdKeyPair.fingerprint) {
        return reject(new Error("Need HDSigner to sign input"));
      }
      const signers = getSignersFromHD(inputIndex, this.data.inputs, hdKeyPair);
      const promises = signers.map((signer) => this.signInputAsync(inputIndex, signer, sighashTypes));
      return Promise.all(promises).then(() => {
        resolve();
      }).catch(reject);
    });
  }
  signAllInputs(keyPair, sighashTypes = [Transaction.SIGHASH_ALL]) {
    if (!keyPair || !keyPair.publicKey)
      throw new Error("Need Signer to sign input");
    const results = [];
    for (const i of range(this.data.inputs.length)) {
      try {
        this.signInput(i, keyPair, sighashTypes);
        results.push(true);
      } catch (err) {
        results.push(false);
      }
    }
    if (results.every((v) => v === false)) {
      throw new Error("No inputs were signed");
    }
    return this;
  }
  signAllInputsAsync(keyPair, sighashTypes = [Transaction.SIGHASH_ALL]) {
    return new Promise((resolve, reject) => {
      if (!keyPair || !keyPair.publicKey)
        return reject(new Error("Need Signer to sign input"));
      const results = [];
      const promises = [];
      for (const [i] of this.data.inputs.entries()) {
        promises.push(this.signInputAsync(i, keyPair, sighashTypes).then(() => {
          results.push(true);
        }, () => {
          results.push(false);
        }));
      }
      return Promise.all(promises).then(() => {
        if (results.every((v) => v === false)) {
          return reject(new Error("No inputs were signed"));
        }
        resolve();
      });
    });
  }
  signInput(inputIndex, keyPair, sighashTypes = [Transaction.SIGHASH_ALL]) {
    if (!keyPair || !keyPair.publicKey)
      throw new Error("Need Signer to sign input");
    const { hash, sighashType: sighashType2 } = getHashAndSighashType(this.data.inputs, inputIndex, Buffer.from(keyPair.publicKey), this.__CACHE, sighashTypes);
    const partialSig2 = [
      {
        pubkey: Buffer.from(keyPair.publicKey),
        signature: signature.encode(Buffer.from(keyPair.sign(hash)), sighashType2)
      }
    ];
    this.data.updateInput(inputIndex, { partialSig: partialSig2 });
    return this;
  }
  signInputAsync(inputIndex, keyPair, sighashTypes = [Transaction.SIGHASH_ALL]) {
    return Promise.resolve().then(() => {
      if (!keyPair || !keyPair.publicKey)
        throw new Error("Need Signer to sign input");
      const { hash, sighashType: sighashType2 } = getHashAndSighashType(this.data.inputs, inputIndex, keyPair.publicKey, this.__CACHE, sighashTypes);
      return Promise.resolve(keyPair.sign(hash)).then((signature$1) => {
        const partialSig2 = [
          {
            pubkey: keyPair.publicKey,
            signature: signature.encode(signature$1, sighashType2)
          }
        ];
        this.data.updateInput(inputIndex, { partialSig: partialSig2 });
      });
    });
  }
  toBuffer() {
    checkCache(this.__CACHE);
    return this.data.toBuffer();
  }
  toHex() {
    checkCache(this.__CACHE);
    return this.data.toHex();
  }
  toBase64() {
    checkCache(this.__CACHE);
    return this.data.toBase64();
  }
  updateGlobal(updateData) {
    this.data.updateGlobal(updateData);
    return this;
  }
  updateInput(inputIndex, updateData) {
    if (updateData.witnessScript)
      checkInvalidP2WSH(updateData.witnessScript);
    this.data.updateInput(inputIndex, updateData);
    if (updateData.nonWitnessUtxo) {
      addNonWitnessTxCache(this.__CACHE, this.data.inputs[inputIndex], inputIndex);
    }
    return this;
  }
  updateOutput(outputIndex, updateData) {
    this.data.updateOutput(outputIndex, updateData);
    return this;
  }
  addUnknownKeyValToGlobal(keyVal) {
    this.data.addUnknownKeyValToGlobal(keyVal);
    return this;
  }
  addUnknownKeyValToInput(inputIndex, keyVal) {
    this.data.addUnknownKeyValToInput(inputIndex, keyVal);
    return this;
  }
  addUnknownKeyValToOutput(outputIndex, keyVal) {
    this.data.addUnknownKeyValToOutput(outputIndex, keyVal);
    return this;
  }
  clearFinalizedInput(inputIndex) {
    this.data.clearFinalizedInput(inputIndex);
    return this;
  }
}
const transactionFromBuffer = (buffer) => new PsbtTransaction(buffer);
class PsbtTransaction {
  constructor(buffer = Buffer.from([2, 0, 0, 0, 0, 0, 0, 0, 0, 0])) {
    this.tx = Transaction.fromBuffer(buffer);
    checkTxEmpty(this.tx);
    Object.defineProperty(this, "tx", {
      enumerable: false,
      writable: true
    });
  }
  getInputOutputCounts() {
    return {
      inputCount: this.tx.ins.length,
      outputCount: this.tx.outs.length
    };
  }
  addInput(input) {
    if (input.hash === void 0 || input.index === void 0 || !Buffer.isBuffer(input.hash) && typeof input.hash !== "string" || typeof input.index !== "number") {
      throw new Error("Error adding input.");
    }
    const hash = typeof input.hash === "string" ? reverseBuffer(Buffer.from(input.hash, "hex")) : input.hash;
    this.tx.addInput(hash, input.index, input.sequence);
  }
  addOutput(output) {
    if (output.script === void 0 || output.value === void 0 || !Buffer.isBuffer(output.script) || typeof output.value !== "number") {
      throw new Error("Error adding output.");
    }
    this.tx.addOutput(output.script, output.value);
  }
  toBuffer() {
    return this.tx.toBuffer();
  }
}
function canFinalize(input, script, scriptType) {
  switch (scriptType) {
    case "pubkey":
    case "pubkeyhash":
    case "witnesspubkeyhash":
      return hasSigs(1, input.partialSig);
    case "multisig":
      const p2ms$1 = p2ms({ output: script });
      return hasSigs(p2ms$1.m, input.partialSig, p2ms$1.pubkeys);
    default:
      return false;
  }
}
function checkCache(cache) {
  if (cache.__UNSAFE_SIGN_NONSEGWIT !== false) {
    throw new Error("Not BIP174 compliant, can not export");
  }
}
function hasSigs(neededSigs, partialSig2, pubkeys) {
  if (!partialSig2)
    return false;
  let sigs;
  if (pubkeys) {
    sigs = pubkeys.map((pkey) => {
      const pubkey = compressPubkey(pkey);
      return partialSig2.find((pSig) => pSig.pubkey.equals(pubkey));
    }).filter((v) => !!v);
  } else {
    sigs = partialSig2;
  }
  if (sigs.length > neededSigs)
    throw new Error("Too many signatures");
  return sigs.length === neededSigs;
}
function isFinalized(input) {
  return !!input.finalScriptSig || !!input.finalScriptWitness;
}
function isPaymentFactory(payment) {
  return (script) => {
    try {
      payment({ output: script });
      return true;
    } catch (err) {
      return false;
    }
  };
}
const isP2MS = isPaymentFactory(p2ms);
const isP2PK = isPaymentFactory(p2pk);
const isP2PKH = isPaymentFactory(p2pkh);
const isP2WPKH = isPaymentFactory(p2wpkh);
const isP2WSHScript = isPaymentFactory(p2wsh);
const isP2SHScript = isPaymentFactory(p2sh);
function bip32DerivationIsMine(root) {
  return (d) => {
    if (!d.masterFingerprint.equals(root.fingerprint))
      return false;
    if (!root.derivePath(d.path).publicKey.equals(d.pubkey))
      return false;
    return true;
  };
}
function check32Bit(num) {
  if (typeof num !== "number" || num !== Math.floor(num) || num > 4294967295 || num < 0) {
    throw new Error("Invalid 32 bit integer");
  }
}
function checkFees(psbt2, cache, opts) {
  const feeRate = cache.__FEE_RATE || psbt2.getFeeRate();
  const vsize = cache.__EXTRACTED_TX.virtualSize();
  const satoshis = feeRate * vsize;
  if (feeRate >= opts.maximumFeeRate) {
    throw new Error(`Warning: You are paying around ${(satoshis / 1e8).toFixed(8)} in fees, which is ${feeRate} satoshi per byte for a transaction with a VSize of ${vsize} bytes (segwit counted as 0.25 byte per byte). Use setMaximumFeeRate method to raise your threshold, or pass true to the first arg of extractTransaction.`);
  }
}
function checkInputsForPartialSig(inputs, action) {
  inputs.forEach((input) => {
    let throws = false;
    let pSigs = [];
    if ((input.partialSig || []).length === 0) {
      if (!input.finalScriptSig && !input.finalScriptWitness)
        return;
      pSigs = getPsigsFromInputFinalScripts(input);
    } else {
      pSigs = input.partialSig;
    }
    pSigs.forEach((pSig) => {
      const { hashType } = signature.decode(pSig.signature);
      const whitelist = [];
      const isAnyoneCanPay = hashType & Transaction.SIGHASH_ANYONECANPAY;
      if (isAnyoneCanPay)
        whitelist.push("addInput");
      const hashMod = hashType & 31;
      switch (hashMod) {
        case Transaction.SIGHASH_ALL:
          break;
        case Transaction.SIGHASH_SINGLE:
        case Transaction.SIGHASH_NONE:
          whitelist.push("addOutput");
          whitelist.push("setInputSequence");
          break;
      }
      if (whitelist.indexOf(action) === -1) {
        throws = true;
      }
    });
    if (throws) {
      throw new Error("Can not modify transaction, signatures exist.");
    }
  });
}
function checkPartialSigSighashes(input) {
  if (!input.sighashType || !input.partialSig)
    return;
  const { partialSig: partialSig2, sighashType: sighashType2 } = input;
  partialSig2.forEach((pSig) => {
    const { hashType } = signature.decode(pSig.signature);
    if (sighashType2 !== hashType) {
      throw new Error("Signature sighash does not match input sighash type");
    }
  });
}
function checkScriptForPubkey(pubkey, script, action) {
  if (!pubkeyInScript(pubkey, script)) {
    throw new Error(`Can not ${action} for this input with the key ${pubkey.toString("hex")}`);
  }
}
function checkTxEmpty(tx) {
  const isEmpty = tx.ins.every((input) => input.script && input.script.length === 0 && input.witness && input.witness.length === 0);
  if (!isEmpty) {
    throw new Error("Format Error: Transaction ScriptSigs are not empty");
  }
}
function checkTxForDupeIns(tx, cache) {
  tx.ins.forEach((input) => {
    checkTxInputCache(cache, input);
  });
}
function checkTxInputCache(cache, input) {
  const key = reverseBuffer(Buffer.from(input.hash)).toString("hex") + ":" + input.index;
  if (cache.__TX_IN_CACHE[key])
    throw new Error("Duplicate input detected.");
  cache.__TX_IN_CACHE[key] = 1;
}
function scriptCheckerFactory(payment, paymentScriptName) {
  return (inputIndex, scriptPubKey, redeemScript2, ioType) => {
    const redeemScriptOutput = payment({
      redeem: { output: redeemScript2 }
    }).output;
    if (!scriptPubKey.equals(redeemScriptOutput)) {
      throw new Error(`${paymentScriptName} for ${ioType} #${inputIndex} doesn't match the scriptPubKey in the prevout`);
    }
  };
}
const checkRedeemScript = scriptCheckerFactory(p2sh, "Redeem script");
const checkWitnessScript = scriptCheckerFactory(p2wsh, "Witness script");
function getTxCacheValue(key, name, inputs, c) {
  if (!inputs.every(isFinalized))
    throw new Error(`PSBT must be finalized to calculate ${name}`);
  if (key === "__FEE_RATE" && c.__FEE_RATE)
    return c.__FEE_RATE;
  if (key === "__FEE" && c.__FEE)
    return c.__FEE;
  let tx;
  let mustFinalize = true;
  if (c.__EXTRACTED_TX) {
    tx = c.__EXTRACTED_TX;
    mustFinalize = false;
  } else {
    tx = c.__TX.clone();
  }
  inputFinalizeGetAmts(inputs, tx, c, mustFinalize);
  if (key === "__FEE_RATE")
    return c.__FEE_RATE;
  else if (key === "__FEE")
    return c.__FEE;
}
function getFinalScripts(inputIndex, input, script, isSegwit, isP2SH, isP2WSH) {
  const scriptType = classifyScript(script);
  if (!canFinalize(input, script, scriptType))
    throw new Error(`Can not finalize input #${inputIndex}`);
  return prepareFinalScripts(script, scriptType, input.partialSig, isSegwit, isP2SH, isP2WSH);
}
function prepareFinalScripts(script, scriptType, partialSig2, isSegwit, isP2SH, isP2WSH) {
  let finalScriptSig2;
  let finalScriptWitness2;
  const payment = getPayment(script, scriptType, partialSig2);
  const p2wsh$1 = !isP2WSH ? null : p2wsh({ redeem: payment });
  const p2sh$1 = !isP2SH ? null : p2sh({ redeem: p2wsh$1 || payment });
  if (isSegwit) {
    if (p2wsh$1) {
      finalScriptWitness2 = witnessStackToScriptWitness(p2wsh$1.witness);
    } else {
      finalScriptWitness2 = witnessStackToScriptWitness(payment.witness);
    }
    if (p2sh$1) {
      finalScriptSig2 = p2sh$1.input;
    }
  } else {
    if (p2sh$1) {
      finalScriptSig2 = p2sh$1.input;
    } else {
      finalScriptSig2 = payment.input;
    }
  }
  return {
    finalScriptSig: finalScriptSig2,
    finalScriptWitness: finalScriptWitness2
  };
}
function getHashAndSighashType(inputs, inputIndex, pubkey, cache, sighashTypes) {
  const input = utilsExports.checkForInput(inputs, inputIndex);
  const { hash, sighashType: sighashType2, script } = getHashForSig(inputIndex, input, cache, false, sighashTypes);
  checkScriptForPubkey(pubkey, script, "sign");
  return {
    hash,
    sighashType: sighashType2
  };
}
function getHashForSig(inputIndex, input, cache, forValidate, sighashTypes) {
  const unsignedTx2 = cache.__TX;
  const sighashType2 = input.sighashType || Transaction.SIGHASH_ALL;
  if (sighashTypes && sighashTypes.indexOf(sighashType2) < 0) {
    const str = sighashTypeToString(sighashType2);
    throw new Error(`Sighash type is not allowed. Retry the sign method passing the sighashTypes array of whitelisted types. Sighash type: ${str}`);
  }
  let hash;
  let prevout;
  if (input.nonWitnessUtxo) {
    const nonWitnessUtxoTx = nonWitnessUtxoTxFromCache(cache, input, inputIndex);
    const prevoutHash = unsignedTx2.ins[inputIndex].hash;
    const utxoHash = nonWitnessUtxoTx.getHash();
    if (!prevoutHash.equals(utxoHash)) {
      throw new Error(`Non-witness UTXO hash for input #${inputIndex} doesn't match the hash specified in the prevout`);
    }
    const prevoutIndex = unsignedTx2.ins[inputIndex].index;
    prevout = nonWitnessUtxoTx.outs[prevoutIndex];
  } else if (input.witnessUtxo) {
    prevout = input.witnessUtxo;
  } else {
    throw new Error("Need a Utxo input item for signing");
  }
  const { meaningfulScript, type } = getMeaningfulScript(prevout.script, inputIndex, "input", input.redeemScript, input.witnessScript);
  if (["p2sh-p2wsh", "p2wsh"].indexOf(type) >= 0) {
    hash = unsignedTx2.hashForWitnessV0(inputIndex, meaningfulScript, prevout.value, sighashType2);
  } else if (isP2WPKH(meaningfulScript)) {
    const signingScript = p2pkh({ hash: meaningfulScript.slice(2) }).output;
    hash = unsignedTx2.hashForWitnessV0(inputIndex, signingScript, prevout.value, sighashType2);
  } else {
    if (input.nonWitnessUtxo === void 0 && cache.__UNSAFE_SIGN_NONSEGWIT === false)
      throw new Error(`Input #${inputIndex} has witnessUtxo but non-segwit script: ${meaningfulScript.toString("hex")}`);
    if (!forValidate && cache.__UNSAFE_SIGN_NONSEGWIT !== false)
      console.warn("Warning: Signing non-segwit inputs without the full parent transaction means there is a chance that a miner could feed you incorrect information to trick you into paying large fees. This behavior is the same as Psbt's predecesor (TransactionBuilder - now removed) when signing non-segwit scripts. You are not able to export this Psbt with toBuffer|toBase64|toHex since it is not BIP174 compliant.\n*********************\nPROCEED WITH CAUTION!\n*********************");
    hash = unsignedTx2.hashForSignature(inputIndex, meaningfulScript, sighashType2);
  }
  return {
    script: meaningfulScript,
    sighashType: sighashType2,
    hash
  };
}
function getPayment(script, scriptType, partialSig2) {
  let payment;
  switch (scriptType) {
    case "multisig":
      const sigs = getSortedSigs(script, partialSig2);
      payment = p2ms({
        output: script,
        signatures: sigs
      });
      break;
    case "pubkey":
      payment = p2pk({
        output: script,
        signature: partialSig2[0].signature
      });
      break;
    case "pubkeyhash":
      payment = p2pkh({
        output: script,
        pubkey: partialSig2[0].pubkey,
        signature: partialSig2[0].signature
      });
      break;
    case "witnesspubkeyhash":
      payment = p2wpkh({
        output: script,
        pubkey: partialSig2[0].pubkey,
        signature: partialSig2[0].signature
      });
      break;
  }
  return payment;
}
function getPsigsFromInputFinalScripts(input) {
  const scriptItems = !input.finalScriptSig ? [] : decompile(input.finalScriptSig) || [];
  const witnessItems = !input.finalScriptWitness ? [] : decompile(input.finalScriptWitness) || [];
  return scriptItems.concat(witnessItems).filter((item) => {
    return Buffer.isBuffer(item) && isCanonicalScriptSignature(item);
  }).map((sig) => ({ signature: sig }));
}
function getScriptFromInput(inputIndex, input, cache) {
  const unsignedTx2 = cache.__TX;
  const res = {
    script: null,
    isSegwit: false,
    isP2SH: false,
    isP2WSH: false
  };
  res.isP2SH = !!input.redeemScript;
  res.isP2WSH = !!input.witnessScript;
  if (input.witnessScript) {
    res.script = input.witnessScript;
  } else if (input.redeemScript) {
    res.script = input.redeemScript;
  } else {
    if (input.nonWitnessUtxo) {
      const nonWitnessUtxoTx = nonWitnessUtxoTxFromCache(cache, input, inputIndex);
      const prevoutIndex = unsignedTx2.ins[inputIndex].index;
      res.script = nonWitnessUtxoTx.outs[prevoutIndex].script;
    } else if (input.witnessUtxo) {
      res.script = input.witnessUtxo.script;
    }
  }
  if (input.witnessScript || isP2WPKH(res.script)) {
    res.isSegwit = true;
  }
  return res;
}
function getSignersFromHD(inputIndex, inputs, hdKeyPair) {
  const input = utilsExports.checkForInput(inputs, inputIndex);
  if (!input.bip32Derivation || input.bip32Derivation.length === 0) {
    throw new Error("Need bip32Derivation to sign with HD");
  }
  const myDerivations = input.bip32Derivation.map((bipDv) => {
    if (bipDv.masterFingerprint.equals(hdKeyPair.fingerprint)) {
      return bipDv;
    } else {
      return;
    }
  }).filter((v) => !!v);
  if (myDerivations.length === 0) {
    throw new Error("Need one bip32Derivation masterFingerprint to match the HDSigner fingerprint");
  }
  const signers = myDerivations.map((bipDv) => {
    const node = hdKeyPair.derivePath(bipDv.path);
    if (!bipDv.pubkey.equals(node.publicKey)) {
      throw new Error("pubkey did not match bip32Derivation");
    }
    return node;
  });
  return signers;
}
function getSortedSigs(script, partialSig2) {
  const p2ms$1 = p2ms({ output: script });
  return p2ms$1.pubkeys.map((pk) => {
    return (partialSig2.filter((ps) => {
      return ps.pubkey.equals(pk);
    })[0] || {}).signature;
  }).filter((v) => !!v);
}
function scriptWitnessToWitnessStack(buffer) {
  let offset = 0;
  function readSlice(n) {
    offset += n;
    return buffer.slice(offset - n, offset);
  }
  function readVarInt() {
    const vi = converter_varint.decode(buffer, offset);
    offset += converter_varint.decode.bytes;
    return vi;
  }
  function readVarSlice() {
    return readSlice(readVarInt());
  }
  function readVector() {
    const count = readVarInt();
    const vector = [];
    for (let i = 0; i < count; i++)
      vector.push(readVarSlice());
    return vector;
  }
  return readVector();
}
function sighashTypeToString(sighashType2) {
  let text = sighashType2 & Transaction.SIGHASH_ANYONECANPAY ? "SIGHASH_ANYONECANPAY | " : "";
  const sigMod = sighashType2 & 31;
  switch (sigMod) {
    case Transaction.SIGHASH_ALL:
      text += "SIGHASH_ALL";
      break;
    case Transaction.SIGHASH_SINGLE:
      text += "SIGHASH_SINGLE";
      break;
    case Transaction.SIGHASH_NONE:
      text += "SIGHASH_NONE";
      break;
  }
  return text;
}
function witnessStackToScriptWitness(witness) {
  let buffer = Buffer.allocUnsafe(0);
  function writeSlice(slice) {
    buffer = Buffer.concat([buffer, Buffer.from(slice)]);
  }
  function writeVarInt(i) {
    const currentLen = buffer.length;
    const varintLen = converter_varint.encodingLength(i);
    buffer = Buffer.concat([buffer, Buffer.allocUnsafe(varintLen)]);
    converter_varint.encode(i, buffer, currentLen);
  }
  function writeVarSlice(slice) {
    writeVarInt(slice.length);
    writeSlice(slice);
  }
  function writeVector(vector) {
    writeVarInt(vector.length);
    vector.forEach(writeVarSlice);
  }
  writeVector(witness);
  return buffer;
}
function addNonWitnessTxCache(cache, input, inputIndex) {
  cache.__NON_WITNESS_UTXO_BUF_CACHE[inputIndex] = input.nonWitnessUtxo;
  const tx = Transaction.fromBuffer(input.nonWitnessUtxo);
  cache.__NON_WITNESS_UTXO_TX_CACHE[inputIndex] = tx;
  const self = cache;
  const selfIndex = inputIndex;
  delete input.nonWitnessUtxo;
  Object.defineProperty(input, "nonWitnessUtxo", {
    enumerable: true,
    get() {
      const buf = self.__NON_WITNESS_UTXO_BUF_CACHE[selfIndex];
      const txCache = self.__NON_WITNESS_UTXO_TX_CACHE[selfIndex];
      if (buf !== void 0) {
        return buf;
      } else {
        const newBuf = txCache.toBuffer();
        self.__NON_WITNESS_UTXO_BUF_CACHE[selfIndex] = newBuf;
        return newBuf;
      }
    },
    set(data) {
      self.__NON_WITNESS_UTXO_BUF_CACHE[selfIndex] = data;
    }
  });
}
function inputFinalizeGetAmts(inputs, tx, cache, mustFinalize) {
  let inputAmount = 0;
  inputs.forEach((input, idx) => {
    if (mustFinalize && input.finalScriptSig)
      tx.ins[idx].script = input.finalScriptSig;
    if (mustFinalize && input.finalScriptWitness) {
      tx.ins[idx].witness = scriptWitnessToWitnessStack(input.finalScriptWitness);
    }
    if (input.witnessUtxo) {
      inputAmount += input.witnessUtxo.value;
    } else if (input.nonWitnessUtxo) {
      const nwTx = nonWitnessUtxoTxFromCache(cache, input, idx);
      const vout = tx.ins[idx].index;
      const out = nwTx.outs[vout];
      inputAmount += out.value;
    }
  });
  const outputAmount = tx.outs.reduce((total, o) => total + o.value, 0);
  const fee = inputAmount - outputAmount;
  if (fee < 0) {
    throw new Error("Outputs are spending more than Inputs");
  }
  const bytes = tx.virtualSize();
  cache.__FEE = fee;
  cache.__EXTRACTED_TX = tx;
  cache.__FEE_RATE = Math.floor(fee / bytes);
}
function nonWitnessUtxoTxFromCache(cache, input, inputIndex) {
  const c = cache.__NON_WITNESS_UTXO_TX_CACHE;
  if (!c[inputIndex]) {
    addNonWitnessTxCache(cache, input, inputIndex);
  }
  return c[inputIndex];
}
function getScriptFromUtxo(inputIndex, input, cache) {
  if (input.witnessUtxo !== void 0) {
    return input.witnessUtxo.script;
  } else if (input.nonWitnessUtxo !== void 0) {
    const nonWitnessUtxoTx = nonWitnessUtxoTxFromCache(cache, input, inputIndex);
    return nonWitnessUtxoTx.outs[cache.__TX.ins[inputIndex].index].script;
  } else {
    throw new Error("Can't find pubkey in input without Utxo data");
  }
}
function pubkeyInInput(pubkey, input, inputIndex, cache) {
  const script = getScriptFromUtxo(inputIndex, input, cache);
  const { meaningfulScript } = getMeaningfulScript(script, inputIndex, "input", input.redeemScript, input.witnessScript);
  return pubkeyInScript(pubkey, meaningfulScript);
}
function pubkeyInOutput(pubkey, output, outputIndex, cache) {
  const script = cache.__TX.outs[outputIndex].script;
  const { meaningfulScript } = getMeaningfulScript(script, outputIndex, "output", output.redeemScript, output.witnessScript);
  return pubkeyInScript(pubkey, meaningfulScript);
}
function redeemFromFinalScriptSig(finalScript) {
  if (!finalScript)
    return;
  const decomp = decompile(finalScript);
  if (!decomp)
    return;
  const lastItem = decomp[decomp.length - 1];
  if (!Buffer.isBuffer(lastItem) || isPubkeyLike(lastItem) || isSigLike(lastItem))
    return;
  const sDecomp = decompile(lastItem);
  if (!sDecomp)
    return;
  return lastItem;
}
function redeemFromFinalWitnessScript(finalScript) {
  if (!finalScript)
    return;
  const decomp = scriptWitnessToWitnessStack(finalScript);
  const lastItem = decomp[decomp.length - 1];
  if (isPubkeyLike(lastItem))
    return;
  const sDecomp = decompile(lastItem);
  if (!sDecomp)
    return;
  return lastItem;
}
function compressPubkey(pubkey) {
  if (pubkey.length === 65) {
    const parity = pubkey[64] & 1;
    const newKey = pubkey.slice(0, 33);
    newKey[0] = 2 | parity;
    return newKey;
  }
  return pubkey.slice();
}
function isPubkeyLike(buf) {
  return buf.length === 33 && isCanonicalPubKey(buf);
}
function isSigLike(buf) {
  return isCanonicalScriptSignature(buf);
}
function getMeaningfulScript(script, index, ioType, redeemScript2, witnessScript2) {
  const isP2SH = isP2SHScript(script);
  const isP2SHP2WSH = isP2SH && redeemScript2 && isP2WSHScript(redeemScript2);
  const isP2WSH = isP2WSHScript(script);
  if (isP2SH && redeemScript2 === void 0)
    throw new Error("scriptPubkey is P2SH but redeemScript missing");
  if ((isP2WSH || isP2SHP2WSH) && witnessScript2 === void 0)
    throw new Error("scriptPubkey or redeemScript is P2WSH but witnessScript missing");
  let meaningfulScript;
  if (isP2SHP2WSH) {
    meaningfulScript = witnessScript2;
    checkRedeemScript(index, script, redeemScript2, ioType);
    checkWitnessScript(index, redeemScript2, witnessScript2, ioType);
    checkInvalidP2WSH(meaningfulScript);
  } else if (isP2WSH) {
    meaningfulScript = witnessScript2;
    checkWitnessScript(index, script, witnessScript2, ioType);
    checkInvalidP2WSH(meaningfulScript);
  } else if (isP2SH) {
    meaningfulScript = redeemScript2;
    checkRedeemScript(index, script, redeemScript2, ioType);
  } else {
    meaningfulScript = script;
  }
  return {
    meaningfulScript,
    type: isP2SHP2WSH ? "p2sh-p2wsh" : isP2SH ? "p2sh" : isP2WSH ? "p2wsh" : "raw"
  };
}
function checkInvalidP2WSH(script) {
  if (isP2WPKH(script) || isP2SHScript(script)) {
    throw new Error("P2WPKH or P2SH can not be contained within P2WSH");
  }
}
function pubkeyInScript(pubkey, script) {
  const pubkeyHash = hash160(pubkey);
  const decompiled = decompile(script);
  if (decompiled === null)
    throw new Error("Unknown script error");
  return decompiled.some((element) => {
    if (typeof element === "number")
      return false;
    return element.equals(pubkey) || element.equals(pubkeyHash);
  });
}
function classifyScript(script) {
  if (isP2WPKH(script))
    return "witnesspubkeyhash";
  if (isP2PKH(script))
    return "pubkeyhash";
  if (isP2MS(script))
    return "multisig";
  if (isP2PK(script))
    return "pubkey";
  return "nonstandard";
}
function range(n) {
  return [...Array(n).keys()];
}
export {
  Psbt
};
