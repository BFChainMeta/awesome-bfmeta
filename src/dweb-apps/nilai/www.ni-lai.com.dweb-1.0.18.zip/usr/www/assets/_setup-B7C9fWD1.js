import { p as prepareSHA256 } from "./sha256-C2OttJA4.js";
import { p as prepareSHA512 } from "./sha512-D6HcgfaY.js";
import "./WASMInterface-BIOcGvqx.js";
import "./index-DzX_QLg7.js";
import "./index-BgMR6XJ4.js";
import "./index-DAk_nVWR.js";
const prepareBip39 = async () => {
  await prepareSHA256.prepare();
  await prepareSHA512.prepare();
};
export {
  prepareBip39
};
