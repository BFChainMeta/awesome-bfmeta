import { r as reactExports, R as React, ax as BlobImage, dt as m, du as hasI18nZh, am as adminApi } from "./index-DAk_nVWR.js";
const _save_local_assetType_info = {};
let hasRunning = false;
let queryTask = Promise.withResolvers();
const assetsLogoMap = /* @__PURE__ */ new Map([
  ["ccchain-ccc", "ccchain-ccc.webp"],
  ["ccchain-nlt", "ccchain-nlt.webp"]
]);
const updateAssetTypeInfo = async (key) => {
  try {
    if (hasRunning) {
      await queryTask.promise;
      return key && _save_local_assetType_info[key];
    }
    hasRunning = true;
    queryTask = Promise.withResolvers();
    const brandAssetTypeList = await adminApi.brand.getBrandAssetTypeInfoList.query();
    brandAssetTypeList.forEach((item) => {
      const rwaKey = `${item.brandAssetTypeInfo.rwa.chainName.toLowerCase()}-${item.brandAssetTypeInfo.rwa.assetType.toLowerCase()}`;
      const stablecoinKey = `${item.brandAssetTypeInfo.stablecoin.chainName.toLowerCase()}-${item.brandAssetTypeInfo.stablecoin.assetType.toLowerCase()}`;
      _save_local_assetType_info[rwaKey] = {
        logo: item.brandAssetTypeInfo.rwa.logo,
        assetTypeName: item.brandAssetTypeInfo.rwa.assetTypeName
      };
      _save_local_assetType_info[stablecoinKey] = {
        logo: item.brandAssetTypeInfo.stablecoin.logo,
        assetTypeName: item.brandAssetTypeInfo.stablecoin.assetTypeName
      };
    });
    return key && _save_local_assetType_info[key];
  } finally {
    hasRunning = false;
    queryTask.resolve(true);
  }
};
updateAssetTypeInfo();
const AssetTypeIcon = ({
  assetType,
  chainName,
  cssClass,
  logoUrl
}) => {
  const [assetTypeIcon, setAssetTypeIcon] = reactExports.useState(
    /* @__PURE__ */ React.createElement(
      "img",
      {
        src: logoUrl ? logoUrl : "./images/asset-logo/default.webp",
        className: cssClass,
        alt: ""
      }
    )
  );
  reactExports.useEffect(() => {
    if (logoUrl) {
      return;
    }
    const lowerAssetType = assetType.toLowerCase();
    const lowerChainName = chainName.toLowerCase();
    const filename = assetsLogoMap.get(`${lowerChainName}-${lowerAssetType}`);
    if (filename) {
      setAssetTypeIcon(
        /* @__PURE__ */ React.createElement(
          "img",
          {
            src: `./images/asset-logo/${filename}`,
            className: cssClass,
            alt: ""
          }
        )
      );
      return;
    }
    let item = _save_local_assetType_info[`${lowerChainName}-${lowerAssetType}`];
    if (item) {
      setAssetTypeIcon(
        /* @__PURE__ */ React.createElement(BlobImage, { bloburi: item.logo, fill: true, className: cssClass, alt: "" })
      );
    } else {
      updateAssetTypeInfo(`${lowerChainName}-${lowerAssetType}`).then(
        (info) => {
          if (info) {
            setAssetTypeIcon(
              /* @__PURE__ */ React.createElement(
                BlobImage,
                {
                  bloburi: info.logo,
                  fill: true,
                  className: cssClass,
                  alt: ""
                }
              )
            );
          }
        }
      );
    }
  }, []);
  return /* @__PURE__ */ React.createElement("div", { className: "inline-block overflow-hidden rounded-full" }, assetTypeIcon);
};
const AssetTypeName = ({
  assetType,
  chainName,
  cssClass
}) => {
  const [assetTypeName, setAssetTypeName] = reactExports.useState(assetType);
  reactExports.useEffect(() => {
    if (m[assetType]) {
      setAssetTypeName(m[assetType]());
      return;
    }
    if (hasI18nZh() === false) {
      return;
    }
    const lowerAssetType = assetType.toLowerCase();
    const lowerChainName = chainName.toLowerCase();
    let item = _save_local_assetType_info[`${lowerChainName}-${lowerAssetType}`];
    if (item) {
      setAssetTypeName(item.assetTypeName);
    } else {
      updateAssetTypeInfo(`${lowerChainName}-${lowerAssetType}`).then(
        (info) => {
          if (info) {
            setAssetTypeName(info.assetTypeName);
          }
        }
      );
    }
  }, []);
  return /* @__PURE__ */ React.createElement("span", { className: cssClass }, assetTypeName);
};
export {
  AssetTypeName as A,
  AssetTypeIcon as a
};
