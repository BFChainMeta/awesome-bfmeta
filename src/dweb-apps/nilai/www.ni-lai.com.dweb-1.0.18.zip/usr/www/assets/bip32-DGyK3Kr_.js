import { B as Buffer } from "./index-BgMR6XJ4.js";
import { c as createSHA512Sync } from "./sha512-D6HcgfaY.js";
import { c as createHMACSync } from "./hmac-CYoWib7y.js";
import { hash160 } from "./crypto-CIvSaiGD.js";
import { b as bs58check } from "./index-mSLBfEgs.js";
import { t as typeforce } from "./typeforce-BXjzjt-d.js";
import { e as encode } from "./index-DDyEOUjF.js";
import "./index-DAk_nVWR.js";
import "./WASMInterface-BIOcGvqx.js";
import "./index-DzX_QLg7.js";
import "./ripemd160-DVjwZ6Kb.js";
import "./sha1-CAxM_YzN.js";
import "./sha256-C2OttJA4.js";
function hmacSHA512(key, data) {
  return Buffer.from(createHMACSync(createSHA512Sync(), key).update(data).digest());
}
function BIP32Factory(ecc) {
  const UINT256_TYPE = typeforce.BufferN(32);
  const NETWORK_TYPE = typeforce.compile({
    wif: typeforce.UInt8,
    bip32: {
      public: typeforce.UInt32,
      private: typeforce.UInt32
    }
  });
  const BITCOIN = {
    messagePrefix: "Bitcoin Signed Message:\n",
    bech32: "bc",
    bip32: {
      public: 76067358,
      private: 76066276
    },
    pubKeyHash: 0,
    scriptHash: 5,
    wif: 128
  };
  const HIGHEST_BIT = 2147483648;
  const UINT31_MAX = Math.pow(2, 31) - 1;
  function BIP32Path(value) {
    return typeforce.String(value) && value.match(/^(m\/)?(\d+'?\/)*\d+'?$/) !== null;
  }
  function UInt31(value) {
    return typeforce.UInt32(value) && value <= UINT31_MAX;
  }
  function toXOnly(pubKey) {
    return pubKey.length === 32 ? pubKey : pubKey.slice(1, 33);
  }
  class Bip32Signer {
    constructor(__D, __Q) {
      this.__D = __D;
      this.__Q = __Q;
      this.lowR = false;
    }
    get publicKey() {
      if (this.__Q === void 0)
        this.__Q = Buffer.from(ecc.pointFromScalar(this.__D, true));
      return this.__Q;
    }
    get privateKey() {
      return this.__D;
    }
    sign(hash, lowR) {
      if (!this.privateKey)
        throw new Error("Missing private key");
      if (lowR === void 0)
        lowR = this.lowR;
      if (lowR === false) {
        return Buffer.from(ecc.sign(hash, this.privateKey));
      } else {
        let sig = Buffer.from(ecc.sign(hash, this.privateKey));
        const extraData = Buffer.alloc(32, 0);
        let counter = 0;
        while (sig[0] > 127) {
          counter++;
          extraData.writeUIntLE(counter, 0, 6);
          sig = Buffer.from(ecc.sign(hash, this.privateKey, extraData));
        }
        return sig;
      }
    }
    signSchnorr(hash) {
      if (!this.privateKey)
        throw new Error("Missing private key");
      if (!ecc.signSchnorr)
        throw new Error("signSchnorr not supported by ecc library");
      return Buffer.from(ecc.signSchnorr(hash, this.privateKey));
    }
    verify(hash, signature) {
      return ecc.verify(hash, this.publicKey, signature);
    }
    verifySchnorr(hash, signature) {
      if (!ecc.verifySchnorr)
        throw new Error("verifySchnorr not supported by ecc library");
      return ecc.verifySchnorr(hash, this.publicKey.subarray(1, 33), signature);
    }
  }
  class BIP32 extends Bip32Signer {
    constructor(__D, __Q, chainCode, network, __DEPTH = 0, __INDEX = 0, __PARENT_FINGERPRINT = 0) {
      super(__D, __Q);
      this.chainCode = chainCode;
      this.network = network;
      this.__DEPTH = __DEPTH;
      this.__INDEX = __INDEX;
      this.__PARENT_FINGERPRINT = __PARENT_FINGERPRINT;
      typeforce(NETWORK_TYPE, network);
    }
    get depth() {
      return this.__DEPTH;
    }
    get index() {
      return this.__INDEX;
    }
    get parentFingerprint() {
      return this.__PARENT_FINGERPRINT;
    }
    get identifier() {
      return hash160(this.publicKey);
    }
    get fingerprint() {
      return this.identifier.slice(0, 4);
    }
    get compressed() {
      return true;
    }
    // Private === not neutered
    // Public === neutered
    isNeutered() {
      return this.__D === void 0;
    }
    neutered() {
      return fromPublicKeyLocal(this.publicKey, this.chainCode, this.network, this.depth, this.index, this.parentFingerprint);
    }
    toBase58() {
      const network = this.network;
      const version = !this.isNeutered() ? network.bip32.private : network.bip32.public;
      const buffer = Buffer.allocUnsafe(78);
      buffer.writeUInt32BE(version, 0);
      buffer.writeUInt8(this.depth, 4);
      buffer.writeUInt32BE(this.parentFingerprint, 5);
      buffer.writeUInt32BE(this.index, 9);
      this.chainCode.copy(buffer, 13);
      if (!this.isNeutered()) {
        buffer.writeUInt8(0, 45);
        this.privateKey.copy(buffer, 46);
      } else {
        this.publicKey.copy(buffer, 45);
      }
      return bs58check.encode(buffer);
    }
    toWIF() {
      if (!this.privateKey)
        throw new TypeError("Missing private key");
      return encode(this.network.wif, this.privateKey, true);
    }
    // https://github.com/bitcoin/bips/blob/master/bip-0032.mediawiki#child-key-derivation-ckd-functions
    derive(index) {
      typeforce(typeforce.UInt32, index);
      const isHardened = index >= HIGHEST_BIT;
      const data = Buffer.allocUnsafe(37);
      if (isHardened) {
        if (this.isNeutered())
          throw new TypeError("Missing private key for hardened child key");
        data[0] = 0;
        this.privateKey.copy(data, 1);
        data.writeUInt32BE(index, 33);
      } else {
        this.publicKey.copy(data, 0);
        data.writeUInt32BE(index, 33);
      }
      const I = hmacSHA512(this.chainCode, data);
      const IL = I.slice(0, 32);
      const IR = I.slice(32);
      if (!ecc.isPrivate(IL))
        return this.derive(index + 1);
      let hd;
      if (!this.isNeutered()) {
        const ki = Buffer.from(ecc.privateAdd(this.privateKey, IL));
        if (ki == null)
          return this.derive(index + 1);
        hd = fromPrivateKeyLocal(ki, IR, this.network, this.depth + 1, index, this.fingerprint.readUInt32BE(0));
      } else {
        const Ki = Buffer.from(ecc.pointAddScalar(this.publicKey, IL, true));
        if (Ki === null)
          return this.derive(index + 1);
        hd = fromPublicKeyLocal(Ki, IR, this.network, this.depth + 1, index, this.fingerprint.readUInt32BE(0));
      }
      return hd;
    }
    deriveHardened(index) {
      typeforce(UInt31, index);
      return this.derive(index + HIGHEST_BIT);
    }
    derivePath(path) {
      typeforce(BIP32Path, path);
      let splitPath = path.split("/");
      if (splitPath[0] === "m") {
        if (this.parentFingerprint)
          throw new TypeError("Expected master, got child");
        splitPath = splitPath.slice(1);
      }
      return splitPath.reduce((prevHd, indexStr) => {
        let index;
        if (indexStr.slice(-1) === `'`) {
          index = parseInt(indexStr.slice(0, -1), 10);
          return prevHd.deriveHardened(index);
        } else {
          index = parseInt(indexStr, 10);
          return prevHd.derive(index);
        }
      }, this);
    }
    tweak(t) {
      if (this.privateKey)
        return this.tweakFromPrivateKey(t);
      return this.tweakFromPublicKey(t);
    }
    tweakFromPublicKey(t) {
      const xOnlyPubKey = toXOnly(this.publicKey);
      const tweakedPublicKey = ecc.xOnlyPointAddTweak(xOnlyPubKey, t);
      if (!tweakedPublicKey || tweakedPublicKey.xOnlyPubkey === null)
        throw new Error("Cannot tweak public key!");
      const parityByte = Buffer.from([
        tweakedPublicKey.parity === 0 ? 2 : 3
      ]);
      const tweakedPublicKeyCompresed = Buffer.concat([
        parityByte,
        tweakedPublicKey.xOnlyPubkey
      ]);
      return new Bip32Signer(void 0, tweakedPublicKeyCompresed);
    }
    tweakFromPrivateKey(t) {
      const hasOddY = this.publicKey[0] === 3 || this.publicKey[0] === 4 && (this.publicKey[64] & 1) === 1;
      const privateKey = hasOddY ? ecc.privateNegate(this.privateKey) : this.privateKey;
      const tweakedPrivateKey = ecc.privateAdd(privateKey, t);
      if (!tweakedPrivateKey)
        throw new Error("Invalid tweaked private key!");
      return new Bip32Signer(Buffer.from(tweakedPrivateKey), void 0);
    }
  }
  function fromBase58(inString, network) {
    const buffer = bs58check.decode(inString);
    if (buffer.length !== 78)
      throw new TypeError("Invalid buffer length");
    network = network || BITCOIN;
    const version = buffer.readUInt32BE(0);
    if (version !== network.bip32.private && version !== network.bip32.public)
      throw new TypeError("Invalid network version");
    const depth = buffer[4];
    const parentFingerprint = buffer.readUInt32BE(5);
    if (depth === 0) {
      if (parentFingerprint !== 0)
        throw new TypeError("Invalid parent fingerprint");
    }
    const index = buffer.readUInt32BE(9);
    if (depth === 0 && index !== 0)
      throw new TypeError("Invalid index");
    const chainCode = buffer.slice(13, 45);
    let hd;
    if (version === network.bip32.private) {
      if (buffer.readUInt8(45) !== 0)
        throw new TypeError("Invalid private key");
      const k = buffer.slice(46, 78);
      hd = fromPrivateKeyLocal(k, chainCode, network, depth, index, parentFingerprint);
    } else {
      const X = buffer.slice(45, 78);
      hd = fromPublicKeyLocal(X, chainCode, network, depth, index, parentFingerprint);
    }
    return hd;
  }
  function fromPrivateKey(privateKey, chainCode, network) {
    return fromPrivateKeyLocal(privateKey, chainCode, network);
  }
  function fromPrivateKeyLocal(privateKey, chainCode, network, depth, index, parentFingerprint) {
    typeforce({
      privateKey: UINT256_TYPE,
      chainCode: UINT256_TYPE
    }, { privateKey, chainCode });
    network = network || BITCOIN;
    if (!ecc.isPrivate(privateKey))
      throw new TypeError("Private key not in range [1, n)");
    return new BIP32(privateKey, void 0, chainCode, network, depth, index, parentFingerprint);
  }
  function fromPublicKey(publicKey, chainCode, network) {
    return fromPublicKeyLocal(publicKey, chainCode, network);
  }
  function fromPublicKeyLocal(publicKey, chainCode, network, depth, index, parentFingerprint) {
    typeforce({
      publicKey: typeforce.BufferN(33),
      chainCode: UINT256_TYPE
    }, { publicKey, chainCode });
    network = network || BITCOIN;
    if (!ecc.isPoint(publicKey))
      throw new TypeError("Point is not on the curve");
    return new BIP32(void 0, publicKey, chainCode, network, depth, index, parentFingerprint);
  }
  function fromSeed(seed, network) {
    typeforce(typeforce.Buffer, seed);
    if (seed.length < 16)
      throw new TypeError("Seed should be at least 128 bits");
    if (seed.length > 64)
      throw new TypeError("Seed should be at most 512 bits");
    network = network || BITCOIN;
    const I = hmacSHA512(Buffer.from("Bitcoin seed", "utf8"), seed);
    const IL = I.slice(0, 32);
    const IR = I.slice(32);
    return fromPrivateKey(IL, IR, network);
  }
  return {
    fromSeed,
    fromBase58,
    fromPublicKey,
    fromPrivateKey,
    toXOnly
  };
}
export {
  BIP32Factory
};
