import { p as prepareBs58check } from "./_setup-Bz2G42jh.js";
import "./sha256-C2OttJA4.js";
import "./WASMInterface-BIOcGvqx.js";
import "./index-DzX_QLg7.js";
import "./index-BgMR6XJ4.js";
import "./index-DAk_nVWR.js";
const prepareWif = async () => {
  await prepareBs58check();
};
const prepareEcpair = async () => {
  await prepareWif();
};
export {
  prepareEcpair
};
