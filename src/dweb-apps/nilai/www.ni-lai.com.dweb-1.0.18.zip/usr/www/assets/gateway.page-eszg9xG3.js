import { d as definePage, r as reactExports, R as React, P as Page, O as Navbar, an as useEasyState, ao as Card, ap as CardHeader, aq as CardContent, ar as Input, as as CardFooter, a as Button, at as userApi, au as TextEditor, av as AnimatePresence, aw as motion } from "./index-DAk_nVWR.js";
var q = ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z", "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z", "#", "$", "%", "*", "+", ",", "-", ".", ":", ";", "=", "?", "@", "[", "]", "^", "_", "{", "|", "}", "~"], x = (t) => {
  let e = 0;
  for (let r = 0; r < t.length; r++) {
    let n = t[r], l = q.indexOf(n);
    e = e * 83 + l;
  }
  return e;
};
var f = (t) => {
  let e = t / 255;
  return e <= 0.04045 ? e / 12.92 : Math.pow((e + 0.055) / 1.055, 2.4);
}, h = (t) => {
  let e = Math.max(0, Math.min(1, t));
  return e <= 31308e-7 ? Math.trunc(e * 12.92 * 255 + 0.5) : Math.trunc((1.055 * Math.pow(e, 0.4166666666666667) - 0.055) * 255 + 0.5);
}, F = (t) => t < 0 ? -1 : 1, M = (t, e) => F(t) * Math.pow(Math.abs(t), e);
var d = class extends Error {
  constructor(e) {
    super(e), this.name = "ValidationError", this.message = e;
  }
};
var C = (t) => {
  if (!t || t.length < 6) throw new d("The blurhash string must be at least 6 characters");
  let e = x(t[0]), r = Math.floor(e / 9) + 1, n = e % 9 + 1;
  if (t.length !== 4 + 2 * n * r) throw new d(`blurhash length mismatch: length is ${t.length} but it should be ${4 + 2 * n * r}`);
}, z = (t) => {
  let e = t >> 16, r = t >> 8 & 255, n = t & 255;
  return [f(e), f(r), f(n)];
}, L = (t, e) => {
  let r = Math.floor(t / 361), n = Math.floor(t / 19) % 19, l = t % 19;
  return [M((r - 9) / 9, 2) * e, M((n - 9) / 9, 2) * e, M((l - 9) / 9, 2) * e];
}, U = (t, e, r, n) => {
  C(t), n = n | 1;
  let l = x(t[0]), m = Math.floor(l / 9) + 1, b = l % 9 + 1, i = (x(t[1]) + 1) / 166, u = new Array(b * m);
  for (let o = 0; o < u.length; o++) if (o === 0) {
    let a = x(t.substring(2, 6));
    u[o] = z(a);
  } else {
    let a = x(t.substring(4 + o * 2, 6 + o * 2));
    u[o] = L(a, i * n);
  }
  let c = e * 4, s = new Uint8ClampedArray(c * r);
  for (let o = 0; o < r; o++) for (let a = 0; a < e; a++) {
    let y = 0, B = 0, R = 0;
    for (let w = 0; w < m; w++) for (let P = 0; P < b; P++) {
      let G = Math.cos(Math.PI * a * P / e) * Math.cos(Math.PI * o * w / r), T = u[P + w * b];
      y += T[0] * G, B += T[1] * G, R += T[2] * G;
    }
    let V = h(y), I = h(B), E = h(R);
    s[4 * a + 0 + o * c] = V, s[4 * a + 1 + o * c] = I, s[4 * a + 2 + o * c] = E, s[4 * a + 3 + o * c] = 255;
  }
  return s;
}, j = U;
const gateway_page = definePage((args) => {
  const UploadCard = reactExports.useMemo(UploadCardFactory, []);
  const LoginCard = reactExports.useMemo(LoginCardFactory, []);
  const LoginerUploadCard = reactExports.useMemo(LoginerUploadCardFactory, []);
  const LoginerDbCard = reactExports.useMemo(LoginerDbCardFactory, []);
  const P2PMessage = reactExports.useMemo(P2PMessageFactory, []);
  return /* @__PURE__ */ React.createElement(Page, { name: "gateway" }, /* @__PURE__ */ React.createElement(Navbar, { title: "Gateway", backLink: args.backLink }), /* @__PURE__ */ React.createElement(UploadCard, { ...args }), /* @__PURE__ */ React.createElement(LoginCard, { ...args }), /* @__PURE__ */ React.createElement(LoginerUploadCard, { ...args }), /* @__PURE__ */ React.createElement(LoginerDbCard, { ...args }), /* @__PURE__ */ React.createElement(P2PMessage, { ...args }));
});
const UploadCardFactory = () => {
  return definePage((args) => {
    const file = useEasyState(null);
    const uploadResult = useEasyState();
    return /* @__PURE__ */ React.createElement(Card, null, /* @__PURE__ */ React.createElement(CardHeader, null, "文件上传测试"), /* @__PURE__ */ React.createElement(CardContent, null, /* @__PURE__ */ React.createElement(
      Input,
      {
        type: "file",
        onChange: (e) => {
          file.value = e.target.files.item(0);
          console.log(file.value);
        }
      }
    ), /* @__PURE__ */ React.createElement("p", null, uploadResult.value)), /* @__PURE__ */ React.createElement(CardFooter, null, /* @__PURE__ */ React.createElement(
      Button,
      {
        onClick: async () => {
          try {
            const form = new FormData();
            form.append("demoFile", file.value);
            const res = await userApi.demo.upload.mutate(form);
            uploadResult.value = "上传成功: " + JSON.stringify(res);
          } catch (error) {
            uploadResult.value = "上传失败: " + error;
          }
        },
        disabled: file.value == null
      },
      "upload"
    )));
  });
};
const LoginCardFactory = () => {
  return definePage((args) => {
    const dwebLoginSecret = useEasyState("");
    const dwebLoginResult = useEasyState("");
    const dwebCurrentLoginer = useEasyState("");
    return /* @__PURE__ */ React.createElement(React.Fragment, null, /* @__PURE__ */ React.createElement(Card, null, /* @__PURE__ */ React.createElement(CardHeader, null, "密钥注册网关"), /* @__PURE__ */ React.createElement(CardContent, null, /* @__PURE__ */ React.createElement(
      Input,
      {
        type: "text",
        onInput: (e) => {
          dwebLoginSecret.value = e.target.value;
        }
      }
    ), /* @__PURE__ */ React.createElement("p", null, dwebLoginResult.value)), /* @__PURE__ */ React.createElement(CardFooter, null, /* @__PURE__ */ React.createElement(
      Button,
      {
        onClick: async () => {
          try {
            dwebLoginResult.value = "注册中...";
            const result = await userApi.demo.login.mutate(
              dwebLoginSecret.value
            );
            dwebLoginResult.value = "注册成功：" + JSON.stringify(result);
          } catch (error) {
            dwebLoginResult.value = "注册失败: " + error;
          }
        },
        disabled: dwebLoginSecret.value.length == 0
      },
      "注册"
    ))), /* @__PURE__ */ React.createElement(Card, null, /* @__PURE__ */ React.createElement(CardHeader, null, "获取当前注册用户"), /* @__PURE__ */ React.createElement(CardContent, null, /* @__PURE__ */ React.createElement(
      "p",
      {
        style: {
          wordBreak: "break-all"
        }
      },
      dwebCurrentLoginer.value
    )), /* @__PURE__ */ React.createElement(CardFooter, null, /* @__PURE__ */ React.createElement(
      Button,
      {
        onClick: async () => {
          try {
            dwebCurrentLoginer.value = "查询中...";
            const result = await userApi.demo.currentLoginer.query();
            dwebCurrentLoginer.value = "查询成功：" + JSON.stringify(result);
          } catch (error) {
            dwebCurrentLoginer.value = "查询失败: " + error;
          }
        }
      },
      "查询"
    ))));
  });
};
const LoginerUploadCardFactory = () => {
  const canvas = document.createElement("canvas");
  const ctx = canvas.getContext("2d");
  const PreViewImage = ({ info }) => {
    const blur_url = reactExports.useMemo(() => {
      const pixels = j(info.blurhash, info.width, info.height);
      canvas.width = info.width;
      canvas.height = info.height;
      const imageData = ctx.createImageData(info.width, info.height);
      imageData.data.set(pixels);
      ctx.putImageData(imageData, 0, 0);
      return canvas.toDataURL();
    }, [info.blurhash, info.width, info.height]);
    const blob_url = reactExports.useMemo(() => {
      return new URL(
        `image/${info.blob_id}`,
        "https://blob-api.nilai.dweb.xin/"
      ).href;
    }, [info.blob_id]);
    return /* @__PURE__ */ React.createElement(React.Fragment, null, /* @__PURE__ */ React.createElement("img", { src: blur_url, alt: "blurhash image" }), /* @__PURE__ */ React.createElement("img", { src: blob_url, alt: "blob image" }));
  };
  return definePage((args) => {
    useEasyState(false);
    const file = useEasyState(null);
    const uploadResult = useEasyState("");
    const imageInfo = useEasyState(null);
    return /* @__PURE__ */ React.createElement(Card, null, /* @__PURE__ */ React.createElement(CardHeader, null, "登录者上传文件测试"), /* @__PURE__ */ React.createElement(CardContent, null, /* @__PURE__ */ React.createElement(
      Input,
      {
        type: "file",
        accept: "image/*",
        onChange: (e) => {
          file.value = e.target.files.item(0);
          console.log(file.value);
        }
      }
    ), /* @__PURE__ */ React.createElement("p", null, uploadResult.value), imageInfo.value ? /* @__PURE__ */ React.createElement(PreViewImage, { info: imageInfo.value }) : null), /* @__PURE__ */ React.createElement(CardFooter, null, /* @__PURE__ */ React.createElement(
      Button,
      {
        onClick: async () => {
          try {
            const form = new FormData();
            form.append("demoFile", file.value);
            const blob_uri = await userApi.demo.uploadToBlob.mutate(form);
            uploadResult.value = "上传成功: " + blob_uri;
            const [blob_id, size, blurhash] = blob_uri.split("/");
            const [width, height] = size.split("x");
            imageInfo.value = {
              blob_id,
              blurhash,
              width: +width,
              height: +height
            };
          } catch (error) {
            uploadResult.value = "上传失败: " + error;
          }
        },
        disabled: file.value == null
      },
      "upload"
    )));
  });
};
const LoginerDbCardFactory = () => {
  return definePage((args) => {
    const dwebLoginerDbKey = useEasyState("");
    const dwebLoginerDbValue = useEasyState("");
    const dwebLoginerDbResult = useEasyState("");
    return /* @__PURE__ */ React.createElement(Card, null, /* @__PURE__ */ React.createElement(CardHeader, null, "当前注册用户 的数据读写"), /* @__PURE__ */ React.createElement(CardContent, null, /* @__PURE__ */ React.createElement(
      Input,
      {
        type: "text",
        onInput: (e) => {
          dwebLoginerDbKey.value = e.target.value;
        },
        value: dwebLoginerDbKey.value,
        placeholder: "Key"
      }
    ), /* @__PURE__ */ React.createElement(
      Input,
      {
        type: "text",
        onInput: (e) => {
          dwebLoginerDbValue.value = e.target.value;
        },
        value: dwebLoginerDbValue.value,
        placeholder: "Value"
      }
    ), /* @__PURE__ */ React.createElement("p", null, dwebLoginerDbResult.value)), /* @__PURE__ */ React.createElement(CardFooter, null, /* @__PURE__ */ React.createElement(
      Button,
      {
        onClick: async () => {
          try {
            dwebLoginerDbResult.value = "写入中...";
            const result = await userApi.demo.loginer_db_write.mutate({
              key: dwebLoginerDbKey.value,
              value: dwebLoginerDbValue.value
            });
            dwebLoginerDbResult.value = "写入成功：" + JSON.stringify(result);
          } catch (error) {
            dwebLoginerDbResult.value = "写入失败: " + error;
          }
        }
      },
      "写入"
    ), /* @__PURE__ */ React.createElement(
      Button,
      {
        onClick: async () => {
          try {
            dwebLoginerDbResult.value = "读取中...";
            const result = await userApi.demo.loginer_db_read.query({
              key: dwebLoginerDbKey.value
            });
            dwebLoginerDbResult.value = "读取成功：" + JSON.stringify(result);
          } catch (error) {
            dwebLoginerDbResult.value = "读取失败: " + error;
          }
        }
      },
      "读取"
    )));
  });
};
const P2PMessageFactory = () => {
  return definePage((args) => {
    const remoteAddress = useEasyState("");
    const message = useEasyState("");
    const log = useEasyState("");
    return /* @__PURE__ */ React.createElement(Card, null, /* @__PURE__ */ React.createElement(CardHeader, null, "点对点消息"), /* @__PURE__ */ React.createElement(CardContent, null, /* @__PURE__ */ React.createElement(
      Input,
      {
        type: "text",
        placeholder: "Remote Address",
        onInput: (e) => remoteAddress.value = e.target.value,
        value: remoteAddress.value
      }
    ), /* @__PURE__ */ React.createElement(
      TextEditor,
      {
        placeholder: "Enter text...",
        buttons: [
          ["bold", "italic", "underline", "strikeThrough"],
          ["orderedList", "unorderedList"]
        ],
        onTextEditorChange: (value) => message.value = value,
        value: message.value
      }
    ), /* @__PURE__ */ React.createElement(AnimatePresence, null, log.value ? /* @__PURE__ */ React.createElement(
      motion.div,
      {
        initial: { scale: 0 },
        animate: { scale: 1 },
        style: {
          backgroundColor: "#4caf50",
          borderRadius: "8px",
          padding: "8px"
        }
      },
      log.value
    ) : null)), /* @__PURE__ */ React.createElement(CardFooter, null, /* @__PURE__ */ React.createElement(
      Button,
      {
        onClick: async () => {
          try {
            log.value = "发送中...";
            const res = await userApi.demo.sendMessage.mutate({
              remoteAddress: remoteAddress.value,
              message: message.value
            });
            log.value = "发送完成:" + res;
          } catch (e) {
            log.value = "发送失败:" + e;
          }
        }
      },
      "发送"
    ), /* @__PURE__ */ React.createElement(
      Button,
      {
        onClick: async () => {
          try {
            log.value = "拉去中...";
            const res = await userApi.demo.readMessage.query({
              remoteAddress: remoteAddress.value
            });
            log.value = "拉去完成:" + res;
          } catch (e) {
            log.value = "拉去失败:" + e;
          }
        }
      },
      "拉取"
    )));
  });
};
export {
  gateway_page as default
};
