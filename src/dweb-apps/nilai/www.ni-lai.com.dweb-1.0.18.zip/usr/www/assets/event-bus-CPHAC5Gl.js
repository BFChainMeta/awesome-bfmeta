import { cd as pureEvent } from "./index-DAk_nVWR.js";
const onSelectMineAddress = pureEvent();
const onSelectDiscountPoints = pureEvent();
export {
  onSelectMineAddress as a,
  onSelectDiscountPoints as o
};
