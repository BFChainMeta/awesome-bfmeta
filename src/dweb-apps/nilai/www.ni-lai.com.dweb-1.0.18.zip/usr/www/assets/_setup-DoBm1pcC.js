import { p as prepareBs58check } from "./_setup-Bz2G42jh.js";
import { p as prepareRIPEMD160 } from "./ripemd160-DVjwZ6Kb.js";
import { p as prepareSHA1 } from "./sha1-CAxM_YzN.js";
import { p as prepareSHA256 } from "./sha256-C2OttJA4.js";
import "./WASMInterface-BIOcGvqx.js";
import "./index-DzX_QLg7.js";
import "./index-BgMR6XJ4.js";
import "./index-DAk_nVWR.js";
const prepareBitcoinLib = async () => {
  await prepareBs58check();
  await prepareRIPEMD160.prepare();
  await prepareSHA1.prepare();
  await prepareSHA256.prepare();
};
export {
  prepareBitcoinLib
};
