import { ce as __vitePreload } from "./index-DAk_nVWR.js";
const ALL_LANGUAGE = [
  "english",
  "japanese",
  "chinese_simplified",
  "chinese_traditional",
  "czech",
  "french",
  "italian",
  "korean",
  "portuguese",
  "spanish"
];
const getWordList = async (language) => {
  switch (language) {
    case "chinese_simplified":
      return (await __vitePreload(async () => {
        const { default: __vite_default__ } = await import("./chinese_simplified-B_bgJk-I.js");
        return { default: __vite_default__ };
      }, true ? [] : void 0)).default;
    case "chinese_traditional":
      return (await __vitePreload(async () => {
        const { default: __vite_default__ } = await import("./chinese_traditional-qB6lF_Qi.js");
        return { default: __vite_default__ };
      }, true ? [] : void 0)).default;
    case "czech":
      return (await __vitePreload(async () => {
        const { default: __vite_default__ } = await import("./czech-PHQmBgUL.js");
        return { default: __vite_default__ };
      }, true ? [] : void 0)).default;
    case "english":
      return (await __vitePreload(async () => {
        const { default: __vite_default__ } = await import("./english-CYTRTixi.js");
        return { default: __vite_default__ };
      }, true ? [] : void 0)).default;
    case "french":
      return (await __vitePreload(async () => {
        const { default: __vite_default__ } = await import("./french-Dke5xSkC.js");
        return { default: __vite_default__ };
      }, true ? [] : void 0)).default;
    case "italian":
      return (await __vitePreload(async () => {
        const { default: __vite_default__ } = await import("./italian-C5sU67x9.js");
        return { default: __vite_default__ };
      }, true ? [] : void 0)).default;
    case "japanese":
      return (await __vitePreload(async () => {
        const { default: __vite_default__ } = await import("./japanese-YMfwG9jM.js");
        return { default: __vite_default__ };
      }, true ? [] : void 0)).default;
    case "korean":
      return (await __vitePreload(async () => {
        const { default: __vite_default__ } = await import("./korean-qc2BzwN3.js");
        return { default: __vite_default__ };
      }, true ? [] : void 0)).default;
    case "portuguese":
      return (await __vitePreload(async () => {
        const { default: __vite_default__ } = await import("./portuguese-CWEa3Ctm.js");
        return { default: __vite_default__ };
      }, true ? [] : void 0)).default;
    case "spanish":
      return (await __vitePreload(async () => {
        const { default: __vite_default__ } = await import("./spanish-DfztzDFM.js");
        return { default: __vite_default__ };
      }, true ? [] : void 0)).default;
  }
  throw new Error(`unsupport language: ${language}`);
};
const WORDLISTS_MAP = /* @__PURE__ */ new Map();
let DEFAULT_WORDLIST;
function setDefaultWordlist(language, wordlist) {
  if (wordlist === void 0) {
    wordlist = WORDLISTS_MAP.get(language);
  }
  if (wordlist === void 0) {
    throw new Error(`need load wordList first, call \`await getWordList('${language}')\`.`);
  }
  DEFAULT_WORDLIST = { language, wordlist };
}
function getDefaultWordlist() {
  return DEFAULT_WORDLIST;
}
export {
  ALL_LANGUAGE,
  getDefaultWordlist,
  getWordList,
  setDefaultWordlist
};
