import { b as bitcoin } from "./networks-C0ceHyyb.js";
import { i as isPoint, a as isCanonicalScriptSignature, c as compile, d as decompile } from "./script-CcQKSyex.js";
import { p as prop, v as value } from "./address-myg3N2yt.js";
import { t as typeforce } from "./typeforce-BXjzjt-d.js";
import { OPS as OPS$1 } from "./ops-DRP2Obq2.js";
const OPS = OPS$1;
function p2pk(a, opts) {
  if (!a.input && !a.output && !a.pubkey && !a.input && !a.signature)
    throw new TypeError("Not enough data");
  opts = Object.assign({ validate: true }, opts || {});
  typeforce({
    network: typeforce.maybe(typeforce.Object),
    output: typeforce.maybe(typeforce.Buffer),
    pubkey: typeforce.maybe(isPoint),
    signature: typeforce.maybe(isCanonicalScriptSignature),
    input: typeforce.maybe(typeforce.Buffer)
  }, a);
  const _chunks = value(() => {
    return decompile(a.input);
  });
  const network = a.network || bitcoin;
  const o = { name: "p2pk", network };
  prop(o, "output", () => {
    if (!a.pubkey)
      return;
    return compile([a.pubkey, OPS.OP_CHECKSIG]);
  });
  prop(o, "pubkey", () => {
    if (!a.output)
      return;
    return a.output.slice(1, -1);
  });
  prop(o, "signature", () => {
    if (!a.input)
      return;
    return _chunks()[0];
  });
  prop(o, "input", () => {
    if (!a.signature)
      return;
    return compile([a.signature]);
  });
  prop(o, "witness", () => {
    if (!o.input)
      return;
    return [];
  });
  if (opts.validate) {
    if (a.output) {
      if (a.output[a.output.length - 1] !== OPS.OP_CHECKSIG)
        throw new TypeError("Output is invalid");
      if (!isPoint(o.pubkey))
        throw new TypeError("Output pubkey is invalid");
      if (a.pubkey && !a.pubkey.equals(o.pubkey))
        throw new TypeError("Pubkey mismatch");
    }
    if (a.signature) {
      if (a.input && !a.input.equals(o.input))
        throw new TypeError("Signature mismatch");
    }
    if (a.input) {
      if (_chunks().length !== 1)
        throw new TypeError("Input is invalid");
      if (!isCanonicalScriptSignature(o.signature))
        throw new TypeError("Input has invalid signature");
    }
  }
  return Object.assign(o, a);
}
export {
  p2pk as p
};
