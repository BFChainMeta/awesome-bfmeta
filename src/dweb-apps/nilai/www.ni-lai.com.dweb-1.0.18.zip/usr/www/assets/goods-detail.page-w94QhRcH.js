import { d as definePage, aL as zGoodsDetailParams, aC as useTrpcQueryState, at as userApi, r as reactExports, R as React, P as Page, O as Navbar, aM as goods_detail, aF as Toolbar, a as Button, $ as colors, a2 as Icon, aN as shop_now, aO as useSuperellipseCustomMutableRef, aP as price, aQ as discounted_price_info, aR as buy_now, Q as PageContent, ad as LoadingPageData, V as useFlow, aS as SharedTransition, ax as BlobImage, aT as z, aU as N, aV as discounted_price, aW as price_with_html, aX as promotional_price, aY as points_can_offset, aK as SuperellipseBox, aZ as details, x as toast, a_ as this_product_has_been_taken_down } from "./index-DAk_nVWR.js";
const goodsDetail_page = definePage(({ goods, ...args }) => {
  const { goodsId } = zGoodsDetailParams.parse(args.f7route.params);
  if (!goodsId) {
    return;
  }
  const getGoodsDetails = useTrpcQueryState(userApi.getGoodsDetails);
  const [details2 = goods, isLoadingDetails, queryGoodsDetails] = getGoodsDetails;
  reactExports.useEffect(() => {
    if (details2 == null) {
      getGoodsDetails.doQuery(goodsId);
    }
  }, [goodsId]);
  const goPayment = async () => {
    const details22 = await queryGoodsDetails(goodsId);
    if (details22.status !== 1) {
      toast(this_product_has_been_taken_down());
      return;
    }
    const amount = details22.promotionalPrice ?? details22.price;
    args.safeF7Navigater.goods.orderConfirmation({
      query: {
        goodsDiscountbrandProportion: details22.goodsDiscountbrandProportion,
        amount,
        goodsName: details22.goodsName,
        goodsId,
        nilaiProportion: details22.nilaiProportion,
        brandProportion: details22.brandProportion,
        imgBloburi: details22.thumbnail[0].bloburi
      }
    });
    args.safeF7Navigater.goods.payment;
  };
  return /* @__PURE__ */ React.createElement(Page, { name: "good-detail", className: "bg-background", ...args.pageProps, pageContent: false }, /* @__PURE__ */ React.createElement(Navbar, { title: goods_detail(), backLink: true, color: "white" }), /* @__PURE__ */ React.createElement(Toolbar, { bottom: true, style: { "--f7-toolbar-height": "4.5rem" } }, /* @__PURE__ */ React.createElement(
    Button,
    {
      color: colors.primary,
      className: "text-xss rounded-3 h-12 px-4",
      onClick: () => {
        if (details2) {
          args.safeF7Navigater.brand.details({
            params: details2.brandInfo,
            props: { brand: details2.brandInfo }
          });
        }
      }
    },
    /* @__PURE__ */ React.createElement("div", { className: "text-primary flex flex-col items-center justify-center" }, /* @__PURE__ */ React.createElement(Icon, { material: "storefront", size: 28 }), /* @__PURE__ */ React.createElement("span", null, shop_now()))
  ), /* @__PURE__ */ React.createElement(
    Button,
    {
      ref: useSuperellipseCustomMutableRef((it) => it.el, {}),
      raised: true,
      preloader: isLoadingDetails,
      preloaderColor: "white",
      loading: isLoadingDetails,
      color: "white",
      onClick: goPayment,
      className: "bg-secondary-red text-xss rounded-3 h-12 px-4"
    },
    /* @__PURE__ */ React.createElement("div", { className: "flex flex-col items-center justify-center" }, /* @__PURE__ */ React.createElement("span", { className: "flex items-center text-xs" }, /* @__PURE__ */ React.createElement(Icon, { f7: "money_yen", size: 20 }), /* @__PURE__ */ React.createElement("span", { className: "text-base" }, price(
      details2 ? details2.goodsDiscountbrandProportion ? discounted_price_info(
        details2.promotionalPrice || details2.price,
        details2.goodsDiscountbrandProportion
      ).discountedPrice : details2.promotionalPrice ?? details2.price : void 0
    ))), /* @__PURE__ */ React.createElement("span", null, buy_now()))
  )), /* @__PURE__ */ React.createElement(PageContent, { style: { "--f7-toolbar-height": "72px" } }, details2 ? /* @__PURE__ */ React.createElement(GoodsDetail, { details: details2, ...args }) : /* @__PURE__ */ React.createElement(LoadingPageData, null)));
});
const GoodsDetail = ({ details: details$1, ...props }) => {
  const [isPageIn] = useFlow(props.isPageInFlow);
  return /* @__PURE__ */ React.createElement("div", { className: "w-full flex-grow overflow-auto" }, /* @__PURE__ */ React.createElement(SharedTransition, { sharedId: details$1.thumbnail[0].bloburi, visibility: isPageIn }, /* @__PURE__ */ React.createElement(
    BlobImage,
    {
      className: "h-[48vh] max-h-[375px] w-full object-cover",
      fill: true,
      bloburi: details$1.thumbnail[0].bloburi,
      alt: ""
    }
  )), /* @__PURE__ */ React.createElement("div", { className: "m-auto mt-2 w-[96%] p-2 text-lg text-white" }, /* @__PURE__ */ React.createElement("div", { className: "mt-1 break-all font-bold" }, details$1.type === 0 ? /* @__PURE__ */ React.createElement(Icon, { className: "mb-1", f7: "flame_fill", color: "red", size: 16 }) : /* @__PURE__ */ React.createElement(React.Fragment, null), details$1.title), /* @__PURE__ */ React.createElement("div", { className: "" }, /* @__PURE__ */ React.createElement("span", { className: "text-primary text-xs" }, z(details$1).with({ goodsDiscountbrandProportion: N.nonNullable.select() }, (goodsDiscountbrandProportion) => {
    return /* @__PURE__ */ React.createElement(React.Fragment, null, /* @__PURE__ */ React.createElement("span", { className: "text-secondary-red mr-1" }, discounted_price()), /* @__PURE__ */ React.createElement("span", { className: "text-secondary-red mr-1" }, "¥"), /* @__PURE__ */ React.createElement("span", { className: "text-secondary-red mr-1 text-base" }, price_with_html(
      discounted_price_info(details$1.promotionalPrice || details$1.price, goodsDiscountbrandProportion).discountedPrice,
      {
        dotClassName: "text-xss",
        floatClassName: "text-xss"
      }
    )), /* @__PURE__ */ React.createElement("span", { className: "text-xss text-subtext mr-1 line-through" }, price(details$1.promotionalPrice || details$1.price)));
  }).with({ promotionalPrice: N.nonNullable.select() }, (promotionalPrice) => /* @__PURE__ */ React.createElement(React.Fragment, null, /* @__PURE__ */ React.createElement("span", { className: "text-secondary-red mr-1" }, promotional_price()), /* @__PURE__ */ React.createElement("span", { className: "text-secondary-red mr-1" }, "¥"), /* @__PURE__ */ React.createElement("span", { className: "text-secondary-red mr-1 text-base" }, price(promotionalPrice)), /* @__PURE__ */ React.createElement("span", { className: "text-xss text-subtext line-through" }, price(details$1.price)))).otherwise(() => /* @__PURE__ */ React.createElement(React.Fragment, null, /* @__PURE__ */ React.createElement("span", { className: "mr-1" }, "¥"), /* @__PURE__ */ React.createElement("span", { className: "text-base" }, price(details$1.price)))))), details$1.goodsDiscountbrandProportion && /* @__PURE__ */ React.createElement("span", { className: "bg-secondary-red rounded-3 px-1.5 py-1 text-xs text-white backdrop-blur-sm backdrop-brightness-50 backdrop-contrast-150" }, points_can_offset(), " ¥", " ", price(
    discounted_price_info(details$1.promotionalPrice || details$1.price, details$1.goodsDiscountbrandProportion).discountedDiff
  ), /* @__PURE__ */ React.createElement(Icon, { f7: "arrowshape_turn_up_right_fill", size: 12, className: "ml-0.5 rotate-90" }))), !!details$1.brandInfo.notice && /* @__PURE__ */ React.createElement("div", { className: "text-sm text-secondary-red mb-2 px-2" }, details$1.brandInfo.notice), /* @__PURE__ */ React.createElement("div", { className: "bg-pop-background rounded-4 mx-4 mb-3 flex items-center justify-between px-4 py-4 text-white" }, /* @__PURE__ */ React.createElement("div", { className: "flex items-center justify-start" }, /* @__PURE__ */ React.createElement(SuperellipseBox, { className: "rounded-3 mr-2" }, /* @__PURE__ */ React.createElement(BlobImage, { bloburi: details$1.brandInfo.logo, fill: "48x48", className: "h-12 w-12", alt: "brand logo" })), /* @__PURE__ */ React.createElement("div", { className: "text-sm text-white" }, details$1.brandInfo.brandName)), /* @__PURE__ */ React.createElement(
    "button",
    {
      className: "rounded-2 bg-primary w-auto px-2 py-1 text-sm font-bold text-black",
      onClick: () => {
        props.safeF7Navigater.brand.details({
          params: details$1.brandInfo,
          props: { brand: details$1.brandInfo }
        });
      }
    },
    shop_now()
  )), /* @__PURE__ */ React.createElement("div", { className: "bg-pop-background rounded-4 mx-4 mb-4 pb-4" }, /* @__PURE__ */ React.createElement("div", { className: "flex items-center justify-center pb-4 pt-5 text-center text-white" }, /* @__PURE__ */ React.createElement(
    "span",
    {
      style: {
        display: "inline-block",
        width: "64px",
        height: "1px",
        background: "linear-gradient( 315deg, rgba(255,255,255,0.3) 0%, rgba(255,255,255,0.03) 100%)",
        borderRadius: "0px 0px 0px 0px"
      },
      className: "mr-3"
    }
  ), details(), /* @__PURE__ */ React.createElement(
    "span",
    {
      style: {
        display: "inline-block",
        width: "64px",
        height: "1px",
        background: "linear-gradient( 315deg, rgba(255,255,255,0.03) 0%, rgba(255,255,255,0.3) 96%)",
        borderRadius: "0px 0px 0px 0px"
      },
      className: "ml-3"
    }
  )), details$1.detail.map((item, index) => {
    return /* @__PURE__ */ React.createElement("div", { key: String(index) }, /* @__PURE__ */ React.createElement(BlobImage, { className: "h-auto w-full", bloburi: item.bloburi, fill: true, alt: "" }));
  })));
};
export {
  goodsDetail_page as default
};
