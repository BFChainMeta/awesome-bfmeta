import { c as createWasmPreparer } from "./WASMInterface-BIOcGvqx.js";
const prepareSHA256 = createWasmPreparer("sha256", 32);
const sha256 = async (data) => {
  return (await prepareSHA256()).calculate(data, 256);
};
const createSHA256 = async () => {
  return createSHA256Sync(await prepareSHA256());
};
const createSHA256Sync = (wasm = prepareSHA256.wasm) => {
  wasm.init(256);
  const obj = {
    init: () => {
      wasm.init(256);
      return obj;
    },
    update: (data) => {
      wasm.update(data);
      return obj;
    },
    digest: (outputType) => wasm.digest(outputType),
    save: () => wasm.save(),
    load: (data) => {
      wasm.load(data);
      return obj;
    },
    blockSize: 64,
    digestSize: 32
  };
  return obj;
};
export {
  createSHA256 as a,
  createSHA256Sync as c,
  prepareSHA256 as p,
  sha256 as s
};
