import { d as definePage, r as reactExports, al as usePageQueryState, R as React, P as Page, O as Navbar, bT as my_points_record, bU as Subnavbar, bV as Segmented, $ as colors, a as Button, bW as reward, bX as deducted, Q as PageContent, ad as LoadingPageData, a6 as List, a7 as ListItem, ae as NoData, bY as order_id, F as userController, N as NiLaiIcon, b3 as Big, bZ as sending, ba as get_showAsset_balance, b_ as consumption, b$ as invitation, c0 as returned } from "./index-DAk_nVWR.js";
import { A as AssetTypeName, a as AssetTypeIcon } from "./asset-type-Dz_tlnol.js";
const formatDateTime = (timestamp) => {
  const date = new Date(timestamp);
  const formatter = new Intl.DateTimeFormat("en-CA", {
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hour12: false
    // 24 小时制
  });
  return formatter.format(date).replace(/[-]/g, ".").replace(/,/, "");
};
const minePointsRecord_page = definePage((args) => {
  const pageContentRef = reactExports.useRef({ el: null });
  const [pointsStatus, setPoints] = reactExports.useState(
    0
    /* reward */
  );
  const pointsRecordListHub = {
    [
      0
      /* reward */
    ]: usePageQueryState([], 1, async (preContent, page) => {
      const result = await userController.getRewardList(page, 20);
      preContent.push(...result.data);
      const content = preContent;
      return {
        content,
        nextPage: page + 1,
        end: content.length >= result.total
      };
    }),
    [
      1
      /* use */
    ]: usePageQueryState([], 1, async (preContent, page) => {
      const result = await userController.getDeductionList(page, 20);
      preContent.push(...result.data);
      const content = preContent;
      return {
        content,
        nextPage: page + 1,
        end: content.length >= result.total
      };
    })
  };
  const pointsRecordList = pointsRecordListHub[pointsStatus];
  reactExports.useEffect(() => {
    if (pointsRecordList.isLoading === false && pointsRecordList.isReady === false) {
      pointsRecordList.loadFirst();
    }
  }, [pointsRecordList]);
  const switchPoinstsStatus = (status) => {
    if (pointsStatus === status) {
      return;
    }
    pageContentRef.current.el && pageContentRef.current.el.scrollTo({
      left: 0,
      top: 0,
      behavior: "smooth"
    });
    setPoints(status);
  };
  return /* @__PURE__ */ React.createElement(Page, { name: "mine-points-record", pageContent: false }, /* @__PURE__ */ React.createElement(Navbar, { title: my_points_record(), backLink: true, color: "white", className: "text-white" }, /* @__PURE__ */ React.createElement(Subnavbar, null, /* @__PURE__ */ React.createElement(
    Segmented,
    {
      strong: true,
      style: {
        "--f7-segmented-strong-button-active-bg-color": colors.primary,
        "--f7-segmented-strong-button-text-color": colors.subtext,
        "--f7-segmented-strong-button-active-text-color": colors.black
      }
    },
    /* @__PURE__ */ React.createElement(
      Button,
      {
        active: pointsStatus === 0,
        onClick: () => switchPoinstsStatus(
          0
          /* reward */
        )
      },
      reward()
    ),
    /* @__PURE__ */ React.createElement(Button, { active: pointsStatus === 1, onClick: () => switchPoinstsStatus(
      1
      /* use */
    ) }, deducted())
  ))), /* @__PURE__ */ React.createElement(PageContent, { ref: pageContentRef, ...pointsRecordList.f7PageInfiniteProps }, pointsRecordList.render({
    loading: () => /* @__PURE__ */ React.createElement(LoadingPageData, null),
    content: (data) => data.length ? /* @__PURE__ */ React.createElement(
      List,
      {
        strong: true,
        dividers: true,
        accordionList: true,
        className: "rounded-4 mx-4 mt-4 overflow-hidden",
        style: {
          "--f7-list-strong-bg-color": "#232629",
          "--f7-list-item-border-color": "#626A73"
        }
      },
      data.map((item, index) => {
        return /* @__PURE__ */ React.createElement(ListItem, { key: index }, pointsStatus === 0 ? /* @__PURE__ */ React.createElement(AirdropItemView, { info: item }) : /* @__PURE__ */ React.createElement(OrderDiscountItemView, { info: item }));
      })
    ) : /* @__PURE__ */ React.createElement(NoData, { cssClass: "text-subtext mt-[20vh]" })
  })));
});
const getItemTypeText = (str) => {
  const type = {
    /** 购物 */
    consumption: consumption(),
    /** 邀请 */
    invitation: invitation(),
    /** 抵扣 */
    deduction: deducted(),
    /** 退回 */
    refund: returned()
  };
  return type[str];
};
const AirdropItemView = ({ info }) => {
  const getRewardValue = (item) => {
    if (item.airdropType === "cashback") {
      return /* @__PURE__ */ React.createElement(React.Fragment, null, +(item.airdropCashback || 0) * 100 / 1e4, /* @__PURE__ */ React.createElement(NiLaiIcon, { name: "red-envelope", className: "icon-4 ml-1" }));
    } else {
      const assetBalance_BI = new Big(item.airdropAssetType.assetInfo.number);
      return /* @__PURE__ */ React.createElement(React.Fragment, null, /* @__PURE__ */ React.createElement("span", { className: "ml-1 mr-0.5" }, assetBalance_BI.div(1e8).toString()), /* @__PURE__ */ React.createElement("span", { className: "text-xs text-white" }, /* @__PURE__ */ React.createElement("span", { className: "text-primary mr-1" }, /* @__PURE__ */ React.createElement(
        AssetTypeName,
        {
          assetType: item.airdropAssetType.assetInfo.assetType,
          chainName: item.airdropAssetType.assetInfo.chainName
        }
      )), "x ", item.airdropAssetType.quantity), /* @__PURE__ */ React.createElement(
        AssetTypeIcon,
        {
          assetType: item.airdropAssetType.assetInfo.assetType,
          chainName: item.airdropAssetType.assetInfo.chainName,
          cssClass: "ml-1 h-4 w-4 rounded-full"
        }
      ));
    }
  };
  const getTipsText = (item) => {
    if (!item.done) {
      if (item.airdropType === "cashback") {
        return /* @__PURE__ */ React.createElement("div", { className: "text-subtext text-right" }, sending());
      } else {
        return /* @__PURE__ */ React.createElement("div", { className: "text-subtext text-right" }, sending(), ": ", item.airdropAssetType.transactionList.filter((item2) => item2.inBlockType == 1).length, "/", item.airdropAssetType.quantity);
      }
    }
  };
  return /* @__PURE__ */ React.createElement(React.Fragment, null, /* @__PURE__ */ React.createElement("div", { className: "w-full text-base" }, /* @__PURE__ */ React.createElement("div", { className: "text-xss text-subtext" }, formatDateTime(info.createdAt)), /* @__PURE__ */ React.createElement("div", { className: "flex items-center justify-between" }, /* @__PURE__ */ React.createElement("div", { className: "text-sm text-white" }, getItemTypeText(info.airdropCategory)), /* @__PURE__ */ React.createElement("div", { className: `${info.done ? "text-primary" : "text-subtext"} flex items-center justify-end` }, "+", getRewardValue(info))), /* @__PURE__ */ React.createElement("div", { className: "text-xss" }, getTipsText(info))));
};
const OrderDiscountItemView = ({ info }) => {
  const getValue = (item) => {
    const assetType = item.transactionInfo.trs.asset.transferAsset.assetType;
    const amount = item.transactionInfo.trs.asset.transferAsset.amount;
    const chainName = item.transactionInfo.chainName;
    return /* @__PURE__ */ React.createElement(React.Fragment, null, /* @__PURE__ */ React.createElement("span", { className: "ml-1 mr-0.5" }, item.type === "refund" ? "+" : "-", " ", get_showAsset_balance(amount)), /* @__PURE__ */ React.createElement("span", { className: "text-xs" }, /* @__PURE__ */ React.createElement("span", { className: "mr-1" }, /* @__PURE__ */ React.createElement(AssetTypeName, { assetType, chainName }))), /* @__PURE__ */ React.createElement(AssetTypeIcon, { assetType, chainName, cssClass: "ml-1 h-4 w-4 rounded-full" }));
  };
  return /* @__PURE__ */ React.createElement("div", { className: "w-full text-base" }, /* @__PURE__ */ React.createElement("div", { className: "text-xss text-subtext flex items-center justify-between" }, formatDateTime(info.createdAt), /* @__PURE__ */ React.createElement("span", null, order_id(), ":", info.orderId)), /* @__PURE__ */ React.createElement("div", { className: "flex items-center justify-between" }, /* @__PURE__ */ React.createElement("div", { className: "text-sm text-white" }, getItemTypeText(info.type)), /* @__PURE__ */ React.createElement(
    "div",
    {
      className: `${info.type === "refund" ? "text-secondary-green" : "text-secondary-red"} flex items-center justify-end`
    },
    getValue(info)
  )));
};
export {
  AirdropItemView,
  OrderDiscountItemView,
  minePointsRecord_page as default
};
