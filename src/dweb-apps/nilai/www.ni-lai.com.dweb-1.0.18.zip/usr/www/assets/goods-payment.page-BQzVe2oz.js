import { G as GoodsOrderDiscountStatus } from "./order.table-BhHagEF8.js";
import { d as definePage, a$ as zGoodsPaymentQuery, r as reactExports, V as useFlow, b0 as if_payment_is_made_for_this_order_please_do_not_proceed_with_payment, b1 as cancel, b2 as payment, b3 as Big, b4 as func_exclusive, R as React, P as Page, O as Navbar, b5 as confirm_payment, a as Button, b6 as FadeInOut, b7 as Preloader, b8 as deduct_again, B as Block, ax as BlobImage, b9 as need_to_consume_$consume$_to_deduction$deduction$, ba as get_showAsset_balance, bb as get_discount_consumption_asset_types_amount_info, aP as price, bc as payment_method, a6 as List, a7 as ListItem, bd as alipay, be as AlertDialog, n as ConfirmDialog, bf as address_transaction_password, ah as confirm, aG as clsx, bg as please_enter_the_address_transaction_password, aj as appUserInfoFlow, bh as f7, at as userApi, a_ as this_product_has_been_taken_down, F as userController, bi as there_are_unpaid_orders_for_this_product_Please_go_to_My_Orders_to_process_the_payment, I as ccchainController, bj as getUserAddressSecondPublicKey, x as toast, bk as payment_error, bl as browserOpen, bm as order_initiated_successfully, bn as Please_go_to_my_order_to_check_the_status_of_your_order, bo as view_order, bp as back, bq as delay, br as transaction_password_incorrect, bs as nilaiDialogStyle } from "./index-DAk_nVWR.js";
import { A as AssetTypeName } from "./asset-type-Dz_tlnol.js";
import { u as useRefresh } from "./use_refresh-BDtdKSoi.js";
const goodsPayment_page = definePage(({ payPwd, ...args }) => {
  const detailObj = zGoodsPaymentQuery.parse(args.f7route.query);
  const secondPublicKey = reactExports.useRef("");
  const [deductAgain, setDeductAgain] = reactExports.useState(false);
  const [amount, setAmount] = reactExports.useState("0");
  const [appUserInfo] = useFlow(appUserInfoFlow);
  const deductionInfo = reactExports.useRef(null);
  const [paymentType, setPaymentType] = reactExports.useState(
    "ALIPAY"
    /* ALIPAY */
  );
  const [openErrorDialog, setOpenErrorDialog] = reactExports.useState(false);
  const [errorText, setErrorText] = reactExports.useState("");
  const contentRefresh = useRefresh();
  const [openConfirmDialog, setOpenConfirmDialog] = reactExports.useState(false);
  const confirmCallBack = reactExports.useRef({
    confirm: () => {
    },
    cancel: () => {
    }
  });
  const confirmText = reactExports.useRef({
    message: () => if_payment_is_made_for_this_order_please_do_not_proceed_with_payment(),
    cancelText: () => cancel(),
    confirmText: () => payment()
  });
  const [payUrl, setPayUrl] = reactExports.useState("");
  const alertDialogCallBack = reactExports.useRef(() => {
  });
  const initPayUrl = async () => {
    try {
      f7.preloader.show();
      alertDialogCallBack.current = () => args.f7router.back(void 0, {
        force: true
      });
      const details = await userApi.getGoodsDetails.query(detailObj.goodsId);
      if (details.status !== 1) {
        setErrorText(this_product_has_been_taken_down());
        setOpenErrorDialog(true);
        return;
      }
      if (detailObj.orderId && await userController.hasOrderPay(detailObj.orderId)) {
        const hasSuccess = await userController.getOrderPaymentStatus(detailObj.orderId);
        if (hasSuccess) {
          setErrorText((void 0)());
          setOpenErrorDialog(true);
          return;
        }
      }
      const res = await userController.createOrder({
        orderId: deductionInfo?.current?.orderId || detailObj.orderId || "",
        goodsId: detailObj.goodsId,
        addressId: detailObj.addressId,
        quantity: +detailObj.quantity,
        actualPrice: String(detailObj.amount),
        paymentMethod: paymentType,
        airdropInfo: {
          platform: {
            assetType: detailObj.platformAssetType || "",
            chainMagic: detailObj.platformChainMagic || ""
          },
          brand: {
            assetType: detailObj.brandAssetType || "",
            chainMagic: detailObj.brandChainMagic || ""
          }
        },
        orderNotes: detailObj.orderNotes || void 0,
        discountInformation: detailObj.discountAssetType && detailObj.discountChainMagic ? {
          assetType: detailObj.discountAssetType,
          chainMagic: detailObj.discountChainMagic
        } : void 0
      });
      if (res.success === false) {
        setErrorText(there_are_unpaid_orders_for_this_product_Please_go_to_My_Orders_to_process_the_payment());
        setOpenErrorDialog(true);
        return;
      }
      {
        if (res.discountInfo) {
          const price_BI = new Big(res.actualPrice);
          setAmount(price_BI.mul(detailObj.quantity).toString());
          for await (const item of res.discountInfo) {
            if (item.type === "assetType") {
              item.info.fee = item.info.trs?.fee || (await ccchainController.getTransferTransactionMinFee({
                paySecret: "abcdefghijklnmopqrstuvwxyz",
                receiveAddress: res.reAddress,
                remark: {
                  orderId: res.orderId
                },
                assetType: item.info.brandStablecoin.assetType,
                amount: item.info.amount
              })).fee;
            }
          }
          deductionInfo.current = res;
          if (res.payUrl) {
            setPayUrl(res.payUrl);
          }
          if (!inputUserPayPwd) {
            const userSecondPublicKey = await getUserAddressSecondPublicKey(appUserInfo.address);
            if (userSecondPublicKey) {
              secondPublicKey.current = userSecondPublicKey;
            }
          }
          contentRefresh();
          return;
        }
      }
      const data = res.data;
      if (typeof data === "number") {
        setErrorText((void 0)());
        setOpenErrorDialog(true);
        return;
      }
      const payUrl2 = data.payUrl;
      setPayUrl(payUrl2);
    } catch (err) {
      toast(String(err));
      setErrorText(payment_error());
      setOpenErrorDialog(true);
    } finally {
      f7.preloader.hide();
    }
  };
  const submitOrderDeductedTrs = async () => {
    try {
      if (deductionInfo.current) {
        f7.preloader.show();
        const deductionAssetTypeItem = deductionInfo.current?.discountInfo.find(
          (item) => item.type === "assetType" && (item.info.status === GoodsOrderDiscountStatus.init || item.info.status === GoodsOrderDiscountStatus.fail)
        );
        if (deductionAssetTypeItem) {
          if (secondPublicKey.current && !inputUserPayPwd) {
            setOpenUserPayPwdDialog(true);
            return;
          }
          const discountAmount = get_discount_consumption_asset_types_amount_info(detailObj.amount, {
            deductionRatio: detailObj.goodsDiscountbrandProportion,
            numberToPriceRatio: deductionAssetTypeItem.info.brandStablecoin.number,
            goodsQuantity: detailObj.quantity
          }).discountedAmount;
          let fee = deductionAssetTypeItem.info.fee;
          if (fee) {
            fee = String(BigInt(fee) * 2n);
          }
          const trs = await ccchainController.getTransferTransaction({
            mainSecret: appUserInfo.main,
            paySecret: inputUserPayPwd || void 0,
            receiveAddress: deductionInfo.current.reAddress,
            remark: {
              orderId: deductionInfo.current.orderId
            },
            assetType: deductionAssetTypeItem.info.brandStablecoin.assetType,
            amount: discountAmount,
            fee
          });
          const success = await userController.submitOrderDeductedTrs(trs);
          if (success && deductionInfo.current) {
            await initPayUrl();
            setDeductAgain(false);
            contentRefresh();
          }
        }
      }
    } catch (err) {
      toast(String(err));
      setDeductAgain(true);
    } finally {
      f7.preloader.hide();
    }
  };
  reactExports.useEffect(() => {
    const price_BI = new Big(detailObj.actualPrice);
    setAmount(price_BI.mul(detailObj.quantity).toString());
    initPayUrl().then(submitOrderDeductedTrs);
  }, []);
  const selectPaymentType = (type) => {
    setPaymentType(type);
  };
  const confirmPayment = async () => {
    try {
      let cancel_pay = Promise.withResolvers();
      if (detailObj.orderId) {
        confirmCallBack.current = {
          confirm: () => cancel_pay.resolve(false),
          cancel: () => cancel_pay.resolve(true)
        };
        setOpenConfirmDialog(true);
      } else {
        cancel_pay.resolve(false);
      }
      if (await cancel_pay.promise) {
        return;
      }
      f7.preloader.show();
      const backPage = (back2) => {
        if (back2) {
          args.f7router.back(void 0, {
            force: true
          });
          return;
        }
        args.safeF7Navigater.order.orderList({ reloadCurrent: true });
      };
      browserOpen(payUrl, "_blank");
      if (detailObj.orderId) {
        toast(order_initiated_successfully());
      }
      if (detailObj.orderId) {
        setErrorText(Please_go_to_my_order_to_check_the_status_of_your_order());
        setOpenErrorDialog(true);
        alertDialogCallBack.current = () => backPage(true);
      } else {
        confirmText.current = {
          message: () => Please_go_to_my_order_to_check_the_status_of_your_order(),
          cancelText: () => view_order(),
          confirmText: () => back()
        };
        confirmCallBack.current = {
          confirm: () => backPage(true),
          cancel: () => backPage(false)
        };
        contentRefresh();
        setOpenConfirmDialog(true);
      }
    } catch (err) {
      toast(String(err));
    } finally {
      f7.preloader.hide();
    }
  };
  const deductAgainTrs = reactExports.useMemo(
    () => func_exclusive(async () => {
      const ani_delayer = delay(1e3);
      await ani_delayer;
      await submitOrderDeductedTrs();
    }),
    []
  );
  const deductAgainTrsFlow = useFlow(deductAgainTrs.stateFlow);
  const [openUserPayPwdDialog, setOpenUserPayPwdDialog] = reactExports.useState(false);
  const [inputUserPayPwd, setInputUserPayPwd] = reactExports.useState(payPwd || "");
  const checkUserPayPwd = async () => {
    const userPayPwd = inputUserPayPwd;
    setInputUserPayPwd("");
    if (!userPayPwd) {
      return;
    }
    const res = await ccchainController.checkSecondSecret(appUserInfo.main, userPayPwd, secondPublicKey.current);
    if (!res) {
      toast(transaction_password_incorrect());
      setDeductAgain(true);
      return;
    }
    submitOrderDeductedTrs();
  };
  return /* @__PURE__ */ React.createElement(Page, { name: "good-detail", bgColor: "white", className: "bg-background" }, /* @__PURE__ */ React.createElement(Navbar, { title: confirm_payment(), backLink: true, color: "white", className: "text-white" }, /* @__PURE__ */ React.createElement("div", { className: "navbar-bg !bg-background" })), /* @__PURE__ */ React.createElement("div", { className: "bg-background flex h-full w-full flex-col items-center justify-between" }, /* @__PURE__ */ React.createElement("div", { className: "w-full flex-grow overflow-scroll" }, /* @__PURE__ */ React.createElement("div", { className: "text-primary pt-16 text-center text-[2.5rem] font-bold" }, "¥", +amount * 100 / 1e4), /* @__PURE__ */ React.createElement("div", { className: "text-center text-base text-white" }, detailObj.goodsName), !!deductionInfo.current && /* @__PURE__ */ React.createElement("div", { className: "text-subtext pb-4 pt-6" }, deductAgain && /* @__PURE__ */ React.createElement("div", { className: "mb-2 flex items-center justify-end px-4 text-xs" }, /* @__PURE__ */ React.createElement(Button, { className: "bg-primary text-xs text-black", onClick: deductAgainTrs }, /* @__PURE__ */ React.createElement(
    FadeInOut,
    {
      condition: deductAgainTrsFlow.value === "pending",
      true_node: () => /* @__PURE__ */ React.createElement(Preloader, { size: 12, className: "ml-0.5", color: "black" }),
      false_node: () => /* @__PURE__ */ React.createElement(React.Fragment, null, deduct_again())
    }
  ))), /* @__PURE__ */ React.createElement(Block, { strong: true, inset: true, className: "my-0 p-2" }, deductionInfo.current.discountInfo.map((item, index) => /* @__PURE__ */ React.createElement("div", { key: index }, /* @__PURE__ */ React.createElement("div", { className: "flex items-center justify-between" }, /* @__PURE__ */ React.createElement(
    BlobImage,
    {
      className: "mr-2 h-6 w-6 rounded-full object-cover",
      bloburi: item.info.brandStablecoin.logo,
      alt: ""
    }
  ), /* @__PURE__ */ React.createElement("div", { className: "w-full text-sm" }, /* @__PURE__ */ React.createElement("div", { className: "flex items-center justify-between" }, /* @__PURE__ */ React.createElement(
    AssetTypeName,
    {
      cssClass: "flex-shrink-0",
      assetType: item.info.brandStablecoin.assetType,
      chainName: item.info.brandStablecoin.chainName
    }
  ), /* @__PURE__ */ React.createElement("div", { className: "ml-2 flex items-center" }, /* @__PURE__ */ React.createElement("div", { className: "text-xss mr-1 text-right" }, /* @__PURE__ */ React.createElement(
    "div",
    {
      className: "text-sm",
      dangerouslySetInnerHTML: {
        __html: need_to_consume_$consume$_to_deduction$deduction$({
          consumeCss: "text-secondary-green",
          consume: get_showAsset_balance(
            get_discount_consumption_asset_types_amount_info(detailObj.amount, {
              deductionRatio: detailObj.goodsDiscountbrandProportion,
              numberToPriceRatio: item.info.brandStablecoin.number,
              goodsQuantity: detailObj.quantity
            }).discountedAmount
          ),
          deductionCss: "text-primary",
          deduction: price(
            get_discount_consumption_asset_types_amount_info(detailObj.amount, {
              deductionRatio: detailObj.goodsDiscountbrandProportion,
              numberToPriceRatio: item.info.brandStablecoin.number,
              goodsQuantity: detailObj.quantity
            }).discountedDiff
          )
        })
      }
    }
  ))))))))))), /* @__PURE__ */ React.createElement("div", { className: "w-full flex-shrink-0" }, /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("div", { className: "text-subtext px-3 py-2" }, payment_method(), " :"), /* @__PURE__ */ React.createElement("div", { className: "rounded-3 overflow-hidden px-4" }, /* @__PURE__ */ React.createElement(List, { strongIos: true, dividersIos: true, className: "rounded-3 nilai my-0 overflow-hidden" }, /* @__PURE__ */ React.createElement(
    ListItem,
    {
      radio: true,
      name: "seleted-payment-type",
      checked: paymentType === "ALIPAY",
      onChange: () => selectPaymentType(
        "ALIPAY"
        /* ALIPAY */
      )
    },
    /* @__PURE__ */ React.createElement("img", { src: "./images/alipay-payment.svg", className: "h-6 w-6", slot: "media" }),
    /* @__PURE__ */ React.createElement("div", { slot: "before-title", className: "text-white" }, alipay())
  )))), /* @__PURE__ */ React.createElement("div", { className: "w-full flex-shrink-0 px-5" }, /* @__PURE__ */ React.createElement(
    Button,
    {
      large: true,
      raised: true,
      fill: true,
      disabled: !payUrl,
      preloader: true,
      preloaderColor: "black",
      className: `bg-primary my-4 w-full rounded-full text-base font-bold text-black`,
      onClick: confirmPayment
    },
    confirm_payment()
  )))), /* @__PURE__ */ React.createElement(
    AlertDialog,
    {
      open: openErrorDialog,
      onRequireClose: setOpenErrorDialog,
      onConfirmCallback: alertDialogCallBack.current
    },
    errorText
  ), /* @__PURE__ */ React.createElement(
    ConfirmDialog,
    {
      cancelText: confirmText.current.cancelText(),
      confirmText: confirmText.current.confirmText(),
      open: openConfirmDialog,
      onRequireClose: setOpenConfirmDialog,
      onConfirmCallback: confirmCallBack.current.confirm,
      onCancelCallback: confirmCallBack.current.cancel
    },
    confirmText.current.message()
  ), /* @__PURE__ */ React.createElement(
    ConfirmDialog,
    {
      open: openUserPayPwdDialog,
      title: address_transaction_password(),
      confirmText: confirm(),
      onRequireClose: () => {
        setOpenUserPayPwdDialog(false);
        setDeductAgain(true);
      },
      className: clsx("dialog", nilaiDialogStyle.nilaiDialog),
      onCancelCallback: () => setInputUserPayPwd(""),
      onConfirmCallback: () => checkUserPayPwd()
    },
    /* @__PURE__ */ React.createElement(
      "input",
      {
        value: inputUserPayPwd,
        onChange: (e) => {
          setInputUserPayPwd(e.target.value);
        },
        placeholder: please_enter_the_address_transaction_password(),
        type: "password",
        className: "!bg-pop-background !rounded-3 !px-2 !py-1 text-center text-white"
      }
    )
  ));
});
export {
  goodsPayment_page as default
};
