import { d as definePage, c4 as z, V as useFlow, r as reactExports, c as canOpenUrl, g as getDwebAppDownUrl, R as React, P as Page, O as Navbar, d1 as account_backup, Q as PageContent, d2 as account_backup_tips, B as Block, d3 as address, d4 as current_account_key, N as NiLaiIcon, $ as colors, d5 as account_import_tips, a as Button, d6 as Connect_to_X_Pay_for_verification, d7 as display_key, aj as appUserInfoFlow, cv as writeText, x as toast, cD as copied_successfully, q as dwebAppConfig, t as gotoDwebAppMarketDownLoad, d8 as verifyAddressImport, d9 as CHAIN_NAME, w as focusWindow, da as validation_failed, db as verification_successful, dc as updateLoginerUserBackup } from "./index-DAk_nVWR.js";
const z_MimeAddressPageType = z.enum(["pick", "manage"]);
const userBackUp_page = definePage((args) => {
  const [appUserInfo] = useFlow(appUserInfoFlow);
  const copyText = async () => {
    if (showPwd === false) {
      return;
    }
    await writeText(appUserInfo.main);
    toast(copied_successfully());
  };
  const [showPwd, setShowPwd] = reactExports.useState(false);
  const xPayInfo = dwebAppConfig.XPay(false);
  const [isLoading, setIsLoading] = reactExports.useState(false);
  const [hasDownXPay, setHasDownXPay] = reactExports.useState(true);
  const [dwebDownUrl, setDwebDownUrl] = reactExports.useState(
    {}
  );
  reactExports.useEffect(() => {
    {
      canOpenUrl(xPayInfo.mmid).then((canOpen) => {
        setHasDownXPay(canOpen.success);
      }).catch();
      getDwebAppDownUrl(xPayInfo).then((res) => setDwebDownUrl(res));
    }
  }, []);
  const checkAccountBackup = async () => {
    if (showPwd === false) {
      setShowPwd(true);
      return;
    }
    try {
      setIsLoading(true);
      if (!hasDownXPay) {
        gotoDwebAppMarketDownLoad(dwebDownUrl);
        setHasDownXPay(true);
        return;
      }
      setIsLoading(false);
      const res = await verifyAddressImport(xPayInfo.mmid, {
        address: appUserInfo.address,
        message: account_backup(),
        chainName: CHAIN_NAME.CCChain
      });
      void focusWindow();
      if (res == false) {
        toast(validation_failed());
        return;
      }
      toast(verification_successful());
      updateLoginerUserBackup(appUserInfo.address);
      args.f7router.back();
    } finally {
      setIsLoading(false);
    }
  };
  return /* @__PURE__ */ React.createElement(Page, { name: "user-back-up", pageContent: false }, /* @__PURE__ */ React.createElement(Navbar, { title: account_backup(), backLink: true, color: "white" }), /* @__PURE__ */ React.createElement(PageContent, null, /* @__PURE__ */ React.createElement("p", { className: "text-secondary-red px-5 pt-5 text-xs" }, "*", account_backup_tips()), /* @__PURE__ */ React.createElement(Block, { strong: true, inset: true, className: "mb-2 flex-grow p-2 text-center" }, /* @__PURE__ */ React.createElement("p", { className: "text-primary mb-2 text-xs" }, address(), ": ", `${appUserInfo.address}`), /* @__PURE__ */ React.createElement("p", { className: "text-subtext" }, current_account_key()), /* @__PURE__ */ React.createElement(
    "div",
    {
      className: "rounded-3 relative flex h-12 w-full items-center justify-center overflow-hidden",
      onClick: copyText
    },
    appUserInfo.main,
    /* @__PURE__ */ React.createElement(
      NiLaiIcon,
      {
        className: "ml-1",
        style: {
          "--color-1": colors.primary
        },
        name: "common-copy"
      }
    ),
    showPwd === false && /* @__PURE__ */ React.createElement("div", { className: "bg-background absolute bottom-0 left-0 right-0 top-0 bg-opacity-75 backdrop-blur-sm" })
  )), showPwd && /* @__PURE__ */ React.createElement("p", { className: "text-secondary-red mb-4 px-5 text-center text-sm" }, "*", account_import_tips()), /* @__PURE__ */ React.createElement("div", { className: "px-5" }, /* @__PURE__ */ React.createElement(
    Button,
    {
      className: "bg-primary w-full rounded-full text-base font-bold text-black",
      large: true,
      raised: true,
      fill: true,
      preloader: true,
      loading: isLoading,
      preloaderColor: "black",
      onClick: checkAccountBackup
    },
    showPwd ? Connect_to_X_Pay_for_verification() : display_key()
  ))));
});
const AddressInfoView = ({
  info,
  ...props
}) => {
  return /* @__PURE__ */ React.createElement("div", { ...props }, /* @__PURE__ */ React.createElement("div", { className: "flex items-center justify-start py-1 font-bold" }, /* @__PURE__ */ React.createElement("span", { className: "mr-2" }, info.name), /* @__PURE__ */ React.createElement("span", null, info.phone)), /* @__PURE__ */ React.createElement("div", { className: "overflow-hidden break-all pb-1 text-xs text-white/80" }, `${info.area || ""} ${info.address}`));
};
export {
  AddressInfoView,
  userBackUp_page as default,
  z_MimeAddressPageType
};
