import { prepareTinySecp256k1 } from "./_setup-CN14odYP.js";
import { g as getSha3Preparer } from "./sha3-DcKHfBWh.js";
import "./index-BgMR6XJ4.js";
import "./index-DAk_nVWR.js";
import "./index-QegyMGjU.js";
import "./WASMInterface-BIOcGvqx.js";
import "./index-DzX_QLg7.js";
const prepareEthereumUtil = async () => {
  await prepareTinySecp256k1();
  await getSha3Preparer(224).prepare();
  await getSha3Preparer(256).prepare();
  await getSha3Preparer(384).prepare();
  await getSha3Preparer(512).prepare();
};
export {
  prepareEthereumUtil
};
