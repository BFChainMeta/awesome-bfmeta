import { d as definePage, r as reactExports, at as userApi, ay as useStore, R as React, P as Page, O as Navbar, a6 as List, a7 as ListItem, az as ListInput, a2 as Icon, B as Block, aA as title, a as Button, H as store } from "./index-DAk_nVWR.js";
const demo_page = definePage((args) => {
  const [name, setName] = reactExports.useState("");
  const [hello, setHello] = reactExports.useState("");
  reactExports.useEffect(() => {
    userApi.readName.query().then((name2) => setName(name2 ?? ""));
  }, []);
  reactExports.useEffect(() => {
    (async () => {
      setHello(await userApi.hello.query(name));
      await userApi.writeName.mutate(name);
    })();
  }, [name]);
  const language = useStore("lang");
  return /* @__PURE__ */ React.createElement(Page, { name: "demo" }, /* @__PURE__ */ React.createElement(Navbar, { title: "Demo Page", backLink: true }), /* @__PURE__ */ React.createElement(List, { dividersIos: true, outlineIos: true, strongIos: true }, /* @__PURE__ */ React.createElement(ListItem, { link: "/about/", title: "About Page" }), /* @__PURE__ */ React.createElement(ListItem, { link: "/login/", title: "Login Page" }), /* @__PURE__ */ React.createElement(
    ListInput,
    {
      label: "Name",
      type: "text",
      placeholder: "Your name",
      value: name,
      onInput: (e) => setName(e.target.value),
      clearButton: true
    },
    /* @__PURE__ */ React.createElement(Icon, { icon: "input", slot: "media" })
  ), /* @__PURE__ */ React.createElement(ListItem, { title: hello })), /* @__PURE__ */ React.createElement(Block, { strong: true, outlineIos: true }, /* @__PURE__ */ React.createElement("h1", null, language, ": ", title()), /* @__PURE__ */ React.createElement("div", { className: "grid-gap grid grid-cols-3" }, /* @__PURE__ */ React.createElement(Button, { tonal: true, onClick: () => store.dispatch("setLang", "zh-hans") }, "简体"), /* @__PURE__ */ React.createElement(Button, { tonal: true, onClick: () => store.dispatch("setLang", "zh-hant") }, "繁體"), /* @__PURE__ */ React.createElement(Button, { tonal: true, onClick: () => store.dispatch("setLang", "en-us") }, "Englisg"))));
});
export {
  demo_page as default
};
