(function() {
  "use strict";
  /**
   * @license
   * Copyright 2019 Google LLC
   * SPDX-License-Identifier: Apache-2.0
   */
  const proxyMarker = Symbol("Comlink.proxy");
  const createEndpoint = Symbol("Comlink.endpoint");
  const releaseProxy = Symbol("Comlink.releaseProxy");
  const finalizer = Symbol("Comlink.finalizer");
  const throwMarker = Symbol("Comlink.thrown");
  const isObject = (val) => typeof val === "object" && val !== null || typeof val === "function";
  const proxyTransferHandler = {
    canHandle: (val) => isObject(val) && val[proxyMarker],
    serialize(obj) {
      const { port1, port2 } = new MessageChannel();
      expose(obj, port1);
      return [port2, [port2]];
    },
    deserialize(port) {
      port.start();
      return wrap(port);
    }
  };
  const throwTransferHandler = {
    canHandle: (value) => isObject(value) && throwMarker in value,
    serialize({ value }) {
      let serialized;
      if (value instanceof Error) {
        serialized = {
          isError: true,
          value: {
            message: value.message,
            name: value.name,
            stack: value.stack
          }
        };
      } else {
        serialized = { isError: false, value };
      }
      return [serialized, []];
    },
    deserialize(serialized) {
      if (serialized.isError) {
        throw Object.assign(new Error(serialized.value.message), serialized.value);
      }
      throw serialized.value;
    }
  };
  const transferHandlers = /* @__PURE__ */ new Map([
    ["proxy", proxyTransferHandler],
    ["throw", throwTransferHandler]
  ]);
  function isAllowedOrigin(allowedOrigins, origin) {
    for (const allowedOrigin of allowedOrigins) {
      if (origin === allowedOrigin || allowedOrigin === "*") {
        return true;
      }
      if (allowedOrigin instanceof RegExp && allowedOrigin.test(origin)) {
        return true;
      }
    }
    return false;
  }
  function expose(obj, ep2 = globalThis, allowedOrigins = ["*"]) {
    ep2.addEventListener("message", function callback(ev) {
      if (!ev || !ev.data) {
        return;
      }
      if (!isAllowedOrigin(allowedOrigins, ev.origin)) {
        console.warn(`Invalid origin '${ev.origin}' for comlink proxy`);
        return;
      }
      const { id, type, path } = Object.assign({ path: [] }, ev.data);
      const argumentList = (ev.data.argumentList || []).map(fromWireValue);
      let returnValue;
      try {
        const parent = path.slice(0, -1).reduce((obj2, prop) => obj2[prop], obj);
        const rawValue = path.reduce((obj2, prop) => obj2[prop], obj);
        switch (type) {
          case "GET":
            {
              returnValue = rawValue;
            }
            break;
          case "SET":
            {
              parent[path.slice(-1)[0]] = fromWireValue(ev.data.value);
              returnValue = true;
            }
            break;
          case "APPLY":
            {
              returnValue = rawValue.apply(parent, argumentList);
            }
            break;
          case "CONSTRUCT":
            {
              const value = new rawValue(...argumentList);
              returnValue = proxy(value);
            }
            break;
          case "ENDPOINT":
            {
              const { port1, port2 } = new MessageChannel();
              expose(obj, port2);
              returnValue = transfer(port1, [port1]);
            }
            break;
          case "RELEASE":
            {
              returnValue = void 0;
            }
            break;
          default:
            return;
        }
      } catch (value) {
        returnValue = { value, [throwMarker]: 0 };
      }
      Promise.resolve(returnValue).catch((value) => {
        return { value, [throwMarker]: 0 };
      }).then((returnValue2) => {
        const [wireValue, transferables] = toWireValue(returnValue2);
        ep2.postMessage(Object.assign(Object.assign({}, wireValue), { id }), transferables);
        if (type === "RELEASE") {
          ep2.removeEventListener("message", callback);
          closeEndPoint(ep2);
          if (finalizer in obj && typeof obj[finalizer] === "function") {
            obj[finalizer]();
          }
        }
      }).catch((error) => {
        const [wireValue, transferables] = toWireValue({
          value: new TypeError("Unserializable return value"),
          [throwMarker]: 0
        });
        ep2.postMessage(Object.assign(Object.assign({}, wireValue), { id }), transferables);
      });
    });
    if (ep2.start) {
      ep2.start();
    }
  }
  function isMessagePort(endpoint) {
    return endpoint.constructor.name === "MessagePort";
  }
  function closeEndPoint(endpoint) {
    if (isMessagePort(endpoint))
      endpoint.close();
  }
  function wrap(ep2, target) {
    const pendingListeners = /* @__PURE__ */ new Map();
    ep2.addEventListener("message", function handleMessage(ev) {
      const { data } = ev;
      if (!data || !data.id) {
        return;
      }
      const resolver = pendingListeners.get(data.id);
      if (!resolver) {
        return;
      }
      try {
        resolver(data);
      } finally {
        pendingListeners.delete(data.id);
      }
    });
    return createProxy(ep2, pendingListeners, [], target);
  }
  function throwIfProxyReleased(isReleased) {
    if (isReleased) {
      throw new Error("Proxy has been released and is not useable");
    }
  }
  function releaseEndpoint(ep2) {
    return requestResponseMessage(ep2, /* @__PURE__ */ new Map(), {
      type: "RELEASE"
    }).then(() => {
      closeEndPoint(ep2);
    });
  }
  const proxyCounter = /* @__PURE__ */ new WeakMap();
  const proxyFinalizers = "FinalizationRegistry" in globalThis && new FinalizationRegistry((ep2) => {
    const newCount = (proxyCounter.get(ep2) || 0) - 1;
    proxyCounter.set(ep2, newCount);
    if (newCount === 0) {
      releaseEndpoint(ep2);
    }
  });
  function registerProxy(proxy2, ep2) {
    const newCount = (proxyCounter.get(ep2) || 0) + 1;
    proxyCounter.set(ep2, newCount);
    if (proxyFinalizers) {
      proxyFinalizers.register(proxy2, ep2, proxy2);
    }
  }
  function unregisterProxy(proxy2) {
    if (proxyFinalizers) {
      proxyFinalizers.unregister(proxy2);
    }
  }
  function createProxy(ep2, pendingListeners, path = [], target = function() {
  }) {
    let isProxyReleased = false;
    const proxy2 = new Proxy(target, {
      get(_target, prop) {
        throwIfProxyReleased(isProxyReleased);
        if (prop === releaseProxy) {
          return () => {
            unregisterProxy(proxy2);
            releaseEndpoint(ep2);
            pendingListeners.clear();
            isProxyReleased = true;
          };
        }
        if (prop === "then") {
          if (path.length === 0) {
            return { then: () => proxy2 };
          }
          const r = requestResponseMessage(ep2, pendingListeners, {
            type: "GET",
            path: path.map((p) => p.toString())
          }).then(fromWireValue);
          return r.then.bind(r);
        }
        return createProxy(ep2, pendingListeners, [...path, prop]);
      },
      set(_target, prop, rawValue) {
        throwIfProxyReleased(isProxyReleased);
        const [value, transferables] = toWireValue(rawValue);
        return requestResponseMessage(ep2, pendingListeners, {
          type: "SET",
          path: [...path, prop].map((p) => p.toString()),
          value
        }, transferables).then(fromWireValue);
      },
      apply(_target, _thisArg, rawArgumentList) {
        throwIfProxyReleased(isProxyReleased);
        const last = path[path.length - 1];
        if (last === createEndpoint) {
          return requestResponseMessage(ep2, pendingListeners, {
            type: "ENDPOINT"
          }).then(fromWireValue);
        }
        if (last === "bind") {
          return createProxy(ep2, pendingListeners, path.slice(0, -1));
        }
        const [argumentList, transferables] = processArguments(rawArgumentList);
        return requestResponseMessage(ep2, pendingListeners, {
          type: "APPLY",
          path: path.map((p) => p.toString()),
          argumentList
        }, transferables).then(fromWireValue);
      },
      construct(_target, rawArgumentList) {
        throwIfProxyReleased(isProxyReleased);
        const [argumentList, transferables] = processArguments(rawArgumentList);
        return requestResponseMessage(ep2, pendingListeners, {
          type: "CONSTRUCT",
          path: path.map((p) => p.toString()),
          argumentList
        }, transferables).then(fromWireValue);
      }
    });
    registerProxy(proxy2, ep2);
    return proxy2;
  }
  function myFlat(arr) {
    return Array.prototype.concat.apply([], arr);
  }
  function processArguments(argumentList) {
    const processed = argumentList.map(toWireValue);
    return [processed.map((v) => v[0]), myFlat(processed.map((v) => v[1]))];
  }
  const transferCache = /* @__PURE__ */ new WeakMap();
  function transfer(obj, transfers) {
    transferCache.set(obj, transfers);
    return obj;
  }
  function proxy(obj) {
    return Object.assign(obj, { [proxyMarker]: true });
  }
  function toWireValue(value) {
    for (const [name, handler] of transferHandlers) {
      if (handler.canHandle(value)) {
        const [serializedValue, transferables] = handler.serialize(value);
        return [
          {
            type: "HANDLER",
            name,
            value: serializedValue
          },
          transferables
        ];
      }
    }
    return [
      {
        type: "RAW",
        value
      },
      transferCache.get(value) || []
    ];
  }
  function fromWireValue(value) {
    switch (value.type) {
      case "HANDLER":
        return transferHandlers.get(value.name).deserialize(value.value);
      case "RAW":
        return value.value;
    }
  }
  function requestResponseMessage(ep2, pendingListeners, msg, transfers) {
    return new Promise((resolve) => {
      const id = generateUUID();
      pendingListeners.set(id, resolve);
      if (ep2.start) {
        ep2.start();
      }
      ep2.postMessage(Object.assign({ id }, msg), transfers);
    });
  }
  function generateUUID() {
    return new Array(4).fill(0).map(() => Math.floor(Math.random() * Number.MAX_SAFE_INTEGER).toString(16)).join("-");
  }
  const digitLookup = new Uint8Array(128);
  for (let i = 0; i < 83; i++) {
    digitLookup["0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz#$%*+,-.:;=?@[]^_{|}~".charCodeAt(
      i
    )] = i;
  }
  const decode83 = (str, start, end) => {
    let value = 0;
    while (start < end) {
      value *= 83;
      value += digitLookup[str.charCodeAt(start++)];
    }
    return value;
  };
  const pow = Math.pow;
  const PI = Math.PI;
  const PI2 = PI * 2;
  const d = 3294.6;
  const e = 269.025;
  const sRGBToLinear = (value) => value > 10.31475 ? pow(value / e + 0.052132, 2.4) : value / d;
  const linearTosRGB = (v) => ~~(v > 1227e-8 ? e * pow(v, 0.416666) - 13.025 : v * d + 1);
  const signSqr = (x) => (x < 0 ? -1 : 1) * x * x;
  const fastCos = (x) => {
    x += PI / 2;
    while (x > PI) {
      x -= PI2;
    }
    const cos = 1.27323954 * x - 0.405284735 * signSqr(x);
    return 0.225 * (signSqr(cos) - cos) + cos;
  };
  function getBlurHashAverageColor(blurHash) {
    const val = decode83(blurHash, 2, 6);
    return [val >> 16, val >> 8 & 255, val & 255];
  }
  function decodeBlurHash(blurHash, width, height, punch) {
    const sizeFlag = decode83(blurHash, 0, 1);
    const numX = sizeFlag % 9 + 1;
    const numY = ~~(sizeFlag / 9) + 1;
    const size = numX * numY;
    let i = 0, j = 0, x = 0, y = 0, r = 0, g = 0, b = 0, basis = 0, basisY = 0, colorIndex = 0, pixelIndex = 0, value = 0;
    const maximumValue = (decode83(blurHash, 1, 2) + 1) / 13446 * (punch | 1);
    const colors = new Float64Array(size * 3);
    const averageColor = getBlurHashAverageColor(blurHash);
    for (i = 0; i < 3; i++) {
      colors[i] = sRGBToLinear(averageColor[i]);
    }
    for (i = 1; i < size; i++) {
      value = decode83(blurHash, 4 + i * 2, 6 + i * 2);
      colors[i * 3] = signSqr(~~(value / 361) - 9) * maximumValue;
      colors[i * 3 + 1] = signSqr(~~(value / 19) % 19 - 9) * maximumValue;
      colors[i * 3 + 2] = signSqr(value % 19 - 9) * maximumValue;
    }
    const cosinesY = new Float64Array(numY * height);
    const cosinesX = new Float64Array(numX * width);
    for (j = 0; j < numY; j++) {
      for (y = 0; y < height; y++) {
        cosinesY[j * height + y] = fastCos(PI * y * j / height);
      }
    }
    for (i = 0; i < numX; i++) {
      for (x = 0; x < width; x++) {
        cosinesX[i * width + x] = fastCos(PI * x * i / width);
      }
    }
    const bytesPerRow = width * 4;
    const pixels = new Uint8ClampedArray(bytesPerRow * height);
    for (y = 0; y < height; y++) {
      for (x = 0; x < width; x++) {
        r = g = b = 0;
        for (j = 0; j < numY; j++) {
          basisY = cosinesY[j * height + y];
          for (i = 0; i < numX; i++) {
            basis = cosinesX[i * width + x] * basisY;
            colorIndex = (i + j * numX) * 3;
            r += colors[colorIndex] * basis;
            g += colors[colorIndex + 1] * basis;
            b += colors[colorIndex + 2] * basis;
          }
        }
        pixelIndex = 4 * x + y * bytesPerRow;
        pixels[pixelIndex] = linearTosRGB(r);
        pixels[pixelIndex + 1] = linearTosRGB(g);
        pixels[pixelIndex + 2] = linearTosRGB(b);
        pixels[pixelIndex + 3] = 255;
      }
    }
    return pixels;
  }
  const canDraw = (() => {
    try {
      const canvas = new OffscreenCanvas(1, 1);
      const ctx = canvas.getContext("2d");
      return {
        ctx,
        canvas
      };
    } catch {
    }
  })();
  const decode = async (blurHash, width, height) => {
    const pixels = decodeBlurHash(blurHash, width, height);
    const imageData = transfer(pixels, [pixels.buffer]);
    if (canDraw) {
      const { canvas, ctx } = canDraw;
      canvas.width = width;
      canvas.height = height;
      ctx.putImageData(new ImageData(imageData, width, height), 0, 0);
      const blob = await canvas.convertToBlob();
      return URL.createObjectURL(blob);
    }
    return imageData;
  };
  var ep = /* @__PURE__ */ Object.freeze({
    __proto__: null,
    decode
  });
  expose(ep, self);
})();
