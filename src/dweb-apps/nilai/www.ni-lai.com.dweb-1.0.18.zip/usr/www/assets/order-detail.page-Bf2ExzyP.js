import { d as definePage, R as React, P as Page, O as Navbar, B as Block } from "./index-DAk_nVWR.js";
const orderDetail_page = definePage((args) => /* @__PURE__ */ React.createElement(Page, { name: "orderDetail" }, /* @__PURE__ */ React.createElement(Navbar, { title: "Order Detail", backLink: true }), /* @__PURE__ */ React.createElement(Block, { strongIos: true, outlineIos: true }, "订单详情")));
export {
  orderDetail_page as default
};
