import{p}from"./sha256-juZ8Vuwh.js";const a=async()=>{await p.prepare()};export{a as p};
