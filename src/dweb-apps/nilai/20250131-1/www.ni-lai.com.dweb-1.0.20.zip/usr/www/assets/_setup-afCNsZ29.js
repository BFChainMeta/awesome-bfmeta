import{p}from"./sha256-ClyDc8BE.js";const a=async()=>{await p.prepare()};export{a as p};
