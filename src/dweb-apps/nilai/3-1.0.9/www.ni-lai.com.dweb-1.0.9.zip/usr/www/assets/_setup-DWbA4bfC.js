import{p}from"./sha256-DBoapY7B.js";const a=async()=>{await p.prepare()};export{a as p};
