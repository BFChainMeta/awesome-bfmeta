import{d as n,R as e,P as t,S as i}from"./index-D-8Z_XUF.js";const o=n(a=>e.createElement(t,{name:"login"},e.createElement(i,{title:"Login",backLink:a.backLink}),"Login Page"));export{o as default};
