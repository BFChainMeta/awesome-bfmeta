import{d as n,R as e,P as t,Q as i}from"./index-BfulfIme.js";const o=n(a=>e.createElement(t,{name:"login"},e.createElement(i,{title:"Login",backLink:a.backLink}),"Login Page"));export{o as default};
