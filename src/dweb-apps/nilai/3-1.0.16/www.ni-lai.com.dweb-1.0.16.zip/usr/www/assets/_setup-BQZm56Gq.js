import{p}from"./sha256-v6dRksGW.js";const a=async()=>{await p.prepare()};export{a as p};
