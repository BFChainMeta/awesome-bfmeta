import{p}from"./sha256-YCDpDUdV.js";const a=async()=>{await p.prepare()};export{a as p};
