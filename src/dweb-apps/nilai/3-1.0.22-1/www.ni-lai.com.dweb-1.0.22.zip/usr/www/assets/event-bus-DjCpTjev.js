import{ck as o}from"./index-IOpBx0nu.js";const s=o(),t=o();export{s as a,t as o};
