import{p}from"./sha256-_Cf2hiS5.js";const a=async()=>{await p.prepare()};export{a as p};
