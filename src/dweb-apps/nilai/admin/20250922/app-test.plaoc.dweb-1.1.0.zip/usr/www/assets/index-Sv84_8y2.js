import{R as e}from"./index-CPPG0a6z.js";const n=()=>e.createElement(e.Fragment,null,e.createElement("div",null,"Points"));export{n as default};
