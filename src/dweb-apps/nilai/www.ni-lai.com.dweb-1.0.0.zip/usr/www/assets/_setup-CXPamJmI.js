import{p}from"./sha256-CYIgBUnt.js";const a=async()=>{await p.prepare()};export{a as p};
