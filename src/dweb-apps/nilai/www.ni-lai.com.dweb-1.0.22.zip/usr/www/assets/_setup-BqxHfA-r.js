import{p}from"./sha256-DCXk1i3e.js";const a=async()=>{await p.prepare()};export{a as p};
