import{ck as o}from"./index-C-WyDWDN.js";const s=o(),t=o();export{s as a,t as o};
