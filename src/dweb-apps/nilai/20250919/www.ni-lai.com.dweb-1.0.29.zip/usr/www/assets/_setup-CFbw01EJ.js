import{p}from"./sha256-BbZsPn9o.js";const a=async()=>{await p.prepare()};export{a as p};
