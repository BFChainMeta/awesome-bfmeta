import{d as n,R as e,P as t,S as i}from"./index-ePxNM-ry.js";const o=n(a=>e.createElement(t,{name:"login"},e.createElement(i,{title:"Login",backLink:a.backLink}),"Login Page"));export{o as default};
