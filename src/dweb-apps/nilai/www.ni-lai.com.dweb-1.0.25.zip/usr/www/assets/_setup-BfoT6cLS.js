import{p}from"./sha256-Cxgi6AJ5.js";const a=async()=>{await p.prepare()};export{a as p};
