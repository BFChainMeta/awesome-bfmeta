import"./preloader-0pPPGO-D.js";import{q as e}from"./page-DoyRnDwy.js";import{R as o}from"./index-C3b-K6Ph.js";const s=r=>o.createElement(e,{size:24,...r});export{s as P};
