import{L as s}from"./list-BDuyxVdw.js";const o=s;export{o as L};
