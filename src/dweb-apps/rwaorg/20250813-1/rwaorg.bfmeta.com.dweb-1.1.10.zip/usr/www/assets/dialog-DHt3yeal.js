import{f as o,D as a}from"./index-C3b-K6Ph.js";const l=o.dialog;await o.loadModule(a);export{l as d};
