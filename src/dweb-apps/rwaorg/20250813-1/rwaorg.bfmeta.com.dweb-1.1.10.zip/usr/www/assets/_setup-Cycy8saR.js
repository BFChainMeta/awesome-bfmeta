import{p}from"./sha256-csbjz4SP.js";const a=async()=>{await p.prepare()};export{a as p};
