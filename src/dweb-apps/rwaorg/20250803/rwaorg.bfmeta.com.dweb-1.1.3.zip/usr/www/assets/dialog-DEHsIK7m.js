import{f as o,D as a}from"./index-D0pQ5vVs.js";const l=o.dialog;await o.loadModule(a);export{l as d};
