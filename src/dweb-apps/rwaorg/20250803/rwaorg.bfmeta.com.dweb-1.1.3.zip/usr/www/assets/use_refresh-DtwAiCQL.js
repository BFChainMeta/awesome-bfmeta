import{r as s}from"./index-D0pQ5vVs.js";const o=()=>{const[,e]=s.useReducer(r=>r+1,0);return e};export{o as u};
