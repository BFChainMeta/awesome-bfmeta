import"./preloader-Ce4FOtDg.js";import{q as e}from"./page-Boovgf78.js";import{R as o}from"./index-D0pQ5vVs.js";const s=r=>o.createElement(e,{size:24,...r});export{s as P};
