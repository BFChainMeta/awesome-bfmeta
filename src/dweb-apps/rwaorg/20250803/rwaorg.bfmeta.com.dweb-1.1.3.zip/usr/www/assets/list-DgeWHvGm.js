import{L as s}from"./list-DMTFq1VS.js";const o=s;export{o as L};
