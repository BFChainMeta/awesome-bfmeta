import{p}from"./sha256-CXFu6s6j.js";const a=async()=>{await p.prepare()};export{a as p};
