import{p}from"./sha256-BOzy03fQ.js";const a=async()=>{await p.prepare()};export{a as p};
