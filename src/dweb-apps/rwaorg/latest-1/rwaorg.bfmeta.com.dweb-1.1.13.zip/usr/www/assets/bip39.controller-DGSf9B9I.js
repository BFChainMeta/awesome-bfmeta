import{g as s,s as a}from"./index-CDQMwFp6.js";a({wasmBaseUrl:"./wallet-util/assets"});const t=async()=>{const{mnemonic:e}=await s(12,"english");return e};export{t as c};
