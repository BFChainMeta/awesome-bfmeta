import{C as t}from"./page-CM1erU2H.js";import"./index-D2PqiMUR.js";let s={};const F=e=>{s=e},l=(e,o)=>{const n={ETH:t.Ethereum,BSC:t.Binance,TRON:t.Tron,BFCHAINV2:t.BFChainV2,BFMCHAIN:t.BFMeta,CCCHAIN:t.CCChain,PMCHAIN:t.PMChain,ETHMETA:t.ETHMeta,BTGMETA:t.BTGMeta,BIWMETA:t.BIWMeta,MALIBU:t.Malibu};o in n&&(o=n[o]);const a=s[o];if(a)return a[e]},i={"BFMeta-BFM":"./images/token/BFMeta-BFM.png","BFMeta-DEXT":"./images/token/BFMeta-DEXT.png","BFMeta-DEX":"./images/token/BFMeta-DEX.png","BFMeta-DXD":"./images/token/BFMeta-DXD.png","BFMeta-CPCC":"./images/token/BFMeta-CPCC.png","BFMeta-MOC":"./images/token/BFMeta-MOC.png","BFMeta-MOT":"./images/token/BFMeta-MOT.png","BFMeta-MOW":"./images/token/BFMeta-MOW.png","BFMeta-CPCT":"./images/token/BFMeta-CPCT.png","BFMeta-USDT":"./images/token/BFMeta-USDT.webp","Binance-USDT":"./images/token/Binance-USDT.webp","Ethereum-USDT":"./images/token/Ethereum-USDT.webp","Tron-USDT":"./images/token/Tron-USDT.webp"},h=(e,o,n)=>{if(i[`${o}-${e}`])return i[`${o}-${e}`];const a=l(e,o);return a||n||C(e)},T=e=>`./images/icon_${e}.webp`,C=e=>{const o=e.charAt(0);let n=0;for(let r=0;r<e.length;r++)n=e.charCodeAt(r)+((n<<5)-n);const a=`hsl(${Math.abs(n)%360}, 70%, 45%)`,g=`hsl(${(Math.abs(n)+120)%360}, 70%, 30%)`,M=`
                <svg xmlns="http://www.w3.org/2000/svg" width="200" height="200" viewBox="0 0 200 200">
                    <defs>
                        <linearGradient id="gradient" x1="0%" y1="0%" x2="100%" y2="100%">
                            <stop offset="0%" stop-color="${a}" />
                            <stop offset="100%" stop-color="${g}" />
                        </linearGradient>
                    </defs>
                    <rect width="200" height="200" fill="url(#gradient)" rx="15" />
                    <text 
                        x="100" 
                        y="115" 
                        font-family="Arial, sans-serif" 
                        font-size="80" 
                        font-weight="bold" 
                        fill="white" 
                        text-anchor="middle"
                        dominant-baseline="middle"
                        stroke="rgba(0,0,0,0.2)"
                        stroke-width="2"
                    >
                        ${o}
                    </text>
                </svg>
            `,B=new Blob([M],{type:"image/svg+xml;charset=utf-8"});return URL.createObjectURL(B)};export{T as a,h as g,F as s};
