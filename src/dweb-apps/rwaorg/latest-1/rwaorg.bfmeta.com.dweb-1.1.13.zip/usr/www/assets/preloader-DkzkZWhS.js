import"./preloader-DgVC8Plo.js";import{k as e}from"./page-CM1erU2H.js";import{R as o}from"./index-D2PqiMUR.js";const s=r=>o.createElement(e,{size:24,...r});export{s as P};
