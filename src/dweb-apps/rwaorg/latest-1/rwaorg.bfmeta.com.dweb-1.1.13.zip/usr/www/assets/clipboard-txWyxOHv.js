import{i}from"./core-BcHAVgP8.js";import"./page-CM1erU2H.js";const a=async t=>{await i.write({string:t})},o=async t=>{await a(t)};export{o as w};
