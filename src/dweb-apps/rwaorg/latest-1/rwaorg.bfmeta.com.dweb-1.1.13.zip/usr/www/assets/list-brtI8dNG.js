import{L as s}from"./list-ClJJHXLK.js";const o=s;export{o as L};
