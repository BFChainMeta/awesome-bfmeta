import"./preloader-YA8U_v6j.js";import{q as e}from"./page-CtRXI6fq.js";import{R as o}from"./index-DydK_UIF.js";const s=r=>o.createElement(e,{size:24,...r});export{s as P};
