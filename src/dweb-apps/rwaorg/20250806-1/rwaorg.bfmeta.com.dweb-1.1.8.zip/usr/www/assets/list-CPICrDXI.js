import{L as s}from"./list-dMe0Ftvw.js";const o=s;export{o as L};
