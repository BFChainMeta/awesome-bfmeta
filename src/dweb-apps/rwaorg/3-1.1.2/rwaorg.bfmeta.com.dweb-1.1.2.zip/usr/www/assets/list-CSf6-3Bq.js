import{L as s}from"./list-PZvFRFGA.js";const o=s;export{o as L};
