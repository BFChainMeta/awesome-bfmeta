import{p}from"./sha256-CX886aoO.js";const a=async()=>{await p.prepare()};export{a as p};
