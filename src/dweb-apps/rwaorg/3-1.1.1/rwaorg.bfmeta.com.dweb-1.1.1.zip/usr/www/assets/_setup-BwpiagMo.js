import{p}from"./sha256-VLNVY1M7.js";const a=async()=>{await p.prepare()};export{a as p};
