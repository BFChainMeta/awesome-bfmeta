import"./preloader-CqVU9KG3.js";import{q as e}from"./page-DrAg9-I1.js";import{R as o}from"./index-KUzCajBD.js";const s=r=>o.createElement(e,{size:24,...r});export{s as P};
