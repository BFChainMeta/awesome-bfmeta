import{L as s}from"./list-Cr43D28N.js";const o=s;export{o as L};
