import{p}from"./sha256-DU7eM-lk.js";const a=async()=>{await p.prepare()};export{a as p};
