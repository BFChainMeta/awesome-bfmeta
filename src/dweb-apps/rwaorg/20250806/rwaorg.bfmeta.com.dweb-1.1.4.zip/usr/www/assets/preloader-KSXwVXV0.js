import"./preloader-BCCEPltp.js";import{q as e}from"./page-D2HzrV2X.js";import{R as o}from"./index-DVqhwvTb.js";const s=r=>o.createElement(e,{size:24,...r});export{s as P};
