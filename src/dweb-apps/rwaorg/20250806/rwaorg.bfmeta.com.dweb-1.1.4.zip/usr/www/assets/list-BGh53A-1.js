import{L as s}from"./list-Q5LeFefY.js";const o=s;export{o as L};
