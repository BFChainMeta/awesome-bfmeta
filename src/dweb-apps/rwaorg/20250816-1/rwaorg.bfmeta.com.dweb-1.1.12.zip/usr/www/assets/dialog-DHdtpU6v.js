import{f as o,D as a}from"./index-Df8T3yo8.js";const l=o.dialog;await o.loadModule(a);export{l as d};
