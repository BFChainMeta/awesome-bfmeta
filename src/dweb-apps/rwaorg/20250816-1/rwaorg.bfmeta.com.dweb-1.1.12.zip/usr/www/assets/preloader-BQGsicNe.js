import"./preloader-B1VIFp6C.js";import{q as e}from"./page-_7kjXfiI.js";import{R as o}from"./index-Df8T3yo8.js";const s=r=>o.createElement(e,{size:24,...r});export{s as P};
