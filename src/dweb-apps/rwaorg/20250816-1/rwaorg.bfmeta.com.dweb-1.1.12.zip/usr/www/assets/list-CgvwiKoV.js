import{L as s}from"./list-BIhAnE3T.js";const o=s;export{o as L};
