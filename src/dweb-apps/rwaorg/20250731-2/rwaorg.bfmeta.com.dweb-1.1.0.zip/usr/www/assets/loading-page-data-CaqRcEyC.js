import{C as t,q as m}from"./page-CxllmBlI.js";import{R as s}from"./index-CWaQAxGr.js";import"./preloader-CaZQ3zSo.js";let l={};const w=e=>{l=e},C=(e,o)=>{const n={ETH:t.Ethereum,BSC:t.Binance,TRON:t.Tron,BFCHAINV2:t.BFChainV2,BFMCHAIN:t.BFMeta,CCCHAIN:t.CCChain,PMCHAIN:t.PMChain,ETHMETA:t.ETHMeta,BTGMETA:t.BTGMeta,BIWMETA:t.BIWMeta,MALIBU:t.Malibu};o in n&&(o=n[o]);const r=l[o];if(r)return r[e]},i={"BFMeta-BFM":"./images/token/BFMeta-BFM.png","BFMeta-DEXT":"./images/token/BFMeta-DEXT.png","BFMeta-CPCC":"./images/token/BFMeta-CPCC.png","BFMeta-CPCT":"./images/token/BFMeta-CPCT.png","BFMeta-USDT":"./images/token/BFMeta-USDT.webp","Binance-USDT":"./images/token/Binance-USDT.webp","Ethereum-USDT":"./images/token/Ethereum-USDT.webp","Tron-USDT":"./images/token/Tron-USDT.webp"},F=(e,o,n)=>{if(i[`${o}-${e}`])return i[`${o}-${e}`];const r=C(e,o);return r||n||B(e)},p=e=>`./images/icon_${e}.webp`,B=e=>{const o=e.charAt(0);let n=0;for(let a=0;a<e.length;a++)n=e.charCodeAt(a)+((n<<5)-n);const r=`hsl(${Math.abs(n)%360}, 70%, 45%)`,g=`hsl(${(Math.abs(n)+120)%360}, 70%, 30%)`,c=`
                <svg xmlns="http://www.w3.org/2000/svg" width="200" height="200" viewBox="0 0 200 200">
                    <defs>
                        <linearGradient id="gradient" x1="0%" y1="0%" x2="100%" y2="100%">
                            <stop offset="0%" stop-color="${r}" />
                            <stop offset="100%" stop-color="${g}" />
                        </linearGradient>
                    </defs>
                    <rect width="200" height="200" fill="url(#gradient)" rx="15" />
                    <text 
                        x="100" 
                        y="115" 
                        font-family="Arial, sans-serif" 
                        font-size="80" 
                        font-weight="bold" 
                        fill="white" 
                        text-anchor="middle"
                        dominant-baseline="middle"
                        stroke="rgba(0,0,0,0.2)"
                        stroke-width="2"
                    >
                        ${o}
                    </text>
                </svg>
            `,f=new Blob([c],{type:"image/svg+xml;charset=utf-8"});return URL.createObjectURL(f)},M=e=>s.createElement(m,{size:24,...e}),E=e=>s.createElement("div",{className:"flex h-32 w-full items-center justify-center"},s.createElement(M,{size:32,...e}));export{E as L,M as P,p as a,F as g,w as s};
