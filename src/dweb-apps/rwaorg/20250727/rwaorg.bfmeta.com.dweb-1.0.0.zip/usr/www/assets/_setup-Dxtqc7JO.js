import{p}from"./sha256-BmWgELwu.js";const a=async()=>{await p.prepare()};export{a as p};
