import{f as o,D as a}from"./index-CVfx_374.js";const l=o.dialog;await o.loadModule(a);export{l as d};
