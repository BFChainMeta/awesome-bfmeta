const l=globalThis||void 0||self;export{l as g};
