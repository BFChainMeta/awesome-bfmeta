import{p}from"./sha256-DTlUjnvz.js";const a=async()=>{await p.prepare()};export{a as p};
