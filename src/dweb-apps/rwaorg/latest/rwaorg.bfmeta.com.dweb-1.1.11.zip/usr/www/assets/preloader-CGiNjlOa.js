import"./preloader-CFURfcvg.js";import{q as e}from"./page-BzYO5ZfW.js";import{R as o}from"./index-CpObIVT8.js";const s=r=>o.createElement(e,{size:24,...r});export{s as P};
