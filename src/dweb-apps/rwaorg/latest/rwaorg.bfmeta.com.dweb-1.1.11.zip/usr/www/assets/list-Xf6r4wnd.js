import{L as s}from"./list-CRAfh891.js";const o=s;export{o as L};
