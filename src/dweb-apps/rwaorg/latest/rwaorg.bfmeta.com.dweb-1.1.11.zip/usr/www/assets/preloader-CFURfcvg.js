import{$ as o,h as p,M as i,N as t,f as n}from"./index-CpObIVT8.js";const l={init(e){const r=this,a={iosPreloaderContent:t,mdPreloaderContent:i},d=o(e);d.length===0||d.children(".preloader-inner").length>0||d.children(".preloader-inner-line").length>0||d.append(a[`${r.theme}PreloaderContent`])},visible:!1,show(e){e===void 0&&(e="white");const r=this;if(l.visible)return;const d={iosPreloaderContent:t,mdPreloaderContent:i}[`${r.theme}PreloaderContent`]||"";o("html").addClass("with-modal-preloader"),r.$el.append(`
      <div class="preloader-backdrop"></div>
      <div class="preloader-modal">
        <div class="preloader color-${e}">${d}</div>
      </div>
    `),l.visible=!0},showIn(e,r){r===void 0&&(r="white");const a=this,s={iosPreloaderContent:t,mdPreloaderContent:i}[`${a.theme}PreloaderContent`]||"";o(e||"html").addClass("with-modal-preloader"),o(e||a.$el).append(`
      <div class="preloader-backdrop"></div>
      <div class="preloader-modal">
        <div class="preloader color-${r}">${s}</div>
      </div>
    `)},hide(){const e=this;l.visible&&(o("html").removeClass("with-modal-preloader"),e.$el.find(".preloader-backdrop, .preloader-modal").remove(),l.visible=!1)},hideIn(e){const r=this;o(e||"html").removeClass("with-modal-preloader"),o(e||r.$el).find(".preloader-backdrop, .preloader-modal").remove()}},h={name:"preloader",create(){p(this,{preloader:l})},on:{photoBrowserOpen(e){const r=this;e.$el.find(".preloader").each(a=>{r.preloader.init(a)})},tabMounted(e){const r=this;o(e).find(".preloader").each(a=>{r.preloader.init(a)})},pageInit(e){const r=this;e.$el.find(".preloader").each(a=>{r.preloader.init(a)})}},vnode:{preloader:{insert(e){const r=this,a=e.elm;r.preloader.init(a)}}}};await n.loadModule(h);
