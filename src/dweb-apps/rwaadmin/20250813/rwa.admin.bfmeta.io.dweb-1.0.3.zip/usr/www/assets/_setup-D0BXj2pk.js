import{p}from"./sha256-CE380LzT.js";const a=async()=>{await p.prepare()};export{a as p};
