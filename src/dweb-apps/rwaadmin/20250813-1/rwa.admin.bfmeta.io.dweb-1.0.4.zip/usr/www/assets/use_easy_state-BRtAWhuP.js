import{r as e,s as a}from"./index-DNEDAKPz.js";const o=a([],{get value(){return this[0]},set value(t){this[1](t)}}),p=t=>{const s=e.useState(t);return Object.setPrototypeOf(s,o),s};export{p as u};
