import{p}from"./sha256-B2HC8aWi.js";const a=async()=>{await p.prepare()};export{a as p};
