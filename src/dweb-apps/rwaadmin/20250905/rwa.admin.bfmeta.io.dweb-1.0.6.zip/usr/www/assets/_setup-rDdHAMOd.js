import{p}from"./sha256-7RGKPDBj.js";const a=async()=>{await p.prepare()};export{a as p};
