import"./index-CDnRftDM.js";import{C as o}from"./types-BPGt8Mdc.js";let a={};const d=t=>{a=t},c=(t,e)=>{const n={ETH:o.Ethereum,BSC:o.Binance,TRON:o.Tron,BFCHAINV2:o.BFChainV2,BFMCHAIN:o.BFMeta,CCCHAIN:o.CCChain,PMCHAIN:o.PMChain,ETHMETA:o.ETHMeta,BTGMETA:o.BTGMeta,BIWMETA:o.BIWMeta,MALIBU:o.Malibu};e in n&&(e=n[e]);const r=a[e];if(r)return r[t]},i={"BFMeta-BFM":"./images/token/BFMeta-BFM.png","BFMeta-DEXT":"./images/token/BFMeta-DEXT.png","BFMeta-CPCC":"./images/token/BFMeta-CPCC.png"},m=(t,e,n)=>{if(i[`${e}-${t}`])return i[`${e}-${t}`];const r=c(t,e);return r||n||C(t)},u=t=>`./images/icon_${t}.webp`,C=t=>{const e=t.charAt(0);let n=0;for(let s=0;s<t.length;s++)n=t.charCodeAt(s)+((n<<5)-n);const r=`hsl(${Math.abs(n)%360}, 70%, 45%)`,l=`hsl(${(Math.abs(n)+120)%360}, 70%, 30%)`,g=`
                <svg xmlns="http://www.w3.org/2000/svg" width="200" height="200" viewBox="0 0 200 200">
                    <defs>
                        <linearGradient id="gradient" x1="0%" y1="0%" x2="100%" y2="100%">
                            <stop offset="0%" stop-color="${r}" />
                            <stop offset="100%" stop-color="${l}" />
                        </linearGradient>
                    </defs>
                    <rect width="200" height="200" fill="url(#gradient)" rx="15" />
                    <text 
                        x="100" 
                        y="115" 
                        font-family="Arial, sans-serif" 
                        font-size="80" 
                        font-weight="bold" 
                        fill="white" 
                        text-anchor="middle"
                        dominant-baseline="middle"
                        stroke="rgba(0,0,0,0.2)"
                        stroke-width="2"
                    >
                        ${e}
                    </text>
                </svg>
            `,f=new Blob([g],{type:"image/svg+xml;charset=utf-8"});return URL.createObjectURL(f)};export{u as a,m as g,d as s};
