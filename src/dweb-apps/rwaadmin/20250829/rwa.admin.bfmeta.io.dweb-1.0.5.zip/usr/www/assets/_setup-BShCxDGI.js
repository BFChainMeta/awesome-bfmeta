import{p}from"./sha256-CyKv4qSB.js";const a=async()=>{await p.prepare()};export{a as p};
