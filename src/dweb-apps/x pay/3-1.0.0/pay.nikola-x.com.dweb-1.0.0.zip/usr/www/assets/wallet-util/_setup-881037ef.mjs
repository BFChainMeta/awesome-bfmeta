import{p as a}from"./sha256-2286a103.mjs";const p=async()=>{await a.prepare()};export{p};
