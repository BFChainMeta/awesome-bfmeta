import{p as a}from"./sha256-d88873b6.mjs";const p=async()=>{await a.prepare()};export{p};
