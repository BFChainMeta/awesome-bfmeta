import{p as a}from"./sha256-e58017d9.mjs";const p=async()=>{await a.prepare()};export{p};
