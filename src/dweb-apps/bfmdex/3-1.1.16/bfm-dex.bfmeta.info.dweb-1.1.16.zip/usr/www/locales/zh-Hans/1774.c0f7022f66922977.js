(self.webpackChunkmalibu_dex = self.webpackChunkmalibu_dex || []).push([
  [1774],
  {
    5359: (u, m, r) => {
      var _ = r(4303)(r(94985), "DataView");
      u.exports = _;
    },
    37326: (u, m, r) => {
      var c = r(31964),
        s = r(50981),
        _ = r(68776),
        e = r(31371),
        h = r(1900);
      function f(S) {
        var b = -1,
          P = null == S ? 0 : S.length;
        for (this.clear(); ++b < P; ) {
          var M = S[b];
          this.set(M[0], M[1]);
        }
      }
      ((f.prototype.clear = c),
        (f.prototype.delete = s),
        (f.prototype.get = _),
        (f.prototype.has = e),
        (f.prototype.set = h),
        (u.exports = f));
    },
    91699: (u, m, r) => {
      var c = r(97012),
        s = r(77168),
        _ = r(38946),
        e = r(89646),
        h = r(62133);
      function f(S) {
        var b = -1,
          P = null == S ? 0 : S.length;
        for (this.clear(); ++b < P; ) {
          var M = S[b];
          this.set(M[0], M[1]);
        }
      }
      ((f.prototype.clear = c),
        (f.prototype.delete = s),
        (f.prototype.get = _),
        (f.prototype.has = e),
        (f.prototype.set = h),
        (u.exports = f));
    },
    52583: (u, m, r) => {
      var _ = r(4303)(r(94985), "Map");
      u.exports = _;
    },
    23027: (u, m, r) => {
      var c = r(50837),
        s = r(38566),
        _ = r(84387),
        e = r(77451),
        h = r(94716);
      function f(S) {
        var b = -1,
          P = null == S ? 0 : S.length;
        for (this.clear(); ++b < P; ) {
          var M = S[b];
          this.set(M[0], M[1]);
        }
      }
      ((f.prototype.clear = c),
        (f.prototype.delete = s),
        (f.prototype.get = _),
        (f.prototype.has = e),
        (f.prototype.set = h),
        (u.exports = f));
    },
    10509: (u, m, r) => {
      var _ = r(4303)(r(94985), "Promise");
      u.exports = _;
    },
    80429: (u, m, r) => {
      var _ = r(4303)(r(94985), "Set");
      u.exports = _;
    },
    89288: (u, m, r) => {
      var c = r(91699),
        s = r(40553),
        _ = r(41608),
        e = r(25678),
        h = r(87716),
        f = r(6734);
      function S(b) {
        var P = (this.__data__ = new c(b));
        this.size = P.size;
      }
      ((S.prototype.clear = s),
        (S.prototype.delete = _),
        (S.prototype.get = e),
        (S.prototype.has = h),
        (S.prototype.set = f),
        (u.exports = S));
    },
    98466: (u, m, r) => {
      var c = r(94985);
      u.exports = c.Symbol;
    },
    63427: (u, m, r) => {
      var c = r(94985);
      u.exports = c.Uint8Array;
    },
    37137: (u, m, r) => {
      var _ = r(4303)(r(94985), "WeakMap");
      u.exports = _;
    },
    77958: (u) => {
      u.exports = function m(r, c) {
        for (var s = -1, _ = null == r ? 0 : r.length; ++s < _ && !1 !== c(r[s], s, r); );
        return r;
      };
    },
    93233: (u) => {
      u.exports = function m(r, c) {
        for (var s = -1, _ = null == r ? 0 : r.length, e = 0, h = []; ++s < _; ) {
          var f = r[s];
          c(f, s, r) && (h[e++] = f);
        }
        return h;
      };
    },
    9461: (u, m, r) => {
      var c = r(62059),
        s = r(39240),
        _ = r(27524),
        e = r(90237),
        h = r(30308),
        f = r(15527),
        b = Object.prototype.hasOwnProperty;
      u.exports = function P(M, O) {
        var x = _(M),
          H = !x && s(M),
          oe = !x && !H && e(M),
          K = !x && !H && !oe && f(M),
          se = x || H || oe || K,
          de = se ? c(M.length, String) : [],
          $ = de.length;
        for (var R in M)
          (O || b.call(M, R)) &&
            (!se ||
              !(
                "length" == R ||
                (oe && ("offset" == R || "parent" == R)) ||
                (K && ("buffer" == R || "byteLength" == R || "byteOffset" == R)) ||
                h(R, $)
              )) &&
            de.push(R);
        return de;
      };
    },
    79908: (u) => {
      u.exports = function m(r, c) {
        for (var s = -1, _ = c.length, e = r.length; ++s < _; ) r[e + s] = c[s];
        return r;
      };
    },
    77280: (u, m, r) => {
      var c = r(72350),
        s = r(93011),
        e = Object.prototype.hasOwnProperty;
      u.exports = function h(f, S, b) {
        var P = f[S];
        (!e.call(f, S) || !s(P, b) || (void 0 === b && !(S in f))) && c(f, S, b);
      };
    },
    1207: (u, m, r) => {
      var c = r(93011);
      u.exports = function s(_, e) {
        for (var h = _.length; h--; ) if (c(_[h][0], e)) return h;
        return -1;
      };
    },
    1064: (u, m, r) => {
      var c = r(62669),
        s = r(25626);
      u.exports = function _(e, h) {
        return e && c(h, s(h), e);
      };
    },
    33545: (u, m, r) => {
      var c = r(62669),
        s = r(11500);
      u.exports = function _(e, h) {
        return e && c(h, s(h), e);
      };
    },
    72350: (u, m, r) => {
      var c = r(85599);
      u.exports = function s(_, e, h) {
        "__proto__" == e && c
          ? c(_, e, {
              configurable: !0,
              enumerable: !0,
              value: h,
              writable: !0,
            })
          : (_[e] = h);
      };
    },
    97247: (u, m, r) => {
      var c = r(89288),
        s = r(77958),
        _ = r(77280),
        e = r(1064),
        h = r(33545),
        f = r(40134),
        S = r(83520),
        b = r(34831),
        P = r(43354),
        M = r(39083),
        O = r(73438),
        x = r(57164),
        H = r(79672),
        oe = r(72604),
        K = r(85007),
        se = r(27524),
        de = r(90237),
        $ = r(79015),
        R = r(69071),
        pe = r(47542),
        W = r(25626),
        ce = r(11500),
        ae = "[object Arguments]",
        j = "[object Function]",
        et = "[object Object]",
        U = {};
      ((U[ae] =
        U["[object Array]"] =
        U["[object ArrayBuffer]"] =
        U["[object DataView]"] =
        U["[object Boolean]"] =
        U["[object Date]"] =
        U["[object Float32Array]"] =
        U["[object Float64Array]"] =
        U["[object Int8Array]"] =
        U["[object Int16Array]"] =
        U["[object Int32Array]"] =
        U["[object Map]"] =
        U["[object Number]"] =
        U[et] =
        U["[object RegExp]"] =
        U["[object Set]"] =
        U["[object String]"] =
        U["[object Symbol]"] =
        U["[object Uint8Array]"] =
        U["[object Uint8ClampedArray]"] =
        U["[object Uint16Array]"] =
        U["[object Uint32Array]"] =
          !0),
        (U["[object Error]"] = U[j] = U["[object WeakMap]"] = !1),
        (u.exports = function $e(L, be, Ae, xe, We, ge) {
          var te,
            je = 1 & be,
            Ve = 2 & be,
            Dt = 4 & be;
          if ((Ae && (te = We ? Ae(L, xe, We, ge) : Ae(L)), void 0 !== te)) return te;
          if (!R(L)) return L;
          var ot = se(L);
          if (ot) {
            if (((te = H(L)), !je)) return S(L, te);
          } else {
            var Pe = x(L),
              st = Pe == j || "[object GeneratorFunction]" == Pe;
            if (de(L)) return f(L, je);
            if (Pe == et || Pe == ae || (st && !We)) {
              if (((te = Ve || st ? {} : K(L)), !je)) return Ve ? P(L, h(te, L)) : b(L, e(te, L));
            } else {
              if (!U[Pe]) return We ? L : {};
              te = oe(L, Pe, je);
            }
          }
          ge || (ge = new c());
          var at = ge.get(L);
          if (at) return at;
          (ge.set(L, te),
            pe(L)
              ? L.forEach(function (fe) {
                  te.add($e(fe, be, Ae, fe, L, ge));
                })
              : $(L) &&
                L.forEach(function (fe, Ce) {
                  te.set(Ce, $e(fe, be, Ae, Ce, L, ge));
                }));
          var rt = ot ? void 0 : (Dt ? (Ve ? O : M) : Ve ? ce : W)(L);
          return (
            s(rt || L, function (fe, Ce) {
              (rt && (fe = L[(Ce = fe)]), _(te, Ce, $e(fe, be, Ae, Ce, L, ge)));
            }),
            te
          );
        }));
    },
    59033: (u, m, r) => {
      var c = r(69071),
        s = Object.create,
        _ = (function () {
          function e() {}
          return function (h) {
            if (!c(h)) return {};
            if (s) return s(h);
            e.prototype = h;
            var f = new e();
            return ((e.prototype = void 0), f);
          };
        })();
      u.exports = _;
    },
    56929: (u, m, r) => {
      var c = r(79908),
        s = r(27524);
      u.exports = function _(e, h, f) {
        var S = h(e);
        return s(e) ? S : c(S, f(e));
      };
    },
    93759: (u, m, r) => {
      var c = r(98466),
        s = r(76096),
        _ = r(21627),
        f = c ? c.toStringTag : void 0;
      u.exports = function S(b) {
        return null == b ? (void 0 === b ? "[object Undefined]" : "[object Null]") : f && f in Object(b) ? s(b) : _(b);
      };
    },
    70842: (u, m, r) => {
      var c = r(93759),
        s = r(84010);
      u.exports = function e(h) {
        return s(h) && "[object Arguments]" == c(h);
      };
    },
    48428: (u, m, r) => {
      var c = r(57164),
        s = r(84010);
      u.exports = function e(h) {
        return s(h) && "[object Map]" == c(h);
      };
    },
    78979: (u, m, r) => {
      var c = r(61309),
        s = r(62522),
        _ = r(69071),
        e = r(61786),
        f = /^\[object .+?Constructor\]$/,
        O = RegExp(
          "^" +
            Function.prototype.toString
              .call(Object.prototype.hasOwnProperty)
              .replace(/[\\^$.*+?()[\]{}|]/g, "\\$&")
              .replace(/hasOwnProperty|(function).*?(?=\\\()| for .+?(?=\\\])/g, "$1.*?") +
            "$",
        );
      u.exports = function x(H) {
        return !(!_(H) || s(H)) && (c(H) ? O : f).test(e(H));
      };
    },
    22197: (u, m, r) => {
      var c = r(57164),
        s = r(84010);
      u.exports = function e(h) {
        return s(h) && "[object Set]" == c(h);
      };
    },
    96349: (u, m, r) => {
      var c = r(93759),
        s = r(62322),
        _ = r(84010),
        D = {};
      ((D["[object Float32Array]"] =
        D["[object Float64Array]"] =
        D["[object Int8Array]"] =
        D["[object Int16Array]"] =
        D["[object Int32Array]"] =
        D["[object Uint8Array]"] =
        D["[object Uint8ClampedArray]"] =
        D["[object Uint16Array]"] =
        D["[object Uint32Array]"] =
          !0),
        (D["[object Arguments]"] =
          D["[object Array]"] =
          D["[object ArrayBuffer]"] =
          D["[object Boolean]"] =
          D["[object DataView]"] =
          D["[object Date]"] =
          D["[object Error]"] =
          D["[object Function]"] =
          D["[object Map]"] =
          D["[object Number]"] =
          D["[object Object]"] =
          D["[object RegExp]"] =
          D["[object Set]"] =
          D["[object String]"] =
          D["[object WeakMap]"] =
            !1),
        (u.exports = function me(Le) {
          return _(Le) && s(Le.length) && !!D[c(Le)];
        }));
    },
    70915: (u, m, r) => {
      var c = r(68722),
        s = r(67601),
        e = Object.prototype.hasOwnProperty;
      u.exports = function h(f) {
        if (!c(f)) return s(f);
        var S = [];
        for (var b in Object(f)) e.call(f, b) && "constructor" != b && S.push(b);
        return S;
      };
    },
    327: (u, m, r) => {
      var c = r(69071),
        s = r(68722),
        _ = r(51928),
        h = Object.prototype.hasOwnProperty;
      u.exports = function f(S) {
        if (!c(S)) return _(S);
        var b = s(S),
          P = [];
        for (var M in S) ("constructor" == M && (b || !h.call(S, M))) || P.push(M);
        return P;
      };
    },
    62059: (u) => {
      u.exports = function m(r, c) {
        for (var s = -1, _ = Array(r); ++s < r; ) _[s] = c(s);
        return _;
      };
    },
    95332: (u) => {
      u.exports = function m(r) {
        return function (c) {
          return r(c);
        };
      };
    },
    88100: (u, m, r) => {
      var c = r(63427);
      u.exports = function s(_) {
        var e = new _.constructor(_.byteLength);
        return (new c(e).set(new c(_)), e);
      };
    },
    40134: (u, m, r) => {
      u = r.nmd(u);
      var c = r(94985),
        s = m && !m.nodeType && m,
        _ = s && u && !u.nodeType && u,
        h = _ && _.exports === s ? c.Buffer : void 0,
        f = h ? h.allocUnsafe : void 0;
      u.exports = function S(b, P) {
        if (P) return b.slice();
        var M = b.length,
          O = f ? f(M) : new b.constructor(M);
        return (b.copy(O), O);
      };
    },
    48691: (u, m, r) => {
      var c = r(88100);
      u.exports = function s(_, e) {
        var h = e ? c(_.buffer) : _.buffer;
        return new _.constructor(h, _.byteOffset, _.byteLength);
      };
    },
    3352: (u) => {
      var m = /\w*$/;
      u.exports = function r(c) {
        var s = new c.constructor(c.source, m.exec(c));
        return ((s.lastIndex = c.lastIndex), s);
      };
    },
    21883: (u, m, r) => {
      var c = r(98466),
        s = c ? c.prototype : void 0,
        _ = s ? s.valueOf : void 0;
      u.exports = function e(h) {
        return _ ? Object(_.call(h)) : {};
      };
    },
    57388: (u, m, r) => {
      var c = r(88100);
      u.exports = function s(_, e) {
        var h = e ? c(_.buffer) : _.buffer;
        return new _.constructor(h, _.byteOffset, _.length);
      };
    },
    83520: (u) => {
      u.exports = function m(r, c) {
        var s = -1,
          _ = r.length;
        for (c || (c = Array(_)); ++s < _; ) c[s] = r[s];
        return c;
      };
    },
    62669: (u, m, r) => {
      var c = r(77280),
        s = r(72350);
      u.exports = function _(e, h, f, S) {
        var b = !f;
        f || (f = {});
        for (var P = -1, M = h.length; ++P < M; ) {
          var O = h[P],
            x = S ? S(f[O], e[O], O, f, e) : void 0;
          (void 0 === x && (x = e[O]), b ? s(f, O, x) : c(f, O, x));
        }
        return f;
      };
    },
    34831: (u, m, r) => {
      var c = r(62669),
        s = r(30438);
      u.exports = function _(e, h) {
        return c(e, s(e), h);
      };
    },
    43354: (u, m, r) => {
      var c = r(62669),
        s = r(38267);
      u.exports = function _(e, h) {
        return c(e, s(e), h);
      };
    },
    42909: (u, m, r) => {
      var c = r(94985);
      u.exports = c["__core-js_shared__"];
    },
    85599: (u, m, r) => {
      var c = r(4303),
        s = (function () {
          try {
            var _ = c(Object, "defineProperty");
            return (_({}, "", {}), _);
          } catch {}
        })();
      u.exports = s;
    },
    42293: (u) => {
      var m = "object" == typeof global && global && global.Object === Object && global;
      u.exports = m;
    },
    39083: (u, m, r) => {
      var c = r(56929),
        s = r(30438),
        _ = r(25626);
      u.exports = function e(h) {
        return c(h, _, s);
      };
    },
    73438: (u, m, r) => {
      var c = r(56929),
        s = r(38267),
        _ = r(11500);
      u.exports = function e(h) {
        return c(h, _, s);
      };
    },
    12343: (u, m, r) => {
      var c = r(68215);
      u.exports = function s(_, e) {
        var h = _.__data__;
        return c(e) ? h["string" == typeof e ? "string" : "hash"] : h.map;
      };
    },
    4303: (u, m, r) => {
      var c = r(78979),
        s = r(38473);
      u.exports = function _(e, h) {
        var f = s(e, h);
        return c(f) ? f : void 0;
      };
    },
    37298: (u, m, r) => {
      var s = r(4652)(Object.getPrototypeOf, Object);
      u.exports = s;
    },
    76096: (u, m, r) => {
      var c = r(98466),
        s = Object.prototype,
        _ = s.hasOwnProperty,
        e = s.toString,
        h = c ? c.toStringTag : void 0;
      u.exports = function f(S) {
        var b = _.call(S, h),
          P = S[h];
        try {
          S[h] = void 0;
          var M = !0;
        } catch {}
        var O = e.call(S);
        return (M && (b ? (S[h] = P) : delete S[h]), O);
      };
    },
    30438: (u, m, r) => {
      var c = r(93233),
        s = r(78226),
        e = Object.prototype.propertyIsEnumerable,
        h = Object.getOwnPropertySymbols;
      u.exports = h
        ? function (S) {
            return null == S
              ? []
              : ((S = Object(S)),
                c(h(S), function (b) {
                  return e.call(S, b);
                }));
          }
        : s;
    },
    38267: (u, m, r) => {
      var c = r(79908),
        s = r(37298),
        _ = r(30438),
        e = r(78226);
      u.exports = Object.getOwnPropertySymbols
        ? function (S) {
            for (var b = []; S; ) (c(b, _(S)), (S = s(S)));
            return b;
          }
        : e;
    },
    57164: (u, m, r) => {
      var c = r(5359),
        s = r(52583),
        _ = r(10509),
        e = r(80429),
        h = r(37137),
        f = r(93759),
        S = r(61786),
        b = "[object Map]",
        M = "[object Promise]",
        O = "[object Set]",
        x = "[object WeakMap]",
        H = "[object DataView]",
        oe = S(c),
        K = S(s),
        se = S(_),
        de = S(e),
        $ = S(h),
        R = f;
      (((c && R(new c(new ArrayBuffer(1))) != H) ||
        (s && R(new s()) != b) ||
        (_ && R(_.resolve()) != M) ||
        (e && R(new e()) != O) ||
        (h && R(new h()) != x)) &&
        (R = function (pe) {
          var W = f(pe),
            ce = "[object Object]" == W ? pe.constructor : void 0,
            ee = ce ? S(ce) : "";
          if (ee)
            switch (ee) {
              case oe:
                return H;
              case K:
                return b;
              case se:
                return M;
              case de:
                return O;
              case $:
                return x;
            }
          return W;
        }),
        (u.exports = R));
    },
    38473: (u) => {
      u.exports = function m(r, c) {
        return null == r ? void 0 : r[c];
      };
    },
    31964: (u, m, r) => {
      var c = r(15572);
      u.exports = function s() {
        ((this.__data__ = c ? c(null) : {}), (this.size = 0));
      };
    },
    50981: (u) => {
      u.exports = function m(r) {
        var c = this.has(r) && delete this.__data__[r];
        return ((this.size -= c ? 1 : 0), c);
      };
    },
    68776: (u, m, r) => {
      var c = r(15572),
        e = Object.prototype.hasOwnProperty;
      u.exports = function h(f) {
        var S = this.__data__;
        if (c) {
          var b = S[f];
          return "__lodash_hash_undefined__" === b ? void 0 : b;
        }
        return e.call(S, f) ? S[f] : void 0;
      };
    },
    31371: (u, m, r) => {
      var c = r(15572),
        _ = Object.prototype.hasOwnProperty;
      u.exports = function e(h) {
        var f = this.__data__;
        return c ? void 0 !== f[h] : _.call(f, h);
      };
    },
    1900: (u, m, r) => {
      var c = r(15572);
      u.exports = function _(e, h) {
        var f = this.__data__;
        return ((this.size += this.has(e) ? 0 : 1), (f[e] = c && void 0 === h ? "__lodash_hash_undefined__" : h), this);
      };
    },
    79672: (u) => {
      var r = Object.prototype.hasOwnProperty;
      u.exports = function c(s) {
        var _ = s.length,
          e = new s.constructor(_);
        return (_ && "string" == typeof s[0] && r.call(s, "index") && ((e.index = s.index), (e.input = s.input)), e);
      };
    },
    72604: (u, m, r) => {
      var c = r(88100),
        s = r(48691),
        _ = r(3352),
        e = r(21883),
        h = r(57388);
      u.exports = function Me(ae, Oe, D) {
        var me = ae.constructor;
        switch (Oe) {
          case "[object ArrayBuffer]":
            return c(ae);
          case "[object Boolean]":
          case "[object Date]":
            return new me(+ae);
          case "[object DataView]":
            return s(ae, D);
          case "[object Float32Array]":
          case "[object Float64Array]":
          case "[object Int8Array]":
          case "[object Int16Array]":
          case "[object Int32Array]":
          case "[object Uint8Array]":
          case "[object Uint8ClampedArray]":
          case "[object Uint16Array]":
          case "[object Uint32Array]":
            return h(ae, D);
          case "[object Map]":
          case "[object Set]":
            return new me();
          case "[object Number]":
          case "[object String]":
            return new me(ae);
          case "[object RegExp]":
            return _(ae);
          case "[object Symbol]":
            return e(ae);
        }
      };
    },
    85007: (u, m, r) => {
      var c = r(59033),
        s = r(37298),
        _ = r(68722);
      u.exports = function e(h) {
        return "function" != typeof h.constructor || _(h) ? {} : c(s(h));
      };
    },
    30308: (u) => {
      var r = /^(?:0|[1-9]\d*)$/;
      u.exports = function c(s, _) {
        var e = typeof s;
        return (
          !!(_ = null == _ ? 9007199254740991 : _) &&
          ("number" == e || ("symbol" != e && r.test(s))) &&
          s > -1 &&
          s % 1 == 0 &&
          s < _
        );
      };
    },
    68215: (u) => {
      u.exports = function m(r) {
        var c = typeof r;
        return "string" == c || "number" == c || "symbol" == c || "boolean" == c ? "__proto__" !== r : null === r;
      };
    },
    62522: (u, m, r) => {
      var e,
        c = r(42909),
        s = (e = /[^.]+$/.exec((c && c.keys && c.keys.IE_PROTO) || "")) ? "Symbol(src)_1." + e : "";
      u.exports = function _(e) {
        return !!s && s in e;
      };
    },
    68722: (u) => {
      var m = Object.prototype;
      u.exports = function r(c) {
        var s = c && c.constructor;
        return c === (("function" == typeof s && s.prototype) || m);
      };
    },
    97012: (u) => {
      u.exports = function m() {
        ((this.__data__ = []), (this.size = 0));
      };
    },
    77168: (u, m, r) => {
      var c = r(1207),
        _ = Array.prototype.splice;
      u.exports = function e(h) {
        var f = this.__data__,
          S = c(f, h);
        return !(S < 0 || (S == f.length - 1 ? f.pop() : _.call(f, S, 1), --this.size, 0));
      };
    },
    38946: (u, m, r) => {
      var c = r(1207);
      u.exports = function s(_) {
        var e = this.__data__,
          h = c(e, _);
        return h < 0 ? void 0 : e[h][1];
      };
    },
    89646: (u, m, r) => {
      var c = r(1207);
      u.exports = function s(_) {
        return c(this.__data__, _) > -1;
      };
    },
    62133: (u, m, r) => {
      var c = r(1207);
      u.exports = function s(_, e) {
        var h = this.__data__,
          f = c(h, _);
        return (f < 0 ? (++this.size, h.push([_, e])) : (h[f][1] = e), this);
      };
    },
    50837: (u, m, r) => {
      var c = r(37326),
        s = r(91699),
        _ = r(52583);
      u.exports = function e() {
        ((this.size = 0),
          (this.__data__ = {
            hash: new c(),
            map: new (_ || s)(),
            string: new c(),
          }));
      };
    },
    38566: (u, m, r) => {
      var c = r(12343);
      u.exports = function s(_) {
        var e = c(this, _).delete(_);
        return ((this.size -= e ? 1 : 0), e);
      };
    },
    84387: (u, m, r) => {
      var c = r(12343);
      u.exports = function s(_) {
        return c(this, _).get(_);
      };
    },
    77451: (u, m, r) => {
      var c = r(12343);
      u.exports = function s(_) {
        return c(this, _).has(_);
      };
    },
    94716: (u, m, r) => {
      var c = r(12343);
      u.exports = function s(_, e) {
        var h = c(this, _),
          f = h.size;
        return (h.set(_, e), (this.size += h.size == f ? 0 : 1), this);
      };
    },
    15572: (u, m, r) => {
      var s = r(4303)(Object, "create");
      u.exports = s;
    },
    67601: (u, m, r) => {
      var s = r(4652)(Object.keys, Object);
      u.exports = s;
    },
    51928: (u) => {
      u.exports = function m(r) {
        var c = [];
        if (null != r) for (var s in Object(r)) c.push(s);
        return c;
      };
    },
    31457: (u, m, r) => {
      u = r.nmd(u);
      var c = r(42293),
        s = m && !m.nodeType && m,
        _ = s && u && !u.nodeType && u,
        h = _ && _.exports === s && c.process,
        f = (function () {
          try {
            return (_ && _.require && _.require("util").types) || (h && h.binding && h.binding("util"));
          } catch {}
        })();
      u.exports = f;
    },
    21627: (u) => {
      var r = Object.prototype.toString;
      u.exports = function c(s) {
        return r.call(s);
      };
    },
    4652: (u) => {
      u.exports = function m(r, c) {
        return function (s) {
          return r(c(s));
        };
      };
    },
    94985: (u, m, r) => {
      var c = r(42293),
        s = "object" == typeof self && self && self.Object === Object && self,
        _ = c || s || Function("return this")();
      u.exports = _;
    },
    40553: (u, m, r) => {
      var c = r(91699);
      u.exports = function s() {
        ((this.__data__ = new c()), (this.size = 0));
      };
    },
    41608: (u) => {
      u.exports = function m(r) {
        var c = this.__data__,
          s = c.delete(r);
        return ((this.size = c.size), s);
      };
    },
    25678: (u) => {
      u.exports = function m(r) {
        return this.__data__.get(r);
      };
    },
    87716: (u) => {
      u.exports = function m(r) {
        return this.__data__.has(r);
      };
    },
    6734: (u, m, r) => {
      var c = r(91699),
        s = r(52583),
        _ = r(23027);
      u.exports = function h(f, S) {
        var b = this.__data__;
        if (b instanceof c) {
          var P = b.__data__;
          if (!s || P.length < 199) return (P.push([f, S]), (this.size = ++b.size), this);
          b = this.__data__ = new _(P);
        }
        return (b.set(f, S), (this.size = b.size), this);
      };
    },
    61786: (u) => {
      var r = Function.prototype.toString;
      u.exports = function c(s) {
        if (null != s) {
          try {
            return r.call(s);
          } catch {}
          try {
            return s + "";
          } catch {}
        }
        return "";
      };
    },
    9509: (u, m, r) => {
      var c = r(97247);
      u.exports = function e(h) {
        return c(h, 5);
      };
    },
    93011: (u) => {
      u.exports = function m(r, c) {
        return r === c || (r != r && c != c);
      };
    },
    39240: (u, m, r) => {
      var c = r(70842),
        s = r(84010),
        _ = Object.prototype,
        e = _.hasOwnProperty,
        h = _.propertyIsEnumerable,
        f = c(
          (function () {
            return arguments;
          })(),
        )
          ? c
          : function (S) {
              return s(S) && e.call(S, "callee") && !h.call(S, "callee");
            };
      u.exports = f;
    },
    27524: (u) => {
      u.exports = Array.isArray;
    },
    64523: (u, m, r) => {
      var c = r(61309),
        s = r(62322);
      u.exports = function _(e) {
        return null != e && s(e.length) && !c(e);
      };
    },
    90237: (u, m, r) => {
      u = r.nmd(u);
      var c = r(94985),
        s = r(64601),
        _ = m && !m.nodeType && m,
        e = _ && u && !u.nodeType && u,
        f = e && e.exports === _ ? c.Buffer : void 0;
      u.exports = (f ? f.isBuffer : void 0) || s;
    },
    61309: (u, m, r) => {
      var c = r(93759),
        s = r(69071);
      u.exports = function S(b) {
        if (!s(b)) return !1;
        var P = c(b);
        return (
          "[object Function]" == P ||
          "[object GeneratorFunction]" == P ||
          "[object AsyncFunction]" == P ||
          "[object Proxy]" == P
        );
      };
    },
    62322: (u) => {
      u.exports = function r(c) {
        return "number" == typeof c && c > -1 && c % 1 == 0 && c <= 9007199254740991;
      };
    },
    79015: (u, m, r) => {
      var c = r(48428),
        s = r(95332),
        _ = r(31457),
        e = _ && _.isMap,
        h = e ? s(e) : c;
      u.exports = h;
    },
    69071: (u) => {
      u.exports = function m(r) {
        var c = typeof r;
        return null != r && ("object" == c || "function" == c);
      };
    },
    84010: (u) => {
      u.exports = function m(r) {
        return null != r && "object" == typeof r;
      };
    },
    47542: (u, m, r) => {
      var c = r(22197),
        s = r(95332),
        _ = r(31457),
        e = _ && _.isSet,
        h = e ? s(e) : c;
      u.exports = h;
    },
    15527: (u, m, r) => {
      var c = r(96349),
        s = r(95332),
        _ = r(31457),
        e = _ && _.isTypedArray,
        h = e ? s(e) : c;
      u.exports = h;
    },
    25626: (u, m, r) => {
      var c = r(9461),
        s = r(70915),
        _ = r(64523);
      u.exports = function e(h) {
        return _(h) ? c(h) : s(h);
      };
    },
    11500: (u, m, r) => {
      var c = r(9461),
        s = r(327),
        _ = r(64523);
      u.exports = function e(h) {
        return _(h) ? c(h, !0) : s(h);
      };
    },
    78226: (u) => {
      u.exports = function m() {
        return [];
      };
    },
    64601: (u) => {
      u.exports = function m() {
        return !1;
      };
    },
    91774: (u, m, r) => {
      "use strict";
      (r.r(m), r.d(m, { TabsComponent: () => k, default: () => Ts }));
      var ue,
        c = r(1017),
        s = r(89923),
        _ = r(60030),
        e = r(35554),
        h = r(42068),
        f = r(22077),
        S = r(45197),
        b = r(89622),
        P = r(95287),
        M = r(95150),
        O = r(15222),
        x = r(19404),
        H = r(22761),
        oe = r(82772),
        K = r(46910),
        se = r(92048),
        $ = (r(73162), r(11698)),
        R = r(12927),
        pe = r(99474),
        W = r(78582),
        ce = r(94072),
        ee = r(5619);
      function Me(a, n) {
        1 & a && e._UZ(0, "span", 26);
      }
      function ae(a, n) {
        if (
          (1 & a &&
            (e.TgZ(0, "div", 17), e._uU(1), e.qZA(), e.TgZ(2, "div", 27), e._uU(3), e.qZA(), e._UZ(4, "bs-icon", 18)),
          2 & a)
        ) {
          const t = e.oxw();
          (e.xp6(1), e.Oqu(t.newVersion), e.xp6(2), e.hij(" ", "New", " "));
        }
      }
      function Oe(a, n) {
        1 & a && (e.TgZ(0, "div", 17), e.SDv(1, 28), e.qZA());
      }
      function D(a, n) {
        1 & a && e._UZ(0, "bs-icon", 29);
      }
      function me(a, n) {
        1 & a && e._UZ(0, "bs-icon", 30);
      }
      function Le(a, n) {
        if (1 & a) {
          const t = e.EpF();
          (e.TgZ(0, "bs-connect-wallet-panel-page", 31),
            e.NdJ("returnValue$", function (o) {
              e.CHM(t);
              const l = e.oxw();
              return e.KtG(l.onConnectWallet(o));
            }),
            e.qZA());
        }
        if (2 & a) {
          const t = e.oxw();
          e.Q6J("connectType", t.selectWalletSheet.conncetType)("presetWallets", t.selectWalletSheet.presetWallets);
        }
      }
      class j extends x.Wh {
        constructor() {
          (super(...arguments),
            (this.walletService = (0, e.f3M)(R.X)),
            (this.version = ""),
            (this.localeId = (0, e.f3M)(e.soG)),
            (this.language = (0, e.f3M)(e.soG)),
            (this.languageMap = new Map([
              ["zh-Hans", "\u7b80\u4f53\u4e2d\u6587"],
              ["zh-Hant", "\u7e41\u4f53\u4e2d\u6587"],
              ["en-US", "English"],
            ])),
            (this._versionUpgradeService = (0, e.f3M)(pe._)),
            (this.isCheckingVersion = !0),
            (this.canUpgrade = !1),
            (this.newVersion = ""),
            (this.selectWalletSheet = {
              is_open: !1,
              conncetType: se.i.CONNECT_WALLET,
              presetWallets: [],
            }));
        }
        getLanguageName() {
          return this.languageMap.get(this.language);
        }
        jumpUserAgreement() {
          this.nav.routeTo("/mine/user-agreement");
        }
        jumpLanguageSwitch() {
          this.nav.routeTo("/mine/language-switch");
        }
        jumpRisefallSwitch() {
          this.nav.routeTo("/mine/risefall-switch");
        }
        jumpEnterpriseSettleMent() {
          this.nav.routeTo("/mine/jumpEnterprise-settleMent-intro");
        }
        initData() {
          const n = localStorage.getItem("version");
          n && (this.version = n);
        }
        checkUpdate() {
          var n = this;
          return (0, c.Z)(function* () {
            n.isCheckingVersion = !0;
            let t = n.injectorForceGet(e.soG);
            n.environment.DWEB_APP && (t = yield n.injectorForceGet(W.Le).getLang());
            const i = yield n._versionUpgradeService.checkUpdate(t);
            ((n.isCheckingVersion = !1),
              "object" != typeof i || !1 === n._versionUpgradeService.needUpgradeApp.hasNeed
                ? (n.canUpgrade = !1)
                : ((n.canUpgrade = !0), (n.newVersion = i.version)));
          })();
        }
        checkVersionUpgrade() {
          var n = this;
          return (0, c.Z)(function* () {
            if (!n.isCheckingVersion)
              try {
                yield n._templateDialogService.openDialogByName("checkVersionUpgrade", {
                  input: void 0,
                  panelClass: "px-12 !h-auto",
                });
              } catch (t) {
                if (!1 !== t) throw t;
                ($.F.show("\u8FD9\u662F\u6700\u65B0\u7248\u672C"), n.console.log("no need upgrade"));
              }
          })();
        }
        kLineColor() {
          return localStorage.getItem("risefallColor") || "riseGreenFallRed";
        }
        onConnectWallet(n) {
          var t = this;
          return (0, c.Z)(function* () {
            n.walletName && (t.console.info("switch to wallet", n), t._returnRootPage());
          })();
        }
        _returnRootPage() {
          (Array.from(this.walletService.allSubscribes.values()).forEach((n) => {
            n.forEach((t) => {
              t.unsubscribe();
            });
          }),
            (this.walletService.allSubscribes = new Map()),
            this.nav.setPageRoot("tabs"));
        }
      }
      (((ue = j).ɵfac = (() => {
        let a;
        return function (t) {
          return (a || (a = e.n5z(ue)))(t || ue);
        };
      })()),
        (ue.ɵcmp = e.Xpm({
          type: ue,
          selectors: [["bs-version-info-panel"]],
          standalone: !0,
          features: [e.qOj, e.jDz],
          decls: 44,
          vars: 9,
          consts: () => {
            let a, n, t, i, o, l, d, p;
            return (
              (a = "BFM Dex"),
              (n = "Beta"),
              (t = "\u7248\u672C\u66F4\u65B0"),
              (i = "\u8BED\u8A00"),
              (o = "k\u7EBF\u989C\u8272"),
              (l = "\u7528\u6237\u534F\u8BAE"),
              (d = "\u4F01\u4E1A\u5165\u9A7B"),
              (p = "\u5DF2\u662F\u6700\u65B0\u7248\u672C"),
              [
                [3, "hideBackButton", "hideHeader", "contentBackground", "contentSafeArea"],
                [1, "p-4"],
                [1, "flex", "justify-end"],
                ["name", "icon-close", 1, "ml-auto", "text-3xl", 3, "click"],
                [1, "flex", "flex-col", "items-center"],
                [1, "border-gray-1", "rounded-4", "flex", "h-16", "w-16", "items-center", "justify-center", "border"],
                ["src", "../../assets/images/logo.png", 1, "h-12", "w-12"],
                [1, "mb-2", "mt-3", "text-xl", "font-semibold"],
                a,
                [1, "text-title-2", "text-xs"],
                n,
                [1, "mt-10", "flex", "items-center", "justify-between", 3, "click"],
                [1, "text-base", "font-semibold"],
                t,
                [1, "flex", "items-center", "justify-end"],
                ["class", "duibs-loading duibs-loading-dots duibs-loading-md text-primary mx-auto block"],
                i,
                [1, "text-title-2", "ml-auto", "text-xs"],
                ["name", "icon-chevron-right", 1, "text-xl"],
                o,
                ["class", "text-xl", "name", "icon-Kline, A"],
                [1, "mb-3", "mt-8", "flex", "items-center", 3, "click"],
                l,
                ["name", "icon-chevron-right", 1, "ml-auto", "text-xl"],
                d,
                [3, "isOpen", "isOpenChange"],
                [1, "duibs-loading", "duibs-loading-dots", "duibs-loading-md", "text-primary", "mx-auto", "block"],
                [
                  1,
                  "bg-primary",
                  "text-xxs",
                  "ml-2",
                  "mr-1",
                  "flex",
                  "h-4",
                  "items-center",
                  "rounded-full",
                  "px-2",
                  "text-white",
                ],
                p,
                ["name", "icon-Kline, A", 1, "text-xl"],
                ["name", "icon-Kline1, B", 1, "text-xl"],
                [3, "connectType", "presetWallets", "returnValue$"],
              ]
            );
          },
          template: function (n, t) {
            (1 & n &&
              (e.TgZ(0, "common-page", 0)(1, "div", 1)(2, "div", 2)(3, "bs-icon", 3),
              e.NdJ("click", function () {
                return t.nav.back();
              }),
              e.qZA()(),
              e.TgZ(4, "div", 4)(5, "div", 5),
              e._UZ(6, "img", 6),
              e.qZA(),
              e.TgZ(7, "div", 7),
              e.SDv(8, 8),
              e.qZA(),
              e.TgZ(9, "div", 9),
              e._uU(10),
              e.qZA(),
              e.TgZ(11, "div"),
              e.SDv(12, 10),
              e.qZA()(),
              e.TgZ(13, "div", 11),
              e.NdJ("click", function () {
                return t.checkVersionUpgrade();
              }),
              e.TgZ(14, "div", 12),
              e.SDv(15, 13),
              e.qZA(),
              e.TgZ(16, "div", 14),
              e.YNc(17, Me, 1, 0, "span", 15)(18, ae, 5, 2)(19, Oe, 2, 0),
              e.qZA()(),
              e.TgZ(20, "div", 11),
              e.NdJ("click", function () {
                return t.jumpLanguageSwitch();
              }),
              e.TgZ(21, "div", 12),
              e.SDv(22, 16),
              e.qZA(),
              e.TgZ(23, "div", 14)(24, "div", 17),
              e._uU(25),
              e.qZA(),
              e._UZ(26, "bs-icon", 18),
              e.qZA()(),
              e.TgZ(27, "div", 11),
              e.NdJ("click", function () {
                return t.jumpRisefallSwitch();
              }),
              e.TgZ(28, "div", 12),
              e.SDv(29, 19),
              e.qZA(),
              e.TgZ(30, "div", 14),
              e.YNc(31, D, 1, 0, "bs-icon", 20)(32, me, 1, 0),
              e._UZ(33, "bs-icon", 18),
              e.qZA()(),
              e.TgZ(34, "div", 21),
              e.NdJ("click", function () {
                return t.jumpUserAgreement();
              }),
              e.TgZ(35, "div", 12),
              e.SDv(36, 22),
              e.qZA(),
              e._UZ(37, "bs-icon", 23),
              e.qZA(),
              e.TgZ(38, "div", 21),
              e.NdJ("click", function () {
                return t.jumpEnterpriseSettleMent();
              }),
              e.TgZ(39, "div", 12),
              e.SDv(40, 24),
              e.qZA(),
              e._UZ(41, "bs-icon", 23),
              e.qZA()()(),
              e.TgZ(42, "common-bottom-sheet", 25),
              e.NdJ("isOpenChange", function (o) {
                return (t.selectWalletSheet.is_open = o);
              }),
              e.YNc(43, Le, 1, 2, "ng-template"),
              e.qZA()),
              2 & n &&
                (e.Q6J("hideBackButton", !0)("hideHeader", !0)("contentBackground", "white")("contentSafeArea", !1),
                e.xp6(10),
                e.Oqu(t.version),
                e.xp6(7),
                e.um2(17, t.isCheckingVersion ? 17 : t.canUpgrade ? 18 : 0 == t.canUpgrade ? 19 : -1),
                e.xp6(8),
                e.Oqu(t.getLanguageName()),
                e.xp6(6),
                e.um2(31, "riseGreenFallRed" === t.kLineColor() ? 31 : 32),
                e.xp6(11),
                e.Q6J("isOpen", t.selectWalletSheet.is_open)));
          },
          dependencies: [x.f5, ce.y, ee.C, O.oJ, M.Z],
          styles: [
            ".mat-bottom-sheet-container{border-top-left-radius:1.25rem!important;border-top-right-radius:1.25rem!important}",
          ],
          changeDetection: 0,
        })),
        (0, s.gn)([j.State(), (0, s.w6)("design:type", Object)], j.prototype, "version", void 0),
        (0, s.gn)([j.State(), (0, s.w6)("design:type", Object)], j.prototype, "localeId", void 0),
        (0, s.gn)([j.State(), (0, s.w6)("design:type", Object)], j.prototype, "language", void 0),
        (0, s.gn)(
          [
            j.OnInit(),
            (0, s.w6)("design:type", Function),
            (0, s.w6)("design:paramtypes", []),
            (0, s.w6)("design:returntype", void 0),
          ],
          j.prototype,
          "initData",
          null,
        ),
        (0, s.gn)([j.State(), (0, s.w6)("design:type", Object)], j.prototype, "isCheckingVersion", void 0),
        (0, s.gn)([j.State(), (0, s.w6)("design:type", Object)], j.prototype, "canUpgrade", void 0),
        (0, s.gn)([j.State(), (0, s.w6)("design:type", Object)], j.prototype, "newVersion", void 0),
        (0, s.gn)(
          [
            j.OnReady(),
            (0, s.w6)("design:type", Function),
            (0, s.w6)("design:paramtypes", []),
            (0, s.w6)("design:returntype", Promise),
          ],
          j.prototype,
          "checkUpdate",
          null,
        ),
        (0, s.gn)([j.States(1), (0, s.w6)("design:type", Object)], j.prototype, "selectWalletSheet", void 0));
      var ye,
        y = r(99557),
        _e = r(63234),
        et = r(64249);
      function wt(a, n) {
        if (
          (1 & a &&
            (e.TgZ(0, "div", 21)(1, "div", 22),
            e._UZ(2, "bs-icon", 23),
            e.qZA(),
            e.TgZ(3, "div", 24),
            e._uU(4),
            e.qZA(),
            e.TgZ(5, "div", 25),
            e._uU(6),
            e.ALo(7, "addressHidden"),
            e.qZA()()),
          2 & a)
        ) {
          const t = n.$implicit;
          (e.xp6(2), e.Q6J("name", t.icon), e.xp6(2), e.Oqu(t.chain), e.xp6(2), e.Oqu(e.lcZ(7, 3, t.address)));
        }
      }
      class Ne extends x.Wh {
        constructor() {
          (super(...arguments),
            (this.returnValue$ = new x.sS()),
            (this.walletService = (0, e.f3M)(R.X)),
            (this.chainInfo = []),
            (this.selectWalletSheet = {
              is_open: !1,
              conncetType: se.i.CONNECT_WALLET,
              presetWallets: [],
            }));
        }
        initData() {
          if (this.connectedWallet)
            for (const [n, t] of this.connectedWallet.assetInfoListMap) {
              const i = (0, y.kI)(n || "Default");
              this.chainInfo.push({ icon: i, chain: n, address: t.address });
            }
        }
        disconnectWallet() {
          var n = this;
          return (0, c.Z)(function* () {
            const t = yield n.confirm({
              bodyMessage: "\u662F\u5426\u9000\u51FA\u5F53\u524D\u94B1\u5305\u8D26\u6237?",
              footerTheme: "normal",
              bodyClass: "font-semibold pt-4 px-6",
              footerClass: "pt-10 mb-6",
              confirmText: "\u786E\u8BA4",
            });
            (yield (0, K._v)(250),
              t &&
                ((yield n.walletService.disconnectWallet())
                  ? (n.console.info("disconnect wallet success"), n._returnRootPage(), et.FN.show("\u672A\u8FDE\u63A5"))
                  : et.FN.show("\u65AD\u5F00\u8FDE\u63A5\u5931\u8D25")));
          })();
        }
        _returnRootPage() {
          (Array.from(this.walletService.allSubscribes.values()).forEach((n) => {
            n.forEach((t) => {
              t.unsubscribe();
            });
          }),
            (this.walletService.allSubscribes = new Map()),
            this.nav.back());
        }
        openSwapWalletSheet() {
          var n = this;
          return (0, c.Z)(function* () {
            n.returnValue$.return({ reconnectWallet: !0 });
          })();
        }
      }
      (((ye = Ne).ɵfac = (() => {
        let a;
        return function (t) {
          return (a || (a = e.n5z(ye)))(t || ye);
        };
      })()),
        (ye.ɵcmp = e.Xpm({
          type: ye,
          selectors: [["bs-wallet-info-panel"]],
          inputs: {
            connectedWallet: "connectedWallet",
            walletIcon: "walletIcon",
          },
          outputs: { returnValue$: "returnValue$" },
          standalone: !0,
          features: [e.qOj, e.jDz],
          decls: 24,
          vars: 6,
          consts: () => {
            let a, n, t, i;
            return (
              (a = "\u94B1\u5305"),
              (n = "\u5DF2\u8FDE\u63A5"),
              (t = "\u5173\u8054\u7684\u94B1\u5305\u5404\u94FE\u5730\u5740\u5982\u4E0B:"),
              (i = "\u91CD\u65B0\u8FDE\u63A5"),
              [
                [3, "hideBackButton", "hideHeader", "contentBackground", "contentSafeArea"],
                [1, "p-4"],
                [1, "flex"],
                [
                  1,
                  "rounded-4",
                  "overflow-hidden",
                  "border-gray-1",
                  "flex",
                  "h-14",
                  "w-14",
                  "items-center",
                  "justify-center",
                  "border",
                ],
                [1, "icon-14", 3, "name"],
                [1, "ml-2", "flex", "flex-col"],
                [1, "flex", "items-center"],
                [1, "text-lg", "font-semibold", "mr-2"],
                [1, "text-lg", "font-semibold"],
                a,
                ["name", "icon-log-out", 1, "text-red", "ml-2", "text-base", 3, "click"],
                [1, "bg-green-pale", "flex", "w-fit", "items-center", "justify-center", "px-2", "py-1", "rounded-1"],
                [1, "bg-green", "mr-1", "h-1", "w-1", "rounded-full"],
                [1, "text-green", "text-xs"],
                n,
                ["name", "icon-close", 1, "ml-auto", "text-3xl", 3, "click"],
                [1, "px-3.5"],
                [1, "text-title-1", "mb-4", "mt-8", "text-xs"],
                t,
                [
                  1,
                  "bg-primary",
                  "mt-8",
                  "flex",
                  "items-center",
                  "justify-center",
                  "rounded-full",
                  "py-3",
                  "text-lg",
                  "leading-6",
                  "text-white",
                  3,
                  "click",
                ],
                i,
                [1, "mb-2", "flex", "items-center"],
                [1, "rounded-1.5", "bg-blue-pale", "flex", "h-6", "w-6", "items-center", "justify-center"],
                [1, "text-lg", 3, "name"],
                [1, "text-title-1", "ml-2", "text-xs"],
                [1, "ml-auto", "text-xs", "font-semibold"],
                ["class", "mb-2 flex items-center"],
              ]
            );
          },
          template: function (n, t) {
            (1 & n &&
              (e.TgZ(0, "common-page", 0)(1, "div", 1)(2, "div", 2)(3, "div", 3),
              e._UZ(4, "bs-icon", 4),
              e.qZA(),
              e.TgZ(5, "div", 5)(6, "div", 6)(7, "div", 7),
              e._uU(8),
              e.qZA(),
              e.TgZ(9, "div", 8),
              e.SDv(10, 9),
              e.qZA(),
              e.TgZ(11, "bs-icon", 10),
              e.NdJ("click", function () {
                return t.disconnectWallet();
              }),
              e.qZA()(),
              e.TgZ(12, "div", 11),
              e._UZ(13, "div", 12),
              e.TgZ(14, "div", 13),
              e.SDv(15, 14),
              e.qZA()()(),
              e.TgZ(16, "bs-icon", 15),
              e.NdJ("click", function () {
                return t.nav.back();
              }),
              e.qZA()(),
              e.TgZ(17, "div", 16)(18, "div", 17),
              e.SDv(19, 18),
              e.qZA(),
              e.SjG(20, wt, 8, 5, "div", 26, e.ikw),
              e.qZA(),
              e.TgZ(22, "div", 19),
              e.NdJ("click", function () {
                return t.openSwapWalletSheet();
              }),
              e.SDv(23, 20),
              e.qZA()()()),
              2 & n &&
                (e.Q6J("hideBackButton", !0)("hideHeader", !0)("contentBackground", "white")("contentSafeArea", !1),
                e.xp6(4),
                e.Q6J("name", t.walletIcon),
                e.xp6(4),
                e.Oqu(null == t.connectedWallet ? null : t.connectedWallet.walletName),
                e.xp6(12),
                e.wJu(t.chainInfo)));
          },
          dependencies: [x.f5, ee.C, O.oJ, _e.bz],
          styles: [
            ".mat-bottom-sheet-container{border-top-left-radius:1.25rem!important;border-top-right-radius:1.25rem!important}  .mat-mdc-dialog-container{min-height:10.5rem!important}",
          ],
          changeDetection: 0,
        })),
        (0, s.gn)(
          [
            Ne.OnInit(),
            (0, s.w6)("design:type", Function),
            (0, s.w6)("design:paramtypes", []),
            (0, s.w6)("design:returntype", void 0),
          ],
          Ne.prototype,
          "initData",
          null,
        ),
        (0, s.gn)([Ne.States(1), (0, s.w6)("design:type", Object)], Ne.prototype, "selectWalletSheet", void 0));
      var xe,
        Mt = r(83686),
        Ot = r(76653),
        Lt = r(39112),
        ve = r(85081),
        N = r(31678),
        it = r(79357),
        G = r(6840),
        Rt = r(41072),
        Be = r(4442),
        Re = r(3177),
        kt = r(39289),
        Fe = r(56498),
        U = r(75387),
        $e = r(46413),
        L = r(22694),
        be = r(84405),
        Ae = r(23138);
      function We(a, n) {
        if (1 & a) {
          const t = e.EpF();
          (e.TgZ(0, "div", 22),
            e.NdJ("click", function () {
              e.CHM(t);
              const o = e.oxw();
              return e.KtG(o.jumpAssetAllocation());
            }),
            e._UZ(1, "bs-icon", 23),
            e.qZA());
        }
        2 & a && (e.xp6(1), e.Q6J("name", "icon-chart"));
      }
      function ge(a, n) {
        if ((1 & a && e._UZ(0, "bn-loading-wrapper", 24), 2 & a)) {
          const t = e.oxw();
          e.Q6J("loadingTheme", "ellipsis")("showLoading", t.loading);
        }
      }
      function te(a, n) {
        if (
          (1 & a && (e.TgZ(0, "div", 25), e._uU(1), e.ALo(2, "amountFormat"), e.qZA(), e._UZ(3, "bs-icon", 26)), 2 & a)
        ) {
          const t = e.oxw(2);
          (e.xp6(1), e.hij(" ", "- -" !== t.totalUAmount ? e.lcZ(2, 1, t.totalUAmount) : "- -", " "));
        }
      }
      function je(a, n) {
        1 & a && (e.TgZ(0, "div", 25), e._uU(1, "****"), e.qZA(), e._UZ(2, "bs-icon", 27));
      }
      function Ve(a, n) {
        if ((1 & a && e.YNc(0, te, 4, 3)(1, je, 3, 0), 2 & a)) {
          const t = e.oxw();
          e.um2(0, t.showMyAsset ? 0 : 1);
        }
      }
      function Dt(a, n) {
        if ((1 & a && (e.TgZ(0, "div", 33), e._UZ(1, "div", 34), e.qZA()), 2 & a)) {
          const t = e.oxw(2);
          (e.Q6J("@fadeInLeft", void 0), e.xp6(1), e.Udp("background-color", t.showChainInfo.bgColor));
        }
      }
      function ot(a, n) {
        if (1 & a) {
          const t = e.EpF();
          (e.TgZ(0, "li", 28)(1, "button", 29),
            e.NdJ("click", function () {
              const l = e.CHM(t).$implicit,
                d = e.oxw();
              return e.KtG(d.selectChain(l));
            }),
            e._UZ(2, "bs-icon", 30)(3, "bs-icon", 31),
            e.qZA(),
            e.YNc(4, Dt, 2, 3, "div", 32),
            e.qZA());
        }
        if (2 & a) {
          const t = n.$implicit,
            i = e.oxw();
          (e.xp6(2),
            e.Q6J("defaultName", "chain-Default")("name", t.activeIcon)(
              "ngClass",
              i.isSelectedChain(t) ? "opacity-100" : "opacity-0",
            ),
            e.xp6(1),
            e.Q6J("defaultName", "chain-Default-s")("name", t.unactiveIcon),
            e.xp6(1),
            e.um2(4, i.isSelectedChain(t) ? 4 : -1));
        }
      }
      const Pe = (a) => ({ "--color-1": a });
      function st(a, n) {
        if (
          (1 & a &&
            (e.TgZ(0, "div", 39)(1, "span"),
            e._uU(2),
            e.ALo(3, "addressHidden"),
            e.qZA(),
            e._UZ(4, "bs-icon", 40),
            e.ALo(5, "color"),
            e.qZA()),
          2 & a)
        ) {
          const t = e.oxw(2);
          (e.xp6(2),
            e.Oqu(e.lcZ(3, 4, t.showChainInfo.address)),
            e.xp6(2),
            e.Akn(e.VKq(8, Pe, e.lcZ(5, 6, "gray-pale"))),
            e.Q6J("wClickToCopy", t.showChainInfo.address));
        }
      }
      function at(a, n) {
        1 & a && (e.TgZ(0, "div", 41), e.SDv(1, 42), e.qZA());
      }
      function Ut(a, n) {
        if (
          (1 & a &&
            (e.TgZ(0, "div", 35)(1, "div")(2, "div", 36),
            e._uU(3),
            e.qZA(),
            e.YNc(4, st, 6, 10, "div", 37)(5, at, 2, 0),
            e.qZA(),
            e._UZ(6, "img", 38),
            e.qZA()),
          2 & a)
        ) {
          const t = e.oxw();
          (e.Udp("background-color", t.showChainInfo.bgColor),
            e.Q6J("@fadeInRight", void 0),
            e.xp6(3),
            e.Oqu(t.showChainInfo.chainName),
            e.xp6(1),
            e.um2(4, t.showChainInfo.address ? 4 : 5),
            e.xp6(2),
            e.Q6J("src", t.showChainInfo.bgIconUrl, e.LSH));
        }
      }
      function rt(a, n) {
        if ((1 & a && e._UZ(0, "img", 52), 2 & a)) {
          const t = e.oxw().$implicit;
          e.Q6J("src", t.iconUrl, e.LSH);
        }
      }
      function fe(a, n) {
        if ((1 & a && e._UZ(0, "bs-icon", 53), 2 & a)) {
          const t = e.oxw().$implicit;
          e.Q6J("defaultName", "token-Default")("name", t.localTokenIcon);
        }
      }
      const Ce = () => ({ removeZero: !0 });
      function Cn(a, n) {
        if (
          (1 & a &&
            (e.TgZ(0, "li", 46)(1, "div", 47),
            e.YNc(2, rt, 1, 1, "img", 48)(3, fe, 1, 2),
            e.TgZ(4, "span", 49),
            e._uU(5),
            e.qZA()(),
            e.TgZ(6, "div", 50)(7, "span", 51),
            e._uU(8),
            e.ALo(9, "amountFixed"),
            e.qZA()()()),
          2 & a)
        ) {
          const t = n.$implicit;
          (e.xp6(2),
            e.um2(2, t.iconUrl ? 2 : 3),
            e.xp6(3),
            e.Oqu(t.assetType),
            e.xp6(3),
            e.hij(" ", e.Dn7(9, 3, t.amount, t.decimals, e.DdM(7, Ce)), " "));
        }
      }
      const En = () => ({ height: "calc(100% - 6.75rem)" });
      function yn(a, n) {
        if (1 & a) {
          const t = e.EpF();
          (e.TgZ(0, "ul", 43),
            e.NdJ("pulled$", function (o) {
              e.CHM(t);
              const l = e.oxw();
              return e.KtG(o.waitFor(l.reGetAsset()));
            }),
            e._UZ(1, "bn-pull-to-refresh-spinner", 44),
            e.SjG(2, Cn, 10, 8, "li", 54, e.ikw),
            e._UZ(4, "li", 45),
            e.qZA());
        }
        if (2 & a) {
          const t = e.oxw();
          (e.Akn(e.DdM(5, En)),
            e.Q6J("emitDistance", 158)("maxDistance", 200)("@listFadeInRight", t.listFadeInRightState),
            e.xp6(2),
            e.wJu(t.showChainInfo.assets));
        }
      }
      const Nn = () => ({ "--page-safe-area-inset-top": 0 });
      class V extends x.Wh {
        constructor() {
          var n;
          (super(...arguments),
            (n = this),
            (this.walletService = (0, e.f3M)(R.X)),
            (this.userService = (0, e.f3M)(it.f)),
            (this.liquidityPoolService = (0, e.f3M)(Be.X)),
            (this.commonService = (0, e.f3M)(Re._)),
            (this.uName = ""),
            (this.chainListDetail = []),
            (this.supportChainList = []),
            (this.connectedWallet = this.walletService.connectedWallet),
            (this.totalUAmount = "- -"),
            (this.paradiseUserService = (0, e.f3M)(kt.x)),
            (this.showMyAsset = !!this.paradiseUserService.paradiseAppSettings.hideAsset),
            (this.loading = !0),
            (this.walletAssets$ = this.walletService.curentWalletAssets_subject.subscribe(
              (function () {
                var t = (0, c.Z)(function* (i) {
                  i.updating ||
                    void 0 === i.connectedWallet ||
                    void 0 === n.connectedWallet ||
                    n.connectedWallet.pmchainAddress !== i.connectedWallet.pmchainAddress ||
                    (n.console.info("\u66f4\u65b0\u8d44\u4ea7\u9875\u4f59\u989d"),
                    (n.connectedWallet = i.connectedWallet));
                });
                return function (i) {
                  return t.apply(this, arguments);
                };
              })(),
            )),
            (this.CHAIN_CARD_INFO = new Map([
              [
                W.Ei.BFMeta,
                {
                  bgColor: "#7D65F7",
                  bgIconUrl: "./assets/images/chain-BFMeta-w.png",
                },
              ],
              [
                W.Ei.BIWMeta,
                {
                  bgColor: "#f7931a",
                  bgIconUrl: "./assets/images/chain-BIWMeta-n.svg",
                },
              ],
              [
                W.Ei.BFChainV2,
                {
                  bgColor: "#A484EE",
                  bgIconUrl: "./assets/images/chain-BFChainV2-w.png",
                },
              ],
              [
                W.Ei.BTGMeta,
                {
                  bgColor: "#33D383",
                  bgIconUrl: "./assets/images/bg-btgm.svg",
                },
              ],
              [
                W.Ei.ETHMeta,
                {
                  bgColor: "#1829F5",
                  bgIconUrl: "./assets/images/chain-ETHMeta-w.png",
                },
              ],
              [
                W.Ei.PMChain,
                {
                  bgColor: "#8265F9",
                  bgIconUrl: "./assets/images/chain-Pay-Meta-Chain-w.png",
                },
              ],
              [
                W.Ei.CCChain,
                {
                  bgColor: "#d655ff",
                  bgIconUrl: "./assets/images/chain-CCChain-n.png",
                },
              ],
              [
                W.Ei.Ethereum,
                {
                  bgColor: "#4469f8",
                  bgIconUrl: "./assets/images/chain-Ethereum-n.png",
                },
              ],
              [
                W.Ei.Tron,
                {
                  bgColor: "#f2313e",
                  bgIconUrl: "./assets/images/chain-Tron-n.png",
                },
              ],
              [
                W.Ei.Binance,
                {
                  bgColor: "#fac00a",
                  bgIconUrl: "./assets/images/chain-Binance-n.png",
                },
              ],
            ])),
            (this.CHAIN_CARD_DEFAULT_INFO = {
              bgColor: "#A484EE",
              bgIconUrl: "./assets/images/chain-normal-w.png",
            }),
            (this.CHAIN_NAME = W.Ei),
            (this.pieChartData = { totalAmount: "- -", list: [] }));
        }
        handShowMyAsset() {
          this.showMyAsset = this.paradiseUserService.paradiseAppSettings.hideAsset =
            !this.paradiseUserService.paradiseAppSettings.hideAsset;
        }
        openTip() {
          var n = this;
          return (0, c.Z)(function* () {
            yield n.alert({
              headerTitle: "\u603B\u8D44\u4EA7",
              bodyMessage:
                "\u603B\u8D44\u4EA7\u4EC5\u6839\u636E\u94B1\u5305\u6388\u6743\u7684\u4E14\u5728\u4EA4\u6613\u6240\u4E2D\u652F\u6301\u5151\u6362\u7684\u6743\u76CA\uFF0C\u6362\u7B97\u6210 U \u6765\u8BA1\u7B97\u3002\u8303\u56F4\u5305\u62EC\u5730\u5740\u4E2D\u7684\u6743\u76CA\uFF0C\u4EE5\u53CA\u5404\u5408\u7EA6\u6C60\u6743\u76CA\u3002",
              buttonText: "\u597D\u7684",
              bodyClass: "swap",
            });
          })();
        }
        get showChainInfo() {
          const n = this.CHAIN_CARD_INFO.get(this.activeChainName);
          if (this.activeChainName && this.connectedWallet) {
            const t = this.connectedWallet.assetInfoListMap.get(this.activeChainName);
            if (t)
              return (
                t.assets.forEach((i) => {
                  const o = (0, O.Yq)(i.assetType || "", this.activeChainName);
                  i.iconUrl = o || i.iconUrl;
                }),
                {
                  bgIconUrl: (null == n ? void 0 : n.bgIconUrl) || this.CHAIN_CARD_DEFAULT_INFO.bgIconUrl,
                  bgColor: (null == n ? void 0 : n.bgColor) || this.CHAIN_CARD_DEFAULT_INFO.bgColor,
                  ...t,
                }
              );
          }
          return {
            bgIconUrl: (null == n ? void 0 : n.bgIconUrl) || this.CHAIN_CARD_DEFAULT_INFO.bgIconUrl,
            bgColor: (null == n ? void 0 : n.bgColor) || this.CHAIN_CARD_DEFAULT_INFO.bgColor,
            chainName: this.activeChainName,
            assets: [],
            address: "",
          };
        }
        isSelectedChain(n) {
          return n.chain === this.activeChainName;
        }
        reGetAsset() {
          var n = this;
          return (0, c.Z)(function* () {
            yield n.walletService.updateAsset();
          })();
        }
        unsubscribe() {
          (this.subscription && this.subscription.unsubscribe(),
            this.console.log("\u6e05\u9664 \u8ba2\u9605 walletAssets$"),
            this.walletAssets$.unsubscribe(),
            this.walletService.allSubscribes.delete("AssetsPage"));
        }
        selectDefaultChain() {
          var n = this;
          return (0, c.Z)(function* () {
            n.activeChainName = n.supportChainList[0].chain;
          })();
        }
        selectChain(n) {
          this.activeChainName = n.chain;
        }
        get listFadeInRightState() {
          return this.activeChainName + ":" + this.showChainInfo.assets.length;
        }
        get chianNameFadeInRightState() {
          return this.activeChainName;
        }
        initAssets() {
          ((this.totalUAmount = "- -"), (this.pieChartData.totalAmount = "- -"), (this.pieChartData.list = []));
        }
        walletInit() {
          var n = this;
          ((this.subscription = this.commonService.virtualCoinAlias.subscribe((t) => {
            ((this.uName = t), this.cdRef.detectChanges());
          })),
            (this.connectWallet$ = this.walletService.wallletConnected_subject.subscribe(
              (function () {
                var t = (0, c.Z)(function* (i) {
                  if (void 0 === i) return;
                  const o = i.wallet;
                  (n.console.info("\u5151\u6362\u9762\u677f\u76d1\u542c\u5230\u94b1\u5305\u53d8\u5316", o),
                    (n.connectedWallet = o),
                    void 0 === o && n.initAssets());
                });
                return function (i) {
                  return t.apply(this, arguments);
                };
              })(),
            )),
            (this.walletAssets$ = this.walletService.curentWalletAssets_subject.subscribe(
              (function () {
                var t = (0, c.Z)(function* (i) {
                  const { updating: o, connectedWallet: l } = i;
                  (n.console.info("\u5151\u6362\u9762\u677f\u76d1\u542c\u5230\u4f59\u989d\u53d8\u5316", o, l),
                    o ? (n.loading = !0) : l && ((n.connectedWallet = l), n.getUserPositonList()));
                });
                return function (i) {
                  return t.apply(this, arguments);
                };
              })(),
            )));
        }
        jumpAssetAllocation() {
          this.nav.routeTo("/mine/my-asset-allocation", {
            pieChartData: JSON.stringify(this.pieChartData),
          });
        }
        getUserPositonList() {
          var n = this;
          return (0, c.Z)(function* () {
            const { connectedWallet: t } = n;
            if (t) {
              const i = t.pmchainAddress,
                o = yield n.userService.getLiquidityUserAssetsList({
                  userId: i,
                });
              if (o) {
                const l = t.assetInfoListMap,
                  d = n.handlerPositionAssetGenMap(o),
                  p = n.handleWalletAsset(l, d),
                  g = n.calculateWalletTotalU(p),
                  T = n.calculatePostitonTotalU(o),
                  v = new N.Z(g).plus(T).toFixed(8, 1).toString();
                ((n.totalUAmount = Number(v).toString()), n.handlePieChartData(p, o), (n.loading = !1));
              }
            } else n.totalUAmount = "- -";
          })();
        }
        handlePieChartData(n, t) {
          const { totalUAmount: i } = this,
            o = [];
          n.forEach((d) => {
            const p = new N.Z(d.amount).div(i);
            o.push({ name: d.coin, amount: Number(p) });
          });
          const l = (d) => (void 0 === d ? "" : "USDM" === d.toUpperCase() ? this.uName : d);
          (t.forEach((d) => {
            const { userRedeemableQuoteCoinsAmount: p } = d;
            if (Number(p) > 0) {
              const T = new N.Z(p).div(1e8).multipliedBy(2).div(i);
              o.push({
                name: `\u6c60${d.anchorCoinsName}-${l(d.quoteCoinsName)}`,
                amount: Number(T),
              });
            }
          }),
            (this.pieChartData.totalAmount = i),
            (this.pieChartData.list = o));
        }
        calculatePostitonTotalU(n) {
          let t = "0";
          return (
            n.forEach((i) => {
              t = new N.Z(i.userRedeemableQuoteCoinsAmount).div(1e8).multipliedBy(2).plus(t).toString();
            }),
            t
          );
        }
        calculateWalletTotalU(n) {
          let t = "0";
          return (
            n.forEach((i) => {
              t = new N.Z(t).plus(i.amount).toString();
            }),
            t
          );
        }
        handlerPositionAssetGenMap(n) {
          const t = new Map();
          return (
            n.forEach((i) => {
              t.set(`${i.anchorCoinsName}-${y.AG[i.anchorCoinsChainName]}`, i);
            }),
            t
          );
        }
        handleWalletAsset(n, t) {
          var i = this;
          let o = 0;
          const l = [];
          for (const [d, p] of n)
            p.assets.forEach(
              (function () {
                var g = (0, c.Z)(function* (T) {
                  const { assetType: v, amount: A } = T,
                    w = y.FN[d],
                    B =
                      w !== G.BNQKL_SWAP_CHAIN_NAME.ETH &&
                      w !== G.BNQKL_SWAP_CHAIN_NAME.TRON &&
                      w !== G.BNQKL_SWAP_CHAIN_NAME.BSC;
                  if (Number(A) > 0 && B)
                    if (i.commonService.dollarEquivalentCoins.value.map((F) => F.coinName).includes(v))
                      o = new N.Z(A).div(`1e+${T.decimals}`).plus(o).toNumber();
                    else {
                      const Z = t.get(`${v}-${d}`);
                      if (Z) {
                        const { price: he } = Z,
                          Ze = new N.Z(he).multipliedBy(A).div(`1e+${T.decimals}`).toNumber();
                        l.push({ coin: v, amount: Ze });
                      }
                    }
                });
                return function (T) {
                  return g.apply(this, arguments);
                };
              })(),
            );
          return (
            o > 0 &&
              l.unshift({
                coin: this.commonService.virtualCoinAliasValue,
                amount: o,
              }),
            l
          );
        }
        jumpToRecharge() {
          this.nav.routeTo("/recharge");
        }
      }
      (((xe = V).ɵfac = (() => {
        let a;
        return function (t) {
          return (a || (a = e.n5z(xe)))(t || xe);
        };
      })()),
        (xe.ɵcmp = e.Xpm({
          type: xe,
          selectors: [["bs-assets"]],
          standalone: !0,
          features: [e.qOj, e.jDz],
          decls: 28,
          vars: 9,
          consts: () => {
            let a, n, t, i;
            return (
              (a = "\u94B1\u5305"),
              (n = "\u603B\u8D44\u4EA7"),
              (t = "\u94B1\u5305"),
              (i = "\u672A\u6388\u6743\u5730\u5740"),
              [
                [3, "hideHeader", "contentBackground", "ngStyle"],
                [1, "flex", "h-full", "flex-col", "pt-4"],
                [1, "mb-4", "shrink-0", "flex", "h-10", "items-center", "px-4", "text-[28px]", "font-semibold"],
                a,
                ["class", "rounded-2.5 bg-gray-pale ml-auto flex h-8 w-8 items-center justify-center"],
                [1, "mb-4", "px-4", "text-white"],
                [1, "h-29", "_bg-asset", "p-4"],
                [1, "mb-4", "flex", "items-center", "text-xs"],
                n,
                ["name", "icon-info", 1, "icon-4", "ml-1", 3, "click"],
                [1, "flex", "items-center", "h-8", 3, "click"],
                ["class", "icon-6", 3, "loadingTheme", "showLoading"],
                [1, "flex", "pl-7", "pr-4", "items-end"],
                [1, "text-base", "flex", "flex-col", "justify-between", "items-center"],
                [1, "mb-1", "font-semibold"],
                t,
                [1, "w-4.5", "h-[3px]", "rounded-full", "bg-primary"],
                [1, "flex", "flex-row", "border-t", 2, "height", "calc(100% - 14rem)"],
                [
                  1,
                  "my-4",
                  "grid",
                  "w-16",
                  "grid-flow-row",
                  "gap-4",
                  "overflow-y-auto",
                  "overflow-x-hidden",
                  "pl-4",
                  "hidden-bar",
                ],
                [1, "h-full", "flex-grow", "overflow-hidden", "border-l", "bg-white", "hidden-bar"],
                [
                  "class",
                  "rounded-4 ml-2 mr-4 mt-6 flex w-auto items-center justify-between text-white",
                  3,
                  "backgroundColor",
                ],
                [
                  "wPullToRefresh",
                  "",
                  "class",
                  "overflow-x-hidden overflow-y-scroll pl-1.5 pr-5 pt-1.5",
                  3,
                  "emitDistance",
                  "maxDistance",
                  "style",
                ],
                [
                  1,
                  "rounded-2.5",
                  "bg-gray-pale",
                  "ml-auto",
                  "flex",
                  "h-8",
                  "w-8",
                  "items-center",
                  "justify-center",
                  3,
                  "click",
                ],
                [1, "icon-4.5", 3, "name"],
                [1, "icon-6", 3, "loadingTheme", "showLoading"],
                [1, "text-2xl", "font-extrabold"],
                ["name", "icon-eye", 1, "icon-5", "ml-2"],
                ["name", "icon-eye-off", 1, "icon-5", "ml-2", "mb-2"],
                [1, "flex", "items-center"],
                [1, "grid-areas-[icon]", "rounded-2", "bg-blue-pale", "grid", 3, "click"],
                [
                  1,
                  "icon-8",
                  "duration-ios",
                  "ease-ios-out",
                  "grid-in-[icon]",
                  "z-[2]",
                  3,
                  "defaultName",
                  "name",
                  "ngClass",
                ],
                [1, "icon-8", "grid-in-[icon]", "z-[1]", "grayscale", 3, "defaultName", "name"],
                ["class", "pl-3"],
                [1, "pl-3"],
                [1, "h-4.5", "w-1", "rounded-lg"],
                [
                  1,
                  "rounded-4",
                  "ml-2",
                  "mr-4",
                  "mt-6",
                  "flex",
                  "w-auto",
                  "items-center",
                  "justify-between",
                  "text-white",
                ],
                [1, "ml-3", "mt-3", "font-semibold"],
                ["class", "text-gray-pale mb-3 ml-3 flex items-center text-xs font-normal"],
                [1, "mr-2", "h-16", "w-16", 3, "src"],
                [1, "text-gray-pale", "mb-3", "ml-3", "flex", "items-center", "text-xs", "font-normal"],
                ["name", "icon-copy1", 1, "icon-7", "grid-in-[icon]", "z-[1]", 3, "wClickToCopy"],
                [1, "text-normal", "text-gray-pale", "my-4", "ml-3", "text-sm"],
                i,
                [
                  "wPullToRefresh",
                  "",
                  1,
                  "overflow-x-hidden",
                  "overflow-y-scroll",
                  "pl-1.5",
                  "pr-5",
                  "pt-1.5",
                  3,
                  "emitDistance",
                  "maxDistance",
                  "pulled$",
                ],
                [1, "text-subtext"],
                [1, "h-25", "w-full"],
                [
                  1,
                  "rounded-4",
                  "h-13",
                  "text-black-1",
                  "flex",
                  "items-center",
                  "justify-between",
                  "bg-white",
                  "text-sm",
                  "font-semibold",
                ],
                [1, "flex", "w-1/2", "items-center"],
                ["class", "h-7 w-7 rounded-full", "alt", "", 3, "src"],
                [1, "ml-2", "overflow-hidden", "text-ellipsis"],
                [1, "flex", "w-1/2", "justify-end"],
                [1, "no-scrollbar", "overflow-scroll"],
                ["alt", "", 1, "h-7", "w-7", "rounded-full", 3, "src"],
                [1, "icon-7", 3, "defaultName", "name"],
                [
                  "class",
                  "rounded-4 h-13 text-black-1 flex items-center justify-between bg-white text-sm font-semibold",
                ],
                ["class", "flex items-center"],
              ]
            );
          },
          template: function (n, t) {
            (1 & n &&
              (e.TgZ(0, "common-page", 0)(1, "div", 1)(2, "div", 2)(3, "div"),
              e.SDv(4, 3),
              e.qZA(),
              e.YNc(5, We, 2, 1, "div", 4),
              e.qZA(),
              e.TgZ(6, "div", 5)(7, "div", 6)(8, "div", 7)(9, "span"),
              e.SDv(10, 8),
              e.qZA(),
              e._uU(11),
              e.TgZ(12, "bs-icon", 9),
              e.NdJ("click", function () {
                return t.openTip();
              }),
              e.qZA()(),
              e.TgZ(13, "div", 10),
              e.NdJ("click", function () {
                return t.handShowMyAsset();
              }),
              e.YNc(14, ge, 1, 2, "bn-loading-wrapper", 11)(15, Ve, 2, 1),
              e.qZA()()(),
              e.TgZ(16, "div", 12)(17, "div", 13)(18, "div", 14),
              e.SDv(19, 15),
              e.qZA(),
              e._UZ(20, "div", 16),
              e.qZA()(),
              e.TgZ(21, "main", 17)(22, "ul", 18),
              e.SjG(23, ot, 5, 6, "li", 55, e.ikw),
              e.qZA(),
              e.TgZ(25, "div", 19),
              e.YNc(26, Ut, 7, 6, "div", 20)(27, yn, 5, 6, "ul", 21),
              e.qZA()()()()),
              2 & n &&
                (e.Q6J("hideHeader", !0)("contentBackground", "white")("ngStyle", e.DdM(8, Nn)),
                e.xp6(5),
                e.um2(5, !t.loading && t.connectedWallet && "0" != t.totalUAmount ? 5 : -1),
                e.xp6(6),
                e.hij("(", t.uName, ") "),
                e.xp6(3),
                e.um2(14, t.loading ? 14 : 15),
                e.xp6(9),
                e.wJu(t.supportChainList),
                e.xp6(3),
                e.um2(26, t.activeChainName ? 26 : -1),
                e.xp6(1),
                e.um2(27, t.activeChainName ? 27 : -1)));
          },
          dependencies: [Rt.n, _e.bz, x.f5, Fe.I, U.O, $e.a, _.mk, _.PC, ee.C, O.oJ, L.G4, be.z, Ae.r, _.ez],
          styles: [
            "[_nghost-%COMP%]   ._bg-asset[_ngcontent-%COMP%]{background-image:url(asset-allocation-bg.c8da21ee42070489.png);background-size:100% 100%}[_nghost-%COMP%]   .hidden-bar[_ngcontent-%COMP%]::-webkit-scrollbar{display:none}",
          ],
          data: { animation: [ve.kT, ve.Ps, ve.Ri, ve.jw, ve.yi] },
          changeDetection: 0,
        })),
        (0, s.gn)([V.State(), (0, s.w6)("design:type", Object)], V.prototype, "uName", void 0),
        (0, s.gn)([V.State(), (0, s.w6)("design:type", Array)], V.prototype, "supportChainList", void 0),
        (0, s.gn)([V.State(), (0, s.w6)("design:type", Object)], V.prototype, "activeChainName", void 0),
        (0, s.gn)([V.State(), (0, s.w6)("design:type", Object)], V.prototype, "connectedWallet", void 0),
        (0, s.gn)([V.State(), (0, s.w6)("design:type", Object)], V.prototype, "totalUAmount", void 0),
        (0, s.gn)([V.State(), (0, s.w6)("design:type", Object)], V.prototype, "showMyAsset", void 0),
        (0, s.gn)([V.State(), (0, s.w6)("design:type", Object)], V.prototype, "loading", void 0),
        (0, s.gn)(
          [
            V.OnDestroy(),
            (0, s.w6)("design:type", Function),
            (0, s.w6)("design:paramtypes", []),
            (0, s.w6)("design:returntype", void 0),
          ],
          V.prototype,
          "unsubscribe",
          null,
        ),
        (0, s.gn)(
          [
            V.OnReady(),
            (0, s.w6)("design:type", Function),
            (0, s.w6)("design:paramtypes", []),
            (0, s.w6)("design:returntype", Promise),
          ],
          V.prototype,
          "selectDefaultChain",
          null,
        ),
        (0, s.gn)(
          [
            V.OnInit(),
            (0, s.w6)("design:type", Function),
            (0, s.w6)("design:paramtypes", []),
            (0, s.w6)("design:returntype", void 0),
          ],
          V.prototype,
          "walletInit",
          null,
        ));
      const en = V;
      var xn = r(37514),
        Zt = r(565),
        q = (function (a) {
          return ((a.DESC = "DESC"), (a.ASC = "ASC"), (a.DEFAULT = "DEFAULT"), a);
        })(q || {}),
        ke = (function (a) {
          return ((a.NAME = "NAME"), (a.PRICE = "PRICE"), (a.FLUCTUATION = "FLUCTUATION"), a);
        })(ke || {});
      const tn = {
        [q.ASC]: "./assets/images/price_upper.png",
        [q.DESC]: "./assets/images/price_below.png",
        [q.DEFAULT]: "./assets/images/price_default.png",
      };
      var Xe,
        lt = r(110),
        Pn = r(39722),
        In = r(20776),
        nn = r(12533),
        wn = r(50047),
        ct = r(35196),
        Mn = r(11776),
        Gt = r(16505),
        On = r(66560),
        dt = r(37886),
        Ln = r(10320);
      const Rn = ["tabsSlides"],
        kn = ["divOpen"];
      function Dn(a, n) {
        1 & a && e._UZ(0, "div", 24);
      }
      function Un(a, n) {
        if (1 & a) {
          const t = e.EpF();
          (e.TgZ(0, "button", 49),
            e.NdJ("click", function (o) {
              e.CHM(t);
              const l = e.oxw().$implicit,
                d = e.oxw(4);
              return e.KtG(d.goMint(l, o));
            }),
            e.TgZ(1, "span", 50),
            e.SDv(2, 51),
            e.qZA(),
            e.TgZ(3, "span", 52),
            e.SDv(4, 53),
            e.qZA(),
            e.TgZ(5, "span", 52),
            e._uU(6, " > "),
            e.qZA()());
        }
      }
      function Zn(a, n) {
        1 & a && (e.TgZ(0, "div", 55), e._UZ(1, "bs-icon", 56), e.TgZ(2, "p", 57), e.SDv(3, 58), e.qZA()());
      }
      function Gn(a, n) {
        1 & a && (e.TgZ(0, "div", 59), e._UZ(1, "bs-icon", 60), e.TgZ(2, "p", 57), e.SDv(3, 61), e.qZA()());
      }
      function Bn(a, n) {
        if ((1 & a && e.YNc(0, Zn, 4, 0, "div", 54)(1, Gn, 4, 0), 2 & a)) {
          const t = e.oxw().$implicit;
          e.um2(0, 2 === t.useIcoStatus ? 0 : 1);
        }
      }
      function Fn(a, n) {
        1 & a && (e.TgZ(0, "div", 59), e._UZ(1, "bs-icon", 60), e.TgZ(2, "p", 57), e.SDv(3, 63), e.qZA()());
      }
      function $n(a, n) {
        1 & a && (e.TgZ(0, "div", 65), e._UZ(1, "bs-icon", 66), e.TgZ(2, "p", 57), e.SDv(3, 67), e.qZA()());
      }
      function Wn(a, n) {
        1 & a && (e.TgZ(0, "div", 55), e._UZ(1, "bs-icon", 56), e.TgZ(2, "p", 57), e.SDv(3, 68), e.qZA()());
      }
      function jn(a, n) {
        if ((1 & a && e.YNc(0, $n, 4, 0, "div", 64)(1, Wn, 4, 0), 2 & a)) {
          const t = e.oxw(2).$implicit,
            i = e.oxw(4);
          e.um2(0, i.isPublish(t) ? 0 : 1);
        }
      }
      function Vn(a, n) {
        1 & a && (e.TgZ(0, "div", 69), e._UZ(1, "bs-icon", 56), e.TgZ(2, "p", 57), e.SDv(3, 70), e.qZA()());
      }
      function Xn(a, n) {
        if ((1 & a && e.YNc(0, Fn, 4, 0, "div", 62)(1, jn, 2, 1)(2, Vn, 4, 0), 2 & a)) {
          const t = e.oxw().$implicit;
          e.um2(0, 1 === t.useIcoStatus ? 0 : 2 === t.useIcoStatus ? 1 : 2);
        }
      }
      function Hn(a, n) {
        if (1 & a) {
          const t = e.EpF();
          (e.TgZ(0, "div", 30),
            e.NdJ("click", function () {
              const l = e.CHM(t).$implicit,
                d = e.oxw(4);
              return e.KtG(d.goDetail(l));
            }),
            e.TgZ(1, "div")(2, "div", 31)(3, "div"),
            e._UZ(4, "bs-icon", 32),
            e.qZA(),
            e.TgZ(5, "div", 33)(6, "div", 34)(7, "div", 35),
            e._uU(8),
            e.qZA(),
            e._UZ(9, "bs-icon", 36),
            e.qZA(),
            e.TgZ(10, "div", 37),
            e._uU(11),
            e.qZA(),
            e.YNc(12, Un, 7, 0, "button", 38),
            e.qZA()(),
            e.TgZ(13, "div", 39)(14, "div", 40),
            e.YNc(15, Bn, 2, 1)(16, Xn, 3, 1),
            e.qZA(),
            e.TgZ(17, "div", 41)(18, "div"),
            e._uU(19, "1"),
            e.qZA(),
            e._UZ(20, "bs-icon", 42),
            e.TgZ(21, "div"),
            e._uU(22),
            e.qZA(),
            e.TgZ(23, "div", 43),
            e.SDv(24, 44),
            e.qZA()()()(),
            e.TgZ(25, "div", 45)(26, "div", 46)(27, "div", 47),
            e._uU(28),
            e.ALo(29, "date"),
            e.ALo(30, "date"),
            e.qZA(),
            e._UZ(31, "bs-icon", 48),
            e.qZA()()());
        }
        if (2 & a) {
          const t = n.$implicit,
            i = e.oxw(4);
          (e.xp6(1),
            e.Gre("", 0 === i.currentTabIdx ? "underway-box" : "finished-box", " h-33 relative"),
            e.xp6(2),
            e.Gre(
              "",
              0 === i.currentTabIdx ? "underway-circle" : "finished-circle",
              " min-w-22 w-22 h-22 rounded-full ml-[12px] flex items-center justify-center",
            ),
            e.xp6(1),
            e.Q6J("defaultName", "token-Default")("iconUrl", i.handleIcon(t, !0))("name", i.handleIcon(t)),
            e.xp6(4),
            e.Oqu(t.icoCoinName),
            e.xp6(3),
            e.hij(" ", i.getChainName(t.icoCoinChainName), " "),
            e.xp6(1),
            e.um2(12, 0 === i.currentTabIdx && 1 === t.useIcoStatus && i.IsNeedMint(t) ? 12 : -1),
            e.xp6(3),
            e.um2(15, 0 === i.currentTabIdx ? 15 : 16),
            e.xp6(5),
            e.Q6J("defaultName", "token-Default")("iconUrl", i.handleIcon(t, !0))("name", i.handleIcon(t)),
            e.xp6(2),
            e.hij("= ", t.price ? t.price : "--", ""),
            e.xp6(6),
            e.AsE(
              " ",
              e.xi3(29, 19, t.startTime, "yyyy-MM-dd HH:mm"),
              " - ",
              e.xi3(30, 22, t.endTime, "yyyy-MM-dd HH:mm"),
              " ",
            ));
        }
      }
      function zn(a, n) {
        if ((1 & a && (e.ynx(0), e.SjG(1, Hn, 32, 25, "div", 71, e.ikw), e._UZ(3, "div", 29), e.BQk()), 2 & a)) {
          const t = e.oxw(3);
          (e.xp6(1), e.wJu(t.pageListData.dataList));
        }
      }
      function qn(a, n) {
        1 & a && (e.TgZ(0, "bn-infinite-scroll-spinner")(1, "span", 72), e.SDv(2, 73), e.qZA()());
      }
      function Qn(a, n) {
        if (1 & a) {
          const t = e.EpF();
          (e.TgZ(0, "div", 25, 26),
            e.NdJ("infinited$", function (o) {
              e.CHM(t);
              const l = e.oxw(2);
              return e.KtG(o.waitFor(l.loadMoreList()));
            }),
            e.YNc(2, zn, 4, 0, "ng-container", 27)(3, qn, 3, 0, "bn-infinite-scroll-spinner", 28),
            e.qZA());
        }
        if (2 & a) {
          e.oxw();
          const t = e.MAs(15),
            i = e.oxw(),
            o = e.MAs(6);
          (e.Q6J("infiniteScrollElement", t)("hasMore", i.pageListData.hasMore)(
            "@listFadeInRight",
            i.pageListData.dataList.length,
          ),
            e.xp6(2),
            e.Q6J("ngIf", i.pageListData.dataList.length)("ngIfElse", o),
            e.xp6(1),
            e.Q6J("ngIf", i.pageListData.hasMore));
        }
      }
      function Jn(a, n) {
        (1 & a && (e.TgZ(0, "div", 74), e._UZ(1, "bn-loading-wrapper", 75), e.TgZ(2, "p", 72), e.SDv(3, 76), e.qZA()()),
          2 & a && (e.xp6(1), e.Q6J("showLoading", !0)));
      }
      function Yn(a, n) {
        if (1 & a) {
          const t = e.EpF();
          (e.TgZ(0, "div", 77)(1, "button", 78),
            e.NdJ("click", function () {
              e.CHM(t);
              const o = e.oxw(2);
              return e.KtG(o.oneClickStagging());
            }),
            e.TgZ(2, "bn-loading-wrapper", 79)(3, "div", 80),
            e._UZ(4, "bs-icon", 81),
            e.TgZ(5, "div", 82),
            e.SDv(6, 83),
            e.qZA()()()()());
        }
        if (2 & a) {
          const t = e.oxw(2);
          (e.xp6(1),
            e.Q6J("@fadeInUp", void 0),
            e.xp6(1),
            e.Q6J("loadingTheme", "ellipsis")("waitFor", t.oneClickStagging.running));
        }
      }
      const on = (a) => ({ "pointer-events-none opacity-50": a }),
        Kn = (a) => ({ "--index": a });
      function ei(a, n) {
        if (1 & a) {
          const t = e.EpF();
          (e.TgZ(0, "header", 5)(1, "nav", 6, 7)(3, "div", 8),
            e.NdJ("click", function () {
              e.CHM(t);
              const o = e.oxw();
              return e.KtG(o.selectTab(0));
            }),
            e.SDv(4, 9),
            e.qZA(),
            e.TgZ(5, "div", 10),
            e.NdJ("click", function () {
              e.CHM(t);
              const o = e.oxw();
              return e.KtG(o.selectTab(1));
            }),
            e.SDv(6, 11),
            e.qZA(),
            e._UZ(7, "div", 12, 13),
            e.qZA(),
            e.TgZ(9, "div", 14),
            e.NdJ("click", function () {
              e.CHM(t);
              const o = e.oxw();
              return e.KtG(o.goMystock());
            }),
            e.TgZ(10, "div", 15)(11, "span"),
            e.SDv(12, 16),
            e.qZA(),
            e.YNc(13, Dn, 1, 0, "div", 17),
            e.qZA()()(),
            e.TgZ(14, "section", 18, 19),
            e.NdJ("pulled$", function (o) {
              e.CHM(t);
              const l = e.oxw();
              return e.KtG(o.waitFor(l.refreshList()));
            }),
            e._UZ(16, "bn-pull-to-refresh-spinner", 20),
            e.YNc(17, Qn, 4, 6, "div", 21)(18, Jn, 4, 1, "ng-template", null, 22, e.W1O),
            e.qZA(),
            e.YNc(20, Yn, 7, 3, "div", 23));
        }
        if (2 & a) {
          const t = e.MAs(19),
            i = e.oxw();
          (e.xp6(3),
            e.Gre(
              "px-4 text-xs whitespace-nowrap ",
              0 === i.currentTabIdx ? "text-title font-medium" : "text-title-2 font-normal",
              "",
            ),
            e.Q6J("ngClass", e.VKq(15, on, i.pageListData.loading)),
            e.xp6(2),
            e.Gre(
              "px-4 text-xs whitespace-nowrap ",
              1 === i.currentTabIdx ? "text-title font-medium" : "text-title-2 font-normal",
              "",
            ),
            e.Q6J("ngClass", e.VKq(17, on, i.pageListData.loading)),
            e.xp6(2),
            e.Q6J("ngStyle", e.VKq(19, Kn, i.currentTabIdx || 0)),
            e.xp6(6),
            e.um2(13, i.winCount > 0 ? 13 : -1),
            e.xp6(1),
            e.Q6J("emitDistance", 158)("maxDistance", 200),
            e.xp6(3),
            e.Q6J("ngIf", i.pageListData.init && !i.pageListData.loading)("ngIfElse", t),
            e.xp6(3),
            e.um2(20, 0 === i.currentTabIdx && i.pageListData.dataList.length && !1 === i.isAllStagged ? 20 : -1));
        }
      }
      function ti(a, n) {
        1 & a && (e.TgZ(0, "div", 84), e._UZ(1, "img", 85), e.TgZ(2, "div", 86), e.SDv(3, 87), e.qZA()());
      }
      function ni(a, n) {
        1 & a &&
          (e.TgZ(0, "div", 88)(1, "div", 89), e._UZ(2, "img", 90), e.TgZ(3, "h1", 91), e.SDv(4, 92), e.qZA()()());
      }
      function ii(a, n) {
        if ((1 & a && e._UZ(0, "bs-forge-panel-page", 93), 2 & a)) {
          const t = e.oxw();
          e.Q6J("dataList", t.selectAssetSheet.data)("thresholdMode", t.selectAssetSheet.mode);
        }
      }
      class re extends (0, f.To)(x.Wh) {
        constructor() {
          var n;
          (super(...arguments),
            (n = this),
            (this.currentTabIdx = 0),
            (this.selectAssetSheet = { isOpen: !1, data: [], mode: 1 }),
            (this.pageListData = {
              dataList: [],
              maxIndex: 1e10,
              minIndex: 0,
              pageSize: 10,
              hasMore: !1,
              loading: !1,
              init: !1,
            }),
            (this.plateStaggingService = (0, e.f3M)(nn.P)),
            (this.walletService = (0, e.f3M)(R.X)),
            (this.winCount = 0),
            (this.refreshFlag = !1),
            (this.externalAppService = (0, e.f3M)(wn.l)),
            (this.successRes = { successList: [], failureList: [] }),
            (this.oneClickStagging = (0, b.mf)(
              (0, c.Z)(function* () {
                const { connectedWallet: t } = n;
                if (t) {
                  const i = {
                      userId: t.pmchainAddress,
                      state: G.SHARE_ICO_FILTER_STATUS.IN_PROGRESS,
                      maxIndex: 1e10,
                      minIndex: 0,
                      size: n.pageListData.pageSize,
                    },
                    { list: o } = yield n.plateStaggingService.getICOList(i),
                    l = t.pmchainAddress,
                    d = t.walletId,
                    p = o
                      .filter((A) => !1 === n.IsNeedMint(A))
                      .filter((A) => 1 === A.useIcoStatus)
                      .map((A) => A.icoId);
                  if (0 === p.length) return void $.F.show("\u5F53\u524D\u65E0\u53EF\u7533\u8D2D\u9879\u76EE");
                  const g = {
                      userId: l,
                      icoIds: p,
                      publicKey: t.pmchainPublicKey,
                    },
                    T = {
                      type: W.h0.message,
                      chainName: W.Ei.PMChain,
                      senderAddress: l,
                      message: JSON.stringify(g),
                    },
                    v = yield n.externalAppService.sinature(d, [T]);
                  if (!v) return (ct.dq.focusWindow(), void $.F.show("\u94B1\u5305\u7B7E\u540D\u5931\u8D25\uFF01"));
                  {
                    ct.dq.focusWindow();
                    const A = yield n.plateStaggingService.participate({
                      ...g,
                      signature: v[0],
                    });
                    A && ((n.successRes = A), n.divOpenRef.nativeElement.click());
                  }
                }
              }),
            )),
            (this.goMint = (0, b.mf)(
              (function () {
                var t = (0, c.Z)(function* (i, o) {
                  var l;
                  o.stopPropagation();
                  const d =
                    null === (l = i.threshold) || void 0 === l
                      ? void 0
                      : l.conditions.map((g) => {
                          var T;
                          const v =
                              null === (T = n.connectedWallet) || void 0 === T
                                ? void 0
                                : T.assetInfoListMap.get(y.AG[g.chainName]),
                            A = null == v ? void 0 : v.assets.filter((E) => E.assetType === g.coinName)[0];
                          if (A && A.amount) {
                            const E = new N.Z(g.minAmount).minus(A.amount).toString();
                            return { ...g, stillNeedAmount: E, decimals: 8 };
                          }
                          return {
                            ...g,
                            stillNeedAmount: g.minAmount,
                            decimals: 8,
                          };
                        });
                  var p;
                  (yield (0, K._v)(200),
                    d &&
                      ((n.selectAssetSheet.data = d),
                      (n.selectAssetSheet.mode = null === (p = i.threshold) || void 0 === p ? void 0 : p.mode),
                      (n.selectAssetSheet.isOpen = !0)));
                });
                return function (i, o) {
                  return t.apply(this, arguments);
                };
              })(),
            )));
        }
        dataInit() {
          var n = this;
          return (0, c.Z)(function* () {
            n.connectWallet$ = n.walletService.wallletConnected_subject.subscribe(
              (function () {
                var t = (0, c.Z)(function* (i) {
                  i && null != i && i.wallet
                    ? ((n.connectedWallet = n.walletService.connectedWallet),
                      yield n.getWinUnpaidCount(),
                      (n.currentTabIdx = 0),
                      yield (0, K._v)(200),
                      yield n.refreshList(),
                      n.cdRef.detectChanges())
                    : ((n.connectedWallet = void 0), n.cdRef.detectChanges());
                });
                return function (i) {
                  return t.apply(this, arguments);
                };
              })(),
            );
          })();
        }
        unsubscribe() {
          (this.console.log("\u6e05\u9664 \u8ba2\u9605"), this.connectWallet$ && this.connectWallet$.unsubscribe());
        }
        loadMoreList() {
          var n = this;
          return (0, c.Z)(function* () {
            return n.getList();
          })();
        }
        getWinUnpaidCount() {
          var n = this;
          return (0, c.Z)(function* () {
            if (void 0 === n.connectedWallet) return;
            const t = { userId: n.connectedWallet.pmchainAddress },
              i = yield n.plateStaggingService.getWinUnpaidCount(t);
            i && (n.winCount = i.count);
          })();
        }
        getList() {
          var n = this;
          return (0, c.Z)(function* () {
            if (void 0 !== n.connectedWallet && !n.pageListData.loading) {
              n.pageListData.loading = !0;
              try {
                const t = {
                    userId: n.connectedWallet.pmchainAddress,
                    state:
                      0 === n.currentTabIdx ? G.SHARE_ICO_FILTER_STATUS.IN_PROGRESS : G.SHARE_ICO_FILTER_STATUS.ENDED,
                    maxIndex: n.pageListData.maxIndex,
                    minIndex: 0,
                    size: n.pageListData.pageSize,
                  },
                  i = yield n.plateStaggingService.getICOList(t);
                if (i) {
                  const { list: o, hasMore: l } = i,
                    d = o.sort((p, g) => g.index - p.index);
                  ((n.pageListData.loading = !1),
                    (n.pageListData.hasMore = l),
                    n.refreshFlag
                      ? ((n.refreshFlag = !1), (n.pageListData.dataList = [...d]))
                      : (n.pageListData.dataList = [...n.pageListData.dataList, ...d]),
                    n.pageListData.dataList.length > 0 &&
                      (n.pageListData.maxIndex = n.pageListData.dataList[n.pageListData.dataList.length - 1].index - 1),
                    !1 === n.pageListData.init && (n.pageListData.init = !0),
                    n.cdRef.detectChanges());
                }
              } catch (t) {
                n.console.error(t);
              } finally {
                n.pageListData.loading = !1;
              }
            }
          })();
        }
        refreshList() {
          var n = this;
          return (0, c.Z)(function* () {
            if (n.pageListData.loading) return !0;
            ((n.refreshFlag = !0),
              (n.pageListData.maxIndex = 1e10),
              (n.pageListData.hasMore = !1),
              (n.pageListData.dataList = []),
              (n.pageListData.loading = !1),
              yield n.getList());
          })();
        }
        viewInit() {
          const t = document.getElementById("underway");
          if (this.subscriptRef && t) {
            const i = document.getElementById("underway");
            (document.getElementById("finished"),
              this.renderer2.setStyle(this.subscriptRef.nativeElement, "left", "3px"),
              this.renderer2.setStyle(this.subscriptRef.nativeElement, "width", `${i.clientWidth}px`));
          }
        }
        selectTab(n) {
          var t = this;
          return (0, c.Z)(function* () {
            if (n === t.currentTabIdx) return;
            t.currentTabIdx = n;
            const i = document.getElementById(0 === n ? "underway" : "finished");
            if (t.subscriptRef && i) {
              const o = document.getElementById("underway"),
                l = document.getElementById("finished");
              0 === n
                ? (t.renderer2.setStyle(t.subscriptRef.nativeElement, "left", "3px"),
                  t.renderer2.setStyle(t.subscriptRef.nativeElement, "width", `${o.clientWidth}px`))
                : (t.renderer2.setStyle(t.subscriptRef.nativeElement, "left", `${o.clientWidth + 3}px`),
                  t.renderer2.setStyle(t.subscriptRef.nativeElement, "width", `${l.clientWidth}px`));
            }
            yield t.refreshList();
          })();
        }
        openSuccess() {
          var n = this;
          return (0, c.Z)(function* () {
            (yield n._templateDialogService.openDialogByName("successStaggingOneClick", {
              input: {
                success: n.successRes.successList ? n.successRes.successList.length : 0,
                fail: n.successRes.failureList ? n.successRes.failureList.length : 0,
              },
            })).returnValue$.subscribe(
              (0, c.Z)(function* () {
                yield n.refreshList();
              }),
            );
          })();
        }
        goMystock() {
          void 0 !== this.connectedWallet && this.nav.routeTo("/my-stock-ballot");
        }
        goDetail(n) {
          var t;
          this.nav.routeTo("/stagging-detail", {
            userId: null === (t = this.connectedWallet) || void 0 === t ? void 0 : t.pmchainAddress,
            detail: JSON.stringify(n),
            type: 0 === this.currentTabIdx ? "UNDERWAY" : "FINISHED",
          });
        }
        handleIcon(n, t = !1) {
          return (0, y.TH)(y.AG[n.icoCoinChainName], n.icoCoinName, t);
        }
        getChainName(n) {
          return y.AG[n];
        }
        get isAllStagged() {
          return this.pageListData.dataList.every(
            (n) => n.useIcoStatus === G.SHARE_ICO_USER_ICO_STATUS.ALREADY_PARTICIPATED,
          );
        }
        isPublish(n) {
          return new Date().getTime() >= n.publishTime;
        }
        IsNeedMint(n) {
          if (n.isSetThreshold) {
            var t, i;
            const o =
              null === (t = n.threshold) || void 0 === t
                ? void 0
                : t.conditions.map((l) => {
                    var d;
                    const p =
                        null === (d = this.connectedWallet) || void 0 === d
                          ? void 0
                          : d.assetInfoListMap.get(y.AG[l.chainName]),
                      g = null == p ? void 0 : p.assets.filter((T) => T.assetType === l.coinName)[0];
                    return !g || !g.amount || BigInt(g.amount) < BigInt(l.minAmount);
                  });
            return (null === (i = n.threshold) || void 0 === i ? void 0 : i.mode) === G.SHARE_ICO_THRESHOLD_MODE.ALL
              ? !(null == o ? void 0 : o.every((d) => !1 === d))
              : !(null == o ? void 0 : o.includes(!1));
          }
          return !1;
        }
      }
      (((Xe = re).ɵfac = (() => {
        let a;
        return function (t) {
          return (a || (a = e.n5z(Xe)))(t || Xe);
        };
      })()),
        (Xe.ɵcmp = e.Xpm({
          type: Xe,
          selectors: [["bs-stagging"]],
          viewQuery: function (n, t) {
            if ((1 & n && (e.Gf(Rn, 5), e.Gf(kn, 7)), 2 & n)) {
              let i;
              (e.iGM((i = e.CRH())) && (t.subscriptRef = i.first), e.iGM((i = e.CRH())) && (t.divOpenRef = i.first));
            }
          },
          standalone: !0,
          features: [e.qOj, e.jDz],
          decls: 9,
          vars: 3,
          consts: () => {
            let a, n, t, i, o, l, d, p, g, T, v, A, E, w, B, z, F;
            return (
              (a = "\u8FDB\u884C\u4E2D"),
              (n = "\u5F80\u671F"),
              (t = "\u6211\u7684\u4E2D\u7B7E"),
              (i = "U"),
              (o = "\u672A\u6EE1\u8DB3\u7533\u8D2D\u6761\u4EF6\uFF0C"),
              (l = "\u53BB\u953B\u9020"),
              (d = "\u5DF2\u7533\u8D2D"),
              (p = "\u672A\u7533\u8D2D"),
              (g = "\u672A\u7533\u8D2D"),
              (T = "\u672A\u4E2D\u7B7E"),
              (v = "\u5DF2\u7533\u8D2D"),
              (A = "\u5DF2\u4E2D\u7B7E"),
              (E = "\u52A0\u8F7D\u4E2D"),
              (w = "\u52A0\u8F7D\u4E2D"),
              (B = "\u4E00\u952E\u7533\u8D2D"),
              (z = "\u8BF7\u5148\u8FDE\u63A5\u94B1\u5305"),
              (F = "\u5F53\u524D\u6682\u65E0\u6743\u76CA\u53EF\u7533\u8D2D"),
              [
                [1, "h-full", "pt-4"],
                [1, "left-999999", "right-999999", "absolute", "-z-[99999]", "opacity-0", 3, "click"],
                ["divOpen", ""],
                ["emptyListView", ""],
                [3, "isOpen", "panelClass", "isOpenChange"],
                [1, "mb-2", "flex", "items-center", "justify-between", "px-4"],
                [
                  "wObSize",
                  "",
                  1,
                  "grid-in-[tabs]",
                  "bg-gray-pale",
                  "relative",
                  "z-[2]",
                  "flex",
                  "h-8",
                  "items-center",
                  "justify-start",
                  "rounded-full",
                  "px-[3px]",
                ],
                ["navSize", "obSize"],
                ["id", "underway", 3, "ngClass", "click"],
                a,
                ["id", "finished", 3, "ngClass", "click"],
                n,
                [1, "_subscript", 3, "ngStyle"],
                ["tabsSlides", ""],
                [1, "flex", "items-center", "justify-center", 3, "click"],
                [1, "bg-text", "relative", "rounded-full", "px-2", "py-0.5", "text-sm", "font-medium", "text-white"],
                t,
                ["class", "bg-red absolute -top-0.5 right-0.5 h-1.5 w-1.5 rounded-full"],
                [
                  "wPullToRefresh",
                  "",
                  1,
                  "overflow-y-auto",
                  "px-4",
                  "pt-2",
                  2,
                  "height",
                  "calc(100% - 88px)",
                  3,
                  "emitDistance",
                  "maxDistance",
                  "pulled$",
                ],
                ["homeScrollView", ""],
                [1, "text-subtext"],
                [
                  "class",
                  "no-scrollbar w-full",
                  "wInfiniteScroll",
                  "",
                  3,
                  "infiniteScrollElement",
                  "hasMore",
                  "infinited$",
                  4,
                  "ngIf",
                  "ngIfElse",
                ],
                ["initLoadingView", ""],
                [
                  "class",
                  "h-40 absolute bottom-0 z-10 w-full !bg-gradient-to-t !from-white !to-transparent text-right",
                ],
                [1, "bg-red", "absolute", "-top-0.5", "right-0.5", "h-1.5", "w-1.5", "rounded-full"],
                [
                  "wInfiniteScroll",
                  "",
                  1,
                  "no-scrollbar",
                  "w-full",
                  3,
                  "infiniteScrollElement",
                  "hasMore",
                  "infinited$",
                ],
                ["dataListContent", ""],
                [4, "ngIf", "ngIfElse"],
                [4, "ngIf"],
                [1, "h-40", "w-full"],
                [1, "mb-2", 3, "click"],
                [1, "flex"],
                [1, "icon-16", "rounded-full", "overflow-hidden", 3, "defaultName", "iconUrl", "name"],
                [1, "ml-3", "mt-6", "w-full", "pr-4"],
                [1, "grid", "grid-cols-[auto,1rem]"],
                [1, "text-title", "overflow-hidden", "text-ellipsis", "text-xl", "font-bold"],
                ["name", "icon-chevron-right", 1, "icon-5", "text-title"],
                [1, "text-title-1", "text-xs"],
                ["bnRippleButton", "", "class", "text-xs text-primary"],
                [1, "absolute", "bottom-0", "flex", "w-full", "items-center", "justify-between", "pr-4"],
                [1, "relative", "flex", "items-center"],
                [1, "text-title", "flex", "items-center", "text-sm"],
                [1, "mx-[2px]", "text-[18px]", 3, "defaultName", "iconUrl", "name"],
                [1, "ml-[2px]"],
                i,
                [
                  1,
                  "rounded-bl-5",
                  "rounded-br-5",
                  "border-tiny",
                  "border-gray-1",
                  "w-full",
                  "border-t-transparent",
                  "px-4",
                  "py-4",
                ],
                [1, "flex", "items-center", "justify-end", "gap-1"],
                [1, "text-title-2", "text-xs"],
                ["name", "icon-timeline", 1, "icon-3.5", "text-title-2"],
                ["bnRippleButton", "", 1, "text-xs", "text-primary", 3, "click"],
                [1, "text-xs", "text-title-1", 2, "word-break", "break-all"],
                o,
                [1, "text-xs", "text-primary"],
                l,
                ["class", "participated-box h-8.5 z-10 flex items-center justify-center gap-1 pl-2 pr-4"],
                [
                  1,
                  "participated-box",
                  "h-8.5",
                  "z-10",
                  "flex",
                  "items-center",
                  "justify-center",
                  "gap-1",
                  "pl-2",
                  "pr-4",
                ],
                ["name", "icon-select", 1, "icon-3", "text-white"],
                [1, "whitespace-nowrap", "text-white"],
                d,
                [
                  1,
                  "h-8.5",
                  "not-participated-box",
                  "z-10",
                  "flex",
                  "items-center",
                  "justify-center",
                  "gap-1",
                  "px-2",
                  "pl-2",
                  "pr-4",
                ],
                ["name", "icon-select-no", 1, "icon-3", "text-white"],
                p,
                ["class", "h-8.5 not-participated-box z-10 flex items-center justify-center gap-1 px-2 pl-2 pr-4"],
                g,
                ["class", "h-8.5 failed-box z-10 flex items-center justify-center gap-1 pl-2 pr-4"],
                [1, "h-8.5", "failed-box", "z-10", "flex", "items-center", "justify-center", "gap-1", "pl-2", "pr-4"],
                ["name", "icon-miss", 1, "icon-3", "text-white"],
                T,
                v,
                [
                  1,
                  "h-8.5",
                  "win-box",
                  "z-10",
                  "flex",
                  "items-center",
                  "justify-center",
                  "gap-1",
                  "px-2",
                  "pl-2",
                  "pr-4",
                ],
                A,
                ["class", "mb-2"],
                [1, "text-sm"],
                E,
                [1, "flex", "h-full", "w-full", "flex-col", "items-center", "justify-center"],
                [1, "icon-6", 3, "showLoading"],
                w,
                [
                  1,
                  "h-40",
                  "absolute",
                  "bottom-0",
                  "z-10",
                  "w-full",
                  "!bg-gradient-to-t",
                  "!from-white",
                  "!to-transparent",
                  "text-right",
                ],
                [
                  "bnRippleButton",
                  "",
                  1,
                  "from-blue-0",
                  "to-blue-1",
                  "h-10",
                  "rounded-bl-full",
                  "rounded-tl-full",
                  "bg-gradient-to-r",
                  "px-4",
                  3,
                  "click",
                ],
                [3, "loadingTheme", "waitFor"],
                [1, "flex", "items-center", "justify-center", "gap-1"],
                ["name", "icon-all", 1, "icon-4.5", "text-primary-0"],
                [1, "text-sm", "text-white"],
                B,
                [1, "mt-20", "flex", "flex-col", "items-center", "justify-center"],
                ["src", "./assets/images/connect-wallet.png", 1, "h-30", "w-40"],
                [1, "text-title-2"],
                z,
                [1, "no-scrollbar", "flex", "w-full", "justify-center"],
                [1, "mt-25", "text-center"],
                ["src", "../../assets/images/stagging-empty.png", 1, "h-30", "mx-auto", "w-40", "flex-shrink-0"],
                [1, "text-title-2", "text-sm"],
                F,
                [3, "dataList", "thresholdMode"],
              ]
            );
          },
          template: function (n, t) {
            (1 & n &&
              (e.TgZ(0, "section", 0)(1, "div", 1, 2),
              e.NdJ("click", function () {
                return t.openSuccess();
              }),
              e.qZA(),
              e.YNc(3, ei, 21, 21)(4, ti, 4, 0),
              e.qZA(),
              e.YNc(5, ni, 5, 0, "ng-template", null, 3, e.W1O),
              e.TgZ(7, "common-bottom-sheet", 4),
              e.NdJ("isOpenChange", function (o) {
                return (t.selectAssetSheet.isOpen = o);
              }),
              e.YNc(8, ii, 1, 2, "ng-template"),
              e.qZA()),
              2 & n &&
                (e.xp6(3),
                e.um2(3, t.connectedWallet ? 3 : 4),
                e.xp6(4),
                e.Q6J("isOpen", t.selectAssetSheet.isOpen)("panelClass", "h-4/5")));
          },
          dependencies: [x.f5, ce.y, Gt.Q, Fe.I, U.O, On.s, dt.w, Ln.R, _.mk, _.O5, _.PC, O.oJ, L.G4, _.uU, _.ez, Mn.Z],
          styles: [
            "[_nghost-%COMP%]   ._subscript[_ngcontent-%COMP%]{position:absolute;--tw-bg-opacity: 1;background-color:rgb(255 255 255 / var(--tw-bg-opacity));height:calc(100% - 6px);width:50%;border-radius:1000px;top:50%;transform:translateY(-50%);--index: 0;z-index:-1;transition-duration:.2s;transition-timing-function:ease-out;box-shadow:0 2px 4px #08164414}[_nghost-%COMP%]   .underway-box[_ngcontent-%COMP%]{width:100%;background-image:url(color-bg.464e8743fe0ed581.png);background-size:100% 90%;background-repeat:no-repeat;background-position:bottom}[_nghost-%COMP%]   .underway-circle[_ngcontent-%COMP%]{background-image:url(color-circle.1cc4c57b5ff88176.png);background-size:contain;background-repeat:no-repeat}[_nghost-%COMP%]   .finished-box[_ngcontent-%COMP%]{width:100%;background-image:url(gray-bg.e9cf8c5791665985.png);background-size:100% 90%;background-repeat:no-repeat;background-position:bottom}[_nghost-%COMP%]   .finished-circle[_ngcontent-%COMP%]{background-image:url(gray-circle.27e378d6b7844975.png);background-size:contain;background-repeat:no-repeat}[_nghost-%COMP%]   .triangle-top[_ngcontent-%COMP%]{top:0;transform:translate(-50%,-50%);width:0px;height:0px;border:17px solid;border-color:transparent;border-top-color:#7928ff}[_nghost-%COMP%]   .triangle-bottom[_ngcontent-%COMP%]{bottom:0;transform:translate(-50%,50%);width:0px;height:0px;border:17px solid;border-color:transparent;border-bottom-color:#7928ff}[_nghost-%COMP%]   .triangle-top-no[_ngcontent-%COMP%]{top:0;transform:translate(-50%,-50%);width:0px;height:0px;border:17px solid;border-color:transparent;border-top-color:#d7c4fb}[_nghost-%COMP%]   .triangle-bottom-no[_ngcontent-%COMP%]{bottom:0;transform:translate(-50%,50%);width:0px;height:0px;border:17px solid;border-color:transparent;border-bottom-color:#d7c4fb}[_nghost-%COMP%]   .triangle-top-win[_ngcontent-%COMP%]{top:0;transform:translate(-50%,-50%);width:0px;height:0px;border:17px solid;border-color:transparent;border-top-color:#f8465c}[_nghost-%COMP%]   .triangle-bottom-win[_ngcontent-%COMP%]{bottom:0;transform:translate(-50%,50%);width:0px;height:0px;border:17px solid;border-color:transparent;border-bottom-color:#f8465c}[_nghost-%COMP%]   .triangle-top-win-no[_ngcontent-%COMP%]{top:0;transform:translate(-50%,-50%);width:0px;height:0px;border:17px solid;border-color:transparent;border-top-color:#abadc1}[_nghost-%COMP%]   .triangle-bottom-win-no[_ngcontent-%COMP%]{bottom:0;transform:translate(-50%,50%);width:0px;height:0px;border:17px solid;border-color:transparent;border-bottom-color:#abadc1}[_nghost-%COMP%]   .participated-box[_ngcontent-%COMP%]{min-width:100px;background-image:url(label-3.693e8844f5a8dc74.png);background-size:100% 100%;background-repeat:no-repeat}[_nghost-%COMP%]   .not-participated-box[_ngcontent-%COMP%]{min-width:100px;background-image:url(label-1.b19cbd2686f44b62.png);background-size:100% 100%;background-repeat:no-repeat}[_nghost-%COMP%]   .failed-box[_ngcontent-%COMP%]{min-width:100px;background-image:url(label-2.0382b901519f175f.png);background-size:100% 100%;background-repeat:no-repeat}[_nghost-%COMP%]   .win-box[_ngcontent-%COMP%]{min-width:100px;background-image:url(label-4.9bde6305a3e7d963.png);background-size:100% 100%;background-repeat:no-repeat}",
          ],
          data: { animation: [ve.Ps, ve.BU] },
          changeDetection: 0,
        })),
        (0, s.gn)([re.States(1), (0, s.w6)("design:type", Object)], re.prototype, "selectAssetSheet", void 0),
        (0, s.gn)(
          [
            re.OnInit(),
            (0, s.w6)("design:type", Function),
            (0, s.w6)("design:paramtypes", []),
            (0, s.w6)("design:returntype", Promise),
          ],
          re.prototype,
          "dataInit",
          null,
        ),
        (0, s.gn)(
          [
            re.OnDestroy(),
            (0, s.w6)("design:type", Function),
            (0, s.w6)("design:paramtypes", []),
            (0, s.w6)("design:returntype", void 0),
          ],
          re.prototype,
          "unsubscribe",
          null,
        ),
        (0, s.gn)([re.State(), (0, s.w6)("design:type", Object)], re.prototype, "pageListData", void 0),
        (0, s.gn)([re.State(), (0, s.w6)("design:type", Number)], re.prototype, "winCount", void 0),
        (0, s.gn)(
          [
            re.AfterViewInit(),
            (0, s.w6)("design:type", Function),
            (0, s.w6)("design:paramtypes", []),
            (0, s.w6)("design:returntype", void 0),
          ],
          re.prototype,
          "viewInit",
          null,
        ));
      const oi = re;
      var He,
        si = r(89813);
      const sn = (a, n) => ({ left: a, zIndex: n });
      function ai(a, n) {
        if ((1 & a && (e.ynx(0), e._UZ(1, "img", 4), e.BQk()), 2 & a)) {
          const t = n.ngIf,
            i = e.oxw(2).$index;
          (e.xp6(1), e.Akn(e.WLB(3, sn, "-" + 6 * i + "px", 1e3 - i)), e.Q6J("src", t, e.LSH));
        }
      }
      function ri(a, n) {
        if ((1 & a && e._UZ(0, "bs-icon", 5), 2 & a)) {
          const t = e.oxw(2),
            i = t.$index,
            o = t.$implicit,
            l = e.oxw();
          (e.Akn(e.WLB(5, sn, "-" + 6 * i + "px", 1e3 - i)),
            e.Q6J("defaultName", "token-Default")("iconUrl", l.handleIcon(o.chainName, o.coinName, !0))(
              "name",
              l.handleIcon(o.chainName, o.coinName),
            ));
        }
      }
      function li(a, n) {
        if ((1 & a && e.YNc(0, ai, 2, 6, "ng-container", 2)(1, ri, 1, 8, "ng-template", null, 3, e.W1O), 2 & a)) {
          const t = e.MAs(2),
            i = e.oxw().$implicit,
            o = e.oxw();
          e.Q6J("ngIf", o.handleLogoUrl(i.chainName, i.coinName))("ngIfElse", t);
        }
      }
      function ci(a, n) {
        (1 & a && e.YNc(0, li, 3, 2), 2 & a && e.um2(0, n.$index < 8 ? 0 : -1));
      }
      function di(a, n) {
        1 & a && (e.TgZ(0, "div", 6), e._UZ(1, "div", 7)(2, "div", 7)(3, "div", 7), e.qZA());
      }
      class ze extends si.t {
        constructor() {
          (super(...arguments),
            (this.tokenSize = "icon-8"),
            (this.size = 0),
            (this.sizeClass = {
              width: "width:2rem",
              chainSize: "font-size:1rem",
              coinSize: "font-size:2rem",
              chainTranslate: "transform: translate(0px,0px)",
            }),
            (this.getLogoUrlInfo = O.Yq),
            (this.logoChainName = ""));
        }
        init() {
          (this.handleSize(), this.cdRef.detectChanges());
        }
        handleSize() {
          const { size: n } = this;
          if (n > 0) {
            const d = n / 32;
            ((this.sizeClass.chainSize = `font-size:${16 * d}px`),
              (this.sizeClass.coinSize = `font-size:${32 * d}px`),
              (this.sizeClass.width = "width:" + 32 * d),
              (this.sizeClass.chainTranslate = `transform: translate(${6 * d}px,${8 * d}px)`));
          }
        }
        handleIcon(n, t, i = !1) {
          const d = (0, y.TH)(y.AG[n], t, i);
          return i ? d : "KMCTW" === t || "DOT" === t || "MVPC" === t ? "token-Default" : d;
        }
        handleLogoUrl(n, t) {
          return this.getLogoUrlInfo(t || "", y.AG[n]);
        }
      }
      (((He = ze).ɵfac = (() => {
        let a;
        return function (t) {
          return (a || (a = e.n5z(He)))(t || He);
        };
      })()),
        (He.ɵcmp = e.Xpm({
          type: He,
          selectors: [["bs-token-by-plate-icon"]],
          inputs: {
            tokenSize: "tokenSize",
            tokenList: "tokenList",
            size: "size",
          },
          standalone: !0,
          features: [e.qOj, e.jDz],
          decls: 4,
          vars: 1,
          consts: [
            [1, "flex", "items-center", "justify-center"],
            [
              "class",
              "relative -left-12 flex h-5 w-5 items-center justify-center gap-[2px] rounded-full bg-[rgba(255,255,255,0.32)]",
            ],
            [4, "ngIf", "ngIfElse"],
            ["iconViewByToken", ""],
            [1, "_asset_logo", "border-tiny", "relative", "rounded-full", "border-white", "text-base", 3, "src"],
            [
              1,
              "border-tiny",
              "relative",
              "rounded-full",
              "border-white",
              "text-base",
              3,
              "defaultName",
              "iconUrl",
              "name",
            ],
            [
              1,
              "relative",
              "-left-12",
              "flex",
              "h-5",
              "w-5",
              "items-center",
              "justify-center",
              "gap-[2px]",
              "rounded-full",
              "bg-[rgba(255,255,255,0.32)]",
            ],
            [1, "bg-title-2", "h-[2px]", "w-[2px]", "rounded-full"],
          ],
          template: function (n, t) {
            (1 & n &&
              (e.TgZ(0, "div", 0), e.SjG(1, ci, 1, 1, null, null, e.ikw), e.YNc(3, di, 4, 0, "div", 1), e.qZA()),
              2 & n && (e.xp6(1), e.wJu(t.tokenList), e.xp6(2), e.um2(3, t.tokenList.length > 8 ? 3 : -1)));
          },
          dependencies: [x.f5, _.O5, O.oJ],
          encapsulation: 2,
          changeDetection: 0,
        })),
        (0, s.gn)([ze.State(), (0, s.w6)("design:type", Object)], ze.prototype, "sizeClass", void 0),
        (0, s.gn)(
          [
            ze.OnChanges(),
            (0, s.w6)("design:type", Function),
            (0, s.w6)("design:paramtypes", []),
            (0, s.w6)("design:returntype", void 0),
          ],
          ze.prototype,
          "init",
          null,
        ));
      var qe,
        an = r(66722);
      const ui = ["tabsSlides"],
        _i = ["staggingPage"];
      function hi(a, n) {
        if (1 & a) {
          const t = e.EpF();
          (e.TgZ(0, "div", 11),
            e.NdJ("click", function () {
              const l = e.CHM(t).$implicit,
                d = e.oxw();
              return e.KtG(d.selectTab(l.index));
            }),
            e._uU(1),
            e.qZA());
        }
        if (2 & a) {
          const t = n.$implicit,
            i = e.oxw();
          (e.Gre("text-[1rem] font-semibold ", i.currentTabIdx === t.index ? "text-title" : "text-title-2", ""),
            e.s9C("id", t.id),
            e.xp6(1),
            e.hij(" ", t.label, " "));
        }
      }
      function pi(a, n) {
        if (1 & a) {
          const t = e.EpF();
          (e.TgZ(0, "div", 18),
            e.NdJ("click", function () {
              const l = e.CHM(t).$implicit,
                d = e.oxw(3);
              return e.KtG(d.goPlateDetail(l.plateId));
            }),
            e.TgZ(1, "h1", 19),
            e._uU(2),
            e.qZA(),
            e._UZ(3, "bs-token-by-plate-icon", 20),
            e.qZA());
        }
        if (2 & a) {
          const t = n.$implicit,
            i = n.$index;
          (e.Jzz("background-image: url('../../../assets/images/plate-", i <= 3 ? i : 0, ".png')"),
            e.xp6(2),
            e.Oqu(t.plateName),
            e.xp6(1),
            e.Q6J("tokenList", t.coins));
        }
      }
      function mi(a, n) {
        if ((1 & a && (e.TgZ(0, "section", 17), e.SjG(1, pi, 4, 5, "div", 21, e.ikw), e.qZA()), 2 & a)) {
          const t = e.oxw(2);
          (e.xp6(1), e.wJu(t.platesList));
        }
      }
      const gi = (a) => ({ "text-left": a });
      function fi(a, n) {
        if (1 & a) {
          const t = e.EpF();
          (e.TgZ(0, "div", 22),
            e.NdJ("click", function () {
              const l = e.CHM(t).$implicit,
                d = e.oxw(2);
              return e.KtG(d.handleFilterClick(l.key));
            }),
            e.TgZ(1, "div", 23),
            e._uU(2),
            e.qZA(),
            e.TgZ(3, "div", 24),
            e._UZ(4, "bs-icon", 25)(5, "bs-icon", 26),
            e.qZA()());
        }
        if (2 & a) {
          const t = n.$implicit,
            i = n.$index,
            o = e.oxw(2);
          (e.Q6J("ngClass", 0 === i ? "justify-start" : "justify-end"),
            e.xp6(1),
            e.Tol(e.VKq(10, gi, 0 === i)),
            e.xp6(1),
            e.Oqu(t.title),
            e.xp6(2),
            e.Gre("text-xxxs ", t.order === o.FILTER_VALUE_ENUM.ASC ? "" : "text-text", " "),
            e.xp6(1),
            e.Gre("text-xxxs ", t.order === o.FILTER_VALUE_ENUM.DESC ? "" : "text-text", ""));
        }
      }
      function Si(a, n) {
        if (1 & a) {
          const t = e.EpF();
          (e.TgZ(0, "li", 30),
            e.NdJ("click", function () {
              const l = e.CHM(t).$implicit,
                d = e.oxw(3);
              return e.KtG(d.goToDetailPage(l));
            }),
            e.TgZ(1, "div", 31),
            e._UZ(2, "bs-token-with-chain-icon", 32),
            e.TgZ(3, "div", 33)(4, "span", 34),
            e._uU(5),
            e.qZA(),
            e.TgZ(6, "span", 35),
            e._uU(7),
            e.qZA()()(),
            e.TgZ(8, "div", 36)(9, "span", 37),
            e._uU(10),
            e.ALo(11, "significantDigits"),
            e.qZA()(),
            e.TgZ(12, "div", 38)(13, "span", 36),
            e._uU(14),
            e.qZA()()());
        }
        if (2 & a) {
          const t = n.$implicit,
            i = e.oxw(3);
          (e.xp6(2),
            e.Q6J("swapCoinName", t.coinName)("swapChainName", t.chainName),
            e.xp6(3),
            e.hij(" ", t.coinName, " "),
            e.xp6(2),
            e.hij(" ", t.chainName, " "),
            e.xp6(3),
            e.hij("", e.lcZ(11, 7, t.price), " "),
            e.xp6(2),
            e.Q6J("ngClass", i.riseFallColor(t.fluctuation)),
            e.xp6(2),
            e.Oqu("--" === t.fluctuation ? "--" : (t.fluctuationNumber > 0 ? "+" : "") + t.fluctuation + "%"));
        }
      }
      function Ti(a, n) {
        if (1 & a) {
          const t = e.EpF();
          (e.TgZ(0, "ul", 27),
            e.NdJ("pulled$", function (o) {
              e.CHM(t);
              const l = e.oxw(2);
              return e.KtG(o.waitFor(l.regetMarketList()));
            }),
            e._UZ(1, "bn-pull-to-refresh-spinner", 28),
            e.SjG(2, Si, 15, 9, "li", 39, e.ikw),
            e._UZ(4, "li", 29),
            e.qZA());
        }
        if (2 & a) {
          const t = e.oxw(2);
          (e.Q6J("emitDistance", 158)("maxDistance", 200), e.xp6(2), e.wJu(t.marketListByFilter));
        }
      }
      function vi(a, n) {
        if (1 & a) {
          const t = e.EpF();
          (e.TgZ(0, "div", 41),
            e._UZ(1, "img", 42),
            e.TgZ(2, "span", 43),
            e.SDv(3, 44),
            e.qZA(),
            e.TgZ(4, "div", 45),
            e.NdJ("click", function () {
              e.CHM(t);
              const o = e.oxw(3);
              return e.KtG(o.nav.routeTo("add-liquidity"));
            }),
            e.SDv(5, 46),
            e.qZA()());
        }
      }
      function bi(a, n) {
        1 & a && (e.TgZ(0, "div", 41), e._UZ(1, "span", 47), e.qZA());
      }
      function Ai(a, n) {
        if ((1 & a && e.YNc(0, vi, 6, 0, "div", 40)(1, bi, 2, 0), 2 & a)) {
          const t = e.oxw(2);
          e.um2(0, t.marketListUpdating ? 1 : 0);
        }
      }
      function Ci(a, n) {
        if (
          (1 & a &&
            (e.TgZ(0, "section", 12),
            e.YNc(1, mi, 3, 0, "section", 13),
            e.TgZ(2, "header", 14),
            e.SjG(3, fi, 6, 12, "div", 48, e.ikw),
            e.qZA(),
            e.TgZ(5, "div", 15),
            e.YNc(6, Ti, 5, 2, "ul", 16)(7, Ai, 2, 1),
            e.qZA()()),
          2 & a)
        ) {
          const t = e.oxw();
          (e.xp6(1),
            e.um2(1, t.platesList.length ? 1 : -1),
            e.xp6(2),
            e.wJu(t.filterOptions),
            e.xp6(3),
            e.um2(6, t.marketList.length ? 6 : 7));
        }
      }
      function Ei(a, n) {
        1 & a && (e.TgZ(0, "section", 12), e._UZ(1, "bs-stagging", null, 49), e.qZA());
      }
      const yi = () => ({ "--page-safe-area-inset-top": 0 }),
        Ni = (a) => ({ "--index": a }),
        xi = (a) => ({ "--color-1": a });
      class X extends (0, f.To)(x.Wh) {
        constructor() {
          (super(...arguments),
            (this.marketTabs = [
              { label: "\u5E02\u573A", id: "market", index: 0 },
              { label: "\u6253\u65B0", id: "stagging", index: 1 },
            ]),
            (this.currentTabIdx = 0),
            (this.platesList = []),
            (this.FILTER_VALUE_ENUM = q),
            (this.commonServer = (0, e.f3M)(Re._)),
            (this.UName = ""),
            (this.filterOptions = [
              { title: "\u540D\u79F0", key: ke.NAME, order: q.DEFAULT },
              {
                title: "\u4EF7\u683C" + `(${this.UName})`,
                key: ke.PRICE,
                order: q.DEFAULT,
              },
              {
                title: "\u6DA8\u8DCC(24h)",
                key: ke.FLUCTUATION,
                order: q.DEFAULT,
              },
            ]),
            (this.poolService = (0, e.f3M)(Be.X)),
            (this.walletService = (0, e.f3M)(R.X)),
            (this.marketService = (0, e.f3M)(Pn.j)),
            (this.plateStaggingService = (0, e.f3M)(nn.P)),
            (this.marketList = []),
            (this.inited = !1),
            (this.marketListUpdating = !1),
            (this.poolDetailChangeHandle = (n) => {
              const t = JSON.parse(n);
              if (
                (this.console.info("websocket pool price:market page", t),
                null == t || t.length <= 0 || 0 == this.inited)
              )
                return;
              const i = this.marketList;
              t.forEach((o) => {
                const l = i.find((d) => o.poolId == d.poolId);
                if (l) {
                  this.console.info("websocket pool price: check", l);
                  const d = (0, lt.S)(o);
                  d &&
                    ((l.fluctuation = d.fluctuation),
                    (l.fluctuationNumber = d.fluctuationNumber),
                    (l.price = d.price),
                    this.console.info("websocket pool price: to =>", d),
                    this.marketService.updateMarketList(this.marketList),
                    this.cdRef.detectChanges());
                }
              });
            }));
        }
        dataInit() {
          var n = this;
          return (0, c.Z)(function* () {
            ((n.subscription = n.commonServer.virtualCoinAlias.subscribe((t) => {
              ((n.UName = t), (n.filterOptions[1].title = "\u4EF7\u683C" + `(${n.UName})`), n.cdRef.detectChanges());
            })),
              (n.platesList = yield n.plateStaggingService.getPlateList()),
              n.poolService.watchLiquidityPoolPriceChange(n.poolDetailChangeHandle),
              (n.marketList = yield n.marketService.getLiquidityPoolMarket()),
              n.console.log("Lifecycle MarketPage init:watchLiquidityPoolPriceChange"),
              n.initRemoteData(),
              n.selectTab(0));
          })();
        }
        initRemoteData() {
          var n = this;
          return (0, c.Z)(function* () {
            !1 === n.marketListUpdating && n.marketList.length <= 0 && (n.marketListUpdating = !0);
            const t = yield n.poolService.wsGetLiquidityPoolMarketList();
            ((n.marketList = (0, lt.t)(t)),
              n.marketService.updateMarketList(n.marketList),
              (n.marketListUpdating = !1),
              (n.inited = !0),
              n.console.log("MarketPage init", "get market list", t));
          })();
        }
        selectTab(n) {
          var t = this;
          return (0, c.Z)(function* () {
            t.currentTabIdx = n;
            const i = document.getElementById(t.marketTabs[n].id);
            if (t.subscriptRef && i) {
              const o = document.getElementById(t.marketTabs[0].id);
              t.renderer2.setStyle(
                t.subscriptRef.nativeElement,
                "left",
                i.clientWidth / 2 + t.currentTabIdx * (o.clientWidth + 16) - 10 + "px",
              );
            }
            0 === t.currentTabIdx && (t.platesList = yield t.plateStaggingService.getPlateList());
          })();
        }
        unsubscribe() {
          (this.console.log("\u6e05\u9664 \u8ba2\u9605"),
            this.poolList$ && this.poolList$.unsubscribe(),
            this.poolDetailChange$ && this.poolDetailChange$.unsubscribe(),
            this.walletService.allSubscribes.delete("MarketPage"),
            this.subscription && this.subscription.unsubscribe());
        }
        get marketListByFilter() {
          return this.activeFilter
            ? this.activeFilter.key === ke.PRICE
              ? this.marketList.sort((n, t) => {
                  var i;
                  const o = new N.Z(n.price),
                    l = new N.Z(t.price);
                  return (null === (i = this.activeFilter) || void 0 === i ? void 0 : i.value) === q.DESC
                    ? l.comparedTo(o)
                    : o.comparedTo(l);
                })
              : this.activeFilter.key === ke.NAME
                ? this.marketList.sort((n, t) => {
                    var i;
                    return (null === (i = this.activeFilter) || void 0 === i ? void 0 : i.value) === q.DESC
                      ? t.coinName > n.coinName
                        ? 1
                        : -1
                      : n.coinName > t.coinName
                        ? 1
                        : -1;
                  })
                : this.activeFilter.key === ke.FLUCTUATION
                  ? this.marketList.sort((n, t) => {
                      var i;
                      const o = new N.Z(t.fluctuation || "0"),
                        l = new N.Z(n.fluctuation || "0");
                      return (null === (i = this.activeFilter) || void 0 === i ? void 0 : i.value) === q.DESC
                        ? o.comparedTo(l)
                        : l.comparedTo(o);
                    })
                  : this.marketList
            : this.marketList;
        }
        getIconByFilterKey(n) {
          return this.activeFilter && this.activeFilter.key == n ? tn[this.activeFilter.value] : tn[q.DEFAULT];
        }
        riseFallColor(n) {
          const t = localStorage.getItem("risefallColor") || "riseGreenFallRed";
          return "--" !== n && +n > 0
            ? "riseGreenFallRed" === t
              ? "text-green"
              : "text-red"
            : "--" !== n && +n < 0
              ? "riseGreenFallRed" === t
                ? "text-red"
                : "text-green"
              : "text-title-2";
        }
        handleFilterClick(n) {
          if (0 != this.marketList.length) {
            if (this.activeFilter) {
              const { key: t, value: i } = this.activeFilter;
              t == n
                ? (this.activeFilter.value = i == q.ASC ? q.DESC : q.ASC)
                : (this.activeFilter = { key: n, value: q.ASC });
            } else this.activeFilter = { key: n, value: q.ASC };
            this.filterOptions.forEach((t) => {
              const { key: i } = t,
                { key: o, value: l } = this.activeFilter;
              t.order = i === o ? l : q.DEFAULT;
            });
          }
        }
        goToDetailPage(n) {
          this.nav.routeTo("liquidity-detail", {
            poolDetailstring: JSON.stringify(n),
          });
        }
        pageOnPause() {
          (this.poolService.unwatchLiquidityPoolPriceChange(this.poolDetailChangeHandle),
            this.console.log("Lifecycle MarketPage pause: unwatchLiquidityPoolPriceChange"));
        }
        pageOnResume() {
          var n = this;
          return (0, c.Z)(function* () {
            if (
              (n.poolService.watchLiquidityPoolPriceChange(n.poolDetailChangeHandle),
              n.console.log("Lifecycle MarketPage Resume: watchLiquidityPoolPriceChange"),
              1 === n.currentTabIdx)
            ) {
              const t = n.child;
              (yield t.getWinUnpaidCount(), yield t.refreshList(), t.cdRef.detectChanges());
            }
            yield n.regetMarketList();
          })();
        }
        regetMarketList() {
          var n = this;
          return (0, c.Z)(function* () {
            const t = yield n.poolService.wsGetLiquidityPoolMarketList();
            ((n.marketList = (0, lt.t)(t)),
              n.marketService.updateMarketList(n.marketList),
              n.console.log("MarketPage get market list", t));
          })();
        }
        goSearch() {
          this.nav.routeTo("/searching");
        }
        goPlateDetail(n) {
          this.nav.routeTo("/plate-detail", { plateId: n });
        }
      }
      (((qe = X).ɵfac = (() => {
        let a;
        return function (t) {
          return (a || (a = e.n5z(qe)))(t || qe);
        };
      })()),
        (qe.ɵcmp = e.Xpm({
          type: qe,
          selectors: [["bs-market-page"]],
          viewQuery: function (n, t) {
            if ((1 & n && (e.Gf(ui, 5), e.Gf(_i, 5)), 2 & n)) {
              let i;
              (e.iGM((i = e.CRH())) && (t.subscriptRef = i.first), e.iGM((i = e.CRH())) && (t.child = i.first));
            }
          },
          standalone: !0,
          features: [e.qOj, e.jDz],
          decls: 15,
          vars: 14,
          consts: () => {
            let a, n, t;
            return (
              (a = "\u540D\u79F0"),
              (n = "\u5C1A\u672A\u521B\u5EFA\u4EA4\u6613\u6C60"),
              (t = "\u589E\u52A0\u6D41\u52A8\u6027"),
              [
                [3, "headerTitle", "ngStyle", "hideHeader"],
                [1, "h-full", "overflow-hidden", "pt-4"],
                [1, "flex", "h-10", "items-center", "justify-between", "px-4"],
                [
                  "wObSize",
                  "",
                  1,
                  "grid-in-[tabs]",
                  "relative",
                  "z-[2]",
                  "flex",
                  "items-center",
                  "justify-start",
                  "gap-4",
                ],
                ["navSize", "obSize"],
                [1, "_subscript", 3, "ngStyle"],
                ["tabsSlides", ""],
                [1, "bg-gray-0", "min-w-24", "flex", "h-9", "w-24", "items-center", "rounded-full"],
                [
                  "type",
                  "text",
                  "disabled",
                  "",
                  "placeholder",
                  a,
                  1,
                  "placeholder-title-2",
                  "h-full",
                  "w-full",
                  "pl-3",
                  "text-sm",
                  "font-normal",
                  3,
                  "click",
                ],
                ["name", "icon-search", 1, "icon-5", "ml-4", "mr-2", "flex-shrink-0", 3, "click"],
                ["class", "h-full"],
                [2, "white-space", "nowrap", 3, "id", "click"],
                [1, "h-full"],
                ["class", "plate-box mt-4 flex items-center justify-start gap-2 overflow-x-auto px-4"],
                [1, "text-title-1", "grid", "h-12", "grid-cols-[8.2rem,auto,5rem]", "py-3", "pl-8", "pr-6"],
                [
                  "bnRestoreScrollPosition",
                  "",
                  1,
                  "_market-list-height",
                  "flex",
                  "w-full",
                  "flex-col",
                  "overflow-y-auto",
                  "rounded-t-2xl",
                  "bg-white",
                  "px-4",
                ],
                ["wPullToRefresh", "", 3, "emitDistance", "maxDistance"],
                [1, "plate-box", "mt-4", "flex", "items-center", "justify-start", "gap-2", "overflow-x-auto", "px-4"],
                [
                  1,
                  "w-37.5",
                  "min-w-37.5",
                  "h-26",
                  "flex",
                  "flex-col",
                  "items-start",
                  "justify-between",
                  "bg-contain",
                  "bg-no-repeat",
                  "p-4",
                  3,
                  "click",
                ],
                [1, "mb-3", "text-sm", "text-white"],
                [3, "tokenList"],
                [
                  "class",
                  "w-37.5 min-w-37.5 h-26 flex flex-col items-start justify-between bg-contain bg-no-repeat p-4",
                  3,
                  "style",
                ],
                [1, "flex", "items-center", "text-xs", 3, "ngClass", "click"],
                [1, "mb-0.5"],
                [1, "ml-1", "flex", "flex-col"],
                ["name", "icon-arrowhead-top"],
                ["name", "icon-arrowhead-down"],
                ["wPullToRefresh", "", 3, "emitDistance", "maxDistance", "pulled$"],
                [1, "text-subtext"],
                [1, "h-28", "w-full"],
                [
                  1,
                  "bg-gray-pale",
                  "rounded-5",
                  "mb-2",
                  "grid",
                  "grid-cols-[8.2rem,auto,5rem]",
                  "items-center",
                  "px-4",
                  "py-5",
                  "font-semibold",
                  3,
                  "click",
                ],
                [1, "flex", "w-full", "items-center"],
                [3, "swapCoinName", "swapChainName"],
                [1, "ml-2", "flex", "flex-col", "overflow-hidden", "text-ellipsis", "text-base"],
                [1, "overflow-hidden", "text-ellipsis"],
                [1, "text-title-2", "overflow-hidden", "text-ellipsis", "text-xs", "font-normal"],
                [1, "flex", "items-center", "justify-end", "overflow-hidden", "text-ellipsis"],
                [1, "mr-0.5", "overflow-hidden", "text-ellipsis"],
                [1, "flex", "w-full", "flex-col", "justify-end", 3, "ngClass"],
                [
                  "class",
                  "bg-gray-pale rounded-5 mb-2 grid grid-cols-[8.2rem,auto,5rem] items-center px-4 py-5 font-semibold",
                ],
                ["class", "flex h-full w-full flex-col items-center justify-center"],
                [1, "flex", "h-full", "w-full", "flex-col", "items-center", "justify-center"],
                ["src", "./assets/images/placeholder-2.png", 1, "-mt-30", "h-30", "w-40"],
                [1, "text-line", "text-sm", "text-gray-400"],
                n,
                [1, "duibs-btn", "duibs-btn-primary", "mt-8", "w-[10.25rem]", "rounded-full", "text-white", 3, "click"],
                t,
                [1, "duibs-loading", "duibs-loading-infinity", "duibs-loading-lg", "text-primary"],
                ["class", "flex items-center text-xs", 3, "ngClass"],
                ["staggingPage", ""],
                ["style", "white-space: nowrap", 3, "id", "class"],
              ]
            );
          },
          template: function (n, t) {
            (1 & n &&
              (e.TgZ(0, "common-page", 0)(1, "div", 1)(2, "div", 2)(3, "nav", 3, 4),
              e.SjG(5, hi, 2, 5, "div", 50, e.ikw),
              e._UZ(7, "div", 5, 6),
              e.qZA(),
              e.TgZ(9, "div", 7)(10, "input", 8),
              e.NdJ("click", function () {
                return t.goSearch();
              }),
              e.qZA(),
              e.TgZ(11, "bs-icon", 9),
              e.NdJ("click", function () {
                return t.goSearch();
              }),
              e.ALo(12, "color"),
              e.qZA()()(),
              e.YNc(13, Ci, 8, 2, "section", 10)(14, Ei, 3, 0),
              e.qZA()()),
              2 & n &&
                (e.Q6J("headerTitle", "Market")("ngStyle", e.DdM(9, yi))("hideHeader", !0),
                e.xp6(5),
                e.wJu(t.marketTabs),
                e.xp6(2),
                e.Q6J("ngStyle", e.VKq(10, Ni, t.currentTabIdx || 0)),
                e.xp6(4),
                e.Akn(e.VKq(12, xi, e.lcZ(12, 7, "title"))),
                e.xp6(2),
                e.um2(13, 0 === t.currentTabIdx ? 13 : 14)));
          },
          dependencies: [In.i, x.f5, Fe.I, U.O, dt.w, an.B, _.mk, _.PC, ee.C, O.oJ, be.z, _.ez, Zt.V, ze, oi, S.R9],
          styles: [
            "._market-list-height[_ngcontent-%COMP%]{height:calc(100% - 4.2rem)}.plate-box[_ngcontent-%COMP%]{scroll-snap-type:x mandatory}.plate-box[_ngcontent-%COMP%]::-webkit-scrollbar{display:none}._subscript[_ngcontent-%COMP%]{position:absolute;--tw-bg-opacity: 1;background-color:rgb(100 15 243 / var(--tw-bg-opacity));height:4px;width:24px;border-radius:40px;bottom:-70%;--index: 0;transition-duration:.2s;transition-timing-function:ease-out}",
          ],
          changeDetection: 0,
        })),
        (0, s.gn)([X.States(), (0, s.w6)("design:type", Array)], X.prototype, "platesList", void 0),
        (0, s.gn)([X.States(1), (0, s.w6)("design:type", Object)], X.prototype, "activeFilter", void 0),
        (0, s.gn)([X.State(), (0, s.w6)("design:type", Array)], X.prototype, "marketList", void 0),
        (0, s.gn)([X.State(), (0, s.w6)("design:type", Object)], X.prototype, "inited", void 0),
        (0, s.gn)([X.State(), (0, s.w6)("design:type", Object)], X.prototype, "marketListUpdating", void 0),
        (0, s.gn)(
          [
            X.OnInit(),
            (0, s.w6)("design:type", Function),
            (0, s.w6)("design:paramtypes", []),
            (0, s.w6)("design:returntype", Promise),
          ],
          X.prototype,
          "dataInit",
          null,
        ),
        (0, s.gn)(
          [
            X.OnDestroy(),
            (0, s.w6)("design:type", Function),
            (0, s.w6)("design:paramtypes", []),
            (0, s.w6)("design:returntype", void 0),
          ],
          X.prototype,
          "unsubscribe",
          null,
        ),
        (0, s.gn)(
          [
            X.OnPause(),
            (0, s.w6)("design:type", Function),
            (0, s.w6)("design:paramtypes", []),
            (0, s.w6)("design:returntype", void 0),
          ],
          X.prototype,
          "pageOnPause",
          null,
        ),
        (0, s.gn)(
          [
            X.OnResume(),
            (0, s.w6)("design:type", Function),
            (0, s.w6)("design:paramtypes", []),
            (0, s.w6)("design:returntype", Promise),
          ],
          X.prototype,
          "pageOnResume",
          null,
        ));
      const Pi = X;
      var Qe,
        Ii = r(87490),
        rn = r(57461),
        tt = r(56789),
        ln = r(3675),
        ne = r(40103),
        Bt = r(69675),
        wi = r(57644);
      function Mi(a, n) {
        if (
          (1 & a &&
            (e.TgZ(0, "div", 39), e._UZ(1, "bs-swap-token-chain-icon", 40), e.TgZ(2, "div", 41), e._uU(3), e.qZA()()),
          2 & a)
        ) {
          const t = e.oxw();
          (e.xp6(1), e.Q6J("swapChainName", t.sellPanel.chain), e.xp6(2), e.Oqu(t.sellPanel.chain));
        }
      }
      function Oi(a, n) {
        if (
          (1 & a &&
            (e.TgZ(0, "div", 39), e._UZ(1, "bs-swap-token-chain-icon", 40), e.TgZ(2, "div", 41), e._uU(3), e.qZA()()),
          2 & a)
        ) {
          const t = e.oxw();
          (e.xp6(1), e.Q6J("swapChainName", t.buyPanel.chain), e.xp6(2), e.Oqu(t.buyPanel.chain));
        }
      }
      const Li = () => ({ havePercent: !0 });
      class I extends x.Wh {
        constructor() {
          (super(...arguments),
            (this.service = (0, e.f3M)(rn.H)),
            (this.commonService = (0, e.f3M)(Re._)),
            (this.uName = this.commonService.virtualCoinAliasValue),
            (this.walletService = (0, e.f3M)(R.X)),
            (this.leastGainAmount = "0"),
            (this.transactionFee = "0"),
            (this.feeRatio = "0"),
            (this.slippageTolerance = ""),
            (this.expirationTime = ""),
            (this.addLiquidityRatio = ""),
            (this.priceSell = "0"),
            (this.priceBuy = "0"),
            (this.expectBuyAmount = ""),
            (this.expectSellAmount = ""),
            (this.returnValue$ = new x.sS()),
            (this.btnText = "\u786E\u8BA4\u5151\u6362"),
            (this.loading = !1),
            (this.disabled = !1),
            (this.sellCoinIcon = void 0),
            (this.sellChainIcon = void 0),
            (this.buyCoinIcon = void 0),
            (this.buyChainIcon = void 0),
            (this.platformFee = ""),
            (this.showAddLiquidityDetail = !1),
            (this.sellCoinIsU = !1),
            (this.buyCoinIsU = !1),
            (this.expectedIncreasedLiquiditys = []),
            (this.price = {
              leftCoin: void 0,
              rightCoin: void 0,
              forwordPrice: ne.qn.AMOUNT_NONE,
              backwordPirce: ne.qn.AMOUNT_NONE,
              showPrice: ne.qn.AMOUNT_NONE,
              direction: ne.SC.BACKWARD,
            }));
        }
        transferToTokenIconBychainName(n, t) {
          return (0, y.TH)(n, t);
        }
        judgeCoinIsU(n, t) {
          ((this.sellCoinIsU = n === G.BNQKL_SWAP_COIN_NAME.USDM),
            (this.buyCoinIsU = t === G.BNQKL_SWAP_COIN_NAME.USDM));
        }
        toggleShowDetail() {
          this.showAddLiquidityDetail = !this.showAddLiquidityDetail;
        }
        init() {
          const { sellPanel: n, buyPanel: t } = this;
          if (void 0 === n || void 0 === t) return;
          const { coin: i } = n,
            { coin: o } = t;
          if (void 0 === i || void 0 === o) return;
          const { slippageTolerance: l, expirationTime: d, addLiquidityRatio: p } = this.service.getSelectedValue();
          if (void 0 === l || void 0 === d) return;
          ((this.slippageTolerance = l.label), (this.expirationTime = d.label), (this.addLiquidityRatio = p.label));
          const g = new N.Z(1).minus(p.value);
          this.expectSellAmount = tt.Q.transform(g.multipliedBy(this.sellPanel.amount).toFixed(8, 1));
          const v = this.buyPanel.amount;
          ((this.transactionFee = tt.Q.transform(
            new N.Z(this.expectSellAmount).multipliedBy(this.platformFee).toFixed(8, 1),
          )),
            (this.feeRatio = new N.Z(this.platformFee).multipliedBy(100).toString()),
            (this.priceSell = tt.Q.transform(new N.Z(this.expectBuyAmount).div(this.expectSellAmount).toFixed(8, 1))),
            (this.priceBuy = tt.Q.transform(new N.Z(this.expectSellAmount).div(this.expectBuyAmount).toFixed(8, 1))),
            this.handlePriceCaculate(i, this.expectSellAmount, o, this.expectBuyAmount));
          const A = new N.Z(1).minus(l.value),
            E = tt.Q.transform(A.multipliedBy(this.expectBuyAmount).toFixed(8, 1));
          ((this.leastGainAmount = 0 === Number(E) ? v : E),
            this.judgeCoinIsU(n.coin, t.coin),
            this.handleAddLiquidityInfo(),
            this.initIcon());
        }
        handleAddLiquidityInfo() {
          if (this.preParams) {
            const { expectedIncreasedLiquiditys: n } = this.preParams;
            if (n) {
              const t = n.length;
              this.expectedIncreasedLiquiditys = n.map((i) => {
                const l = (0, y.kI)(y.AG[i.anchorCoinsChainName] || "Default"),
                  d = (0, y.Oq)(i.anchorCoinsChainName, i.anchorCoinsName),
                  p = 1 === t ? y.FN[this.buyPanel.chain] : i.quoteCoinsChainName,
                  T = (0, y.kI)(y.AG[p] || "Default"),
                  v = (0, y.Oq)(p, i.quoteCoinsName),
                  A =
                    i.quoteCoinsChainName === G.BNQKL_SWAP_CHAIN_NAME.SWAP &&
                    i.quoteCoinsName === G.BNQKL_SWAP_COIN_NAME.USDM;
                return {
                  ...i,
                  anchorChainIcon: l,
                  anchorCoinIcon: d,
                  quoteChainIcon: T,
                  quoteCoinIcon: v,
                  isBigU: A,
                };
              });
            }
          }
        }
        initIcon() {
          const { sellPanel: n, buyPanel: t } = this;
          ((this.sellCoinIcon = (0, y.Oq)(y.FN[n.chain], n.coin)),
            (this.sellChainIcon = (0, y.kI)(n.chain || "Default")),
            (this.buyCoinIcon = (0, y.Oq)(y.FN[t.chain], t.coin)),
            (this.buyChainIcon = (0, y.kI)(t.chain || "Default")));
        }
        submit() {
          var n = this;
          return (0, c.Z)(function* () {
            const { preParams: t, transferOptions: i } = n;
            if (void 0 === t || void 0 === i)
              return (
                n.console.error("\u5151\u6362\u9762\u677f\u6570\u636e\u51fa\u9519\uff1a", t, i),
                void $.F.show("\u6570\u636E\u9519\u8BEF")
              );
            ((n.btnText = "\u7B7E\u540D\u8BF7\u6C42\u4E2D"), (n.loading = !0), (n.disabled = !0));
            {
              /// lsy 涨跌停
              const todayPriceRes = yield n.service.orderService.getLiquidityPoolReportTodayPrice({
                poolId: n.preParams.transaction.sellCoinOptions.poolId,
              });
               if (todayPriceRes && !!todayPriceRes.startPrice) {
                const { startPrice, firstDay } = todayPriceRes;
                let topRate = firstDay ? 1.2 : 1.1;
                let dropRate = firstDay ? 0.8 : 0.9;
                const topLimit = Number(startPrice) * topRate;
                const dropLimit = Number(startPrice) * dropRate;
                // sellCoinOptions;
                // buyCoinOptions.amount;
                const nowPrice =
                  Number(n.preParams.transaction.sellCoinOptions.quoteCoinsAmount) /
                  Number(n.preParams.transaction.sellCoinOptions.anchorCoinsAmount);
                const transferAsset = n.transferOptions.amount;
                // 卖出
                let exceptPrice = 0;
                if (n.buyPanel.coin === "USDT") {
                  exceptPrice =
                    (Number(n.preParams.transaction.sellCoinOptions.quoteCoinsAmount) -
                      Number(n.preParams.transaction.buyCoinOptions.amount)) /
                    (Number(n.preParams.transaction.sellCoinOptions.anchorCoinsAmount) + Number(transferAsset));
                } else {
                  exceptPrice =
                    (Number(n.preParams.transaction.sellCoinOptions.quoteCoinsAmount) + Number(transferAsset)) /
                    (Number(n.preParams.transaction.sellCoinOptions.anchorCoinsAmount) -
                      Number(n.preParams.transaction.buyCoinOptions.amount));
                }

                if (exceptPrice > topLimit) {
                  n.loading = !1;
                  n.disabled = !1;
                  $.F.show("已涨停");
                  return;
                } else if (exceptPrice < dropLimit) {
                  n.loading = !1;
                  n.disabled = !1;
                  $.F.show("已跌停");
                  return;
                }
              }
            }
            const o = yield n.walletService.getSwapOrderInfoWithSignature(t, i);
            (n.console.log(o),
              n.loading && o
                ? (ln.N.DWEB_APP && ct.dq.focusWindow(), n.returnValue$.return({ transactionData: o }), n.nav.back())
                : (void 0 === o
                    ? $.F.show("\u672A\u8FDE\u63A5\u94B1\u5305")
                    : null === o
                      ? ($.F.show("\u7B7E\u540D\u5DF2\u62D2\u7EDD"), ln.N.DWEB_APP && ct.dq.focusWindow())
                      : $.F.show("\u7B7E\u540D\u9519\u8BEF"),
                  (n.btnText = "\u786E\u8BA4\u5151\u6362"),
                  n.console.error("\u7b7e\u540d\u51fa\u9519:sinature:", o)),
              (n.disabled = !1),
              (n.loading = !1));
          })();
        }
        handleClose() {
          ((this.disabled = !1), (this.loading = !1), $.F.show("\u53D6\u6D88"), this.nav.back());
        }
        handleReversePrice() {
          Object.assign(this.price, (0, ne.ML)(this.price));
        }
        handlePriceCaculate(n, t, i, o) {
          if (0 === Number(t) || 0 === Number(o)) return void this.console.log("\u6570\u91cf\u4e0d\u80fd\u4e3a\u96f6");
          this.price.direction = ne.SC.FORWARD;
          const l = Number(new N.Z(t).dividedBy(o).toFixed(8, 1)).toString(),
            d = Number(new N.Z(o).dividedBy(t).toFixed(8, 1)).toString(),
            g = (0, ne.JV)(i, l, n, d, {
              direction: ne.SC.FORWARD,
              format: !1,
            });
          this.price = g;
        }
      }
      (((Qe = I).ɵfac = (() => {
        let a;
        return function (t) {
          return (a || (a = e.n5z(Qe)))(t || Qe);
        };
      })()),
        (Qe.ɵcmp = e.Xpm({
          type: Qe,
          selectors: [["bs-swap-detail-panel-page"]],
          inputs: {
            sellPanel: "sellPanel",
            buyPanel: "buyPanel",
            preParams: "preParams",
            transferOptions: "transferOptions",
            expectBuyAmount: "expectBuyAmount",
            platformFee: "platformFee",
          },
          outputs: { returnValue$: "returnValue$" },
          standalone: !0,
          features: [e.qOj, e.jDz],
          decls: 68,
          vars: 45,
          consts: () => {
            let a, n, t, i, o, l, d, p, g, T;
            return (
              (a = "\u5151\u6362\u8BE6\u60C5"),
              (n = "\u652F\u4ED8"),
              (t = "\u83B7\u5F97"),
              (i = "\u53D1\u8D77\u4EF7\u683C"),
              (o = "\u6700\u5C0F\u63A5\u6536\u989D"),
              (l = "\u6D41\u52A8\u6C60\u624B\u7EED\u8D39 (" + "\ufffd0\ufffd" + ")"),
              (d = "\u6ED1\u70B9\u5BB9\u5FCD\u5EA6"),
              (p = "\u622A\u6B62\u65F6\u95F4"),
              (g = "" + "\ufffd0\ufffd" + ""),
              (T =
                "\u83B7\u5F97\u91CF\u662F\u9884\u4F30\u503C\uFF0C\u6CE8\u610F\u9884\u7559\u7F51\u7EDC\u8D39\u4E8E\u94B1\u5305\u7B7E\u540D"),
              [
                [
                  "headerTitle",
                  a,
                  3,
                  "hideBackButton",
                  "headerClass",
                  "contentBackground",
                  "contentSafeArea",
                  "contentClass",
                  "footerClass",
                ],
                ["endMenu", "", "bnRippleButton", "", 1, "icon-7", 3, "mode", "click"],
                ["name", "icon-popup-close"],
                [1, "h-full", "max-h-[60vh]", "overflow-scroll"],
                [1, "rounded-4", "bg-gray-pale", "mb-4", "mt-2.5", "flex", "items-center", "p-3"],
                [1, "text-base", "font-bold"],
                n,
                [1, "ml-auto", "text-base", "font-bold"],
                [1, "text-title-1", "mx-1", "text-xs", "font-normal"],
                [3, "size", "swapCoinName", "swapChainName"],
                [1, "rounded-4", "bg-gray-pale", "mb-2", "p-3"],
                [1, "mb-3", "flex", "items-center"],
                t,
                [1, "bg-gray-pale", "rounded-2", "mb-3", "p-2"],
                [1, "flex", "items-center"],
                [3, "swapCoinName", "swapChainName"],
                [1, "text-title-1", "mx-1"],
                ["class", "bg-blue-pale rounded-1 flex items-center border border-white pr-1"],
                [1, "text-title-1", "ml-auto"],
                [1, "flex", "justify-end"],
                ["name", "icon-arrow-down", 1, "text-title-2", "text-xl"],
                [1, "text-title-2", "grid", "grid-cols-[1fr,auto]", "items-center", "gap-y-2", "text-xs"],
                [1, "text-title-2", "whitespace-nowrap"],
                i,
                [1, "text-title-1", "flex", "items-center", "text-right"],
                ["name", "icon-swap-horizonal-small", 1, "ml-1", "text-lg", 3, "click"],
                [1, "whitespace-nowrap"],
                o,
                [1, "text-title-1", "text-right"],
                l,
                d,
                p,
                g,
                ["footer", ""],
                [1, "text-title-2", "my-1.5", "text-center", "text-xs"],
                T,
                [
                  "bnRippleButton",
                  "",
                  1,
                  "from-blue-0",
                  "to-blue-1",
                  "rounded-12",
                  "flex",
                  "h-12",
                  "w-full",
                  "items-center",
                  "justify-center",
                  "bg-gradient-to-r",
                  "text-lg",
                  "font-extrabold",
                  "text-white",
                  3,
                  "disabled",
                  "click",
                ],
                [1, "relative"],
                [1, "icon-6", "absolute", "-right-6", "top-0", 3, "loadingTheme", "showLoading"],
                [1, "bg-blue-pale", "rounded-1", "flex", "items-center", "border", "border-white", "pr-1"],
                [3, "swapChainName"],
                [1, "text-primary", "text-xxxs", "leading-4"],
              ]
            );
          },
          template: function (n, t) {
            (1 & n &&
              (e.TgZ(0, "common-page", 0)(1, "button", 1),
              e.NdJ("click", function () {
                return t.handleClose();
              }),
              e._UZ(2, "bs-icon", 2),
              e.qZA(),
              e.TgZ(3, "div", 3)(4, "div", 4)(5, "div", 5),
              e.SDv(6, 6),
              e.qZA(),
              e.TgZ(7, "div", 7),
              e._uU(8),
              e.qZA(),
              e.TgZ(9, "div", 8),
              e._uU(10),
              e.qZA(),
              e._UZ(11, "bs-token-with-chain-icon", 9),
              e.qZA(),
              e.TgZ(12, "div", 10)(13, "div", 11)(14, "div", 5),
              e.SDv(15, 12),
              e.qZA(),
              e.TgZ(16, "div", 7),
              e._uU(17),
              e.qZA(),
              e.TgZ(18, "div", 8),
              e._uU(19),
              e.qZA(),
              e._UZ(20, "bs-token-with-chain-icon", 9),
              e.qZA(),
              e.TgZ(21, "div", 13)(22, "div", 14),
              e._UZ(23, "bs-swap-token-chain-icon", 15),
              e.TgZ(24, "div", 16),
              e._uU(25),
              e.qZA(),
              e.YNc(26, Mi, 4, 2, "div", 17),
              e.TgZ(27, "div", 18),
              e._uU(28),
              e.qZA()(),
              e.TgZ(29, "div", 19),
              e._UZ(30, "bs-icon", 20),
              e.qZA(),
              e.TgZ(31, "div", 14),
              e._UZ(32, "bs-swap-token-chain-icon", 15),
              e.TgZ(33, "div", 16),
              e._uU(34),
              e.qZA(),
              e.YNc(35, Oi, 4, 2, "div", 17),
              e.TgZ(36, "div", 18),
              e._uU(37),
              e.qZA()()(),
              e.TgZ(38, "div", 21)(39, "div", 22),
              e.SDv(40, 23),
              e.qZA(),
              e.TgZ(41, "div", 24),
              e._uU(42),
              e.TgZ(43, "bs-icon", 25),
              e.NdJ("click", function () {
                return t.handleReversePrice();
              }),
              e.qZA()(),
              e.TgZ(44, "div", 26),
              e.SDv(45, 27),
              e.qZA(),
              e.TgZ(46, "div", 28),
              e._uU(47),
              e.qZA(),
              e.TgZ(48, "div", 26),
              e.SDv(49, 29),
              e.ALo(50, "percentageTransfer"),
              e.qZA(),
              e.TgZ(51, "div", 28),
              e._uU(52),
              e.qZA(),
              e.TgZ(53, "div", 26),
              e.SDv(54, 30),
              e.qZA(),
              e.TgZ(55, "div", 28),
              e._uU(56),
              e.qZA(),
              e.TgZ(57, "div", 26),
              e.SDv(58, 31),
              e.qZA(),
              e.TgZ(59, "div", 28),
              e.SDv(60, 32),
              e.qZA()()()(),
              e.TgZ(61, "section", 33)(62, "div", 34),
              e.SDv(63, 35),
              e.qZA(),
              e.TgZ(64, "button", 36),
              e.NdJ("click", function () {
                return t.submit();
              }),
              e.TgZ(65, "div", 37),
              e._uU(66),
              e._UZ(67, "bn-loading-wrapper", 38),
              e.qZA()()()()),
              2 & n &&
                (e.Q6J("hideBackButton", !0)("headerClass", "pt-2.5 text-lg")("contentBackground", "white")(
                  "contentSafeArea",
                  !0,
                )("contentClass", "!px-3")("footerClass", "pb-0"),
                e.xp6(1),
                e.Q6J("mode", "icon"),
                e.xp6(7),
                e.Oqu(t.sellPanel.amount),
                e.xp6(2),
                e.Oqu(t.sellPanel.coin),
                e.xp6(1),
                e.Q6J("size", 24)("swapCoinName", t.sellPanel.coin)("swapChainName", t.sellPanel.chain),
                e.xp6(6),
                e.Oqu(t.expectBuyAmount),
                e.xp6(2),
                e.Oqu(t.buyPanel.coin),
                e.xp6(1),
                e.Q6J("size", 24)("swapCoinName", t.buyPanel.coin)("swapChainName", t.buyPanel.chain),
                e.xp6(3),
                e.Q6J("swapCoinName", t.sellPanel.coin)("swapChainName", t.sellPanel.chain),
                e.xp6(2),
                e.Oqu(t.sellPanel.coin),
                e.xp6(1),
                e.um2(26, t.sellCoinIsU ? -1 : 26),
                e.xp6(2),
                e.Oqu(t.expectSellAmount),
                e.xp6(4),
                e.Q6J("swapCoinName", t.buyPanel.coin)("swapChainName", t.buyPanel.chain),
                e.xp6(2),
                e.Oqu(t.buyPanel.coin),
                e.xp6(1),
                e.um2(35, t.buyCoinIsU ? -1 : 35),
                e.xp6(2),
                e.Oqu(t.expectBuyAmount),
                e.xp6(5),
                e.lnq(" 1 ", t.price.leftCoin, " = ", t.price.showPrice, " ", t.price.rightCoin, " "),
                e.xp6(5),
                e.AsE("", t.leastGainAmount, " ", t.buyPanel.coin, ""),
                e.xp6(3),
                e.pQV(e.xi3(50, 41, t.platformFee, e.DdM(44, Li))),
                e.QtT(49),
                e.xp6(2),
                e.AsE("", t.transactionFee, " ", t.sellPanel.coin, ""),
                e.xp6(4),
                e.Oqu(t.slippageTolerance),
                e.xp6(4),
                e.pQV(t.expirationTime),
                e.QtT(60),
                e.xp6(4),
                e.Q6J("disabled", t.disabled),
                e.xp6(2),
                e.hij(" ", t.btnText, " "),
                e.xp6(1),
                e.Q6J("loadingTheme", "ellipsis")("showLoading", t.loading)));
          },
          dependencies: [Bt.j, wi.d, x.f5, Gt.Q, ee.C, O.oJ, L.G4, Zt.V],
          encapsulation: 2,
          changeDetection: 0,
        })),
        (0, s.gn)([I.State(), (0, s.w6)("design:type", Object)], I.prototype, "uName", void 0),
        (0, s.gn)([I.State(), (0, s.w6)("design:type", Object)], I.prototype, "leastGainAmount", void 0),
        (0, s.gn)([I.State(), (0, s.w6)("design:type", Object)], I.prototype, "transactionFee", void 0),
        (0, s.gn)([I.State(), (0, s.w6)("design:type", Object)], I.prototype, "feeRatio", void 0),
        (0, s.gn)([I.State(), (0, s.w6)("design:type", Object)], I.prototype, "slippageTolerance", void 0),
        (0, s.gn)([I.State(), (0, s.w6)("design:type", Object)], I.prototype, "expirationTime", void 0),
        (0, s.gn)([I.State(), (0, s.w6)("design:type", Object)], I.prototype, "addLiquidityRatio", void 0),
        (0, s.gn)([I.State(), (0, s.w6)("design:type", Object)], I.prototype, "priceSell", void 0),
        (0, s.gn)([I.State(), (0, s.w6)("design:type", Object)], I.prototype, "priceBuy", void 0),
        (0, s.gn)([I.State(), (0, s.w6)("design:type", String)], I.prototype, "expectSellAmount", void 0),
        (0, s.gn)([I.State(), (0, s.w6)("design:type", Object)], I.prototype, "btnText", void 0),
        (0, s.gn)([I.State(), (0, s.w6)("design:type", Object)], I.prototype, "loading", void 0),
        (0, s.gn)([I.State(), (0, s.w6)("design:type", Object)], I.prototype, "disabled", void 0),
        (0, s.gn)([I.State(), (0, s.w6)("design:type", Object)], I.prototype, "sellCoinIcon", void 0),
        (0, s.gn)([I.State(), (0, s.w6)("design:type", Object)], I.prototype, "sellChainIcon", void 0),
        (0, s.gn)([I.State(), (0, s.w6)("design:type", Object)], I.prototype, "buyCoinIcon", void 0),
        (0, s.gn)([I.State(), (0, s.w6)("design:type", Object)], I.prototype, "buyChainIcon", void 0),
        (0, s.gn)([I.State(), (0, s.w6)("design:type", Object)], I.prototype, "showAddLiquidityDetail", void 0),
        (0, s.gn)([I.State(), (0, s.w6)("design:type", Object)], I.prototype, "sellCoinIsU", void 0),
        (0, s.gn)([I.State(), (0, s.w6)("design:type", Object)], I.prototype, "buyCoinIsU", void 0),
        (0, s.gn)(
          [
            I.OnInit(),
            (0, s.w6)("design:type", Function),
            (0, s.w6)("design:paramtypes", []),
            (0, s.w6)("design:returntype", void 0),
          ],
          I.prototype,
          "init",
          null,
        ));
      const Ri = I;
      var ki = r(31194),
        Di = r(10826),
        Ui = r(9509),
        ut = r.n(Ui),
        Se = r(50720),
        cn = r(93930),
        Q = (function (a) {
          return ((a.HAS_NO_LIQUIDITY = "HAS_NO_LIQUIDITY"), (a.INPUT_ZERO = "INPUT_ZERO"), a);
        })(Q || {});
      const Zi = {
        [Q.HAS_NO_LIQUIDITY]: "\u6D41\u52A8\u6027\u4E0D\u8DB3",
        [Q.INPUT_ZERO]: "\u6570\u91CF\u4E0D\u80FD\u4E3A\u96F6",
      };
      var J = (function (a) {
        return ((a.SELL = "SELL"), (a.BUY = "BUY"), a);
      })(J || {});
      const nt = "del",
        Ie = "enter",
        At = "esc",
        dn = window.requestAnimationFrame,
        un = (a, n = () => {}, t = 60) => {
          let i = !0,
            o = 0;
          const l = (d) => {
            !1 !== i && (a(d, ++o, t), o < t ? dn(l) : n());
          };
          return (
            dn(l),
            () => {
              i = !1;
            }
          );
        },
        Wt = (a) => null != a && "false" != `${a}`,
        Gi = {
          number: [
            [{ key: "1" }, { key: "2" }, { key: "3" }, { key: Ie, rowspan: 3, color: "!text-white" }],
            [{ key: "4" }, { key: "5" }, { key: "6" }],
            [{ key: "7" }, { key: "8" }, { key: "9" }],
            [
              { key: "." },
              { key: "0" },
              {
                key: nt,
                iconName: "icon-delete-rectangle",
                iconColor: "text-title",
              },
              {
                key: At,
                rowspan: 1,
                iconName: "icon-chevron-down-big",
                color: "!text-primary",
              },
            ],
          ],
          tel: [
            [{ key: "1" }, { key: "2" }, { key: "3" }],
            [{ key: "4" }, { key: "5" }, { key: "6" }],
            [{ key: "7" }, { key: "8" }, { key: "9" }],
            [{ key: nt }, { key: "0" }, { key: Ie }],
          ],
          phone: [
            [{ key: "1" }, { key: "2" }, { key: "3" }, { key: nt }],
            [{ key: "4" }, { key: "5" }, { key: "6" }, { key: Ie }],
            [{ key: "7" }, { key: "8" }, { key: "9" }, { key: "." }],
            [{ key: "" }, { key: "0" }, { key: "" }, { key: At }],
          ],
        };
      var jt = r(67147),
        Bi = r(19476),
        Vt = r(22036),
        Fi = r(69324),
        $i = r(57178),
        Wi = r(37689),
        ji = r(65846),
        Vi = r(87632),
        Xi = r(14908),
        ie = r(28716),
        _n = r(94241),
        De = r(32245);
      const Hi = ["knob"],
        zi = ["valueIndicatorContainer"];
      function qi(a, n) {
        if ((1 & a && (e.TgZ(0, "div", 4, 5)(2, "div", 6)(3, "span", 7), e._uU(4), e.qZA()()()), 2 & a)) {
          const t = e.oxw();
          (e.xp6(4), e.Oqu(t.valueIndicatorText));
        }
      }
      const Qi = ["trackActive"];
      function Ji(a, n) {
        if ((1 & a && e._UZ(0, "div"), 2 & a)) {
          const t = n.$implicit,
            i = n.$index,
            o = e.oxw(3);
          (e.Tol(0 === t ? "mdc-slider__tick-mark--active" : "mdc-slider__tick-mark--inactive"),
            e.Udp("transform", o._calcTickMarkTransform(i)));
        }
      }
      function Yi(a, n) {
        if ((1 & a && e.SjG(0, Ji, 1, 4, "div", 9, e.x6l), 2 & a)) {
          const t = e.oxw(2);
          e.wJu(t._tickMarks);
        }
      }
      function Ki(a, n) {
        if ((1 & a && (e.TgZ(0, "div", 7, 8), e.YNc(2, Yi, 2, 0), e.qZA()), 2 & a)) {
          const t = e.oxw();
          (e.xp6(2), e.um2(2, t._cachedWidth ? 2 : -1));
        }
      }
      function eo(a, n) {
        if ((1 & a && e._UZ(0, "mat-slider-visual-thumb", 6), 2 & a)) {
          const t = e.oxw();
          e.Q6J("discrete", t.discrete)("thumbPosition", 1)("valueIndicatorText", t.startValueIndicatorText);
        }
      }
      const to = ["*"],
        Ct = new e.OlP("_MatSlider"),
        hn = new e.OlP("_MatSliderThumb"),
        pn = new e.OlP("_MatSliderRangeThumb"),
        mn = new e.OlP("_MatSliderVisualThumb");
      let no = (() => {
        var a;
        class n {
          constructor(i, o, l, d) {
            ((this._cdr = i),
              (this._ngZone = o),
              (this._slider = d),
              (this._isHovered = !1),
              (this._isActive = !1),
              (this._isValueIndicatorVisible = !1),
              (this._onPointerMove = (p) => {
                if (this._sliderInput._isFocused) return;
                const g = this._hostElement.getBoundingClientRect(),
                  T = this._slider._isCursorOnSliderThumb(p, g);
                ((this._isHovered = T), T ? this._showHoverRipple() : this._hideRipple(this._hoverRippleRef));
              }),
              (this._onMouseLeave = () => {
                ((this._isHovered = !1), this._hideRipple(this._hoverRippleRef));
              }),
              (this._onFocus = () => {
                (this._hideRipple(this._hoverRippleRef),
                  this._showFocusRipple(),
                  this._hostElement.classList.add("mdc-slider__thumb--focused"));
              }),
              (this._onBlur = () => {
                (this._isActive || this._hideRipple(this._focusRippleRef),
                  this._isHovered && this._showHoverRipple(),
                  this._hostElement.classList.remove("mdc-slider__thumb--focused"));
              }),
              (this._onDragStart = (p) => {
                0 === p.button && ((this._isActive = !0), this._showActiveRipple());
              }),
              (this._onDragEnd = () => {
                ((this._isActive = !1),
                  this._hideRipple(this._activeRippleRef),
                  this._sliderInput._isFocused || this._hideRipple(this._focusRippleRef));
              }),
              (this._hostElement = l.nativeElement));
          }
          ngAfterViewInit() {
            ((this._ripple.radius = 24),
              (this._sliderInput = this._slider._getInput(this.thumbPosition)),
              (this._sliderInputEl = this._sliderInput._hostElement));
            const i = this._sliderInputEl;
            this._ngZone.runOutsideAngular(() => {
              (i.addEventListener("pointermove", this._onPointerMove),
                i.addEventListener("pointerdown", this._onDragStart),
                i.addEventListener("pointerup", this._onDragEnd),
                i.addEventListener("pointerleave", this._onMouseLeave),
                i.addEventListener("focus", this._onFocus),
                i.addEventListener("blur", this._onBlur));
            });
          }
          ngOnDestroy() {
            const i = this._sliderInputEl;
            (i.removeEventListener("pointermove", this._onPointerMove),
              i.removeEventListener("pointerdown", this._onDragStart),
              i.removeEventListener("pointerup", this._onDragEnd),
              i.removeEventListener("pointerleave", this._onMouseLeave),
              i.removeEventListener("focus", this._onFocus),
              i.removeEventListener("blur", this._onBlur));
          }
          _showHoverRipple() {
            var i;
            this._isShowingRipple(this._hoverRippleRef) ||
              ((this._hoverRippleRef = this._showRipple({
                enterDuration: 0,
                exitDuration: 0,
              })),
              null === (i = this._hoverRippleRef) ||
                void 0 === i ||
                i.element.classList.add("mat-mdc-slider-hover-ripple"));
          }
          _showFocusRipple() {
            var i;
            this._isShowingRipple(this._focusRippleRef) ||
              ((this._focusRippleRef = this._showRipple({ enterDuration: 0, exitDuration: 0 }, !0)),
              null === (i = this._focusRippleRef) ||
                void 0 === i ||
                i.element.classList.add("mat-mdc-slider-focus-ripple"));
          }
          _showActiveRipple() {
            var i;
            this._isShowingRipple(this._activeRippleRef) ||
              ((this._activeRippleRef = this._showRipple({
                enterDuration: 225,
                exitDuration: 400,
              })),
              null === (i = this._activeRippleRef) ||
                void 0 === i ||
                i.element.classList.add("mat-mdc-slider-active-ripple"));
          }
          _isShowingRipple(i) {
            return 0 === (null == i ? void 0 : i.state) || 1 === (null == i ? void 0 : i.state);
          }
          _showRipple(i, o) {
            var l;
            if (
              !this._slider.disabled &&
              (this._showValueIndicator(),
              this._slider._isRange && this._slider._getThumb(1 === this.thumbPosition ? 2 : 1)._showValueIndicator(),
              null === (l = this._slider._globalRippleOptions) || void 0 === l || !l.disabled || o)
            )
              return this._ripple.launch({
                animation: this._slider._noopAnimations ? { enterDuration: 0, exitDuration: 0 } : i,
                centered: !0,
                persistent: !0,
              });
          }
          _hideRipple(i) {
            if ((null == i || i.fadeOut(), this._isShowingAnyRipple())) return;
            this._slider._isRange || this._hideValueIndicator();
            const o = this._getSibling();
            o._isShowingAnyRipple() || (this._hideValueIndicator(), o._hideValueIndicator());
          }
          _showValueIndicator() {
            this._hostElement.classList.add("mdc-slider__thumb--with-indicator");
          }
          _hideValueIndicator() {
            this._hostElement.classList.remove("mdc-slider__thumb--with-indicator");
          }
          _getSibling() {
            return this._slider._getThumb(1 === this.thumbPosition ? 2 : 1);
          }
          _getValueIndicatorContainer() {
            var i;
            return null === (i = this._valueIndicatorContainer) || void 0 === i ? void 0 : i.nativeElement;
          }
          _getKnob() {
            return this._knob.nativeElement;
          }
          _isShowingAnyRipple() {
            return (
              this._isShowingRipple(this._hoverRippleRef) ||
              this._isShowingRipple(this._focusRippleRef) ||
              this._isShowingRipple(this._activeRippleRef)
            );
          }
        }
        return (
          ((a = n).ɵfac = function (i) {
            return new (i || a)(e.Y36(e.sBO), e.Y36(e.R0b), e.Y36(e.SBq), e.Y36(Ct));
          }),
          (a.ɵcmp = e.Xpm({
            type: a,
            selectors: [["mat-slider-visual-thumb"]],
            viewQuery: function (i, o) {
              if ((1 & i && (e.Gf(De.wG, 5), e.Gf(Hi, 5), e.Gf(zi, 5)), 2 & i)) {
                let l;
                (e.iGM((l = e.CRH())) && (o._ripple = l.first),
                  e.iGM((l = e.CRH())) && (o._knob = l.first),
                  e.iGM((l = e.CRH())) && (o._valueIndicatorContainer = l.first));
              }
            },
            hostAttrs: [1, "mdc-slider__thumb", "mat-mdc-slider-visual-thumb"],
            inputs: {
              discrete: "discrete",
              thumbPosition: "thumbPosition",
              valueIndicatorText: "valueIndicatorText",
            },
            features: [e._Bn([{ provide: mn, useExisting: a }])],
            decls: 4,
            vars: 2,
            consts: [
              ["class", "mdc-slider__value-indicator-container"],
              [1, "mdc-slider__thumb-knob"],
              ["knob", ""],
              ["matRipple", "", 1, "mat-mdc-focus-indicator", 3, "matRippleDisabled"],
              [1, "mdc-slider__value-indicator-container"],
              ["valueIndicatorContainer", ""],
              [1, "mdc-slider__value-indicator"],
              [1, "mdc-slider__value-indicator-text"],
            ],
            template: function (i, o) {
              (1 & i && (e.YNc(0, qi, 5, 1, "div", 0), e._UZ(1, "div", 1, 2)(3, "div", 3)),
                2 & i && (e.um2(0, o.discrete ? 0 : -1), e.xp6(3), e.Q6J("matRippleDisabled", !0)));
            },
            dependencies: [De.wG],
            styles: [
              ".mat-mdc-slider-visual-thumb .mat-ripple{height:100%;width:100%}.mat-mdc-slider .mdc-slider__tick-marks{justify-content:start}.mat-mdc-slider .mdc-slider__tick-marks .mdc-slider__tick-mark--active,.mat-mdc-slider .mdc-slider__tick-marks .mdc-slider__tick-mark--inactive{position:absolute;left:2px}",
            ],
            encapsulation: 2,
            changeDetection: 0,
          })),
          n
        );
      })();
      const io = (0, De.pj)(
        (0, De.Kr)(
          class {
            constructor(a) {
              this._elementRef = a;
            }
          },
        ),
        "primary",
      );
      let oo = (() => {
        var a;
        class n extends io {
          get disabled() {
            return this._disabled;
          }
          set disabled(i) {
            this._disabled = (0, ie.Ig)(i);
            const o = this._getInput(2),
              l = this._getInput(1);
            (o && (o.disabled = this._disabled), l && (l.disabled = this._disabled));
          }
          get discrete() {
            return this._discrete;
          }
          set discrete(i) {
            ((this._discrete = (0, ie.Ig)(i)), this._updateValueIndicatorUIs());
          }
          get showTickMarks() {
            return this._showTickMarks;
          }
          set showTickMarks(i) {
            this._showTickMarks = (0, ie.Ig)(i);
          }
          get min() {
            return this._min;
          }
          set min(i) {
            const o = (0, ie.su)(i, this._min);
            this._min !== o && this._updateMin(o);
          }
          _updateMin(i) {
            const o = this._min;
            ((this._min = i),
              this._isRange ? this._updateMinRange({ old: o, new: i }) : this._updateMinNonRange(i),
              this._onMinMaxOrStepChange());
          }
          _updateMinRange(i) {
            const o = this._getInput(2),
              l = this._getInput(1),
              d = o.value,
              p = l.value;
            ((l.min = i.new),
              (o.min = Math.max(i.new, l.value)),
              (l.max = Math.min(o.max, o.value)),
              l._updateWidthInactive(),
              o._updateWidthInactive(),
              i.new < i.old ? this._onTranslateXChangeBySideEffect(o, l) : this._onTranslateXChangeBySideEffect(l, o),
              d !== o.value && this._onValueChange(o),
              p !== l.value && this._onValueChange(l));
          }
          _updateMinNonRange(i) {
            const o = this._getInput(2);
            if (o) {
              const l = o.value;
              ((o.min = i), o._updateThumbUIByValue(), this._updateTrackUI(o), l !== o.value && this._onValueChange(o));
            }
          }
          get max() {
            return this._max;
          }
          set max(i) {
            const o = (0, ie.su)(i, this._max);
            this._max !== o && this._updateMax(o);
          }
          _updateMax(i) {
            const o = this._max;
            ((this._max = i),
              this._isRange ? this._updateMaxRange({ old: o, new: i }) : this._updateMaxNonRange(i),
              this._onMinMaxOrStepChange());
          }
          _updateMaxRange(i) {
            const o = this._getInput(2),
              l = this._getInput(1),
              d = o.value,
              p = l.value;
            ((o.max = i.new),
              (l.max = Math.min(i.new, o.value)),
              (o.min = l.value),
              o._updateWidthInactive(),
              l._updateWidthInactive(),
              i.new > i.old ? this._onTranslateXChangeBySideEffect(l, o) : this._onTranslateXChangeBySideEffect(o, l),
              d !== o.value && this._onValueChange(o),
              p !== l.value && this._onValueChange(l));
          }
          _updateMaxNonRange(i) {
            const o = this._getInput(2);
            if (o) {
              const l = o.value;
              ((o.max = i), o._updateThumbUIByValue(), this._updateTrackUI(o), l !== o.value && this._onValueChange(o));
            }
          }
          get step() {
            return this._step;
          }
          set step(i) {
            const o = (0, ie.su)(i, this._step);
            this._step !== o && this._updateStep(o);
          }
          _updateStep(i) {
            ((this._step = i),
              this._isRange ? this._updateStepRange() : this._updateStepNonRange(),
              this._onMinMaxOrStepChange());
          }
          _updateStepRange() {
            const i = this._getInput(2),
              o = this._getInput(1),
              l = i.value,
              d = o.value,
              p = o.value;
            ((i.min = this._min),
              (o.max = this._max),
              (i.step = this._step),
              (o.step = this._step),
              this._platform.SAFARI && ((i.value = i.value), (o.value = o.value)),
              (i.min = Math.max(this._min, o.value)),
              (o.max = Math.min(this._max, i.value)),
              o._updateWidthInactive(),
              i._updateWidthInactive(),
              i.value < p ? this._onTranslateXChangeBySideEffect(o, i) : this._onTranslateXChangeBySideEffect(i, o),
              l !== i.value && this._onValueChange(i),
              d !== o.value && this._onValueChange(o));
          }
          _updateStepNonRange() {
            const i = this._getInput(2);
            if (i) {
              const o = i.value;
              ((i.step = this._step),
                this._platform.SAFARI && (i.value = i.value),
                i._updateThumbUIByValue(),
                o !== i.value && this._onValueChange(i));
            }
          }
          constructor(i, o, l, d, p, g) {
            (super(l),
              (this._ngZone = i),
              (this._cdr = o),
              (this._dir = d),
              (this._globalRippleOptions = p),
              (this._disabled = !1),
              (this._discrete = !1),
              (this._showTickMarks = !1),
              (this._min = 0),
              (this._max = 100),
              (this._step = 1),
              (this.displayWith = (T) => `${T}`),
              (this._rippleRadius = 24),
              (this.startValueIndicatorText = ""),
              (this.endValueIndicatorText = ""),
              (this._isRange = !1),
              (this._isRtl = !1),
              (this._hasViewInitialized = !1),
              (this._tickMarkTrackWidth = 0),
              (this._hasAnimation = !1),
              (this._resizeTimer = null),
              (this._platform = (0, e.f3M)(_n.t4)),
              (this._knobRadius = 8),
              (this._thumbsOverlap = !1),
              (this._noopAnimations = "NoopAnimations" === g),
              (this._dirChangeSubscription = this._dir.change.subscribe(() => this._onDirChange())),
              (this._isRtl = "rtl" === this._dir.value));
          }
          ngAfterViewInit() {
            this._platform.isBrowser && this._updateDimensions();
            const i = this._getInput(2),
              o = this._getInput(1);
            ((this._isRange = !!i && !!o), this._cdr.detectChanges());
            const l = this._getThumb(2);
            ((this._rippleRadius = l._ripple.radius),
              (this._inputPadding = this._rippleRadius - this._knobRadius),
              (this._inputOffset = this._knobRadius),
              this._isRange ? this._initUIRange(i, o) : this._initUINonRange(i),
              this._updateTrackUI(i),
              this._updateTickMarkUI(),
              this._updateTickMarkTrackUI(),
              this._observeHostResize(),
              this._cdr.detectChanges());
          }
          _initUINonRange(i) {
            (i.initProps(),
              i.initUI(),
              this._updateValueIndicatorUI(i),
              (this._hasViewInitialized = !0),
              i._updateThumbUIByValue());
          }
          _initUIRange(i, o) {
            (i.initProps(),
              i.initUI(),
              o.initProps(),
              o.initUI(),
              i._updateMinMax(),
              o._updateMinMax(),
              i._updateStaticStyles(),
              o._updateStaticStyles(),
              this._updateValueIndicatorUIs(),
              (this._hasViewInitialized = !0),
              i._updateThumbUIByValue(),
              o._updateThumbUIByValue());
          }
          ngOnDestroy() {
            var i;
            (this._dirChangeSubscription.unsubscribe(),
              null === (i = this._resizeObserver) || void 0 === i || i.disconnect(),
              (this._resizeObserver = null));
          }
          _onDirChange() {
            ((this._isRtl = "rtl" === this._dir.value),
              this._isRange ? this._onDirChangeRange() : this._onDirChangeNonRange(),
              this._updateTickMarkUI());
          }
          _onDirChangeRange() {
            const i = this._getInput(2),
              o = this._getInput(1);
            (i._setIsLeftThumb(),
              o._setIsLeftThumb(),
              (i.translateX = i._calcTranslateXByValue()),
              (o.translateX = o._calcTranslateXByValue()),
              i._updateStaticStyles(),
              o._updateStaticStyles(),
              i._updateWidthInactive(),
              o._updateWidthInactive(),
              i._updateThumbUIByValue(),
              o._updateThumbUIByValue());
          }
          _onDirChangeNonRange() {
            this._getInput(2)._updateThumbUIByValue();
          }
          _observeHostResize() {
            typeof ResizeObserver > "u" ||
              !ResizeObserver ||
              this._ngZone.runOutsideAngular(() => {
                ((this._resizeObserver = new ResizeObserver(() => {
                  this._isActive() || (this._resizeTimer && clearTimeout(this._resizeTimer), this._onResize());
                })),
                  this._resizeObserver.observe(this._elementRef.nativeElement));
              });
          }
          _isActive() {
            return this._getThumb(1)._isActive || this._getThumb(2)._isActive;
          }
          _getValue(i = 2) {
            const o = this._getInput(i);
            return o ? o.value : this.min;
          }
          _skipUpdate() {
            var i, o;
            return !!(
              (null !== (i = this._getInput(1)) && void 0 !== i && i._skipUIUpdate) ||
              (null !== (o = this._getInput(2)) && void 0 !== o && o._skipUIUpdate)
            );
          }
          _updateDimensions() {
            ((this._cachedWidth = this._elementRef.nativeElement.offsetWidth),
              (this._cachedLeft = this._elementRef.nativeElement.getBoundingClientRect().left));
          }
          _setTrackActiveStyles(i) {
            const o = this._trackActive.nativeElement.style;
            ((o.left = i.left),
              (o.right = i.right),
              (o.transformOrigin = i.transformOrigin),
              (o.transform = i.transform));
          }
          _calcTickMarkTransform(i) {
            return `translateX(${i * (this._tickMarkTrackWidth / (this._tickMarks.length - 1))}px`;
          }
          _onTranslateXChange(i) {
            this._hasViewInitialized &&
              (this._updateThumbUI(i), this._updateTrackUI(i), this._updateOverlappingThumbUI(i));
          }
          _onTranslateXChangeBySideEffect(i, o) {
            this._hasViewInitialized && (i._updateThumbUIByValue(), o._updateThumbUIByValue());
          }
          _onValueChange(i) {
            this._hasViewInitialized &&
              (this._updateValueIndicatorUI(i), this._updateTickMarkUI(), this._cdr.detectChanges());
          }
          _onMinMaxOrStepChange() {
            this._hasViewInitialized &&
              (this._updateTickMarkUI(), this._updateTickMarkTrackUI(), this._cdr.markForCheck());
          }
          _onResize() {
            if (this._hasViewInitialized) {
              if ((this._updateDimensions(), this._isRange)) {
                const i = this._getInput(2),
                  o = this._getInput(1);
                (i._updateThumbUIByValue(),
                  o._updateThumbUIByValue(),
                  i._updateStaticStyles(),
                  o._updateStaticStyles(),
                  i._updateMinMax(),
                  o._updateMinMax(),
                  i._updateWidthInactive(),
                  o._updateWidthInactive());
              } else {
                const i = this._getInput(2);
                i && i._updateThumbUIByValue();
              }
              (this._updateTickMarkUI(), this._updateTickMarkTrackUI(), this._cdr.detectChanges());
            }
          }
          _areThumbsOverlapping() {
            const i = this._getInput(1),
              o = this._getInput(2);
            return !(!i || !o) && o.translateX - i.translateX < 20;
          }
          _updateOverlappingThumbClassNames(i) {
            const o = i.getSibling(),
              l = this._getThumb(i.thumbPosition);
            (this._getThumb(o.thumbPosition)._hostElement.classList.remove("mdc-slider__thumb--top"),
              l._hostElement.classList.toggle("mdc-slider__thumb--top", this._thumbsOverlap));
          }
          _updateOverlappingThumbUI(i) {
            !this._isRange ||
              this._skipUpdate() ||
              (this._thumbsOverlap !== this._areThumbsOverlapping() &&
                ((this._thumbsOverlap = !this._thumbsOverlap), this._updateOverlappingThumbClassNames(i)));
          }
          _updateThumbUI(i) {
            this._skipUpdate() ||
              (this._getThumb(2 === i.thumbPosition ? 2 : 1)._hostElement.style.transform =
                `translateX(${i.translateX}px)`);
          }
          _updateValueIndicatorUI(i) {
            if (this._skipUpdate()) return;
            const o = this.displayWith(i.value);
            if (
              (this._hasViewInitialized ? (i._valuetext = o) : i._hostElement.setAttribute("aria-valuetext", o),
              this.discrete)
            ) {
              1 === i.thumbPosition ? (this.startValueIndicatorText = o) : (this.endValueIndicatorText = o);
              const l = this._getThumb(i.thumbPosition);
              o.length < 3
                ? l._hostElement.classList.add("mdc-slider__thumb--short-value")
                : l._hostElement.classList.remove("mdc-slider__thumb--short-value");
            }
          }
          _updateValueIndicatorUIs() {
            const i = this._getInput(2),
              o = this._getInput(1);
            (i && this._updateValueIndicatorUI(i), o && this._updateValueIndicatorUI(o));
          }
          _updateTickMarkTrackUI() {
            if (!this.showTickMarks || this._skipUpdate()) return;
            const i = this._step && this._step > 0 ? this._step : 1,
              l = (Math.floor(this.max / i) * i - this.min) / (this.max - this.min);
            this._tickMarkTrackWidth = this._cachedWidth * l - 6;
          }
          _updateTrackUI(i) {
            this._skipUpdate() || (this._isRange ? this._updateTrackUIRange(i) : this._updateTrackUINonRange(i));
          }
          _updateTrackUIRange(i) {
            const o = i.getSibling();
            if (!o || !this._cachedWidth) return;
            const l = Math.abs(o.translateX - i.translateX) / this._cachedWidth;
            this._setTrackActiveStyles(
              i._isLeftThumb && this._cachedWidth
                ? {
                    left: "auto",
                    right: this._cachedWidth - o.translateX + "px",
                    transformOrigin: "right",
                    transform: `scaleX(${l})`,
                  }
                : {
                    left: `${o.translateX}px`,
                    right: "auto",
                    transformOrigin: "left",
                    transform: `scaleX(${l})`,
                  },
            );
          }
          _updateTrackUINonRange(i) {
            this._setTrackActiveStyles(
              this._isRtl
                ? {
                    left: "auto",
                    right: "0px",
                    transformOrigin: "right",
                    transform: `scaleX(${1 - i.fillPercentage})`,
                  }
                : {
                    left: "0px",
                    right: "auto",
                    transformOrigin: "left",
                    transform: `scaleX(${i.fillPercentage})`,
                  },
            );
          }
          _updateTickMarkUI() {
            if (!this.showTickMarks || void 0 === this.step || void 0 === this.min || void 0 === this.max) return;
            const i = this.step > 0 ? this.step : 1;
            (this._isRange ? this._updateTickMarkUIRange(i) : this._updateTickMarkUINonRange(i),
              this._isRtl && this._tickMarks.reverse());
          }
          _updateTickMarkUINonRange(i) {
            const o = this._getValue();
            let l = Math.max(Math.round((o - this.min) / i), 0),
              d = Math.max(Math.round((this.max - o) / i), 0);
            (this._isRtl ? l++ : d++, (this._tickMarks = Array(l).fill(0).concat(Array(d).fill(1))));
          }
          _updateTickMarkUIRange(i) {
            const o = this._getValue(),
              l = this._getValue(1),
              d = Math.max(Math.floor((l - this.min) / i), 0),
              p = Math.max(Math.floor((o - l) / i) + 1, 0),
              g = Math.max(Math.floor((this.max - o) / i), 0);
            this._tickMarks = Array(d).fill(1).concat(Array(p).fill(0), Array(g).fill(1));
          }
          _getInput(i) {
            var o;
            return 2 === i && this._input
              ? this._input
              : null !== (o = this._inputs) && void 0 !== o && o.length
                ? 1 === i
                  ? this._inputs.first
                  : this._inputs.last
                : void 0;
          }
          _getThumb(i) {
            var o, l;
            return 2 === i
              ? null === (o = this._thumbs) || void 0 === o
                ? void 0
                : o.last
              : null === (l = this._thumbs) || void 0 === l
                ? void 0
                : l.first;
          }
          _setTransition(i) {
            ((this._hasAnimation = !this._platform.IOS && i && !this._noopAnimations),
              this._elementRef.nativeElement.classList.toggle("mat-mdc-slider-with-animation", this._hasAnimation));
          }
          _isCursorOnSliderThumb(i, o) {
            const l = o.width / 2,
              T = i.clientY - (o.y + l);
            return Math.pow(i.clientX - (o.x + l), 2) + Math.pow(T, 2) < Math.pow(l, 2);
          }
        }
        return (
          ((a = n).ɵfac = function (i) {
            return new (i || a)(
              e.Y36(e.R0b),
              e.Y36(e.sBO),
              e.Y36(e.SBq),
              e.Y36(Xi.Is, 8),
              e.Y36(De.Y2, 8),
              e.Y36(e.QbO, 8),
            );
          }),
          (a.ɵcmp = e.Xpm({
            type: a,
            selectors: [["mat-slider"]],
            contentQueries: function (i, o, l) {
              if ((1 & i && (e.Suo(l, hn, 5), e.Suo(l, pn, 4)), 2 & i)) {
                let d;
                (e.iGM((d = e.CRH())) && (o._input = d.first), e.iGM((d = e.CRH())) && (o._inputs = d));
              }
            },
            viewQuery: function (i, o) {
              if ((1 & i && (e.Gf(Qi, 5), e.Gf(mn, 5)), 2 & i)) {
                let l;
                (e.iGM((l = e.CRH())) && (o._trackActive = l.first), e.iGM((l = e.CRH())) && (o._thumbs = l));
              }
            },
            hostAttrs: [1, "mat-mdc-slider", "mdc-slider"],
            hostVars: 10,
            hostBindings: function (i, o) {
              2 & i &&
                e.ekj("mdc-slider--range", o._isRange)("mdc-slider--disabled", o.disabled)(
                  "mdc-slider--discrete",
                  o.discrete,
                )("mdc-slider--tick-marks", o.showTickMarks)("_mat-animation-noopable", o._noopAnimations);
            },
            inputs: {
              color: "color",
              disableRipple: "disableRipple",
              disabled: "disabled",
              discrete: "discrete",
              showTickMarks: "showTickMarks",
              min: "min",
              max: "max",
              step: "step",
              displayWith: "displayWith",
            },
            exportAs: ["matSlider"],
            features: [e._Bn([{ provide: Ct, useExisting: a }]), e.qOj],
            ngContentSelectors: to,
            decls: 9,
            vars: 5,
            consts: [
              [1, "mdc-slider__track"],
              [1, "mdc-slider__track--inactive"],
              [1, "mdc-slider__track--active"],
              [1, "mdc-slider__track--active_fill"],
              ["trackActive", ""],
              ["class", "mdc-slider__tick-marks"],
              [3, "discrete", "thumbPosition", "valueIndicatorText"],
              [1, "mdc-slider__tick-marks"],
              ["tickMarkContainer", ""],
              [3, "class", "transform"],
            ],
            template: function (i, o) {
              (1 & i &&
                (e.F$t(),
                e.Hsn(0),
                e.TgZ(1, "div", 0),
                e._UZ(2, "div", 1),
                e.TgZ(3, "div", 2),
                e._UZ(4, "div", 3, 4),
                e.qZA(),
                e.YNc(6, Ki, 3, 1, "div", 5),
                e.qZA(),
                e.YNc(7, eo, 1, 3, "mat-slider-visual-thumb", 6),
                e._UZ(8, "mat-slider-visual-thumb", 6)),
                2 & i &&
                  (e.xp6(6),
                  e.um2(6, o.showTickMarks ? 6 : -1),
                  e.xp6(1),
                  e.um2(7, o._isRange ? 7 : -1),
                  e.xp6(1),
                  e.Q6J("discrete", o.discrete)("thumbPosition", 2)("valueIndicatorText", o.endValueIndicatorText)));
            },
            dependencies: [no],
            styles: [
              '.mdc-slider{cursor:pointer;height:48px;margin:0 24px;position:relative;touch-action:pan-y}.mdc-slider .mdc-slider__track{position:absolute;top:50%;transform:translateY(-50%);width:100%}.mdc-slider .mdc-slider__track--active,.mdc-slider .mdc-slider__track--inactive{display:flex;height:100%;position:absolute;width:100%}.mdc-slider .mdc-slider__track--active{overflow:hidden}.mdc-slider .mdc-slider__track--active_fill{border-top-style:solid;box-sizing:border-box;height:100%;width:100%;position:relative;-webkit-transform-origin:left;transform-origin:left}[dir=rtl] .mdc-slider .mdc-slider__track--active_fill,.mdc-slider .mdc-slider__track--active_fill[dir=rtl]{-webkit-transform-origin:right;transform-origin:right}.mdc-slider .mdc-slider__track--inactive{left:0;top:0}.mdc-slider .mdc-slider__track--inactive::before{position:absolute;box-sizing:border-box;width:100%;height:100%;top:0;left:0;border:1px solid rgba(0,0,0,0);border-radius:inherit;content:"";pointer-events:none}@media screen and (forced-colors: active){.mdc-slider .mdc-slider__track--inactive::before{border-color:CanvasText}}.mdc-slider .mdc-slider__value-indicator-container{bottom:44px;left:50%;left:var(--slider-value-indicator-container-left, 50%);pointer-events:none;position:absolute;right:var(--slider-value-indicator-container-right);transform:translateX(-50%);transform:var(--slider-value-indicator-container-transform, translateX(-50%))}.mdc-slider .mdc-slider__value-indicator{transition:transform 100ms 0ms cubic-bezier(0.4, 0, 1, 1);align-items:center;border-radius:4px;display:flex;height:32px;padding:0 12px;transform:scale(0);transform-origin:bottom}.mdc-slider .mdc-slider__value-indicator::before{border-left:6px solid rgba(0,0,0,0);border-right:6px solid rgba(0,0,0,0);border-top:6px solid;bottom:-5px;content:"";height:0;left:50%;left:var(--slider-value-indicator-caret-left, 50%);position:absolute;right:var(--slider-value-indicator-caret-right);transform:translateX(-50%);transform:var(--slider-value-indicator-caret-transform, translateX(-50%));width:0}.mdc-slider .mdc-slider__value-indicator::after{position:absolute;box-sizing:border-box;width:100%;height:100%;top:0;left:0;border:1px solid rgba(0,0,0,0);border-radius:inherit;content:"";pointer-events:none}@media screen and (forced-colors: active){.mdc-slider .mdc-slider__value-indicator::after{border-color:CanvasText}}.mdc-slider .mdc-slider__thumb--with-indicator .mdc-slider__value-indicator-container{pointer-events:auto}.mdc-slider .mdc-slider__thumb--with-indicator .mdc-slider__value-indicator{transition:transform 100ms 0ms cubic-bezier(0, 0, 0.2, 1);transform:scale(1)}@media(prefers-reduced-motion){.mdc-slider .mdc-slider__value-indicator,.mdc-slider .mdc-slider__thumb--with-indicator .mdc-slider__value-indicator{transition:none}}.mdc-slider .mdc-slider__thumb{display:flex;left:-24px;outline:none;position:absolute;user-select:none;height:48px;width:48px}.mdc-slider .mdc-slider__thumb--top{z-index:1}.mdc-slider .mdc-slider__thumb--top .mdc-slider__thumb-knob,.mdc-slider .mdc-slider__thumb--top.mdc-slider__thumb:hover .mdc-slider__thumb-knob,.mdc-slider .mdc-slider__thumb--top.mdc-slider__thumb--focused .mdc-slider__thumb-knob{border-style:solid;border-width:1px;box-sizing:content-box}.mdc-slider .mdc-slider__thumb-knob{box-sizing:border-box;left:50%;position:absolute;top:50%;transform:translate(-50%, -50%)}.mdc-slider .mdc-slider__tick-marks{align-items:center;box-sizing:border-box;display:flex;height:100%;justify-content:space-between;padding:0 1px;position:absolute;width:100%}.mdc-slider--discrete .mdc-slider__thumb,.mdc-slider--discrete .mdc-slider__track--active_fill{transition:transform 80ms ease}@media(prefers-reduced-motion){.mdc-slider--discrete .mdc-slider__thumb,.mdc-slider--discrete .mdc-slider__track--active_fill{transition:none}}.mdc-slider--disabled{cursor:auto}.mdc-slider--disabled .mdc-slider__thumb{pointer-events:none}.mdc-slider__input{cursor:pointer;left:2px;margin:0;height:44px;opacity:0;pointer-events:none;position:absolute;top:2px;width:44px}.mat-mdc-slider{display:inline-block;box-sizing:border-box;outline:none;vertical-align:middle;margin-left:8px;margin-right:8px;width:auto;min-width:112px;-webkit-tap-highlight-color:rgba(0,0,0,0)}.mat-mdc-slider .mdc-slider__thumb-knob{background-color:var(--mdc-slider-handle-color);border-color:var(--mdc-slider-handle-color)}.mat-mdc-slider .mdc-slider__thumb--top .mdc-slider__thumb-knob,.mat-mdc-slider .mdc-slider__thumb--top.mdc-slider__thumb:hover .mdc-slider__thumb-knob,.mat-mdc-slider .mdc-slider__thumb--top.mdc-slider__thumb--focused .mdc-slider__thumb-knob{border-color:#fff}.mat-mdc-slider.mdc-slider--disabled .mdc-slider__thumb-knob{background-color:var(--mdc-slider-disabled-handle-color);border-color:var(--mdc-slider-disabled-handle-color)}.mat-mdc-slider.mdc-slider--disabled .mdc-slider__thumb--top .mdc-slider__thumb-knob,.mat-mdc-slider.mdc-slider--disabled .mdc-slider__thumb--top.mdc-slider__thumb:hover .mdc-slider__thumb-knob,.mat-mdc-slider.mdc-slider--disabled .mdc-slider__thumb--top.mdc-slider__thumb--focused .mdc-slider__thumb-knob{border-color:#fff}.mat-mdc-slider .mdc-slider__thumb::before,.mat-mdc-slider .mdc-slider__thumb::after{background-color:var(--mdc-slider-handle-color)}.mat-mdc-slider .mdc-slider__thumb:hover::before,.mat-mdc-slider .mdc-slider__thumb.mdc-ripple-surface--hover::before{opacity:var(--mdc-ripple-hover-opacity)}.mat-mdc-slider .mdc-slider__thumb.mdc-ripple-upgraded--background-focused::before,.mat-mdc-slider .mdc-slider__thumb:not(.mdc-ripple-upgraded):focus::before{transition-duration:75ms;opacity:var(--mdc-ripple-focus-opacity)}.mat-mdc-slider .mdc-slider__thumb:not(.mdc-ripple-upgraded)::after{transition:opacity 150ms linear}.mat-mdc-slider .mdc-slider__thumb:not(.mdc-ripple-upgraded):active::after{transition-duration:75ms;opacity:var(--mdc-ripple-press-opacity)}.mat-mdc-slider .mdc-slider__thumb.mdc-ripple-upgraded{--mdc-ripple-fg-opacity:var(--mdc-ripple-press-opacity)}.mat-mdc-slider .mdc-slider__track--active_fill{border-color:var(--mdc-slider-active-track-color)}.mat-mdc-slider.mdc-slider--disabled .mdc-slider__track--active_fill{border-color:var(--mdc-slider-disabled-active-track-color)}.mat-mdc-slider .mdc-slider__track--inactive{background-color:var(--mdc-slider-inactive-track-color);opacity:.24}.mat-mdc-slider.mdc-slider--disabled .mdc-slider__track--inactive{background-color:var(--mdc-slider-disabled-inactive-track-color);opacity:.24}.mat-mdc-slider .mdc-slider__tick-mark--active{background-color:var(--mdc-slider-with-tick-marks-active-container-color);opacity:var(--mdc-slider-with-tick-marks-active-container-opacity)}.mat-mdc-slider.mdc-slider--disabled .mdc-slider__tick-mark--active{background-color:var(--mdc-slider-with-tick-marks-active-container-color);opacity:var(--mdc-slider-with-tick-marks-active-container-opacity)}.mat-mdc-slider .mdc-slider__tick-mark--inactive{background-color:var(--mdc-slider-with-tick-marks-inactive-container-color);opacity:var(--mdc-slider-with-tick-marks-inactive-container-opacity)}.mat-mdc-slider.mdc-slider--disabled .mdc-slider__tick-mark--inactive{background-color:var(--mdc-slider-with-tick-marks-disabled-container-color);opacity:var(--mdc-slider-with-tick-marks-inactive-container-opacity)}.mat-mdc-slider .mdc-slider__value-indicator{background-color:var(--mdc-slider-label-container-color);opacity:1}.mat-mdc-slider .mdc-slider__value-indicator::before{border-top-color:var(--mdc-slider-label-container-color)}.mat-mdc-slider .mdc-slider__value-indicator{color:var(--mdc-slider-label-label-text-color)}.mat-mdc-slider .mdc-slider__track{height:var(--mdc-slider-inactive-track-height)}.mat-mdc-slider .mdc-slider__track--active{height:var(--mdc-slider-active-track-height);top:calc((var(--mdc-slider-inactive-track-height) - var(--mdc-slider-active-track-height)) / 2)}.mat-mdc-slider .mdc-slider__track--active_fill{border-top-width:var(--mdc-slider-active-track-height)}.mat-mdc-slider .mdc-slider__track--inactive{height:var(--mdc-slider-inactive-track-height)}.mat-mdc-slider .mdc-slider__tick-mark--active,.mat-mdc-slider .mdc-slider__tick-mark--inactive{height:var(--mdc-slider-with-tick-marks-container-size);width:var(--mdc-slider-with-tick-marks-container-size)}.mat-mdc-slider.mdc-slider--disabled{opacity:0.38}.mat-mdc-slider .mdc-slider__value-indicator-text{letter-spacing:var(--mdc-slider-label-label-text-tracking);font-size:var(--mdc-slider-label-label-text-size);font-family:var(--mdc-slider-label-label-text-font);font-weight:var(--mdc-slider-label-label-text-weight);line-height:var(--mdc-slider-label-label-text-line-height)}.mat-mdc-slider .mdc-slider__track--active{border-radius:var(--mdc-slider-active-track-shape)}.mat-mdc-slider .mdc-slider__track--inactive{border-radius:var(--mdc-slider-inactive-track-shape)}.mat-mdc-slider .mdc-slider__thumb-knob{border-radius:var(--mdc-slider-handle-shape);width:var(--mdc-slider-handle-width);height:var(--mdc-slider-handle-height);border-style:solid;border-width:calc(var(--mdc-slider-handle-height) / 2) calc(var(--mdc-slider-handle-width) / 2)}.mat-mdc-slider .mdc-slider__tick-mark--active,.mat-mdc-slider .mdc-slider__tick-mark--inactive{border-radius:var(--mdc-slider-with-tick-marks-container-shape)}.mat-mdc-slider .mdc-slider__thumb:hover .mdc-slider__thumb-knob{background-color:var(--mdc-slider-hover-handle-color);border-color:var(--mdc-slider-hover-handle-color)}.mat-mdc-slider .mdc-slider__thumb:hover .mdc-slider__thumb--top .mdc-slider__thumb-knob,.mat-mdc-slider .mdc-slider__thumb:hover .mdc-slider__thumb--top.mdc-slider__thumb:hover .mdc-slider__thumb-knob,.mat-mdc-slider .mdc-slider__thumb:hover .mdc-slider__thumb--top.mdc-slider__thumb--focused .mdc-slider__thumb-knob{border-color:#fff}.mat-mdc-slider .mdc-slider__thumb--focused .mdc-slider__thumb-knob{background-color:var(--mdc-slider-focus-handle-color);border-color:var(--mdc-slider-focus-handle-color)}.mat-mdc-slider .mdc-slider__thumb--focused .mdc-slider__thumb--top .mdc-slider__thumb-knob,.mat-mdc-slider .mdc-slider__thumb--focused .mdc-slider__thumb--top.mdc-slider__thumb:hover .mdc-slider__thumb-knob,.mat-mdc-slider .mdc-slider__thumb--focused .mdc-slider__thumb--top.mdc-slider__thumb--focused .mdc-slider__thumb-knob{border-color:#fff}.mat-mdc-slider .mdc-slider__thumb:not(:disabled):active .mdc-slider__thumb--top .mdc-slider__thumb-knob,.mat-mdc-slider .mdc-slider__thumb:not(:disabled):active .mdc-slider__thumb--top.mdc-slider__thumb:hover .mdc-slider__thumb-knob,.mat-mdc-slider .mdc-slider__thumb:not(:disabled):active .mdc-slider__thumb--top.mdc-slider__thumb--focused .mdc-slider__thumb-knob{border-color:#fff}.mat-mdc-slider .mdc-slider__thumb--top .mdc-slider__thumb-knob,.mat-mdc-slider .mdc-slider__thumb--top.mdc-slider__thumb:hover .mdc-slider__thumb-knob,.mat-mdc-slider .mdc-slider__thumb--top.mdc-slider__thumb--focused .mdc-slider__thumb-knob{border-color:var(--mdc-slider-with-overlap-handle-outline-color);border-width:var(--mdc-slider-with-overlap-handle-outline-width)}.mat-mdc-slider .mdc-slider__thumb-knob{box-shadow:var(--mdc-slider-handle-elevation)}.mat-mdc-slider .mdc-slider__input{box-sizing:content-box;pointer-events:auto}.mat-mdc-slider .mdc-slider__input.mat-mdc-slider-input-no-pointer-events{pointer-events:none}.mat-mdc-slider .mdc-slider__input.mat-slider__right-input{left:auto;right:0}.mat-mdc-slider .mdc-slider__thumb,.mat-mdc-slider .mdc-slider__track--active_fill{transition-duration:0ms}.mat-mdc-slider.mat-mdc-slider-with-animation .mdc-slider__thumb,.mat-mdc-slider.mat-mdc-slider-with-animation .mdc-slider__track--active_fill{transition-duration:80ms}.mat-mdc-slider.mdc-slider--discrete .mdc-slider__thumb,.mat-mdc-slider.mdc-slider--discrete .mdc-slider__track--active_fill{transition-duration:0ms}.mat-mdc-slider.mat-mdc-slider-with-animation .mdc-slider__thumb,.mat-mdc-slider.mat-mdc-slider-with-animation .mdc-slider__track--active_fill{transition-duration:80ms}.mat-mdc-slider .mdc-slider__track,.mat-mdc-slider .mdc-slider__thumb{pointer-events:none}.mat-mdc-slider .mdc-slider__value-indicator{opacity:var(--mat-slider-value-indicator-opacity)}.mat-mdc-slider .mat-ripple .mat-ripple-element{background-color:var(--mat-mdc-slider-ripple-color, transparent)}.mat-mdc-slider .mat-ripple .mat-mdc-slider-hover-ripple{background-color:var(--mat-mdc-slider-hover-ripple-color, transparent)}.mat-mdc-slider .mat-ripple .mat-mdc-slider-focus-ripple,.mat-mdc-slider .mat-ripple .mat-mdc-slider-active-ripple{background-color:var(--mat-mdc-slider-focus-ripple-color, transparent)}.mat-mdc-slider._mat-animation-noopable.mdc-slider--discrete .mdc-slider__thumb,.mat-mdc-slider._mat-animation-noopable.mdc-slider--discrete .mdc-slider__track--active_fill,.mat-mdc-slider._mat-animation-noopable .mdc-slider__value-indicator{transition:none}.mat-mdc-slider .mat-mdc-focus-indicator::before{border-radius:50%}.mat-mdc-slider .mdc-slider__value-indicator{word-break:normal}.mdc-slider__thumb--focused .mat-mdc-focus-indicator::before{content:""}',
            ],
            encapsulation: 2,
            changeDetection: 0,
          })),
          n
        );
      })();
      const ao = {
        provide: Se.JU,
        useExisting: (0, e.Gpc)(() => Xt),
        multi: !0,
      };
      let Xt = (() => {
          var a;
          class n {
            get value() {
              return (0, ie.su)(this._hostElement.value);
            }
            set value(i) {
              const o = (0, ie.su)(i).toString();
              this._hasSetInitialValue
                ? this._isActive ||
                  ((this._hostElement.value = o),
                  this._updateThumbUIByValue(),
                  this._slider._onValueChange(this),
                  this._cdr.detectChanges(),
                  this._slider._cdr.markForCheck())
                : (this._initialValue = o);
            }
            get translateX() {
              return this._slider.min >= this._slider.max
                ? ((this._translateX = 0), this._translateX)
                : (void 0 === this._translateX && (this._translateX = this._calcTranslateXByValue()), this._translateX);
            }
            set translateX(i) {
              this._translateX = i;
            }
            get min() {
              return (0, ie.su)(this._hostElement.min);
            }
            set min(i) {
              ((this._hostElement.min = (0, ie.su)(i).toString()), this._cdr.detectChanges());
            }
            get max() {
              return (0, ie.su)(this._hostElement.max);
            }
            set max(i) {
              ((this._hostElement.max = (0, ie.su)(i).toString()), this._cdr.detectChanges());
            }
            get step() {
              return (0, ie.su)(this._hostElement.step);
            }
            set step(i) {
              ((this._hostElement.step = (0, ie.su)(i).toString()), this._cdr.detectChanges());
            }
            get disabled() {
              return (0, ie.Ig)(this._hostElement.disabled);
            }
            set disabled(i) {
              ((this._hostElement.disabled = (0, ie.Ig)(i)),
                this._cdr.detectChanges(),
                this._slider.disabled !== this.disabled && (this._slider.disabled = this.disabled));
            }
            get percentage() {
              return this._slider.min >= this._slider.max
                ? this._slider._isRtl
                  ? 1
                  : 0
                : (this.value - this._slider.min) / (this._slider.max - this._slider.min);
            }
            get fillPercentage() {
              return this._slider._cachedWidth
                ? 0 === this._translateX
                  ? 0
                  : this.translateX / this._slider._cachedWidth
                : this._slider._isRtl
                  ? 1
                  : 0;
            }
            _setIsFocused(i) {
              this._isFocused = i;
            }
            constructor(i, o, l, d) {
              ((this._ngZone = i),
                (this._elementRef = o),
                (this._cdr = l),
                (this._slider = d),
                (this.valueChange = new e.vpe()),
                (this.dragStart = new e.vpe()),
                (this.dragEnd = new e.vpe()),
                (this.thumbPosition = 2),
                (this._knobRadius = 8),
                (this._isActive = !1),
                (this._isFocused = !1),
                (this._hasSetInitialValue = !1),
                (this._destroyed = new jt.x()),
                (this._skipUIUpdate = !1),
                (this._onTouchedFn = () => {}),
                (this._isControlInitialized = !1),
                (this._platform = (0, e.f3M)(_n.t4)),
                (this._hostElement = o.nativeElement),
                this._ngZone.runOutsideAngular(() => {
                  (this._hostElement.addEventListener("pointerdown", this._onPointerDown.bind(this)),
                    this._hostElement.addEventListener("pointermove", this._onPointerMove.bind(this)),
                    this._hostElement.addEventListener("pointerup", this._onPointerUp.bind(this)));
                }));
            }
            ngOnDestroy() {
              (this._hostElement.removeEventListener("pointerdown", this._onPointerDown),
                this._hostElement.removeEventListener("pointermove", this._onPointerMove),
                this._hostElement.removeEventListener("pointerup", this._onPointerUp),
                this._destroyed.next(),
                this._destroyed.complete(),
                this.dragStart.complete(),
                this.dragEnd.complete());
            }
            initProps() {
              (this._updateWidthInactive(),
                this.disabled !== this._slider.disabled && (this._slider.disabled = !0),
                (this.step = this._slider.step),
                (this.min = this._slider.min),
                (this.max = this._slider.max),
                this._initValue());
            }
            initUI() {
              this._updateThumbUIByValue();
            }
            _initValue() {
              ((this._hasSetInitialValue = !0),
                void 0 === this._initialValue
                  ? (this.value = this._getDefaultValue())
                  : ((this._hostElement.value = this._initialValue),
                    this._updateThumbUIByValue(),
                    this._slider._onValueChange(this),
                    this._cdr.detectChanges()));
            }
            _getDefaultValue() {
              return this.min;
            }
            _onBlur() {
              (this._setIsFocused(!1), this._onTouchedFn());
            }
            _onFocus() {
              this._setIsFocused(!0);
            }
            _onChange() {
              (this.valueChange.emit(this.value), this._isActive && this._updateThumbUIByValue({ withAnimation: !0 }));
            }
            _onInput() {
              var i;
              (null === (i = this._onChangeFn) || void 0 === i || i.call(this, this.value),
                (this._slider.step || !this._isActive) && this._updateThumbUIByValue({ withAnimation: !0 }),
                this._slider._onValueChange(this));
            }
            _onNgControlValueChange() {
              ((!this._isActive || !this._isFocused) &&
                (this._slider._onValueChange(this), this._updateThumbUIByValue()),
                (this._slider.disabled = this._formControl.disabled));
            }
            _onPointerDown(i) {
              if (!this.disabled && 0 === i.button) {
                if (this._platform.IOS) {
                  const o = this._slider._isCursorOnSliderThumb(
                    i,
                    this._slider._getThumb(this.thumbPosition)._hostElement.getBoundingClientRect(),
                  );
                  return ((this._isActive = o), this._updateWidthActive(), void this._slider._updateDimensions());
                }
                ((this._isActive = !0),
                  this._setIsFocused(!0),
                  this._updateWidthActive(),
                  this._slider._updateDimensions(),
                  this._slider.step || this._updateThumbUIByPointerEvent(i, { withAnimation: !0 }),
                  this.disabled ||
                    (this._handleValueCorrection(i),
                    this.dragStart.emit({
                      source: this,
                      parent: this._slider,
                      value: this.value,
                    })));
              }
            }
            _handleValueCorrection(i) {
              ((this._skipUIUpdate = !0),
                setTimeout(() => {
                  ((this._skipUIUpdate = !1), this._fixValue(i));
                }, 0));
            }
            _fixValue(i) {
              var o;
              const l = i.clientX - this._slider._cachedLeft,
                d = this._slider._cachedWidth,
                p = 0 === this._slider.step ? 1 : this._slider.step,
                g = Math.floor((this._slider.max - this._slider.min) / p),
                A =
                  (Math.round((this._slider._isRtl ? 1 - l / d : l / d) * g) / g) *
                    (this._slider.max - this._slider.min) +
                  this._slider.min,
                E = Math.round(A / p) * p;
              if (E === this.value)
                return (
                  this._slider._onValueChange(this),
                  void (this._slider.step > 0
                    ? this._updateThumbUIByValue()
                    : this._updateThumbUIByPointerEvent(i, {
                        withAnimation: this._slider._hasAnimation,
                      }))
                );
              ((this.value = E),
                this.valueChange.emit(this.value),
                null === (o = this._onChangeFn) || void 0 === o || o.call(this, this.value),
                this._slider._onValueChange(this),
                this._slider.step > 0
                  ? this._updateThumbUIByValue()
                  : this._updateThumbUIByPointerEvent(i, {
                      withAnimation: this._slider._hasAnimation,
                    }));
            }
            _onPointerMove(i) {
              !this._slider.step && this._isActive && this._updateThumbUIByPointerEvent(i);
            }
            _onPointerUp() {
              this._isActive &&
                ((this._isActive = !1),
                this.dragEnd.emit({
                  source: this,
                  parent: this._slider,
                  value: this.value,
                }),
                setTimeout(() => this._updateWidthInactive(), this._platform.IOS ? 10 : 0));
            }
            _clamp(i) {
              return Math.max(Math.min(i, this._slider._cachedWidth), 0);
            }
            _calcTranslateXByValue() {
              return this._slider._isRtl
                ? (1 - this.percentage) * this._slider._cachedWidth
                : this.percentage * this._slider._cachedWidth;
            }
            _calcTranslateXByPointerEvent(i) {
              return i.clientX - this._slider._cachedLeft;
            }
            _updateWidthActive() {
              ((this._hostElement.style.padding = `0 ${this._slider._inputPadding}px`),
                (this._hostElement.style.width = `calc(100% + ${this._slider._inputPadding}px)`));
            }
            _updateWidthInactive() {
              ((this._hostElement.style.padding = "0px"),
                (this._hostElement.style.width = "calc(100% + 48px)"),
                (this._hostElement.style.left = "-24px"));
            }
            _updateThumbUIByValue(i) {
              ((this.translateX = this._clamp(this._calcTranslateXByValue())), this._updateThumbUI(i));
            }
            _updateThumbUIByPointerEvent(i, o) {
              ((this.translateX = this._clamp(this._calcTranslateXByPointerEvent(i))), this._updateThumbUI(o));
            }
            _updateThumbUI(i) {
              (this._slider._setTransition(!(null == i || !i.withAnimation)), this._slider._onTranslateXChange(this));
            }
            writeValue(i) {
              (this._isControlInitialized || null !== i) && (this.value = i);
            }
            registerOnChange(i) {
              ((this._onChangeFn = i), (this._isControlInitialized = !0));
            }
            registerOnTouched(i) {
              this._onTouchedFn = i;
            }
            setDisabledState(i) {
              this.disabled = i;
            }
            focus() {
              this._hostElement.focus();
            }
            blur() {
              this._hostElement.blur();
            }
          }
          return (
            ((a = n).ɵfac = function (i) {
              return new (i || a)(e.Y36(e.R0b), e.Y36(e.SBq), e.Y36(e.sBO), e.Y36(Ct));
            }),
            (a.ɵdir = e.lG2({
              type: a,
              selectors: [["input", "matSliderThumb", ""]],
              hostAttrs: ["type", "range", 1, "mdc-slider__input"],
              hostVars: 1,
              hostBindings: function (i, o) {
                (1 & i &&
                  e.NdJ("change", function () {
                    return o._onChange();
                  })("input", function () {
                    return o._onInput();
                  })("blur", function () {
                    return o._onBlur();
                  })("focus", function () {
                    return o._onFocus();
                  }),
                  2 & i && e.uIk("aria-valuetext", o._valuetext));
              },
              inputs: { value: "value" },
              outputs: {
                valueChange: "valueChange",
                dragStart: "dragStart",
                dragEnd: "dragEnd",
              },
              exportAs: ["matSliderThumb"],
              features: [e._Bn([ao, { provide: hn, useExisting: a }])],
            })),
            n
          );
        })(),
        co = (() => {
          var a;
          class n {}
          return (
            ((a = n).ɵfac = function (i) {
              return new (i || a)();
            }),
            (a.ɵmod = e.oAB({ type: a })),
            (a.ɵinj = e.cJS({ imports: [De.BQ, De.si] })),
            n
          );
        })();
      function uo(a, n) {
        if ((1 & a && e._UZ(0, "bs-icon", 11), 2 & a)) {
          const t = e.oxw().$implicit;
          e.Q6J("name", t.iconName)("ngClass", t.iconColor);
        }
      }
      function _o(a, n) {
        if (1 & a) {
          const t = e.EpF();
          (e.TgZ(0, "td", 9),
            e.NdJ("touchstart", function (o) {
              const d = e.CHM(t).$implicit,
                p = e.oxw(2);
              return e.KtG(p.onTouchStart(o, d));
            })("touchend", function (o) {
              const d = e.CHM(t).$implicit,
                p = e.oxw(2);
              return e.KtG(p.onTouchEnd(o, d));
            })("mousedown", function (o) {
              const d = e.CHM(t).$implicit,
                p = e.oxw(2);
              return e.KtG(p.onTouchStart(o, d));
            })("mouseup", function (o) {
              const d = e.CHM(t).$implicit,
                p = e.oxw(2);
              return e.KtG(p.onTouchEnd(o, d));
            }),
            e.YNc(1, uo, 1, 2, "bs-icon", 10),
            e.qZA());
        }
        if (2 & a) {
          const t = n.$implicit,
            i = e.oxw(2);
          (e.ekj("active", i._keyItem === t),
            e.Q6J("ngClass", (t.key === i.ENTER ? "rounded-1 " : " ") + t.color),
            e.uIk("rowspan", t.rowspan)("colspan", t.colspan)("data-key", t.key)(
              "data-icon",
              t.key === i.ENTER ? (null == i.kp ? null : i.kp.entertext) : t.key,
            ),
            e.xp6(1),
            e.Q6J("ngIf", !!t.iconName));
        }
      }
      function ho(a, n) {
        if ((1 & a && (e.TgZ(0, "tr"), e.YNc(1, _o, 2, 8, "td", 8), e.qZA()), 2 & a)) {
          const t = n.$implicit;
          (e.xp6(1), e.Q6J("ngForOf", t));
        }
      }
      const po = (0, b.f0)(() => (0, b.Ji)("--virtual-keyboard-cover-height", "<length>", 0, "false"));
      let mo = (() => {
        var a;
        class n {
          constructor() {
            ((this.cssProp = po()),
              (this.layout = "number"),
              (this.entertext = "\u786E\u8BA4"),
              (this.sliderValue = 0),
              (this.hostEle = document.querySelector("common-pages-outlet")),
              (this.sliderValueChange = new e.vpe()),
              (this.press = new e.vpe()),
              (this.enterpress = new e.vpe()),
              (this.longPress = new e.vpe()),
              (this.longEnterpress = new e.vpe()),
              (this.longPressEnd = new e.vpe()),
              (this.longEnterpressEnd = new e.vpe()),
              (this.eleRef = (0, e.f3M)(e.SBq)),
              (this.destroy$ = new jt.x()),
              (this.ks = { resolvedLayout: [] }),
              (this.ENTER = Ie),
              (this.DEL = nt),
              (this.ESC = At),
              (this.touchEnd$ = new jt.x()),
              (this.touchMove$ = (0, Bi.R)(document, "touchmove").pipe((0, Vt.R)(this.destroy$))));
          }
          getSliderValueChange(i) {
            this.sliderValueChange.emit(i);
          }
          ngOnInit() {
            this.init({ layout: this.layout, entertext: this.entertext });
          }
          ngAfterViewInit() {
            this.setPageKeyHeight();
          }
          _setStyle(i, o, l) {
            i.style.setProperty(o, l);
          }
          _removeStyle(i, o) {
            i.style.removeProperty(o);
          }
          setPageKeyHeight() {
            var i;
            const o =
              null === (i = this.eleRef.nativeElement.querySelector("table")) || void 0 === i ? void 0 : i.offsetHeight;
            var l;
            void 0 === o || o <= 0
              ? setTimeout(() => {
                  this.setPageKeyHeight();
                }, 380)
              : this.hostEle &&
                (this._setStyle(this.hostEle, this.cssProp, o + "px"),
                null === (l = this.numericInput) ||
                  void 0 === l ||
                  l.scrollIntoView({ behavior: "smooth", block: "end" }));
          }
          stopEvent(i) {
            (i.stopPropagation(), i.preventDefault());
          }
          onTouchStart(i, o) {
            (i instanceof MouseEvent && "ontouchstart" in document.documentElement) ||
              ((this._keyItem = o),
              (this.touchStart = i),
              (0, Fi.H)(500)
                .pipe((0, $i.U)(() => o))
                .pipe((0, Vt.R)((0, Wi.T)(this.touchEnd$, this.touchMove$)))
                .subscribe((l) => {
                  ((this.touchStart = void 0), this.longPress.emit(l.key), l.key === Ie && this.longEnterpress.emit());
                }));
          }
          onTouchEnd(i, o) {
            (i instanceof MouseEvent && "ontouchstart" in document.documentElement) ||
              ((this._keyItem = void 0),
              this.touchEnd$.next(o),
              this.touchStart || (this.longPressEnd.emit(o.key), o.key === Ie && this.longEnterpressEnd.emit(o.key)),
              (0, ji.of)(o)
                .pipe(
                  (0, Vi.h)(() => void 0 !== this.touchStart),
                  (0, Vt.R)(this.touchMove$),
                )
                .subscribe((l) => {
                  (this.press.emit(l.key), l.key === Ie && this.enterpress.emit());
                }));
          }
          init(i) {
            const { layout: o } = i;
            let l;
            if ("string" == typeof o) {
              if (((l = Gi[o]), !1 === Array.isArray(l))) throw new Error(`${o} is not a build-in layout.`);
            } else {
              if (null == o || !1 === Array.isArray(o) || !1 === o.every((d) => Array.isArray(d)))
                throw new Error("custom layout must be a two-dimensional array.");
              l = o;
            }
            ((this.kp = i), (this.ks = { resolvedLayout: l }));
          }
          ngOnDestroy() {
            (this.destroy$.next(),
              this.destroy$.complete(),
              this.hostEle && this._removeStyle(this.hostEle, this.cssProp));
          }
          sliderLabel(i) {
            return `${i}%`;
          }
        }
        return (
          ((a = n).ɵfac = function (i) {
            return new (i || a)();
          }),
          (a.ɵcmp = e.Xpm({
            type: a,
            selectors: [["bs-numeric-keyboard"]],
            inputs: {
              layout: "layout",
              entertext: "entertext",
              numericInput: "numericInput",
            },
            outputs: {
              sliderValueChange: "sliderValueChange",
              press: "press",
              enterpress: "enterpress",
              longPress: "longPress",
              longEnterpress: "longEnterpress",
              longPressEnd: "longPressEnd",
              longEnterpressEnd: "longEnterpressEnd",
            },
            standalone: !0,
            features: [e.jDz],
            decls: 9,
            vars: 4,
            consts: [
              [
                1,
                "numeric-keyboard",
                "border-t-tiny",
                "border-gray-1",
                "text-2xl",
                2,
                "padding-bottom",
                "var(--env-safe-area-inset-bottom)",
              ],
              [1, "h-12"],
              ["colspan", "3"],
              ["discrete", "", 1, "keyboard-slider", "w-[76%]", 3, "displayWith"],
              ["matSliderThumb", "", 3, "ngModel", "ngModelChange", "valueChange"],
              ["colspan", "1"],
              [
                1,
                "border-tiny",
                "border-text",
                "rounded-1",
                "flex",
                "h-8",
                "items-center",
                "justify-center",
                "text-sm",
              ],
              [4, "ngFor", "ngForOf"],
              [
                "class",
                "numeric-keyboard-key font-semibold",
                3,
                "ngClass",
                "active",
                "touchstart",
                "touchend",
                "mousedown",
                "mouseup",
                4,
                "ngFor",
                "ngForOf",
              ],
              [
                1,
                "numeric-keyboard-key",
                "font-semibold",
                3,
                "ngClass",
                "touchstart",
                "touchend",
                "mousedown",
                "mouseup",
              ],
              ["class", "text-2xl", 3, "name", "ngClass", 4, "ngIf"],
              [1, "text-2xl", 3, "name", "ngClass"],
            ],
            template: function (i, o) {
              (1 & i &&
                (e.TgZ(0, "table", 0)(1, "tr", 1)(2, "td", 2)(3, "mat-slider", 3)(4, "input", 4),
                e.NdJ("ngModelChange", function (d) {
                  return (o.sliderValue = d);
                })("valueChange", function (d) {
                  return o.getSliderValueChange(d);
                }),
                e.qZA()()(),
                e.TgZ(5, "td", 5)(6, "div", 6),
                e._uU(7),
                e.qZA()()(),
                e.YNc(8, ho, 2, 1, "tr", 7),
                e.qZA()),
                2 & i &&
                  (e.xp6(3),
                  e.Q6J("displayWith", o.sliderLabel),
                  e.xp6(1),
                  e.Q6J("ngModel", o.sliderValue),
                  e.xp6(3),
                  e.hij(" ", o.sliderValue, "% "),
                  e.xp6(1),
                  e.Q6J("ngForOf", o.ks.resolvedLayout)));
            },
            dependencies: [x.f5, an.B, _.mk, _.sg, _.O5, Se.Fj, Se.JJ, Se.On, O.oJ, co, oo, Xt],
            styles: [
              '.half[_ngcontent-%COMP%]{height:50%}  .keyboard-slider{--mdc-slider-handle-width: 14px;--mdc-slider-handle-height: 14px;--mdc-slider-active-track-color: #640ff3;--mdc-slider-label-container-color: #640ff3;--mat-slider-value-indicator-opacity: 1}  .keyboard-slider .mdc-slider__value-indicator-container{bottom:38px!important}  .keyboard-slider .mdc-slider__value-indicator-container .mdc-slider__value-indicator{font-size:12px!important;line-height:22px!important;height:22px!important;padding:0 4px!important;transition:none!important}  .keyboard-slider .mdc-slider__value-indicator-container .mdc-slider__value-indicator:before{border-left:3px solid rgba(0,0,0,0)!important;border-right:3px solid rgba(0,0,0,0)!important;border-top:4px solid #640ff3!important;bottom:-4px!important}  .keyboard-slider .mdc-slider__thumb-knob{border:2px solid #640ff3!important;background:white!important}  .keyboard-slider .mdc-slider__track--inactive{background-color:#eaedf0!important;opacity:1!important}.numeric-keyboard[_ngcontent-%COMP%]{padding-left:4px;padding-right:4px;width:100%;background:#fff;table-layout:fixed;border-collapse:separate;border-spacing:4px;text-align:center}.numeric-keyboard-key[_ngcontent-%COMP%]{touch-action:manipulation;transition:background .3s;color:#050615;padding:5px 0}.numeric-keyboard-key.active[_ngcontent-%COMP%]{background:#e1e1e1}.numeric-keyboard-key[data-key=""][_ngcontent-%COMP%]{pointer-events:none}.numeric-keyboard-key[data-key=enter][_ngcontent-%COMP%]{color:#5695e8;background:#640ff3;font-size:20px;letter-spacing:-.5px!important}.numeric-keyboard-key[data-key=del][_ngcontent-%COMP%], .numeric-keyboard-key[data-key="."][_ngcontent-%COMP%]{color:#4c4c4c}.numeric-keyboard-key[data-key=del][_ngcontent-%COMP%]:active, .numeric-keyboard-key[data-key="."][_ngcontent-%COMP%]:active{background:#d5d5d5}.numeric-keyboard-key[data-icon][_ngcontent-%COMP%]:before{content:attr(data-icon)}.numeric-keyboard-key[data-icon=esc][_ngcontent-%COMP%]:before, .numeric-keyboard-key[data-icon=del][_ngcontent-%COMP%]:before{display:block;content:" "}.numeric-keyboard-actionsheet[_nghost-%COMP%]{position:fixed;bottom:0;left:0;width:100%;height:40%}.numeric-keyboard-actionsheet[_nghost-%COMP%] > div[_ngcontent-%COMP%]:first-child{height:100%}.numeric-keyboard-actionsheet[_nghost-%COMP%] > div[_ngcontent-%COMP%]:last-child{position:absolute;top:0;right:0;bottom:0;left:0;transform:translateY(100%);box-shadow:0 -2px 4px #cfd4da}',
            ],
          })),
          n
        );
      })();
      var Ue;
      function go(a, n) {
        if ((1 & a && (e.TgZ(0, "span", 7), e._uU(1), e.qZA()), 2 & a)) {
          const t = n.$implicit;
          (e.uIk("data-index", n.index), e.xp6(1), e.hij(" ", t, " "));
        }
      }
      function fo(a, n) {
        if ((1 & a && e._UZ(0, "span", 8), 2 & a)) {
          const t = e.oxw();
          e.uIk("data-index", null == t.ks || null == t.ks.rawValue ? null : t.ks.rawValue.length);
        }
      }
      function So(a, n) {
        if ((1 & a && (e.TgZ(0, "div", 9)(1, "span", 10), e._uU(2), e.qZA()()), 2 & a)) {
          const t = e.oxw();
          (e.xp6(2), e.hij(" ", null == t.kp ? null : t.kp.placeholder, " "));
        }
      }
      function To(a, n) {
        if ((1 & a && e._UZ(0, "div", 11), 2 & a)) {
          const t = e.oxw();
          e.Udp("background", null == t.ks ? null : t.ks.cursorColor);
        }
      }
      const vo = /^\d*(?:\.\d*)?$/,
        bo = /^\d*$/,
        Ht = (() => {
          let a;
          return {
            register(n) {
              (this.unregister(void 0),
                (a = n),
                document.addEventListener("touchend", this.unregister, !1),
                document.addEventListener("mouseup", this.unregister, !1));
            },
            unregister(n) {
              if (a) {
                if (n && (a.ks.inputElement.contains(n.target) || a.ks.keyboardElement.contains(n.target))) return;
                (a.closeKeyboard(),
                  (a = null),
                  document.removeEventListener("touchend", this.unregister, !1),
                  document.removeEventListener("mouseup", this.unregister, !1));
              }
            },
          };
        })(),
        le = {
          type: "number",
          value: "",
          autofocus: !1,
          disabled: !1,
          readonly: !1,
          maxlength: 255,
          maxDecimals: 255,
          name: "",
          placeholder: "",
          format: "^",
          layout: "string",
          entertext: "\u786E\u8BA4",
        };
      class we extends x.Wh {
        constructor() {
          (super(...arguments),
            (this._autofocus = le.autofocus),
            (this._disabled = le.disabled),
            (this._readonly = le.readonly),
            (this._value = le.value),
            (this.activeColor = "#3B3B3B"),
            (this.isFocus = !1),
            (this.maxValue = ""),
            (this.type = le.type),
            (this.value = le.value),
            (this.maxlength = le.maxlength),
            (this.maxDecimals = le.maxDecimals),
            (this.name = le.name),
            (this.placeholder = le.placeholder),
            (this.format = le.format),
            (this.layout = le.layout),
            (this.entertext = le.entertext),
            (this.inputFocus = new e.vpe()),
            (this.inputBlur = new e.vpe()),
            (this.enterpress = new e.vpe()),
            (this.ngModelChange = new e.vpe()),
            (this._onChange = () => {}),
            (this.element = (0, e.f3M)(e.SBq)),
            (this.appRef = (0, e.f3M)(e.z2F)),
            (this.componentFactoryResolver = (0, e.f3M)(e._Vd)));
        }
        get autofocus() {
          return this._autofocus;
        }
        set autofocus(n) {
          ((this._autofocus = Wt(n)), this.cdRef.detectChanges());
        }
        get disabled() {
          return this._disabled;
        }
        set disabled(n) {
          ((this._disabled = Wt(n)), this.cdRef.detectChanges());
        }
        get readonly() {
          return this._readonly;
        }
        set readonly(n) {
          ((this._readonly = Wt(n)), this.cdRef.detectChanges());
        }
        get ngModel() {
          return this._value;
        }
        set ngModel(n) {
          if (this.ks && (this.ks.value !== n || this.ks.rawValue.join("") !== n)) {
            const t = n.toString().split(""),
              i = t.length;
            (this.set("rawValue", t), this.set("cursorPos", i));
          }
          ((this._value = n), this.cdRef.detectChanges());
        }
        onInit() {
          const n = {};
          (Object.keys(le).forEach((t) => {
            n[t] = Reflect.get(this, t);
          }),
            this.init(n),
            this.cdRef.detectChanges());
        }
        onDestroy() {
          Ht.unregister(null);
        }
        afterViewInit() {
          this.onMounted(this.element.nativeElement.querySelector(".numeric-input"));
        }
        ngAfterViewChecked() {
          (this.onUpdated(), this.cdRef.detectChanges());
        }
        trackByIndex(n) {
          return n;
        }
        writeValue(n) {
          ((this._value = typeof n > "u" || null === n ? "" : n), this.cdRef.detectChanges());
        }
        registerOnChange(n) {
          this._onChange = n;
        }
        registerOnTouched() {}
        onFocus(n) {
          if ((n.stopPropagation(), n instanceof MouseEvent && "ontouchstart" in document.documentElement)) return;
          this.openKeyboard();
          const t = n.target;
          if (t) {
            const i = +(t.dataset.index || this.ks.rawValue.length);
            (this.set("cursorPos", isNaN(i) ? this.ks.rawValue.length : i), this.cdRef.detectChanges());
          }
        }
        dispatch(n, t) {
          switch (n) {
            case "focus":
              this.inputFocus.emit();
              break;
            case "blur":
              this.inputBlur.emit();
              break;
            case "enterpress":
              this.enterpress.emit();
              break;
            case "input":
              this.ngModelChange.emit(t);
          }
          this.cdRef.detectChanges();
        }
        createKeyboard(n, t, i, o) {
          const l = this.componentFactoryResolver.resolveComponentFactory(mo).create(this.injector);
          (Object.assign(l.instance, t), l.instance.ngOnInit());
          for (const p in i) Reflect.get(l.instance, p).subscribe(i[p]);
          (this.appRef.attachView(l.hostView),
            n.appendChild(l.hostView.rootNodes[0]),
            o(l),
            this.cdRef.detectChanges());
        }
        destroyKeyboard(n, t) {
          (t.destroy(), this.appRef.detachView(t.hostView), this.cdRef.detectChanges());
        }
        init(n) {
          let t = n.format;
          var d;
          "string" == typeof t && ((d = new RegExp(n.format)), (t = (p) => d.test(p)));
          const i = n.value,
            o = i.toString().split(""),
            l = o.length;
          ((this.kp = n),
            (this.ks = {
              formatFn: t,
              value: i,
              rawValue: o,
              cursorPos: l,
              cursorColor: null,
              cursorActive: !1,
              keyboard: null,
              inputElement: null,
              keyboardElement: null,
            }),
            this.cdRef.detectChanges());
        }
        set(n, t) {
          (Reflect.set(this.ks, n, t), this.cdRef.detectChanges());
        }
        onMounted(n) {
          (this.set("inputElement", n),
            this.set("cursorColor", this.activeColor),
            this.kp.autofocus &&
              null == this.kp.readonly &&
              null == this.kp.disabled &&
              setTimeout(() => this.openKeyboard(), 500));
        }
        onUpdated() {
          (this.moveCursor(), this.cdRef.detectChanges());
        }
        sliderValueChange(n) {
          if (!1 === isNaN(+this.maxValue)) {
            const i = this.injectorForceGet(W.lQ).getPrecisionInteger(this.maxValue, 8),
              o = new N.Z(String((BigInt(i) * BigInt(n)) / BigInt(100))).dividedBy(1e8).toFixed(8, 1);
            this.dispatch("input", o);
          }
        }
        input(n) {
          const { type: t, maxlength: i, maxDecimals: o } = this.kp,
            { rawValue: l, cursorPos: d, formatFn: p } = this.ks,
            g = (T) => {
              const v = typeof T < "u",
                A = l.slice();
              v ? A.splice(d, 0, T) : A.splice(d - 1, 1);
              let E = A.join("");
              if (p(E)) {
                if ("number" === t) {
                  if (!1 === vo.test(E)) return;
                  isNaN(parseFloat(E)) && (E = "");
                } else if (E.length > i || ("tel" === t && !1 === bo.test(E))) return;
                const w = E.split(".");
                if (w[1] && w[1].length > o) return;
                (this.set("value", E),
                  this.set("rawValue", A),
                  this.set("cursorPos", v ? d + 1 : d - 1),
                  this.dispatch("input", E));
              }
            };
          switch (n) {
            case "":
              break;
            case At:
              this.closeKeyboard();
              break;
            case Ie:
              (this.closeKeyboard(), this.dispatch("enterpress"));
              break;
            case nt:
              d > 0 && g(void 0);
              break;
            default:
              g(n);
          }
          this.cdRef.detectChanges();
        }
        moveCursor() {
          if (this.ks.cursorActive) {
            const n = this.ks.inputElement.querySelector(".numeric-input-cursor"),
              t = this.ks.inputElement.querySelector(".numeric-input-text"),
              i = t.querySelector(`span:nth-child(${this.ks.cursorPos})`);
            if (null == i) return ((n.style.transform = "translateX(0)"), void (t.style.transform = "translateX(0)"));
            const o = i.offsetLeft + i.offsetWidth,
              l = t.parentNode.offsetWidth;
            ((n.style.transform = `translateX(${Math.min(l - 1, o)}px)`),
              (t.style.transform = `translateX(${Math.min(0, l - o)}px)`),
              this.cdRef.detectChanges());
          }
        }
        openKeyboard() {
          if (this.ks.keyboard) return;
          const n = document.createElement("div"),
            t = document.createElement("div"),
            i = document.createElement("div");
          ((n.className = "numeric-keyboard-actionsheet"),
            n.appendChild(t),
            n.appendChild(i),
            document.body.appendChild(n));
          const o = this.input.bind(this),
            l = this.sliderValueChange.bind(this);
          (this.createKeyboard(
            i,
            {
              layout: this.kp.layout || this.kp.type,
              entertext: this.kp.entertext,
              numericInput: this.hostElement,
            },
            { press: o, longPress: o, sliderValueChange: l },
            (d) => this.set("keyboard", d),
          ),
            un(
              (d, p, g) => {
                ((i.style.position = "fixed"),
                  (i.style.bottom = "0"),
                  (i.style.left = "0"),
                  (i.style.transform = `translateY(${((g - p) / g) * 100}%)`));
              },
              () => {},
              10,
            ),
            this.set("keyboardElement", i),
            this.set("cursorActive", !0),
            this.set("cursorPos", this.ks.rawValue.length),
            (this.isFocus = !0),
            this.dispatch("focus"),
            Ht.register(this),
            this.cdRef.detectChanges());
        }
        closeKeyboard() {
          if (this.ks.keyboard) {
            const n = this.ks.keyboard,
              t = this.ks.keyboardElement;
            (un(
              (i, o, l) => {
                t.style.transform = `translateY(${(o / l) * 100}%)`;
              },
              () => {
                setTimeout(() => {
                  (this.destroyKeyboard(t, n), document.body.removeChild(t.parentNode));
                }, 50);
              },
              10,
            ),
              this.set("keyboard", null),
              this.set("keyboardElement", null),
              this.set("cursorActive", !1),
              this.set("cursorPos", 0),
              (this.isFocus = !1),
              this.dispatch("blur"),
              Ht.unregister(null),
              this.cdRef.detectChanges());
          }
        }
      }
      (((Ue = we).ɵfac = (() => {
        let a;
        return function (t) {
          return (a || (a = e.n5z(Ue)))(t || Ue);
        };
      })()),
        (Ue.ɵcmp = e.Xpm({
          type: Ue,
          selectors: [["bs-numeric-input"]],
          inputs: {
            activeColor: "activeColor",
            autofocus: "autofocus",
            disabled: "disabled",
            readonly: "readonly",
            ngModel: "ngModel",
            maxValue: "maxValue",
            type: "type",
            value: "value",
            maxlength: "maxlength",
            maxDecimals: "maxDecimals",
            name: "name",
            placeholder: "placeholder",
            format: "format",
            layout: "layout",
            entertext: "entertext",
          },
          outputs: {
            inputFocus: "inputFocus",
            inputBlur: "inputBlur",
            enterpress: "enterpress",
            ngModelChange: "ngModelChange",
          },
          standalone: !0,
          features: [e._Bn([{ provide: Se.JU, useExisting: (0, e.Gpc)(() => Ue), multi: !0 }]), e.qOj, e.jDz],
          decls: 8,
          vars: 9,
          consts: [
            [1, "numeric-input-container"],
            [1, "numeric-input", 3, "touchend", "mouseup"],
            [1, "numeric-input-text", "flex"],
            ["class", "input-text", 4, "ngFor", "ngForOf", "ngForTrackBy"],
            ["class", "input-text w-1", 4, "ngIf"],
            ["class", "numeric-input-placeholder", 4, "ngIf"],
            ["class", "numeric-input-cursor blinking-cursor", 3, "background", 4, "ngIf"],
            [1, "input-text"],
            [1, "input-text", "w-1"],
            [1, "numeric-input-placeholder"],
            [1, "typo-placeholder", "font-normal", "text-title-2"],
            [1, "numeric-input-cursor", "blinking-cursor"],
          ],
          template: function (n, t) {
            (1 & n &&
              (e.TgZ(0, "div", 0)(1, "div", 1),
              e.NdJ("touchend", function (o) {
                return t.onFocus(o);
              })("mouseup", function (o) {
                return t.onFocus(o);
              }),
              e.TgZ(2, "div")(3, "div", 2),
              e.YNc(4, go, 2, 2, "span", 3)(5, fo, 1, 1, "span", 4),
              e.qZA(),
              e.YNc(6, So, 3, 1, "div", 5)(7, To, 1, 2, "div", 6),
              e.qZA()()()),
              2 & n &&
                (e.xp6(1),
                e.ekj("readonly", null == t.kp ? null : t.kp.readonly)("disabled", null == t.kp ? null : t.kp.disabled),
                e.xp6(3),
                e.Q6J("ngForOf", null == t.ks ? null : t.ks.rawValue)("ngForTrackBy", t.trackByIndex),
                e.xp6(1),
                e.Q6J("ngIf", 0 !== (null == t.ks || null == t.ks.rawValue ? null : t.ks.rawValue.length)),
                e.xp6(1),
                e.Q6J("ngIf", 0 === (null == t.ks || null == t.ks.rawValue ? null : t.ks.rawValue.length)),
                e.xp6(1),
                e.Q6J("ngIf", null == t.ks ? null : t.ks.cursorActive)));
          },
          dependencies: [x.f5, _.sg, _.O5],
          styles: [
            ".numeric-input-container[_ngcontent-%COMP%]{display:flex;text-align:left}.numeric-input-container[_ngcontent-%COMP%]   .numeric-input[_ngcontent-%COMP%]{display:block;background:transparent;width:100%;height:100%;padding:0;text-align:inherit}.numeric-input-container[_ngcontent-%COMP%]   .numeric-input.readonly[_ngcontent-%COMP%], .numeric-input-container[_ngcontent-%COMP%]   .numeric-input.disabled[_ngcontent-%COMP%]{opacity:.5;pointer-events:none}.numeric-input-container[_ngcontent-%COMP%]   .numeric-input[_ngcontent-%COMP%] > div[_ngcontent-%COMP%]{position:relative;overflow:hidden;height:100%}.numeric-input-container[_ngcontent-%COMP%]   .numeric-input-placeholder[_ngcontent-%COMP%]{color:#757575}.numeric-input-container[_ngcontent-%COMP%]   .numeric-input-text[_ngcontent-%COMP%]{width:10000%}.numeric-input-container[_ngcontent-%COMP%]   .numeric-input-cursor[_ngcontent-%COMP%]{pointer-events:none;position:absolute;left:1px;top:1px;width:1px;height:90%;animation:_ngcontent-%COMP%_numeric-input-cursor 1s steps(1) infinite}@keyframes _ngcontent-%COMP%_numeric-input-cursor{50%{background-color:transparent}}",
          ],
        })),
        (0, s.gn)(
          [
            we.OnInit(),
            (0, s.w6)("design:type", Function),
            (0, s.w6)("design:paramtypes", []),
            (0, s.w6)("design:returntype", void 0),
          ],
          we.prototype,
          "onInit",
          null,
        ),
        (0, s.gn)(
          [
            we.OnDestroy(),
            (0, s.w6)("design:type", Function),
            (0, s.w6)("design:paramtypes", []),
            (0, s.w6)("design:returntype", void 0),
          ],
          we.prototype,
          "onDestroy",
          null,
        ),
        (0, s.gn)(
          [
            we.OnReady(),
            (0, s.w6)("design:type", Function),
            (0, s.w6)("design:paramtypes", []),
            (0, s.w6)("design:returntype", void 0),
          ],
          we.prototype,
          "afterViewInit",
          null,
        ));
      var Je,
        Ao = r(13950),
        Co = r(84375);
      function Eo(a, n) {
        1 & a && (e.TgZ(0, "div", 9), e._UZ(1, "img", 10), e.TgZ(2, "div", 11), e.SDv(3, 12), e.qZA()());
      }
      function yo(a, n) {
        if ((1 & a && (e.TgZ(0, "div", 21), e._uU(1), e.ALo(2, "chainNameTransfer"), e.qZA()), 2 & a)) {
          const t = e.oxw().$implicit;
          (e.xp6(1), e.hij(" ", e.lcZ(2, 1, t.quoteCoinsChainName), " "));
        }
      }
      const gn = () => ({ removeZero: !0 });
      function No(a, n) {
        if (1 & a) {
          const t = e.EpF();
          (e.TgZ(0, "div", 16),
            e.NdJ("click", function () {
              const l = e.CHM(t).$implicit,
                d = e.oxw(3);
              return e.KtG(d.jumpDetail(l.poolId));
            }),
            e.TgZ(1, "div", 17),
            e._UZ(2, "bs-token-with-chain-icon", 18),
            e.TgZ(3, "div", 19)(4, "div", 20),
            e._uU(5),
            e.qZA(),
            e.TgZ(6, "div", 21),
            e._uU(7),
            e.ALo(8, "chainNameTransfer"),
            e.qZA()(),
            e._UZ(9, "div", 22)(10, "bs-icon", 23),
            e.TgZ(11, "div", 19)(12, "div", 24),
            e._uU(13),
            e.qZA(),
            e.YNc(14, yo, 3, 3, "div", 25),
            e.qZA(),
            e._UZ(15, "bs-icon", 26),
            e.qZA(),
            e.TgZ(16, "div", 27)(17, "div", 28),
            e.SDv(18, 29),
            e.qZA(),
            e.TgZ(19, "div", 30)(20, "div", 31),
            e._uU(21),
            e.ALo(22, "amountFixed"),
            e.qZA(),
            e._UZ(23, "bs-swap-token-chain-icon", 32),
            e.TgZ(24, "div", 31),
            e._uU(25),
            e.ALo(26, "amountFixed"),
            e.qZA(),
            e._UZ(27, "bs-icon", 33),
            e.qZA()()());
        }
        if (2 & a) {
          const t = n.$implicit,
            i = e.oxw(3);
          (e.xp6(2),
            e.Q6J("swapChainName", t.anchorCoinsChainName)("swapCoinName", t.anchorCoinsName),
            e.xp6(3),
            e.Oqu(t.anchorCoinsName),
            e.xp6(2),
            e.hij(" ", e.lcZ(8, 16, t.anchorCoinsChainName), " "),
            e.xp6(3),
            e.Q6J("defaultName", "token-Default")("iconUrl", i.getLogoUrlInfo(t.quoteCoinsChainName, i.uName))(
              "name",
              i.transferToTokenIconBychainName(t.quoteCoinsChainName, i.uName),
            ),
            e.xp6(3),
            e.Oqu(i.uName),
            e.xp6(1),
            e.um2(14, i.noBigU(t.quoteCoinsChainName, t.quoteCoinsName) ? 14 : -1),
            e.xp6(7),
            e.hij(" ", e.Dn7(22, 18, t.userRedeemableAnchorCoinsAmount, 8, e.DdM(26, gn)), " "),
            e.xp6(2),
            e.Q6J("swapCoinName", t.anchorCoinsName)("swapChainName", t.anchorCoinsChainName),
            e.xp6(2),
            e.hij(" ", e.Dn7(26, 22, t.userRedeemableQuoteCoinsAmount, 8, e.DdM(27, gn)), " "),
            e.xp6(2),
            e.Q6J("defaultName", "token-Default")("iconUrl", i.getLogoUrlInfo(t.quoteCoinsChainName, i.uName))(
              "name",
              i.transferToTokenIconBychainName(t.quoteCoinsChainName, i.uName),
            ));
        }
      }
      function xo(a, n) {
        if (1 & a) {
          const t = e.EpF();
          (e.TgZ(0, "div", 14),
            e.NdJ("pulled$", function (o) {
              e.CHM(t);
              const l = e.oxw(2);
              return e.KtG(o.waitFor(l.refresh()));
            }),
            e._UZ(1, "bn-pull-to-refresh-spinner"),
            e.SjG(2, No, 28, 28, "div", 34, e.ikw),
            e._UZ(4, "div", 15),
            e.qZA());
        }
        if (2 & a) {
          const t = e.oxw(2);
          (e.Q6J("emitDistance", 158)("maxDistance", 200), e.xp6(2), e.wJu(t.dataList));
        }
      }
      function Po(a, n) {
        1 & a && (e.TgZ(0, "div", 35), e._UZ(1, "img", 36), e.TgZ(2, "div"), e.SDv(3, 37), e.qZA()());
      }
      function Io(a, n) {
        if ((1 & a && e.YNc(0, xo, 5, 2, "div", 13)(1, Po, 4, 0), 2 & a)) {
          const t = e.oxw();
          e.um2(0, t.dataList.length > 0 ? 0 : 1);
        }
      }
      function wo(a, n) {
        (1 & a && (e.TgZ(0, "div", 38), e._UZ(1, "bn-loading-wrapper", 39), e.TgZ(2, "p", 40), e.SDv(3, 41), e.qZA()()),
          2 & a && (e.xp6(1), e.Q6J("showLoading", !0)));
      }
      const Mo = () => ({ "--page-safe-area-inset-top": 0 });
      class Y extends x.Wh {
        constructor() {
          (super(...arguments),
            (this.poolService = (0, e.f3M)(Be.X)),
            (this.userService = (0, e.f3M)(it.f)),
            (this.walletService = (0, e.f3M)(R.X)),
            (this.connectedWallet = this.walletService.connectedWallet),
            (this.searchkey = ""),
            (this.init = !1),
            (this.commonService = (0, e.f3M)(Re._)),
            (this.uName = ""),
            (this.dataList = []));
        }
        getLogoUrlInfo(n, t) {
          return (0, O.Yq)(t, n);
        }
        transferToTokenIconBychainName(n, t) {
          return (0, y.TH)(n, t);
        }
        jumpDetail(n) {
          var t;
          const i = null === (t = this.connectedWallet) || void 0 === t ? void 0 : t.pmchainAddress;
          i &&
            this.nav.routeTo("/mine/my-holdings-detail", {
              userId: i,
              poolId: n,
            });
        }
        onresume() {
          this.console.log("onresume HoldingsPage");
        }
        unsubscribe() {
          this.subscription && this.subscription.unsubscribe();
        }
        walletInit() {
          var n = this;
          ((this.subscription = this.commonService.virtualCoinAlias.subscribe((t) => {
            ((this.uName = t), this.cdRef.detectChanges());
          })),
            (this.connectWallet$ = this.walletService.wallletConnected_subject.subscribe(
              (function () {
                var t = (0, c.Z)(function* (i) {
                  if (void 0 === i) return;
                  const { wallet: o } = i;
                  ((n.connectedWallet = o), o ? n.getDataList() : ((n.dataList = []), (n.init = !1)));
                });
                return function (i) {
                  return t.apply(this, arguments);
                };
              })(),
            )));
        }
        jumpAddLiquidity() {
          this.connectedWallet ? this.nav.routeTo("/add-liquidity") : $.F.show("\u8BF7\u5148\u8FDE\u63A5\u94B1\u5305");
        }
        jumpRecordPage() {
          this.connectedWallet ? this.nav.routeTo("/mine/my-record") : $.F.show("\u8BF7\u5148\u8FDE\u63A5\u94B1\u5305");
        }
        refresh() {
          var n = this;
          return (0, c.Z)(function* () {
            n.getDataList();
          })();
        }
        jumpRemovePage(n) {
          this.nav.routeTo("/remove-liquidity", { hold: JSON.stringify(n) });
        }
        jumpAddPage(n) {
          const { anchorCoinsName: t, anchorCoinsChainName: i, quoteCoinsName: o, quoteCoinsChainName: l } = n;
          this.nav.routeTo("/add-liquidity", {
            anchorCoinName: t,
            anchorChainName: i,
            quoteCoinName: o,
            quoteChainName: l,
          });
        }
        jumpPoolPage(n) {
          const t = {
              fluctuationRange: "--",
              quoteCoinsTotalFee: "0",
              anchorCoinsTotalFee: "0",
              ...n,
              anchorCoinsReceivedProfits: "",
              quoteCoinsReceivedProfits: "",
              createdTime: 0,
              updatedTime: 0,
              anchorAssociatedCoins: [],
              quoteAssociatedCoins: [],
              anchorCoinsRecipientAddress: "",
              quoteCoinsRecipientAddress: "",
              feeRatio: "",
              anchorCoinsTotalProfits: "",
              quoteCoinsTotalProfits: "",
              totalValue: "",
              totalExchangesTimes: "",
              quoteDayVolume: "0",
              isAddDescription: !1,
            },
            i = (0, lt.S)(t);
          i
            ? this.nav.routeTo("/liquidity-detail", {
                poolDetailstring: JSON.stringify(i),
              })
            : this.console.error("\u6c60\u5b50\u6d41\u52a8\u6027\u4e3a0");
        }
        noBigU(n, t) {
          return n !== G.BNQKL_SWAP_CHAIN_NAME.SWAP || t !== G.BNQKL_SWAP_COIN_NAME.USDM;
        }
        getDataList() {
          var n = this;
          return (0, c.Z)(function* () {
            var t;
            const i = null === (t = n.connectedWallet) || void 0 === t ? void 0 : t.pmchainAddress;
            if (i) {
              const o = yield n.userService.getUserLiquidityHolding({
                userId: i,
              });
              o && ((n.init = !0), (n.dataList = o));
            }
          })();
        }
      }
      (((Je = Y).ɵfac = (() => {
        let a;
        return function (t) {
          return (a || (a = e.n5z(Je)))(t || Je);
        };
      })()),
        (Je.ɵcmp = e.Xpm({
          type: Je,
          selectors: [["bs-mine-my-liquidity-holdings"]],
          standalone: !0,
          features: [e.qOj, e.jDz],
          decls: 11,
          vars: 5,
          consts: () => {
            let a, n, t, i, o, l;
            return (
              (a = "\u589E\u52A0\u6D41\u52A8\u6027"),
              (n = "\u6211\u7684\u6D41\u52A8\u6027\u6301\u4ED3"),
              (t = "\u8BF7\u5148\u8FDE\u63A5\u94B1\u5305"),
              (i = "\u6301\u6709"),
              (o = "\u5F53\u524D\u6CA1\u6709\u6D41\u52A8\u6027\u6301\u4ED3"),
              (l = "\u52A0\u8F7D\u4E2D"),
              [
                [3, "hideHeader", "contentBackground", "ngStyle"],
                [1, "min-h-full", "px-4", "pt-4"],
                [
                  "bnRippleButton",
                  "",
                  1,
                  "from-blue-0",
                  "to-blue-1",
                  "mx-auto",
                  "flex",
                  "h-12",
                  "w-56",
                  "items-center",
                  "justify-center",
                  "rounded-full",
                  "bg-gradient-to-r",
                  3,
                  "click",
                ],
                ["name", "icon-add", 1, "mr-2", "text-xl", "text-white"],
                [1, "text-lg", "text-white"],
                a,
                [1, "mb-4", "mt-6", "text-base", "font-semibold"],
                n,
                ["class", "mt-20 flex flex-col items-center justify-center"],
                [1, "mt-20", "flex", "flex-col", "items-center", "justify-center"],
                ["src", "./assets/images/connect-wallet.png", 1, "h-30", "w-40"],
                [1, "text-title-2"],
                t,
                ["wPullToRefresh", "", 3, "emitDistance", "maxDistance"],
                ["wPullToRefresh", "", 3, "emitDistance", "maxDistance", "pulled$"],
                [1, "h-28", "w-full"],
                [1, "rounded-4", "_item-bg", "mb-4", "p-4", 3, "click"],
                [1, "flex", "items-center"],
                [3, "swapChainName", "swapCoinName"],
                [1, "ml-2"],
                [1, "text-[1rem]", "font-semibold"],
                [1, "text-title-2", "text-xs", "leading-3"],
                [1, "bg-text", "mx-4", "h-8", "w-[1px]"],
                [1, "icon-8", 3, "defaultName", "iconUrl", "name"],
                [1, "text-base", "font-semibold", "leading-4"],
                ["class", "text-title-2 text-xs leading-3"],
                ["name", "icon-chevron-right", 1, "text-primary", "ml-auto", "text-xl"],
                [1, "mt-4", "flex", "items-center"],
                [1, "text-title-1", "text-sm"],
                i,
                [1, "ml-auto", "grid", "grid-cols-[auto,1fr]", "grid-rows-2", "items-center", "gap-x-1"],
                [1, "text-right", "text-sm", "font-medium"],
                [3, "swapCoinName", "swapChainName"],
                [1, "icon-4", 3, "defaultName", "iconUrl", "name"],
                ["class", "rounded-4 _item-bg mb-4 p-4"],
                [
                  1,
                  "text-title-1",
                  "absolute",
                  "left-1/2",
                  "top-1/2",
                  "-translate-x-1/2",
                  "-translate-y-1/2",
                  "text-center",
                  "text-sm",
                ],
                ["src", "./assets/images/placeholder-1.png", 1, "w-[14.6875rem]"],
                o,
                [1, "absolute", "left-1/2", "top-1/2", "-translate-x-1/2", "-translate-y-1/2"],
                [1, "icon-6", 3, "showLoading"],
                [1, "text-sm"],
                l,
              ]
            );
          },
          template: function (n, t) {
            (1 & n &&
              (e.TgZ(0, "common-page", 0)(1, "div", 1)(2, "button", 2),
              e.NdJ("click", function () {
                return t.jumpAddLiquidity();
              }),
              e._UZ(3, "bs-icon", 3),
              e.TgZ(4, "div", 4),
              e.SDv(5, 5),
              e.qZA()(),
              e.TgZ(6, "div", 6),
              e.SDv(7, 7),
              e.qZA(),
              e.YNc(8, Eo, 4, 0, "div", 8)(9, Io, 2, 1)(10, wo, 4, 1),
              e.qZA()()),
              2 & n &&
                (e.Q6J("hideHeader", !0)("contentBackground", "#fff")("ngStyle", e.DdM(4, Mo)),
                e.xp6(8),
                e.um2(8, t.connectedWallet ? (t.init ? 9 : 10) : 8)));
          },
          dependencies: [Bt.j, Co.c, x.f5, Gt.Q, Fe.I, U.O, _.PC, ee.C, O.oJ, L.G4, Ae.r, _.ez, Zt.V],
          styles: [
            "[_nghost-%COMP%]   ._item-bg[_ngcontent-%COMP%]{background-image:url(stagging-bg.1789782a32b479f0.png);background-repeat:no-repeat;background-size:100% 100%}",
          ],
          changeDetection: 0,
        })),
        (0, s.gn)([Y.State(), (0, s.w6)("design:type", Object)], Y.prototype, "connectedWallet", void 0),
        (0, s.gn)([Y.State(), (0, s.w6)("design:type", Object)], Y.prototype, "init", void 0),
        (0, s.gn)([Y.State(), (0, s.w6)("design:type", Object)], Y.prototype, "uName", void 0),
        (0, s.gn)([Y.State(), (0, s.w6)("design:type", Array)], Y.prototype, "dataList", void 0),
        (0, s.gn)(
          [
            Y.OnResume(),
            (0, s.w6)("design:type", Function),
            (0, s.w6)("design:paramtypes", []),
            (0, s.w6)("design:returntype", void 0),
          ],
          Y.prototype,
          "onresume",
          null,
        ),
        (0, s.gn)(
          [
            Y.OnDestroy(),
            (0, s.w6)("design:type", Function),
            (0, s.w6)("design:paramtypes", []),
            (0, s.w6)("design:returntype", void 0),
          ],
          Y.prototype,
          "unsubscribe",
          null,
        ),
        (0, s.gn)(
          [
            Y.OnInit(),
            (0, s.w6)("design:type", Function),
            (0, s.w6)("design:paramtypes", []),
            (0, s.w6)("design:returntype", void 0),
          ],
          Y.prototype,
          "walletInit",
          null,
        ),
        (0, s.gn)(
          [
            Y.OnInit(),
            (0, s.w6)("design:type", Function),
            (0, s.w6)("design:paramtypes", []),
            (0, s.w6)("design:returntype", Promise),
          ],
          Y.prototype,
          "getDataList",
          null,
        ));
      const Oo = Y;
      var Ye;
      const Lo = ["tabsSlides"],
        Ro = ["myHoldingsPage"],
        ko = ["sellInputRef"],
        Do = ["buyInputRef"];
      function Uo(a, n) {
        if (1 & a) {
          const t = e.EpF();
          (e.TgZ(0, "div", 13),
            e.NdJ("click", function () {
              const l = e.CHM(t).$implicit,
                d = e.oxw();
              return e.KtG(d.selectTab(l.index));
            }),
            e._uU(1),
            e.qZA());
        }
        if (2 & a) {
          const t = n.$implicit,
            i = e.oxw();
          (e.Gre("text-[1rem] font-semibold ", i.currentTabIdx === t.index ? "text-title" : "text-title-2", ""),
            e.s9C("id", t.id),
            e.xp6(1),
            e.hij(" ", t.label, " "));
        }
      }
      function Zo(a, n) {
        if (1 & a) {
          const t = e.EpF();
          (e.TgZ(0, "div", 14),
            e.NdJ("click", function () {
              e.CHM(t);
              const o = e.oxw();
              return e.KtG(o.openAdvancedSettingsSheet());
            }),
            e.TgZ(1, "div", 15),
            e.SDv(2, 16),
            e.qZA(),
            e.TgZ(3, "button", 17),
            e._UZ(4, "bs-icon", 18),
            e.qZA()());
        }
        if (2 & a) {
          const t = e.oxw();
          (e.xp6(2), e.pQV(t.slippageLabel), e.QtT(2));
        }
      }
      function Go(a, n) {
        if (
          (1 & a &&
            (e.TgZ(0, "div", 47),
            e._UZ(1, "bs-swap-token-chain-icon", 48),
            e.qZA(),
            e.TgZ(2, "div", 49),
            e._uU(3),
            e.qZA()),
          2 & a)
        ) {
          const t = e.oxw(2);
          (e.xp6(1),
            e.Q6J("swapChainName", t.buyPanel.chain)("iconSize", "icon-4.5"),
            e.xp6(2),
            e.hij(" ", t.buyPanel.chain, " "));
        }
      }
      function Bo(a, n) {
        (1 & a && (e.TgZ(0, "div", 50)(1, "div", 51), e.SDv(2, 52), e.qZA(), e._UZ(3, "bs-icon", 53), e.qZA()),
          2 & a && (e.xp6(3), e.Q6J("mode", "icon")));
      }
      function Fo(a, n) {
        if (
          (1 & a &&
            (e._UZ(0, "bs-swap-token-chain-icon", 54),
            e.TgZ(1, "span", 55),
            e._uU(2),
            e.qZA(),
            e.TgZ(3, "button", 56),
            e._UZ(4, "bs-icon", 57),
            e.qZA()),
          2 & a)
        ) {
          const t = e.oxw(2);
          (e.Q6J("swapChainName", t.buyPanel.chain)("iconSize", "text-[1.75rem]")("swapCoinName", t.buyPanel.coin),
            e.xp6(2),
            e.Oqu(t.buyPanel.coin),
            e.xp6(1),
            e.Q6J("mode", "icon"));
        }
      }
      function $o(a, n) {
        if (
          (1 & a &&
            (e.TgZ(0, "div", 58),
            e._UZ(1, "bs-swap-token-chain-icon", 48),
            e.qZA(),
            e.TgZ(2, "div", 49),
            e._uU(3),
            e.qZA()),
          2 & a)
        ) {
          const t = e.oxw(2);
          (e.xp6(1),
            e.Q6J("swapChainName", t.sellPanel.chain)("iconSize", "icon-4.5"),
            e.xp6(2),
            e.hij(" ", t.sellPanel.chain, " "));
        }
      }
      function Wo(a, n) {
        (1 & a && (e.TgZ(0, "div", 59)(1, "div", 51), e.SDv(2, 60), e.qZA(), e._UZ(3, "bs-icon", 53), e.qZA()),
          2 & a && (e.xp6(3), e.Q6J("mode", "icon")));
      }
      function jo(a, n) {
        if (
          (1 & a &&
            (e._UZ(0, "bs-swap-token-chain-icon", 54),
            e.TgZ(1, "span", 55),
            e._uU(2),
            e.qZA(),
            e.TgZ(3, "button", 56),
            e._UZ(4, "bs-icon", 57),
            e.qZA()),
          2 & a)
        ) {
          const t = e.oxw(2);
          (e.Q6J("swapChainName", t.sellPanel.chain)("iconSize", "text-[1.75rem]")("swapCoinName", t.sellPanel.coin),
            e.xp6(2),
            e.Oqu(t.sellPanel.coin),
            e.xp6(1),
            e.Q6J("mode", "icon"));
        }
      }
      function Vo(a, n) {
        if (1 & a) {
          const t = e.EpF();
          (e.TgZ(0, "button", 61),
            e.NdJ("click", function (o) {
              e.CHM(t);
              const l = e.oxw(2);
              return e.KtG(l.handleMaxBtn(o));
            }),
            e.SDv(1, 62),
            e.qZA());
        }
      }
      function Xo(a, n) {
        1 & a && e._UZ(0, "img", 64);
      }
      function Ho(a, n) {
        1 & a && e._UZ(0, "img", 66);
      }
      function zo(a, n) {
        if (
          (1 & a &&
            (e.TgZ(0, "div", 63),
            e.YNc(1, Xo, 1, 0, "img", 64)(2, Ho, 1, 0),
            e.TgZ(3, "span"),
            e.SDv(4, 65),
            e.qZA()()),
          2 & a)
        ) {
          const t = e.oxw(2);
          (e.xp6(1),
            e.um2(1, t.gasFeeIsEnough ? 1 : 2),
            e.xp6(2),
            e.Gre("", t.gasFeeIsEnough ? "text-green" : "text-red", "  ml-2 text-xs"),
            e.xp6(1),
            e.pQV(t.gasFeeTipText),
            e.QtT(4));
        }
      }
      function qo(a, n) {
        if ((1 & a && (e.TgZ(0, "div", 67), e.SDv(1, 68), e.qZA()), 2 & a)) {
          const t = e.oxw(2);
          (e.xp6(1), e.pQV(t.poolUNotEnoughTip), e.QtT(1));
        }
      }
      const Qo = (a) => ({ "_price-ani": a }),
        fn = () => ({ "--color-1": "#7a7b90" });
      function Jo(a, n) {
        if (1 & a) {
          const t = e.EpF();
          (e.TgZ(0, "div", 69)(1, "bs-icon", 70),
            e.NdJ("click", function () {
              e.CHM(t);
              const o = e.oxw(2);
              return e.KtG(o.refreshPrice());
            }),
            e.qZA(),
            e.TgZ(2, "span", 71),
            e._uU(3),
            e.qZA(),
            e.TgZ(4, "bs-icon", 72),
            e.NdJ("click", function () {
              e.CHM(t);
              const o = e.oxw(2);
              return e.KtG(o.handleReversePrice());
            }),
            e.qZA()());
        }
        if (2 & a) {
          const t = e.oxw(2);
          (e.xp6(1),
            e.Tol(e.VKq(7, Qo, t.priceAnimationState)),
            e.Q6J("ngStyle", e.DdM(9, fn)),
            e.xp6(2),
            e.lnq("1 ", t.price.leftCoin, " = ", t.price.showPrice, " ", t.price.rightCoin, ""),
            e.xp6(1),
            e.Q6J("ngStyle", e.DdM(10, fn)));
        }
      }
      function Yo(a, n) {
        if (1 & a) {
          const t = e.EpF();
          (e.TgZ(0, "section", 19)(1, "div", 20)(2, "div", 21)(3, "div", 22)(4, "div", 23),
            e.SDv(5, 24),
            e.qZA(),
            e.YNc(6, Go, 4, 3),
            e.qZA(),
            e.TgZ(7, "div", 25)(8, "div", 26),
            e.NdJ("click", function () {
              e.CHM(t);
              const o = e.oxw();
              return e.KtG(o.openSelectAssetSheet(o.OPERATE.BUY));
            }),
            e.YNc(9, Bo, 4, 1, "div", 27)(10, Fo, 5, 5),
            e.qZA(),
            e.TgZ(11, "bs-numeric-input", 28),
            e.NdJ("ngModelChange", function (o) {
              e.CHM(t);
              const l = e.oxw();
              return e.KtG((l.buyPanel.amount = o));
            }),
            e.qZA()(),
            e.TgZ(12, "div", 29),
            e._UZ(13, "bs-icon", 30),
            e.TgZ(14, "span", 31),
            e._uU(15),
            e.qZA()()()(),
            e.TgZ(16, "div", 32)(17, "div", 33),
            e.NdJ("click", function () {
              e.CHM(t);
              const o = e.oxw();
              return e.KtG(o.reversePanel());
            }),
            e._UZ(18, "bs-icon", 34),
            e.qZA(),
            e.TgZ(19, "div", 21)(20, "div", 22)(21, "div", 23),
            e.SDv(22, 35),
            e.qZA(),
            e.YNc(23, $o, 4, 3),
            e.qZA(),
            e.TgZ(24, "div", 25)(25, "div", 26),
            e.NdJ("click", function () {
              e.CHM(t);
              const o = e.oxw();
              return e.KtG(o.openSelectAssetSheet(o.OPERATE.SELL));
            }),
            e.YNc(26, Wo, 4, 1, "div", 36)(27, jo, 5, 5),
            e.qZA(),
            e.TgZ(28, "bs-numeric-input", 37),
            e.NdJ("ngModelChange", function (o) {
              e.CHM(t);
              const l = e.oxw();
              return e.KtG((l.sellPanel.amount = o));
            }),
            e.qZA()(),
            e.TgZ(29, "div", 38),
            e._UZ(30, "bs-icon", 30),
            e.TgZ(31, "span", 31),
            e._uU(32),
            e.qZA(),
            e.YNc(33, Vo, 2, 0, "button", 39),
            e.qZA()()(),
            e.TgZ(34, "div", 40),
            e.YNc(35, zo, 5, 5, "div", 41),
            e.qZA(),
            e.TgZ(36, "button", 42),
            e.NdJ("click", function () {
              e.CHM(t);
              const o = e.oxw();
              return e.KtG(o.btnEvent());
            }),
            e.TgZ(37, "div", 43),
            e._uU(38),
            e._UZ(39, "bn-loading-wrapper", 44),
            e.qZA()(),
            e.YNc(40, qo, 2, 1, "div", 45)(41, Jo, 5, 11, "div", 46),
            e.qZA());
        }
        if (2 & a) {
          const t = e.oxw();
          (e.xp6(6),
            e.um2(6, t.buyPanel.chain ? 6 : -1),
            e.xp6(3),
            e.um2(9, t.buyPanel.coin ? 10 : 9),
            e.xp6(2),
            e.Q6J("maxDecimals", 8)("maxValue", t.buyMaxValue)("layout", t.number)("formControl", t.buyControl)(
              "ngModel",
              t.buyPanel.amount,
            ),
            e.xp6(4),
            e.Oqu(t.buyPanel.balance),
            e.xp6(8),
            e.um2(23, t.sellPanel.chain ? 23 : -1),
            e.xp6(3),
            e.um2(26, t.sellPanel.coin ? 27 : 26),
            e.xp6(2),
            e.Q6J("maxDecimals", 8)("maxValue", t.getSellMaxValue)("layout", t.number)("formControl", t.sellControl)(
              "ngModel",
              t.sellPanel.amount,
            ),
            e.xp6(4),
            e.Oqu(t.sellPanel.balance),
            e.xp6(1),
            e.um2(33, t.showMax() ? 33 : -1),
            e.xp6(2),
            e.um2(35, t.showGasTip ? 35 : -1),
            e.xp6(1),
            e.Tol(t.btnDisabled ? "bg-title-2" : "bg-gradient-to-r from-blue-0 to-blue-1"),
            e.Q6J("disabled", t.btnDisabled),
            e.xp6(2),
            e.hij(" ", t.btnText, " "),
            e.xp6(1),
            e.Q6J("loadingTheme", "ellipsis")("showLoading", t.loading),
            e.xp6(1),
            e.um2(40, t.showPoolCoinNotEnough ? 40 : -1),
            e.xp6(1),
            e.um2(41, t.showPrice ? 41 : -1));
        }
      }
      function Ko(a, n) {
        1 & a && (e.TgZ(0, "section", 19), e._UZ(1, "bs-mine-my-liquidity-holdings", null, 73), e.qZA());
      }
      function es(a, n) {
        if (1 & a) {
          const t = e.EpF();
          (e.TgZ(0, "bs-swap-detail-panel-page", 74),
            e.NdJ("returnValue$", function (o) {
              e.CHM(t);
              const l = e.oxw();
              return e.KtG(l.onSwapSubmited(o));
            }),
            e.qZA());
        }
        if (2 & a) {
          const t = e.oxw();
          e.Q6J("sellPanel", t.sellPanel)("buyPanel", t.buyPanel)("preParams", t.preParams)(
            "transferOptions",
            t.transferOptions,
          )("platformFee", t.platformFee)("expectBuyAmount", t.expectBuyAmount);
        }
      }
      function ts(a, n) {
        1 & a && e._UZ(0, "bs-order-settings-page");
      }
      function ns(a, n) {
        if (1 & a) {
          const t = e.EpF();
          (e.TgZ(0, "bs-select-asset-panel-page", 75),
            e.NdJ("returnValue$", function (o) {
              e.CHM(t);
              const l = e.oxw();
              return e.KtG(l.onSelectToken(o));
            }),
            e.qZA());
        }
        if (2 & a) {
          const t = e.oxw();
          e.Q6J("dataList", t.selectAssetSheet.data.assets);
        }
      }
      function is(a, n) {
        if ((1 & a && e._UZ(0, "bs-connect-wallet-panel-page", 76), 2 & a)) {
          const t = e.oxw();
          e.Q6J("connectType", t.selectWalletSheet.conncetType)("presetWallets", t.selectWalletSheet.presetWallets);
        }
      }
      const os = () => ({ "--page-safe-area-inset-top": 0 }),
        ss = (a) => ({ "--index": a });
      class C extends (0, f.To)(x.Wh) {
        constructor() {
          (super(...arguments),
            (this.swapTabs = [
              { label: "\u5151\u6362", id: "swap", index: 0 },
              { label: "\u5408\u7EA6\u6C60", id: "pool", index: 1 },
            ]),
            (this.currentTabIdx = 0),
            (this.fromRouter = !1),
            (this.orderService = (0, e.f3M)(Di.c)),
            (this.OPERATE = J),
            (this.poolService = (0, e.f3M)(Be.X)),
            (this.settingsService = (0, e.f3M)(rn.H)),
            (this.commonConfigService = (0, e.f3M)(Re._)),
            (this.walletService = (0, e.f3M)(R.X)),
            (this.connectedWallet = this.walletService.connectedWallet),
            (this.liquidityPoolAssetsListWithAmount = []),
            (this.poolDetailList = []),
            (this.slippageTolerance = ""),
            (this.expirationTime = 0),
            (this.priceAnimationState = !1),
            (this.btnText = "\u8FDE\u63A5\u94B1\u5305"),
            (this.btnDisabled = !1),
            (this.btnEvent = this.openConnectWalletPanel),
            (this.loading = !1),
            (this.operate = J.BUY),
            (this.lastInput = void 0),
            (this.version = ""),
            (this.feeRatio = "0"),
            (this.relatePool = { sellPool: void 0, buyPool: void 0 }),
            (this.relatePoolId = { sellPoolId: "", buyPoolId: "" }),
            (this.caculateErr = Q.HAS_NO_LIQUIDITY),
            (this.caculateResult = !0),
            (this.price = {
              leftCoin: void 0,
              rightCoin: void 0,
              forwordPrice: ne.qn.AMOUNT_NONE,
              backwordPirce: ne.qn.AMOUNT_NONE,
              showPrice: ne.qn.AMOUNT_NONE,
              direction: ne.SC.BACKWARD,
            }),
            (this.buyPanel = {
              chain: void 0,
              coin: void 0,
              amount: "",
              balance: "- -",
            }),
            (this.sellPanel = {
              chain: void 0,
              coin: void 0,
              amount: "",
              balance: "- -",
            }),
            (this.DECIMALS = 8),
            (this.platformFee = ""),
            (this.showGasTip = !1),
            (this.preParams = void 0),
            (this.transferOptions = void 0),
            (this.expectBuyAmount = "0"),
            (this._sellControlRun = !1),
            (this.sellControl = new Se.NI("", {
              validators: [
                (n) => {
                  const t = String(n.value),
                    i = (0, cn.sx)(t, this.DECIMALS);
                  return (
                    i !== t && n.setValue(i),
                    !1 === this._buyControlRun && ((this._sellControlRun = !0), this.sellInputEvent()),
                    null
                  );
                },
              ],
            })),
            (this._buyControlRun = !1),
            (this.buyControl = new Se.NI("", {
              validators: [
                (n) => {
                  const t = String(n.value),
                    i = (0, cn.sx)(t, this.DECIMALS);
                  return (
                    i !== t && n.setValue(i),
                    !1 === this._sellControlRun && ((this._buyControlRun = !0), this.buyInputEvent()),
                    null
                  );
                },
              ],
            })),
            (this.number = "number"),
            (this.btnObjList = [
              {
                text: "\u8FDE\u63A5\u94B1\u5305",
                disabled: !1,
                check: this.checkWallet.bind(this),
                event: this.openConnectWalletPanel,
              },
              {
                text: "\u9009\u62E9\u5E01\u79CD",
                disabled: !1,
                check: this.checkToken.bind(this),
                event: this.openSelectAssetSheet,
              },
              {
                text: "\u6B63\u5728\u83B7\u53D6\u6570\u636E",
                disabled: !0,
                check: this.checkLoading.bind(this),
                event: void 0,
              },
              {
                text: "\u6682\u65E0\u5F53\u524D\u5E01\u79CD\u6C60\u5B50",
                disabled: !0,
                check: this.checkPool.bind(this),
                event: void 0,
              },
              {
                text: "\u6682\u65E0\u6D41\u52A8\u6C60\u53EF\u5151\u6362",
                disabled: !1,
                check: this.checkPoolLiquidity.bind(this),
                event: this.openAddLiquidityDialog.bind(this),
              },
              {
                text: "\u4F59\u989D\u4E0D\u8DB3",
                disabled: !0,
                check: this.checkGasFee.bind(this),
                event: void 0,
              },
              {
                text: "\u4F59\u989D\u4E0D\u8DB3",
                disabled: !0,
                check: this.checkBalance.bind(this),
                event: void 0,
              },
              {
                text: () => this.caculateErr,
                disabled: !0,
                check: this.checkLiquidityAmount.bind(this),
                event: void 0,
              },
              {
                text: "\u8F93\u5165\u6570\u91CF",
                disabled: !1,
                check: this.checkAmount.bind(this),
                event: this.onManuallyFocus,
              },
              {
                text: "\u6570\u91CF\u4E0D\u80FD\u4E3A\u96F6",
                disabled: !0,
                check: this.checkZero.bind(this),
                event: void 0,
              },
              {
                text: "\u5151\u6362",
                disabled: !1,
                check: () => !1,
                event: this.openSwapSheet,
              },
            ]),
            (this.mainCoin = ""),
            (this.gasFee = ""),
            (this.gasFeeIsEnough = !0),
            (this.gasFeeTipText = ""),
            (this.swapSheet = { is_open: !1 }),
            (this.selectAssetSheet = {
              isOpen: !1,
              data: { allAssets: [], assets: [] },
            }),
            (this.selectWalletSheet = {
              is_open: !1,
              conncetType: se.i.CONNECT_WALLET,
              presetWallets: [],
            }),
            (this.advancedSettingsSheet = { is_open: !1 }),
            (this.maxMode = !1),
            (this.buyMaxValue = "0"),
            (this.showPoolCoinNotEnough = !1),
            (this.poolUNotEnoughTip = ""));
        }
        selectTab(n) {
          var t = this;
          return (0, c.Z)(function* () {
            t.currentTabIdx = n;
            const i = document.getElementById(t.swapTabs[n].id);
            if (t.subscriptRef && i) {
              const o = document.getElementById(t.swapTabs[0].id);
              t.renderer2.setStyle(
                t.subscriptRef.nativeElement,
                "left",
                i.clientWidth / 2 + t.currentTabIdx * (o.clientWidth + 16) - 10 + "px",
              );
            }
          })();
        }
        get slippageLabel() {
          const { slippageTolerance: n } = this.settingsService.getSelectedValue();
          return null == n ? void 0 : n.label;
        }
        get addLiquilidityRatioLabel() {
          const { addLiquidityRatio: n } = this.settingsService.getSelectedValue();
          return null == n ? void 0 : n.label;
        }
        get addLiquilidityRatioValue() {
          const { addLiquidityRatio: n } = this.settingsService.getSelectedValue();
          return null == n ? void 0 : n.value;
        }
        get showAddLiquidityRatio() {
          const { sellCoin: n } = this.poolUtil();
          return !!n;
        }
        reversePanel() {
          const { buyPanel: n, sellPanel: t } = this;
          ((n.amount = ""), (t.amount = ""));
          const i = ut()(n);
          ((this.buyPanel = ut()(t)),
            (this.sellPanel = i),
            (this.lastInput = void 0),
            (this.caculateResult = !0),
            this.initGasFeeInfo(),
            this.initMainCoinInfoAndFee(),
            this.initPoolInfo(),
            this.handleRelateId(),
            this.handlePoolInfo(),
            this.checkEventList(),
            (this.showPoolCoinNotEnough = !1));
          const { chain: o } = this.sellPanel;
          o && this.getMainChainInfoandCalculateFee(o);
        }
        onSwapSubmited(n) {
          var t = this;
          return (0, c.Z)(function* () {
            t.swapSheet.is_open = !1;
            const { transactionData: i } = n;
            t.loading = !0;
            const o = yield t.orderService.exchangeOrder(i);
            ((t.loading = !1),
              o
                ? ((t.sellPanel.amount = ""),
                  (t.buyPanel.amount = ""),
                  t.checkEventList(),
                  $.F.show("\u4EA4\u6613\u63D0\u4EA4"),
                  yield (0, K._v)(500),
                  t.nav.routeTo("/mine/my-record-swap"))
                : $.F.show("\u5151\u6362\u5931\u8D25"));
          })();
        }
        unsubscribe() {
          (this.console.log("\u6e05\u9664 \u8ba2\u9605"),
            this.walletAssets$ && this.walletAssets$.unsubscribe(),
            this.connectWallet$ && this.connectWallet$.unsubscribe(),
            this.poolDetail$ && this.poolDetail$.unsubscribe(),
            this.walletService.allSubscribes.delete("SwapPage"),
            this.settingsService.reset(),
            this.sellInputRef &&
              this.sellInputRef.nativeElement.removeEventListener("input", this.sellInputEvent.bind(this)),
            this.buyInputRef &&
              this.buyInputRef.nativeElement.removeEventListener("input", this.buyInputEvent.bind(this)));
        }
        sellInputEvent() {
          (this.sellTimer && clearTimeout(this.sellTimer),
            (this.sellTimer = setTimeout(() => {
              ((this.maxMode = !1),
                (this.lastInput = J.SELL),
                (this.showPoolCoinNotEnough = !1),
                this.initGasFeeInfo(),
                this.handleSellCaculate(),
                this.checkEventList(),
                setTimeout(() => {
                  this._sellControlRun = !1;
                }, 100));
            }, 500)));
        }
        buyInputEvent() {
          (this.buyTimer && clearTimeout(this.buyTimer),
            (this.buyTimer = setTimeout(() => {
              ((this.maxMode = !1),
                (this.lastInput = J.BUY),
                (this.showPoolCoinNotEnough = !1),
                this.initGasFeeInfo(),
                this.handleBuyCaculate(),
                this.checkEventList(),
                setTimeout(() => {
                  this._buyControlRun = !1;
                }, 100));
            }, 500)));
        }
        refreshPrice() {
          this.getLiquidityPoolDetail();
        }
        checkVersionUpgrade() {
          var n = this;
          return (0, c.Z)(function* () {
            try {
              yield n._templateDialogService.openDialogByName("checkVersionUpgrade", { input: void 0 });
            } catch (t) {
              if (!1 !== t) throw t;
              ($.F.show("\u8FD9\u662F\u6700\u65B0\u7248\u672C"), n.console.log("no need upgrade"));
            }
          })();
        }
        dataInit() {
          var n = this;
          return (0, c.Z)(function* () {
            const t = localStorage.getItem("version");
            (t && (n.version = t),
              (n.walletAssets$ = n.walletService.curentWalletAssets_subject.subscribe(
                (function () {
                  var i = (0, c.Z)(function* (o) {
                    o.updating ||
                      void 0 === o.connectedWallet ||
                      ((n.connectedWallet = o.connectedWallet),
                      n.console.info(
                        "\u5151\u6362\u9762\u677f\u76d1\u542c\u5230\u4f59\u989d\u53d8\u5316",
                        n.connectedWallet,
                      ),
                      n.changeViewBalanceAmount());
                  });
                  return function (o) {
                    return i.apply(this, arguments);
                  };
                })(),
              )),
              (n.poolDetail$ = n.poolService.liquidityPoolDetailQueryTask_subject.subscribe((i) => {
                if (
                  null != i &&
                  (n.console.info("\u5151\u6362\u9762\u677f\u76d1\u542c\u5230\u6c60\u5b50\u8be6\u60c5\u53d8\u5316", i),
                  i)
                ) {
                  const { liquidityPoolsdetail: o, updating: l } = i;
                  ((n.priceAnimationState = l),
                    (n.loading = l),
                    !1 === l &&
                      o &&
                      ((n.poolDetailList = o),
                      n.fromRouter && n.handleRouerSelectCoin(),
                      n.handlePoolInfo(),
                      n.lastInput && n.lastInput === J.SELL ? n.handleSellCaculate() : n.handleBuyCaculate()),
                    n.checkEventList());
                }
              })),
              (n.connectWallet$ = n.walletService.wallletConnected_subject.subscribe(
                (function () {
                  var i = (0, c.Z)(function* (o) {
                    if (void 0 === o) return;
                    const { wallet: l } = o;
                    (void 0 === l && n.clearAllInfo(), (n.connectedWallet = l), n.checkEventList());
                  });
                  return function (o) {
                    return i.apply(this, arguments);
                  };
                })(),
              )),
              (n.liquidityPoolAssetsListWithAmount =
                yield n.walletService.getliquidityPoolAssetsListWithAmountAtFirst()),
              yield n.settingsService.getConfig(),
              n.cdRef.detectChanges(),
              n.selectTab(0));
          })();
        }
        bindButton() {
          this.checkEventList();
        }
        handleReversePrice() {
          Object.assign(this.price, (0, ne.ML)(this.price));
        }
        checkLoading() {
          return !1 === this.loading;
        }
        checkPool() {
          const { sellChain: n, sellCoin: t, buyChain: i, buyCoin: o } = this.poolUtil(),
            { loading: l } = this;
          if (n && t && i && o && !1 === l) {
            const { sellPoolId: d, buyPoolId: p } = this.relatePoolId;
            return !!d && !!p;
          }
          return !0;
        }
        openSwapSheet() {
          var n, t;
          const activityTime = this.commonConfigService.activityTime;
          if (activityTime) {
            function getCurrentTime() {
              // 获取本地时间戳
              const localTimestamp = Date.now();

              // 显示本地时间
              const localDate = new Date(localTimestamp);

              // 计算东八区时间
              const localOffset = localDate.getTimezoneOffset(); // 本地时区与UTC的偏移（分钟）
              const utc8Offset = 480; // 东八区偏移（480分钟）
              const offset = (utc8Offset + localOffset) * 60 * 1000; // 总偏移量（毫秒）
              const utc8Timestamp = localTimestamp + offset;

              // 格式化东八区时间
              const utc8Date = new Date(utc8Timestamp);
              const hours = utc8Date.getHours();
              const minutes = utc8Date.getMinutes();
              return {
                hours,
                minutes,
              };
            }
            // 将时间转换为分钟数（便于比较）
            function timeToMinutes(time) {
              return time.hours * 60 + time.minutes;
            }

            // 查找下一个时间段
            function findNextTimeSlot() {
              const now = new Date();
              const currentHours = now.getHours();
              const currentMinutes = now.getMinutes();
              const currentTotalMinutes = currentHours * 60 + currentMinutes;

              let nextSlotIndex = -1;
              let minDifference = Infinity;

              // 检查每个时间段
              for (let i = 0; i < activityTime.length; i++) {
                const slot = activityTime[i];
                const startMinutes = timeToMinutes(slot.startTime);

                // 计算与当前时间的差值
                let difference = startMinutes - currentTotalMinutes;

                // 如果时间段已经开始，检查是否已经结束
                if (difference < 0) {
                  const endMinutes = timeToMinutes(slot.endTime);
                  // 如果时间段还在进行中，那么下一个时间段是当前时间段之后的下一个
                  if (currentTotalMinutes < endMinutes) {
                    // 当前正处于这个时间段
                    difference = 0;
                  } else {
                    // 这个时间段已经结束，跳过
                    continue;
                  }
                }

                // 找到时间差最小的未来时间段
                if (difference >= 0 && difference < minDifference) {
                  minDifference = difference;
                  nextSlotIndex = i;
                }
              }

              // 返回下一个时间段的信息和倒计时
              return {
                index: nextSlotIndex,
                difference: minDifference,
              };
            }

            activityTime.sort((a, b) => (a.startTime > b.startTime ? -1 : 1));
            const { minutes, hours } = getCurrentTime();
            const currentTotalMinutes = hours * 60 + minutes;
            const inActiveTime = activityTime.find((item) => {
              const startMinutes = timeToMinutes(item.startTime);
              const endMinutes = timeToMinutes(item.endTime);
              // 检查当前时间是否在此时间段内
              if (currentTotalMinutes >= startMinutes && currentTotalMinutes <= endMinutes) {
                return true;
              }
              return false;
            });
            if (!inActiveTime) {
              /// 没在交易时间 弹出提示下一个时间
              const { index } = findNextTimeSlot();
              const next = activityTime[index];

              $.F.show(
                `下个交易时间：${String(next.startTime.hours).padStart(2, "0")}:${String(next.startTime.minutes).padStart(2, "0")} - ${String(next.endTime.hours).padStart(2, "0")}:${String(next.endTime.minutes).padStart(2, "0")}`,
              );
              return;
            }
          }
          const i = null === (n = this.connectedWallet) || void 0 === n ? void 0 : n.pmchainAddress,
            o = null === (t = this.connectedWallet) || void 0 === t ? void 0 : t.pmchainPublicKey,
            { gasFee: l } = this,
            { slippageTolerance: d, expirationTime: p, addLiquidityRatio: g } = this.settingsService.getSelectedValue(),
            T = g.value,
            {
              sellCoin: v,
              sellChain: A,
              buyCoin: E,
              buyChain: w,
              sellAmount: B,
              buyAmount: z,
              sellPool: F,
              buyPool: Z,
              sellIsQuote: he,
              buyIsQuote: Ze,
            } = this.poolUtil();
          if (
            void 0 === F ||
            void 0 === Z ||
            void 0 === o ||
            void 0 === i ||
            void 0 === v ||
            void 0 === A ||
            void 0 === E ||
            void 0 === w ||
            void 0 === B ||
            void 0 === z ||
            void 0 === d ||
            void 0 === p
          )
            throw (
              this.console.error("\u5151\u6362\u9762\u677f\u6570\u636e\u51fa\u9519\uff1a", v, A, E, w, B, z),
              new Error("\u5151\u6362\u9762\u677f\u6570\u636e\u51fa\u9519")
            );
          const {
              anchorCoinsChainName: vs,
              anchorCoinsName: bs,
              anchorCoinsRecipientAddress: As,
              poolId: Tn,
              quoteAssociatedCoins: Cs,
            } = F,
            { poolId: vn } = Z,
            { anchorCoinsAmount: Es, quoteCoinsAmount: ys } = F,
            { anchorCoinsAmount: Ns, quoteCoinsAmount: xs } = Z,
            Ps = v === bs && y.FN[A] === vs,
            Et = new N.Z(B).multipliedBy(1e8).toString(),
            zt = new N.Z(Et).multipliedBy(T).dp(0, N.Z.ROUND_CEIL).toString(),
            qt = new N.Z(Et).minus(zt).toString(),
            yt = this.calculateGainByExchange(y.FN[A], v, qt, F).toString();
          let Qt = "";
          if (Ps) Qt = As;
          else {
            const Ge = Cs.find((It) => It.chainName === y.FN[A]);
            if (void 0 === Ge) throw new Error("\u627e\u4e0d\u5230\u5c0fU");
            Qt = Ge.recipientAddress;
          }
          const Is = Tn !== vn,
            Te = ut()(F),
            Ee = ut()(Z);
          he
            ? ((Te.quoteCoinsAmount = new N.Z(Te.quoteCoinsAmount).plus(qt).toString()),
              (Te.anchorCoinsAmount = new N.Z(Te.anchorCoinsAmount).minus(yt).toString()))
            : ((Te.quoteCoinsAmount = new N.Z(Te.quoteCoinsAmount).minus(yt).toString()),
              (Te.anchorCoinsAmount = new N.Z(Te.anchorCoinsAmount).plus(qt).toString()));
          let Nt = "";
          const xt = G.calculateHelper.calculateIncreasedAmount(y.FN[A], v, zt, Te).toString();
          let Jt = "0",
            Pt = "0";
          if (!1 === he && !1 === Ze) {
            const Ge = new N.Z(yt).minus(xt).toString();
            Pt = new N.Z(Ge).multipliedBy(T).dp(0, N.Z.ROUND_CEIL).toString();
            const It = new N.Z(Ge).minus(Pt).toString(),
              An = G.calculateHelper
                .calculateGainByExchange(Ee.quoteCoinsChainName, Ee.quoteCoinsName, It, Ee)
                .toString();
            ((Ee.quoteCoinsAmount = new N.Z(Ee.quoteCoinsAmount).plus(It).toString()),
              (Ee.anchorCoinsAmount = new N.Z(Ee.anchorCoinsAmount).minus(An).toString()),
              (Jt = G.calculateHelper
                .calculateIncreasedAmount(G.BNQKL_SWAP_CHAIN_NAME.SWAP, G.BNQKL_SWAP_COIN_NAME.USDM, Pt, Ee)
                .toString()),
              (Nt = new N.Z(An).minus(Jt.toString()).toString()));
          } else Nt = new N.Z(yt).minus(xt).toString();
          this.expectBuyAmount = new N.Z(Nt).dividedBy(1e8).toString();
          const ws = {
              poolId: Tn,
              anchorCoinsAmount: Es,
              quoteCoinsAmount: ys,
              chainName: y.FN[A],
              payload: void 0,
            },
            Ms = {
              poolId: vn,
              anchorCoinsAmount: Ns,
              quoteCoinsAmount: xs,
              chainName: y.FN[w],
              coinName: E,
              amount: Nt,
            },
            bn = Date.now(),
            Os = new N.Z(bn).plus(p.value),
            Ls = new N.Z(Et).multipliedBy(T).toNumber(),
            Rs = he ? xt : zt,
            ks = he ? Math.floor(Ls).toString() : xt,
            Ds = [this.handleAddLiquidityRatioInfo(Te, Rs, ks)];
          if (Is) {
            const Ge = this.handleAddLiquidityRatioInfo(Ee, Jt, Pt);
            Ds.push(Ge);
          }
          const Us = {
              chainName: A,
              receiveAddress: Qt,
              assetType: v,
              amount: Et,
              fee: l,
              remark: {
                chainName: y.FN[w],
                assetType: E,
                address: i,
                from: "btcswap",
              },
            },
            Zs = {
              type: G.ORDER_RECORD_TYPES.EXCHANGE_COINS,
              userId: i,
              recipientAddress: i,
              slippageTolerance: String(d.value),
              startTime: bn,
              expirationTime: Number(Os),
              transaction: { sellCoinOptions: ws, buyCoinOptions: Ms },
              publicKey: o,
              increasedLiquidityRatio: T,
            };
          ((this.transferOptions = Us),
            (this.preParams = Zs),
            (this.platformFee = F.feeRatio),
            (this.swapSheet.is_open = !0));
        }
        addLiAmountCalc(n, t, i, o, l) {
          const d = new N.Z(t).multipliedBy(n).toString();
          return G.calculateHelper.calculateIncreasedAmount(i, o, d, l).toString();
        }
        handleAddLiquidityRatioInfo(n, t, i) {
          const o = G.calculateHelper.calculateLPCoinByAdd(t, i, n);
          return {
            poolId: n.poolId,
            anchorCoinsChainName: n.anchorCoinsChainName,
            anchorCoinsName: n.anchorCoinsName,
            anchorCoinsAmount: t,
            quoteCoinsChainName: n.quoteCoinsChainName,
            quoteCoinsName: n.quoteCoinsName,
            quoteCoinsAmount: i,
            lpCoinsAmount: o.toString(),
          };
        }
        checkEventList() {
          var n = this;
          return (0, c.Z)(function* () {
            const { btnObjList: t } = n;
            for (let i = 0; i < t.length; i++) {
              const o = t[i],
                l = o.check();
              if (!1 === ("boolean" == typeof l ? l : yield l)) {
                const { text: p, disabled: g, event: T } = o;
                return (
                  (n.btnText = "string" == typeof p ? p : String(Zi[p()])),
                  (n.btnDisabled = g),
                  void (T && (n.btnEvent = T))
                );
              }
            }
          })();
        }
        getMainChainInfoandCalculateFee(n) {
          var t = this;
          return (0, c.Z)(function* () {
            const o = t.walletService.CHAIN_CONFIG_MAP.get(n);
            if (!o) throw new Error("\u6ca1\u6709\u627e\u5230\u4e3b\u5e01\u79cd");
            t.mainCoin = o.symbol;
            const l = yield t.walletService.getBioforestChainFeeByChainName(n);
            t.gasFee = l;
          })();
        }
        checkGasFee() {
          var n = this;
          return (0, c.Z)(function* () {
            var t;
            const { sellCoin: i, sellChain: o, sellAmount: l } = n.poolUtil();
            if (void 0 === i || void 0 === o)
              throw new Error("\u672a\u9009\u62e9\u5e01\u79cd\uff0c\u65e0\u6cd5\u8ba1\u7b97");
            if (!l) return !0;
            const { mainCoin: d, gasFee: p } = n,
              g = null === (t = n.connectedWallet) || void 0 === t ? void 0 : t.assetInfoListMap.get(o),
              T = null == g ? void 0 : g.assets.find((B) => B.assetType === d);
            if (void 0 === T)
              throw new Error("\u6ca1\u6709\u627e\u5230\u4e3b\u94fe\u5e01\u79cd\u94b1\u5305\u4fe1\u606f");
            const v = i === d,
              A = new N.Z(1).minus(n.addLiquilidityRatioValue),
              E = v ? new N.Z(l).multipliedBy(1e8).multipliedBy(A).plus(p).toString() : p,
              w = new N.Z(T.amount).isGreaterThanOrEqualTo(E);
            if (((n.gasFeeIsEnough = w), (n.showGasTip = !0), w))
              n.maxMode
                ? (n.gasFeeTipText = "\u5DF2\u4E3A\u60A8\u9884\u7559\u94B1\u5305\u7B7E\u540D\u624B\u7EED\u8D39")
                : (n.showGasTip = !1);
            else {
              if (v) {
                const B = _e.rZ.transform(p, String(n.DECIMALS), {
                  removeZero: !0,
                });
                return ((n.gasFeeTipText = "\u8BF7\u9884\u7559" + B + "" + d + "\u77FF\u5DE5\u8D39"), !1);
              }
              n.gasFeeTipText = "\u5F53\u524D" + d + "\u4E0D\u8DB3\uFF0C\u53EF\u80FD\u65E0\u6CD5\u7B7E\u540D";
            }
            return !0;
          })();
        }
        initGasFeeInfo() {
          ((this.showGasTip = !1), (this.gasFeeIsEnough = !0), (this.gasFeeTipText = ""));
        }
        initMainCoinInfoAndFee() {
          ((this.mainCoin = ""), (this.gasFee = ""));
        }
        changeViewBalanceAmount() {
          ([this.sellPanel, this.buyPanel].forEach((n) => {
            var t;
            const { chain: i, coin: o } = n;
            if (void 0 === i || void 0 === o) return;
            const l = null === (t = this.connectedWallet) || void 0 === t ? void 0 : t.assetInfoListMap.get(i);
            if (void 0 === l) return;
            const { assets: d } = l,
              p = d.find((v) => v.assetType === o);
            if (void 0 === p) return;
            const T = Number.isNaN(parseFloat(p.amount))
              ? "- -"
              : _e.rZ.transform(p.amount, p.decimals, { removeZero: !0 });
            n.balance = T;
          }),
            this.getBuyMaxValue());
        }
        checkWallet() {
          return !!this.connectedWallet;
        }
        checkToken() {
          return !!this.buyPanel.coin && !!this.sellPanel.coin;
        }
        checkZero() {
          return 0 == (0 === parseFloat(this.sellPanel.amount) || 0 === parseFloat(this.buyPanel.amount));
        }
        checkAmount() {
          const n = !1 === Number.isNaN(parseFloat(this.sellPanel.amount)),
            t = !1 === Number.isNaN(parseFloat(this.buyPanel.amount));
          return n && t;
        }
        checkData() {
          return !this.buyTimer;
        }
        checkBalance() {
          const { amount: n, balance: t } = this.sellPanel;
          return !n || !t || new N.Z(t).isGreaterThanOrEqualTo(n);
        }
        compareCoinAmount(n, t) {
          const i = new N.Z(n).multipliedBy(1e8);
          return new N.Z(t).isGreaterThan(i);
        }
        checkLiquidityAmount() {
          const { caculateResult: n } = this;
          return n;
        }
        checkPoolLiquidity() {
          const { relatePool: n } = this,
            { sellPool: t, buyPool: i } = n;
          return [t, i].some((o) => {
            if (o) {
              const { anchorCoinsAmount: l, quoteCoinsAmount: d } = o;
              return Number(l) > 0 && Number(d) > 0;
            }
          });
        }
        get showPrice() {
          const { sellAmount: n, buyAmount: t, sellPool: i, buyPool: o } = this.poolUtil();
          return i && o && Number(n) > 0 && Number(t) > 0;
        }
        getLiquidityPoolDetail() {
          const n = [],
            { sellPoolId: t, buyPoolId: i } = this.relatePoolId;
          (t && n.push(t), i && n.push(i));
          const o = [...new Set(n)];
          o.length > 0 && this.poolService.startQueryPoolTask(o);
        }
        onManuallyFocus() {
          const n = [this.sellInputRef, this.buyInputRef];
          for (const t of n)
            if (t) {
              const i = t.nativeElement;
              if (!i.value) {
                i.focus();
                break;
              }
            }
        }
        initInputListenEvent() {
          (this.sellInputRef &&
            this.sellInputRef.nativeElement.addEventListener("input", this.sellInputEvent.bind(this)),
            this.buyInputRef &&
              this.buyInputRef.nativeElement.addEventListener("input", this.buyInputEvent.bind(this)));
        }
        openConnectWalletPanel() {
          var n = this;
          return (0, c.Z)(function* () {
            const { selectWalletSheet: t } = n;
            t.is_open ||
              ((n.selectWalletSheet.presetWallets = yield n.walletService.getPresetWallet()), (t.is_open = !0));
          })();
        }
        swapSubmit() {
          var n = this;
          return (0, c.Z)(function* () {
            const { swapSheet: t } = n;
            t.is_open || (t.is_open = !0);
          })();
        }
        openAdvancedSettingsSheet() {
          var n = this;
          return (0, c.Z)(function* () {
            const { advancedSettingsSheet: t } = n;
            t.is_open || (t.is_open = !0);
          })();
        }
        openSelectAssetSheet(n) {
          var t = this;
          return (0, c.Z)(function* () {
            ((t.operate = n || (t.sellPanel.coin ? J.BUY : J.SELL)),
              n === J.SELL ? t.handleSellPanleDataList() : n === J.BUY && t.handleBuyPanleDataList(),
              (t.selectAssetSheet.isOpen = !0));
          })();
        }
        handleBuyPanleDataList() {
          const t = this.commonConfigService.dollarEquivalentCoins.value,
            l = [
              ...this.commonConfigService.poolListSubject.value.map((d) => ({
                chainName: d.anchorCoinsChainName,
                coinName: d.anchorCoinsName,
              })),
              ...t,
            ].map((d) => {
              const p = y.AG[d.chainName],
                g = d.coinName,
                { amount: T, decimals: v } = this.getOwnCoinAmount(p, g),
                { sellChain: A, sellCoin: E } = this.poolUtil();
              return {
                chainName: p,
                tokenName: g,
                amount: T,
                decimals: v,
                disabled: !1,
                select: A === p && E === g,
              };
            });
          this.selectAssetSheet.data.assets = l;
        }
        handleSellPanleDataList() {
          const t = this.commonConfigService.dollarEquivalentCoins.value,
            l = [
              ...this.commonConfigService.poolListSubject.value.map((d) => ({
                chainName: d.anchorCoinsChainName,
                coinName: d.anchorCoinsName,
              })),
              ...t,
            ].map((d) => {
              const p = y.AG[d.chainName],
                g = d.coinName,
                { amount: T, decimals: v } = this.getOwnCoinAmount(p, g),
                { buyChain: A, buyCoin: E } = this.poolUtil(),
                w = A === p && E === g;
              return {
                chainName: p,
                tokenName: g,
                amount: T,
                decimals: v,
                disabled: w,
                select: w,
              };
            });
          this.selectAssetSheet.data.assets = l;
        }
        getOwnCoinAmount(n, t) {
          var i;
          const o = null === (i = this.connectedWallet) || void 0 === i ? void 0 : i.assetInfoListMap;
          let l = "0",
            d = 8;
          if (o) {
            const p = o.get(n);
            if (p) {
              const g = p.assets.find((T) => T.assetType === t);
              g && ((l = g.amount), (d = g.decimals));
            }
          }
          return { amount: l, decimals: d };
        }
        initPoolInfo() {
          ((this.relatePool.buyPool = void 0), (this.relatePool.sellPool = void 0));
        }
        initPanel(n) {
          Object.assign(n === J.SELL ? this.sellPanel : this.buyPanel, {
            poolId: "",
            icon: void 0,
            chain: void 0,
            coin: void 0,
            amount: "",
            balance: "- -",
          });
        }
        clearPoolInfo() {
          ((this.showPoolCoinNotEnough = !1),
            (this.poolDetailList = []),
            (this.relatePoolId = { sellPoolId: "", buyPoolId: "" }),
            (this.relatePool.buyPool = void 0),
            (this.relatePool.sellPool = void 0));
        }
        clearAllInfo() {
          (this.initPanel(J.BUY),
            this.initPanel(J.SELL),
            this.clearPoolInfo(),
            this.initGasFeeInfo(),
            this.initMainCoinInfoAndFee());
        }
        onSelectToken(n) {
          var t = this;
          return (0, c.Z)(function* () {
            t.console.info("submit select token", n);
            const { selectedAsset: i } = n,
              { chainName: o, tokenName: l } = i,
              d = t.operate === J.SELL;
            if ((t.clearPoolInfo(), t.initGasFeeInfo(), d)) {
              (t.initMainCoinInfoAndFee(), yield t.getMainChainInfoandCalculateFee(o));
              const { chain: g, coin: T } = t.buyPanel;
              if (g && T) {
                const v = t.commonConfigService.dollarEquivalentCoins.value.find(
                    (E) => E.chainName === y.FN[o] && E.coinName === l,
                  ),
                  A = t.commonConfigService.dollarEquivalentCoins.value.find(
                    (E) => E.chainName === y.FN[g] && E.coinName === T,
                  );
                v && A && t.initPanel(J.BUY);
              }
            } else {
              const { chain: g, coin: T } = t.sellPanel;
              if (g && T) {
                const v = t.commonConfigService.dollarEquivalentCoins.value.find(
                    (E) => E.chainName === y.FN[o] && E.coinName === l,
                  ),
                  A = t.commonConfigService.dollarEquivalentCoins.value.find(
                    (E) => E.chainName === y.FN[g] && E.coinName === T,
                  );
                v && A && t.initPanel(J.SELL);
              }
            }
            const p = d ? t.sellPanel : t.buyPanel;
            ((p.coin = l), (p.chain = o), t.changeViewBalanceAmount(), t.handleRelateId(), t.getLiquidityPoolDetail());
          })();
        }
        pageOnPause() {
          ((this.fromRouter = !1), this.poolService.removeQueryPoolTask());
        }
        handleRouerSelectCoin() {
          let t;
          if (
            ((this.fromRouter = !1),
            this.poolDetailList[0].quoteAssociatedCoins.forEach((d) => {
              (void 0 === t || Number(d.amount) > Number(t.amount)) && (t = d);
            }),
            void 0 === t)
          )
            throw new Error("\u6ca1\u6709\u627e\u5230\u5c0fU");
          const { chainName: i, coinName: o } = t,
            l = { chainName: y.AG[i], tokenName: o };
          ((this.maxMode = !1), this.onSelectToken({ selectedAsset: l }));
        }
        handleRouterParams(n) {
          if (void 0 === n) return;
          const { anchorCoin: t, anchorChain: i } = n;
          ((this.buyPanel.chain = i), (this.buyPanel.coin = t), (this.operate = J.SELL));
          const o = this.commonConfigService.searchPool(y.FN[i], t);
          ((this.fromRouter = !0), o && this.poolService.startQueryPoolTask([o.poolId]));
        }
        jumpSwapPage() {
          this.connectedWallet
            ? 0 === this.currentTabIdx
              ? this.nav.routeTo("/mine/my-record-swap")
              : this.child.jumpRecordPage()
            : $.F.show("\u8BF7\u5148\u8FDE\u63A5\u94B1\u5305");
        }
        pageOnResume() {
          this.getLiquidityPoolDetail();
        }
        showMax() {
          const n = parseFloat(this.sellPanel.balance);
          return !Number.isNaN(n) && 0 !== n;
        }
        get getSellMaxValue() {
          const { gasFee: n } = this;
          let t = new N.Z(this.sellPanel.balance);
          if (n) {
            const i = new N.Z(n).dividedBy(1e8).toFixed(8, 1);
            t = t.minus(i);
          }
          return t.toString();
        }
        getBuyMaxValue() {
          ((this.caculateErr = Q.HAS_NO_LIQUIDITY), (this.caculateResult = !0));
          const { sellCoin: n, buyCoin: t, sellChain: i, buyChain: o, sellAmount: l } = this.poolUtil(),
            { relatePool: d } = this,
            { sellPool: p, buyPool: g } = d;
          if (void 0 === p || void 0 === g) return (this.console.log("\u6ca1\u6709\u5bf9\u5e94\u6c60\u5b50"), "0");
          if (n && t && i && o) {
            if (Number.isNaN(Number(l)) || "" === l || 0 === Number(l)) return "0";
            const T = this.caculateSell(i, n, new N.Z(l).multipliedBy(1e8).toString(), p, g, o, t, !0),
              { result: v } = T;
            if (((this.caculateResult = v), v)) {
              const { amount: A } = T;
              return A;
            }
            return "0";
          }
          return "0";
        }
        handleMaxBtn(n) {
          (n.preventDefault(), n.stopPropagation());
          const { gasFee: t, mainCoin: i } = this,
            { sellCoin: o } = this.poolUtil(),
            l = this.getSellMaxValue;
          if (((this.showPoolCoinNotEnough = !1), (this.maxMode = !0), +l > 0))
            ((this.sellPanel.amount = i === o ? l : this.sellPanel.balance), (this.lastInput = J.SELL));
          else {
            const d = new N.Z(t).dividedBy(1e8).toFixed(8, 1);
            ((this.gasFeeIsEnough = !1),
              (this.showGasTip = !0),
              (this.gasFeeTipText = `\u8bf7\u9884\u7559 ${d} ${o} \u77ff\u5de5\u8d39`));
          }
          this.checkEventList();
        }
        getPoolById(n) {
          return this.poolDetailList.find((i) => i.poolId === n);
        }
        handlePoolInfo() {
          const { sellPoolId: n, buyPoolId: t } = this.relatePoolId,
            i = this.getPoolById(n),
            o = this.getPoolById(t);
          i && o && ((this.relatePool.sellPool = i), (this.relatePool.buyPool = o));
        }
        handleRelateId() {
          const { sellIsQuote: n, buyIsQuote: t, sellChain: i, sellCoin: o, buyChain: l, buyCoin: d } = this.poolUtil();
          if (void 0 !== i && void 0 !== o && void 0 !== l && void 0 !== d)
            if (n || t) {
              const T = this.commonConfigService.searchPool(y.FN[n ? l : i], n ? d : o);
              if (!T) throw (this.checkEventList(), new Error("\u6ca1\u6709\u627e\u5230\u5bf9\u5e94\u6c60\u5b50ID"));
              this.relatePoolId = { sellPoolId: T.poolId, buyPoolId: T.poolId };
            } else {
              const p = this.commonConfigService.searchPool(y.FN[i], o),
                g = this.commonConfigService.searchPool(y.FN[l], d);
              (p && (this.relatePoolId.sellPoolId = p.poolId), g && (this.relatePoolId.buyPoolId = g.poolId));
            }
        }
        poolUtil() {
          const { sellPanel: n, buyPanel: t, relatePool: i } = this,
            { coin: o, chain: l, amount: d } = n,
            { coin: p, chain: g, amount: T } = t,
            A = Array.from(new Set(this.commonConfigService.dollarEquivalentCoins.value.map((F) => F.coinName))),
            E = A.includes(o),
            w = A.includes(p),
            { sellPool: B, buyPool: z } = i;
          return {
            sellAmount: d,
            buyAmount: T,
            sellCoin: o,
            buyCoin: p,
            sellChain: l,
            buyChain: g,
            sellIsQuote: E,
            buyIsQuote: w,
            sellPool: B,
            buyPool: z,
          };
        }
        handleSellCaculate() {
          ((this.caculateErr = Q.HAS_NO_LIQUIDITY), (this.caculateResult = !0));
          const { sellCoin: n, sellAmount: t, buyCoin: i, sellChain: o, buyChain: l } = this.poolUtil(),
            { relatePool: d } = this,
            { sellPool: p, buyPool: g } = d;
          if (void 0 !== p && void 0 !== g) {
            if (n && i && o && l) {
              if ("" === t) return void (this.buyPanel.amount = "");
              if (0 === Number(t))
                return (
                  (this.buyPanel.amount = ""),
                  (this.caculateResult = !1),
                  void (this.caculateErr = Q.INPUT_ZERO)
                );
              const T = this.caculateSell(o, n, t, p, g, l, i),
                { result: v } = T;
              if (((this.caculateResult = v), v)) {
                const { amount: A } = T;
                ((this.buyPanel.amount = A), this.handlePriceCaculate(n, t, i, A));
              } else {
                this.buyPanel.amount = "";
                const { message: A } = T;
                this.caculateErr = A;
              }
            }
          } else this.console.log("\u6ca1\u6709\u5bf9\u5e94\u6c60\u5b50");
        }
        handlePriceCaculate(n, t, i, o) {
          if (0 === Number(t) || 0 === Number(o)) return void this.console.log("\u6570\u91cf\u4e0d\u80fd\u4e3a\u96f6");
          this.price.direction = ne.SC.FORWARD;
          const l = Number(new N.Z(t).dividedBy(o).toFixed(8, 1)).toString(),
            d = Number(new N.Z(o).dividedBy(t).toFixed(8, 1)).toString(),
            g = (0, ne.JV)(i, l, n, d, {
              direction: ne.SC.FORWARD,
              format: !1,
            });
          this.price = g;
        }
        caculateSell(n, t, i, o, l, d, p, g = !1) {
          const T = new N.Z(i).multipliedBy(1e8).toString(),
            { sellIsQuote: v, buyIsQuote: A } = this.poolUtil();
          if (v || A) {
            const E = v ? t : p,
              w = v ? n : d,
              { success: B, amount: z } = this.getPoolSmallUAmountByCoinName(o, w, E);
            if (!1 === B || "0" === T)
              return (
                (this.showPoolCoinNotEnough = !0),
                (this.poolUNotEnoughTip = `\u5f53\u524d\u6c60\u5b50\u4e0d\u652f\u6301 ${E} ( ${w} ) \u7684\u4ea4\u6613,\u8bf7\u91cd\u9009`),
                { result: !1, message: Q.HAS_NO_LIQUIDITY }
              );
            const F = this.calculateGainByExchange(y.FN[n], t, T, o),
              Z = _e.rZ.transform(Number(F), 8, { removeZero: !0 }),
              he = v ? T : F.toString();
            if (A && new N.Z(he).isGreaterThanOrEqualTo(z)) {
              this.showPoolCoinNotEnough = !0;
              const Ze = _e.rZ.transform(Number(z), 8, { removeZero: !0 });
              return (
                (this.poolUNotEnoughTip = `* \u6c60\u4e2d${E}(${w}) \u7684\u6570\u91cf\u5269\u4f59 ${Ze} `),
                { result: !1, message: Q.HAS_NO_LIQUIDITY }
              );
            }
            return { result: !0, amount: Z };
          }
          {
            const E = this.sellPoolCaculate(o, l, n, t, T),
              { result: w } = E;
            if (w) {
              const { amount: B } = E;
              return {
                result: !0,
                amount: _e.rZ.transform(Number(B), 8, { removeZero: !0 }),
              };
            }
            {
              const { message: B } = E;
              return { result: !1, message: B };
            }
          }
        }
        calculateGainByExchange(n, t, i, o) {
          const l = this.commonConfigService.dollarEquivalentCoins.value.find(
            (g) => g.chainName === n && g.coinName === t,
          );
          return G.calculateHelper.calculateGainByExchange(
            void 0 === l ? n : o.quoteCoinsChainName,
            void 0 === l ? t : o.quoteCoinsName,
            i,
            o,
          );
        }
        calculateSpendByExchange(n, t, i, o) {
          const l = this.commonConfigService.dollarEquivalentCoins.value.find(
            (g) => g.chainName === n && g.coinName === t,
          );
          return G.calculateHelper.calculateSpendByExchange(
            void 0 === l ? n : o.quoteCoinsChainName,
            void 0 === l ? t : o.quoteCoinsName,
            i,
            o,
          );
        }
        getPoolCoinAmountByCoinAndChain(n, t, i) {
          const { anchorCoinsName: o, anchorCoinsChainName: l, anchorCoinsAmount: d, quoteCoinsAmount: p } = i;
          return n === o && t === y.AG[l] ? d : p;
        }
        buyPoolCaculate(n, t, i, o, l) {
          const d = this.getPoolCoinAmountByCoinAndChain(o, i, n);
          if (Number(l) > Number(d)) return { message: Q.HAS_NO_LIQUIDITY, result: !1 };
          const p = this.calculateSpendByExchange(y.FN[i], o, l, n),
            { chain: g, coin: T } = this.sellPanel;
          if (void 0 === g || void 0 === T)
            throw new Error("\u9762\u677f\u8f93\u5165\u503c\u4e0d\u5e94\u8be5\u4e3aundefined");
          const { anchorCoinsChainName: v, anchorCoinsName: A, quoteCoinsName: E, quoteCoinsChainName: w } = t,
            B = g === y.AG[v] && T === A,
            z = B ? w : v,
            F = B ? E : A;
          if (Number(p) > Number(this.getPoolCoinAmountByCoinAndChain(F, y.AG[z], t)))
            return (
              this.console.log(
                "\u5151\u6362\u8def\u5f84\u8ba1\u7b97\u7ed3\u679c\uff1aB\u6c60\u5b50U\u6570\u91cf\u4e0d\u8db3\u4ee5\u5151\u6362",
              ),
              { message: Q.HAS_NO_LIQUIDITY, result: !1 }
            );
          if (0 === Number(p))
            return (
              this.console.log(
                "\u5151\u6362\u8def\u5f84\u8ba1\u7b97\u7ed3\u679c\uff1a\u5151\u6362\u51fa\u6765\u7684U\u8fc7\u5c0f",
              ),
              { message: Q.HAS_NO_LIQUIDITY, result: !1 }
            );
          const he = this.calculateSpendByExchange(z, F, String(p), t);
          return { result: !0, amount: String(he) };
        }
        sellPoolCaculate(n, t, i, o, l) {
          const d = this.calculateGainByExchange(y.FN[i], o, l, n),
            { chain: p, coin: g } = this.buyPanel;
          if (0 === Number(d))
            return (
              this.console.log(
                "\u5151\u6362\u8def\u5f84\u8ba1\u7b97\u7ed3\u679c\uff1a\u5151\u6362\u51fa\u6765\u7684U\u8fc7\u5c0f",
              ),
              { message: Q.HAS_NO_LIQUIDITY, result: !1 }
            );
          const { anchorCoinsChainName: T, anchorCoinsName: v, quoteCoinsName: A, quoteCoinsChainName: E } = t,
            w = p === y.AG[T] && g === v,
            F = this.calculateGainByExchange(w ? E : T, w ? A : v, String(d), t);
          return { result: !0, amount: String(F) };
        }
        handleBuyCaculate() {
          ((this.caculateResult = !0), (this.caculateErr = Q.HAS_NO_LIQUIDITY));
          const { buyCoin: n, buyAmount: t, sellCoin: i, buyChain: o, sellChain: l } = this.poolUtil(),
            { relatePool: d } = this,
            { sellPool: p, buyPool: g } = d;
          if (void 0 !== p && void 0 !== g) {
            if (i && n && o && l) {
              if ("" === t) return void (this.sellPanel.amount = "");
              if (0 === Number(t))
                return (
                  (this.sellPanel.amount = ""),
                  (this.caculateResult = !1),
                  void (this.caculateErr = Q.INPUT_ZERO)
                );
              const T = this.caculateBuy(o, n, t, p, g, l, i),
                { result: v } = T;
              if (((this.caculateResult = v), v)) {
                const { amount: A } = T;
                ((this.sellPanel.amount = A), this.handlePriceCaculate(i, A, n, t));
              } else {
                const { message: A } = T;
                ((this.caculateErr = A), (this.sellPanel.amount = ""));
              }
            }
          } else this.console.log("\u6ca1\u6709\u5bf9\u5e94\u6c60\u5b50");
        }
        getPoolSmallUAmountByCoinName(n, t, i) {
          const o = n.quoteAssociatedCoins.find((l) => l.chainName === y.FN[t] && l.coinName === i);
          return void 0 === o ? { success: !1, amount: "0" } : { success: !0, amount: o.amount };
        }
        caculateBuy(n, t, i, o, l, d, p) {
          const g = new N.Z(i).multipliedBy(1e8).toString(),
            { sellIsQuote: T, buyIsQuote: v } = this.poolUtil();
          if (T || v) {
            const A =
              o.anchorCoinsChainName === y.FN[n] && o.anchorCoinsName === t ? o.anchorCoinsAmount : o.quoteCoinsAmount;
            if (new N.Z(g).isGreaterThanOrEqualTo(A)) return { result: !1, message: Q.HAS_NO_LIQUIDITY };
            const E = v ? t : p,
              w = v ? n : d,
              B = this.getPoolSmallUAmountByCoinName(o, w, E),
              { success: z, amount: F } = B;
            if (!1 === z || "0" === g)
              return (
                (this.showPoolCoinNotEnough = !0),
                (this.poolUNotEnoughTip = `\u5f53\u524d\u6c60\u5b50\u4e0d\u652f\u6301 ${E} ( ${w} ) \u7684\u4ea4\u6613,\u8bf7\u91cd\u9009`),
                { result: !1, message: Q.HAS_NO_LIQUIDITY }
              );
            const Z = this.calculateSpendByExchange(y.FN[n], t, g, o),
              he = _e.rZ.transform(Number(Z), 8, { removeZero: !0 });
            if (v && new N.Z(g).isGreaterThanOrEqualTo(F)) {
              this.showPoolCoinNotEnough = !0;
              const Ze = _e.rZ.transform(Number(F), 8, { removeZero: !0 });
              return (
                (this.poolUNotEnoughTip = `* \u6c60\u4e2d${E}(${w}) \u7684\u6570\u91cf\u5269\u4f59 ${Ze} `),
                { result: !1, message: Q.HAS_NO_LIQUIDITY }
              );
            }
            return { result: !0, amount: he };
          }
          {
            const A = this.buyPoolCaculate(l, o, n, t, g),
              { result: E } = A;
            if (E) {
              const { amount: w } = A;
              return {
                amount: _e.rZ.transform(w, 8, { removeZero: !0 }),
                result: !0,
              };
            }
            {
              const { message: w } = A;
              return { message: w, result: !1 };
            }
          }
        }
        openAddLiquidityDialog() {
          var n = this;
          return (0, c.Z)(function* () {
            const { sellIsQuote: t, buyIsQuote: i, sellCoin: o, buyCoin: l, sellChain: d, buyChain: p } = n.poolUtil();
            if (void 0 === p || void 0 === l || void 0 === o || void 0 === d) return;
            const g = `${o}-${l}`,
              T = t ? o : l,
              v = t || i ? `${g}` : `${o}-${T},${l}-${T}`;
            let A = {};
            t
              ? (A = {
                  anchorCoinName: l,
                  anchorChainName: y.FN[p],
                  quoteCoinName: o,
                  quoteChainName: y.FN[d],
                })
              : i &&
                (A = {
                  anchorCoinName: o,
                  anchorChainName: y.FN[d],
                  quoteCoinName: l,
                  quoteChainName: y.FN[p],
                });
            const E = yield n.confirm({
              headerTitle: `\u5f53\u524d${v}\u6d41\u52a8\u6027\u6c60\u6682\u65e0\u8d44\u91d1\uff0c\u65e0\u6cd5\u8fdb\u884c${g}\u7684\u5151\u6362\u3002`,
              bodyMessage:
                "\u60a8\u53ef\u4ee5\u7b49\u5f85\u5176\u4ed6\u7528\u6237\u63d0\u4f9b\u6d41\u52a8\u6027\u540e\u518d\u8fdb\u884c\u5151\u6362\uff0c\u4e5f\u53ef\u4ee5\u524d\u5f80\u589e\u52a0\u5bf9\u5e94\u5e01\u79cd\u7684\u6d41\u52a8\u6027\u3002",
              footerTheme: "normal",
              bodyAlign: "left",
              confirmText: "\u589e\u52a0\u6d41\u52a8\u6027",
            });
            (yield (0, K._v)(250), E && n.nav.routeTo("/add-liquidity", { ...A }));
          })();
        }
      }
      (((Ye = C).ɵfac = (() => {
        let a;
        return function (t) {
          return (a || (a = e.n5z(Ye)))(t || Ye);
        };
      })()),
        (Ye.ɵcmp = e.Xpm({
          type: Ye,
          selectors: [["bs-swap-page"]],
          viewQuery: function (n, t) {
            if ((1 & n && (e.Gf(Lo, 5), e.Gf(Ro, 5), e.Gf(ko, 5), e.Gf(Do, 5)), 2 & n)) {
              let i;
              (e.iGM((i = e.CRH())) && (t.subscriptRef = i.first),
                e.iGM((i = e.CRH())) && (t.child = i.first),
                e.iGM((i = e.CRH())) && (t.sellInputRef = i.first),
                e.iGM((i = e.CRH())) && (t.buyInputRef = i.first));
            }
          },
          standalone: !0,
          features: [e.qOj, e.jDz],
          decls: 22,
          vars: 15,
          consts: () => {
            let a, n, t, i, o, l, d, p, g, T;
            return (
              (a = "" + "\ufffd0\ufffd" + "\u6ED1\u70B9"),
              (n = "\u4E70\u5165"),
              (t = "\u8F93\u5165\u6570\u91CF"),
              (i = "\u5356\u51FA"),
              (o = "\u8F93\u5165\u6570\u91CF"),
              (l = "\u9009\u62E9\u8D44\u4EA7"),
              (d = "\u9009\u62E9\u8D44\u4EA7"),
              (p = "\u6700\u5927"),
              (g = "" + "\ufffd0\ufffd" + ""),
              (T = " " + "\ufffd0\ufffd" + " "),
              [
                [3, "contentBackground", "hideHeader", "ngStyle"],
                [1, "px-4", "pt-4", "h-full", "overflow-hidden"],
                [1, "flex", "h-10", "items-center", "justify-between"],
                [
                  "wObSize",
                  "",
                  1,
                  "grid-in-[tabs]",
                  "relative",
                  "z-[2]",
                  "flex",
                  "items-center",
                  "justify-start",
                  "gap-4",
                ],
                ["navSize", "obSize"],
                [1, "_subscript", 3, "ngStyle"],
                ["tabsSlides", ""],
                ["class", "rounded-2.5 border-gray-pale ml-auto mr-3 flex items-center justify-center border pl-3"],
                [1, "bg-gray-0", "rounded-2.5", "flex", "h-8", "w-8", "items-center", "justify-center"],
                ["name", "icon-history", 1, "icon-5", 3, "click"],
                ["class", "h-full pt-4"],
                [3, "isOpen", "panelClass", "isOpenChange"],
                [3, "isOpen", "isOpenChange"],
                [2, "white-space", "nowrap", 3, "id", "click"],
                [
                  1,
                  "rounded-2.5",
                  "border-gray-pale",
                  "ml-auto",
                  "mr-3",
                  "flex",
                  "items-center",
                  "justify-center",
                  "border",
                  "pl-3",
                  3,
                  "click",
                ],
                [1, "text-title-1", "text-xs"],
                a,
                [1, "bg-gray-0", "rounded-2.5", "ml-2.5", "flex", "h-8", "w-8", "items-center", "justify-center"],
                ["name", "icon-slider", 1, "text-xl"],
                [1, "h-full", "pt-4"],
                [1, "rounded-4", "bg-gray-pale", "relative", "mb-2", "flex-shrink-0", "p-4"],
                [1, "relative", "z-10"],
                [1, "mb-4", "flex", "items-center"],
                [1, "text-title-1", "text-sm", "font-semibold"],
                n,
                [1, "mb-4", "flex", "h-10", "items-center"],
                [1, "flex", "items-center", 3, "click"],
                ["class", "rounded-1.5 flex flex-shrink-0 items-center bg-white py-1 pl-3 pr-2"],
                [
                  "placeholder",
                  t,
                  1,
                  "placeholder:text-title-2",
                  "max-w-1/2",
                  "ml-auto",
                  "border-none",
                  "text-right",
                  "text-2xl",
                  "font-semibold",
                  "outline-none",
                  "placeholder:text-2xl",
                  "overflow-hidden",
                  3,
                  "maxDecimals",
                  "maxValue",
                  "layout",
                  "formControl",
                  "ngModel",
                  "ngModelChange",
                ],
                [1, "relative", "z-10", "flex", "items-center", "text-sm"],
                ["name", "icon-assets-normal", 1, "text-2xl"],
                [1, "text-title-1", "mr-1"],
                [1, "rounded-4", "bg-gray-pale", "relative", "mb-2", "p-4"],
                [
                  1,
                  "absolute",
                  "-top-6",
                  "right-16",
                  "z-20",
                  "flex",
                  "h-12",
                  "w-12",
                  "items-center",
                  "justify-center",
                  "rounded-full",
                  "bg-white",
                  3,
                  "click",
                ],
                ["name", "icon-home-arrow-exchange", 1, "text-2xl"],
                i,
                ["class", "rounded-1.5 flex flex-shrink-0 items-center bg-white py-1 pl-2 pr-3"],
                [
                  "placeholder",
                  o,
                  1,
                  "placeholder:text-title-2",
                  "max-w-1/2",
                  "ml-auto",
                  "border-none",
                  "text-right",
                  "text-2xl",
                  "font-semibold",
                  "outline-none",
                  "placeholder:text-2xl",
                  "overflow-hidden",
                  3,
                  "maxDecimals",
                  "maxValue",
                  "layout",
                  "formControl",
                  "ngModel",
                  "ngModelChange",
                ],
                [1, "flex", "items-center", "text-sm"],
                ["class", "text-title-0 bg-title-3 rounded-1 ml-auto px-2 py-1 text-xs"],
                [1, "flex", "h-8", "items-center", "justify-center"],
                ["class", "flex items-center justify-center"],
                [
                  "bnRippleButton",
                  "",
                  1,
                  "rounded-12",
                  "mt-4",
                  "flex",
                  "w-full",
                  "shrink-0",
                  "items-center",
                  "justify-center",
                  "py-2.5",
                  "text-lg",
                  "font-semibold",
                  "text-white",
                  3,
                  "disabled",
                  "click",
                ],
                [1, "relative"],
                [1, "icon-6", "absolute", "-right-6", "top-0", 3, "loadingTheme", "showLoading"],
                ["class", "text-red mx-auto mt-2 w-4/5 text-center text-xs leading-5"],
                ["class", "my-6 flex items-center justify-center"],
                [
                  1,
                  "rounded-1.5",
                  "mx-1",
                  "flex",
                  "h-5",
                  "w-5",
                  "items-center",
                  "justify-center",
                  "border",
                  "border-white",
                ],
                [3, "swapChainName", "iconSize"],
                [1, ""],
                [1, "rounded-1.5", "flex", "flex-shrink-0", "items-center", "bg-white", "py-1", "pl-3", "pr-2"],
                [1, "mr-1"],
                l,
                ["name", "icon-home-arrow-token", "bnRippleButton", "", 1, "icon-4", 3, "mode"],
                [3, "swapChainName", "iconSize", "swapCoinName"],
                [1, "text-black-1", "mx-1", "text-base", "font-semibold"],
                ["bnRippleButton", "", 1, "icon-4", 3, "mode"],
                ["name", "icon-home-arrow-token"],
                [
                  1,
                  "rounded-1",
                  "mx-1",
                  "flex",
                  "h-5",
                  "w-5",
                  "items-center",
                  "justify-center",
                  "border",
                  "border-white",
                ],
                [1, "rounded-1.5", "flex", "flex-shrink-0", "items-center", "bg-white", "py-1", "pl-2", "pr-3"],
                d,
                [1, "text-title-0", "bg-title-3", "rounded-1", "ml-auto", "px-2", "py-1", "text-xs", 3, "click"],
                p,
                [1, "flex", "items-center", "justify-center"],
                ["src", "./assets/images/icon-right.svg"],
                g,
                ["src", "./assets/images/icon-wrong.svg"],
                [1, "text-red", "mx-auto", "mt-2", "w-4/5", "text-center", "text-xs", "leading-5"],
                T,
                [1, "my-6", "flex", "items-center", "justify-center"],
                ["name", "icon-home-refresh", 1, "text-2xl", 3, "ngStyle", "click"],
                [1, "text-title-1", "mx-1", "text-center"],
                ["name", "icon-home-arrow-exchange-rate", 1, "text-2xl", 3, "ngStyle", "click"],
                ["myHoldingsPage", ""],
                [
                  3,
                  "sellPanel",
                  "buyPanel",
                  "preParams",
                  "transferOptions",
                  "platformFee",
                  "expectBuyAmount",
                  "returnValue$",
                ],
                [3, "dataList", "returnValue$"],
                [3, "connectType", "presetWallets"],
                ["style", "white-space: nowrap", 3, "id", "class"],
              ]
            );
          },
          template: function (n, t) {
            (1 & n &&
              (e.TgZ(0, "common-page", 0)(1, "div", 1)(2, "div", 2)(3, "nav", 3, 4),
              e.SjG(5, Uo, 2, 5, "div", 77, e.ikw),
              e._UZ(7, "div", 5, 6),
              e.qZA(),
              e.YNc(9, Zo, 5, 1, "div", 7),
              e.TgZ(10, "button", 8)(11, "bs-icon", 9),
              e.NdJ("click", function () {
                return t.jumpSwapPage();
              }),
              e.qZA()()(),
              e.YNc(12, Yo, 42, 26, "section", 10)(13, Ko, 3, 0),
              e.qZA()(),
              e.TgZ(14, "common-bottom-sheet", 11),
              e.NdJ("isOpenChange", function (o) {
                return (t.swapSheet.is_open = o);
              }),
              e.YNc(15, es, 1, 6, "ng-template"),
              e.qZA(),
              e.TgZ(16, "common-bottom-sheet", 12),
              e.NdJ("isOpenChange", function (o) {
                return (t.advancedSettingsSheet.is_open = o);
              }),
              e.YNc(17, ts, 1, 0, "ng-template"),
              e.qZA(),
              e.TgZ(18, "common-bottom-sheet", 11),
              e.NdJ("isOpenChange", function (o) {
                return (t.selectAssetSheet.isOpen = o);
              }),
              e.YNc(19, ns, 1, 1, "ng-template"),
              e.qZA(),
              e.TgZ(20, "common-bottom-sheet", 12),
              e.NdJ("isOpenChange", function (o) {
                return (t.selectWalletSheet.is_open = o);
              }),
              e.YNc(21, is, 1, 2, "ng-template"),
              e.qZA()),
              2 & n &&
                (e.Q6J("contentBackground", "#fff")("hideHeader", !0)("ngStyle", e.DdM(12, os)),
                e.xp6(5),
                e.wJu(t.swapTabs),
                e.xp6(2),
                e.Q6J("ngStyle", e.VKq(13, ss, t.currentTabIdx || 0)),
                e.xp6(2),
                e.um2(9, 0 === t.currentTabIdx ? 9 : -1),
                e.xp6(3),
                e.um2(12, 0 === t.currentTabIdx ? 12 : 13),
                e.xp6(2),
                e.Q6J("isOpen", t.swapSheet.is_open)("panelClass", "max-h-4/5"),
                e.xp6(2),
                e.Q6J("isOpen", t.advancedSettingsSheet.is_open),
                e.xp6(2),
                e.Q6J("isOpen", t.selectAssetSheet.isOpen)("panelClass", "h-4/5"),
                e.xp6(2),
                e.Q6J("isOpen", t.selectWalletSheet.is_open)));
          },
          dependencies: [
            Bt.j,
            Ii.QP,
            x.f5,
            ce.y,
            dt.w,
            _.PC,
            Se.JJ,
            Se.oH,
            ee.C,
            O.oJ,
            L.G4,
            _.ez,
            Ri,
            ki._,
            Ao.Z,
            M.Z,
            we,
            Oo,
          ],
          styles: [
            "@keyframes _ngcontent-%COMP%_ring{0%{transform:rotate(0)}to{transform:rotate(-360deg)}}[_nghost-%COMP%]   ._price-ani[_ngcontent-%COMP%]{animation-name:_ngcontent-%COMP%_ring;animation-duration:2s;animation-timing-function:linear;animation-iteration-count:infinite}[_nghost-%COMP%]   ._reverse-ani[_ngcontent-%COMP%]{animation-name:_ngcontent-%COMP%_ring;animation-duration:1s;animation-timing-function:linear;animation-iteration-count:1}[_nghost-%COMP%]   ._market-list-height[_ngcontent-%COMP%]{height:calc(100% - 4.2rem)}[_nghost-%COMP%]   .plate-box[_ngcontent-%COMP%]{scroll-snap-type:x mandatory}[_nghost-%COMP%]   .plate-box[_ngcontent-%COMP%]::-webkit-scrollbar{display:none}[_nghost-%COMP%]   ._subscript[_ngcontent-%COMP%]{position:absolute;--tw-bg-opacity: 1;background-color:rgb(100 15 243 / var(--tw-bg-opacity));height:4px;width:24px;border-radius:40px;bottom:-70%;--index: 0;transition-duration:.2s;transition-timing-function:ease-out}",
          ],
          changeDetection: 0,
        })),
        (0, s.gn)([C.State(), (0, s.w6)("design:type", Object)], C.prototype, "OPERATE", void 0),
        (0, s.gn)([C.State(), (0, s.w6)("design:type", Object)], C.prototype, "connectedWallet", void 0),
        (0, s.gn)([C.States(1), (0, s.w6)("design:type", Array)], C.prototype, "poolDetailList", void 0),
        (0, s.gn)([C.State(), (0, s.w6)("design:type", Object)], C.prototype, "priceAnimationState", void 0),
        (0, s.gn)([C.State(), (0, s.w6)("design:type", Object)], C.prototype, "btnText", void 0),
        (0, s.gn)([C.State(), (0, s.w6)("design:type", Object)], C.prototype, "btnDisabled", void 0),
        (0, s.gn)([C.State(), (0, s.w6)("design:type", Object)], C.prototype, "loading", void 0),
        (0, s.gn)([C.State(), (0, s.w6)("design:type", Object)], C.prototype, "version", void 0),
        (0, s.gn)([C.State(), (0, s.w6)("design:type", Object)], C.prototype, "feeRatio", void 0),
        (0, s.gn)([C.States(1), (0, s.w6)("design:type", Object)], C.prototype, "buyPanel", void 0),
        (0, s.gn)([C.States(1), (0, s.w6)("design:type", Object)], C.prototype, "sellPanel", void 0),
        (0, s.gn)([C.State(), (0, s.w6)("design:type", Object)], C.prototype, "platformFee", void 0),
        (0, s.gn)([C.State(), (0, s.w6)("design:type", Object)], C.prototype, "showGasTip", void 0),
        (0, s.gn)([C.State(), (0, s.w6)("design:type", Object)], C.prototype, "preParams", void 0),
        (0, s.gn)([C.State(), (0, s.w6)("design:type", Object)], C.prototype, "transferOptions", void 0),
        (0, s.gn)(
          [
            C.OnDestroy(),
            (0, s.w6)("design:type", Function),
            (0, s.w6)("design:paramtypes", []),
            (0, s.w6)("design:returntype", void 0),
          ],
          C.prototype,
          "unsubscribe",
          null,
        ),
        (0, s.gn)([C.State(), (0, s.w6)("design:type", Object)], C.prototype, "sellControl", void 0),
        (0, s.gn)([C.State(), (0, s.w6)("design:type", Object)], C.prototype, "buyControl", void 0),
        (0, s.gn)(
          [
            C.OnInit(),
            (0, s.w6)("design:type", Function),
            (0, s.w6)("design:paramtypes", []),
            (0, s.w6)("design:returntype", Promise),
          ],
          C.prototype,
          "dataInit",
          null,
        ),
        (0, s.gn)(
          [
            C.OnInit(),
            (0, s.w6)("design:type", Function),
            (0, s.w6)("design:paramtypes", []),
            (0, s.w6)("design:returntype", void 0),
          ],
          C.prototype,
          "bindButton",
          null,
        ),
        (0, s.gn)([C.State(), (0, s.w6)("design:type", Object)], C.prototype, "gasFeeIsEnough", void 0),
        (0, s.gn)([C.State(), (0, s.w6)("design:type", Object)], C.prototype, "gasFeeTipText", void 0),
        (0, s.gn)([C.States(1), (0, s.w6)("design:type", Object)], C.prototype, "swapSheet", void 0),
        (0, s.gn)([C.States(1), (0, s.w6)("design:type", Object)], C.prototype, "selectAssetSheet", void 0),
        (0, s.gn)(
          [
            C.AfterViewInit(),
            (0, s.w6)("design:type", Function),
            (0, s.w6)("design:paramtypes", []),
            (0, s.w6)("design:returntype", void 0),
          ],
          C.prototype,
          "initInputListenEvent",
          null,
        ),
        (0, s.gn)([C.States(1), (0, s.w6)("design:type", Object)], C.prototype, "selectWalletSheet", void 0),
        (0, s.gn)([C.States(1), (0, s.w6)("design:type", Object)], C.prototype, "advancedSettingsSheet", void 0),
        (0, s.gn)(
          [
            C.OnPause(),
            (0, s.w6)("design:type", Function),
            (0, s.w6)("design:paramtypes", []),
            (0, s.w6)("design:returntype", void 0),
          ],
          C.prototype,
          "pageOnPause",
          null,
        ),
        (0, s.gn)(
          [
            C.OnResume(),
            (0, s.w6)("design:type", Function),
            (0, s.w6)("design:paramtypes", []),
            (0, s.w6)("design:returntype", void 0),
          ],
          C.prototype,
          "pageOnResume",
          null,
        ),
        (0, s.gn)([C.State(), (0, s.w6)("design:type", Object)], C.prototype, "maxMode", void 0),
        (0, s.gn)([C.State(), (0, s.w6)("design:type", Object)], C.prototype, "buyMaxValue", void 0),
        (0, s.gn)([C.State(), (0, s.w6)("design:type", Object)], C.prototype, "showPoolCoinNotEnough", void 0),
        (0, s.gn)([C.State(), (0, s.w6)("design:type", Object)], C.prototype, "poolUNotEnoughTip", void 0));
      const as = C;
      var Ke,
        Sn = r(384);
      const rs = ["bottomNavSize"],
        ls = ["panel"],
        cs = ["linkContainer"];
      function ds(a, n) {
        if (1 & a) {
          const t = e.EpF();
          (e.TgZ(0, "div", 16),
            e.NdJ("click", function () {
              e.CHM(t);
              const o = e.oxw();
              return e.KtG(o.openWalletInfoSheet());
            }),
            e.TgZ(1, "div", 17),
            e._UZ(2, "bs-icon", 18),
            e.qZA(),
            e.TgZ(3, "div", 19),
            e._uU(4),
            e.qZA(),
            e._UZ(5, "bs-icon", 20),
            e.qZA());
        }
        if (2 & a) {
          const t = e.oxw();
          (e.xp6(2), e.Q6J("name", t.walletIcon), e.xp6(2), e.Oqu(t.connectedWallet.walletName));
        }
      }
      function us(a, n) {
        if (1 & a) {
          const t = e.EpF();
          (e.TgZ(0, "button", 21),
            e.NdJ("click", function () {
              e.CHM(t);
              const o = e.oxw();
              return e.KtG(o.openSwapWalletSheet());
            }),
            e._UZ(1, "bs-icon", 22),
            e.TgZ(2, "div", 23),
            e.SDv(3, 24),
            e.qZA()());
        }
      }
      function _s(a, n) {
        1 & a && e._UZ(0, "div", 25, 26);
      }
      function hs(a, n) {
        if (1 & a) {
          const t = e.EpF();
          (e.TgZ(0, "div", 27),
            e.NdJ("click", function () {
              const l = e.CHM(t).index,
                d = e.oxw();
              return e.KtG(d.selectTab(l));
            }),
            e._UZ(1, "bs-icon", 28),
            e.qZA());
        }
        if (2 & a) {
          const t = n.$implicit,
            i = e.oxw();
          (e.Gre(
            "flex rounded-full h-11 w-11 flex-col items-center justify-center ",
            (null == i.currLink ? null : i.currLink.index) === t.index ? "bg-white" : "",
            "",
          ),
            e.xp6(1),
            e.Q6J("name", (null == i.currLink ? null : i.currLink.index) === t.index ? t.icon_hover : t.icon_normal));
        }
      }
      function ps(a, n) {
        if (1 & a) {
          const t = e.EpF();
          (e.TgZ(0, "bs-wallet-info-panel", 29),
            e.NdJ("returnValue$", function (o) {
              e.CHM(t);
              const l = e.oxw();
              return e.KtG(l.onReconnectWallet(o));
            }),
            e.qZA());
        }
        if (2 & a) {
          const t = e.oxw();
          e.Q6J("walletIcon", t.walletIcon)("connectedWallet", t.walletInfoSheet.connectedWallet);
        }
      }
      function ms(a, n) {
        1 & a && e._UZ(0, "bs-version-info-panel");
      }
      function gs(a, n) {
        if ((1 & a && e._UZ(0, "bs-connect-wallet-panel-page", 30), 2 & a)) {
          const t = e.oxw();
          e.Q6J("connectType", t.selectWalletSheet.conncetType)("presetWallets", t.selectWalletSheet.presetWallets);
        }
      }
      const fs = () => ({ "--page-safe-area-inset-bottom": "0px" }),
        Ss = () => ({ "--env-safe-area-inset-bottom": "40px" });
      class k extends (0, f.To)(x.Wh) {
        constructor() {
          (super(...arguments),
            (this.__console_internal_config__ = {
              default: "warn",
              matchMode: "strict",
            }),
            (this.walletService = (0, e.f3M)(R.X)),
            (this.walletSheetSwitchService = (0, e.f3M)(Ot.h)),
            (this.showConnectWalletSheet = (0, e.cEC)(() => {
              this.walletSheetSwitchService.showConnectWalletSheet() && this.openSwapWalletSheet();
            })),
            (this.showWalletInfoSheet = (0, e.cEC)(() => {
              this.walletSheetSwitchService.showWalletInfoSheet() && this.openWalletInfoSheet();
            })),
            (this.bottomNavHeight = "0px"),
            (this.links = [
              {
                index: 0,
                href: "market",
                icon_normal: "icon-market-normal",
                icon_hover: "icon-market-hover",
                label_text: "\u5E02\u573A",
                component: Pi,
                ref: void 0,
              },
              {
                index: 1,
                href: "swap",
                icon_normal: "icon-swap-normal",
                icon_hover: "icon-swap-hover",
                label_text: "\u5151\u6362",
                component: as,
                ref: void 0,
              },
              {
                index: 2,
                href: "paradise",
                icon_normal: "icon-paradise-normal",
                icon_hover: "icon-paradise-hover",
                label_text: "\u4E50\u56ED",
                component: xn.ZP,
                ref: void 0,
              },
              {
                index: 3,
                href: "assets",
                icon_normal: "icon-assets-normal",
                icon_hover: "icon-assets-hover",
                label_text: "\u94B1\u5305",
                component: en,
                ref: void 0,
              },
            ]),
            (this.walletIcon = void 0),
            (this.connectedWallet = this.resolveData.conncetedWallet),
            (this.tryToOpenSwapWalletSheet = !1),
            (this.selectWalletSheet = {
              is_open: !1,
              conncetType: se.i.CONNECT_WALLET,
              presetWallets: [],
            }),
            (this.walletInfoSheet = { open: !1, connectedWallet: void 0 }),
            (this.versionInfoSheet = { open: !1 }),
            (this._colorService = (0, e.f3M)(H.x)),
            (this.poolDetailPageReturnController = new oe.k(this, Mt.default)));
        }
        set bottomNavSize(n) {
          this.takeUntilDestroy(n.resized$).subscribe((t) => {
            this.bottomNavHeight = t.borderHeight + "px";
          });
        }
        onConnectWallet(n) {
          var t = this;
          return (0, c.Z)(function* () {
            n.walletName && ((t.connectedWallet = n), t.console.info("connected to wallet", n));
          })();
        }
        dataInit() {
          var n = this;
          this.connectWallet$ = this.walletService.wallletConnected_subject.subscribe(
            (function () {
              var t = (0, c.Z)(function* (i) {
                void 0 !== i && ((n.connectedWallet = i.wallet), n.handleWalletIcon());
              });
              return function (i) {
                return t.apply(this, arguments);
              };
            })(),
          );
        }
        unsubscribe() {
          (this.console.log("\u6e05\u9664 \u8ba2\u9605"),
            this.connectWallet$ && this.connectWallet$.unsubscribe(),
            this.showConnectWalletSheet.destroy(),
            this.showWalletInfoSheet.destroy());
        }
        initLink() {
          var n = this;
          return (0, c.Z)(function* () {
            var t;
            const i = n.nav.getQueryParams(),
              o = i.index,
              l = i.swapSelectedAsset;
            ((n.currLink = n.selectTab(o ? Number(o) : 0)),
              "1" == o &&
                l &&
                (null === (t = n.links[1].ref) || void 0 === t ? void 0 : t.instance).handleRouterParams(
                  JSON.parse(l),
                ));
            for (const d of n.links) (yield (0, b.wc)(), n._initLinkRef(d));
          })();
        }
        openWalletInfoSheet() {
          ((this.walletInfoSheet.connectedWallet = this.connectedWallet), (this.walletInfoSheet.open = !0));
        }
        hideSplashScreen() {
          P.c.hide();
        }
        openSwapWalletSheet() {
          var n = this;
          return (0, c.Z)(function* () {
            const { selectWalletSheet: t } = n;
            t.is_open ||
              ((n.selectWalletSheet.presetWallets = yield n.walletService.getPresetWallet()), (t.is_open = !0));
          })();
        }
        onWalletPanelClose() {
          (this.console.log("\u5173\u95ed\u94b1\u5305\u9762\u677f\u5f39\u7a97"),
            this.tryToOpenSwapWalletSheet && (this.openSwapWalletSheet(), (this.tryToOpenSwapWalletSheet = !1)),
            this.walletSheetSwitchService.setWalletInfo(!1));
        }
        onConnectWalletPanelClose() {
          this.walletSheetSwitchService.setConnectWallet(!1);
        }
        onReconnectWallet(n) {
          n.reconnectWallet &&
            (this.console.info(
              "\u91cd\u65b0\u6253\u5f00\u94b1\u5305\u8fde\u63a5\u5f39\u7a97\u4ee5\u91cd\u65b0\u8fde\u63a5",
            ),
            (this.tryToOpenSwapWalletSheet = !0));
        }
        initTheme() {
          this.nav.storeState({
            theme: this._colorService.transform("primary"),
          });
        }
        handleWalletIcon() {
          const n = Lt.c.find((t) => {
            var i;
            return t.name === (null === (i = this.connectedWallet) || void 0 === i ? void 0 : i.walletName);
          });
          n && (this.walletIcon = n.iconName);
        }
        selectTab(n) {
          var t = this;
          const i = this.linkContainerList.get(n);
          if (void 0 === i) return;
          const o = this.links[n];
          return (
            this.currLink !== o &&
              ((this.prevLink = this.currLink),
              (this.currLink = o),
              this._initLinkRef(o, i),
              (0, c.Z)(function* () {
                (t.panelAnimationsStart(), yield (0, b.v1)(), t.panelAnimationsDone());
              })()),
            o
          );
        }
        _initLinkRef(n, t = this.linkContainerList.get(this.links.indexOf(n))) {
          void 0 === n.ref &&
            void 0 !== n.component &&
            ((n.ref = this._panelVcRef.createComponent(n.component)),
            n.ref.instance instanceof en && (n.ref.instance.supportChainList = this.resolveData.supportChainList),
            this.renderer2.appendChild(null == t ? void 0 : t.nativeElement, n.ref.location.nativeElement),
            n.ref.instance.requestUpdate(),
            this.cdRef.detectChanges());
        }
        panelAnimationsStart() {
          var n;
          this.console.info("animation start");
          const t =
            null === (n = this.currLink) || void 0 === n || null === (n = n.ref) || void 0 === n ? void 0 : n.instance;
          null == t || t.ngOnResume("tab");
        }
        panelAnimationsDone() {
          var n, t, i;
          this.console.info("animation done");
          const o =
              null === (n = this.currLink) || void 0 === n || null === (n = n.ref) || void 0 === n
                ? void 0
                : n.instance,
            l = null == o || null === (t = o.pageTheme$) || void 0 === t ? void 0 : t.value;
          var d;
          void 0 !== l && (null === (d = this.pageTheme$) || void 0 === d || d.next(l));
          const p =
            null === (i = this.prevLink) || void 0 === i || null === (i = i.ref) || void 0 === i ? void 0 : i.instance;
          null == p || p.ngOnPause("tab");
        }
        ngOnPause(n) {
          var t;
          (super.ngOnPause(n),
            null === (t = this.currLink) ||
              void 0 === t ||
              null === (t = t.ref) ||
              void 0 === t ||
              null === (t = t.instance) ||
              void 0 === t ||
              t.ngOnPause(n));
        }
        ngOnResume(n) {
          var t;
          (super.ngOnResume(n),
            null === (t = this.currLink) ||
              void 0 === t ||
              null === (t = t.ref) ||
              void 0 === t ||
              null === (t = t.instance) ||
              void 0 === t ||
              t.ngOnResume(n),
            this.pageReturnPromise && this.pageReturnPromise.resolve(!0));
        }
        openVersionSheet() {
          var n = this;
          return (0, c.Z)(function* () {
            n.versionInfoSheet.open = !0;
          })();
        }
        poolDetailPageReturn() {
          var n = this;
          this.poolDetailPageReturnController.pageReturn$.subscribe(
            (function () {
              var t = (0, c.Z)(function* (i) {
                var o;
                (n.console.log(i),
                  (n.pageReturnPromise = new K.UC()),
                  yield n.pageReturnPromise.promise,
                  yield (0, b.v1)(),
                  (null === (o = n.links[1].ref) || void 0 === o ? void 0 : o.instance).handleRouterParams(
                    i.swapSelectedAsset,
                  ),
                  n.selectTab(1));
              });
              return function (i) {
                return t.apply(this, arguments);
              };
            })(),
          );
        }
      }
      (((Ke = k).ɵfac = (() => {
        let a;
        return function (t) {
          return (a || (a = e.n5z(Ke)))(t || Ke);
        };
      })()),
        (Ke.ɵcmp = e.Xpm({
          type: Ke,
          selectors: [["bs-tabs"]],
          viewQuery: function (n, t) {
            if ((1 & n && (e.Gf(rs, 5), e.Gf(ls, 5, e.s_b), e.Gf(cs, 5, e.SBq)), 2 & n)) {
              let i;
              (e.iGM((i = e.CRH())) && (t.bottomNavSize = i.first),
                e.iGM((i = e.CRH())) && (t._panelVcRef = i.first),
                e.iGM((i = e.CRH())) && (t.linkContainerList = i));
            }
          },
          standalone: !0,
          features: [e.qOj, e.jDz, e.zW0([f.ap])],
          decls: 22,
          vars: 12,
          consts: () => {
            let a;
            return (
              (a = "\u8FDE\u63A5\u94B1\u5305"),
              [
                ["wObSize", "", 1, "grid-in-[wallet]", "z-[3]", 2, "padding-top", "var(--page-safe-area-inset-top)"],
                ["navSize", "obSize"],
                [1, "flex", "h-16", "items-center", "justify-between", "px-4"],
                [1, "flex", "items-center", 3, "click"],
                ["src", "../../assets/images/logo-title.png", 1, "w-[128px]", "h-auto"],
                ["name", "icon-chevron-down-small", 1, "text-title-2", "text-xl"],
                ["class", "flex h-8 items-center rounded-full bg-white/[0.16] px-1"],
                [
                  "wTabGroup",
                  "",
                  1,
                  "grid-in-[wallet/wallet/tabs/tabs]",
                  "_wallet",
                  "z-[2]",
                  "grid",
                  "flex-grow",
                  "grid-flow-col",
                  "overflow-x-hidden",
                  2,
                  "padding-top",
                  "calc(var(--page-safe-area-inset-top) + 4.125rem)",
                  3,
                  "ngStyle",
                  "selectedIndex",
                  "scrollSmooth",
                  "selectedIndexChange$",
                ],
                ["panel", ""],
                ["class", "w-cqw-100 rounded-t-5 block h-full overflow-hidden", "wTab", "", 4, "ngFor", "ngForOf"],
                [
                  "wObSize",
                  "",
                  1,
                  "grid-in-[tabs]",
                  "rounded-10.5",
                  "bg-black-0",
                  "w-cqw-80",
                  "h-15",
                  "absolute",
                  "z-[3]",
                  2,
                  "left",
                  "50%",
                  "transform",
                  "translateX(-50%)",
                  "bottom",
                  "var(--env-safe-area-inset-bottom)",
                  "box-shadow",
                  "0px 16px 24px -12px rgba(9, 22, 68, 0.4)",
                  3,
                  "ngStyle",
                ],
                ["bottomNavSize", "obSize"],
                [1, "flex", "h-full", "items-center", "justify-between", "px-2"],
                [3, "class", "click", 4, "ngFor", "ngForOf"],
                [3, "isOpen", "isOpenChange", "closed$"],
                [3, "isOpen", "isOpenChange"],
                [1, "flex", "h-8", "items-center", "rounded-full", "bg-white/[0.16]", "px-1", 3, "click"],
                [1, "rounded-full", "overflow-hidden", "h-6"],
                [1, "text-2xl", 3, "name"],
                [1, "ml-2", "text-xs", "text-white"],
                ["name", "icon-chevron-down-small", 1, "text-xl", "text-white"],
                [
                  1,
                  "duibs-btn",
                  "duibs-btn-ghost",
                  "min-h-8",
                  "bg-primary-0",
                  "text-title-0",
                  "flex",
                  "h-8",
                  "items-center",
                  "rounded-full",
                  3,
                  "click",
                ],
                ["name", "icon-link", 1, "text-title-0", "text-base"],
                [1, "text-sm", "normal-case"],
                a,
                ["wTab", "", 1, "w-cqw-100", "rounded-t-5", "block", "h-full", "overflow-hidden"],
                ["linkContainer", ""],
                [3, "click"],
                [1, "text-[2rem]", 3, "name"],
                [3, "walletIcon", "connectedWallet", "returnValue$"],
                [3, "connectType", "presetWallets"],
              ]
            );
          },
          template: function (n, t) {
            if (
              (1 & n &&
                (e.TgZ(0, "nav", 0, 1)(2, "div", 2)(3, "div", 3),
                e.NdJ("click", function () {
                  return t.openVersionSheet();
                }),
                e._UZ(4, "img", 4)(5, "bs-icon", 5),
                e.qZA(),
                e.YNc(6, ds, 6, 2, "div", 6)(7, us, 4, 0),
                e.qZA()(),
                e.TgZ(8, "main", 7),
                e.NdJ("selectedIndexChange$", function (o) {
                  return t.selectTab(o);
                }),
                e.GkF(9, null, 8),
                e.YNc(11, _s, 2, 0, "div", 9),
                e.qZA(),
                e.TgZ(12, "nav", 10, 11)(14, "div", 12),
                e.YNc(15, hs, 2, 4, "div", 13),
                e.qZA()(),
                e.TgZ(16, "common-bottom-sheet", 14),
                e.NdJ("isOpenChange", function (o) {
                  return (t.walletInfoSheet.open = o);
                })("closed$", function () {
                  return t.onWalletPanelClose();
                }),
                e.YNc(17, ps, 1, 2, "ng-template"),
                e.qZA(),
                e.TgZ(18, "common-bottom-sheet", 15),
                e.NdJ("isOpenChange", function (o) {
                  return (t.versionInfoSheet.open = o);
                }),
                e.YNc(19, ms, 1, 0, "ng-template"),
                e.qZA(),
                e.TgZ(20, "common-bottom-sheet", 14),
                e.NdJ("isOpenChange", function (o) {
                  return (t.selectWalletSheet.is_open = o);
                })("closed$", function () {
                  return t.onConnectWalletPanelClose();
                }),
                e.YNc(21, gs, 1, 2, "ng-template"),
                e.qZA()),
              2 & n)
            ) {
              let i;
              (e.xp6(6),
                e.um2(6, t.connectedWallet ? 6 : 7),
                e.xp6(2),
                e.Q6J("ngStyle", e.DdM(10, fs))(
                  "selectedIndex",
                  null !== (i = null == t.currLink ? null : t.currLink.index) && void 0 !== i ? i : 0,
                )("scrollSmooth", !1),
                e.xp6(3),
                e.Q6J("ngForOf", t.links),
                e.xp6(1),
                e.Q6J("ngStyle", e.DdM(11, Ss)),
                e.xp6(3),
                e.Q6J("ngForOf", t.links),
                e.xp6(1),
                e.Q6J("isOpen", t.walletInfoSheet.open),
                e.xp6(2),
                e.Q6J("isOpen", t.versionInfoSheet.open),
                e.xp6(2),
                e.Q6J("isOpen", t.selectWalletSheet.is_open));
            }
          },
          dependencies: [_.ez, _.sg, _.PC, x.f5, ce.y, dt.w, Sn.m, Sn.w, O.oJ, h.Bz, M.z, Ne, j],
          styles: [
            '@charset "UTF-8";[_nghost-%COMP%]{width:100%;height:100%;display:grid;grid:auto 1fr auto/1fr;grid-template-areas:"wallet" "panel" "tabs"}[_nghost-%COMP%]   ._active-border[_ngcontent-%COMP%]{position:absolute;left:50%;top:50%;height:3rem;width:3rem;transform-origin:center;border-radius:9999px;border-width:1px;border-style:solid;border-color:#ffffff80;transform:translate(-50%,-50%)}[_nghost-%COMP%]   ._wallet[_ngcontent-%COMP%]{background-image:url(bg-wallet.7f2ab3c120b82428.png);background-size:100% 100%;background-repeat:no-repeat}',
          ],
          changeDetection: 0,
        })),
        (0, s.gn)([k.State(), (0, s.w6)("design:type", Object)], k.prototype, "bottomNavHeight", void 0),
        (0, s.gn)(
          [
            k.OnInit(),
            (0, s.w6)("design:type", Function),
            (0, s.w6)("design:paramtypes", []),
            (0, s.w6)("design:returntype", void 0),
          ],
          k.prototype,
          "dataInit",
          null,
        ),
        (0, s.gn)([k.State(), (0, s.w6)("design:type", Object)], k.prototype, "currLink", void 0),
        (0, s.gn)(
          [
            k.OnDestroy(),
            (0, s.w6)("design:type", Function),
            (0, s.w6)("design:paramtypes", []),
            (0, s.w6)("design:returntype", void 0),
          ],
          k.prototype,
          "unsubscribe",
          null,
        ),
        (0, s.gn)(
          [
            k.AfterViewInit(),
            (0, s.w6)("design:type", Function),
            (0, s.w6)("design:paramtypes", []),
            (0, s.w6)("design:returntype", Promise),
          ],
          k.prototype,
          "initLink",
          null,
        ),
        (0, s.gn)([k.State(), (0, s.w6)("design:type", Object)], k.prototype, "walletIcon", void 0),
        (0, s.gn)([k.State(), (0, s.w6)("design:type", Object)], k.prototype, "connectedWallet", void 0),
        (0, s.gn)(
          [
            k.OnInit(),
            (0, s.w6)("design:type", Function),
            (0, s.w6)("design:paramtypes", []),
            (0, s.w6)("design:returntype", void 0),
          ],
          k.prototype,
          "hideSplashScreen",
          null,
        ),
        (0, s.gn)([k.States(1), (0, s.w6)("design:type", Object)], k.prototype, "selectWalletSheet", void 0),
        (0, s.gn)([k.States(1), (0, s.w6)("design:type", Object)], k.prototype, "walletInfoSheet", void 0),
        (0, s.gn)([k.States(1), (0, s.w6)("design:type", Object)], k.prototype, "versionInfoSheet", void 0),
        (0, s.gn)(
          [
            k.OnInit(),
            (0, s.w6)("design:type", Function),
            (0, s.w6)("design:paramtypes", []),
            (0, s.w6)("design:returntype", void 0),
          ],
          k.prototype,
          "initTheme",
          null,
        ),
        (0, s.gn)(
          [
            k.OnInit(),
            (0, s.w6)("design:type", Function),
            (0, s.w6)("design:paramtypes", []),
            (0, s.w6)("design:returntype", void 0),
          ],
          k.prototype,
          "handleWalletIcon",
          null,
        ),
        (0, s.gn)([k.State(), (0, s.w6)("design:type", Object)], k.prototype, "poolDetailPageReturnController", void 0),
        (0, s.gn)(
          [
            k.OnInit(),
            (0, s.w6)("design:type", Function),
            (0, s.w6)("design:paramtypes", []),
            (0, s.w6)("design:returntype", void 0),
          ],
          k.prototype,
          "poolDetailPageReturn",
          null,
        ));
      const Ts = k;
    },
    41072: (u, m, r) => {
      "use strict";
      r.d(m, { n: () => _ });
      var c = r(31678),
        s = r(35554);
      let _ = (() => {
        var e;
        class h {
          constructor() {
            this.transform = h.transform;
          }
          static transform(S) {
            return void 0 === S ? 0 : new c.Z(S).toFormat();
          }
        }
        return (
          ((e = h).ɵfac = function (S) {
            return new (S || e)();
          }),
          (e.ɵpipe = s.Yjl({
            name: "amountFormat",
            type: e,
            pure: !0,
            standalone: !0,
          })),
          h
        );
      })();
    },
    84375: (u, m, r) => {
      "use strict";
      r.d(m, { c: () => _ });
      var c = r(99557),
        s = r(35554);
      let _ = (() => {
        var e;
        class h {
          constructor() {
            this.transform = h.transform;
          }
          static transform(S) {
            return void 0 === S ? "" : c.AG[S];
          }
        }
        return (
          ((e = h).ɵfac = function (S) {
            return new (S || e)();
          }),
          (e.ɵpipe = s.Yjl({
            name: "chainNameTransfer",
            type: e,
            pure: !0,
            standalone: !0,
          })),
          h
        );
      })();
    },
    57644: (u, m, r) => {
      "use strict";
      r.d(m, { d: () => _ });
      var c = r(31678),
        s = r(35554);
      let _ = (() => {
        var e;
        class h {
          constructor() {
            this.transform = h.transform;
          }
          static transform(S, b = { havePercent: !0 }) {
            if (!S || void 0 === S) return 0;
            const P = new c.Z(S).multipliedBy(100);
            return P.isLessThan(0.01)
              ? b.havePercent
                ? "<0.01%"
                : "<0.01"
              : Number(P.toFixed(2, 1)).toString() + (b.havePercent ? "%" : "");
          }
        }
        return (
          ((e = h).ɵfac = function (S) {
            return new (S || e)();
          }),
          (e.ɵpipe = s.Yjl({
            name: "percentageTransfer",
            type: e,
            pure: !0,
            standalone: !0,
          })),
          h
        );
      })();
    },
  },
]);
