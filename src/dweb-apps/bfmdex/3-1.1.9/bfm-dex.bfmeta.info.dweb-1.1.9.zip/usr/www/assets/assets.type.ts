import { CHAIN_NAME } from '@bnqkl/wallet-base/services';
import { type $BfswapIconName } from '~components/icon/icon.component';

/** 配置的链信息 */
export type $SupportChain = {
  chain: CHAIN_NAME;
  symbol: string;
  activeIcon: $BfswapIconName;
  unactiveIcon: $BfswapIconName;
};
export type $CHAIN_CARD_INFO_MAP = Map<CHAIN_NAME, $CHAIN_CARD_INFO>;

export type $CHAIN_CARD_INFO = {
  bgColor: string;
  bgIconUrl: string;
};
